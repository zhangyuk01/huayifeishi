package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordConfrimDO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	/**一级授信金额*/
	private BigDecimal agreeAmount;

	/**一级授信期数*/
	private Integer agreeProductLimit;

	
	
	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public Integer getAgreeProductLimit() {
		return agreeProductLimit;
	}
	public void setAgreeProductLimit(Integer agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}
}
