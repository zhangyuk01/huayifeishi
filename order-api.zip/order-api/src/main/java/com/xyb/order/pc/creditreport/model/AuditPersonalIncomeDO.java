package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditPersonalIncomeDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //id
	private Long custId;//客户ID
	private Long applyId;//申请单ID
	private String cardAccount;//卡号账户名
	private Long cardType;//流水类型
	private String cardTypeStr;//
	private String card;//卡号
	private String cardLogsDate;//银行卡流水具体日期
	private Date cardLogsDateStart;//银行卡1流水日期起于
	private Date cardLogsDateEnd;//银行卡1流水日期至于
	private Double cardMonth0;//卡号1资金流水往
	private Double cardMonth1;//卡号1资金流水往前第1个月
	private Double cardMonth2;//卡号1资金流水往前第2个月
	private Double cardMonth3;//卡号1资金流水往前第3个月
	private Double cardMonth4;//卡号1资金流水往前第4个月
	private Double cardMonth5;//卡号1资金流水往前第5个月
	private Double cardAmountAvg;//卡1月均流水金额
	private String cardRemark;//卡1流水备注
	private Long isDelState;//是否可删除状态
	private String isDelStateStr;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getCardAccount() {
		return cardAccount;
	}
	public void setCardAccount(String cardAccount) {
		this.cardAccount = cardAccount;
	}
	public Long getCardType() {
		return cardType;
	}
	public void setCardType(Long cardType) {
		this.cardType = cardType;
	}
	public String getCardTypeStr() {
		return cardTypeStr;
	}
	public void setCardTypeStr(String cardTypeStr) {
		this.cardTypeStr = cardTypeStr;
	}
	public String getCard() {
		return card;
	}
	public void setCard(String card) {
		this.card = card;
	}
	public String getCardLogsDate() {
		return cardLogsDate;
	}
	public void setCardLogsDate(String cardLogsDate) {
		this.cardLogsDate = cardLogsDate;
	}
	public Date getCardLogsDateStart() {
		return cardLogsDateStart;
	}
	public void setCardLogsDateStart(Date cardLogsDateStart) {
		this.cardLogsDateStart = cardLogsDateStart;
	}
	public Date getCardLogsDateEnd() {
		return cardLogsDateEnd;
	}
	public void setCardLogsDateEnd(Date cardLogsDateEnd) {
		this.cardLogsDateEnd = cardLogsDateEnd;
	}
	public Double getCardMonth0() {
		return cardMonth0;
	}
	public void setCardMonth0(Double cardMonth0) {
		this.cardMonth0 = cardMonth0;
	}
	public Double getCardMonth1() {
		return cardMonth1;
	}
	public void setCardMonth1(Double cardMonth1) {
		this.cardMonth1 = cardMonth1;
	}
	public Double getCardMonth2() {
		return cardMonth2;
	}
	public void setCardMonth2(Double cardMonth2) {
		this.cardMonth2 = cardMonth2;
	}
	public Double getCardMonth3() {
		return cardMonth3;
	}
	public void setCardMonth3(Double cardMonth3) {
		this.cardMonth3 = cardMonth3;
	}
	public Double getCardMonth4() {
		return cardMonth4;
	}
	public void setCardMonth4(Double cardMonth4) {
		this.cardMonth4 = cardMonth4;
	}
	public Double getCardMonth5() {
		return cardMonth5;
	}
	public void setCardMonth5(Double cardMonth5) {
		this.cardMonth5 = cardMonth5;
	}
	public Double getCardAmountAvg() {
		return cardAmountAvg;
	}
	public void setCardAmountAvg(Double cardAmountAvg) {
		this.cardAmountAvg = cardAmountAvg;
	}
	public String getCardRemark() {
		return cardRemark;
	}
	public void setCardRemark(String cardRemark) {
		this.cardRemark = cardRemark;
	}
	public Long getIsDelState() {
		return isDelState;
	}
	public void setIsDelState(Long isDelState) {
		this.isDelState = isDelState;
	}
	public String getIsDelStateStr() {
		return isDelStateStr;
	}
	public void setIsDelStateStr(String isDelStateStr) {
		this.isDelStateStr = isDelStateStr;
	}
}
