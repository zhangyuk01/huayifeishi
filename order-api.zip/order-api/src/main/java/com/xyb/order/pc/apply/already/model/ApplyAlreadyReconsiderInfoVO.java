package com.xyb.order.pc.apply.already.model;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 申请已办复议记录信息
 * @createDate : 2018/06/05 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyReconsiderInfoVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1474149442653973241L;

	/**第一次复议申请信息*/
	private ApplyAlreadyReconsiderOneInfoVO applyAlreadyReconsiderOneInfoVO;
	/**第二次复议申请信息*/
	private ApplyAlreadyReconsiderTwoInfoVO applyAlreadyReconsiderTwoInfoVO;
	/**第一次复议审核信息*/
	private ApplyAlreadyReconsiderAuditOneInfoVO applyAlreadyReconsiderAuditOneInfoVO;
	/**第二次复议申请信息*/
	private ApplyAlreadyReconsiderAuditTwoInfoVO applyAlreadyReconsiderAuditTwoInfoVO;
	public ApplyAlreadyReconsiderOneInfoVO getApplyAlreadyReconsiderOneInfoVO() {
		return applyAlreadyReconsiderOneInfoVO;
	}
	public void setApplyAlreadyReconsiderOneInfoVO(ApplyAlreadyReconsiderOneInfoVO applyAlreadyReconsiderOneInfoVO) {
		this.applyAlreadyReconsiderOneInfoVO = applyAlreadyReconsiderOneInfoVO;
	}
	public ApplyAlreadyReconsiderTwoInfoVO getApplyAlreadyReconsiderTwoInfoVO() {
		return applyAlreadyReconsiderTwoInfoVO;
	}
	public void setApplyAlreadyReconsiderTwoInfoVO(ApplyAlreadyReconsiderTwoInfoVO applyAlreadyReconsiderTwoInfoVO) {
		this.applyAlreadyReconsiderTwoInfoVO = applyAlreadyReconsiderTwoInfoVO;
	}
	public ApplyAlreadyReconsiderAuditOneInfoVO getApplyAlreadyReconsiderAuditOneInfoVO() {
		return applyAlreadyReconsiderAuditOneInfoVO;
	}
	public void setApplyAlreadyReconsiderAuditOneInfoVO(
			ApplyAlreadyReconsiderAuditOneInfoVO applyAlreadyReconsiderAuditOneInfoVO) {
		this.applyAlreadyReconsiderAuditOneInfoVO = applyAlreadyReconsiderAuditOneInfoVO;
	}
	public ApplyAlreadyReconsiderAuditTwoInfoVO getApplyAlreadyReconsiderAuditTwoInfoVO() {
		return applyAlreadyReconsiderAuditTwoInfoVO;
	}
	public void setApplyAlreadyReconsiderAuditTwoInfoVO(
			ApplyAlreadyReconsiderAuditTwoInfoVO applyAlreadyReconsiderAuditTwoInfoVO) {
		this.applyAlreadyReconsiderAuditTwoInfoVO = applyAlreadyReconsiderAuditTwoInfoVO;
	}
	@Override
	public String toString() {
		return "ApplyAlreadyReconsiderInfoVO [applyAlreadyReconsiderOneInfoVO=" + applyAlreadyReconsiderOneInfoVO
				+ ", applyAlreadyReconsiderTwoInfoVO=" + applyAlreadyReconsiderTwoInfoVO
				+ ", applyAlreadyReconsiderAuditOneInfoVO=" + applyAlreadyReconsiderAuditOneInfoVO
				+ ", applyAlreadyReconsiderAuditTwoInfoVO=" + applyAlreadyReconsiderAuditTwoInfoVO + "]";
	}
	
}
