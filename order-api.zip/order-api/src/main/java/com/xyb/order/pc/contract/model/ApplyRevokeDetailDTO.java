package com.xyb.order.pc.contract.model;


import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;


public class ApplyRevokeDetailDTO implements IBaseModel{
	
	/**序列化*/
	private static final long serialVersionUID = 1L;
	/**系统ID*/
	@SignField(order = 0)
	private Long sysId;
	/**借款申请ID*/
	@SignField(order = 1)
	private Long applyId;
	/**[非空][Long]借款人资产账户ID*/
	@SignField(order = 2)
	private Long acctId;
	/**[选填][String,500]返回地址*/
	private String returnUrl;
	/**交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面*/
	private String client;
	/**商户自定义数据——必填,用于传递商户自定义数据，商户上传的数据会直接返回给商户*/
	private String custom;
	/**客户端ip,必填*/
	private String client_ip;
	/**必填,电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）*/
	private String client_service;
	public Long getSysId() {
		return sysId;
	}
	public void setSysId(Long sysId) {
		this.sysId = sysId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getAcctId() {
		return acctId;
	}
	public void setAcctId(Long acctId) {
		this.acctId = acctId;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getCustom() {
		return custom;
	}
	public void setCustom(String custom) {
		this.custom = custom;
	}
	public String getClient_ip() {
		return client_ip;
	}
	public void setClient_ip(String client_ip) {
		this.client_ip = client_ip;
	}
	public String getClient_service() {
		return client_service;
	}
	public void setClient_service(String client_service) {
		this.client_service = client_service;
	}
	@Override
	public String toString() {
		return "ApplyRevokeDetailDTO [sysId=" + sysId + ", applyId=" + applyId + ", acctId=" + acctId + ", returnUrl="
				+ returnUrl + ", client=" + client + ", custom=" + custom + ", client_ip=" + client_ip
				+ ", client_service=" + client_service + "]";
	}

}
