package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;
/**
 * 解绑银行卡请求明细
 * @author         fang
 * @date           2018/11/23 10:20 AM
*/
public class UnBindBankCardRequestBodyDTO implements IBaseModel {

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 7383086863708857218L;

	private String sysId;
	//电子账户,必填，开户返回的电子账户，19(位数)
	@SignField(order = 0)
	private String card_no;
	//客户号，11(位数)
	private String customer_no;
	//绑定卡号，19(位数)
	@SignField(order = 1)
	private String bank_card_no;
	//三方绑定编号，32(位数)	
	private String serial_no;
	//成功跳转地址，256(位数)
	@SignField(order = 2)
	private String success_url;
	//失败跳转地址，256(位数)
	@SignField(order = 3)
	private String fail_url;
	//交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面
	private String client;
	//商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户
	private String custom;
	//客户端ip
	private String client_ip;
	//电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）
	private String client_service;
	public String getCard_no() {
		return card_no;
	}
	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}
	public String getCustomer_no() {
		return customer_no;
	}
	public void setCustomer_no(String customer_no) {
		this.customer_no = customer_no;
	}
	public String getBank_card_no() {
		return bank_card_no;
	}
	public void setBank_card_no(String bank_card_no) {
		this.bank_card_no = bank_card_no;
	}
	public String getSerial_no() {
		return serial_no;
	}
	public void setSerial_no(String serial_no) {
		this.serial_no = serial_no;
	}
	public String getSuccess_url() {
		return success_url;
	}
	public void setSuccess_url(String success_url) {
		this.success_url = success_url;
	}
	public String getFail_url() {
		return fail_url;
	}
	public void setFail_url(String fail_url) {
		this.fail_url = fail_url;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getCustom() {
		return custom;
	}
	public void setCustom(String custom) {
		this.custom = custom;
	}
	public String getClient_ip() {
		return client_ip;
	}
	public void setClient_ip(String client_ip) {
		this.client_ip = client_ip;
	}
	public String getClient_service() {
		return client_service;
	}
	public void setClient_service(String client_service) {
		this.client_service = client_service;
	}
	public String getSysId() {
		return sysId;
	}
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	@Override
	public String toString() {
		return "UnBindBankCardRequestBodyDTO [sysId=" + sysId + ", card_no=" + card_no + ", customer_no=" + customer_no
				+ ", bank_card_no=" + bank_card_no + ", serial_no=" + serial_no + ", success_url=" + success_url
				+ ", fail_url=" + fail_url + ", client=" + client + ", custom=" + custom + ", client_ip=" + client_ip
				+ ", client_service=" + client_service + "]";
	}
	
	

}
