package com.xyb.order.common.constant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.xyb.order.common.util.StringUtils;

/**
 * 节点状态常量类
 * @author         xieqingyang
 * @date           2018/4/4 10:20 AM
*/
public class NodeStateConstant {

    /**
     * 客户申请
     */
    public static final Integer CLIENT_APPLY = 100;

    /**
     * 待授权
     * 已失效
     */
    public static final Integer TO_BE_PRETRIAL = 101;
    /**
     * 预审中
     * 已失效
     */
    public static final Integer TO_BE_AUTHORIZED = 102;
    /**
     * 待分配客服
     */
    public static final Integer UNDISTRIBUTED_CUSTOMER_SERVICE = 104;
    /**
     * 客服录入中
     */
    public static final Integer CUSTOMER_SERVICE_ENTRY = 105;
    /**
     * 复核中
     */
    public static final Integer RECHECK = 106;
    /**
     * 系统审核中
     */
    public static final Integer PENDING_SYSTEM_AUDIT = 107;
    /**
     * 申请作废
     */
    public static final Integer APPLY_FOR_INVALIDATION = 109;

    /**
     * 材料补充
     */
    public static final Integer MATERIAL_SUPPLEMENT = 111;
    /**
     * 冻结
     */
    public static final Integer CONTRACT_FREEZE = 119;

    /**
     * 外访中
     */
    public static final Integer OUTSIDE_VISIT = 121;

    /**
     * 签约前核验
     */
    public static final Integer BEFORE_SIGNING_THE_CONTRACT_VERIFICATION = 131;

    /**
     * 合同录入中
     */
    public static final Integer CONTRACT_ENTRY = 141;
    /**
     * 合同审核
     */
    public static final Integer CONTRACT_REVIEW = 142;
    /**
     * 募标中
     */
    public static final Integer IN_THE_BID = 143;
    /**
     * 合同生效
     */
    public static final Integer THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT = 144;

    /**
     * 客户签约
     */
    public static final Integer CLIENT_CONTRACT = 145;

    /**
     * 待签约协议
     */
    public static final Integer AGREEMENT_SIGNED = 146;

    /**
     * 待签约协议
     */
    public static final Integer TO_RAISED = 147;

    /**
     * 合同作废
     */
    public static final Integer CONTRACT_INVALIDATION = 149;

    /**
     * 复议申请
     */
    public static final Integer APPLICATION_FOR_RECONSIDERATION = 151;

    /**
     * 反欺诈拒贷
     */
    public static final Integer ANTI_FRAUD_REFUSAL_LEND = 194;

    /**
     * 系统审核拒贷 进件
     */
    public static final Integer SYSTEM_AUDITS_APPLY = 195;
    /**
     * 风险提报拒贷
     */
    public static final Integer RIS_REPORTING_AND_REFUSING_TO_LEND = 196;
    /**
     * 合同审核拒贷
     */
    public static final Integer CONTRACT_REVIEW_TO_LEND = 197;

    /**
     * 预审批不通过
     */
    public static final Integer THE_PRETRIAL_APPROVAL_IS_NOT_PASSED = 199;

    /**
     * 初审待分件
     */
    public static final Integer FIRST_TRIAL_TO_BE_DIVIDED = 201;
    /**
     * 初审已分件
     */
    public static final Integer FIRST_TRIAL_HAS_BEEN_DIVIDED = 202;
    /**
     * 终审待分件
     */
    public static final Integer FINAL_ADJUDICATION = 203;
    /**
     * 终审已分件
     */
    public static final Integer FINAL_TRIAL_HAS_BEEN_DIVIDED = 204;

    /**
     * 初审中
     */
    public static final Integer FIRST_TRIAL = 210;

    /**
     * 审核中
     */
    public static final Integer AUDIT = 220;

    /**
     * 终审中
     */
    public static final Integer IN_THE_FINAL_TRIAL = 230;

    /**
     * 签约前核验审核中
     */
    public static final Integer BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT = 240;

    /**
     * 复议审核中
     */
    public static final Integer REVIEW_AND_REVIEW = 250;

    /**
     * 系统审核
     */
    public static final Integer SYSTEM_AUDIT = 260;
    
    /**
     * 借款金额确认中
     */
    public static final Integer LOAN_APPLY_CONFIRM = 280;

    /**
     * 反欺诈审核中
     */
    public static final Integer ANTI_FRAUD_AUDIT = 270;

    /**
     * 借款金额确认中
     */
    public static final Integer CONFIRMATION_LOAN_AMOUNT = 280;

    /**
     * 系统审核拒贷 信审
     */
    public static final Integer SYSTEM_AUDITS_AUDIT = 297;
    /**
     * 签约前核验拒贷
     */
    public static final Integer BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT = 298;
    /**
     * 终审拒贷
     */
    public static final Integer FINAL_LEND = 299;

    /**实地征信和产调*/
    public static final Long  VISIT_MAIN_TYPE_2522 = 2522L;
    /**实地征信*/
    public static final Long  VISIT_MAIN_TYPE_2523 = 2523L;
    /**产调*/
    public static final Long  VISIT_MAIN_TYPE_2611 = 2611L;

    /* 数组模式的节点状态 contains() 判断list中是否存在某值*/
    /**
     * 已办状态的审核中/全量进程表-流程状态   信审节点：初审待分件、初审已分件、终审待分件、终审已分件、初审中、审核中、终审中、复议审核中、反欺诈审核中
     */
    private static final List<Integer> AUDIT_LIST = Arrays.asList(201,202,203,204,210,220,230,250,270);
    /**
     * 合同废除  合同审核拒贷、合同作废
     */
    private static final List<Integer> CONTRACT_INVALIDATION_LIST = Arrays.asList(197,149);
    /**
     * 合同中 签约前核验、签约前核验审核、合同录入中、合同审核中、募标中
     */
    private static final List<Integer> IN_CONTRACT_LIST = Arrays.asList(131,240,141,142,143);
    /**
     * 系统拒贷
     */
    private static final List<Integer> IN_SYSTEM_AUDIT_LIST = Arrays.asList(195,297);
    /**
     * 系统审核中  进件系统审核中、信审系统审核中
     */
    private static final List<Integer> SYSTEM_REFUSING_LEND_LIST = Arrays.asList(107,260);
    /**
     * 审核拒贷
     */
    private static final List<Integer> AUDIT_SYSTEM_REFUSING_LEND_LIST = Arrays.asList(298,299,194);
    /* ----------列表查询状态---------- */
    /**
     * 复议列表查询状态 合同录入中、终审拒贷
     */
    public static final List<Integer> RECONSIDERATION_STATE_LIST = Arrays.asList(141,299);
    /**
     * 风险提报列表查询状态 材料补充、确认借款、签约前核验、签约前核验审核中、合同录入中、合同审核中、募标中、客户签约、风险提报拒贷
     */
    public static final List<Integer> RISK_SUBMIT_LIST = Arrays.asList(111,280,131,240,141,142,143,145,196);
    /**
     * 咨询分配列表查询状态 待分配客服、客服录入中
     */
    public static final List<Integer> CONSULT_LIST = Arrays.asList(104,105);
    /**
     * 已办申请下审核中节点集 
     */
    public static final List<Integer> ALREADY_AUDIT_LIST = Arrays.asList(104,105);
    /**
     * 用户换卡查询节点
     */
    public static final List<Integer> CHANGE_CARD_LIST = Arrays.asList(104,105,107,111,121,131,141,142,143,144,201,202,204,210,220,230,240,250,260,280);

   
    /**
     * B端借款申请中节点
     * 待分配客服、客服录入中、系统审核中、初审待分件、初审已分件、终审待分件、终审已分件、初审中、审核中、终审中、 系统审核、
     * 签约前核验审核中、 复议审核中、 合同审核、 外访中 、材料补充 、签约前核验 、确认借款 、 募标中的借款申请 、 合同录入中、反欺诈审核中
     */
    public static final List<Integer> APPLY_RECORD_PROCESS =Arrays.asList(104,105,107,201,202,203,204,210,220,230,260,
    		240,250,142,121,111,131,280,143,141,270);

    /**C端借款申请提交申请*/
    public static final List<Integer> APPLY_RECORD_BEGIN = Arrays.asList(104,105);


    /**C端借款申请 审核中*/
    public static final List<Integer> APPLY_RECORD_SHENHE = Arrays.asList(107,201,202,203,204,210,220,230,260,
    		240,250,121,111,131,270);


    /**C端借款申请 确认借款*/
    public static final List<Integer> APPLY_RECORD_QUREJIKUAN = Arrays.asList(280);

    /**C端借款申请 募标中*/
    public static final List<Integer> APPLY_RECORD_MUBIAOZHONG = Arrays.asList(143);

    /**C端借款申请 合同中*/
    public static final List<Integer> APPLY_RECORD_HETONGZHONG = Arrays.asList(141,142);

    /**速贷综合查询系统据贷状态*/
    public static final List<Integer> QUICK_LOAN_SYSTEM_REFUSING_LEND_LIST = Arrays.asList(194,195);

    /*临时节点*/
    /**审核中*/
    public static final int IN_AUDIT = 0;
    /**合同中*/
    public static final int IN_CONTRACT = 1;
    /**合同废除*/
    public static final int ABOLISH_CONTRACT = 2;
    /**系统审核中*/
    public static final int IN_SYSTEM_AUDIT = 3;
    /**系统拒贷*/
    public static final int SYSTEM_REFUSING_LEND = 4;
    /**审核拒贷*/
    public static final int AUDIT_SYSTEM_REFUSING_LEND = 5;
    /**速贷综合查询系统拒贷状态*/
    public static final int QUICK_LOAN_SYSTEM_REFUSING_LEND = 6;

    /**
     * 根据节点获得集合
     * @author      xieqingyang
     * @date        2018/10/16 10:25 AM
     * @version     1.0
     * @param state 节点
     * @return 返回节点集合
     */
    public static List<Integer> getNodeStateList(Integer state){
        List<Integer> list;
        if (state == IN_AUDIT){
            list = AUDIT_LIST;
        }else if (state == IN_CONTRACT){
            list = IN_CONTRACT_LIST;
        }else if (state == ABOLISH_CONTRACT){
            list = CONTRACT_INVALIDATION_LIST;
        }else if (state == IN_SYSTEM_AUDIT){
            list = SYSTEM_REFUSING_LEND_LIST;
        }else if (state == SYSTEM_REFUSING_LEND){
            list = IN_SYSTEM_AUDIT_LIST;
        }else if (state == AUDIT_SYSTEM_REFUSING_LEND){
            list = AUDIT_SYSTEM_REFUSING_LEND_LIST;
        }else if (state == QUICK_LOAN_SYSTEM_REFUSING_LEND){
        	list = QUICK_LOAN_SYSTEM_REFUSING_LEND_LIST;
        }else {
            list = new ArrayList<>();
            list.add(state);
        }
        return list;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 复议列表使用
     * @author      xieqingyang
     * @date        2018/10/16 10:25 AM
     * @version     1.0
     * @param state 节点状态
     * @return 返回节点名称
     */
    public static String getNodeStateNameOfReconsideration(Integer state){
        String stateName = "";
        if (SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "系统审核中";
        }else if (MATERIAL_SUPPLEMENT.equals(state)){
            stateName = "材料补充";
        }else if (AUDIT_LIST.contains(state)){
            stateName = "审核中";
        }else if (RIS_REPORTING_AND_REFUSING_TO_LEND.equals(state)){
            stateName = "风险提报拒贷";
        }else if (OUTSIDE_VISIT.equals(state)){
            stateName = "外访中";
        }else if (REVIEW_AND_REVIEW.equals(state)){
            stateName = "复议审核中";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION.equals(state)){
            stateName = "签约前核验";
        }else if (CONTRACT_ENTRY.equals(state)){
            stateName = "合同录入中";
        }else if (CONTRACT_REVIEW.equals(state)){
            stateName = "合同审核中";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT.equals(state)){
            stateName = "签约前核验审核中";
        }else if (CONTRACT_REVIEW_TO_LEND.equals(state)){
            stateName = "合同审核拒贷";
        }else if (IN_THE_BID.equals(state)){
            stateName = "募标中";
        }else if (CLIENT_CONTRACT.equals(state)){
            stateName = "客户签约";
        }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
            stateName = "合同生效";
        }else if (CONTRACT_INVALIDATION.equals(state)){
            stateName = "合同作废";
        }else if (CONTRACT_FREEZE.equals(state)){
            stateName = "冻结";
        }else if (CONFIRMATION_LOAN_AMOUNT.equals(state)){
            stateName = "确认借款";
        }else if (IN_SYSTEM_AUDIT_LIST.contains(state)){
            stateName = "系统拒贷";
        }
        return stateName;
    }

    /**
     * @description 根据节点判断是否在集合中，获取对应的标记 B端APP借款申请使用
     * @author      ZhangYu
     * @CreatedDate 2018/9/19 14:11
     * @param state 节点状态
     * @return 返回节点名称
     */
    public static String getNodeFlagOfApplyRecord(Integer state){
    	String flag = "";
    	if (APPLY_RECORD_BEGIN.contains(state)){
    		 flag = "1";
    	}else if(APPLY_RECORD_SHENHE.contains(state)){
    		 flag = "2";
    	}else if(APPLY_RECORD_QUREJIKUAN.contains(state)){
    		 flag = "3";
    	}else if(APPLY_RECORD_MUBIAOZHONG.contains(state)){
    		 flag = "4";
    	}else if(APPLY_RECORD_HETONGZHONG.contains(state)){
    		 flag = "5";
    	}
    	return flag;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 B端APP借款申请使用
     * @author      ZhangYu
     * @date 2018/9/19 14:11
     * @param flag 节点状态
     * @return 返回节点名称
     */
    public static String getNodeStateNameOfApplyRecord(String flag){
    	String stateName = "";
    	if (StringUtils.isNullOrEmpty(flag)) {
    		return stateName;
		}
    	if ("1".equals(flag)) {
    		 stateName = "提交申请";
		}else if("2".equals(flag)){
			stateName = "审核中";
		}else if("3".equals(flag)){
			stateName = "确认借款";
		}else if("4".equals(flag)){
    		stateName = "募标中";
		}else if("5".equals(flag)){
    		 stateName = "合同中";
		}
    	return stateName;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 已办申请使用
     * @author      xieqingyang
     * @date        2018/10/16 10:25 AM
     * @version     1.0
     * @param state 节点状态
     * @return 返回节点名称
     */
    public static String getNodeStateNameOfApplyAlready(Integer state){
        String stateName = "";
        if (SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "系统审核中";
        }else if (IN_SYSTEM_AUDIT_LIST.contains(state)){
            stateName = "系统拒贷";
        }else if (MATERIAL_SUPPLEMENT.equals(state)){
            stateName = "材料补充";
        }else if (AUDIT_LIST.contains(state)){
            stateName = "审核中";
        }else if (OUTSIDE_VISIT.equals(state)){
            stateName = "外访中";
        }else if (CONFIRMATION_LOAN_AMOUNT.equals(state)){
            stateName = "确认借款";
        }else if (CONTRACT_ENTRY.equals(state)){
            stateName = "合同录入中";
        }else if (CONTRACT_REVIEW.equals(state)){
            stateName = "合同审核中";
        }else if (REVIEW_AND_REVIEW.equals(state)){
            stateName = "复议审核中";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION.equals(state)){
            stateName = "签约前核验";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT.equals(state)){
            stateName = "签约前核验审核中";
        }else if (IN_THE_BID.equals(state)){
            stateName = "募标中";
        }else if (AUDIT_SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "审核拒贷";
        }else if (CONTRACT_REVIEW_TO_LEND.equals(state)){
            stateName = "合同审核拒贷";
        }else if (CLIENT_CONTRACT.equals(state)){
            stateName = "客户签约";
        }else if (CONTRACT_FREEZE.equals(state)){
            stateName = "冻结";
        }else if (CONTRACT_INVALIDATION.equals(state)){
            stateName = "合同作废";
        }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
            stateName = "合同生效";
        }else if (RIS_REPORTING_AND_REFUSING_TO_LEND.equals(state)){
            stateName = "风险提报拒贷";
        }
        return stateName;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 外访使用
     * @author      xieqingyang
     * @date        2018/10/16 10:24 AM
     * @version     1.0
     * @param state 状态节点
     * @return 返回状态名称
     */
    public static String getNodeStateNameOfVisit(Integer state){
        String stateName = "";
        if (AUDIT_LIST.contains(state)){
            stateName = "审核中";
        }else if (IN_CONTRACT_LIST.contains(state)){
            stateName = "合同中";
        }else if (CONTRACT_INVALIDATION_LIST.contains(state)){
            stateName = "合同废除";
        }else if (FINAL_LEND.equals(state)){
            stateName = "终审拒贷";
        }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
            stateName = "合同生效";
        }else if (CLIENT_CONTRACT.equals(state)){
            stateName = "客户签约";
        }
        return stateName;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 区域综合查询/全量进程表
     * @author      xieqingyang
     * @date        2018/10/16 10:24 AM
     * @version     1.0
     * @param state 状态节点
     * @return 返回状态名称
     */
    public static String getNodeStateNameOfReport(Integer state){
        String stateName = "";
        if (CUSTOMER_SERVICE_ENTRY.equals(state)){
            stateName = "客服录入中";
        }else if (APPLY_FOR_INVALIDATION.equals(state)){
            stateName = "申请作废";
        }else if (SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "系统审核中";
        }else if (IN_SYSTEM_AUDIT_LIST.contains(state)){
            stateName = "系统拒贷";
        }else if (MATERIAL_SUPPLEMENT.equals(state)){
            stateName = "补充材料";
        }else if (AUDIT_LIST.contains(state)){
            stateName = "审核中";
        }else if (OUTSIDE_VISIT.equals(state)){
            stateName = "外访中";
        }else if (CONFIRMATION_LOAN_AMOUNT.equals(state)){
            stateName = "确认借款";
        }else if (CONTRACT_ENTRY.equals(state)){
            stateName = "合同录入中";
        }else if (CONTRACT_REVIEW.equals(state)){
            stateName = "合同审核中";
        }else if (REVIEW_AND_REVIEW.equals(state)){
            stateName = "复议审核中";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION.equals(state)){
            stateName = "签约前核验";
        }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT.equals(state)){
            stateName = "签约前核验审核中";
        }else if (IN_THE_BID.equals(state)){
            stateName = "募标中";
        }else if (AUDIT_SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "审核拒贷";
        }else if (CLIENT_CONTRACT.equals(state)){
            stateName = "客户签约";
        }else if (CONTRACT_INVALIDATION.equals(state)){
            stateName = "合同作废";
        }else if (CONTRACT_REVIEW_TO_LEND.equals(state)){
            stateName = "合同审核拒贷";
        }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
            stateName = "合同生效";
        }else if (CONTRACT_FREEZE.equals(state)){
            stateName = "冻结";
        }
        return stateName;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 综合查询
     * @author      xieqingyang
     * @date        2018/10/16 10:24 AM
     * @version     1.0
     * @param state 状态节点
     * @return 返回状态名称
     */
    public static String getNodeStateNameOfAllQueryReport(Integer state){
    	 String stateName = "";
         if (CUSTOMER_SERVICE_ENTRY.equals(state)){
             stateName = "客服录入中";
         }else if (MATERIAL_SUPPLEMENT.equals(state)){
             stateName = "补充材料";
         }else if (APPLY_FOR_INVALIDATION.equals(state)){
             stateName = "申请作废";
         }else if (RIS_REPORTING_AND_REFUSING_TO_LEND.equals(state)){
             stateName = "风险提报拒贷";
         }else if (CONTRACT_FREEZE.equals(state)){
             stateName = "冻结";
         }else if (FINAL_LEND.equals(state)){
             stateName = "终审拒贷";
         }else if (BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT.equals(state)){
             stateName = "签约前核验拒贷";
         }else if (AUDIT_LIST.contains(state)){
             stateName = "审核中";
         }else if(SYSTEM_REFUSING_LEND_LIST.contains(state)){
        	 stateName = "系统审核中";
         }else if(IN_SYSTEM_AUDIT_LIST.contains(state)){
        	 stateName = "系统拒贷";
         }else if (OUTSIDE_VISIT.equals(state)){
             stateName = "外访中";
         }else if (CONFIRMATION_LOAN_AMOUNT.equals(state)){
             stateName = "确认借款";
         }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION.equals(state)){
             stateName = "签约前核验";
         }else if (BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT.equals(state)){
             stateName = "签约前核验审核中";
         }else if (REVIEW_AND_REVIEW.equals(state)){
             stateName = "复议审核中";
         }else if (CONTRACT_ENTRY.equals(state)){
             stateName = "合同录入中";
         }else if (CONTRACT_REVIEW.equals(state)){
             stateName = "合同审核中";
         }else if (CONTRACT_REVIEW_TO_LEND.equals(state)){
             stateName = "合同审核拒贷";
         }else if (IN_THE_BID.equals(state)){
             stateName = "募标中";
         }else if (CLIENT_CONTRACT.equals(state)){
             stateName = "客户签约";
         }else if (CONTRACT_INVALIDATION.equals(state)){
             stateName = "合同作废";
         }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
             stateName = "合同生效";
         }
         return stateName;
    }

    /**
     * 根据节点判断是否在集合中，获取对应的显示状态名称 外访已办
     * @author      xieqingyang
     * @date        2018/10/16 10:23 AM
     * @version     1.0
     * @param state 状态节点
     * @return 返回状态名称
     */
    public static String getNodeStateNameOfContractState(Integer state){
        String stateName = "";
        if (SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "系统审核中";
        }else if (AUDIT_LIST.contains(state)){
            stateName = "审核中";
        }else if (CONFIRMATION_LOAN_AMOUNT.equals(state)){
            stateName = "确认借款";
        }else if (IN_CONTRACT_LIST.contains(state)){
            stateName = "合同中";
        }else if (CLIENT_CONTRACT.equals(state)){
            stateName = "客户签约";
        }else if (AUDIT_SYSTEM_REFUSING_LEND_LIST.contains(state)){
            stateName = "审核拒贷";
        }else if (IN_SYSTEM_AUDIT_LIST.contains(state)){
            stateName = "系统拒贷";
        }else if (CONTRACT_INVALIDATION_LIST.contains(state)){
            stateName = "合同未通过";
        }else if (THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(state)){
            stateName = "合同生效";
        }
        return stateName;
    }
    
    /**
     * 速贷根据节点获取节点级
     * @param state
     * @return
     */
    public static List<Integer> getQuickLoanNodeStateList(Integer state){
        List<Integer> list;
        if (state == NodeStateConstant.QUICK_LOAN_SYSTEM_REFUSING_LEND){
            list = QUICK_LOAN_SYSTEM_REFUSING_LEND_LIST;
        }else {
            list = new ArrayList<>();
            list.add(state);
        }
        return list;
    }
}
