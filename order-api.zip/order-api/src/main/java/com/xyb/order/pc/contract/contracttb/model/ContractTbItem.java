package com.xyb.order.pc.contract.contracttb.model;

import java.math.BigDecimal;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;
/**
 * @author : houlvshuang
 * @projectName : finance-api
 * @package : com.xyb.loan.http.api.model
 * @description : 合同推标数据对象封装
 * @createDate : 2018/8/6 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ContractTbItem implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9160808306608189352L;
//	/**[非空][String,50]借款主体姓名*/
//	private String realName;
//	/**[非空][String,20]借款主体证件编号*/
//	private String idCard;
//	/**[非空][String,10]借款主体证件类型*/
//	private String idType;
//	/**[非空][String,10]借款主体性别 1女0男*/
//	private String sex;
//	/**[非空][String,20]借款主体联系号码*/
//	private String mobile;
//	/**[可空][String,20]借款主体出生日期*/
//	private String birthday;
//	/**[可空][String,50]借款主体邮箱*/
//	private String email;
//	/**[可空][String,50]借款主体微信*/
//	private String wx;
	/**[非空][Long]账户id*/
	private String acctId;
//	/**[非空][String,50]借款编号*/
//	private String loanNo;
	/**[非空][String,100]申请ID，同一应用唯一*/
	@SignField(order = 1)
	private String applyId;
	/**[非空][String,10000]借款标题*/
	private String title;
	/**[非空][Integer]借款类型 参考字典表【借款类型编码*/
	private Integer type;
	/**[非空][Integer]借款子类型 【借款子类型编码】 没有子类型可等于借款类型*/
	private Integer subType;
	/**[非空][Integer]评分*/
	private Integer score;
	/**[非空][String,128]借款用途*/
	private String purpose;
	/**[非空][BigDecimal]借款金额 小数最大精度后2位 例如 1000.55  或者 6000.00*/
	private BigDecimal amount;
	/**[非空][BigDecimal]借款年利率  小数最大精度后4位 例如0.1114 或者 0.1200*/
	private BigDecimal rate;
	/**[非空][Integer]还款方式 参考字典表【 还款方式编码】*/
	private Integer repayType;
	/**[非空][Integer]借款月数 可以为0但借款天数必须大于0*/
	private Integer months;
	/**[非空][Integer]借款天数  可以为0但借款月数必须大于0*/
	private Integer days;
	/**[String,256]借款描述*/
	private String description;
	/**[非空][Long]担保人账户ID*/
	private Long warrantyAcctId;
	/**[非空][BigDecimal]放款一次性收取的服务费 小数最大精度后2位 例如1000.55*/
	private BigDecimal serviceFee;
	/**[非空][BigDecimal]计算借款人还款每期收取的服务费，如无则为0.0000, 小数最大精度后4位 例如0.1114 或者 0.1200*/
	private BigDecimal repayFeeRate;
	/**[非空][String,10240]其他明细内容，JSON格式字符串 必须严格的JSON格式，见明细格式*/
	private String detail;
	public String getAcctId() {
		return acctId;
	}
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getSubType() {
		return subType;
	}
	public void setSubType(Integer subType) {
		this.subType = subType;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	public Integer getRepayType() {
		return repayType;
	}
	public void setRepayType(Integer repayType) {
		this.repayType = repayType;
	}
	public Integer getMonths() {
		return months;
	}
	public void setMonths(Integer months) {
		this.months = months;
	}
	public Integer getDays() {
		return days;
	}
	public void setDays(Integer days) {
		this.days = days;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getWarrantyAcctId() {
		return warrantyAcctId;
	}
	public void setWarrantyAcctId(Long warrantyAcctId) {
		this.warrantyAcctId = warrantyAcctId;
	}
	public BigDecimal getServiceFee() {
		return serviceFee;
	}
	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}
	public BigDecimal getRepayFeeRate() {
		return repayFeeRate;
	}
	public void setRepayFeeRate(BigDecimal repayFeeRate) {
		this.repayFeeRate = repayFeeRate;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	@Override
	public String toString() {
		return "ContractTbItem [acctId=" + acctId + ", applyId=" + applyId + ", title=" + title + ", type=" + type
				+ ", subType=" + subType + ", score=" + score + ", purpose=" + purpose + ", amount=" + amount
				+ ", rate=" + rate + ", repayType=" + repayType + ", months=" + months + ", days=" + days
				+ ", description=" + description + ", warrantyAcctId=" + warrantyAcctId + ", serviceFee=" + serviceFee
				+ ", repayFeeRate=" + repayFeeRate + ", detail=" + detail + "]";
	}
	
}
