package com.xyb.order.app.client.personalcenter.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 
 * @author qiaoJinLong
 * @date 2018年9月19日
 */
public class RewardDistributionDTO implements IBaseModel {

	private static final long serialVersionUID = -4347525325451235250L;

	private BigDecimal contractMoney;// 合同金额

	private Long clientId;// 用户信息表Id

	private Long financePaymentId;// 合同待交易明细id

	@Override
	public String toString() {
		return "RewardDistributionDTO [contractMoney=" + contractMoney + ", clientId=" + clientId
				+ ", financePaymentId=" + financePaymentId + "]";
	}

	public BigDecimal getContractMoney() {
		return contractMoney;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public void setContractMoney(BigDecimal contractMoney) {
		this.contractMoney = contractMoney;
	}

	public Long getFinancePaymentId() {
		return financePaymentId;
	}

	public void setFinancePaymentId(Long financePaymentId) {
		this.financePaymentId = financePaymentId;
	}

}
