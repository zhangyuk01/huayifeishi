package com.xyb.order.app.client.personalcenter.model;

import java.util.List;
import java.util.Map;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 余额类型查询
 * 
 * @author qiaoJinLong
 * @date 2018年9月20日
 */
public class ClientProfitBalanceDetailPage implements IBaseModel {
	private static final long serialVersionUID = -368677728450255209L;
	
	private Integer pageNumber = 0;

	private Integer pageSize = 0;

	private Integer total = 0;

	private Integer startNumber;

	private List<Map<String, Object>> contents;

	@Override
	public String toString() {
		return "ClientProfitBalanceDetailPage [pageNumber=" + pageNumber + ", pageSize=" + pageSize + ", total=" + total
				+ ", startNumber=" + startNumber + ", contents=" + contents + "]";
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getStartNumber() {
		return startNumber;
	}

	public void setStartNumber(Integer startNumber) {
		this.startNumber = startNumber;
	}

	public List<Map<String, Object>> getContents() {
		return contents;
	}

	public void setContents(List<Map<String, Object>> contents) {
		this.contents = contents;
	}

}
