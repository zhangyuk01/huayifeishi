package com.xyb.order.app.client.quickloan.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class QuickLoanRedisBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 申请金额
	 */
	private BigDecimal applyMoney;
	
	/**
	 * 满额金额
	 */
	private BigDecimal dayLimit;
	
	/**
	 * 是否满额 false:否；true：是
	 */
	private Boolean isFull;
	
	/**
	 * 限额规则开关 2478：开启；2479：关闭
	 */
	private Long ruleSwitch;

	public BigDecimal getApplyMoney() {
		return applyMoney;
	}

	public void setApplyMoney(BigDecimal applyMoney) {
		this.applyMoney = applyMoney;
	}

	public BigDecimal getDayLimit() {
		return dayLimit;
	}

	public void setDayLimit(BigDecimal dayLimit) {
		this.dayLimit = dayLimit;
	}

	public Boolean getIsFull() {
		return isFull;
	}

	public void setIsFull(Boolean isFull) {
		this.isFull = isFull;
	}

	public Long getRuleSwitch() {
		return ruleSwitch;
	}

	public void setRuleSwitch(Long ruleSwitch) {
		this.ruleSwitch = ruleSwitch;
	}

	@Override
	public String toString() {
		return "QuickLoanRedisBean [applyMoney=" + applyMoney + ", dayLimit="
				+ dayLimit + ", isFull=" + isFull + ", ruleSwitch="
				+ ruleSwitch + "]";
	}

}
