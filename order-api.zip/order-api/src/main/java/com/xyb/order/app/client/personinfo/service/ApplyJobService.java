package com.xyb.order.app.client.personinfo.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.personinfo.model.JobInfoDTO;
import com.xyb.order.app.client.personinfo.model.PrivateDTO;

/**
 * @ClassName ApplyJobService
 * @author ZhangYu
 * @date 2018年5月22号
 */
public interface ApplyJobService {

	/**
	 * 根据申请单ID获取工作信息 
	 * @return
	 * @throws Exception
	 */
	RestResponse getApplyJobInfo() throws Exception;

	/**
	 * 根据申请单ID获取私营信息 
	 * @return
	 * @throws Exception
	 */
	RestResponse getPrivateInfo() throws Exception;
	
	/**
	 * 新增或者更新工作信息 
	 * @return
	 * @throws Exception
	 */
	RestResponse addOrUpdateJobInfo(JobInfoDTO jobInfoDTO) throws Exception;
	
	
	/**
	 * 新增或者更新私营信息 
	 * @param privateDTO
	 * @return
	 * @throws Exception
	 */
	RestResponse addOrUpdatePrivateInfo(PrivateDTO privateDTO) throws Exception;

//	/**
//	 * @description 客户填写个人信息后提交操作
//	 * @author      xieqingyang
//	 * @CreatedDate 2018/6/3 下午3:17
//	 * @Version     1.0
//	 * @return
//	 * @throws Exception
//	 */
//	RestResponse onSubmit()throws Exception;
}
