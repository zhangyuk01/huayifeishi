package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * 返回数据
 *
 * @author xieqingyang
 * @date 2018/10/18 5:19 PM
 */
public class ResultDTO<T> implements IBaseModel {

    private static final long serialVersionUID = -9104971191004966670L;

    public static final String SUCCESS = "000";
    public static final String SIGNERR = "301";
    public static final String SIGNERR_MESSAGE = "签名错误";
    public static final String ERROR = "999";
    public static final String NOT_FOUND = "404";
    // -- 处理中
    public static final String WAITING = "100";

    @SignField(order = 0)
    private String code;
    @SignField(order = 1)
    private String message;
    private T body;
    /**
     * 签名
     */
    private String sign;

    public ResultDTO() {
    }

    public static ResultDTO<Void> successResult() {
        ResultDTO<Void> result = new ResultDTO<Void>();
        result.setCode(SUCCESS);
        return result;
    }

    public static ResultDTO<Void> errorResult() {
        ResultDTO<Void> result = new ResultDTO<Void>();
        result.setCode(ERROR);
        return result;
    }

    public ResultDTO(String rcode) {
        this.code = rcode;
    }

    public ResultDTO(String rcode, String msg) {
        this.code = rcode;
        this.message = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public boolean success() {
        return SUCCESS.equals(code);
    }

    public boolean notFound() {
        return NOT_FOUND.equals(code);
    }

    public boolean waiting() {
        return WAITING.equals(code);
    }

    public boolean signerr() {
        return SIGNERR.equals(code);
    }

    public boolean error() {
        return ERROR.equals(code);
    }

    @Override
    public String toString() {
        return "ResultDTO{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", body=" + body +
                ", sign='" + sign + '\'' +
                '}';
    }
}
