package com.xyb.order.app.client.quickloan.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 联系信息
 * 
 * @author qiaoJinLong
 * @date 2018年12月20日
 */
public class QuickLoanContactInfoDO implements IBaseModel {
	private static final long serialVersionUID = 1L;
	private String webchat;// 微信
	private String phone;// 备用手机号

	@Override
	public String toString() {
		return "QuickLoanContactInfoDO [webchat=" + webchat + ", phone=" + phone + "]";
	}

	public String getWebchat() {
		return webchat;
	}

	public void setWebchat(String webchat) {
		this.webchat = webchat;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
