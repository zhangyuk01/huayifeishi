package com.xyb.order.app.client.personinfo.model;

import com.beiming.kun.framework.model.IBaseModel;

public class LinkManRelationInfoDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id;//主键ID
	private String name;//联系人姓名
	private Long relation;//联系人关系
	private String relationLabel;//联系人关系描述
	private String phone1;//联系人手机号
	private String idcard;//联系人身份证号
	private String compName;//联系人公司
	private Long isSelfAddr;//是否与本人相同地址
	private Long province;//联系人省
	private String provinceLabel;
	private Long city;//联系人市
	private String cityLabel;
	private Long area;//联系人区
	private String areaLabel;
	private String address;//联系人地址
	private String allAddress;//联系人全地址
	private Long isKnowLoan;//是否知晓申请
	private String isKnowLoanLabel;
	/**职务*/
	private String duty;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getRelation() {
		return relation;
	}
	public void setRelation(Long relation) {
		this.relation = relation;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public Long getIsSelfAddr() {
		return isSelfAddr;
	}
	public void setIsSelfAddr(Long isSelfAddr) {
		this.isSelfAddr = isSelfAddr;
	}
	public Long getProvince() {
		return province;
	}
	public void setProvince(Long province) {
		this.province = province;
	}
	public String getProvinceLabel() {
		return provinceLabel;
	}
	public void setProvinceLabel(String provinceLabel) {
		this.provinceLabel = provinceLabel;
	}
	public Long getCity() {
		return city;
	}
	public void setCity(Long city) {
		this.city = city;
	}
	public String getCityLabel() {
		return cityLabel;
	}
	public void setCityLabel(String cityLabel) {
		this.cityLabel = cityLabel;
	}
	public Long getArea() {
		return area;
	}
	public void setArea(Long area) {
		this.area = area;
	}
	public String getAreaLabel() {
		return areaLabel;
	}
	public void setAreaLabel(String areaLabel) {
		this.areaLabel = areaLabel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAllAddress() {
		return allAddress;
	}
	public void setAllAddress(String allAddress) {
		this.allAddress = allAddress;
	}
	public Long getIsKnowLoan() {
		return isKnowLoan;
	}
	public void setIsKnowLoan(Long isKnowLoan) {
		this.isKnowLoan = isKnowLoan;
	}
	public String getIsKnowLoanLabel() {
		return isKnowLoanLabel;
	}
	public void setIsKnowLoanLabel(String isKnowLoanLabel) {
		this.isKnowLoanLabel = isKnowLoanLabel;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	public String getRelationLabel() {
		return relationLabel;
	}

	public void setRelationLabel(String relationLabel) {
		this.relationLabel = relationLabel;
	}
}
