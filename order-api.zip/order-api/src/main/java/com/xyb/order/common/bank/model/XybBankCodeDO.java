package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    银行类别
 * @author:         xieqingyang
 * @createDate:     2018/7/19 下午2:43
*/
public class XybBankCodeDO implements IBaseModel {

    private static final long serialVersionUID = -1860422548065704611L;
    /**主键ID*/
    private Integer id;
    /**银行类型*/
    private Integer bankType;
    /**银行编码*/
    private String bankCode;
    /**银行名称*/
    private String bankDes;
    /**深圳bankcode 暂时弃用*/
    private String thirdCode;
    /**银行编码ID*/
    private Long bankId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankDes() {
        return bankDes;
    }

    public void setBankDes(String bankDes) {
        this.bankDes = bankDes;
    }

    public String getThirdCode() {
        return thirdCode;
    }

    public void setThirdCode(String thirdCode) {
        this.thirdCode = thirdCode;
    }

    public Long getBankId() {
        return bankId;
    }

    public void setBankId(Long bankId) {
        this.bankId = bankId;
    }

    @Override
    public String toString() {
        return "XybBankCodeDO{" +
                "id=" + id +
                ", bankType=" + bankType +
                ", bankCode='" + bankCode + '\'' +
                ", bankDes='" + bankDes + '\'' +
                ", thirdCode='" + thirdCode + '\'' +
                ", bankId=" + bankId +
                '}';
    }
}
