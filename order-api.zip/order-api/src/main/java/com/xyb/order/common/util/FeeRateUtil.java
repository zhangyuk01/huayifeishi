package com.xyb.order.common.util;

import java.math.BigDecimal;

import com.xyb.order.common.constant.FeeRateConstants;




/**
 * 
 * <br>
 * <b>功能：</b>费率计算公式<br>
 * <b>作者：</b>CodeGenerater<br>
 * <b>日期：</b>2014-07-16 09:41:21<br>
 * <b>版权所有：<b>策诚财富<br>
 */
public class FeeRateUtil {

	/**
	 * 合同金额(备份)
	 * @param actualSum 实际金额
	 * @param n  期次
	 * @param serviceRate  服务费率(月)
	 * @return
	 */
	/*public static double contractSum(double actualSum,int n,double serviceRate){
		return format(actualSum+actualSum*n*serviceRate);
	}*/
	/**
	 * 服务费
	 * @param actualSum
	 * @param n
	 * @param serviceRate
	 * @return
	 */
	public static double serviceSum(double actualSum,int n,double serviceRate){
		double c = 0;
		c = actualSum*(serviceRate/100)*n;
		return formatInteger(c);
	}
	/**
	 * 信用奖金金额()
	 * @param actualSum
	 * @param n
	 * @param creditRate
	 * @return
	 */
	public static double creditSum(double actualSum,int n,double creditRate){
		double c = 0;
		c = actualSum*(creditRate/100)*n;
		return format(c);
	}
	/**
	 * 信用金额(月)
	 * @param actualSum
	 * @param creditRate
	 * @return
	 */
	public static double creditAmount(double actualSum,double creditRate){
		double c = 0;
		c = actualSum*(creditRate/100);
		return c;
	}
	/**
	 * 合同金额
	 * @param calculationType  计算方式
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param serviceRate  服务费率（月）
	 * @param creditRate  信用奖金率（月）
	 * @return
	 */
	public static double contractSum(String calculationType,double actualSum,int n,double serviceRate,double creditRate){
		double c = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			c = actualSum;
		}else{
			c = actualSum+formatInteger(actualSum*n*(serviceRate/100))+actualSum*n*(creditRate/100);
		}
		return c;
	}
	/**
	 * 合同金额
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param serviceRate  服务费率（月）
	 * @return
	 */
	public static double contractSum(double actualSum,int n,double serviceRate){
		double c = actualSum+formatInteger(actualSum*n*(serviceRate/100))+actualSum*n;
		return c;
	}
	/**
	 * 剩余本金
	 * @param calculationType  计算方式
	 * @param contractSum 合同金额
	 * @param n 期次
	 * @param m 第m 月末 0<m≤n
	 * @param borrowRate 借款利率
	 * @return
	 */
	public static double residueCapital(String calculationType,double contractSum,int n,int m,double borrowRate){
		double c = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			if(borrowRate == 0){
				c = contractSum*((n-m)/n);
			}else{
				c = contractSum*((Math.pow(1+(borrowRate/100), n)-Math.pow(1+borrowRate/100, m))/(Math.pow(1+borrowRate/100, n)-1));
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			c = contractSum*(n-m)/n;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)){
			c = contractSum;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			c = contractSum;
		}
		return c;
	}
	
	/**
	 * 账户管理费
	 * @param contractSum 合同金额
	 * @param manageRate  月帐户管理费率 
	 * @return
	 */
	public static double accountManageFee(double contractSum,double manageRate){
		return contractSum*(manageRate/100);
	}
	
	/**
	 * 当月本金
	 * @param calculationType 计算方式
	 * @param n  期次
	 * @param actualSum  实际金额
	 * @param m   第m 月末 0<m≤n
	 * @param borrowRate 利率
	 * @return
	 */
	public static double currentMonthCapital(String calculationType,double actualSum,int n,int m,double borrowRate){
		double c = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			if(borrowRate == 0){
				c = actualSum*(1/n);
			}else{
				c = actualSum*(borrowRate/100)*Math.pow(1+borrowRate/100, m-1)/(Math.pow(1+borrowRate/100, n)-1);
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			c = actualSum/n;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)){
			c = 0;
			if(n==m){
				c = actualSum;
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			c = 0;
			if(n==m){
				c = actualSum;
			}
		}
		return c;
	}
	
	/**
	 * 合同中的月本金
	 * @param calculationType
	 * @param actualSum
	 * @param n
	 * @param m
	 * @param borrowRate
	 * @param serviceRate
	 * @return
	 */
	public static double contractMonthCapital(String calculationType,double actualSum,int n,int m,double borrowRate,double serviceRate,double creditRate,double contractSum){
		double c = 0;
		c = currentMonthCapital(calculationType, actualSum, n, m, borrowRate) + currentMonthServiceFee(calculationType, actualSum, n, m, borrowRate, serviceRate,contractSum)+creditAmount(actualSum, creditRate);
		return format(c);
	}
	
	/**
	 * 当月利息
	 * @param calculationType  计算公式
	 * @param contractSum 合同金额
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param m  第m 月末 0<m≤n
	 * @param borrowRate  借款利率
	 * @return
	 */
	public static double interest(String calculationType,double actualSum,int n,int m,double borrowRate,double contractSum){
		
		double i = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			if(borrowRate == 0){
				i = 0;
			}else{
				i = actualSum*(borrowRate/100)*(Math.pow((1+borrowRate/100), n)-Math.pow((1+borrowRate/100), m-1))/(Math.pow((1+borrowRate/100), n)-1);
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			i = actualSum*(borrowRate/100);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			if(borrowRate == 0){
				i = 0;
			}else{
				i = actualSum*(borrowRate/100);
			}
		}
		return i;
	
	}
	
	/**
	 * 当月服务费
	 * @param calculationType  计算方式
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param m  第m 月末 0<m≤n
	 * @param borrowRate  借款利率
	 * @param serviceRate  服务利率
	 * @return
	 */
	public static double currentMonthServiceFee(String calculationType,double actualSum,int n,int m,double borrowRate,double serviceRate,double contractSum){
		double d = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			d = currentMonthCapital(calculationType, actualSum, n, m, borrowRate)*n*(serviceRate/100);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			d =actualSum*(serviceRate/100);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)){
			d = 0;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			d=0;
			if( m == n){
				d=contractSum*(serviceRate/100);
			}
		}
		return d;
	}
	
	/**
	 * 月利息
	 * @param calculationType
	 * @param actualSum
	 * @param n
	 * @param m
	 * @param borrowRate
	 * @param serviceRate
	 * @return
	 */
	public static double monthInterest(String calculationType,double actualSum,int n,int m,double borrowRate,double serviceRate,double contractSum){
		double d = 0;
		d = interest(calculationType, actualSum, n, m, borrowRate,contractSum)+currentMonthServiceFeeRate(calculationType, actualSum, n, m, borrowRate, serviceRate,contractSum);
		return format(d);
	}
	
	/**
	 * 当月服务费利息
	 * @param calculationType  计算方式
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param m  第m 月末 0<m≤n
	 * @param borrowRate  借款利率
	 * @param serviceRate  服务利率
	 * @return
	 */
	public static double currentMonthServiceFeeRate(String calculationType,double actualSum,int n,int m,double borrowRate,double serviceRate,double contractSum){
		double d = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			d = interest(calculationType, actualSum, n, m, borrowRate,contractSum)*n*(serviceRate/100);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			d = 0;
			if(m == n){
				d = contractSum*(serviceRate/100)*(borrowRate/100);
			}
		}
		return d;
	}
	
	/**
	 * 月还金额  
	 * @param calculationType  计算方式
	 * @param contractSum  合同金额
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param m  
	 * @param borrowRate  借款利率
	 * @param serviceRate  服务利率
	 * @param manageRate  月帐户管理费率 
	 * @return
	 */
	public static double monthReturn(String calculationType,double contractSum,double actualSum,int n,int m,double borrowRate,double serviceRate,double manageRate,double creditRate){
		double d = 0;
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			d = contractSum * (borrowRate/100) * Math.pow(1+borrowRate/100, n)/(Math.pow(1+borrowRate/100, n)-1) + contractSum * manageRate;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			d = contractSum/n + actualSum*(borrowRate/100) + contractSum * manageRate;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			if(m == n){
				d = contractSum*(1+borrowRate/100);
			}else{
				d = contractSum*borrowRate/100;
			}
		}else{
			d = currentMonthCapital(calculationType, actualSum, n, m, borrowRate)
					+interest(calculationType, actualSum, n, m, borrowRate,contractSum)
					+currentMonthServiceFee(calculationType, actualSum, n, m, borrowRate, serviceRate,contractSum)
					+currentMonthServiceFeeRate(calculationType, actualSum, n, m, borrowRate, serviceRate,contractSum)
					+accountManageFee(contractSum, manageRate)
					+creditAmount(actualSum,creditRate);
		}
		return d;
	}
	
	/**
	 * 一次结清
	 * @param calculationType  计算方式
	 * @param contractSum  合同金额
	 * @param actualSum  实际金额
	 * @param n  期数
	 * @param m  第m 月末 0<m≤n
	 * @param serviceRate  服务费率
	 * @param borrowRate  借款利率
	 * @param manageRate  管理费率
	 * @return
	 */
	public static double returnAll(String calculationType,double contractSum,double actualSum,int n,int m,double serviceRate,double borrowRate,double manageRate,double creditRate,double prepaymentRate){
		double a = 0;
		
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			a = residueCapital(calculationType,contractSum,n,m,borrowRate)* (1+Double.valueOf(prepaymentRate)/100)+monthReturn(calculationType,contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)){
			double tmp = residueCapital(calculationType, contractSum, n, m, borrowRate);
			a = tmp+monthReturn(calculationType, contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate)+tmp*0.05;
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)){
			double tmp1 = residueCapital(calculationType, contractSum, n, m, manageRate);
			double tmp2 = monthReturn(calculationType, contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate);
			if(n==6 || n==12){
				a = tmp1+tmp2+actualSum*(serviceRate/100);
			}
			if(n==18 || n==24){
				a = tmp1+tmp2+actualSum*(serviceRate/100)*0.8;
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_6)){
			a = residueCapital(calculationType, contractSum, n, m, manageRate)+monthReturn(calculationType, contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_5)){
			a = residueCapital(calculationType, contractSum, n, m, manageRate)+monthReturn(calculationType, contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate);
			if(n==m){
				a = monthReturn(calculationType, contractSum, actualSum, n, m, borrowRate, serviceRate, manageRate,creditRate);
			}
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_7)){
			a = contractSum*(1+borrowRate/100);
		}
		return format(a);
	}
	
	/**
	 * 月还本息
	 * @param calculationType  计算方式
	 * @param contractSum  合同金额
	 * @param actualSum  实际金额
	 * @param n  期次
	 * @param borrowRate  利率
	 * @return
	 */
	/*public static double monthReturnCapitalAndInterest(String calculationType,double contractSum,double actualSum,int n,double borrowRate){
		
		double ci = 0;
		
		if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_1)){
			ci = contractSum*borrowRate*Math.pow((1+borrowRate), n) / (Math.pow((1+borrowRate), n)-1);
		}else if(calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_2)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_3)
				||calculationType.equals(FeeRateConstants.FEE_RATE_CALCULATION_METHOD_4)){
			ci = currentMonthCapital(calculationType, contractSum, n, 0, borrowRate)+interest(calculationType, actualSum, n, 0, borrowRate);
		}
		
		return  format(ci);
	}*/
	
	/**
	 * 格式化函数
	 * @param d
	 * @return
	 */
	public static double format(double d){
		
		BigDecimal b = new BigDecimal(String.valueOf(d));
		return b.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
		
	}
	
	/**
	 * 四舍五入 取整
	 * @param d
	 * @return
	 */
	public static int formatInteger(double d){
		BigDecimal b = new BigDecimal(String.valueOf(d));
		return b.setScale(0,BigDecimal.ROUND_HALF_UP).intValue();
	}
	
	public static double string2Doble(String str){
		double d = 0;
		if(!StringUtils.isNullOrEmpty(str)){
			d = Double.parseDouble(str);
		}
		return d;
	}
	
	public static int string2Int(String str){
		int i = 0;
		if(!StringUtils.isNullOrEmpty(str)){
			i = Integer.parseInt(str);
		}
		return i;
	}
	
	public static long string2Long(String str){
		long i = 0;
		if(!StringUtils.isNullOrEmpty(str)){
			i = Long.parseLong(str);
		}
		return i;
	}
}
