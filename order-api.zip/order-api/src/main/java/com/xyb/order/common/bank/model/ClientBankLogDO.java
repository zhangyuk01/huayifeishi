package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    客户银行卡变更日志(非存管体系)
 * @author:         xieqingyang
 * @createDate:     2018/7/20 下午2:32
*/
public class ClientBankLogDO implements IBaseModel {
    private static final long serialVersionUID = -4651636495773756150L;
    /**主键ID*/
    private Long id;
    /**用户信息表ID*/
    private Long clientId;
    /**银行卡业务类型（2833）*/
    private Long businessType;
    /**变更前内容（以json格式记录变更前四要素）*/
    private String beforeContent;
    /**变更后内容(以json格式记录变更后四要素)*/
    private String afterContent;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Long businessType) {
        this.businessType = businessType;
    }

    public String getBeforeContent() {
        return beforeContent;
    }

    public void setBeforeContent(String beforeContent) {
        this.beforeContent = beforeContent;
    }

    public String getAfterContent() {
        return afterContent;
    }

    public void setAfterContent(String afterContent) {
        this.afterContent = afterContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }
}
