package com.xyb.order.app.business.manage.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:   APP客户经理申请单信息MODEL  
* @author:        ZhangYu 
* @createDate:    2018/6/13
*/

public class AppBillInfoDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Long applyId;//申请单ID
	private String cusName;//客户姓名
	private Date applyTime;//申请时间
	private String applyNum;//申请单编号
	private String state;//状态

	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public Date getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
