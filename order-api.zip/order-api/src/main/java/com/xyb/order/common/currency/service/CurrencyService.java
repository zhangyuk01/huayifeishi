package com.xyb.order.common.currency.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.currency.model.DropDownBoxListDTO;
import com.xyb.order.common.currency.model.QueryProductLimitByProductIdAndOrgIdDTO;
import com.xyb.order.common.currency.model.QueryTeanManagerDTO;

/**
 * Created by xieqingyang on 2018/4/17.
 */
public interface CurrencyService {

    /**
     * 查询流程日志
     * @param mainId 主表id
     * @return
     */
    RestResponse queryProcessLog(Long mainId) throws Exception;

    /**
     * 查询下拉框
     * @param downBoxListDTO
     * @return
     */
    RestResponse queryDropDownBox(DropDownBoxListDTO downBoxListDTO) throws Exception;

    /**
     * 根据营业部和产品查询产品期限
     * @param dto
     * @return
     */
    RestResponse queryProductLimitByOrg(QueryProductLimitByProductIdAndOrgIdDTO dto) throws Exception;

    /**
     * @description 获取公告
     * @author      xieqingyang
     * @CreatedDate 2018/8/20 下午5:17
     * @Version     1.0
     * @param pageNumber 页数
     * @param pageSize 页码
     * @return 公告信息
     * @throws Exception 所有异常
     */
    RestResponse findBulletin(Integer pageNumber, Integer pageSize)throws Exception;

    /**
     * @description 根据机构ID查询团队经理
     * @author      xieqingyang
     * @CreatedDate 2018/7/16 下午5:20
     * @Version     1.0
     * @param queryTeanManagerDTO teamOrgId 销售团队ID storeOrgId 进件机构ID
     * @return 返回下拉框通用数据
     * @throws Exception 所有异常
     */
    RestResponse findTeamManagerByOrgId(QueryTeanManagerDTO queryTeanManagerDTO)throws Exception;
}
