package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description: 用户银行卡展示信息
 * @author: xieqingyang
 * @createDate: 2018/7/20 下午5:00
 */
public class BankCardInfoVO implements IBaseModel {

	private static final long serialVersionUID = -3914617304443647172L;
	/** 客户姓名 */
	private String name;
	/** 身份证号 */
	private String idCard;
	/** 银行名称 */
	private String bankName;
	/** 银行卡号 */
	private String bankNum;
	/** 银行标识 */
	private Integer bankType;
	/** 银行编号 */
	private String bankCode;
	/** 银行表ID */
	private Long id;
	/** 状态码 **/
	private Integer code;
	private DepositAccountStateVO depositState;

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public DepositAccountStateVO getDepositState() {
		return depositState;
	}

	public void setDepositState(DepositAccountStateVO depositState) {
		this.depositState = depositState;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankNum() {
		return bankNum;
	}

	public void setBankNum(String bankNum) {
		this.bankNum = bankNum;
	}

	public Integer getBankType() {
		return bankType;
	}

	public void setBankType(Integer bankType) {
		this.bankType = bankType;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "BankCardInfoVO [name=" + name + ", idCard=" + idCard + ", bankName=" + bankName + ", bankNum=" + bankNum
				+ ", bankType=" + bankType + ", bankCode=" + bankCode + ", id=" + id + ", code=" + code
				+ ", depositState=" + depositState + "]";
	}
}
