package com.xyb.order.common.msg;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.com.xyb.order.common.msg
 * @description : 系统参数配置枚举
 * @createDate : 2018/05/15 11：09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public enum ParameterConfigEnum {

	PARAMETER_CONFIG_NATERIAL_SWITCH("apply_01","材料补充冻结开关",2757),
	PARAMETER_CONFIG_NATERIAL_DATE("apply_02","材料补充冻结时间",2757),
	PARAMETER_CONFIG_HTLRZDDJ("apply_03","合同录入自动冻结开关",2757),
	PARAMETER_CONFIG_HTLRZDDJSJ("apply_04","合同录入自动冻结时间",2757),
	PARAMETER_CONFIG_WFZDDJ("apply_05","外访自动冻结开关",2757),
	PARAMETER_CONFIG_WFZDDJSJ("apply_06","外访自动冻结时间",2757),
	PARAMETER_CONFIG_07("apply_07","捷安重复调用控制时长查询历史数据",2757);

	/**参数code*/
	String parameterCode;
	/**参数描述*/
	String parameterDesc;
	/**大类id*/
	long typeId;
	
	
	ParameterConfigEnum(String parameterCode, String parameterDesc, long typeId) {
		this.parameterCode = parameterCode;
		this.parameterDesc = parameterDesc;
		this.typeId = typeId;
	}
	public String getParameterCode() {
		return parameterCode;
	}
	public void setParameterCode(String parameterCode) {
		this.parameterCode = parameterCode;
	}
	public String getParameterDesc() {
		return parameterDesc;
	}
	public void setParameterDesc(String parameterDesc) {
		this.parameterDesc = parameterDesc;
	}
	public long getTypeId() {
		return typeId;
	}
	public void setTypeId(long typeId) {
		this.typeId = typeId;
	}
	
	
}
