package com.xyb.order.common.constant;

/**
 * 
* @className : ProductConstant.java
* @package : com.xyb.order.common.constant
* @description : 产品常量类
* @author : zhanghao
* @createDate : 2018年12月19日下午5:33:05
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
public class ProductConstant {

	/**
     * 优信借
     */
    public static final Long YOU_XIN_JIE_ID = 451L;
    /**
     * 开启
     */
    public static final Long OPEN = 2478L;
    /**
     * 关闭
     */
    public static final Long CLOSE = 2479L;
	
}
