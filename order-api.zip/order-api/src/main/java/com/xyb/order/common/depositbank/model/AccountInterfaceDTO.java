package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Objects;

/**
 * 存管请求通用参数
 * @author         fangjie
 * @date           2018/11/23 4:00 PM
*/
public class AccountInterfaceDTO implements IBaseModel {

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = -9035827293959468876L;

	/**存管账户表主键ID*/
	private Long depositId;
	/**客户信息主键ID（t_apply_client_info）*/
	private Long clientId;
	/**资产系统借款人账户ID*/
	private Long accId;
	/**银行卡账户表主键ID*/
	private Long bankId;
	/**电子账户,必填，开户返回的电子账户，19(位数)*/
	private String cardNo;
	/**客户号，11(位数)*/
	private String customerNo;
	/**三方绑定编号，32(位数)*/
	private String serialNo;
	/**绑定卡号，19(位数)*/
	private String bankNum;
	/**借款人放款手续费和还款金额签约状态  大类2692*/
	private Long isSign;

	public Long getDepositId() {
		return depositId;
	}

	public void setDepositId(Long depositId) {
		this.depositId = depositId;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public Long getAccId() {
		return accId;
	}

	public void setAccId(Long accId) {
		this.accId = accId;
	}

	public Long getBankId() {
		return bankId;
	}

	public void setBankId(Long bankId) {
		this.bankId = bankId;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getBankNum() {
		return bankNum;
	}

	public void setBankNum(String bankNum) {
		this.bankNum = bankNum;
	}

	public Long getIsSign() {
		return isSign;
	}

	public void setIsSign(Long isSign) {
		this.isSign = isSign;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		AccountInterfaceDTO that = (AccountInterfaceDTO) o;
		return Objects.equals(depositId, that.depositId) &&
				Objects.equals(clientId, that.clientId) &&
				Objects.equals(accId, that.accId) &&
				Objects.equals(bankId, that.bankId) &&
				Objects.equals(cardNo, that.cardNo) &&
				Objects.equals(customerNo, that.customerNo) &&
				Objects.equals(serialNo, that.serialNo) &&
				Objects.equals(bankNum, that.bankNum) &&
				Objects.equals(isSign, that.isSign);
	}

	@Override
	public int hashCode() {

		return Objects.hash(depositId, clientId, accId, bankId, cardNo, customerNo, serialNo, bankNum, isSign);
	}

	@Override
	public String toString() {
		return "AccountInterfaceDTO{" +
				"depositId=" + depositId +
				", clientId=" + clientId +
				", accId=" + accId +
				", bankId=" + bankId +
				", cardNo='" + cardNo + '\'' +
				", customerNo='" + customerNo + '\'' +
				", serialNo='" + serialNo + '\'' +
				", bankNum='" + bankNum + '\'' +
				", isSign=" + isSign +
				'}';
	}
}
