package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 存管返回信息model
 * @author         xieqingyang
 * @date           2018/11/23 3:29 PM
*/
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DepositBankResultDTO implements IBaseModel {

    private static final long serialVersionUID = -7261961499419052745L;
    @SignField(order = 0)
    private String code;
    @SignField(order = 1)
    private String message;
    private String sign;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DepositBankResultDTO that = (DepositBankResultDTO) o;
        return Objects.equals(code, that.code) &&
                Objects.equals(message, that.message) &&
                Objects.equals(sign, that.sign);
    }

    @Override
    public int hashCode() {

        return Objects.hash(code, message, sign);
    }

    @Override
    public String toString() {
        return "DepositBankResultDTO{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", sign='" + sign + '\'' +
                '}';
    }
}
