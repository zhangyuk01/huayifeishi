package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.validation.constraints.NotNull;

/**
 * @description:    查询消息相关传入参数
 * @author:         xieqingyang
 * @createDate:     2018/6/29 下午4:25
*/
public class AppMessageQueryDTO implements IBaseModel {

    private static final long serialVersionUID = -4486783114697559349L;
    /**通知类型 2525-通知 3082-公告*/
    @NotNull(message = "通知类型不能为空")
    private Long type;
    /**app类型  2526-业务端  2527-客户端*/
    @NotNull(message = "app类型不能为空")
    private Long appType;
    /**页数 当查询列表时不能为空 从0开始*/
    private Integer pageNum;
    @JsonIgnore
    private Long userId;

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public Long getAppType() {
        return appType;
    }

    public void setAppType(Long appType) {
        this.appType = appType;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
