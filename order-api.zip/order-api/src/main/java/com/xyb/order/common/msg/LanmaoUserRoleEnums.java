package com.xyb.order.common.msg;

/**
 * @description:    深圳所需的
 * @author:         xieqingyang
 * @createDate:     2018/5/21 下午4:38
*/
public enum LanmaoUserRoleEnums {
    /**
     * 担保机构
     */
    GUARANTEECORP,
    /**
     * 投资人
     */
    INVESTOR,
    /**
     * 借款人
     */
    BORROWERS,
    /**
     * 合作机构
     */
    COLLABORATOR,
    /**
     * 供应商
     */
    SUPPLIER,
    /**
     * 平台营销款账户
     */
    PLATFORM_MARKETING,
    /**
     * 平台分润账户
     */
    PLATFORM_PROFIT,
    /**
     * 平台收入账户
     */
    PLATFORM_INCOME,
    /**
     * 平台派息账户
     */
    PLATFORM_INTEREST,
    /**
     * 平台代充值账户
     */
    PLATFORM_ALTERNATIVE_RECHARGE,
    /**
     * 平台总账户
     */
    PLATFORM_FUNDS_TRANSFER,
    /**
     * 垫资账户
     */
    PLATFORM_URGENT
}
