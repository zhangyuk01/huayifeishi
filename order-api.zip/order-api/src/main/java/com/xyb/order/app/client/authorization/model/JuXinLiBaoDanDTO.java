package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
* @description:    聚信力保单认证传入参数
* @author:         xieqingyang
* @createDate:     2018/5/17 上午11:53
*/
public class JuXinLiBaoDanDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**
     * 申请单id 必填
     */
    private String applyId;
    /**
     * 保险网站账号 必填
     */
    @NotEmpty(message = "保险网站账号不能为空")
    private String account;
    /**
     * 保险网站密码 必填
     */
    @NotEmpty(message = "保险网站密码不能为空")
    private String password;
    /**
     * 保险网站英文名（从获取数据源列表中选择status为1 的） 必填
     */
    private String website;
    /**
     * 姓名 必填
     */
    private String name;
    /**
     * 身份证 必填
     */
    private String idCard;
    /**
     * 手机号 必填
     */
    private String phone;

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
