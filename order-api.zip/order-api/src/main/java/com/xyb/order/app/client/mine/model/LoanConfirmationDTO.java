package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * @description:    查询借款确认信息传入字段
 * @author:         xieqingyang
 * @createDate:     2018/5/24 下午1:09
*/
public class LoanConfirmationDTO implements IBaseModel {

    private static final long serialVersionUID = 7806643970627548880L;

    /**申请单ID*/
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;
    /**查询类型 frist：查询申请借款信息  second：查询合同借款确认信息*/
    @NotEmpty(message = "查询类型不能为空")
    private String type;

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "LoanConfirmationDTO{" +
                "applyId=" + applyId +
                ", type='" + type + '\'' +
                '}';
    }
}
