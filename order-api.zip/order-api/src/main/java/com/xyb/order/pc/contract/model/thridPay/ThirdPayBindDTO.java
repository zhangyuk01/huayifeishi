package com.xyb.order.pc.contract.model.thridPay;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同录入获取第三方渠道DTO
 * @createDate : 2018/05/28 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ThirdPayBindDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3011416508358945947L;
	/**申请id*/
	@NotNull(message="applyId 不能为空")
	private Long applyId;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Override
	public String toString() {
		return "ThirdPayBindDTO [applyId=" + applyId + "]";
	}
	
}
