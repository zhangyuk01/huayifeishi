package com.xyb.order.pc.apply.already.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.apply.already.model
 * @description : 申请已办列表导出VO model
 * @createDate : 2018/5/24 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyListExportVO implements IBaseModel {

	private static final long serialVersionUID = -5962048808435558098L;

	/**申请编号*/
	private String applyNum;
	/**客戶姓名*/
	private String custName;
	/**手机号*/
	private String phone;
	/**身份证号*/
	private String idCard;
	/**销售团队*/
	private String saleTeamName;
	/**销售人员*/
	private String saleUserName;
	/**客服人员*/
	private String serviceName;
	/**推荐人姓名*/
	private String recommender;
	/**申请产品*/
	private String applyProductName;
	/**是否循环贷*/
	private String isLoopName;
	/**是否签约前核验*/
	private String isSignCheck;
	/**当前状态*/
	private String stateName;
	/**进件时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date incomeTime;
	/**审批时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date auditEndTime;
	/**一级授信产品*/
	private String agreeProduct;
	/**一级授信金额*/
	private String agreeAmount;
	/**确认金额*/
	private BigDecimal confirmAmout;
	/**一级授信期数*/
	private Integer agreeProductLimit;
	/**费率*/
	private String serviceProportion;
	/**是否拒贷*/
	private String isRefuse;
	/**拒贷原因*/
	private String refuseReason;
	/**合同生效日期*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date contractTakeEffectTime;
	/**终极授信金额*/
	private String contractAmount;
	/**月还金额*/
	private String monthReturnAmount;
	/**还款日*/
	private Integer repayDay;
	/**是否已结清*/
	private String isSettle;
	/**复议次数*/
	private Integer reconsiderationQty;
	/**第一次复议日期*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date oneReconsiderationTime;
	/**第二次复议日期*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date towReconsiderationTime;
	/**进件机构*/
	private String orgName;
	@JsonIgnore
	private Integer stateCode;

	public String getApplyNum() {
		return applyNum;
	}

	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getSaleTeamName() {
		return saleTeamName;
	}

	public void setSaleTeamName(String saleTeamName) {
		this.saleTeamName = saleTeamName;
	}

	public String getSaleUserName() {
		return saleUserName;
	}

	public void setSaleUserName(String saleUserName) {
		this.saleUserName = saleUserName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	public String getApplyProductName() {
		return applyProductName;
	}

	public void setApplyProductName(String applyProductName) {
		this.applyProductName = applyProductName;
	}

	public String getIsLoopName() {
		return isLoopName;
	}

	public void setIsLoopName(String isLoopName) {
		this.isLoopName = isLoopName;
	}

	public String getIsSignCheck() {
		return isSignCheck;
	}

	public void setIsSignCheck(String isSignCheck) {
		this.isSignCheck = isSignCheck;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Date getIncomeTime() {
		return incomeTime;
	}

	public void setIncomeTime(Date incomeTime) {
		this.incomeTime = incomeTime;
	}

	public Date getAuditEndTime() {
		return auditEndTime;
	}

	public void setAuditEndTime(Date auditEndTime) {
		this.auditEndTime = auditEndTime;
	}

	public String getAgreeProduct() {
		return agreeProduct;
	}

	public void setAgreeProduct(String agreeProduct) {
		this.agreeProduct = agreeProduct;
	}

	public String getAgreeAmount() {
		return agreeAmount;
	}

	public void setAgreeAmount(String agreeAmount) {
		this.agreeAmount = agreeAmount;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	public Integer getAgreeProductLimit() {
		return agreeProductLimit;
	}

	public void setAgreeProductLimit(Integer agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}

	public String getServiceProportion() {
		return serviceProportion;
	}

	public void setServiceProportion(String serviceProportion) {
		this.serviceProportion = serviceProportion;
	}

	public String getIsRefuse() {
		return isRefuse;
	}

	public void setIsRefuse(String isRefuse) {
		this.isRefuse = isRefuse;
	}

	public String getRefuseReason() {
		return refuseReason;
	}

	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}

	public Date getContractTakeEffectTime() {
		return contractTakeEffectTime;
	}

	public void setContractTakeEffectTime(Date contractTakeEffectTime) {
		this.contractTakeEffectTime = contractTakeEffectTime;
	}

	public String getContractAmount() {
		return contractAmount;
	}

	public void setContractAmount(String contractAmount) {
		this.contractAmount = contractAmount;
	}

	public String getMonthReturnAmount() {
		return monthReturnAmount;
	}

	public void setMonthReturnAmount(String monthReturnAmount) {
		this.monthReturnAmount = monthReturnAmount;
	}

	public Integer getRepayDay() {
		return repayDay;
	}

	public void setRepayDay(Integer repayDay) {
		this.repayDay = repayDay;
	}

	public String getIsSettle() {
		return isSettle;
	}

	public void setIsSettle(String isSettle) {
		this.isSettle = isSettle;
	}

	public Integer getReconsiderationQty() {
		return reconsiderationQty;
	}

	public void setReconsiderationQty(Integer reconsiderationQty) {
		this.reconsiderationQty = reconsiderationQty;
	}

	public Date getOneReconsiderationTime() {
		return oneReconsiderationTime;
	}

	public void setOneReconsiderationTime(Date oneReconsiderationTime) {
		this.oneReconsiderationTime = oneReconsiderationTime;
	}

	public Date getTowReconsiderationTime() {
		return towReconsiderationTime;
	}

	public void setTowReconsiderationTime(Date towReconsiderationTime) {
		this.towReconsiderationTime = towReconsiderationTime;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Integer getStateCode() {
		return stateCode;
	}

	public void setStateCode(Integer stateCode) {
		this.stateCode = stateCode;
	}

	@Override
	public String toString() {
		return "ApplyAlreadyListExportVO{" +
				"applyNum='" + applyNum + '\'' +
				", custName='" + custName + '\'' +
				", phone='" + phone + '\'' +
				", idCard='" + idCard + '\'' +
				", saleTeamName='" + saleTeamName + '\'' +
				", saleUserName='" + saleUserName + '\'' +
				", serviceName='" + serviceName + '\'' +
				", recommender='" + recommender + '\'' +
				", applyProductName='" + applyProductName + '\'' +
				", isLoopName='" + isLoopName + '\'' +
				", isSignCheck='" + isSignCheck + '\'' +
				", stateName='" + stateName + '\'' +
				", incomeTime=" + incomeTime +
				", auditEndTime=" + auditEndTime +
				", agreeProduct='" + agreeProduct + '\'' +
				", agreeAmount='" + agreeAmount + '\'' +
				", confirmAmout=" + confirmAmout +
				", agreeProductLimit=" + agreeProductLimit +
				", serviceProportion='" + serviceProportion + '\'' +
				", isRefuse='" + isRefuse + '\'' +
				", refuseReason='" + refuseReason + '\'' +
				", contractTakeEffectTime=" + contractTakeEffectTime +
				", contractAmount='" + contractAmount + '\'' +
				", monthReturnAmount='" + monthReturnAmount + '\'' +
				", repayDay=" + repayDay +
				", isSettle='" + isSettle + '\'' +
				", reconsiderationQty=" + reconsiderationQty +
				", oneReconsiderationTime=" + oneReconsiderationTime +
				", towReconsiderationTime=" + towReconsiderationTime +
				", orgName='" + orgName + '\'' +
				", stateCode=" + stateCode +
				'}';
	}
}
