package com.xyb.order.app.client.personinfo.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    住址拆分model
 * @author:         xieqingyang
 * @createDate:     2018/6/14 下午1:52
*/
public class PersonalAddressDTO implements IBaseModel {

    private static final long serialVersionUID = 4398837302688889681L;
    private String province = "";
    private String provinceCode = "";
    private String city = "";
    private String cityCode = "";
    private String area = "";
    private String areaCode = "";
    private String allAddress = "";
    private String address = "";

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getAllAddress() {
        return allAddress;
    }

    public void setAllAddress(String allAddress) {
        this.allAddress = allAddress;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    @Override
    public String toString() {
        return "PersonalAddressDTO{" +
                "province='" + province + '\'' +
                ", provinceCode='" + provinceCode + '\'' +
                ", city='" + city + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", area='" + area + '\'' +
                ", areaCode='" + areaCode + '\'' +
                ", allAddress='" + allAddress + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
