package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditVerifyDTO;

/**
 * @ClassName AuditVerifyService
 * @author ZhangYu
 * @date 2018年5月7号
 */
public interface AuditVerifyService {

	/**
	 * 根据申请单ID查询申请核查信息 
	 * @param applyId
	 * @return
	 */
	RestResponse queryVerifyInfoByApplyId(Long applyId)throws Exception;
	
	/**
	 * 修改或新增申请核查信息 
	 * @return
	 */
	RestResponse updateOrAddVerifyInfo(AuditVerifyDTO auditVerifyDTO)throws Exception;
	
	
	

}
