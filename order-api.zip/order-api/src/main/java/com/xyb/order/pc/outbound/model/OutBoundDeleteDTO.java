package com.xyb.order.pc.outbound.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访已办查询DTO model
 * @createDate : 2018/6/04 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDeleteDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1626098167909243090L;
	/**外访删除类型:A:外访家庭信息删除  B：外访经营信息删除*/
	@NotEmpty(message = "type不能为空")
	private String type;
	/**主键id*/
	@NotNull(message = "id不能为空")
	private Long id;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "OutBoundDeleteDTO [type=" + type + ", id=" + id + "]";
	}
	
}
