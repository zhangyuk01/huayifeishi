package com.xyb.order.pc.contract.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class XybContractDTO  implements IBaseModel {
		
		/**
	     * 
	    */
	    private static final long serialVersionUID = 6171800415129896537L;
		//属性部分
		@NotNull(message = "id不能为空")
		private Long id; //id
		@NotNull(message = "applyId不能为空")
		private Long applyId; //申请单ID
		private String cusNumber; //客户编号
		private Date agreeEffect; //协议生效日期
		private Date agreeFailure; //协议失效日期
		private Long isTempSave; //当前状态
		private Date repaymentDateStart; //开始还款日期
		private int repDate; //还款日
		private int repDateNew; //变更后还款日
		@NotNull(message="bankType不能为空")
		private Long bankType; //银行类别
		@NotEmpty(message = "bankAccount不能为空")
		private String bankAccount; //银行卡户名
		private Long contractProvince;//开户行省
		private Long contractCity;//开户行市
		private Long contractArea;//开户行区
		private String bankAccountOpen; //开户行
		@NotNull(message="contractNum不能为空")
		private String contractNum; //合同编号 
		private Long helpUid; //合同辅导人员
		@NotEmpty(message="helpName不能为空")
		private String helpName;//合同辅导人姓名
		@NotEmpty(message="refundCardNum不能为空")
		private String refundCardNum; //还款借记卡卡号
		private String refundCardNum1;
		private Long isCreditCheck; //是否签署了代查信用报告声明书
		private Long isAttention; //是否重点关注
		private Long protocolUid; //协议讲解人
		@NotEmpty(message="protocolName不能为空")
		private String protocolName; //协议讲解人姓名
		private Long bankCheck; //银行流水已核确认
		private Long bankCheckUid; //银行流水核实确认人
		private String bankCheckUname; //银行流水核实确认人
		private Long houseCheck; //房产已核确认
		private Long houseCheckUid; //房产核实确认人
		private String houseCheckName;//房产核验人姓名
		private String contractRemark; //备注
		private String contractViewPath; //合同查看路径
		private String contractDownLoadPath; //合同查看路径
		private Long contractState; //合同状态
		private Long createUser; //创建人
		private String createName;//创建人姓名
		private Date createTime;//创建时间
		private Long modifyUser; //修改人
		private String modifyName; //修改人姓名
		private Date modifyTime; //修改时间
		private java.util.Date contractAbolitionTime;//合同废除时间
		private String contractAbolition;//合同废除原因
		private String contractAbolitionName;//合同废除原因中文描述
		private String remarks;// 废除备注
		private Long isRepaymentPlan;
		private Long loanChannel;//放款渠道
		private  String backFlag;//退回标识
		private String incomeAcountNum;//入账账户（客户的e+账号）
		private Long isNyAcount;//收款卡是否南粤银行
		private Date loanMoneyTime;//渠道放款时间
		private Date pushTime;//推送时间
		@NotEmpty(message="mp不能为空")
		private String mp; //银行预留手机号
		private Long type;//合同类型
		private Long tbState;//推标状态
		private Long storeOrgId;//营业部id
		private Long productId;//产品id
		private String productName;//产品名称
		private BigDecimal productProportion; //产品利率
		private BigDecimal serviceProportion;//服务利率
		private BigDecimal breachProportion;//违约金比例
		private BigDecimal fineProportion;//罚息比例
		private String custName;//客户姓名
		private Long custId;//客户id
		private Long isLoop;//是否循环贷
		private BigDecimal monthRepaymentMoney;//月还金额
		private int productLimit;//合同期数
		private String storeOrgName;//营业部名称
		private String clientIdcard;//身份证号
		@JsonIgnore
		private String clientLabelIds; //客户标签id
		@JsonIgnore
		private String clientLabel;//客户标签
		@NotEmpty(message="dcRecommendText不能为空")
		private String dcRecommendText;//推荐语
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getApplyId() {
			return applyId;
		}
		public void setApplyId(Long applyId) {
			this.applyId = applyId;
		}
		public String getCusNumber() {
			return cusNumber;
		}
		public void setCusNumber(String cusNumber) {
			this.cusNumber = cusNumber;
		}
		public Date getAgreeEffect() {
			return agreeEffect;
		}
		public void setAgreeEffect(Date agreeEffect) {
			this.agreeEffect = agreeEffect;
		}
		public Date getAgreeFailure() {
			return agreeFailure;
		}
		public void setAgreeFailure(Date agreeFailure) {
			this.agreeFailure = agreeFailure;
		}
		public Long getIsTempSave() {
			return isTempSave;
		}
		public void setIsTempSave(Long isTempSave) {
			this.isTempSave = isTempSave;
		}
		public Date getRepaymentDateStart() {
			return repaymentDateStart;
		}
		public void setRepaymentDateStart(Date repaymentDateStart) {
			this.repaymentDateStart = repaymentDateStart;
		}
		public int getRepDate() {
			return repDate;
		}
		public void setRepDate(int repDate) {
			this.repDate = repDate;
		}
		public int getRepDateNew() {
			return repDateNew;
		}
		public void setRepDateNew(int repDateNew) {
			this.repDateNew = repDateNew;
		}
		public Long getBankType() {
			return bankType;
		}
		public void setBankType(Long bankType) {
			this.bankType = bankType;
		}
		public String getBankAccount() {
			return bankAccount;
		}
		public void setBankAccount(String bankAccount) {
			this.bankAccount = bankAccount;
		}
		public Long getContractProvince() {
			return contractProvince;
		}
		public void setContractProvince(Long contractProvince) {
			this.contractProvince = contractProvince;
		}
		public Long getContractCity() {
			return contractCity;
		}
		public void setContractCity(Long contractCity) {
			this.contractCity = contractCity;
		}
		public Long getContractArea() {
			return contractArea;
		}
		public void setContractArea(Long contractArea) {
			this.contractArea = contractArea;
		}
		public String getBankAccountOpen() {
			return bankAccountOpen;
		}
		public void setBankAccountOpen(String bankAccountOpen) {
			this.bankAccountOpen = bankAccountOpen;
		}
		public String getContractNum() {
			return contractNum;
		}
		public void setContractNum(String contractNum) {
			this.contractNum = contractNum;
		}
		public Long getHelpUid() {
			return helpUid;
		}
		public void setHelpUid(Long helpUid) {
			this.helpUid = helpUid;
		}
		public String getHelpName() {
			return helpName;
		}
		public void setHelpName(String helpName) {
			this.helpName = helpName;
		}
		public String getRefundCardNum() {
			return refundCardNum;
		}
		public void setRefundCardNum(String refundCardNum) {
			this.refundCardNum = refundCardNum;
		}
		public String getRefundCardNum1() {
			return refundCardNum1;
		}
		public void setRefundCardNum1(String refundCardNum1) {
			this.refundCardNum1 = refundCardNum1;
		}
		public Long getIsCreditCheck() {
			return isCreditCheck;
		}
		public void setIsCreditCheck(Long isCreditCheck) {
			this.isCreditCheck = isCreditCheck;
		}
		public Long getIsAttention() {
			return isAttention;
		}
		public void setIsAttention(Long isAttention) {
			this.isAttention = isAttention;
		}
		public Long getProtocolUid() {
			return protocolUid;
		}
		public void setProtocolUid(Long protocolUid) {
			this.protocolUid = protocolUid;
		}
		public String getProtocolName() {
			return protocolName;
		}
		public void setProtocolName(String protocolName) {
			this.protocolName = protocolName;
		}
		public Long getBankCheck() {
			return bankCheck;
		}
		public void setBankCheck(Long bankCheck) {
			this.bankCheck = bankCheck;
		}
		public Long getBankCheckUid() {
			return bankCheckUid;
		}
		public void setBankCheckUid(Long bankCheckUid) {
			this.bankCheckUid = bankCheckUid;
		}
		public String getBankCheckUname() {
			return bankCheckUname;
		}
		public void setBankCheckUname(String bankCheckUname) {
			this.bankCheckUname = bankCheckUname;
		}
		public Long getHouseCheck() {
			return houseCheck;
		}
		public void setHouseCheck(Long houseCheck) {
			this.houseCheck = houseCheck;
		}
		public Long getHouseCheckUid() {
			return houseCheckUid;
		}
		public void setHouseCheckUid(Long houseCheckUid) {
			this.houseCheckUid = houseCheckUid;
		}
		public String getHouseCheckName() {
			return houseCheckName;
		}
		public void setHouseCheckName(String houseCheckName) {
			this.houseCheckName = houseCheckName;
		}
		public String getContractRemark() {
			return contractRemark;
		}
		public void setContractRemark(String contractRemark) {
			this.contractRemark = contractRemark;
		}
		public String getContractViewPath() {
			return contractViewPath;
		}
		public void setContractViewPath(String contractViewPath) {
			this.contractViewPath = contractViewPath;
		}
		public String getContractDownLoadPath() {
			return contractDownLoadPath;
		}
		public void setContractDownLoadPath(String contractDownLoadPath) {
			this.contractDownLoadPath = contractDownLoadPath;
		}
		public Long getContractState() {
			return contractState;
		}
		public void setContractState(Long contractState) {
			this.contractState = contractState;
		}
		public Long getCreateUser() {
			return createUser;
		}
		public void setCreateUser(Long createUser) {
			this.createUser = createUser;
		}
		public String getCreateName() {
			return createName;
		}
		public void setCreateName(String createName) {
			this.createName = createName;
		}
		public Date getCreateTime() {
			return createTime;
		}
		public void setCreateTime(Date createTime) {
			this.createTime = createTime;
		}
		public Long getModifyUser() {
			return modifyUser;
		}
		public void setModifyUser(Long modifyUser) {
			this.modifyUser = modifyUser;
		}
		public String getModifyName() {
			return modifyName;
		}
		public void setModifyName(String modifyName) {
			this.modifyName = modifyName;
		}
		public Date getModifyTime() {
			return modifyTime;
		}
		public void setModifyTime(Date modifyTime) {
			this.modifyTime = modifyTime;
		}
		public java.util.Date getContractAbolitionTime() {
			return contractAbolitionTime;
		}
		public void setContractAbolitionTime(java.util.Date contractAbolitionTime) {
			this.contractAbolitionTime = contractAbolitionTime;
		}
		public String getContractAbolition() {
			return contractAbolition;
		}
		public void setContractAbolition(String contractAbolition) {
			this.contractAbolition = contractAbolition;
		}
		public String getContractAbolitionName() {
			return contractAbolitionName;
		}
		public void setContractAbolitionName(String contractAbolitionName) {
			this.contractAbolitionName = contractAbolitionName;
		}
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		public Long getIsRepaymentPlan() {
			return isRepaymentPlan;
		}
		public void setIsRepaymentPlan(Long isRepaymentPlan) {
			this.isRepaymentPlan = isRepaymentPlan;
		}
		public Long getLoanChannel() {
			return loanChannel;
		}
		public void setLoanChannel(Long loanChannel) {
			this.loanChannel = loanChannel;
		}
		public String getBackFlag() {
			return backFlag;
		}
		public void setBackFlag(String backFlag) {
			this.backFlag = backFlag;
		}
		public String getIncomeAcountNum() {
			return incomeAcountNum;
		}
		public void setIncomeAcountNum(String incomeAcountNum) {
			this.incomeAcountNum = incomeAcountNum;
		}
		public Long getIsNyAcount() {
			return isNyAcount;
		}
		public void setIsNyAcount(Long isNyAcount) {
			this.isNyAcount = isNyAcount;
		}
		public Date getLoanMoneyTime() {
			return loanMoneyTime;
		}
		public void setLoanMoneyTime(Date loanMoneyTime) {
			this.loanMoneyTime = loanMoneyTime;
		}
		public Date getPushTime() {
			return pushTime;
		}
		public void setPushTime(Date pushTime) {
			this.pushTime = pushTime;
		}
		public String getMp() {
			return mp;
		}
		public void setMp(String mp) {
			this.mp = mp;
		}
		public Long getType() {
			return type;
		}
		public void setType(Long type) {
			this.type = type;
		}
		public Long getTbState() {
			return tbState;
		}
		public void setTbState(Long tbState) {
			this.tbState = tbState;
		}
		public Long getStoreOrgId() {
			return storeOrgId;
		}
		public void setStoreOrgId(Long storeOrgId) {
			this.storeOrgId = storeOrgId;
		}
		public Long getProductId() {
			return productId;
		}
		public void setProductId(Long productId) {
			this.productId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public BigDecimal getProductProportion() {
			return productProportion;
		}
		public void setProductProportion(BigDecimal productProportion) {
			this.productProportion = productProportion;
		}
		public BigDecimal getServiceProportion() {
			return serviceProportion;
		}
		public void setServiceProportion(BigDecimal serviceProportion) {
			this.serviceProportion = serviceProportion;
		}
		public BigDecimal getBreachProportion() {
			return breachProportion;
		}
		public void setBreachProportion(BigDecimal breachProportion) {
			this.breachProportion = breachProportion;
		}
		public BigDecimal getFineProportion() {
			return fineProportion;
		}
		public void setFineProportion(BigDecimal fineProportion) {
			this.fineProportion = fineProportion;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public Long getCustId() {
			return custId;
		}
		public void setCustId(Long custId) {
			this.custId = custId;
		}
		public Long getIsLoop() {
			return isLoop;
		}
		public void setIsLoop(Long isLoop) {
			this.isLoop = isLoop;
		}
		public BigDecimal getMonthRepaymentMoney() {
			return monthRepaymentMoney;
		}
		public void setMonthRepaymentMoney(BigDecimal monthRepaymentMoney) {
			this.monthRepaymentMoney = monthRepaymentMoney;
		}
		public int getProductLimit() {
			return productLimit;
		}
		public void setProductLimit(int productLimit) {
			this.productLimit = productLimit;
		}
		public String getStoreOrgName() {
			return storeOrgName;
		}
		public void setStoreOrgName(String storeOrgName) {
			this.storeOrgName = storeOrgName;
		}
		public String getClientIdcard() {
			return clientIdcard;
		}
		public void setClientIdcard(String clientIdcard) {
			this.clientIdcard = clientIdcard;
		}
		public String getClientLabelIds() {
			return clientLabelIds;
		}
		public void setClientLabelIds(String clientLabelIds) {
			this.clientLabelIds = clientLabelIds;
		}
		public String getClientLabel() {
			return clientLabel;
		}
		public void setClientLabel(String clientLabel) {
			this.clientLabel = clientLabel;
		}
		public String getDcRecommendText() {
			return dcRecommendText;
		}
		public void setDcRecommendText(String dcRecommendText) {
			this.dcRecommendText = dcRecommendText;
		}
		@Override
		public String toString() {
			return "XybContractDTO [id=" + id + ", applyId=" + applyId + ", cusNumber=" + cusNumber + ", agreeEffect="
					+ agreeEffect + ", agreeFailure=" + agreeFailure + ", isTempSave=" + isTempSave
					+ ", repaymentDateStart=" + repaymentDateStart + ", repDate=" + repDate + ", repDateNew="
					+ repDateNew + ", bankType=" + bankType + ", bankAccount=" + bankAccount + ", contractProvince="
					+ contractProvince + ", contractCity=" + contractCity + ", contractArea=" + contractArea
					+ ", bankAccountOpen=" + bankAccountOpen + ", contractNum=" + contractNum + ", helpUid=" + helpUid
					+ ", helpName=" + helpName + ", refundCardNum=" + refundCardNum + ", refundCardNum1="
					+ refundCardNum1 + ", isCreditCheck=" + isCreditCheck + ", isAttention=" + isAttention
					+ ", protocolUid=" + protocolUid + ", protocolName=" + protocolName + ", bankCheck=" + bankCheck
					+ ", bankCheckUid=" + bankCheckUid + ", bankCheckUname=" + bankCheckUname + ", houseCheck="
					+ houseCheck + ", houseCheckUid=" + houseCheckUid + ", houseCheckName=" + houseCheckName
					+ ", contractRemark=" + contractRemark + ", contractViewPath=" + contractViewPath
					+ ", contractDownLoadPath=" + contractDownLoadPath + ", contractState=" + contractState
					+ ", createUser=" + createUser + ", createName=" + createName + ", createTime=" + createTime
					+ ", modifyUser=" + modifyUser + ", modifyName=" + modifyName + ", modifyTime=" + modifyTime
					+ ", contractAbolitionTime=" + contractAbolitionTime + ", contractAbolition=" + contractAbolition
					+ ", contractAbolitionName=" + contractAbolitionName + ", remarks=" + remarks + ", isRepaymentPlan="
					+ isRepaymentPlan + ", loanChannel=" + loanChannel + ", backFlag=" + backFlag + ", incomeAcountNum="
					+ incomeAcountNum + ", isNyAcount=" + isNyAcount + ", loanMoneyTime=" + loanMoneyTime
					+ ", pushTime=" + pushTime + ", mp=" + mp + ", type=" + type + ", tbState=" + tbState
					+ ", storeOrgId=" + storeOrgId + ", productId=" + productId + ", productName=" + productName
					+ ", productProportion=" + productProportion + ", serviceProportion=" + serviceProportion
					+ ", breachProportion=" + breachProportion + ", fineProportion=" + fineProportion + ", custName="
					+ custName + ", custId=" + custId + ", isLoop=" + isLoop + ", monthRepaymentMoney="
					+ monthRepaymentMoney + ", productLimit=" + productLimit + ", storeOrgName=" + storeOrgName
					+ ", clientIdcard=" + clientIdcard + ", clientLabelIds=" + clientLabelIds + ", clientLabel="
					+ clientLabel + ", dcRecommendText=" + dcRecommendText + "]";
		}
		
}
