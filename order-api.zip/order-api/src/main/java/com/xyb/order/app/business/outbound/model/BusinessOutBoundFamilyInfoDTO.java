package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.List;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 家庭信息DTO
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundFamilyInfoDTO implements IBaseModel {

	private static final long serialVersionUID = -1068214878763235498L;

	private List<BusinessOutBoundFamilyInfoDO> businessOutBoundFamilyInfoDOs;

	public List<BusinessOutBoundFamilyInfoDO> getBusinessOutBoundFamilyInfoDOs() {
		return businessOutBoundFamilyInfoDOs;
	}

	public void setBusinessOutBoundFamilyInfoDOs(List<BusinessOutBoundFamilyInfoDO> businessOutBoundFamilyInfoDOs) {
		this.businessOutBoundFamilyInfoDOs = businessOutBoundFamilyInfoDOs;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundFamilyInfoDTO{" +
				"businessOutBoundFamilyInfoDOs=" + businessOutBoundFamilyInfoDOs +
				'}';
	}
}
