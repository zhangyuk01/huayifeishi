package com.xyb.order.common.util;


public class MessageCountStr {  
    /** 
     * 有一个字符串，其中包含中文字符、英文字符和数字字符，请统计和打印出各个字符的个数 
     * @author Mr.Liao 
     * @date 2013-09-04 
     * 短信发送平台，短信字数控制查询方法 
     */  
        public static void main(String[] args) {
  
            //String str = "adasf AAADFD我是中文,，》123";  
            //String str = "金马甲高端商品交易平台--2013全城热恋克拉钻石项目预售，18个月，三万起步，年化8%，预购请致电展恒私人财富：18611297979";  
            String str = "展恒理财，2004年在北京成立，是国内最大的理财咨询类机构之一。获得国家颁发的独立基金销售牌照.是2013年中国网球公开赛10大核心赞助商之一。公司成立10年来，在为客户进行全面的家庭财务规划方面积累了十分丰富的经验。目前拥有中高端忠实客户10000多名，配置客户资金超过200亿元，位列行业排名前三强。";
              
            System.out.println("[总字符数1]："+countSum(str));
            System.out.println("--------------------");
            System.out.println("[总字符数2]："+countSum2(str));
            System.out.println("--------------------");
            System.out.println("[总字符数3]："+str.length());
        }  
          
        public static int countSum(String str) {
            int unicodeCount = 0;  
            int szCount = 0;  
            int zmCount = 0;  
  
            for (int i = 0; i < str.length(); i++) {  
  
                char c = str.charAt(i);  
                if (c >= '0' && c <= '9') {  
                    szCount++;  
                }else if((c >= 'a' && c<='z') || (c >= 'A' && c<='Z')){  
                    zmCount++;  
                }else{  
                    unicodeCount++;  
                }  
            }  
            System.out.println("Unicode:"+unicodeCount);
            System.out.println("数字："+szCount);
            System.out.println("字母："+zmCount);
            int sum=szCount+zmCount+unicodeCount;  
            return sum;  
        }     
        public static int countSum2(String str) {
            int abccount = 0;  
            int numcount = 0;  
            int spacecount = 0;  
            int othercount = 0;  
            char[] b = str.toCharArray();  
            for(int i = 0; i < b.length; i++){  
                if(b[i]>='a'&&b[i]<='z'||b[i]>='A'&&b[i]<='Z'){  
                    abccount++;  
                }else if(b[i]>='0'&&b[i]<='9'){  
                    numcount++;  
                }else if(b[i]==' '){  
                    spacecount++;  
                }else{  
                    othercount++;  
                }  
        }  
            int sum=abccount+numcount+spacecount+othercount;  
            System.out.println("字符串中含有的英文字母数为：" + abccount);
            System.out.println("字符串中含有的数字数为：" + numcount);
            System.out.println("字符串中含有的空格数为：" + spacecount);
            System.out.println("字符串中含有的其他字符为：" + othercount);
            return sum;   
    }  
} 