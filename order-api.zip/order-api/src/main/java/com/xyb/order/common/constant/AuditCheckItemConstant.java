package com.xyb.order.common.constant;

/**
 * 初审审核项字典
 */
public class AuditCheckItemConstant {
    /**申请单*/
    public static final int APPLY = 1;
    /**同行借贷*/
    public static final int PEER_LENDING = 2;
    /**简版人行报告*/
    public static final int HUMAN_REPORT = 3;
    /**结清证明*/
    public static final int SETTLE = 4;
    /**身份证明*/
    public static final int IDENTITY = 5;
    /**工作证明*/
    public static final int WORK = 6;
    /**个人收入证明*/
    public static final int PERSONAL_INCOME = 7;
    /**经营证明*/
    public static final int MANAGEMENT = 8;
    /**企业收入证明*/
    public static final int ENTERPRISE_INCOME = 9;
    /**居住地证明*/
    public static final int PLACE_RESIDENCE = 10;
    /**房产证明*/
    public static final int HOUSE_PROPERTY = 11;
    /**通话详单*/
    public static final int CALL_DETAILS = 12;
    /**其他材料*/
    public static final int OTHER = 13;
    /**申请核查*/
    public static final int APPLY_CHECK = 14;
    /**实地征信*/
    public static final int FIELD_LETTER = 15;
    /**产调*/
    public static final int INDUSTRY = 16;
    /**实地征信与产调*/
    public static final int FIELD_LETTER_AND_INDUSTRY = 17;
    /**欺诈报告*/
    public static final int CHEAT_REPORT = 18;
    /**保单证明*/ 
    public static final int BAODAN_REPORT = 19;
    /**历史合同信息*/
    public static final int CONTRACT_LOG_INFO = 20;
}
