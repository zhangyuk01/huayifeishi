package com.xyb.order.common.material.service;

/**
 * @ClassName FileClassificationService
 * @author ZhangYu
 * @date 2018年4月17号
 */
public interface FileClassificationService {


	/**
	 * 根据分类code查询图片ID
	 * @param fileClassificationCode
	 * @return
	 */
	Long getImageIdByCode(String fileClassificationCode) ;
	

}
