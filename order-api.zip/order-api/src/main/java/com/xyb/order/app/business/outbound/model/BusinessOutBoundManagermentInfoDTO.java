package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访经营信息 DTOmodel
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundManagermentInfoDTO implements IBaseModel {

	private static final long serialVersionUID = -668823150505543248L;

	private List<BusinessOutBoundManagermentInfoDO> businessOutBoundManagermentInfoDOs;

	public List<BusinessOutBoundManagermentInfoDO> getBusinessOutBoundManagermentInfoDOs() {
		return businessOutBoundManagermentInfoDOs;
	}

	public void setBusinessOutBoundManagermentInfoDOs(List<BusinessOutBoundManagermentInfoDO> businessOutBoundManagermentInfoDOs) {
		this.businessOutBoundManagermentInfoDOs = businessOutBoundManagermentInfoDOs;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundManagermentInfoDTO{" +
				"businessOutBoundManagermentInfoDOs=" + businessOutBoundManagermentInfoDOs +
				'}';
	}
}
