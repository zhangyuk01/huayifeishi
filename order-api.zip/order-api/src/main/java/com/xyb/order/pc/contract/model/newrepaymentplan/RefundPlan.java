package com.xyb.order.pc.contract.model.newrepaymentplan;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RefundPlan {

	private Date fullTime; // 满标时间

	private BigDecimal yearRate;// 年化收益

	private List<RefundUnit> borrowerRefunds = new ArrayList<RefundUnit>(); // 借款人的还款计划

	public void AddBorrowerRefundUnit(RefundUnit un) {

		borrowerRefunds.add(un);

	}

	// 获取借款人应还总额
	public BigDecimal getTotalBorrowMoney() {

		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : borrowerRefunds) {

			total = total.add(un.getPrincipal()).add(un.getInterest());
		}
		return total;  
		
	}

	private Map<Long, List<RefundUnit>> investorRefunds = new HashMap<Long, List<RefundUnit>>(); // 出借人回款计划

	private Map<Long, List<RefundUnit>> investorGiveAwayMoenyRefunds = new HashMap<Long, List<RefundUnit>>(); // 出借人体验金回款计划
	
	private List<RefundUnit> refunds = new ArrayList<RefundUnit>(); //还款计划

	// 获取总的待收金额
	public BigDecimal getTotalLoanMoney(Long key) {
		List<RefundUnit> uns = investorRefunds.get(key);

		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : uns) {

//			total = total.add(un.getPrincipal()).add(un.getInterest());
			total = total.add(un.getPrincipal().add(un.getInterest()).add(un.getAddInterest()).setScale(2, BigDecimal.ROUND_DOWN));
		}

		return total;
	}
	
	//总收益
	public BigDecimal getTotalInterest(){
		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : refunds) {

			total = total.add(un.getInterest());
		}
		return total;
	}
	
	// 总加息收益
	public BigDecimal getTotalAddInterest() {
		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : refunds) {

			total = total.add(un.getAddInterest());
		}
		return total;
	}
	
	//总的收益
	public BigDecimal getTotalLoanMoneyInterest(Long key) {
		List<RefundUnit> uns = investorRefunds.get(key);

		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : uns) {

			total = total.add(un.getInterest());
		}

		return total;
	}

	// 获取总的体验金金额
	public BigDecimal getTotalGiveAwayMoenyMoney(Long key) {
		List<RefundUnit> uns = investorGiveAwayMoenyRefunds.get(key);

		BigDecimal total = BigDecimal.ZERO;

		for (RefundUnit un : uns) {

			total = total.add(un.getPrincipal()).add(un.getInterest());
		}

		return total;
	}

	public void addInvestorRefundUnit(Long bid, List<RefundUnit> unlist) {
		investorRefunds.put(bid, unlist);

	}
	
	//体验金的回款单元
	public void addInvestorGiveAwayMoneyRefundUnit(Long bid, List<RefundUnit> unlist) {
		
		investorGiveAwayMoenyRefunds.put(bid, unlist);

	}

	public List<RefundUnit> getBidRefundUnitsById(Long id) {

		return investorRefunds.get(id);
	}
	
	
	public List<RefundUnit> getGiveAwayMoenyRefundUnitsById(Long id) {
		
		return investorGiveAwayMoenyRefunds.get(id);
	}
	
	public RefundPlan(Date fullTime, BigDecimal yearRate){
		this.fullTime = fullTime ;
		this.yearRate = yearRate ;
	}

	public Date getFullTime() {
		return fullTime;
	}

	public void setFullTime(Date fullTime) {
		this.fullTime = fullTime;
	}

	public BigDecimal getYearRate() {
		return yearRate;
	}

	public void setYearRate(BigDecimal yearRate) {
		this.yearRate = yearRate;
	}

	public Map<Long, List<RefundUnit>> getInvestorRefunds() {
		return investorRefunds;
	}

	public void setInvestorRefunds(Map<Long, List<RefundUnit>> investorRefunds) {
		this.investorRefunds = investorRefunds;
	}

	public List<RefundUnit> getBorrowerRefunds() {
		return borrowerRefunds;
	}

	public void setBorrowerRefunds(List<RefundUnit> borrowerRefunds) {
		this.borrowerRefunds = borrowerRefunds;
	}

	public List<RefundUnit> getRefunds() {
		return refunds;
	}

	public void setRefunds(List<RefundUnit> refunds) {
		this.refunds = refunds;
	}
	
	/**
	 * 得到理财人指定期数回款本息总额
	 * @param period
	 * @return
	 */
	public BigDecimal getInvestTotalEveryMonth(int period) {
		BigDecimal total = BigDecimal.ZERO;
		for(Map.Entry<Long, List<RefundUnit>> unit:investorRefunds.entrySet()){
			//得到该期的所有本息和
			if(unit.getValue().get(period)!=null)
				total = total.add(unit.getValue().get(period).getPrincipal()).add(unit.getValue().get(period).getInterest()) ;
		}
		return total ;
	}
	
	/**
	 * 得到理财人指定期数回款本息总额
	 * @param period
	 * @return
	 */
	public BigDecimal getInvestTotalPrincipal(int period) {
		BigDecimal total = BigDecimal.ZERO;
		for(Map.Entry<Long, List<RefundUnit>> unit:investorRefunds.entrySet()){
			//得到该期的所有本息和
			if(unit.getValue().get(period)!=null)
				total = total.add(unit.getValue().get(period).getPrincipal()) ;
		}
		return total ;
	}

}
