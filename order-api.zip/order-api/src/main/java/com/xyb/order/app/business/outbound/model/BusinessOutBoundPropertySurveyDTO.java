package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访产调 DTO
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundPropertySurveyDTO implements IBaseModel {

	private static final long serialVersionUID = 2260730531465532836L;

	private Long id;
	/**申请id*/
	@NotNull(message = "applyId不能为空")
	private Long applyId;

	/**产调时间*/
	@NotNull(message = "propertySurveyDate不能为空")
	private String propertySurveyDate;

	/**房屋属性(大类2733)*/
	@NotNull(message = "houseAttribute不能为空")
	private Long houseAttribute;

	/**产权来源（大类2734）*/
	@NotNull(message = "propertySource不能为空")
	private Long propertySource;

	/**产权来源备注*/
	private String propertySourceRemark;

	/**抵押次数(大类2735)*/
	@NotNull(message = "mortgageTimes不能为空")
	private Long mortgageTimes;

	/**抵押权人性质，多选英文逗号隔开（大类2736）*/
	@NotNull(message = "mortgageeNature不能为空")
	private String mortgageeNature;

	/**限制情况，多选英文逗号隔开（大类2737）*/
	@NotNull(message = "restrictions不能为空")
	private String restrictions;

	/**限制情况*/
	private String restrictionsQt;

	/**产调备注*/
	private String remark;

	/**操作时间*/
	private Date createTime;

	/**操作者*/
	private Long createUser;

	/**最后更新时间*/
	private Date modifyTime;

	/**最后修改人*/
	private Long modifyUser;

	private Long visitMainId;

	private String flag;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public String getPropertySurveyDate() {
		return propertySurveyDate;
	}

	public void setPropertySurveyDate(String propertySurveyDate) {
		this.propertySurveyDate = propertySurveyDate;
	}

	public Long getHouseAttribute() {
		return houseAttribute;
	}

	public void setHouseAttribute(Long houseAttribute) {
		this.houseAttribute = houseAttribute;
	}

	public Long getPropertySource() {
		return propertySource;
	}

	public void setPropertySource(Long propertySource) {
		this.propertySource = propertySource;
	}

	public String getPropertySourceRemark() {
		return propertySourceRemark;
	}

	public void setPropertySourceRemark(String propertySourceRemark) {
		this.propertySourceRemark = propertySourceRemark;
	}

	public Long getMortgageTimes() {
		return mortgageTimes;
	}

	public void setMortgageTimes(Long mortgageTimes) {
		this.mortgageTimes = mortgageTimes;
	}

	public String getMortgageeNature() {
		return mortgageeNature;
	}

	public void setMortgageeNature(String mortgageeNature) {
		this.mortgageeNature = mortgageeNature;
	}

	public String getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}

	public String getRestrictionsQt() {
		return restrictionsQt;
	}

	public void setRestrictionsQt(String restrictionsQt) {
		this.restrictionsQt = restrictionsQt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundPropertySurveyDTO{" +
				"id=" + id +
				", applyId=" + applyId +
				", propertySurveyDate='" + propertySurveyDate + '\'' +
				", houseAttribute=" + houseAttribute +
				", propertySource=" + propertySource +
				", propertySourceRemark='" + propertySourceRemark + '\'' +
				", mortgageTimes=" + mortgageTimes +
				", mortgageeNature='" + mortgageeNature + '\'' +
				", restrictions='" + restrictions + '\'' +
				", restrictionsQt='" + restrictionsQt + '\'' +
				", remark='" + remark + '\'' +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				", visitMainId=" + visitMainId +
				", flag='" + flag + '\'' +
				'}';
	}
}
