package com.xyb.order.pc.creditreport.model;

import java.util.Date;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditInSuranceAllDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Date systemDate;
	private List<AuditInsuranceDO> auditInsuranceDOs;

	public Date getSystemDate() {
		return systemDate;
	}
	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}
	public List<AuditInsuranceDO> getAuditInsuranceDOs() {
		return auditInsuranceDOs;
	}
	public void setAuditInsuranceDOs(List<AuditInsuranceDO> auditInsuranceDOs) {
		this.auditInsuranceDOs = auditInsuranceDOs;
	}


}
