package com.xyb.order.pc.deposit.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.model
 * @description : 资料变更审核列表参数
 * @createDate : 2018/06/29 15:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class DepositChangeDTO implements IBaseModel {

    private static final long serialVersionUID = -5758645137635899170L;

    private String clientName;
    private String idCard;
    private String phone;
    @JsonIgnore
    private Long orgId;
    @JsonIgnore
    Page page = new Page();

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    @Override
    public String toString() {
        return "DepositChangeDTO{" +
                "clientName='" + clientName + '\'' +
                ", idCard='" + idCard + '\'' +
                ", phone='" + phone + '\'' +
                ", page=" + page +
                ", orgId=" + orgId +
                '}';
    }
}
