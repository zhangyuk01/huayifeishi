package com.xyb.order.app.client.personinfo.model;

import java.util.Date;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDTO;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class ApplyPersonBaseInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //主键ID
	@JsonIgnore
	private Long applyId;//申请单ID
	@JsonIgnore
	private Long cusId;//客户ID
	@JsonIgnore
	private String phone1;
	@NotNull(message = "最高学历不能为空")
	private Long education; //最高学历
	@NotNull(message = "婚姻状况不能为空")
	private Long marriage; //婚姻状况
	@NotNull(message = "子女数量不能为空")
	private Long childrenNum;//子女数量
	@NotNull(message = "居住状态不能为空")
	private Long liveCase;//居住状态
	@NotEmpty(message = "共同居住者不能为空")
	private String liveJoin;//共同居住者
	private String liveJoinOther;//共同居住着其他
	@NotNull(message = "目前地址省不能为空")
	private Long nowAddressProvince;//目前地址省
	@NotNull(message = "目前地址市不能为空")
	private Long nowAddressCity;//目前地址市
	@NotNull(message = "目前地址区不能为空")
	private Long nowAddressArea;//目前地址区
	@NotEmpty(message = "目前地址不能为空")
	private String nowAddress;//目前地址
	private List<ApplyFamilyChildrenDTO> applyFamilyChildrenDTOs;//子女信息
	@JsonIgnore
	private Date createTime; //创建时间
	@JsonIgnore
	private Long createUser; //创建人
	@JsonIgnore
	private Date modifyTime; //修改时间
	@JsonIgnore
	private Long modifyUser; //修改人
	@JsonIgnore
	private String homeTownProvince;
	@JsonIgnore
	private String homeTownCity;
	@JsonIgnore
	private String homeTownArea;
	@JsonIgnore
	private String homeTown;
	@JsonIgnore
	private String homeAllAddress;
	@JsonIgnore
	private Date validTime;
	@JsonIgnore
	private String nowAllAddress;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	
	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public Long getEducation() {
		return education;
	}

	public void setEducation(Long education) {
		this.education = education;
	}

	public Long getMarriage() {
		return marriage;
	}

	public void setMarriage(Long marriage) {
		this.marriage = marriage;
	}

	public Long getChildrenNum() {
		return childrenNum;
	}

	public void setChildrenNum(Long childrenNum) {
		this.childrenNum = childrenNum;
	}

	public Long getLiveCase() {
		return liveCase;
	}

	public void setLiveCase(Long liveCase) {
		this.liveCase = liveCase;
	}

	public String getLiveJoin() {
		return liveJoin;
	}

	public void setLiveJoin(String liveJoin) {
		this.liveJoin = liveJoin;
	}

	public String getLiveJoinOther() {
		return liveJoinOther;
	}

	public void setLiveJoinOther(String liveJoinOther) {
		this.liveJoinOther = liveJoinOther;
	}

	public Long getNowAddressProvince() {
		return nowAddressProvince;
	}

	public void setNowAddressProvince(Long nowAddressProvince) {
		this.nowAddressProvince = nowAddressProvince;
	}

	public Long getNowAddressCity() {
		return nowAddressCity;
	}

	public void setNowAddressCity(Long nowAddressCity) {
		this.nowAddressCity = nowAddressCity;
	}

	public Long getNowAddressArea() {
		return nowAddressArea;
	}

	public void setNowAddressArea(Long nowAddressArea) {
		this.nowAddressArea = nowAddressArea;
	}

	public String getNowAddress() {
		return nowAddress;
	}

	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}

	public List<ApplyFamilyChildrenDTO> getApplyFamilyChildrenDTOs() {
		return applyFamilyChildrenDTOs;
	}

	public void setApplyFamilyChildrenDTOs(List<ApplyFamilyChildrenDTO> applyFamilyChildrenDTOs) {
		this.applyFamilyChildrenDTOs = applyFamilyChildrenDTOs;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getHomeTownProvince() {
		return homeTownProvince;
	}

	public void setHomeTownProvince(String homeTownProvince) {
		this.homeTownProvince = homeTownProvince;
	}

	public String getHomeTownCity() {
		return homeTownCity;
	}

	public void setHomeTownCity(String homeTownCity) {
		this.homeTownCity = homeTownCity;
	}

	public String getHomeTownArea() {
		return homeTownArea;
	}

	public void setHomeTownArea(String homeTownArea) {
		this.homeTownArea = homeTownArea;
	}

	public String getHomeTown() {
		return homeTown;
	}

	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}

	public String getHomeAllAddress() {
		return homeAllAddress;
	}

	public void setHomeAllAddress(String homeAllAddress) {
		this.homeAllAddress = homeAllAddress;
	}

	public Date getValidTime() {
		return validTime;
	}

	public void setValidTime(Date validTime) {
		this.validTime = validTime;
	}

	public String getNowAllAddress() {
		return nowAllAddress;
	}

	public void setNowAllAddress(String nowAllAddress) {
		this.nowAllAddress = nowAllAddress;
	}
}
