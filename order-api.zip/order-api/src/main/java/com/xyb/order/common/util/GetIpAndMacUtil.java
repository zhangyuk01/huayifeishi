/**
 * 
 */
package com.xyb.order.common.util;

import java.net.NetworkInterface;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.common.util
 * @description : TODO
 * @createDate : 2018年11月26日 下午4:17:47
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class GetIpAndMacUtil {

     /**获取mac地址*/
     public static String getMacAddress() throws Exception{
         Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
         byte[] mac = null;
         while (allNetInterfaces.hasMoreElements()) {
             NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
             if (netInterface.isLoopback() || netInterface.isVirtual() || netInterface.isPointToPoint() || !netInterface.isUp()) {
                 continue;
             } else {
                 mac = netInterface.getHardwareAddress();
                 if (mac != null) {
                     StringBuilder sb = new StringBuilder();
                     for (int i = 0; i < mac.length; i++) {
                         sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
                     }
                     if (sb.length() > 0) {
                         return sb.toString();
                     }
                 }
             }
         }
         return "";
     }
 
     /**获取ip地址*/
     public static String getIpAddress(HttpServletRequest request) throws Exception {
    	 String ip = request.getHeader("X-Forwarded-For");
    	 if(ip == null || ip.length() == 0||"unknown".equalsIgnoreCase(ip)){
    		 ip = request.getHeader("Proxy-Client-IP");
    	 }
    	 if(ip == null || ip.length()==0 || "unknown".equalsIgnoreCase(ip)){
    		 ip=request.getHeader("WL-Proxy-Client-IP");
    	 }
    	 if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
    		 ip = request.getHeader("HTTP_CLIENT_IP");
    	 } 
    	 if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
    		 ip = request.getHeader("HTTP_X_FORWARDED_FOR");
    	 }
    	 if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
    		 ip = request.getRemoteAddr();
    	 }
    	 return ip;

     }
     
     public static void main(String[] args) {
		try {
			System.out.println(getMacAddress());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
