package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
* @description:    产品配置三方表
* @author:         xieqingyang
* @createDate:     2018/5/14 下午7:27
*/
public class AuthorizationProductDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private Long id;
    /**产品ID*/
    private Long productId;
    /**三方类型 2873,聚信力运营商报告;2874,聚信力保单报告;2875,融360社保;2876,融360公积金;2877,融360简版人行;2878,算话人行报告*/
    private Long authorizationType;
    /**三方类型名称*/
    private String authorizationTypeName;
    /**是否开启*/
    private Long isOpen;
    /**强授权类型*/
    private Long forceType;
    /**是否必附*/
    private Long isAdditional;
    private Date createTime;
    private Long createUser;
    private Date modifyTime;
    private Long modifyUser;

    public long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getAuthorizationTypeName() {
        return authorizationTypeName;
    }

    public void setAuthorizationTypeName(String authorizationTypeName) {
        this.authorizationTypeName = authorizationTypeName;
    }

    public Long getAuthorizationType() {
        return authorizationType;
    }

    public void setAuthorizationType(Long authorizationType) {
        this.authorizationType = authorizationType;
    }

    public Long getIsOpen() {
        return isOpen;
    }

    public void setIsOpen(Long isOpen) {
        this.isOpen = isOpen;
    }

    public Long getForceType() {
        return forceType;
    }

    public void setForceType(Long forceType) {
        this.forceType = forceType;
    }

    public Long getIsAdditional() {
        return isAdditional;
    }

    public void setIsAdditional(Long isAdditional) {
        this.isAdditional = isAdditional;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }
}
