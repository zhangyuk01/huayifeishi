package com.xyb.order.common.currency.service;

import com.xyb.order.common.currency.model.TableModifyLogDTO;

/**
 * 字符串比对
 * @author         xieqingyang
 * @date           2018/10/19 5:17 PM
*/
public interface TableModifyLogService {

    /**
     * 添加表修改日志方法
     * @author      xieqingyang
     * @date        2018/10/19 5:17 PM
     * @version     1.0
     * @param modifyLogDTO 待比对数据
     * @return 返回是否需要新增
     */
    boolean insertTableModirfyLog(TableModifyLogDTO modifyLogDTO);

    /**
     * 进件使用比对字符串
     * @author      xieqingyang
     * @date        2018/10/19 5:18 PM
     * @version     1.0
     * @param userId 用户ID
     * @param id 主键ID
     * @param tableName 表名
     * @param oldJsonData 待比对数据
     * @param newJsonData 新数据
     * @return 返回是否需要修改
     */
    boolean insertApplyCommonModifyLog(Long userId,Long id,String tableName,String oldJsonData,String newJsonData);
}
