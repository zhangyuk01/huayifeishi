/**
 * 
 */
package com.xyb.order.app.client.personinfo.model;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.app.client.personinfo.model
 * @description : TODO
 * @createDate : 2018年9月19日 下午4:25:39
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplySubmitDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6455422086926382898L;
	
	/**预授权金额*/
	private BigDecimal accreditAmount;
	/**借款金额*/
	@NotNull(message = "借款金额不能为空")
	private BigDecimal applyAmount;
	/**借款期数*/
	@NotNull(message = "借款期数不能为空")
	private Long expectTerm;
	/**借款用途*/
	@NotNull(message = "借款用途不能为空")
	private Long borrowDescCode;
	/**服务网点*/
	@NotNull(message = "服务网点不能为空")
	private Long orgId;
	/**服务网点名称*/
	@NotNull(message = "服务网点名称不能为空")
	private String orgName;
	/**申请产品id*/
	@NotNull(message = "申请产品id不能为空")
	private Long expectProductId;
	public BigDecimal getAccreditAmount() {
		return accreditAmount;
	}
	public void setAccreditAmount(BigDecimal accreditAmount) {
		this.accreditAmount = accreditAmount;
	}
	public BigDecimal getApplyAmount() {
		return applyAmount;
	}
	public void setApplyAmount(BigDecimal applyAmount) {
		this.applyAmount = applyAmount;
	}
	public Long getExpectTerm() {
		return expectTerm;
	}
	public void setExpectTerm(Long expectTerm) {
		this.expectTerm = expectTerm;
	}
	public Long getBorrowDescCode() {
		return borrowDescCode;
	}
	public void setBorrowDescCode(Long borrowDescCode) {
		this.borrowDescCode = borrowDescCode;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public Long getExpectProductId() {
		return expectProductId;
	}
	public void setExpectProductId(Long expectProductId) {
		this.expectProductId = expectProductId;
	}
	@Override
	public String toString() {
		return "ApplySubmitDTO [accreditAmount=" + accreditAmount + ", applyAmount=" + applyAmount + ", expectTerm="
				+ expectTerm + ", borrowDescCode=" + borrowDescCode + ", orgId=" + orgId + ", orgName=" + orgName
				+ ", expectProductId=" + expectProductId + "]";
	}
	
}
