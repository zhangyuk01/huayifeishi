package com.xyb.order.app.client.personinfo.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDO;

public class ApplyPersonBaseInfoDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long education;
	private String educationLabel;
	private Long marriage;
	private String marriageLabel;
	private Long childrenNum;
	private String childrenNumLabel; 
	private Long liveCase;
	private String liveCaseLabel;
	private String liveJoin;
	private String liveJoinOther;
	private Long nowAddressProvince;
	private String nowAddressProvinceLabel;
	private Long nowAddressCity;
	private String nowAddressCityLabel;
	private Long nowAddressArea;
	private String nowAddressAreaLabel;
	private String nowAddress;
	private Long creditCard;
	private List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getEducation() {
		return education;
	}
	public void setEducation(Long education) {
		this.education = education;
	}
	public Long getMarriage() {
		return marriage;
	}
	public void setMarriage(Long marriage) {
		this.marriage = marriage;
	}
	public Long getChildrenNum() {
		return childrenNum;
	}
	public void setChildrenNum(Long childrenNum) {
		this.childrenNum = childrenNum;
	}
	public Long getLiveCase() {
		return liveCase;
	}
	public void setLiveCase(Long liveCase) {
		this.liveCase = liveCase;
	}

	public String getLiveJoin() {
		return liveJoin;
	}

	public void setLiveJoin(String liveJoin) {
		this.liveJoin = liveJoin;
	}

	public Long getNowAddressProvince() {
		return nowAddressProvince;
	}
	public void setNowAddressProvince(Long nowAddressProvince) {
		this.nowAddressProvince = nowAddressProvince;
	}
	public Long getNowAddressCity() {
		return nowAddressCity;
	}
	public void setNowAddressCity(Long nowAddressCity) {
		this.nowAddressCity = nowAddressCity;
	}
	public Long getNowAddressArea() {
		return nowAddressArea;
	}
	public void setNowAddressArea(Long nowAddressArea) {
		this.nowAddressArea = nowAddressArea;
	}
	public String getNowAddress() {
		return nowAddress;
	}
	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}
	public String getEducationLabel() {
		return educationLabel;
	}
	public void setEducationLabel(String educationLabel) {
		this.educationLabel = educationLabel;
	}
	public String getMarriageLabel() {
		return marriageLabel;
	}
	public void setMarriageLabel(String marriageLabel) {
		this.marriageLabel = marriageLabel;
	}
	public String getLiveCaseLabel() {
		return liveCaseLabel;
	}
	public void setLiveCaseLabel(String liveCaseLabel) {
		this.liveCaseLabel = liveCaseLabel;
	}
	public String getNowAddressProvinceLabel() {
		return nowAddressProvinceLabel;
	}
	public void setNowAddressProvinceLabel(String nowAddressProvinceLabel) {
		this.nowAddressProvinceLabel = nowAddressProvinceLabel;
	}
	public String getNowAddressCityLabel() {
		return nowAddressCityLabel;
	}
	public void setNowAddressCityLabel(String nowAddressCityLabel) {
		this.nowAddressCityLabel = nowAddressCityLabel;
	}
	public String getNowAddressAreaLabel() {
		return nowAddressAreaLabel;
	}
	public void setNowAddressAreaLabel(String nowAddressAreaLabel) {
		this.nowAddressAreaLabel = nowAddressAreaLabel;
	}
	public List<ApplyFamilyChildrenDO> getApplyFamilyChildrenDOs() {
		return applyFamilyChildrenDOs;
	}
	public void setApplyFamilyChildrenDOs(List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs) {
		this.applyFamilyChildrenDOs = applyFamilyChildrenDOs;
	}
	public String getLiveJoinOther() {
		return liveJoinOther;
	}
	public void setLiveJoinOther(String liveJoinOther) {
		this.liveJoinOther = liveJoinOther;
	}
	public String getChildrenNumLabel() {
		return childrenNumLabel;
	}
	public void setChildrenNumLabel(String childrenNumLabel) {
		this.childrenNumLabel = childrenNumLabel;
	}
	public Long getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(Long creditCard) {
		this.creditCard = creditCard;
	}
	
}
