package com.xyb.order.app.client.quickloan.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 个人信息
 * 
 * @author qiaoJinLong
 * @date 2018年12月20日
 */
public class QuickLoanApplyPersonInfoDTO implements IBaseModel {
	private static final long serialVersionUID = 1L;
	@JsonIgnore
	private Long id; // 主键ID
	@JsonIgnore
	private Long applyId;// 申请单ID
	@JsonIgnore
	private Long cusId;// 客户ID
	@NotNull(message = "目前地址省不能为空")
	private Long nowAddressProvince;// 目前地址省
	@NotNull(message = "目前地址市不能为空")
	private Long nowAddressCity;// 目前地址市
	@NotNull(message = "目前地址区不能为空")
	private Long nowAddressArea;// 目前地址区
	@NotEmpty(message = "目前地址不能为空")
	private String nowAddress;// 目前地址
	private String nowAddresProvinceMsg;
	private String nowAddresCityMsg;
	private String nowAddresAreaMsg;
	@JsonIgnore
	private String nowAllAddress;
	@NotNull(message = "婚姻状况不能为空")
	private Long marriage; // 婚姻状况
	private String marriageMsg;// 婚姻状况
	@NotNull(message = "请选择是否持有信用卡")
	private Long creditCard;// 是否持有信用卡
	@JsonIgnore
	private String webchat;// wx
	@JsonIgnore
	private String qq;// qq
	@JsonIgnore
	private String phone1;
	@JsonIgnore
	private String phone2;// 备用手机号
	@JsonIgnore
	private Date createTime; // 创建时间
	@JsonIgnore
	private Long createUser; // 创建人
	@JsonIgnore
	private Date modifyTime; // 修改时间
	@JsonIgnore
	private Long modifyUser; // 修改人
	@JsonIgnore
	private String homeTownProvince;
	@JsonIgnore
	private String homeTownCity;
	@JsonIgnore
	private String homeTownArea;
	@JsonIgnore
	private String homeTown;
	@JsonIgnore
	private String homeAllAddress;
	@JsonIgnore
	private Date validTime;

	private Integer linkmanNum;

	public String getNowAddresProvinceMsg() {
		return nowAddresProvinceMsg;
	}

	public void setNowAddresProvinceMsg(String nowAddresProvinceMsg) {
		this.nowAddresProvinceMsg = nowAddresProvinceMsg;
	}

	public String getNowAddresCityMsg() {
		return nowAddresCityMsg;
	}

	public Integer getLinkmanNum() {
		return linkmanNum;
	}

	public void setLinkmanNum(Integer linkmanNum) {
		this.linkmanNum = linkmanNum;
	}

	public void setNowAddresCityMsg(String nowAddresCityMsg) {
		this.nowAddresCityMsg = nowAddresCityMsg;
	}

	public String getNowAddresAreaMsg() {
		return nowAddresAreaMsg;
	}

	public void setNowAddresAreaMsg(String nowAddresAreaMsg) {
		this.nowAddresAreaMsg = nowAddresAreaMsg;
	}

	public Long getApplyId() {
		return applyId;
	}

	public String getMarriageMsg() {
		return marriageMsg;
	}

	public void setMarriageMsg(String marriageMsg) {
		this.marriageMsg = marriageMsg;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getNowAllAddress() {
		return nowAllAddress;
	}

	public void setNowAllAddress(String nowAllAddress) {
		this.nowAllAddress = nowAllAddress;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getHomeTownProvince() {
		return homeTownProvince;
	}

	public void setHomeTownProvince(String homeTownProvince) {
		this.homeTownProvince = homeTownProvince;
	}

	public String getHomeTownCity() {
		return homeTownCity;
	}

	public void setHomeTownCity(String homeTownCity) {
		this.homeTownCity = homeTownCity;
	}

	public String getHomeTownArea() {
		return homeTownArea;
	}

	public void setHomeTownArea(String homeTownArea) {
		this.homeTownArea = homeTownArea;
	}

	public String getHomeTown() {
		return homeTown;
	}

	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}

	public String getHomeAllAddress() {
		return homeAllAddress;
	}

	public void setHomeAllAddress(String homeAllAddress) {
		this.homeAllAddress = homeAllAddress;
	}

	public Date getValidTime() {
		return validTime;
	}

	public void setValidTime(Date validTime) {
		this.validTime = validTime;
	}

	public String getWebchat() {
		return webchat;
	}

	public void setWebchat(String webchat) {
		this.webchat = webchat;
	}

	@Override
	public String toString() {
		return "QuickLoanApplyPersonInfoDTO [id=" + id + ", applyId=" + applyId + ", cusId=" + cusId
				+ ", nowAddressProvince=" + nowAddressProvince + ", nowAddressCity=" + nowAddressCity
				+ ", nowAddressArea=" + nowAddressArea + ", nowAddress=" + nowAddress + ", nowAddresProvinceMsg="
				+ nowAddresProvinceMsg + ", nowAddresCityMsg=" + nowAddresCityMsg + ", nowAddresAreaMsg="
				+ nowAddresAreaMsg + ", nowAllAddress=" + nowAllAddress + ", marriage=" + marriage + ", marriageMsg="
				+ marriageMsg + ", creditCard=" + creditCard + ", webchat=" + webchat + ", qq=" + qq + ", phone1="
				+ phone1 + ", phone2=" + phone2 + ", createTime=" + createTime + ", createUser=" + createUser
				+ ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser + ", homeTownProvince=" + homeTownProvince
				+ ", homeTownCity=" + homeTownCity + ", homeTownArea=" + homeTownArea + ", homeTown=" + homeTown
				+ ", homeAllAddress=" + homeAllAddress + ", validTime=" + validTime + ", linkmanNum=" + linkmanNum
				+ "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getNowAddressProvince() {
		return nowAddressProvince;
	}

	public void setNowAddressProvince(Long nowAddressProvince) {
		this.nowAddressProvince = nowAddressProvince;
	}

	public Long getNowAddressCity() {
		return nowAddressCity;
	}

	public void setNowAddressCity(Long nowAddressCity) {
		this.nowAddressCity = nowAddressCity;
	}

	public Long getNowAddressArea() {
		return nowAddressArea;
	}

	public void setNowAddressArea(Long nowAddressArea) {
		this.nowAddressArea = nowAddressArea;
	}

	public String getNowAddress() {
		return nowAddress;
	}

	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}

	public Long getMarriage() {
		return marriage;
	}

	public void setMarriage(Long marriage) {
		this.marriage = marriage;
	}

	public Long getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(Long creditCard) {
		this.creditCard = creditCard;
	}

}
