package com.xyb.order.pc.creditreport.model;

import java.util.List;
import com.beiming.kun.framework.model.IBaseModel;

public class AuditPhoneDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private AuditDetailPhoneDO auditDetailPhone; //通话信息详情
	private List<AuditPhoneLinkManInfoDO> auditLinkManInfos;//联系人列表
	
	public AuditDetailPhoneDO getAuditDetailPhone() {
		return auditDetailPhone;
	}
	public void setAuditDetailPhone(AuditDetailPhoneDO auditDetailPhone) {
		this.auditDetailPhone = auditDetailPhone;
	}
	public List<AuditPhoneLinkManInfoDO> getAuditLinkManInfos() {
		return auditLinkManInfos;
	}
	public void setAuditLinkManInfos(List<AuditPhoneLinkManInfoDO> auditLinkManInfos) {
		this.auditLinkManInfos = auditLinkManInfos;
	}
}
