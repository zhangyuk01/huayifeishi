package com.xyb.order.pc.contract.model.newrepaymentplan;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class RefundUtils {

	public final static long ONE_DAY = 60 * 60 * 24 * 1000;
	/**
	 * 30天
	 */
	public static final int D30 = 30;

	/**
	 * 360天
	 */
	public static final int D360 = 360;
	
	/**
	 * 365天
	 */
	public static final int D365 = 365;
	/**
	 * 12月
	 */
	public static final int D12 = 12;

	/**
	 * 计算最终精度
	 */
	public static final int SCALE_FINAL = 2;

	/**
	 * 计算中间精度
	 */
	public static final int SCALE_TEMP = 12;
	/**
	 * BigDecimal类型除法时使用的Scale
	 */
	public static final int BIGDECIMALL_DIV_SCALE = 30;
	
}
