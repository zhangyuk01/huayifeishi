package com.xyb.order.app.client.homepage.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:    C端app首页展示产品数据
* @author:         xieqingyang
* @createDate:     2018/5/12 下午2:06
*/
public class ProductListVO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private String productId;// -- 产品ID
    private String productName;// -- 产品名称
    private String productRate;// -- 产品费率
    private String productLimit;// -- 产品期限
    private String productAmount;// -- 产品可借金额
    private String productMaxAmount;// — 产品最大额度
    private String productMinAmount;// — 产品最小额度
    private String productCondition;// -- 产品年龄
    private String isHot;// -- 是否火热
    private String fullAmount; // -- 是否满额

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductRate() {
        return productRate;
    }

    public void setProductRate(String productRate) {
        this.productRate = productRate;
    }

    public String getProductLimit() {
        return productLimit;
    }

    public void setProductLimit(String productLimit) {
        this.productLimit = productLimit;
    }

    public String getProductAmount() {
        return productAmount;
    }

    public void setProductAmount(String productAmount) {
        this.productAmount = productAmount;
    }

    public String getProductMaxAmount() {
        return productMaxAmount;
    }

    public void setProductMaxAmount(String productMaxAmount) {
        this.productMaxAmount = productMaxAmount;
    }

    public String getProductCondition() {
        return productCondition;
    }

    public void setProductCondition(String productCondition) {
        this.productCondition = productCondition;
    }

    public String getIsHot() {
        return isHot;
    }

    public void setIsHot(String isHot) {
        this.isHot = isHot;
    }

    public String getProductMinAmount() {
        return productMinAmount;
    }

    public void setProductMinAmount(String productMinAmount) {
        this.productMinAmount = productMinAmount;
    }

    public String getFullAmount() {
        return fullAmount;
    }

    public void setFullAmount(String fullAmount) {
        this.fullAmount = fullAmount;
    }

    @Override
    public String toString() {
        return "ProductListVO{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", productRate='" + productRate + '\'' +
                ", productLimit='" + productLimit + '\'' +
                ", productAmount='" + productAmount + '\'' +
                ", productMaxAmount='" + productMaxAmount + '\'' +
                ", productMinAmount='" + productMinAmount + '\'' +
                ", productCondition='" + productCondition + '\'' +
                ", isHot='" + isHot + '\'' +
                ", fullAmount='" + fullAmount + '\'' +
                '}';
    }
}
