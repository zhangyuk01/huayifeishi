package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditOtherMaterialDTO;
import com.xyb.order.pc.creditreport.model.AuditPrivateDTO;

/**
 * @ClassName AuditOtherService
 * @author ZhangYu
 * @date 2018年4月25号
 */
public interface AuditOtherService {
	
	/**
	 * 身份证审核信息查询 
	 * @param applyId
	 * @return
	 */
	RestResponse queryPersonInfoByApplyId(Long applyId)throws Exception;

	/**
	 * 经营证明信息查询
	 * @param applyId
	 * @return
	 */
	RestResponse queryPrivateInfoByApplyId(Long applyId)throws Exception;
	
	/**
	 * 修改法人信息
	 * @param auditPrivateDTO
	 * @return
	 */
	RestResponse updateLegalPersonById(AuditPrivateDTO auditPrivateDTO)throws Exception;


	/**
	 * 根据申请单ID查询其他材料信息 
	 * @param applyId
	 * @return
	 */
	RestResponse queryOtherMaterialInfoByApplyId(Long applyId)throws Exception;
	

	/**
	 * 根据申请单ID更新材料补充信息 
	 * @param auditOtherMaterialDTO
	 */
	RestResponse updateOtherMaterialInfoTempSave(AuditOtherMaterialDTO auditOtherMaterialDTO)throws Exception;

}
