package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import java.util.Date;

/**
 * @description:    APP消息模板
 * @author:         xieqingyang
 * @createDate:     2018/6/25 下午7:46
*/
public class AppNoticeTemplateDO implements IBaseModel {

    private static final long serialVersionUID = 8092485440024209948L;
    /**主键ID*/
    private Long id;
    /**通知类型(大类2713)*/
    private Long type;
    /**标题*/
    private String title;
    /**内容*/
    private String content;
    /**访问连接*/
    private String url;
    /**app类型 (大类2714)*/
    private Long appType;
    /**登录设备类型 (大类2715) 暂时不用*/
    private Long equipmentType;
    /**发布时间*/
    private Date releaseTime;
    /**是否定时发布*/
    private Long isTiming;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;
    /**是否有效 (大类2687)*/
    private Long state;
    /**android友盟推送唯一标识*/
    private String androidTaskId;
    /**ios友盟推送唯一标识*/
    private String iosTaskId;
    /**上传附件路径*/
    private String messageFilePath;
    /**上传附件名称*/
    private String messageFileName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getAppType() {
        return appType;
    }

    public void setAppType(Long appType) {
        this.appType = appType;
    }

    public Long getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(Long equipmentType) {
        this.equipmentType = equipmentType;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public Long getIsTiming() {
        return isTiming;
    }

    public void setIsTiming(Long isTiming) {
        this.isTiming = isTiming;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public String getAndroidTaskId() {
        return androidTaskId;
    }

    public void setAndroidTaskId(String androidTaskId) {
        this.androidTaskId = androidTaskId;
    }

    public String getIosTaskId() {
        return iosTaskId;
    }

    public void setIosTaskId(String iosTaskId) {
        this.iosTaskId = iosTaskId;
    }

    public String getMessageFilePath() {
        return messageFilePath;
    }

    public void setMessageFilePath(String messageFilePath) {
        this.messageFilePath = messageFilePath;
    }

    public String getMessageFileName() {
        return messageFileName;
    }

    public void setMessageFileName(String messageFileName) {
        this.messageFileName = messageFileName;
    }

    @Override
    public String toString() {
        return "AppNoticeTemplateDO{" +
                "id=" + id +
                ", type=" + type +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", url='" + url + '\'' +
                ", appType=" + appType +
                ", equipmentType=" + equipmentType +
                ", releaseTime=" + releaseTime +
                ", isTiming=" + isTiming +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                ", state=" + state +
                ", androidTaskId='" + androidTaskId + '\'' +
                ", iosTaskId='" + iosTaskId + '\'' +
                ", messageFilePath='" + messageFilePath + '\'' +
                ", messageFileName='" + messageFileName + '\'' +
                '}';
    }
}
