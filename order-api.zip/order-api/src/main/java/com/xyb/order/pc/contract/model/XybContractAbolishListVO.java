package com.xyb.order.pc.contract.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同废除list返回数据model
 * @createDate : 2018/05/03 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAbolishListVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -521481782993170027L;
	
	/**申请Id*/
	private Long applyId;
	/**申请编号*/
	private String applyNum;
	/**合同编号*/
	private String contractNum;
	/**一级授信金额*/
	private BigDecimal agreeAmount;
	/**审批日期*/
	private Date submitTime;
	/**客户姓名*/
	private String custName;
	/**身份证号码*/
	private String idCard;
	/**终极授信金额*/
	private BigDecimal contractAmount;
	/**进件机构*/
	private String orgName;
	/**当前状态*/
	private String stateName;
	/**废除日期*/
	private Date abolishTime;
	/**废除原因*/
	private String abolishReason;
	/**废除备注*/
	private String abolishRemark;
	/**确认金额*/
	private BigDecimal confirmAmout;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public Date getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(Date submitTime) {
		this.submitTime = submitTime;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Date getAbolishTime() {
		return abolishTime;
	}
	public void setAbolishTime(Date abolishTime) {
		this.abolishTime = abolishTime;
	}
	public String getAbolishReason() {
		return abolishReason;
	}
	public void setAbolishReason(String abolishReason) {
		this.abolishReason = abolishReason;
	}
	public String getAbolishRemark() {
		return abolishRemark;
	}
	public void setAbolishRemark(String abolishRemark) {
		this.abolishRemark = abolishRemark;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	@Override
	public String toString() {
		return "XybContractAbolishListVO{" +
				"applyId=" + applyId +
				", applyNum='" + applyNum + '\'' +
				", contractNum='" + contractNum + '\'' +
				", agreeAmount=" + agreeAmount +
				", submitTime=" + submitTime +
				", custName='" + custName + '\'' +
				", idCard='" + idCard + '\'' +
				", contractAmount=" + contractAmount +
				", orgName='" + orgName + '\'' +
				", stateName='" + stateName + '\'' +
				", abolishTime=" + abolishTime +
				", abolishReason='" + abolishReason + '\'' +
				", abolishRemark='" + abolishRemark + '\'' +
				", confirmAmout=" + confirmAmout +
				'}';
	}
}
