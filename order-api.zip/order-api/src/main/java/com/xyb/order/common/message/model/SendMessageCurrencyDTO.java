package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import java.util.Map;

/**
 * Created by xieqingyang on 2018/4/28.
 * 短信验证码 通用类
 */
public class SendMessageCurrencyDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;
    private Long messageTemplateId;// -- 短信模版ID
    private String phone;// -- 发送短信验证的手机号
    private Map<String,Object> paraMap;// -- 需替换的字段   key为模版中需替换的字符   value为替换值
    private Long userId;// -- 登录人ID

    public Long getMessageTemplateId() {
        return messageTemplateId;
    }

    public void setMessageTemplateId(Long messageTemplateId) {
        this.messageTemplateId = messageTemplateId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Map<String, Object> getParaMap() {
        return paraMap;
    }

    public void setParaMap(Map<String, Object> paraMap) {
        this.paraMap = paraMap;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
