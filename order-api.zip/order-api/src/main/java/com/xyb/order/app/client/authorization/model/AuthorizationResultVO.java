package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:    授权结果
* @author:         xieqingyang
* @createDate:     2018/5/14 下午7:35
*/
public class AuthorizationResultVO implements IBaseModel {

    private static final long serivalVersionUID = 1L;

    /**三方类型名称*/
    private String authorizationTypeName;
    /**三方类型 2873,聚信力运营商报告;2874,聚信力保单报告;2875,融360社保;2876,融360公积金;2877,融360网商;2878,算话人行报告*/
    private String authorizationType;
    /**是否强授权 Y：是 N：否*/
    private String forceType;
    /**授权结果 1:成功 2：失败 3：待授权*/
    private String result;
    /** 申请ID */
    private String applyId;



    public String getAuthorizationTypeName() {
        return authorizationTypeName;
    }

    public void setAuthorizationTypeName(String authorizationTypeName) {
        this.authorizationTypeName = authorizationTypeName;
    }

    public String getAuthorizationType() {
        return authorizationType;
    }

    public void setAuthorizationType(String authorizationType) {
        this.authorizationType = authorizationType;
    }

    public String getForceType() {
        return forceType;
    }

    public void setForceType(String forceType) {
        this.forceType = forceType;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
