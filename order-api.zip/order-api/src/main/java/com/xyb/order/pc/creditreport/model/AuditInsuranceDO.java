package com.xyb.order.pc.creditreport.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditInsuranceDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //主键ID
	private Long applyId; //申请单ID
	private Long custId; //客户ID
	private String insureManName;//投保人姓名
	private String passiveInsureManName;//被保人姓名
	private String insuranceName; //保险公司名称
	private Date effectiveDate;//保险生效日期
	private Long paymentType;//缴费方式
	private BigDecimal paymentYearAmount;//年交总额
	private Date systemDate;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public String getInsureManName() {
		return insureManName;
	}
	public void setInsureManName(String insureManName) {
		this.insureManName = insureManName;
	}
	public String getPassiveInsureManName() {
		return passiveInsureManName;
	}
	public void setPassiveInsureManName(String passiveInsureManName) {
		this.passiveInsureManName = passiveInsureManName;
	}
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Long getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(Long paymentType) {
		this.paymentType = paymentType;
	}
	public BigDecimal getPaymentYearAmount() {
		return paymentYearAmount;
	}
	public void setPaymentYearAmount(BigDecimal paymentYearAmount) {
		this.paymentYearAmount = paymentYearAmount;
	}
	public Date getSystemDate() {
		return systemDate;
	}
	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}
	
	
}
