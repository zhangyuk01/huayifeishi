package com.xyb.order.app.client.mine.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.mine.model.ApplyOnetimePaymentContinueDTO;
import com.xyb.order.app.client.mine.model.ApplyRecordConfrimDTO;
import com.xyb.order.app.client.mine.model.ApplyRecordQueryDTO;
import com.xyb.order.app.client.mine.model.ApplyReturnLoanDTO;
import com.xyb.order.app.client.mine.model.LoanConfirmationDTO;

/**
* @description:    我的功能
* @author:         xieqingyang
* @createDate:     2018/5/12 下午5:20
*/
public interface MineService {

    /**
     * @description 查询我的信息
     * @author      xieqingyang
     * @CreatedDate 2018/5/26 下午5:04
     * @Version     1.0
     */
    RestResponse queryMineInfo()throws Exception;

    /**
     * @description 查询版本信息
     * @author      xieqingyang
     * @CreatedDate 2018/5/26 下午5:03
     * @Version     1.0
     * @param deviceType app类型
     * @return 返回版本信息
     */
    RestResponse queryAppVersion(String deviceType)throws Exception;

    /**
     * 查询借款记录
     * @author      xieqingyang
     * @param
     * @return
     * @exception
     * @date        2018/5/18 下午6:06
     */
    RestResponse getApplyRecord(ApplyRecordQueryDTO applyRecordQueryDTO)throws Exception;
    
    /**
     * @description 确认借款金额信息
     * @author      ZhangYu 
     * @CreatedDate 2018/9/21 13:58
     * @param  
     * @Version     1.0
     * @return      
     */
    RestResponse getApplyRecordConfirmInfo(Long mainId,Long applyId) throws Exception;
   
    /**
     * @description 提交确认借款
     * @author      ZhangYu 
     * @CreatedDate 2018/9/21 14:58
     * @param ApplyRecordConfrimDTO 
     * @Version     1.0
     * @return      
     */
    RestResponse getApplyRecordConfirm(ApplyRecordConfrimDTO applyRecordConfrimDTO) throws Exception;
    
    
    /**
     * @description 确认还款
     * @author      ZhangYu 
     * @CreatedDate 2018/9/27 15:31
     * @param ApplyReturnLoanDTO 
     * @Version     1.0
     * @return      
     */
    RestResponse getApplyReturnLoan(ApplyReturnLoanDTO applyReturnLoanDTO) throws Exception;
    
    /**
     * @description 逾期中弹框接口 
     * @author      ZhangYu 
     * @CreatedDate 2018/10/16 15:31
     * @param  planId 
     * @Version     1.0
     * @return      
     */
    RestResponse getOutTimeContinue(Long planId) throws Exception;
    
    /**
     * @description 一次性结清列表接口 
     * @author      ZhangYu 
     * @CreatedDate 2018/9/27 15:50
     * @param  
     * @Version     1.0
     * @return      
     */ 
    RestResponse getOneTimePayment() throws Exception;
    
    /**
     * @description  
     * @author      ZhangYu 
     * @CreatedDate 2018/9/27 15:50
     * @param  
     * @Version     1.0
     * @return      
     */ 
    RestResponse getOneTimePaymentContinueZf(ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO);
    
    /**
     * @description  
     * @author      ZhangYu 
     * @CreatedDate 2018/9/27 16:00
     * @param  
     * @Version     1.0
     * @return      
     */ 
    RestResponse getOneTimePaymentContinueXh(ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO);
    
    /**
     * @description  
     * @author      ZhangYu 
     * @CreatedDate 2018/9/28 09:58
     * @param  
     * @Version     1.0
     * @return      
     */ 
    RestResponse getOneTimePaymentContnueHk();
    
    /**
     * @description  
     * @author      ZhangYu 
     * @CreatedDate 2018/10/22 15:30
     * @param  
     * @Version     1.0
     * @return      
     */ 
    RestResponse onetimePaymentHistory();

    /**
     * @description 查询借款确认信息
     * @author      xieqingyang
     * @CreatedDate 2018/5/24 下午1:02
     * @param dto 查询类型  frist：查询申请借款信息  second：查询合同借款确认信息
     * @Version     1.0
     * @return      返回借款确认信息（产品、金额、期限）
     */
    RestResponse getLoanConfirmation(LoanConfirmationDTO dto)throws Exception;

    /**
     * @description 查询用户协议信息
     * @author      xieqingyang
     * @CreatedDate 2018/8/6 下午4:57
     * @Version     1.0
     * @return 返回是否需要签署
     * @throws Exception 所有异常
     */
    RestResponse getSign()throws Exception;

    /**
     * 查询推荐人信息
     * @author      weiyuhao
     * @date        2018/8/29 下午2:36
     * @version     1.0
     * @return 推荐人信息
     * @throws Exception 所有异常
     */
    RestResponse getReferrer()throws Exception;
}
