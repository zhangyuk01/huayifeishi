package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访经营信息
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundManagermentInfoDO implements IBaseModel {

	private static final long serialVersionUID = -6586587504403564393L;

	private Long id;
	/**申请id*/
	@NotNull(message = "visitMainId不能为空")
    private Long visitMainId;

    /**外访后经营公司名称*/
	@NotNull(message = "managementCompName不能为空")
    private String managementCompName;

    /**外访后经营公司名称是否一致*/
	@NotNull(message = "isManagementCompNameSame不能为空")
    private Long isManagementCompNameSame;

	/**外访后经营公司电话区号*/
	@NotNull(message = "managementCompTellArea不能为空")
	private String managementCompTellArea;

    /**外访后经营公司电话*/
	@NotNull(message = "managementCompTell不能为空")
    private String managementCompTell;

    /**外访后经营公司电话是否一致*/
	@NotNull(message = "isManagementCompTellSame不能为空")
    private Long isManagementCompTellSame;

    /**经营公司省*/
	@NotNull(message = "managementCompAddrProvince不能为空")
    private Long managementCompAddrProvince;

    /**经营公司城市*/
	@NotNull(message = "managementCompAddrCity不能为空")
    private Long managementCompAddrCity;

    /**经营公司区*/
	@NotNull(message = "managementCompAddrArea不能为空")
    private Long managementCompAddrArea;

    /**经营公司详细地址*/
	@NotNull(message = "managementCompAddrDetail不能为空")
    private String managementCompAddrDetail;

    /**经营类别（大类2726）*/
	@NotNull(message = "managementCategory不能为空")
    private Long managementCategory;

    /**经营类别(大类2726)*/
    private String managementCategoryQt;

    /**经营地剩余使用时间（大类2727）*/
	@NotNull(message = "managementPlaceRemainingTime不能为空")
    private Long managementPlaceRemainingTime;

    /**经营面积(大类2615)*/
	@NotNull(message = "managementAcreage不能为空")
    private Long managementAcreage;

    /**经营证明(大类2728)*/
	@NotNull(message = "businessCertificate不能为空")
    private String businessCertificate;

    /**其他经营证明*/
    private String businessCertificateQt;

    /**存货品(大类2729)*/
	@NotNull(message = "goodsInStock不能为空")
    private Long goodsInStock;

    /**当日在岗员工人数(大类2730)*/
	@NotNull(message = "currentStaffsOnDuty不能为空")
    private Long currentStaffsOnDuty;

    private String remark;

    /**是否有效（大类2692）*/
    private Integer isValid;

    /**用来相同模块排序（同时插入时间区分不了显示位置）*/
    private Integer sort;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public String getManagementCompName() {
		return managementCompName;
	}

	public void setManagementCompName(String managementCompName) {
		this.managementCompName = managementCompName;
	}

	public Long getIsManagementCompNameSame() {
		return isManagementCompNameSame;
	}

	public void setIsManagementCompNameSame(Long isManagementCompNameSame) {
		this.isManagementCompNameSame = isManagementCompNameSame;
	}

	public String getManagementCompTell() {
		return managementCompTell;
	}

	public void setManagementCompTell(String managementCompTell) {
		this.managementCompTell = managementCompTell;
	}

	public Long getIsManagementCompTellSame() {
		return isManagementCompTellSame;
	}

	public void setIsManagementCompTellSame(Long isManagementCompTellSame) {
		this.isManagementCompTellSame = isManagementCompTellSame;
	}

	public Long getManagementCompAddrProvince() {
		return managementCompAddrProvince;
	}

	public void setManagementCompAddrProvince(Long managementCompAddrProvince) {
		this.managementCompAddrProvince = managementCompAddrProvince;
	}

	public Long getManagementCompAddrCity() {
		return managementCompAddrCity;
	}

	public void setManagementCompAddrCity(Long managementCompAddrCity) {
		this.managementCompAddrCity = managementCompAddrCity;
	}

	public Long getManagementCompAddrArea() {
		return managementCompAddrArea;
	}

	public void setManagementCompAddrArea(Long managementCompAddrArea) {
		this.managementCompAddrArea = managementCompAddrArea;
	}

	public String getManagementCompAddrDetail() {
		return managementCompAddrDetail;
	}

	public void setManagementCompAddrDetail(String managementCompAddrDetail) {
		this.managementCompAddrDetail = managementCompAddrDetail;
	}

	public Long getManagementCategory() {
		return managementCategory;
	}

	public void setManagementCategory(Long managementCategory) {
		this.managementCategory = managementCategory;
	}

	public String getManagementCategoryQt() {
		return managementCategoryQt;
	}

	public void setManagementCategoryQt(String managementCategoryQt) {
		this.managementCategoryQt = managementCategoryQt;
	}

	public Long getManagementPlaceRemainingTime() {
		return managementPlaceRemainingTime;
	}

	public void setManagementPlaceRemainingTime(Long managementPlaceRemainingTime) {
		this.managementPlaceRemainingTime = managementPlaceRemainingTime;
	}

	public Long getManagementAcreage() {
		return managementAcreage;
	}

	public void setManagementAcreage(Long managementAcreage) {
		this.managementAcreage = managementAcreage;
	}

	public String getBusinessCertificate() {
		return businessCertificate;
	}

	public void setBusinessCertificate(String businessCertificate) {
		this.businessCertificate = businessCertificate;
	}

	public String getBusinessCertificateQt() {
		return businessCertificateQt;
	}

	public void setBusinessCertificateQt(String businessCertificateQt) {
		this.businessCertificateQt = businessCertificateQt;
	}

	public Long getGoodsInStock() {
		return goodsInStock;
	}

	public void setGoodsInStock(Long goodsInStock) {
		this.goodsInStock = goodsInStock;
	}

	public Long getCurrentStaffsOnDuty() {
		return currentStaffsOnDuty;
	}

	public void setCurrentStaffsOnDuty(Long currentStaffsOnDuty) {
		this.currentStaffsOnDuty = currentStaffsOnDuty;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getManagementCompTellArea() {
		return managementCompTellArea;
	}

	public void setManagementCompTellArea(String managementCompTellArea) {
		this.managementCompTellArea = managementCompTellArea;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundManagermentInfoDO{" +
				"id=" + id +
				", visitMainId=" + visitMainId +
				", managementCompName='" + managementCompName + '\'' +
				", isManagementCompNameSame=" + isManagementCompNameSame +
				", managementCompTellArea='" + managementCompTellArea + '\'' +
				", managementCompTell='" + managementCompTell + '\'' +
				", isManagementCompTellSame=" + isManagementCompTellSame +
				", managementCompAddrProvince=" + managementCompAddrProvince +
				", managementCompAddrCity=" + managementCompAddrCity +
				", managementCompAddrArea=" + managementCompAddrArea +
				", managementCompAddrDetail='" + managementCompAddrDetail + '\'' +
				", managementCategory=" + managementCategory +
				", managementCategoryQt='" + managementCategoryQt + '\'' +
				", managementPlaceRemainingTime=" + managementPlaceRemainingTime +
				", managementAcreage=" + managementAcreage +
				", businessCertificate='" + businessCertificate + '\'' +
				", businessCertificateQt='" + businessCertificateQt + '\'' +
				", goodsInStock=" + goodsInStock +
				", currentStaffsOnDuty=" + currentStaffsOnDuty +
				", remark='" + remark + '\'' +
				", isValid=" + isValid +
				", sort=" + sort +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				'}';
	}
}
