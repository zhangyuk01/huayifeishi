package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
* @description:    修改密码
* @author:         xieqingyang
* @createDate:     2018/5/9 下午6:16
*/
public class ClientUserUpdateDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "手机号不能为空")
    @Size(min = 11,max = 11,message = "请传入正确的手机号")
    private String phone;// -- 手机号
    @NotEmpty(message = "短信验证码不能为空")
    private String msgCode;// -- 短信验证码
    @NotEmpty(message = "密码不能为空")
    private String newPassword;// -- 密码

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMsgCode() {
        return msgCode;
    }

    public void setMsgCode(String msgCode) {
        this.msgCode = msgCode;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
