package com.xyb.order.app.client.personalcenter.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 个人信息
 * 
 * @author qiaoJinLong
 * @date 2018年9月13日
 */
public class PersonalInfoDTO implements IBaseModel {

	private static final long serialVersionUID = 74763399558170569L;

	private String certificationState;// 认证状态 Y 已认证，N 未认证， F 认证已过期

	private String loginName; // 登陆账号

	private String clientName;// 当前登录人信息

	private String refereePhone;// 推荐人手机号

	private String refereeName; // 推荐人姓名

	@Override
	public String toString() {
		return "PersonalInfoDTO [certificationState=" + certificationState + ", loginName=" + loginName
				+ ", clientName=" + clientName + ", refereePhone=" + refereePhone + ", refereeName=" + refereeName
				+ "]";
	}

	public String getCertificationState() {
		return certificationState;
	}

	public void setCertificationState(String certificationState) {
		this.certificationState = certificationState;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getRefereePhone() {
		return refereePhone;
	}

	public void setRefereePhone(String refereePhone) {
		this.refereePhone = refereePhone;
	}

	public String getRefereeName() {
		return refereeName;
	}

	public void setRefereeName(String refereeName) {
		this.refereeName = refereeName;
	}

}
