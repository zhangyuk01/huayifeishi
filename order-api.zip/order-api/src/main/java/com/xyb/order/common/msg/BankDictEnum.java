package com.xyb.order.common.msg;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.com.xyb.order.common.msg
 * @description : 银行类型和系统字典匹配枚举
 * @createDate : 2018/04/24 11：09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public enum BankDictEnum {
	
	ICBC(1020000,"ICBC","工商银行"),
	ABC(1030000,"ABC","农业银行"),
	BOC(1040000,"BOC","中国银行"),
	CCB(1050000,"CCB","建设银行"),
	BOCM(3010000,"BOCM","交通银行"),
	CITIC(3020000,"CITIC","中信银行"),
	CEB(3030000,"CEB","光大银行"),
	CMBC(3050000,"CMBC","民生银行"),
	CGB(3060000,"CGB","广发银行"),
	PAYH(3070000,"PAYH","平安银行"),
	CIB(3090000,"CIB","兴业银行"),
	BOB(3130011,"BOB","北京银行"),
	BOSC(3130031,"BOSC","上海银行"),
	HXB(3040000,"HXB","华夏银行"),
	CMB(3080000,"CMB","招商银行"),
	PSBC(4030000,"PSBC","中国邮储"),
	SPDB(3100000,"SPDB","浦发银行"),
	NJYH(3133201,"NJYH","南京银行"),
	GZYH(4135810,"GZYH","广州银行"),
	SZRCB(14045840,"SZRCB","深圳农村商业银行"),
	CQRCB(14136900,"CQRCB","重庆农村商业银行");
	
	/**银行id*/
	long bankId;
	/**银行编码本系统*/
	String bankCode;
	/**银行名*/
	String bankName;
	
	BankDictEnum(long bankId,String bankCode,String bankName){
		this.bankId = bankId;
		this.bankCode = bankCode;
		this.bankName = bankName;
	}

	public long getBankId() {
		return bankId;
	}

	public void setBankId(long bankId) {
		this.bankId = bankId;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public static BankDictEnum getBankValue(String bankType){
		BankDictEnum bankDictEnum = null;
		switch (bankType) {
		case "ICBC":
			bankDictEnum = BankDictEnum.ICBC;
			break;
		case "ABC":
			bankDictEnum = BankDictEnum.ABC;
			break;
		case "BOC":
			bankDictEnum = BankDictEnum.BOC;
			break;
		case "CCB":
			bankDictEnum = BankDictEnum.CCB;
			break;
		case "BCM":
			bankDictEnum = BankDictEnum.BOCM;
			break;
		case "CITIC":
			bankDictEnum = BankDictEnum.CITIC;
			break;
		case "CEB":
			bankDictEnum = BankDictEnum.CEB;
			break;
		case "CMBC":
			bankDictEnum = BankDictEnum.CMBC;
			break;
		case "CGB":
			bankDictEnum = BankDictEnum.CGB;
			break;
		case "PAB":
			bankDictEnum = BankDictEnum.PAYH;
			break;
		case "CIB":
			bankDictEnum = BankDictEnum.CIB;
			break;
		case "BOB":
			bankDictEnum = BankDictEnum.BOB;
			break;
		case "BOS":
			bankDictEnum = BankDictEnum.BOSC;
			break;
		case "HXB":
			bankDictEnum = BankDictEnum.HXB;
			break;
		case "CMB":
			bankDictEnum = BankDictEnum.CMB;
			break;
		case "PSBC":
			bankDictEnum = BankDictEnum.PSBC;
			break;
		case "SPDB":
			bankDictEnum = BankDictEnum.SPDB;
			break;
		}
		return bankDictEnum;
	}

}
