package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordProcessAmountDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	/**金额*/
	private BigDecimal recordProcessMoney;
	/**期数*/
	private Integer recoreProcessLimit;

	/**服务费率*/
	private BigDecimal serviceProportion;
	/**最大产品利率*/
	private BigDecimal maxProductProportion;
	/**最小产品利率*/
	private BigDecimal minPorductProportion;
	/**产品名称*/
	private String productName;
	
	
	public BigDecimal getRecordProcessMoney() {
		return recordProcessMoney;
	}
	public void setRecordProcessMoney(BigDecimal recordProcessMoney) {
		this.recordProcessMoney = recordProcessMoney;
	}
	public Integer getRecoreProcessLimit() {
		return recoreProcessLimit;
	}
	public void setRecoreProcessLimit(Integer recoreProcessLimit) {
		this.recoreProcessLimit = recoreProcessLimit;
	}
	public BigDecimal getServiceProportion() {
		return serviceProportion;
	}
	public void setServiceProportion(BigDecimal serviceProportion) {
		this.serviceProportion = serviceProportion;
	}
	public BigDecimal getMaxProductProportion() {
		return maxProductProportion;
	}
	public void setMaxProductProportion(BigDecimal maxProductProportion) {
		this.maxProductProportion = maxProductProportion;
	}
	public BigDecimal getMinPorductProportion() {
		return minPorductProportion;
	}
	public void setMinPorductProportion(BigDecimal minPorductProportion) {
		this.minPorductProportion = minPorductProportion;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
}
