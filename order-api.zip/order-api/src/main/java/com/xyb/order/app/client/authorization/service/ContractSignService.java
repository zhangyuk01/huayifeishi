package com.xyb.order.app.client.authorization.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.authorization.model.QueryAgreementDTO;
import com.xyb.order.common.fdd.model.FddReturnInFoDTO;

/**
 * 签约相关接口
 * @author          xieqingyang
 * @date            2018/6/9 下午12:01
*/
public interface ContractSignService {

    /**
     * 个人信息查询、采集授权书签约
     * @author      xieqingyang
     * @date 2018/6/9 下午3:41
     * @version     1.0
     * @return      返回h5签约地址
     * @throws Exception 所有异常
     */
    RestResponse personalAuth()throws Exception;

    /**
     * 借款人声明函&委托扣款授权书、借款人服务协议签约
     * @author      xieqingyang
     * @date 2018/6/9 下午12:23
     * @version     1.0
     * @return      返回h5签约地址
     * @throws Exception 所有异常
     */
    RestResponse loanCol()throws Exception;

    /**
     * 查询合同
     * @author      xieqingyang
     * @date 2018/6/26 下午3:50
     * @version     1.0
     * @param queryAgreementDTO 传入参数
     * @return  页面所需数据
     * @throws Exception 所有异常
     */
    RestResponse queryAgreementInFo(QueryAgreementDTO queryAgreementDTO)throws Exception;


}
