package com.xyb.order.pc.contract.contracttb.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

public class ContractTbResultBodyDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2172823389211186174L;
	/**系统id*/
	@SignField(order = 2)
	private String sysId;
	/**items*/
	private List<ContractTbResultItemsDTO> items;
	public String getSysId() {
		return sysId;
	}
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	public List<ContractTbResultItemsDTO> getItems() {
		return items;
	}
	public void setItems(List<ContractTbResultItemsDTO> items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "ContractTbResultBodyDTO [sysId=" + sysId + ", items=" + items + "]";
	}
}
