package com.xyb.order.app.client.authorization.model;


import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
* @description:    三方日志表
* @author:         xieqingyang
* @createDate:     2018/5/14 下午7:27
*/
public class ThreePartyAuthorizationLogDO implements IBaseModel {

    private static final long serivalVersionUID = 1L;

    @JsonIgnore
    private Long id;
    private Long applyId;
    /**三方类型 2873,聚信力运营商报告;2874,聚信力保单报告;2875,融360社保;2876,融360公积金;2877,融360简版人行;2878,算话人行报告*/
    @NotNull(message = "三方类型不能为空")
    private Long authorizationType;
    /**是否成功 2486:成功  2487：失败*/
    @NotNull(message = "是否成功不能为空")
    private Long isSuccess;
    private String result;
    @JsonIgnore
    private Date createTime;
    @JsonIgnore
    private Long createUser;

    public long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getAuthorizationType() {
        return authorizationType;
    }

    public void setAuthorizationType(Long authorizationType) {
        this.authorizationType = authorizationType;
    }

    public Long getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(Long isSuccess) {
        this.isSuccess = isSuccess;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }
}
