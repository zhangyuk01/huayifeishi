package com.xyb.order.pc.contract.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 合同分配service
 * @createDate : 2018/5/02 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractAllocationService {

	RestResponse listContract(Integer pageNumber, Integer pageSize,XybContractQueryDTO xybContractQueryDTO) ;
	
	RestResponse updateContract(XybContractDetailDTO xybContractDetailDTO) ;
	
	RestResponse allocationContract(XybContractAllocationDTO xybContractAllocationDTO) ;
}
