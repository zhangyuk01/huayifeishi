package com.xyb.order.pc.outbound.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class OutBoundAlreadyListExportVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 78717020163558387L;

	/**申请编号*/
	private String applyNum;
	/**进件机构名称*/
	private String orgName;
	/**客户姓名*/
	private String custName;
	/**手机号码*/
	private String phone;
	/**销售团队*/
	private String saleTeamName;
	/**团队经理*/
	private String teamManagerName;
	/**销售人员*/
	private String saleName;
	/**推荐人姓名*/
	private String recommender;
	/**申请产品*/
	private String applyProductName;
	/**一级授信产品*/
	private String auditEndProductName;
	/**外访类型*/
	private String visitTypeName;
	/**外访返回时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date visitBackDate;
	/**实地外访时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date creditDate;
	/**产调外访时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date visitIndustryDate;
	/**征信负责人*/
	private String visitUidName;
	/**合同生效日期*/
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date contractEffectDate;
	/**合同状态*/
	private String contractState;
	@JsonIgnore
	private Integer stateCode;
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSaleTeamName() {
		return saleTeamName;
	}
	public void setSaleTeamName(String saleTeamName) {
		this.saleTeamName = saleTeamName;
	}
	public String getTeamManagerName() {
		return teamManagerName;
	}
	public void setTeamManagerName(String teamManagerName) {
		this.teamManagerName = teamManagerName;
	}
	public String getSaleName() {
		return saleName;
	}
	public void setSaleName(String saleName) {
		this.saleName = saleName;
	}
	public String getApplyProductName() {
		return applyProductName;
	}
	public void setApplyProductName(String applyProductName) {
		this.applyProductName = applyProductName;
	}
	public String getAuditEndProductName() {
		return auditEndProductName;
	}
	public void setAuditEndProductName(String auditEndProductName) {
		this.auditEndProductName = auditEndProductName;
	}
	public String getVisitTypeName() {
		return visitTypeName;
	}
	public void setVisitTypeName(String visitTypeName) {
		this.visitTypeName = visitTypeName;
	}
	public Date getVisitBackDate() {
		return visitBackDate;
	}
	public void setVisitBackDate(Date visitBackDate) {
		this.visitBackDate = visitBackDate;
	}
	public Date getCreditDate() {
		return creditDate;
	}
	public void setCreditDate(Date creditDate) {
		this.creditDate = creditDate;
	}
	public Date getVisitIndustryDate() {
		return visitIndustryDate;
	}
	public void setVisitIndustryDate(Date visitIndustryDate) {
		this.visitIndustryDate = visitIndustryDate;
	}
	public String getVisitUidName() {
		return visitUidName;
	}
	public void setVisitUidName(String visitUidName) {
		this.visitUidName = visitUidName;
	}
	public Date getContractEffectDate() {
		return contractEffectDate;
	}
	public void setContractEffectDate(Date contractEffectDate) {
		this.contractEffectDate = contractEffectDate;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public Integer getStateCode() {
		return stateCode;
	}
	public void setStateCode(Integer stateCode) {
		this.stateCode = stateCode;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	@Override
	public String toString() {
		return "OutBoundAlreadyListExportVO{" +
				"applyNum='" + applyNum + '\'' +
				", orgName='" + orgName + '\'' +
				", custName='" + custName + '\'' +
				", phone='" + phone + '\'' +
				", saleTeamName='" + saleTeamName + '\'' +
				", teamManagerName='" + teamManagerName + '\'' +
				", saleName='" + saleName + '\'' +
				", recommender='" + recommender + '\'' +
				", applyProductName='" + applyProductName + '\'' +
				", auditEndProductName='" + auditEndProductName + '\'' +
				", visitTypeName='" + visitTypeName + '\'' +
				", visitBackDate=" + visitBackDate +
				", creditDate=" + creditDate +
				", visitIndustryDate=" + visitIndustryDate +
				", visitUidName='" + visitUidName + '\'' +
				", contractEffectDate=" + contractEffectDate +
				", contractState='" + contractState + '\'' +
				", stateCode=" + stateCode +
				'}';
	}
}
