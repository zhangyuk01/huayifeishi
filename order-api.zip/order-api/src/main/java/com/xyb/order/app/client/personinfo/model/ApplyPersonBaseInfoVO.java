package com.xyb.order.app.client.personinfo.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonBaseInfoVO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	private ApplyPersonBaseInfoDO applyPersonBaseInfoDO;
	private Integer applyAge;

	public ApplyPersonBaseInfoDO getApplyPersonBaseInfoDO() {
		return applyPersonBaseInfoDO;
	}
	public void setApplyPersonBaseInfoDO(ApplyPersonBaseInfoDO applyPersonBaseInfoDO) {
		this.applyPersonBaseInfoDO = applyPersonBaseInfoDO;
	}
	public Integer getApplyAge() {
		return applyAge;
	}
	public void setApplyAge(Integer applyAge) {
		this.applyAge = applyAge;
	}
}
