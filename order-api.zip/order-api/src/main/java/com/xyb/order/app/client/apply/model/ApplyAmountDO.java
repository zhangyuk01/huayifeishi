package com.xyb.order.app.client.apply.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyAmountDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private BigDecimal endMinAmount;//最低额度
	private BigDecimal endMaxAmount;//最高额度

	public BigDecimal getEndMinAmount() {
		return endMinAmount;
	}
	public void setEndMinAmount(BigDecimal endMinAmount) {
		this.endMinAmount = endMinAmount;
	}
	public BigDecimal getEndMaxAmount() {
		return endMaxAmount;
	}
	public void setEndMaxAmount(BigDecimal endMaxAmount) {
		this.endMaxAmount = endMaxAmount;
	}

}
