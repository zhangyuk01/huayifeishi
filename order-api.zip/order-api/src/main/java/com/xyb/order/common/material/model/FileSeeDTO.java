package com.xyb.order.common.material.model;

import com.beiming.kun.framework.model.IBaseModel;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @description:    查看图片传入参数
 * @author:         xieqingyang
 * @createDate:     2018/5/28 下午5:49
*/
public class FileSeeDTO implements IBaseModel {

    private static final long serialVersionUID = 592449764991047057L;

    /**申请单ID*/
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;
    /**查询图片类型*/
    @NotNull(message = "图片类型不能为空")
    private List<String> fileType;

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public List<String> getFileType() {
        return fileType;
    }

    public void setFileType(List<String> fileType) {
        this.fileType = fileType;
    }

    @Override
    public String toString() {
        return "FileSeeDTO{" +
                "applyId=" + applyId +
                ", fileType=" + fileType +
                '}';
    }
}
