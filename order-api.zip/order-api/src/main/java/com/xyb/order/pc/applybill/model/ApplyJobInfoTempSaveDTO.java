package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyJobInfoTempSaveDTO implements IBaseModel {
	private static final long serialVersionUID = 1L;

	private Long id; //id
	private Long applyId;//申请单ID
	private Long mainId; //申请主表ID
	private Long cusId;//客户ID
	private String compName;//单位名称
	private Long compAddresProvince;//单位地址省市
	private String compAddresProvinceStr;//单位地址省市
	private Long compAddresCity;
	private String compAddresCityStr;
	private Long compAddresArea;
	private String compAddresAreaStr;
	private String compAdress;//单位地址
	private String compAllAddress;//单位全地
	private String compDept; //所在部门
	private Long compDuty; //职务
	private String compTellArea;//单位电话区号
	private String compTell;//单位电话
	private String compAllTell;//单位区号+固号
	private Date compJoinDate;//入职日期年月日
	private Long compType;//单位性质
	private String compTypeStr;
	private Long staffAmount;//企业规模
	private String staffAmountStr;
	private Long industryType;//行业大类
	private Long industryCode;//行业代码 
	private Long jobsCode; //岗位代码
	private Long employeeType;//雇佣类型
	private String commZip;//单位编码
	private String post; //职务 
	private Long icbcResult;//单位工商查询结果
	private Long officeSpace;//办公场所
	private Long riskCategory;//行业风险类别
	private Long jobNature;//工作性质
	private Long share;//股份
	private Long isRegist;//企业是否注册
	private Double registMoney;//注册金额
	private Long jinpo;//是否有社保
	private Long jinpoRecord;// 社保记录状态
	private Long cpfRecord;//公积金记录状态
	private Long position;// 自雇人士身份
	private Double salary;//薪资收入
	private String salaryDelivery;//薪资发放日
	private Double otherIncome;//其他收入
	private Date registDate;//注册时间
	private Date modifyTime;//修改时间
	private Date createTime;//创建时间
	private Long createUser; //创建人
	private Long modifyUser;//修改人
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public Long getCompAddresProvince() {
		return compAddresProvince;
	}
	public void setCompAddresProvince(Long compAddresProvince) {
		this.compAddresProvince = compAddresProvince;
	}
	public String getCompAddresProvinceStr() {
		return compAddresProvinceStr;
	}
	public void setCompAddresProvinceStr(String compAddresProvinceStr) {
		this.compAddresProvinceStr = compAddresProvinceStr;
	}
	public Long getCompAddresCity() {
		return compAddresCity;
	}
	public void setCompAddresCity(Long compAddresCity) {
		this.compAddresCity = compAddresCity;
	}
	public String getCompAddresCityStr() {
		return compAddresCityStr;
	}
	public void setCompAddresCityStr(String compAddresCityStr) {
		this.compAddresCityStr = compAddresCityStr;
	}
	public Long getCompAddresArea() {
		return compAddresArea;
	}
	public void setCompAddresArea(Long compAddresArea) {
		this.compAddresArea = compAddresArea;
	}
	public String getCompAddresAreaStr() {
		return compAddresAreaStr;
	}
	public void setCompAddresAreaStr(String compAddresAreaStr) {
		this.compAddresAreaStr = compAddresAreaStr;
	}
	public String getCompAdress() {
		return compAdress;
	}
	public void setCompAdress(String compAdress) {
		this.compAdress = compAdress;
	}
	public String getCompAllAddress() {
		return compAllAddress;
	}
	public void setCompAllAddress(String compAllAddress) {
		this.compAllAddress = compAllAddress;
	}
	public String getCompDept() {
		return compDept;
	}
	public void setCompDept(String compDept) {
		this.compDept = compDept;
	}

	public Long getCompDuty() {
		return compDuty;
	}

	public void setCompDuty(Long compDuty) {
		this.compDuty = compDuty;
	}

	public String getCompTellArea() {
		return compTellArea;
	}
	public void setCompTellArea(String compTellArea) {
		this.compTellArea = compTellArea;
	}
	public String getCompTell() {
		return compTell;
	}
	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}
	public String getCompAllTell() {
		return compAllTell;
	}
	public void setCompAllTell(String compAllTell) {
		this.compAllTell = compAllTell;
	}
	public Date getCompJoinDate() {
		return compJoinDate;
	}
	public void setCompJoinDate(Date compJoinDate) {
		this.compJoinDate = compJoinDate;
	}
	public Long getCompType() {
		return compType;
	}
	public void setCompType(Long compType) {
		this.compType = compType;
	}
	public String getCompTypeStr() {
		return compTypeStr;
	}
	public void setCompTypeStr(String compTypeStr) {
		this.compTypeStr = compTypeStr;
	}
	public Long getStaffAmount() {
		return staffAmount;
	}
	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}
	public String getStaffAmountStr() {
		return staffAmountStr;
	}
	public void setStaffAmountStr(String staffAmountStr) {
		this.staffAmountStr = staffAmountStr;
	}
	public Long getIndustryType() {
		return industryType;
	}
	public void setIndustryType(Long industryType) {
		this.industryType = industryType;
	}
	public Long getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(Long industryCode) {
		this.industryCode = industryCode;
	}
	public Long getJobsCode() {
		return jobsCode;
	}
	public void setJobsCode(Long jobsCode) {
		this.jobsCode = jobsCode;
	}
	public Long getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(Long employeeType) {
		this.employeeType = employeeType;
	}
	public String getCommZip() {
		return commZip;
	}
	public void setCommZip(String commZip) {
		this.commZip = commZip;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public Long getIcbcResult() {
		return icbcResult;
	}
	public void setIcbcResult(Long icbcResult) {
		this.icbcResult = icbcResult;
	}
	public Long getOfficeSpace() {
		return officeSpace;
	}
	public void setOfficeSpace(Long officeSpace) {
		this.officeSpace = officeSpace;
	}
	public Long getRiskCategory() {
		return riskCategory;
	}
	public void setRiskCategory(Long riskCategory) {
		this.riskCategory = riskCategory;
	}
	public Long getJobNature() {
		return jobNature;
	}
	public void setJobNature(Long jobNature) {
		this.jobNature = jobNature;
	}
	public Long getShare() {
		return share;
	}
	public void setShare(Long share) {
		this.share = share;
	}
	public Long getIsRegist() {
		return isRegist;
	}
	public void setIsRegist(Long isRegist) {
		this.isRegist = isRegist;
	}
	public Double getRegistMoney() {
		return registMoney;
	}
	public void setRegistMoney(Double registMoney) {
		this.registMoney = registMoney;
	}
	public Long getJinpo() {
		return jinpo;
	}
	public void setJinpo(Long jinpo) {
		this.jinpo = jinpo;
	}
	public Long getJinpoRecord() {
		return jinpoRecord;
	}
	public void setJinpoRecord(Long jinpoRecord) {
		this.jinpoRecord = jinpoRecord;
	}
	public Long getCpfRecord() {
		return cpfRecord;
	}
	public void setCpfRecord(Long cpfRecord) {
		this.cpfRecord = cpfRecord;
	}
	public Long getPosition() {
		return position;
	}
	public void setPosition(Long position) {
		this.position = position;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Double getOtherIncome() {
		return otherIncome;
	}
	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}
	public Date getRegistDate() {
		return registDate;
	}
	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getSalaryDelivery() {
		return salaryDelivery;
	}
	public void setSalaryDelivery(String salaryDelivery) {
		this.salaryDelivery = salaryDelivery;
	}

	@Override
	public String toString() {
		return "ApplyJobInfoTempSaveDTO{" +
				"id=" + id +
				", applyId=" + applyId +
				", mainId=" + mainId +
				", cusId=" + cusId +
				", compName='" + compName + '\'' +
				", compAddresProvince=" + compAddresProvince +
				", compAddresProvinceStr='" + compAddresProvinceStr + '\'' +
				", compAddresCity=" + compAddresCity +
				", compAddresCityStr='" + compAddresCityStr + '\'' +
				", compAddresArea=" + compAddresArea +
				", compAddresAreaStr='" + compAddresAreaStr + '\'' +
				", compAdress='" + compAdress + '\'' +
				", compAllAddress='" + compAllAddress + '\'' +
				", compDept='" + compDept + '\'' +
				", compDuty=" + compDuty +
				", compTellArea='" + compTellArea + '\'' +
				", compTell='" + compTell + '\'' +
				", compAllTell='" + compAllTell + '\'' +
				", compJoinDate=" + compJoinDate +
				", compType=" + compType +
				", compTypeStr='" + compTypeStr + '\'' +
				", staffAmount=" + staffAmount +
				", staffAmountStr='" + staffAmountStr + '\'' +
				", industryType=" + industryType +
				", industryCode=" + industryCode +
				", jobsCode=" + jobsCode +
				", employeeType=" + employeeType +
				", commZip='" + commZip + '\'' +
				", post='" + post + '\'' +
				", icbcResult=" + icbcResult +
				", officeSpace=" + officeSpace +
				", riskCategory=" + riskCategory +
				", jobNature=" + jobNature +
				", share=" + share +
				", isRegist=" + isRegist +
				", registMoney=" + registMoney +
				", jinpo=" + jinpo +
				", jinpoRecord=" + jinpoRecord +
				", cpfRecord=" + cpfRecord +
				", position=" + position +
				", salary=" + salary +
				", salaryDelivery='" + salaryDelivery + '\'' +
				", otherIncome=" + otherIncome +
				", registDate=" + registDate +
				", modifyTime=" + modifyTime +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyUser=" + modifyUser +
				'}';
	}
}
