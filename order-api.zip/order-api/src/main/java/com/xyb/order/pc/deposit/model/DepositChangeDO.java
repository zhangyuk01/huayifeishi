package com.xyb.order.pc.deposit.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.validation.constraints.NotNull;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.model
 * @description : 资料变更审核操作参数
 * @createDate : 2018/06/29 16:06
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class DepositChangeDO implements IBaseModel {

    private static final long serialVersionUID = -8093207624584770581L;

    /**
     * id;id
     * state : 状态 3077-资料变更中 3079-完成
     * depositChangeTypeStr : 申请类型
     */
    @NotNull(message = "id不能为空!")
    private Long id;
    @NotNull(message = "状态不能为空!")
    private Long state;
    @NotNull(message = "手机号不能为空!")
    private String phone;
    private String depositChangeTypeStr;
    @JsonIgnore
    private Long operationUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public Long getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(Long operationUser) {
        this.operationUser = operationUser;
    }

    public String getDepositChangeTypeStr() {
        return depositChangeTypeStr;
    }

    public void setDepositChangeTypeStr(String depositChangeTypeStr) {
        this.depositChangeTypeStr = depositChangeTypeStr;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "DepositChangeDO{" +
                "id=" + id +
                ", state=" + state +
                ", operationUser=" + operationUser +
                ", depositChangeTypeStr=" + depositChangeTypeStr +
                ", phone=" + phone +
                '}';
    }
}
