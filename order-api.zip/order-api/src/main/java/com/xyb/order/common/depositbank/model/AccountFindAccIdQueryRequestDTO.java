package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 查询是否开通存管户请求数据
 * @author         xieqingyang
 * @date           2018/12/25 4:24 PM
*/
public class AccountFindAccIdQueryRequestDTO implements IBaseModel {

    private static final long serialVersionUID = -6795696163734418803L;

    /**系统ID 北京2001 深圳3001*/
    private Long sysId;
    /**证件号码 ，必填,18(位数)*/
    @SignField(order = 0)
    private String cert_no;
    /**交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面*/
    private String client;
    /**商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户*/
    private String custom;
    /**客户端ip*/
    private String client_ip;
    /**电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）*/
    private String client_service;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getCert_no() {
        return cert_no;
    }

    public void setCert_no(String cert_no) {
        this.cert_no = cert_no;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }

    public String getClient_ip() {
        return client_ip;
    }

    public void setClient_ip(String client_ip) {
        this.client_ip = client_ip;
    }

    public String getClient_service() {
        return client_service;
    }

    public void setClient_service(String client_service) {
        this.client_service = client_service;
    }

    @Override
    public String toString() {
        return "AccountFindAccIdQueryRequestDTO{" +
                "sysId=" + sysId +
                ", cert_no='" + cert_no + '\'' +
                ", client='" + client + '\'' +
                ", custom='" + custom + '\'' +
                ", client_ip='" + client_ip + '\'' +
                ", client_service='" + client_service + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountFindAccIdQueryRequestDTO that = (AccountFindAccIdQueryRequestDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(cert_no, that.cert_no) &&
                Objects.equals(client, that.client) &&
                Objects.equals(custom, that.custom) &&
                Objects.equals(client_ip, that.client_ip) &&
                Objects.equals(client_service, that.client_service);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, cert_no, client, custom, client_ip, client_service);
    }
}
