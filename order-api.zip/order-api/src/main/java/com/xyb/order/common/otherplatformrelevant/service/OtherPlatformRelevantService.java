package com.xyb.order.common.otherplatformrelevant.service;

import com.xyb.credit.common.model.CheatInterfaceLogDO;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import net.sf.json.JSONObject;
import java.util.Map;

/**
 * 和其他平台相关业务
 * @author         xieqingyang
 * @date           2018/10/19 5:41 PM
*/
public interface OtherPlatformRelevantService {

    /**
     * 添加未过审页面
     * @author      xieqingyang
     * @date        2018/10/19 5:42 PM
     * @version     1.0
     * @param primaryInfoId 主键ID
     * @param item 类型
     */
    void insertCheckItem(Long primaryInfoId, Integer item);

    /**
     * 组装提交风控数据
     * @author      xieqingyang
     * @date        2018/10/19 5:43 PM
     * @version     1.0
     * @param applyMainId 主表ID
     * @param state 单子所处状态
     * @return 返回组装后的数据
     */
    SystemAuditParamDTO getSystemAuditParam(Long applyMainId, Integer state);

    /**
     * 获取消息消费数据,如果没有插入数据
     * @author      xieqingyang
     * @date        2018/10/12 3:04 PM
     * @version     1.0
     * @param map 数据
     * @return 返回处理结果
     */
    Boolean getAndInsertMessageConsumeLog(Map<String, Object> map);

    /**
     * 接口日志添加
     * @author      xieqingyang
     * @date        2018/10/12 3:04 PM
     * @version     1.0
     * @param cheatInterfaceLogDO 添加数据
     */
    void addCheatInterfaceLog(CheatInterfaceLogDO cheatInterfaceLogDO);

    /**
     * 组装风险提报数据
     * @author      xieqingyang
     * @date        2018/10/12 3:04 PM
     * @version     1.0
     * @param mainId 主表ID
     * @param remark 风险提报内容
     * @param modifyUserId 操作人id
     * @param modifyUserName 操作人姓名
     * @return 返回组装好的数据
     */
    JSONObject getFxtbJson(Long mainId, String remark, Long modifyUserId, String modifyUserName);
}
