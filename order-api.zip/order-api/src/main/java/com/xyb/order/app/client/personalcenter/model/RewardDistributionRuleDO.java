package com.xyb.order.app.client.personalcenter.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 奖励分配规则
 * 
 * @author qiaoJinLong
 * @date 2018年9月19日
 */
public class RewardDistributionRuleDO implements IBaseModel {

	private static final long serialVersionUID = 2791777289470559001L;

	private Long id;

	private double totalRate;// 总奖励比例

	private double recommendRate;// 推荐奖励比例

	private double oneRecommendRate;// 一级用户推荐奖励比例

	private double twoRecommendRate;// 二级用户推荐奖励比例

	private double qualityRate;// 质保奖励比例

	private double oneQualityRate;// 一级用户质保奖励比例

	private double twoQualityRate;// 二级用户质保奖励比例

	private Long createUser;// 创建人

	private Date createTime;// 创建时间

	private Long modifyUser;// 修改人

	private Date modifyTime;// 修改时间

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getTotalRate() {
		return totalRate;
	}

	public void setTotalRate(double totalRate) {
		this.totalRate = totalRate;
	}

	public double getRecommendRate() {
		return recommendRate;
	}

	public void setRecommendRate(double recommendRate) {
		this.recommendRate = recommendRate;
	}

	public double getOneRecommendRate() {
		return oneRecommendRate;
	}

	public void setOneRecommendRate(double oneRecommendRate) {
		this.oneRecommendRate = oneRecommendRate;
	}

	public double getTwoRecommendRate() {
		return twoRecommendRate;
	}

	public void setTwoRecommendRate(double twoRecommendRate) {
		this.twoRecommendRate = twoRecommendRate;
	}

	public double getQualityRate() {
		return qualityRate;
	}

	public void setQualityRate(double qualityRate) {
		this.qualityRate = qualityRate;
	}

	public double getOneQualityRate() {
		return oneQualityRate;
	}

	public void setOneQualityRate(double oneQualityRate) {
		this.oneQualityRate = oneQualityRate;
	}

	public double getTwoQualityRate() {
		return twoQualityRate;
	}

	public void setTwoQualityRate(double twoQualityRate) {
		this.twoQualityRate = twoQualityRate;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	@Override
	public String toString() {
		return "RewardDistributionRuleDO [id=" + id + ", totalRate=" + totalRate + ", recommendRate=" + recommendRate
				+ ", oneRecommendRate=" + oneRecommendRate + ", twoRecommendRate=" + twoRecommendRate + ", qualityRate="
				+ qualityRate + ", oneQualityRate=" + oneQualityRate + ", twoQualityRate=" + twoQualityRate
				+ ", createUser=" + createUser + ", createTime=" + createTime + ", modifyUser=" + modifyUser
				+ ", modifyTime=" + modifyTime + "]";
	}

}
