package com.xyb.order.app.client.authorization.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.authorization.model.SuanHuaDTO;
import com.xyb.order.app.client.authorization.model.SuanHuaRegisterDTO;

/**
* @description:    算话认证接口
* @author:         xieqingyang
* @createDate:     2018/5/17 上午9:47
*/
public interface SuanHuaService {

    /**
    * 算话注册
    * @author      xieqingyang
    * @param dto
    * @return
    * @exception
    * @date        2018/5/17 下午3:42
    */
    RestResponse register(SuanHuaRegisterDTO dto)throws Exception;

    /**
    * 算话申请
    * @author      xieqingyang
    * @param suanHuaDTO
    * @return
    * @exception
    * @date        2018/5/17 下午3:42
    */
    RestResponse suanhuaPush(SuanHuaDTO suanHuaDTO)throws Exception ;

    /**
    * 算话提取报告
    * @author      xieqingyang
    * @param suanHuaDTO
    * @return
    * @exception
    * @date        2018/5/17 下午3:42
    */
    RestResponse invokExtractReport(SuanHuaDTO suanHuaDTO)throws Exception ;
}
