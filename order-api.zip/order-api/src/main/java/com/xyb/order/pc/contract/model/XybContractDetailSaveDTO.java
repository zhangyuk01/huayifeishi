package com.xyb.order.pc.contract.model;

import javax.validation.Valid;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractDetailSaveDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1806578083712188015L;
	@Valid
	private XybContractDO xybContractDO;
	public XybContractDO getXybContractDO() {
		return xybContractDO;
	}
	public void setXybContractDO(XybContractDO xybContractDO) {
		this.xybContractDO = xybContractDO;
	}
	@Override
	public String toString() {
		return "XybContractDetailSaveDTO [xybContractDO=" + xybContractDO + "]";
	}

}
