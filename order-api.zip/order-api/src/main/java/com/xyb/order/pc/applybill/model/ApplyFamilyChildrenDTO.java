package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyFamilyChildrenDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private String id;
	private Integer age;
	private Long applyId;
	private Long delFlag;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(Long delFlag) {
		this.delFlag = delFlag;
	}
}
