package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.math.BigDecimal;

/**
 * 查询复议详细信息model
 * @author         xieqingyang
 * @date           2018/10/17 3:11 PM
*/
public class ReconsiderationInfoDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    /**主表ID*/
    private Long mainId;
    /**申请表id*/
    private Long applyId;
    /**申请编号*/
    private String applyNum;
    /**额度*/
    private BigDecimal amount = BigDecimal.ZERO;
    /**期限*/
    private Integer term = 0;
    /**客户姓名*/
    private String clientName;
    /**当前流程节点状态*/
    private Integer state;
    /**0 显示申请金额，申请期限  1 确认金额、终级授信期数 2 一级授信金额、一级授信期限*/
    private String isRefuse;
    /**复议次数*/
    private Integer reconsiderationQty;
    /**复议审核*/
    private String reconsiderState;
    /**历史复议目标*/
    private String reconsiderTarget;
    /**历史复议申请*/
    private String reconsiderRemark;

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getIsRefuse() {
        return isRefuse;
    }

    public void setIsRefuse(String isRefuse) {
        this.isRefuse = isRefuse;
    }

    public Integer getReconsiderationQty() {
        return reconsiderationQty;
    }

    public void setReconsiderationQty(Integer reconsiderationQty) {
        this.reconsiderationQty = reconsiderationQty;
    }

    public String getReconsiderState() {
        return reconsiderState;
    }

    public void setReconsiderState(String reconsiderState) {
        this.reconsiderState = reconsiderState;
    }

    public String getReconsiderTarget() {
        return reconsiderTarget;
    }

    public void setReconsiderTarget(String reconsiderTarget) {
        this.reconsiderTarget = reconsiderTarget;
    }

    public String getReconsiderRemark() {
        return reconsiderRemark;
    }

    public void setReconsiderRemark(String reconsiderRemark) {
        this.reconsiderRemark = reconsiderRemark;
    }

    @Override
    public String toString() {
        return "ReconsiderationInfoDO{" +
                "mainId=" + mainId +
                ", applyId=" + applyId +
                ", applyNum='" + applyNum + '\'' +
                ", amount=" + amount +
                ", term=" + term +
                ", clientName='" + clientName + '\'' +
                ", state=" + state +
                ", isRefuse='" + isRefuse + '\'' +
                ", reconsiderationQty=" + reconsiderationQty +
                ", reconsiderState='" + reconsiderState + '\'' +
                ", reconsiderTarget='" + reconsiderTarget + '\'' +
                ", reconsiderRemark='" + reconsiderRemark + '\'' +
                '}';
    }
}
