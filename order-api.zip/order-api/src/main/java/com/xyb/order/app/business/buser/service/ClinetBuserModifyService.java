package com.xyb.order.app.business.buser.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePhoneDTO;

/**
 * @ClassName ClinetBuserModifyService
 * @author ZhangYu
 * @date 2018年6月25号
 */

public interface ClinetBuserModifyService {
	
	/**
	 * 修改手机号 
	 * @param clientUserUpdatePhoneDTO
	 * @return
	 * @throws Exception
	 */
    RestResponse updatePhone(ClientUserUpdatePhoneDTO clientUserUpdatePhoneDTO)throws Exception;
    
    /**
     * 修改密码 
     * @return
     * @throws Exception
     */
    RestResponse updatePassword(ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO) throws Exception;
    
    /**
     * 忘记密码 
     * @param clientUserDTO
     * @return
     * @throws Exception
     */
    RestResponse forgetPassword(ClientUserUpdateDTO clientUserDTO)throws Exception;

}
