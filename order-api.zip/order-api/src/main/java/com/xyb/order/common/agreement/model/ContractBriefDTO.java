package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 响应模型包含类型
 * @author         xieqingyang
 * @date           2018/10/18 5:12 PM
*/
public class ContractBriefDTO implements IBaseModel {

    private static final long serialVersionUID = 6881293934128611862L;
    /**下载地址*/
    private String download_url;
    /**pdf查看地址*/
    private String viewpdf_url;

    public String getDownload_url() {
        return download_url;
    }

    public void setDownload_url(String download_url) {
        this.download_url = download_url;
    }

    public String getViewpdf_url() {
        return viewpdf_url;
    }

    public void setViewpdf_url(String viewpdf_url) {
        this.viewpdf_url = viewpdf_url;
    }

    @Override
    public String toString() {
        return "ContractBriefDTO{" +
                "download_url='" + download_url + '\'' +
                ", viewpdf_url='" + viewpdf_url + '\'' +
                '}';
    }
}
