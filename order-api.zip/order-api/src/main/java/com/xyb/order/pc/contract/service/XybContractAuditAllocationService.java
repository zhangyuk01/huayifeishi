package com.xyb.order.pc.contract.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 合同审核重新分配service
 * @createDate : 2018/5/02 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractAuditAllocationService {

	RestResponse listContractAudit(Integer pageNumber, Integer pageSize,XybContractAuditQueryDTO xybContractAuditQueryDTO) ;
	
	RestResponse updateContractAudit(XybContractAuditDetailDTO xybContractAuditDetailDTO) ;
	
	RestResponse allocationContract(XybContractAllocationDTO xybContractAllocationDTO) ;

}
