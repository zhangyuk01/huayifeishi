package com.xyb.order.pc.contract.model.newrepaymentplan;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import my.comp.lang.math.Num;
import my.comp.lang.math.NumberUtils;

/**
 * 等额本息
 * 
 * @author Firefly 2016年9月2日
 */
public class DEBXRefundStrategy {

	public RefundPlan generate(Date sdate, int months, int days, BigDecimal transAmt, BigDecimal yearRate, BigDecimal addRate, BigDecimal feeRate, Object... args) {
		RefundPlan refundPlan = new RefundPlan(sdate, yearRate);
		refundPlan.setRefunds(bulidRefundUnits(yearRate, addRate, months, days, transAmt, sdate));
		return refundPlan;
	}

	public List<RefundUnit> bulidRefundUnits(BigDecimal yearRate, BigDecimal addRate, int months, int days, BigDecimal contractAmount, Date itime) {
		return bulidRefundUnits(yearRate, addRate, null, months, days, contractAmount, itime) ;
	}
	
	protected List<RefundUnit> bulidRefundUnits(BigDecimal rate, BigDecimal addRate, BigDecimal feeRate, int months, int days, BigDecimal money, Date itime) {
		if (addRate == null) addRate = BigDecimal.ZERO;

		List<RefundUnit> ret = new ArrayList<RefundUnit>();
		// 借款人回款
		BigDecimal monthRate = feeRate!=null || NumberUtils.gtZero(feeRate)?rate:this.monRate(rate);
		int monthes2Return = months;
		// 合同金额
		BigDecimal contractAmount = feeRate!=null || NumberUtils.gtZero(feeRate)?money.multiply(BigDecimal.ONE.add(feeRate!=null?feeRate.multiply(new BigDecimal(monthes2Return)):BigDecimal.ZERO)).setScale(2, RoundingMode.HALF_UP):money ;
		// (1+月利率)^合同期限，用于分子
		BigDecimal middle1 = monthRate.add(BigDecimal.ONE).pow(monthes2Return).setScale(10, BigDecimal.ROUND_HALF_UP);
		// ((1+月利率)^合同期限-1)，用于分母
		BigDecimal middle2 = middle1.subtract(BigDecimal.ONE);
		// 每期应还本息总额=合同金额*月利率*(1+月利率)^合同期限/((1+月利率)^合同期限-1)，四舍五入保留两位小数
		BigDecimal everyMonthMoney = contractAmount.multiply(monthRate).multiply(middle1).divide(middle2, 10, BigDecimal.ROUND_DOWN).setScale(2, RoundingMode.HALF_UP) ;
		BigDecimal leftPrincipal = contractAmount; // 剩余本金

		// 供最后一笔调帐使用
		BigDecimal monthTotalMoney = BigDecimal.ZERO;
		BigDecimal monthTotalInterest = BigDecimal.ZERO;

		// 做子回款单元
		for (int i = 1; i <= monthes2Return; i++) {

			if (i == monthes2Return) {
				// 处理最后一期
				Date ptime = getIndexRefundDay(itime, i); // 还款时间
				
				
				
				
				// 每月本金（合同金额-已还本金）
				BigDecimal principal = contractAmount.subtract(monthTotalMoney); 
				
				//如最后一期应还本金大于每期应还本息，则最后一期应还本息=最后一期应还本金
				if(NumberUtils.gt(principal, everyMonthMoney)) everyMonthMoney = principal;

				BigDecimal everyMonthInterest = everyMonthMoney.subtract(principal); 
				
				// 每月利息（每月应还本息-每月本金）
				leftPrincipal = leftPrincipal.subtract(principal);
				//加息收益 = 上期末剩余本金(本期本金+本期剩余本金)*加息利息 /12
				BigDecimal addInterest = (principal.add(leftPrincipal).multiply(addRate)).divide(new BigDecimal("12"), 2, RoundingMode.DOWN) ;
				RefundUnit unitLoan = new RefundUnit(ptime,ptime,ptime, principal, everyMonthInterest, leftPrincipal, addInterest);
				ret.add(unitLoan); // 添加还款计划

			} else {

				Date ptime = getIndexRefundDay(itime, i); // 还款时间
				
				
				BigDecimal middle3 = monthRate.add(BigDecimal.ONE).pow(i-1).setScale(10, BigDecimal.ROUND_HALF_UP);
				//每月本金(合同金额*月利率*（1+月利率）^(当前期数-1）/((1+月利率)^合同期限-1)，四舍五入保留两位小数)
				BigDecimal principal = contractAmount.multiply(monthRate).multiply(middle3).divide(middle2, 10, BigDecimal.ROUND_DOWN).setScale(2, RoundingMode.DOWN) ;
				// 每月利息
				BigDecimal everyMonthInterest = everyMonthMoney.subtract(principal); 
				// 累加每月本金
				monthTotalMoney = monthTotalMoney.add(principal);
				monthTotalInterest = monthTotalInterest.add(everyMonthInterest);
				leftPrincipal = leftPrincipal.subtract(principal);
				//加息收益 = 上期末剩余本金(本期本金+本期剩余本金)*加息利息 /12
				BigDecimal addInterest = (principal.add(leftPrincipal).multiply(addRate)).divide(new BigDecimal("12"), 2, RoundingMode.DOWN) ;
				RefundUnit unitLoan = new RefundUnit(ptime,ptime,ptime, principal, everyMonthInterest, leftPrincipal, addInterest);
				ret.add(unitLoan);// 添加还款计划
			}

		}

		return ret;
	}
	private Date getIndexRefundDay(Date d, int i) {

		Calendar ca = Calendar.getInstance();
		ca.setTime(d);
		ca.add(Calendar.MONTH, i);
		ca.set(Calendar.HOUR_OF_DAY, 23);
		ca.set(Calendar.MINUTE, 59);
		ca.set(Calendar.SECOND, 59);
		return ca.getTime();

	}
	
	private BigDecimal monRate(BigDecimal yearRate) {
		return Num.create(yearRate).div(RefundUtils.D12, RefundUtils.SCALE_TEMP, RoundingMode.FLOOR).bigValue();
	}
	// 结果和银行贷款计算器进行比对
	public static void main(String args[]) throws Exception{

		DEBXRefundStrategy o = new DEBXRefundStrategy();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		List<RefundUnit> tests = o.bulidRefundUnits(new BigDecimal("0.15"), new BigDecimal("0.00"), 12, 0,
				new BigDecimal("50000"),simpleDateFormat.parse("2016-05-30"));

		for (RefundUnit unit : tests) {
			System.out.println(unit.toString());

		}

	}

}
