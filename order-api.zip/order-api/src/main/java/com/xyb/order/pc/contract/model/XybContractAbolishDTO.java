package com.xyb.order.pc.contract.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractAbolishDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3848571572171135150L;
	@NotNull(message = "申请id不能为空")
	private long applyId;
	/**合同废除原因*/
	@NotEmpty(message = "合同废除原因不能为空")
	private String contractAbolition;
	/**合同废除备注*/
	private String remarks;
	public long getApplyId() {
		return applyId;
	}
	public void setApplyId(long applyId) {
		this.applyId = applyId;
	}
	public String getContractAbolition() {
		return contractAbolition;
	}
	public void setContractAbolition(String contractAbolition) {
		this.contractAbolition = contractAbolition;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "XybContractAbolishDTO [applyId=" + applyId + ", contractAbolition=" + contractAbolition + ", remarks="
				+ remarks + "]";
	}

}
