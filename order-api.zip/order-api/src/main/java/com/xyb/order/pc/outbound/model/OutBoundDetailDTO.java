package com.xyb.order.pc.outbound.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访detailDTO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final Long serialVersionUID = 5239930524722349851L;
	/**申请编号*/
	@NotNull(message = "applyId不能为空")
	private Long applyId;

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Override
	public String toString() {
		return "OutBoundDetailDTO [applyId=" + applyId + "]";
	}
}
