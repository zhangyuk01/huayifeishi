package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.common.currency.model
 * @description : 系统参数配置DO
 * @createDate : 2018/5/15 17:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ParameterDO implements IBaseModel {



    /**
	 * 
	 */
	private static final long serialVersionUID = 6104015253419262201L;
	/**
     * id
     * parameterCode 参数码
     * parameterValue 参数值
     * parameterDesc 参数描述
     */
    private Long id;
    private String parameterCode;
    private String parameterValue;
    private String parameterDesc;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getParameterCode() {
        return parameterCode;
    }

    public void setParameterCode(String parameterCode) {
        this.parameterCode = parameterCode;
    }

    public String getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    public String getParameterDesc() {
        return parameterDesc;
    }

    public void setParameterDesc(String parameterDesc) {
        this.parameterDesc = parameterDesc;
    }

    @Override
    public String toString() {
        return "ParameterDTO{" +
                "id=" + id +
                ", parameterCode='" + parameterCode + '\'' +
                ", parameterValue='" + parameterValue + '\'' +
                ", parameterDesc='" + parameterDesc + '\'' +
                '}';
    }


}
