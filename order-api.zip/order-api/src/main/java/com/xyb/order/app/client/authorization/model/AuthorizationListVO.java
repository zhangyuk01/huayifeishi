package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

/**
* app授权产品列表
* @author       xieqingyang
* @date         2018/5/14 下午7:29
*/
public class AuthorizationListVO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**主表ID*/
    private Long mainId;
    /**申请单ID*/
    private Long applyId;
    /**手机号*/
    private String phone;
    /**借款产品*/
    private String productName;
    /**借款产品id*/
    private Long productId;
    /**借款金额*/
    private String expectMoney;
    /**借款期限*/
    private String expectTerm;
    /**申请时间*/
    private String applyTime;
    /**授权相关*/
    private List<AuthorizationResultVO> authorizationResultVOS;
    @JsonIgnore
    /**中转数据 营业部ID*/
    private Long storeOrgId;

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getExpectMoney() {
        return expectMoney;
    }

    public void setExpectMoney(String expectMoney) {
        this.expectMoney = expectMoney;
    }

    public String getExpectTerm() {
        return expectTerm;
    }

    public void setExpectTerm(String expectTerm) {
        this.expectTerm = expectTerm;
    }

    public String getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(String applyTime) {
        this.applyTime = applyTime;
    }

    public List<AuthorizationResultVO> getAuthorizationResultVOS() {
        return authorizationResultVOS;
    }

    public void setAuthorizationResultVOS(List<AuthorizationResultVO> authorizationResultVOS) {
        this.authorizationResultVOS = authorizationResultVOS;
    }

    public Long getStoreOrgId() {
        return storeOrgId;
    }

    public void setStoreOrgId(Long storeOrgId) {
        this.storeOrgId = storeOrgId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "AuthorizationListVO{" +
                "mainId=" + mainId +
                ", applyId=" + applyId +
                ", phone='" + phone + '\'' +
                ", productName='" + productName + '\'' +
                ", productId=" + productId +
                ", expectMoney='" + expectMoney + '\'' +
                ", expectTerm='" + expectTerm + '\'' +
                ", applyTime='" + applyTime + '\'' +
                ", authorizationResultVOS=" + authorizationResultVOS +
                ", storeOrgId=" + storeOrgId +
                '}';
    }
}