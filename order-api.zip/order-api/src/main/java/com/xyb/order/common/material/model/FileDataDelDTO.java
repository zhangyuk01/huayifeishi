package com.xyb.order.common.material.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @description:    删除图片传入参数
 * @author:         xieqingyang
 * @createDate:     2018/5/30 下午4:07
*/
public class FileDataDelDTO implements IBaseModel {

    private static final long serialVersionUID = -2130899737825936837L;
    /**图片ID集合*/
    @NotNull(message = "图片ID不能为空")
    private List<Long> list;
    /**图片类型*/
    @NotEmpty(message = "图片类型不能为空")
    private String type;
    /**申请单ID*/
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;
    /**修改人ID*/
    @JsonIgnore
    private Long userId;

    public List<Long> getList() {
        return list;
    }

    public void setList(List<Long> list) {
        this.list = list;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "FileDataDelDTO{" +
                "list=" + list +
                ", type='" + type + '\'' +
                ", applyId=" + applyId +
                ", userId=" + userId +
                '}';
    }
}
