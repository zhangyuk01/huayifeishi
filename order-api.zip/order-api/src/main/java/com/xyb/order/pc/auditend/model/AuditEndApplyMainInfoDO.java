/**
 * 
 */
package com.xyb.order.pc.auditend.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.auditend.model
 * @description : TODO
 * @createDate : 2018年12月25日 下午4:03:12
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
/**
 * @author xyb
 *
 */
public class AuditEndApplyMainInfoDO implements IBaseModel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * id
     * refuse : 是否拒贷
     * loanChannelId : 放款渠道
     * refuseCode : 拒贷码
     * refuseValue : 拒贷原因
     * agreeProductId : 批贷产品id
     * agreeProductName : 批贷产品
     * agreeProductLimit : 批贷期限
     * visitCount : 外访次数
     * agreeAmount : 批贷金额
     * serviceAmount : 服务费
     * loanMoney : 到账金额
     * contractMoney : 合同金额
     * endauditOverTime : 申请审批时间：终审批贷或拒贷时间
     * signCheck : 是否签约前核验
     * signCheckContent : 签约前核验类型
     * serviceProportionType : 率类型
     * policyCode : 政策码
     * consultFlag : 协商标志
     * consultContext : 协商内容
     * indeedCredit : 是否实地征信
     * indeedCreditContext : 实地征信内容
     * productProportion : 产品利率
     * serviceProportion : 服务费率
     * riskException : 风控系统异常信息
     * cheat : 是否欺诈（大类2692）
     */
    private Long id;
    private Long refuse;
    private Long loanChannelId;
    private String refuseCode;
    private String refuseValue;
    private Long agreeProductId;
    private String agreeProductName;
    private Integer agreeProductLimit;
    private Integer visitCount;
    private BigDecimal agreeAmount;
    private BigDecimal serviceAmount;
    private BigDecimal loanMoney;
    private BigDecimal contractMoney;
    private Date endauditOverTime;
    private Long signCheck;
    private String signCheckContent;
    private String serviceProportionType;
    private Long policyCode;
    private Long consultFlag;
    private String consultContext;
    private Long indeedCredit;
    private String indeedCreditContext;
    private BigDecimal productProportion;
    private BigDecimal serviceProportion;
    private String riskException;
    private Long cheat;
    private Long operationUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRefuse() {
        return refuse;
    }

    public void setRefuse(Long refuse) {
        this.refuse = refuse;
    }

    public Long getLoanChannelId() {
        return loanChannelId;
    }

    public void setLoanChannelId(Long loanChannelId) {
        this.loanChannelId = loanChannelId;
    }

    public String getRefuseCode() {
        return refuseCode;
    }

    public void setRefuseCode(String refuseCode) {
        this.refuseCode = refuseCode;
    }

    public String getRefuseValue() {
        return refuseValue;
    }

    public void setRefuseValue(String refuseValue) {
        this.refuseValue = refuseValue;
    }

    public Long getAgreeProductId() {
        return agreeProductId;
    }

    public void setAgreeProductId(Long agreeProductId) {
        this.agreeProductId = agreeProductId;
    }

    public String getAgreeProductName() {
        return agreeProductName;
    }

    public void setAgreeProductName(String agreeProductName) {
        this.agreeProductName = agreeProductName;
    }

    public Integer getAgreeProductLimit() {
        return agreeProductLimit;
    }

    public void setAgreeProductLimit(Integer agreeProductLimit) {
        this.agreeProductLimit = agreeProductLimit;
    }

    public BigDecimal getAgreeAmount() {
        return agreeAmount;
    }

    public void setAgreeAmount(BigDecimal agreeAmount) {
        this.agreeAmount = agreeAmount;
    }

    public Date getEndauditOverTime() {
        return endauditOverTime;
    }

    public void setEndauditOverTime(Date endauditOverTime) {
        this.endauditOverTime = endauditOverTime;
    }

    public Long getSignCheck() {
        return signCheck;
    }

    public void setSignCheck(Long signCheck) {
        this.signCheck = signCheck;
    }

    public String getSignCheckContent() {
        return signCheckContent;
    }

    public void setSignCheckContent(String signCheckContent) {
        this.signCheckContent = signCheckContent;
    }

    public String getServiceProportionType() {
        return serviceProportionType;
    }

    public void setServiceProportionType(String serviceProportionType) {
        this.serviceProportionType = serviceProportionType;
    }

    public Long getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(Long policyCode) {
        this.policyCode = policyCode;
    }

    public Long getConsultFlag() {
        return consultFlag;
    }

    public void setConsultFlag(Long consultFlag) {
        this.consultFlag = consultFlag;
    }

    public String getConsultContext() {
        return consultContext;
    }

    public void setConsultContext(String consultContext) {
        this.consultContext = consultContext;
    }

    public Long getIndeedCredit() {
        return indeedCredit;
    }

    public void setIndeedCredit(Long indeedCredit) {
        this.indeedCredit = indeedCredit;
    }

    public String getIndeedCreditContext() {
        return indeedCreditContext;
    }

    public void setIndeedCreditContext(String indeedCreditContext) {
        this.indeedCreditContext = indeedCreditContext;
    }

    public BigDecimal getProductProportion() {
        return productProportion;
    }

    public void setProductProportion(BigDecimal productProportion) {
        this.productProportion = productProportion;
    }

    public BigDecimal getServiceProportion() {
        return serviceProportion;
    }

    public void setServiceProportion(BigDecimal serviceProportion) {
        this.serviceProportion = serviceProportion;
    }

    public String getRiskException() {
        return riskException;
    }

    public void setRiskException(String riskException) {
        this.riskException = riskException;
    }

    public Long getCheat() {
        return cheat;
    }

    public void setCheat(Long cheat) {
        this.cheat = cheat;
    }

    public Long getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(Long operationUser) {
        this.operationUser = operationUser;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public BigDecimal getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(BigDecimal serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    public BigDecimal getLoanMoney() {
        return loanMoney;
    }

    public void setLoanMoney(BigDecimal loanMoney) {
        this.loanMoney = loanMoney;
    }

    public BigDecimal getContractMoney() {
        return contractMoney;
    }

    public void setContractMoney(BigDecimal contractMoney) {
        this.contractMoney = contractMoney;
    }

    @Override
    public String toString() {
        return "AuditEndApplyMainInfoDO{" +
                "id=" + id +
                ", refuse=" + refuse +
                ", loanChannelId=" + loanChannelId +
                ", refuseCode='" + refuseCode + '\'' +
                ", refuseValue='" + refuseValue + '\'' +
                ", agreeProductId=" + agreeProductId +
                ", agreeProductName='" + agreeProductName + '\'' +
                ", agreeProductLimit=" + agreeProductLimit +
                ", visitCount=" + visitCount +
                ", agreeAmount=" + agreeAmount +
                ", contractMoney=" + contractMoney +
                ", serviceAmount=" + serviceAmount +
                ", loanMoney=" + loanMoney +
                ", endauditOverTime=" + endauditOverTime +
                ", signCheck=" + signCheck +
                ", signCheckContent='" + signCheckContent + '\'' +
                ", serviceProportionType='" + serviceProportionType + '\'' +
                ", policyCode=" + policyCode +
                ", consultFlag=" + consultFlag +
                ", consultContext='" + consultContext + '\'' +
                ", indeedCredit=" + indeedCredit +
                ", indeedCreditContext='" + indeedCreditContext + '\'' +
                ", productProportion=" + productProportion +
                ", serviceProportion=" + serviceProportion +
                ", riskException=" + riskException +
                ", cheat=" + cheat +
                ", operationUser=" + operationUser +
                '}';
    }
}
