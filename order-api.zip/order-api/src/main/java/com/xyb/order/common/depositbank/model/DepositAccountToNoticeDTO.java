package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.common.depositbank.model
 * @description : 个人绑卡注册通知 参数model
 * @createDate : 2018/11/26 10:44
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class DepositAccountToNoticeDTO implements IBaseModel {
    private static final long serialVersionUID = 2088309317042807722L;


    /**
     * cert_type : 证件类型
     * cert_no : 证件号码
     * name : 姓名
     * card_no : 电子账户
     * customer_no : 客户号（开户返回的客户号）
     * serial_no : 三方绑定编号(绑卡是返回的编号，解绑的时候要根据这个绑定编号解绑)
     * bank_card_no : 银行卡号
     * mobile : 手机号
     * account_type : 账户类型
     * ran_amount : 企业户开户成功后必须激活
     * out_serial_no : 申请流水号
     * service : 交易代码
     * bank_name : 银行名称
     * bank_no : 银行编码
     * rsp_code : 返回响应码
     * acctId : 资产账户ID
     */
    @SignField(order = 2)
    private String cert_type;
    @SignField(order = 3)
    @NotEmpty(message = "cert_no不能为空!")
    private String cert_no;
    @NotEmpty(message = "name不能为空!")
    private String name;
    @SignField(order = 4)
    @NotEmpty(message = "card_no不能为空!")
    private String card_no;
    @NotEmpty(message = "customer_no不能为空!")
    private String customer_no;
    @NotEmpty(message = "serial_no不能为空!")
    private String serial_no;
    @NotEmpty(message = "bank_card_no不能为空!")
    private String bank_card_no;
    @NotEmpty(message = "mobile不能为空!")
    private String mobile;
    private String account_type;
    private String ran_amount;
    private String out_serial_no;
    private String service;
    @NotEmpty(message = "bank_name不能为空!")
    private String bank_name;
    @NotEmpty(message = "bank_no不能为空!")
    private String bank_no;
    private String rsp_code;
    @NotEmpty(message = "acctId不能为空!")
    private String acctId;

    public String getCert_type() {
        return cert_type;
    }

    public void setCert_type(String cert_type) {
        this.cert_type = cert_type;
    }

    public String getCert_no() {
        return cert_no;
    }

    public void setCert_no(String cert_no) {
        this.cert_no = cert_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getSerial_no() {
        return serial_no;
    }

    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    public String getBank_card_no() {
        return bank_card_no;
    }

    public void setBank_card_no(String bank_card_no) {
        this.bank_card_no = bank_card_no;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getRan_amount() {
        return ran_amount;
    }

    public void setRan_amount(String ran_amount) {
        this.ran_amount = ran_amount;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getBank_no() {
        return bank_no;
    }

    public void setBank_no(String bank_no) {
        this.bank_no = bank_no;
    }

    public String getRsp_code() {
        return rsp_code;
    }

    public void setRsp_code(String rsp_code) {
        this.rsp_code = rsp_code;
    }

    public String getAcctId() {
        return acctId;
    }

    public void setAcctId(String acctId) {
        this.acctId = acctId;
    }

    @Override
    public String toString() {
        return "DepositAccountToNoticeDTO{" +
                "cert_type='" + cert_type + '\'' +
                ", cert_no='" + cert_no + '\'' +
                ", name='" + name + '\'' +
                ", card_no='" + card_no + '\'' +
                ", customer_no='" + customer_no + '\'' +
                ", serial_no='" + serial_no + '\'' +
                ", bank_card_no='" + bank_card_no + '\'' +
                ", mobile='" + mobile + '\'' +
                ", account_type='" + account_type + '\'' +
                ", ran_amount='" + ran_amount + '\'' +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", service='" + service + '\'' +
                ", bank_name='" + bank_name + '\'' +
                ", bank_no='" + bank_no + '\'' +
                ", rsp_code='" + rsp_code + '\'' +
                ", acctId='" + acctId + '\'' +
                '}';
    }
}
