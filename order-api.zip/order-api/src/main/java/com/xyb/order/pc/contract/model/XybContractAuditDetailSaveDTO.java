package com.xyb.order.pc.contract.model;

import javax.validation.Valid;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 进件合同审核详情暂存DTO model层
 * @createDate : 2018/3/28 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditDetailSaveDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4051967943938773853L;
	@Valid
	private XybContractAuditDO xybContractAuditDO;
	public XybContractAuditDO getXybContractAuditDO() {
		return xybContractAuditDO;
	}
	public void setXybContractAuditDO(XybContractAuditDO xybContractAuditDO) {
		this.xybContractAuditDO = xybContractAuditDO;
	}
	@Override
	public String toString() {
		return "XybContractAuditDetailSaveDTO [xybContractAuditDO=" + xybContractAuditDO + "]";
	}
	
}
