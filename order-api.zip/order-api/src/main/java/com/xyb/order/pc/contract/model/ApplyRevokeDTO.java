package com.xyb.order.pc.contract.model;


import com.beiming.kun.framework.model.IBaseModel;


public class ApplyRevokeDTO implements IBaseModel {

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	private ApplyRevokeDetailDTO body;
	
	private String sign;
	public ApplyRevokeDetailDTO getBody() {
		return body;
	}
	public void setBody(ApplyRevokeDetailDTO body) {
		this.body = body;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	@Override
	public String toString() {
		return "ApplyRevokeDTO [body=" + body + ", sign=" + sign + "]";
	}
	

}
