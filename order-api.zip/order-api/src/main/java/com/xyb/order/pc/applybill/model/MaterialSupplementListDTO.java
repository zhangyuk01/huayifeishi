package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Created by xieqingyang on 2018/4/25.
 * 材料补充列表数据
 */
public class MaterialSupplementListDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    @JsonIgnore
    private Page page = new Page();

    private String applyNum;// -- 申请编号
    private String clientName;// -- 客户姓名
    private String idCard;// -- 身份证号

    @JsonIgnore
    private Long servieUid;// -- 当前登录人ID
    @JsonIgnore
    private Integer state;// -- 查询的节点状态

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Long getServieUid() {
        return servieUid;
    }

    public void setServieUid(Long servieUid) {
        this.servieUid = servieUid;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }
}
