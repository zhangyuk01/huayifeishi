package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName :
 * @package : com.xyb.order.app.client.authorization.model
 * @description :
 * @createDate : 2018/9/25 16:44
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class TongLianLogDTO implements IBaseModel{

    private static final long serialVersionUID = -306378410949923473L;

    private Long id;

    private String name;

    private String idCard;

    private String code;

    private String result;

    private Date createTime;

    private String seralNo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSeralNo() {
        return seralNo;
    }

    public void setSeralNo(String seralNo) {
        this.seralNo = seralNo;
    }

    @Override
    public String toString() {
        return "TongLianLogDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", idCard='" + idCard + '\'' +
                ", code='" + code + '\'' +
                ", result='" + result + '\'' +
                ", createTime=" + createTime +
                ", seralNo='" + seralNo + '\'' +
                '}';
    }
}
