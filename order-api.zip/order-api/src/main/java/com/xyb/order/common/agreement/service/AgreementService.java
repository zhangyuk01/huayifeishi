package com.xyb.order.common.agreement.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.agreement.model.QueryLoanColResponseDTO;
import com.xyb.order.common.agreement.model.ResultDTO;

/**
 * 深圳查询协议接口
 * @author         xieqingyang
 * @date           2018/10/18 4:26 PM
*/
public interface AgreementService {

    /**
     * 深圳查询借款协议
     * @author      xieqingyang
     * @date        2018/10/18 5:44 PM
     * @version     1.0
     * @param applyId 申请ID
     * @return 返回深圳结果
     * @throws Exception 所有异常
     */
    ResultDTO<QueryLoanColResponseDTO> getContractAgreement(Long applyId) throws Exception;

    /**
     * 查询借款协议   本系统
     * @author      xieqingyang
     * @date        2018/10/18 6:05 PM
     * @version     1.0
     * @param applyId 申请单ID
     * @return 返回页面展示数据
     * @throws Exception 所有异常
     */
    RestResponse queryAgreements(Long applyId)throws Exception;
}
