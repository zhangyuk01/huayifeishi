/**
 * 
 */
package com.xyb.order.pc.contract.model.repaymentplan;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model.repaymentplan
 * @description : TODO
 * @createDate : 2018年8月29日 下午2:11:27
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractRepaymentPlanVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7768161069012429158L;
	/**期数*/
	private int productLimit;
	/**本金*/
	private BigDecimal capital;
	/**利息*/
	private BigDecimal interest;
	/**月还*/
	private BigDecimal monthReturn;
	/**一次性结清*/
	private BigDecimal returnAll;
	public int getProductLimit() {
		return productLimit;
	}
	public void setProductLimit(int productLimit) {
		this.productLimit = productLimit;
	}
	public BigDecimal getCapital() {
		return capital;
	}
	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}
	public BigDecimal getInterest() {
		return interest;
	}
	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}
	public BigDecimal getMonthReturn() {
		return monthReturn;
	}
	public void setMonthReturn(BigDecimal monthReturn) {
		this.monthReturn = monthReturn;
	}
	public BigDecimal getReturnAll() {
		return returnAll;
	}
	public void setReturnAll(BigDecimal returnAll) {
		this.returnAll = returnAll;
	}
	@Override
	public String toString() {
		return "XybContractRepaymentPlanVO [productLimit=" + productLimit + ", capital=" + capital + ", interest="
				+ interest + ", monthReturn=" + monthReturn + ", returnAll=" + returnAll + "]";
	}
	
}
