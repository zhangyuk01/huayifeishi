/*
 *  Copyright 2012, Tera-soft Co., Ltd.  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TERA-SOFT CO.,
 *  LTD.  THE CONTENTS OF THIS FILE MAY NOT BE DISCLOSED TO THIRD
 *  PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART,
 *  WITHOUT THE PRIOR WRITTEN PERMISSION OF TERA-SOFT CO., LTD
 *
 */
package com.xyb.order.common.constant;

/**
 * @author Tera
 *
 */
public class SysConstants {

	/**
	 * 登录用户名
	 */
	public static final String LOGIN_ID = "loginid";
	/**
	 * 登录用户
	 */
	public static final String LOGIN_USER = "login_user";
	/**
	 * 登录用户 当前所选机构
	 */
	//public static final String LOGIN_ORG = "login_org";

	/**
	 * 登录用户 当前所有连接权限
	 */
	public static final String LOGIN_MENUS = "login_menus";

	/**
	 * 登陆用户的IP
	 */
	public static final String LOGIN_IP = "login_ip";

	/**
	 * 每页原始记录条数
	 */
	public static final int PAGE_REC_COUNT = 10;

	
	//合同相关 缓存key名称前缀
//	public final static String CONTRACT = "contract_";
	//合同审核相关
//	public final static String CONTRACT_AUDIT ="contract_audit";
	//还款计划 缓存key名称前缀
	public final static String REPAYMENT_PLAN = "repayMentPlan_";

	
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_REPORT = "auditCredit_Report_";
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_PERSONAL = "auditCredit_Personal_";
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_COMPINFO = "auditCredit_CompInfo_";
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_CARDINFO = "auditCredit_CardInfo_";
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_DETAILINFO = "auditCredit_DetailInfo_";
	//申请单用户报告 缓存key名称前缀
	public final static String AUDIT_CREDIT_LOANINFO = "auditCredit_LoanInfo_";
	//初审调查记录 缓存key名称前缀
	public final static String AUDIT_PRIMARY_RECORD = "auditPrimary_Record_";
	//缓存时间
	public final static int CACHE_TIME = 1800;
	//催收逾期还款划扣 缓存key名称前缀
	public final static String CUISHOU_YUQI_HUAKOU = "cuishouYuqi_huakou_";
	//对公还款
	public final static String DUI_GONG = "2";
	//个人还款
	public final static String GE_REN = "1";
	
	/**成功标志*/
	public static final String INTERFACE_SUCCESS = "000";
	
	/**失败标志*/
	public static final String INTERFACE_FAIL = "999";
	
	/**不可签标识*/
	public static final String INTERFACE_NO_SIGN = "100";

	/**签名错误*/
	public static final String INTERFACE_SIGN_ERROR = "301";
	
	/**北京业务失败返回标志*/
	public static final String INTERFACE_FAIL_BJ = "998";
	
	/**code*/
	public static final String INTERFACE_CODE = "code";
	
	/**message*/
	public static final String INTERFACE_MESSAGE = "message";
	
	/**body*/
	public static final String INTERFACE_BODY = "body";

	/**state*/
	public static final String INTERFACE_STATE = "state";

	/**state*/
	public static final String INTERFACE_WAITCOUNT = "waitCount";

	/**《借款人声明函&委托扣款授权书》下载地址和查询地址*/
	public static final String LOANCOL_URL = "loanColUrl";
	/**《借款人服务协议》下载地址和查询地址*/
	public static final String LOANSERVICE_URL = "loanServiceUrl";
	/**《个人信息采集查询授权书》下载地址和查询地址 */
	public static final String AUTHORIZE_URL = "authorizeUrl";
	/**《借款协议》列表下载地址和查询地址 */
	public static final String LOAN_URL = "loanUrl";

	/**下载地址*/
	public static final String DOWNLOAD_URL = "download_url";
	/**查看地址*/
	public static final String VIEWPDF_URL = "viewpdf_url";

	public static String XYB = "12";//信用宝
	
    
    /************************* 账户类型 *********************************/
    public static final long PERSONAGE = 1; // 个人
    public static final long COMPANY = 2; // 对公
    
    /** 批次表、批次明细表状态  6 确认报盘 String类型*/
    public static final long QUERENBAOPANs = 6;// 确认报盘
    
    /**用户类型*/
    public static final String userTypeOne = "2"; //本地
    public static final String userTypeTwo = "3"; //存量
    
    /**合同签约第三方支付返回结果类型*/
    public static final String  CODEONE = "S";//成功
    public static final String  CODETWO = "F";//失败
    public static final String  CODETHREE = "I";//处理中
    public static final String  CODEFOUR = "E";//验证码错误
    public static final String  CODEFIVE = "O";//验证码超时
    
    /**交易终端*/
    public static final String APP = "00001"; //app端
    public static final String WEB = "00002"; //web端
    public static final String WECHAT = "00003"; //微信端
    public static final String COUNTER = "00004"; //柜面
    
    /**客户类型*/
    public static final String LENDER = "1"; //出借角色
    public static final String BORROWER = "2"; //借款角色
    public static final String COMP = "3"; //代偿角色
    
    /**
     * 1风控人工强制通过  2重新提交  3系统异常（只限同步操作）  4授权异常  5获取报告异常 
     */
    public static final String FLOW_STATE_01 = "1";
    public static final String FLOW_STATE_02 = "2";
    public static final String FLOW_STATE_03 = "3";
    public static final String FLOW_STATE_04 = "4";
    public static final String FLOW_STATE_05 = "5";
}
