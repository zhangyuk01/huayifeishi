package com.xyb.order.pc.contract.contracttb.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : finance-api
 * @package : com.xyb.loan.http.api.model
 * @description : 合同推标数据对象封装
 * @createDate : 2017/12/19 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ContractTbItemList implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7012922442508290550L;
	/**附件来源URL*/
	private String url;
	/**申请id,同上*/
	private String applyId;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	@Override
	public String toString() {
		return "ContractTbItemList [url=" + url + ", applyId=" + applyId + "]";
	}
	


}
