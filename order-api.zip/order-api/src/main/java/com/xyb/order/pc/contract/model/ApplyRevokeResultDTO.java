/**
 * 
 */
package com.xyb.order.pc.contract.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : TODO
 * @createDate : 2018年12月3日 下午4:03:56
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
/**
 * @author xyb
 *
 */
public class ApplyRevokeResultDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5856951232022432492L;
	/**签名字符串*/
	@SignField(order = 0)
	private String code;
	@SignField(order = 1)
	private String message;
	private ApplyRevokeResultBodyDTO body;
	private String sign;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ApplyRevokeResultBodyDTO getBody() {
		return body;
	}
	public void setBody(ApplyRevokeResultBodyDTO body) {
		this.body = body;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	@Override
	public String toString() {
		return "ApplyRevokeResultDTO [code=" + code + ", message=" + message + ", body=" + body + ", sign=" + sign
				+ "]";
	}

}
