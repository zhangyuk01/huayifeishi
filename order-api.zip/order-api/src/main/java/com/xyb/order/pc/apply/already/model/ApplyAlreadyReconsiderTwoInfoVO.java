package com.xyb.order.pc.apply.already.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 申请已办第二次复议申请记录信息
 * @createDate : 2018/06/05 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyReconsiderTwoInfoVO implements IBaseModel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2691287558172969888L;
	/**申请人*/
	private String applyName;
	/**申请时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	private Date applyTime;
	/**复议目标*/
	private String reconsiderTarget;
	/**复议申请备注*/
	private String reconsiderRemark;
	public String getApplyName() {
		return applyName;
	}
	public void setApplyName(String applyName) {
		this.applyName = applyName;
	}
	public Date getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}
	public String getReconsiderTarget() {
		return reconsiderTarget;
	}
	public void setReconsiderTarget(String reconsiderTarget) {
		this.reconsiderTarget = reconsiderTarget;
	}
	public String getReconsiderRemark() {
		return reconsiderRemark;
	}
	public void setReconsiderRemark(String reconsiderRemark) {
		this.reconsiderRemark = reconsiderRemark;
	}
	@Override
	public String toString() {
		return "ApplyAlreadyReconsiderOneInfoVO [applyName=" + applyName + ", applyTime=" + applyTime
				+ ", reconsiderTarget=" + reconsiderTarget + ", reconsiderRemark=" + reconsiderRemark + "]";
	}
	

}
