package com.xyb.order.pc.deposit.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;
import com.xyb.order.pc.deposit.model.DepositChangeDO;
import com.xyb.order.pc.deposit.model.DepositChangeDTO;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.service
 * @description : 存管服务APT
 * @createDate : 2018/06/29 15:23
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface DepositService {

    /**
     * 资料变更审核列表
     * @param pageNumber
     * @param pageSize
     * @param depositChangeDTO
     * @return
     */
    RestResponse depositChangePage(Integer pageNumber, Integer pageSize, DepositChangeDTO depositChangeDTO);

    /**
     * 资料变更审核操作
     * @param depositChangeDO
     * @return
     */
    RestResponse depositChangeOperation(DepositChangeDO depositChangeDO);

    /**
     * version资料变更审核列表(非存管)
     * @author      xieqingyang
     * @date 2018/7/20 下午6:57
     * @version     1.0
     * @param pageNumber 页码
     * @param pageSize 每页数量
     * @param depositChangeDTO 查询参数
     * @return 返回列表数据
     */
    RestResponse depositChangeNoPage(Integer pageNumber, Integer pageSize, DepositChangeDTO depositChangeDTO)throws Exception;

    /**
     * version资料变更审核操作(非存管)
     * @author      xieqingyang
     * @date 2018/7/20 下午6:57
     * @version     1.0
     * @param depositChangeDO 传入参数
     * @return 返回结果
     */
    RestResponse depositChangeOperationNo(DepositChangeDO depositChangeDO)throws Exception;

    /**
     * version签约协议完成后确认提交接口
     * @author      xieqingyang
     * @date 2018/7/20 下午10:12
     * @version     1.0
     * @param id 账户申请表ID
     * @return 返回结果
     * @throws Exception 所有异常
     */
    RestResponse submit(Long id)throws Exception;

    /**
     * version获取当前用户待绑卡渠道列表
     * @author      xieqingyang
     * @date 2018/7/23 下午1:46
     * @version     1.0
     * @param thirdPayBindDTO 传入参数
     * @return 结果
     */
    RestResponse getUserNotBindChannel(ThirdPayBindDTO thirdPayBindDTO)throws Exception;

    /**
     * version预绑卡
     * @author      xieqingyang
     * @date 2018/7/23 下午1:46
     * @version     1.0
     * @param thirdPayBindPreDTO 传入参数
     * @return 结果
     */
    RestResponse preBindCardEntrance(ThirdPayBindPreDTO thirdPayBindPreDTO)throws Exception;

    /**
     * version预绑卡--重发短信
     * @author      xieqingyang
     * @date 2018/7/23 下午1:46
     * @version     1.0
     * @param thirdPayBindPreResendDTO 传入参数
     * @return 结果
     */
    RestResponse resendMessage(ThirdPayBindPreResendDTO thirdPayBindPreResendDTO)throws Exception;

    /**
     * version确认绑卡
     * @author      xieqingyang
     * @date 2018/7/23 下午1:46
     * @version     1.0
     * @param thirdPayBindConfirmBianCardEntranceDTO 传入参数
     * @return 结果
     */
    RestResponse confirmBianCardEntrance(ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO)throws Exception;
}
