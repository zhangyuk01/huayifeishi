package com.xyb.order.pc.apply.already.model;


import java.util.Date;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.apply.already.model
 * @description : 申请已办查询DTO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyQueryDTO implements IBaseModel {

	private static final Long serialVersionUID = 5038832745460326371L;
	@JsonIgnore
	/**分页*/
    private Page page = new Page();
	/**申请已办查询菜单类型--A:客服专员  B:团队经理 C:客服经理 D:城市经理*/
	private String type;
	/**客户姓名*/
	private String custName;
	/**手机号码*/
	private String phone;
	/**身份证号*/
	private String idCard;
	/**进件开始日期*/
	private Date incomeStartTime;
	/**进件结束日期*/
	private Date incomeEndTime;
	/**审批开始日期*/
	private Date auditStartTime;
	/**审批结束日期*/
	private Date auditEndTime;
	/**申请产品*/
	private Long applyProductId;
	/**当前状态*/
	private String state;
	/**当前状态集*/
	private List<Integer> list;
	/**是否循环贷*/
	private Long isLoop;
	/**是否已结清*/
	private Long isSettle;
	/**还款日*/
	private String repayMentDay;
	/**进件机构*/
	private String orgId;
	/**当前登录账户(前端无需关注)*/
	private Long loginId;
	/**数据范围id*/
	@JsonIgnore
	private Long dataId;
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Date getIncomeStartTime() {
		return incomeStartTime;
	}
	public void setIncomeStartTime(Date incomeStartTime) {
		this.incomeStartTime = incomeStartTime;
	}
	public Date getIncomeEndTime() {
		return incomeEndTime;
	}
	public void setIncomeEndTime(Date incomeEndTime) {
		this.incomeEndTime = incomeEndTime;
	}
	public Date getAuditStartTime() {
		return auditStartTime;
	}
	public void setAuditStartTime(Date auditStartTime) {
		this.auditStartTime = auditStartTime;
	}
	public Date getAuditEndTime() {
		return auditEndTime;
	}
	public void setAuditEndTime(Date auditEndTime) {
		this.auditEndTime = auditEndTime;
	}
	public Long getApplyProductId() {
		return applyProductId;
	}
	public void setApplyProductId(Long applyProductId) {
		this.applyProductId = applyProductId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<Integer> getList() {
		return list;
	}
	public void setList(List<Integer> list) {
		this.list = list;
	}
	public Long getIsLoop() {
		return isLoop;
	}
	public void setIsLoop(Long isLoop) {
		this.isLoop = isLoop;
	}
	public Long getIsSettle() {
		return isSettle;
	}
	public void setIsSettle(Long isSettle) {
		this.isSettle = isSettle;
	}
	public String getRepayMentDay() {
		return repayMentDay;
	}
	public void setRepayMentDay(String repayMentDay) {
		this.repayMentDay = repayMentDay;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public Long getLoginId() {
		return loginId;
	}
	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}
	public Long getDataId() {
		return dataId;
	}
	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}
	@Override
	public String toString() {
		return "ApplyAlreadyQueryDTO [page=" + page + ", type=" + type + ", custName=" + custName + ", phone=" + phone
				+ ", idCard=" + idCard + ", incomeStartTime=" + incomeStartTime + ", incomeEndTime=" + incomeEndTime
				+ ", auditStartTime=" + auditStartTime + ", auditEndTime=" + auditEndTime + ", applyProductId="
				+ applyProductId + ", state=" + state + ", list=" + list + ", isLoop=" + isLoop + ", isSettle="
				+ isSettle + ", repayMentDay=" + repayMentDay + ", orgId=" + orgId + ", loginId=" + loginId
				+ ", dataId=" + dataId + "]";
	}
	
}
