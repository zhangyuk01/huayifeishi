package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyLinkmanInfoTempSaveDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id; //主键ID
	private Long cusId;//客户基本信息表主键
	private Long applyId;//申请单ID
	private Long mainId; //申请表主键ID
	private Long contactType;
	private String contactTypeStr;//联系人类型    1734 家庭联系人    1897工作联系人     2092紧急联系人 
	private Long source;//来源          2013 网络查询      2108其他     2136申请表     2226 114查询        2273 人行报告
	private String sourceStr;
	private String sourceOther;//其他备注
	private String name;// 姓名
	private String idcard;//联系人身份证号
	private Long relation;//与联系人关系   2002 父母   2003其他亲属   2004 同事      2005朋友   2006其他     2007同学        2008配偶     2009子女     2010 兄弟   2011姐妹    2012商务合作伙伴 
	private String relationStr;
	private Long isKnowLoan;//是否知晓申请贷款  2486 是      2487 否  
	private String isKnowLoanStr;//是否知晓申请贷款  
	private String compName;//工作单位
	private Long province;//省
	private String provinceStr;//省
	private Long city;
	private String cityStr;//市
	private Long area;//区 
	private String areaStr;//区 
	private String address;//家庭详细住址
	private String allAddress;//家庭全地址
	private String duty;//职务
	private String phone;//联系电话
	private Integer orderNum;//联系人编号
	private Long relationCode;
	private String relationCodeStr;//家庭联系人关系  2371配偶   2373亲密朋友  2375父母  2377子女 2381兄弟 2382姐妹  2383同学 2384同事 2385朋友 2386商务合作伙伴 

	private Long createUser;//创建人
	private Long modifyUser;//修改人
	private Date createTime;//创建时间
	private Date modifyTime;//修改时间
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getContactType() {
		return contactType;
	}
	public void setContactType(Long contactType) {
		this.contactType = contactType;
	}
	public String getContactTypeStr() {
		return contactTypeStr;
	}
	public void setContactTypeStr(String contactTypeStr) {
		this.contactTypeStr = contactTypeStr;
	}
	public Long getSource() {
		return source;
	}
	public void setSource(Long source) {
		this.source = source;
	}
	public String getSourceStr() {
		return sourceStr;
	}
	public void setSourceStr(String sourceStr) {
		this.sourceStr = sourceStr;
	}
	public String getSourceOther() {
		return sourceOther;
	}
	public void setSourceOther(String sourceOther) {
		this.sourceOther = sourceOther;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public Long getRelation() {
		return relation;
	}
	public void setRelation(Long relation) {
		this.relation = relation;
	}
	public String getRelationStr() {
		return relationStr;
	}
	public void setRelationStr(String relationStr) {
		this.relationStr = relationStr;
	}
	public Long getIsKnowLoan() {
		return isKnowLoan;
	}
	public void setIsKnowLoan(Long isKnowLoan) {
		this.isKnowLoan = isKnowLoan;
	}
	public String getIsKnowLoanStr() {
		return isKnowLoanStr;
	}
	public void setIsKnowLoanStr(String isKnowLoanStr) {
		this.isKnowLoanStr = isKnowLoanStr;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public Long getProvince() {
		return province;
	}
	public void setProvince(Long province) {
		this.province = province;
	}
	public String getProvinceStr() {
		return provinceStr;
	}
	public void setProvinceStr(String provinceStr) {
		this.provinceStr = provinceStr;
	}
	public Long getCity() {
		return city;
	}
	public void setCity(Long city) {
		this.city = city;
	}
	public String getCityStr() {
		return cityStr;
	}
	public void setCityStr(String cityStr) {
		this.cityStr = cityStr;
	}
	public Long getArea() {
		return area;
	}
	public void setArea(Long area) {
		this.area = area;
	}
	public String getAreaStr() {
		return areaStr;
	}
	public void setAreaStr(String areaStr) {
		this.areaStr = areaStr;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAllAddress() {
		return allAddress;
	}
	public void setAllAddress(String allAddress) {
		this.allAddress = allAddress;
	}
	public String getDuty() {
		return duty;
	}
	public void setDuty(String duty) {
		this.duty = duty;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}
	public Long getRelationCode() {
		return relationCode;
	}
	public void setRelationCode(Long relationCode) {
		this.relationCode = relationCode;
	}
	public String getRelationCodeStr() {
		return relationCodeStr;
	}
	public void setRelationCodeStr(String relationCodeStr) {
		this.relationCodeStr = relationCodeStr;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	
}
