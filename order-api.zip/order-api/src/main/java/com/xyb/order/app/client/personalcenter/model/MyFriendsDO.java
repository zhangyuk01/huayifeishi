package com.xyb.order.app.client.personalcenter.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 我的好友
 * 
 * @author qiaoJinLong
 * @date 2018年9月17日
 */
public class MyFriendsDO implements IBaseModel {
	private static final long serialVersionUID = 89456840162685987L;

	private String name;// 姓名

	private String phone;// 手机号

	private String initials;// 姓名首字母

	private String recommendCode;// 推荐人id

	@Override
	public String toString() {
		return "MyFriendsDO [name=" + name + ", phone=" + phone + ", initials=" + initials + ", recommendCode="
				+ recommendCode + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public String getRecommendCode() {
		return recommendCode;
	}

	public void setRecommendCode(String recommendCode) {
		this.recommendCode = recommendCode;
	}

}
