package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordStateDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long applyId;
	private Long mainId;
	private Integer state;
	private Long clientId;


	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Long getClientId() {
		return clientId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
}
