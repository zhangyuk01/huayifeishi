package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;

/**
* @description:    用户修改密码传入参数
* @author:         xieqingyang
* @createDate:     2018/5/15 下午6:10
*/
public class ClientUserUpdatePasswordDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "旧密码不能为空")
    private String oldPassword;
    @NotEmpty(message = "新密码不能为空")
    @Pattern(regexp = "^.{6,20}$",message = "请输入6-20位字符的密码")
    private String newPassword;

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    @Override
    public String toString() {
        return "ClientUserUpdatePasswordDTO{" +
                "oldPassword='" + oldPassword + '\'' +
                ", newPassword='" + newPassword + '\'' +
                '}';
    }
}
