package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;

/**
* @description:    根据营业部和产品查询产品期限
* @author:         xieqingyang
* @createDate:     2018/5/12 下午12:03
*/
public class QueryProductLimitByProductIdAndOrgIdDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "营业部不能为空")
    private Long orgId;// -- 营业部ID
    @NotNull(message = "产品不能为空")
    private Long productId;// -- 产品ID

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }
}
