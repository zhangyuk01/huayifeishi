package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDTO;

/**
 * @ClassName AuditRiskCreditReportService
 * @author ZhangYu
 * @date 2018年5月16号
 */
public interface AuditRiskCreditReportService {


	/**
	 * 风控平台获取简版人行征信报告 
	 * @return
	 */
	RestResponse getSuanhuaCreditReportQuery(Long applyId)throws Exception;

	/**
	 * 风控平台获取社保报告 
	 * @param applyId
	 * @return
	 */
	RestResponse getShebaoReport(Long applyId)throws Exception;
	

	/**
	 * 风控平台获取公积金报告 
	 * @param applyId
	 * @return
	 */
	RestResponse getGjjReport(Long applyId)throws Exception;
	

	/**
	 * 获取风控运营商报告  
	 * @param applyId
	 * @return
	 */
	RestResponse getYYSReport(Long applyId)throws Exception;
	

	/**
	 * 获取风控保单报告 
	 * @param applyId
	 * @return
	 * @throws Exception
	 */
	RestResponse getBDReport(Long applyId)throws Exception;
	
	/**
	 * 获取风控通话详单记录 
	 * @param applyId
	 * @return
	 * @throws Exception
	 */
	RestResponse getPhoneCreditReportInfo(Long applyId,String phone) throws Exception;

	/**
	 * 运营商报告通话详单次数暂存
	 * @param applyPersonTationQueryDTO
	 * @return
	 * @throws Exception
	 */
	RestResponse rhCreditReportCountNumTempSave(ApplyPersonTationQueryDTO applyPersonTationQueryDTO) throws Exception;	

	/**
	 * 运营商报告通话详单次数查询 
	 * @return
	 * @throws Exception
	 */
	RestResponse getRhCreditReportCountNum(Long applyId) throws Exception;

}
