package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonTationQueryDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id; //主键ID
	private Long applyId; //申请单ID
	private Integer queryType;//查询类型
	private Integer queryQty;//查询次数
	private Date createTime;//创建时间
	private Long createUser;//创建人
	private Date modifyTime;//修改时间
	private Long modifyUser;//修改人

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Integer getQueryType() {
		return queryType;
	}
	public void setQueryType(Integer queryType) {
		this.queryType = queryType;
	}
	public Integer getQueryQty() {
		return queryQty;
	}
	public void setQueryQty(Integer queryQty) {
		this.queryQty = queryQty;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	
}
