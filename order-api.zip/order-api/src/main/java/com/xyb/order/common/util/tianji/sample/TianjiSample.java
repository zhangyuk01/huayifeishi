package com.xyb.order.common.util.tianji.sample;

import com.xyb.order.common.util.tianji.request.TianjiRequest;
import com.xyb.order.common.util.tianji.utils.RequestUtil;
import net.sf.json.JSONObject;

import java.util.Map;

/**
 * 通过OpenApi访问天机系统的一个简单的样例
 * @author chenrui
 *
 */
public class TianjiSample {
	
	/**
	 * 为机构分配的appid，通常是7位数字
	 */
	private String appId = "2010023";
	
	/**
	 * 机构的私钥，需要是pkcs8格式的
	 */
	private String privateKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBALlmRwq2pyZ+ACx6\n" +
			"ga2yyM4Ev4a5UAznPjLQ3XrS5zRq09S3dtLaMN5CQofDU4bUf6T4JiviM+S4ds8/\n" +
			"p1ZaqC5OGrZ5akEzzyQKCp0OXQAMx1ppaJv4fKuXk2wLmx41wV//Oul8w/RCjDfy\n" +
			"l9z0yRXg/3i4LgAaeUvYoXI1jLunAgMBAAECgYEAsXNCVe/DBqWc9vV+f0lax01m\n" +
			"H8Xo56DBOJQPGIsafmItRDEhiukJ0wGqehUrMibb0YMtzdzg/G7OUMlFGfMFekNo\n" +
			"izYrIqIodS6H5ju3PSdYpgK1AdJ0up00aOeKb5xSLoU+jDA/j/Hnvuur7+g3CVSh\n" +
			"yyrP1rZJtJu/4Ife7NECQQDeXSsS5vxhGPpcKiLUhB3t+CapPos51Vxz14pYBSAo\n" +
			"53IF5rZCU4u1kszPoR/E1DLvZCPZ80xT+ROTU5CKtTLpAkEA1XGyiTjFl1itj/+M\n" +
			"ZJI0u7T7s89+Z3HYbj95hHWL4VjG/SHdfNdC7bD4XCRGQMeIw2tpQVMINuUP4aws\n" +
			"AMDADwJAT9bt/1R2a7qXMf5jESD6yhXec8gkHzjPgDx0zNPSTz2CwEGtUTVEJYa3\n" +
			"CRnWGUsDmta+1KO51TDKaYyIinUy+QJBALXJnT6D7L3nGAOhqefqIiGQliNh4I2o\n" +
			"B6Z2Rz/KgXVPEEN9eU+fYvBgHlcTygXYK6IMtFufpUpjszAIXH3TrH8CQQDIq/0n\n" +
			"93uLHo1pkpm6I4PDIwrwEPOlsnGqPVX86LsU+y1x9VOaENX6VwiQtIyPiqgUaPuf\n" +
			"HPsPXL79zmvOfDVb";
	
	/**
	 * 是否是测试环境，测试环境会连接测试环境并打印debug信息
	 */
	private boolean isTestEnv = false;
	
	public void setIsTestEnv(boolean isTestEnv) {
		this.isTestEnv = isTestEnv;
	}
	
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	
	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getAppId() {
		return appId;
	}

	/**
	 * 请求OpenAPI的数据
	 */
	public JSONObject doOpenApiRequest(String method, Map<String, Object> params) throws Exception {
		String result = RequestUtil.request(method, params, appId, privateKey, isTestEnv);
		if (result == null || result.length() == 0) {
			throw new Exception("Request tianji api " + method + " returns null");
		}
		JSONObject jsonRet = JSONObject.fromObject(result);
		if (jsonRet == null) {
			throw new Exception("Request tianji api " + method + " got a non-json result");
		}
		return jsonRet;
	}

	/**
	 * 用户获取生成的报告详情接口
	 * <link>https://tianji.rong360.com/doc/crawl/tianjireport_collectuser.html</link>
	 * @param params 接口请求的业务参数，授权参数请到<pre>ClientManager</pre>中进行修改
	 * @return 返回结果的JSON对象，基本格式为
	 * {"error": 200, "msg": "success", "tianji_api_tianjireport_detail_response": {}}
	 * @throws Exception 当请求失败，或者返回的结果不是合法的json字符串时，会抛出异常
	 */
	public JSONObject getReportDetail(String method, Map<String, Object> params) throws Exception {
		String result = RequestUtil.request(method, params, appId, privateKey, isTestEnv);
		if (result == null || result.length() == 0) {
			throw new Exception("Request tianji collectUser interface returns null");
		}
		JSONObject jsonRet = JSONObject.fromObject(result);
		if (jsonRet == null) {
			throw new Exception("Request tianji collectUser interface got a non-json result");
		}
		return jsonRet;
	}
//
//	private static String getPrivateKey() throws IOException {
//		FileReader reader = new FileReader("private_key.pem");
//		char[] chars = new char[65*13 + 16];
//		reader.read(chars);
//		String privateKey = new String(chars);
//		reader.close();
//		return privateKey;
//	}
	
	/**
	 * 普通接口测试
	 */
	public static void testApi() throws Exception {
		TianjiSample sample = new TianjiSample();
		sample.setAppId(sample.appId); //TODO 设置Appid
		sample.setPrivateKey(sample.privateKey); // 设置机构私钥，需要机构替换private_key.pem文件
		sample.setIsTestEnv(true); // 设置为请求测试环境
		
		TianjiRequest bizData = new TianjiRequest();
		String method = null;
		//TODO 设置业务参数，示例：bizData.putParam("phone", "13581779389");
		//TODO 设置method，示例： method = "tianji.api.umeng.score";
		JSONObject ret = sample.doOpenApiRequest(method, bizData.getParams());
		System.out.println(ret.toString());
	}
}
