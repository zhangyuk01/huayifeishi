package com.xyb.order.pc.applybill.model;


import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class ApplyBillInfoQueryDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

    @JsonIgnore
    private Page page = new Page();// -- 分页

	private String name; // 客户姓名
	private String tell; // 手机号码
	private String idcard; // 身份证号
	@JsonIgnore
	private Long loginId; //当前登录用户id
	@JsonIgnore
	private Long clientAbandon;//客服放弃
	
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public Long getClientAbandon() {
		return clientAbandon;
	}
	public void setClientAbandon(Long clientAbandon) {
		this.clientAbandon = clientAbandon;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTell() {
		return tell;
	}
	public void setTell(String tell) {
		this.tell = tell;
	}
	public Long getLoginId() {
		return loginId;
	}
	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}

}
