package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    app展示消息列表
 * @author:         xieqingyang
 * @createDate:     2018/6/29 下午3:14
*/
public class AppMessageListVO implements IBaseModel {

    private static final long serialVersionUID = -7501166743653297812L;
    /**标题*/
    private String title = "";
    /**内容*/
    private String content = "";
    /**访问连接*/
    private String url = "";
    private String createDate = "";

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "AppMessageListVO{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", url='" + url + '\'' +
                ", createDate=" + createDate +
                '}';
    }
}
