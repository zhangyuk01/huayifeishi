package com.xyb.order.common.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import my.comp.crypto.impl.StandardCryptoEncoder;


/**
 * @author : jiangzhongyan
 * @projectName : finance-api
 * @package : com.xyb.util
 * @description : 接口验签工具类
 * @createDate : 2017/12/14 20:50
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class SignMatchesUtil {
	private static final Logger logger = LoggerFactory.getLogger(SignMatchesUtil.class);

    /**
     * 生成签名
     *
     * @param o
     * @param secretKey
     * @return
     */
    public static String signEncode(Object o, String secretKey) {
        StandardCryptoEncoder sc = new StandardCryptoEncoder(secretKey);
        String classValueStr = getClassValueStr(o);
        logger.info("加签前本系统原始参数:"+classValueStr);
        return sc.encode(classValueStr);
    }

    /**
     * 接口验签工具方法
     *
     * @param o         参数对象
     * @param sign      验签字符串
     * @param secretKey 密钥
     * @return
     */
    public static boolean matches(Object o, String secretKey, String sign) {
        StandardCryptoEncoder sc = new StandardCryptoEncoder(secretKey);
        String classValueStr = getClassValueStr(o);
        logger.info("验签前本系统原始参数:"+classValueStr);
        return sc.matches(classValueStr, sign);
    }

    /**
     * 参数拼接（把请求数据中的所有元素的值(除sign本身)连接起来（顺序按首字母升序排列，值为空的不参与签名））
     *
     * @param o
     * @return
     */
    public static String getClassValueStr(Object o) {
        Map<Integer, Object> valueMap = new HashMap<>();
        //反射解析
        Map map = reflectParameter(o, valueMap);
        StringBuffer stringBuffer = new StringBuffer();
        List<Map.Entry<Integer, Object>> list = new ArrayList<>(map.entrySet());
        //升序排序
        list.sort(Comparator.comparing(o2 -> o2.getKey()));
        for (Map.Entry<Integer, Object> mapping : list) {
            stringBuffer.append(mapping.getValue());
        }
        return stringBuffer.toString();
    }

    /**
     * //反射解析参数
     *
     * @param o
     * @return
     */
    public static Map<Integer, Object> reflectParameter(Object o, Map<Integer, Object> valueMap) {
        Class oClass = o.getClass();
        Field[] fields = oClass.getDeclaredFields();
        try {
            for (Field field : fields) {
                field.setAccessible(true);
                if (field.get(o) instanceof IBaseModel) {
                    reflectParameter(field.get(o), valueMap);
                } else if (field.get(o) instanceof Collection) {
                    List list = (List) field.get(o);
                    for (Object o2 : list) {
                        if (o2 instanceof IBaseModel) {
                            reflectParameter(o2, valueMap);
                        }
                    }
                } else if (field.get(o) instanceof Map) {
                    Map map = (Map) field.get(o);
                    Iterator<Map.Entry<String, Object>> iterator = map.entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry<String, Object> entry = iterator.next();
                        if (entry.getValue() instanceof IBaseModel) {
                            reflectParameter(entry.getValue(), valueMap);
                        }
                    }
                }
                if (field.isAnnotationPresent(SignField.class)) {
                    SignField signField = field.getAnnotation(SignField.class);
                    if (!ObjectUtils.isEmpty(field.get(o))) {
                        valueMap.put(signField.order(), field.get(o));
                    }
                }
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return valueMap;
    }
}
