package com.xyb.order.app.client.quickloan.model;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 工作信息
 * 
 * @author qiaoJinLong
 * @date 2018年12月20日
 */
public class QuickLoanApplyJobDTO implements IBaseModel {
	private static final long serialVersionUID = 1L;
	@NotNull(message = "月收入不能为空")
	private BigDecimal salary;// 薪资收入
	@NotEmpty(message = "单位名称不能为空")
	private String compName;// 单位名称
	@NotNull(message = "单位地址省不能为空")
	private Long compAddresProvince;// 单位地址省
	@NotNull(message = "单位地址市不能为空")
	private Long compAddresCity;// 单位地址市
	@NotNull(message = "单位地址区不能为空")
	private Long compAddresArea;// 单位地址区
	@NotEmpty(message = "单位地址不能为空")
	private String compAddres;// 单位地址
	private String compAddresProvinceMsg;
	private String compAddresCityMsg;
	private String compAddresAreaMsg;
	@JsonIgnore
	private String compAlladdress;// 单位全地址
	@NotEmpty(message = "在职时长不能为空")
	private Integer workingTime;// 工作时长/月
	@JsonIgnore
	private Long id;
	@JsonIgnore
	private Long applyId;
	@JsonIgnore
	private Long modifyUser;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Long cusId;

	public String getCompAddresProvinceMsg() {
		return compAddresProvinceMsg;
	}

	public void setCompAddresProvinceMsg(String compAddresProvinceMsg) {
		this.compAddresProvinceMsg = compAddresProvinceMsg;
	}

	public String getCompAddresCityMsg() {
		return compAddresCityMsg;
	}

	public void setCompAddresCityMsg(String compAddresCityMsg) {
		this.compAddresCityMsg = compAddresCityMsg;
	}

	public String getCompAddresAreaMsg() {
		return compAddresAreaMsg;
	}

	public void setCompAddresAreaMsg(String compAddresAreaMsg) {
		this.compAddresAreaMsg = compAddresAreaMsg;
	}

	@Override
	public String toString() {
		return "QuickLoanApplyJobDTO [salary=" + salary + ", compName=" + compName + ", compAddresProvince="
				+ compAddresProvince + ", compAddresCity=" + compAddresCity + ", compAddresArea=" + compAddresArea
				+ ", compAddres=" + compAddres + ", compAddresProvinceMsg=" + compAddresProvinceMsg
				+ ", compAddresCityMsg=" + compAddresCityMsg + ", compAddresAreaMsg=" + compAddresAreaMsg
				+ ", compAlladdress=" + compAlladdress + ", workingTime=" + workingTime + ", id=" + id + ", applyId="
				+ applyId + ", modifyUser=" + modifyUser + ", createUser=" + createUser + ", cusId=" + cusId + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public Long getCompAddresProvince() {
		return compAddresProvince;
	}

	public void setCompAddresProvince(Long compAddresProvince) {
		this.compAddresProvince = compAddresProvince;
	}

	public Long getCompAddresCity() {
		return compAddresCity;
	}

	public void setCompAddresCity(Long compAddresCity) {
		this.compAddresCity = compAddresCity;
	}

	public Long getCompAddresArea() {
		return compAddresArea;
	}

	public void setCompAddresArea(Long compAddresArea) {
		this.compAddresArea = compAddresArea;
	}

	public String getCompAddres() {
		return compAddres;
	}

	public void setCompAddres(String compAddres) {
		this.compAddres = compAddres;
	}

	public String getCompAlladdress() {
		return compAlladdress;
	}

	public void setCompAlladdress(String compAlladdress) {
		this.compAlladdress = compAlladdress;
	}

	public Integer getWorkingTime() {
		return workingTime;
	}

	public void setWorkingTime(Integer workingTime) {
		this.workingTime = workingTime;
	}

}
