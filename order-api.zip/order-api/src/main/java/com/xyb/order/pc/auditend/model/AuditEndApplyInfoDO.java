/**
 * 
 */
package com.xyb.order.pc.auditend.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.auditend.model
 * @description : TODO
 * @createDate : 2018年12月25日 下午4:02:23
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */

public class AuditEndApplyInfoDO implements IBaseModel {


    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * id :
     * agreeProductId : 批贷产品Id
     * agreeProductExtId : 批贷期限ID
     * amount : 批贷金额
     * serviceAmount : 服务费
     * endauditOverTime : 申请审批时间：终审批贷或拒贷时间
     * refuse : 是否拒贷
     * refuseNode ; 拒贷环节
     * refuseCode ; 拒贷码
     * signCheck : 是否签约前核验
     */

    private Long id;
    private Long agreeProductId;
    private Long agreeProductExtId;
    private BigDecimal amount;
    private BigDecimal serviceAmount;
    private Date endauditOverTime;
    private Long refuse;
    private Long refuseNode;
    private String refuseCode;
    private Long signCheck;
    private Long operationUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAgreeProductId() {
        return agreeProductId;
    }

    public void setAgreeProductId(Long agreeProductId) {
        this.agreeProductId = agreeProductId;
    }

    public Long getAgreeProductExtId() {
        return agreeProductExtId;
    }

    public void setAgreeProductExtId(Long agreeProductExtId) {
        this.agreeProductExtId = agreeProductExtId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getEndauditOverTime() {
        return endauditOverTime;
    }

    public void setEndauditOverTime(Date endauditOverTime) {
        this.endauditOverTime = endauditOverTime;
    }

    public Long getRefuse() {
        return refuse;
    }

    public void setRefuse(Long refuse) {
        this.refuse = refuse;
    }

    public Long getRefuseNode() {
        return refuseNode;
    }

    public void setRefuseNode(Long refuseNode) {
        this.refuseNode = refuseNode;
    }

    public String getRefuseCode() {
        return refuseCode;
    }

    public void setRefuseCode(String refuseCode) {
        this.refuseCode = refuseCode;
    }

    public Long getSignCheck() {
        return signCheck;
    }

    public void setSignCheck(Long signCheck) {
        this.signCheck = signCheck;
    }

    public Long getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(Long operationUser) {
        this.operationUser = operationUser;
    }

    public BigDecimal getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(BigDecimal serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    @Override
    public String toString() {
        return "AuditEndApplyInfoDO{" +
                "id=" + id +
                ", agreeProductId=" + agreeProductId +
                ", agreeProductExtId=" + agreeProductExtId +
                ", amount=" + amount +
                ", serviceAmount=" + serviceAmount +
                ", endauditOverTime=" + endauditOverTime +
                ", refuse=" + refuse +
                ", refuseNode=" + refuseNode +
                ", refuseCode='" + refuseCode + '\'' +
                ", signCheck=" + signCheck +
                ", operationUser=" + operationUser +
                '}';
    }


}
