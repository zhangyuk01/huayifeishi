package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;
import java.util.Map;

/**
 * 查询下拉框时所需要的
 * @author         xieqingyang
 * @date           2018/8/28 下午6:10
*/
public class DropDownBoxDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    /**查询类型*/
    private String type;
    /**传入参数 没有不传*/
    private Long paramete;
    /**传入参数  多个参数*/
    private Map<String,Object> parametes;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getParamete() {
        return paramete;
    }

    public void setParamete(Long paramete) {
        this.paramete = paramete;
    }

    public Map<String, Object> getParametes() {
        return parametes;
    }

    public void setParametes(Map<String, Object> parametes) {
        this.parametes = parametes;
    }

    @Override
    public String toString() {
        return "DropDownBoxDTO{" +
                "type='" + type + '\'' +
                ", paramete=" + paramete +
                ", parametes=" + parametes +
                '}';
    }
}
