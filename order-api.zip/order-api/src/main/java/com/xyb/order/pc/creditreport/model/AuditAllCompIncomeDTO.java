package com.xyb.order.pc.creditreport.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditAllCompIncomeDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long applyId;
	private	List<AuditCompIncomeDTO> auditCompIncomeDTOs;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public List<AuditCompIncomeDTO> getAuditCompIncomeDTOs() {
		return auditCompIncomeDTOs;
	}
	public void setAuditCompIncomeDTOs(List<AuditCompIncomeDTO> auditCompIncomeDTOs) {
		this.auditCompIncomeDTOs = auditCompIncomeDTOs;
	}
}
