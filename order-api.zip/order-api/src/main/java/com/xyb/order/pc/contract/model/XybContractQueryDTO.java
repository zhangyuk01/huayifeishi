package com.xyb.order.pc.contract.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同list查询model
 * @createDate : 2018/03/29 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractQueryDTO implements IBaseModel {
	
	
	private static final long serialVersionUID = 5247704077120155071L;
	@JsonIgnore
    private Page page = new Page();// -- 分页
	/**申请编号*/
	private String applyNum;
	/**客户姓名*/
	private String custName;
	/**身份证号*/
	private String idCard;
	/**进件机构id*/
	@JsonIgnore
	private Long orgId;
	/**签约前核验*/
	private Long signCheck;
	/**loginId*/
	@JsonIgnore
	private Long loginId;
	/**是否已分配*/
	private Long isAllocation;
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Long getSignCheck() {
		return signCheck;
	}
	public void setSignCheck(Long signCheck) {
		this.signCheck = signCheck;
	}
	public Long getLoginId() {
		return loginId;
	}
	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}
	public Long getIsAllocation() {
		return isAllocation;
	}
	public void setIsAllocation(Long isAllocation) {
		this.isAllocation = isAllocation;
	}
	@Override
	public String toString() {
		return "XybContractQueryDTO [page=" + page + ", applyNum=" + applyNum + ", custName=" + custName + ", idCard="
				+ idCard + ", orgId=" + orgId + ", signCheck=" + signCheck + ", loginId=" + loginId + ", isAllocation="
				+ isAllocation + "]";
	}

}
