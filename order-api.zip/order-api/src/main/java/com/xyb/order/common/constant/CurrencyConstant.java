package com.xyb.order.common.constant;

/**
 * Created by xieqingyang on 2018/4/11.
 * 通用常量类
 */
public class CurrencyConstant {

    public static final String Y = "Y";
    public static final String N = "N";
    public static final String NINE = "99";
    public static final String ONE = "1";

    /**设备类型*/
    public static final String IOS = "ios";
    public static final String ANDROID = "android";

    /**短信相关常量*/
    /**销售人员变更发送短信验证码限制/天*/
    public static final int UPDATE_SALE_MESSAGE_UPPER_LIMIT = 5;

    /**短信渠道商关闭*/
    public static final String CHANNEL_MESSAGE_IS_VALID = "0";
    /**短信渠道商开启*/
    public static final String CHANNEL_MESSAGE_NO_VALID = "1";

    /**短信有效*/
    public static final String MESSAGE_IS_VALID = "0";
    /**短信无效*/
    public static final String MESSAGE_NO_VALID = "1";
    /**app短信有效时间（分钟）*/
    public static final int MESSAGE_VALID_TIME = 5;
    /**短信验证码一天发送次数*/
    public static final int MESSAGE_UP_COUNT = 5;
    /**短信通用验证类*/
    public static final int MESSAGE_CURRENCY_101 = 101;
    /**短信验证次数限制类*/
    public static final int MESSAGE_FREQUENCY_LIMIT_102 = 102;
    /**掌友宝短信验证码*/
    public static final int MESSAGE_FREQUENCY_LIMIT_103 = 103;
    /**新增销售人员短信验证码*/
    public static final int MESSAGE_FREQUENCY_LIMIT_104= 104;
    /**销售人员修改发送短信验证码*/
    public static final int MESSAGE_FREQUENCY_LIMIT_105 = 105;
    /**终审批贷提醒*/
    public static final int REMINDING_FINAL_REVIEW = 201;
    /**还款提醒*/
    public static final int MESSAGE_REMINDERS = 202;

    /**短信大类类型 业务大类，1.验证，2.业务，3.宣传*/
    public static final String MESSAGE_LIST_CURRENCY = "1";
    public static final String MESSAGE_LIST_BUSINESS = "2";
    public static final String MESSAGE_LIST_PROPAGANDA = "3";

    /**短信渠道-漫道*/
    public static final int MESSAGE_CHANNEL_MD = 1;

    /**复议*/
    /**复议次数*/
    public static final int RECONSIDERATION_QTY = 2;

    /**系统账户*/
    public static final long SYSTEM_USER = 0;

    /**销售人员初始密码*/
    public static final String SALE_USER_PASSWORD = "xyb123456";

    /**图片存储前缀*/
    public static final String HTTP = "http://";

    /**一致(是)*/
    public static final Long  CURRENCY_CONSTANT_2486 = 2486L;

    /**不一致(否)*/
    public static final Long  CURRENCY_CONSTANT_2487 = 2487L;
}
