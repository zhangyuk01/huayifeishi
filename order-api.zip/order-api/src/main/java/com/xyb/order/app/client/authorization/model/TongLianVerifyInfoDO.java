package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : weiyuhao
 * @projectName :
 * @package : com.xyb.order.app.client.authorization.model
 * @description :
 * @createDate : 2018/9/25 10:00
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class TongLianVerifyInfoDO implements IBaseModel{

    private static final long serialVersionUID = -4188587158762940109L;

    private String name;

    private String idCard;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    @Override
    public String toString() {
        return "TongLianVerifyInfoDO{" +
                "name='" + name + '\'' +
                ", idCard='" + idCard + '\'' +
                '}';
    }
}
