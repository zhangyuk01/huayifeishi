package com.xyb.order.common.constant;

/**
 * @description:    redis常量类
 * @author:         xieqingyang
 * @createDate:     2018/8/21 下午2:53
*/
public class RedisConstant {

    /**进件系统开头*/
    public static final String ORDER = "order_";

    /**字典*/
    public static final String DICT = "dict_";

    /**销售人员编号*/
    public static final String SALE_CODE = "order_sale_code";

    /**产品展示*/
    public static final String PRODUCT_EXHIBITION = "order_product_exhibition";

    /**身份认证信息*/
    public static final String CLIENT_AUTHENTICATION_INFO = "order_depository_state_";

    /**ios版本信息*/
    public static final String C_APP_VERSION_IOS = "order_capp_version_ios";
    /**android版本信息*/
    public static final String C_APP_VERSION_ANDROID = "order_capp_version_android";

    /**C端消息缓存数据-公告*/
    public static final String C_MESSAGE = "order_c_message_notice_";
    /**C端消息缓存数据-最后一条公告*/
    public static final String C_LAST_MESSAGE = "order_c_message_notice_last";
    /**C端消息缓存数据-用户消息*/
    public static final String C_MESSAGE_USER = "order_c_message_user_";
    /**C端消息缓存数据-最后一条用户消息*/
    public static final String C_LAST_MESSAGE_USER = "order_c_message_user_last_";

    /**B端消息缓存数据-公告*/
    public static final String B_MESSAGE = "order_b_message_notice_";
    /**B端消息缓存数据-最后一条公告*/
    public static final String B_LAST_MESSAGE = "order_b_message_notice_last";
    /**B端消息缓存数据-用户消息*/
    public static final String B_MESSAGE_USER = "order_b_message_user_";
    /**B端消息缓存数据-最后一条用户消息*/
    public static final String B_LAST_MESSAGE_USER = "order_b_message_user_last_";

    /**capp展示的支持的银行卡列表信息*/
    public static final String CAPP_BANKLIST = "order_capp_banklist";

    /**用户绑卡状态信息*/
    public static final String ORDER_USER_BANK_STATE = "order_user_bank_state_";

    /** 推荐人信息 */
    public static final String  ORDER_USER_REFERRER = "order_user_referrer";
    /**限制判断通讯录是否上传的查询时间*/
    public static final String PHONE_ADDRESS_BOOK_CHECK="phone_address_book_check";
    //图片缓存前缀
    public final static String IMAGE_APPLY = "order_image_";
    //缓存时间
    public final static int IMAGE_CACHE_TIME = 260000;
	/*** 用户登录验证码*/
	public static final String USER_LOGIN_SMS_CODE="user_login_sms_code";
	/*** 用户密码验证通过标志*/
	public static final String CHECK_USER_ADOPT="check_user_adopt";
	/**疑难解答首页**/
	public static final String COMMON_PROBLEM_HOME="common_problem_home";

	/** 优信借满额标志 */
	public static final String YOU_XIN_JIE_FULL_AMOUNT_FLAG="you_xin_jie_full_amount_flag_";
}
