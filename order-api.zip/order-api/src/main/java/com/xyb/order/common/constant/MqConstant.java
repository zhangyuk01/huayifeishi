package com.xyb.order.common.constant;

/**
* @description:    mq相关常量
* @author:         xieqingyang
* @createDate:     2018/5/17 下午5:07
*/
public class MqConstant {

    /**监听工厂名称*/
    public static final String JMS_LISTENER_CONTAINER_FACTORY_ID = "jmsListenerContainerFactory";

    /**风控系统审核推送目的地*/
    public static final String SYSTEM_AUDITING_MONITORING_DESTINATION = "risk_hangle_flowpath";
//    public static final String SYSTEM_AUDITING_MONITORING_DESTINATION = "risk_hangle_flowpath_test";
    
    /**风控系统审核推送目的地(优信借)*/
    public static final String SYSTEM_AUDITING_MONITORING_DESTINATION_YOUXINJIE = "risk_hangle_flowpath_yxj";

    /**风控系统审核监听目的地*/
    public static final String SYSTEM_AUDIT_PUSH_DESTINATION = "system_audit_monitoring_destination_apply";
    
    /**风控系统审核优信借监听*/
    public static final String SYSTEM_AUDIT_PUSH_YOUXIN_DESTINATION = "system_audit_youxin_apply";
//    public static final String SYSTEM_AUDIT_PUSH_DESTINATION = "system_audit_monitoring_destination_apply_test";

    /**消息队列*/
    public static final String MESSAGE_QUEUE = "apply_message_queue";
//    public static final String MESSAGE_QUEUE = "apply_message_queue_test";
    /**保存电话簿*/
    public static final String KEEP_PHONE_BOOKS = "keep_phone_books";
}
