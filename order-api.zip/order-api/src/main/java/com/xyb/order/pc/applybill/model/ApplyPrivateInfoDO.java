package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPrivateInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;//主键ID
	private Long applyId;//申请单ID
	private Long mainId; //申请主表ID
	private Long cusId;//客户基本信息主键ID
	private String enterpriseName;//企业名称
	private String tel;//企业电话
	private Long enteType;//企业类型
	private String enteTypeStr;//企业类型
	private Long palace;//经营场所
	private String palaceStr;
	private Date regDate;//成立时间
	private Double stockRatio;//所占股份比例百分比的数值
	private Long staffAmount;//企业规模
	private String staffAmountStr;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}


	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getEnterpriseName() {
		return enterpriseName;
	}
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public Long getEnteType() {
		return enteType;
	}

	public void setEnteType(Long enteType) {
		this.enteType = enteType;
	}

	public String getEnteTypeStr() {
		return enteTypeStr;
	}

	public void setEnteTypeStr(String enteTypeStr) {
		this.enteTypeStr = enteTypeStr;
	}

	public Long getPalace() {
		return palace;
	}
	public void setPalace(Long palace) {
		this.palace = palace;
	}
	public String getPalaceStr() {
		return palaceStr;
	}
	public void setPalaceStr(String palaceStr) {
		this.palaceStr = palaceStr;
	}
	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Double getStockRatio() {
		return stockRatio;
	}

	public void setStockRatio(Double stockRatio) {
		this.stockRatio = stockRatio;
	}
	public Long getStaffAmount() {
		return staffAmount;
	}

	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}

	public String getStaffAmountStr() {
		return staffAmountStr;
	}

	public void setStaffAmountStr(String staffAmountStr) {
		this.staffAmountStr = staffAmountStr;
	}


}
