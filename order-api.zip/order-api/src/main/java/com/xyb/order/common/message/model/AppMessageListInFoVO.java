package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.List;

/**
 * @description:    消息列表包装数据
 * @author:         xieqingyang
 * @createDate:     2018/6/29 下午3:34
*/
public class AppMessageListInFoVO implements IBaseModel {

    private static final long serialVersionUID = 7656615026029540365L;
    private List<AppMessageListVO> list;

    /**是否有下一页 Y:是 N:否*/
    private String isMore = "";

    public List<AppMessageListVO> getList() {
        return list;
    }

    public void setList(List<AppMessageListVO> list) {
        this.list = list;
    }

    public String getIsMore() {
        return isMore;
    }

    public void setIsMore(String isMore) {
        this.isMore = isMore;
    }

    @Override
    public String toString() {
        return "AppMessageListInFoVO{" +
                "list=" + list +
                ", isMore='" + isMore + '\'' +
                '}';
    }
}
