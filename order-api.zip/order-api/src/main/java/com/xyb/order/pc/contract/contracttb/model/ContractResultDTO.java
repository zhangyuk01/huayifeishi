package com.xyb.order.pc.contract.contracttb.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

public class ContractResultDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4364419877683011318L;
	@SignField(order = 0)
	private String code;
	@SignField(order = 1)
	private String message;
	private ContractTbResultBodyDTO body;
	private String sign;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ContractTbResultBodyDTO getBody() {
		return body;
	}
	public void setBody(ContractTbResultBodyDTO body) {
		this.body = body;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	@Override
	public String toString() {
		return "ContractResultDTO [code=" + code + ", message=" + message + ", body=" + body + ", sign=" + sign + "]";
	}

}
