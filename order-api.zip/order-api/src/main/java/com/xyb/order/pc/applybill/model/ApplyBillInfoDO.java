package com.xyb.order.pc.applybill.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;//申请单ID
	private Long cusId;//客户ID
	private Long mainId; //主表ID
	private String applyNum;//申请单编号
	private Date applyTime;//申请时间
	private Long storeOrgId; // 营业部ID 
	private String storeOrgName; //营业部名称
	private Long teamOrgId;// 销售团队
	private String teamOrgName;//销售团队名称
	private Long teamManagerId;//团队经理ID 
	private String teamManageUname;//团队经理名称
	private Long managerUid;//销售人员ID
	private String managerUname;//销售人员姓名
	private Long serviceUid;//客服专员
	private String serviceUname;//客服专员姓名
	private Long expectProductId;//申请借款产品ID
	private String expectProductName; //申请借款产品名称
	private Long expectProductType; //产品名称类型
	private String expectProductTypeStr; 
	private Long borrowDescCode;//借款用途代码 
	private String borrowDescCodeStr;
	private Long borrowDescDetailCode;//借款详细用途
	private String borrowDescOther; //其他借款用途描述
	private BigDecimal maxReturnMoney;//每月最高还款额度
	private BigDecimal expectMoney;//申请借款金额 
	private int expectTerm;//申请借款期数
	private Long isLoop; //是否循环贷
	private String isLoopStr;
	private String cusSource;//客户来源
	private String projectCode;//专案码
	private String remark;// 备注
	private String callCustomerTimeRemark;
	private String serviceRemark;

	private Date callCustomerTimeSta;
	private Date callCustomerTimeEnd;
	
	private Long managerId;
	private Long productType;
	private Long productId;
	/**特殊情况备注*/
	private String specialRemark;
	/**推荐人姓名*/
	private String recommender;

	
	public String getCallCustomerTimeRemark() {
		return callCustomerTimeRemark;
	}
	public void setCallCustomerTimeRemark(String callCustomerTimeRemark) {
		this.callCustomerTimeRemark = callCustomerTimeRemark;
	}
	public String getServiceRemark() {
		return serviceRemark;
	}
	public void setServiceRemark(String serviceRemark) {
		this.serviceRemark = serviceRemark;
	}
	public Date getCallCustomerTimeSta() {
		return callCustomerTimeSta;
	}
	public void setCallCustomerTimeSta(Date callCustomerTimeSta) {
		this.callCustomerTimeSta = callCustomerTimeSta;
	}
	public Date getCallCustomerTimeEnd() {
		return callCustomerTimeEnd;
	}
	public void setCallCustomerTimeEnd(Date callCustomerTimeEnd) {
		this.callCustomerTimeEnd = callCustomerTimeEnd;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public Date getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}
	public String getStoreOrgName() {
		return storeOrgName;
	}
	public void setStoreOrgName(String storeOrgName) {
		this.storeOrgName = storeOrgName;
	}
	
	public Long getStoreOrgId() {
		return storeOrgId;
	}
	public void setStoreOrgId(Long storeOrgId) {
		this.storeOrgId = storeOrgId;
	}
	public Long getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(Long teamOrgId) {
		this.teamOrgId = teamOrgId;
	}
	public String getTeamOrgName() {
		return teamOrgName;
	}
	public void setTeamOrgName(String teamOrgName) {
		this.teamOrgName = teamOrgName;
	}
	public Long getTeamManagerId() {
		return teamManagerId;
	}
	public void setTeamManagerId(Long teamManagerId) {
		this.teamManagerId = teamManagerId;
	}
	public String getTeamManageUname() {
		return teamManageUname;
	}
	public void setTeamManageUname(String teamManageUname) {
		this.teamManageUname = teamManageUname;
	}
	public Long getManagerUid() {
		return managerUid;
	}
	public void setManagerUid(Long managerUid) {
		this.managerUid = managerUid;
	}
	public String getManagerUname() {
		return managerUname;
	}
	public void setManagerUname(String managerUname) {
		this.managerUname = managerUname;
	}
	public Long getServiceUid() {
		return serviceUid;
	}
	public void setServiceUid(Long serviceUid) {
		this.serviceUid = serviceUid;
	}
	public String getServiceUname() {
		return serviceUname;
	}
	public void setServiceUname(String serviceUname) {
		this.serviceUname = serviceUname;
	}
	public Long getExpectProductId() {
		return expectProductId;
	}
	public void setExpectProductId(Long expectProductId) {
		this.expectProductId = expectProductId;
	}
	public String getExpectProductName() {
		return expectProductName;
	}
	public void setExpectProductName(String expectProductName) {
		this.expectProductName = expectProductName;
	}
	public Long getExpectProductType() {
		return expectProductType;
	}
	public void setExpectProductType(Long expectProductType) {
		this.expectProductType = expectProductType;
	}
	public String getExpectProductTypeStr() {
		return expectProductTypeStr;
	}
	public void setExpectProductTypeStr(String expectProductTypeStr) {
		this.expectProductTypeStr = expectProductTypeStr;
	}
	public Long getBorrowDescCode() {
		return borrowDescCode;
	}
	public void setBorrowDescCode(Long borrowDescCode) {
		this.borrowDescCode = borrowDescCode;
	}
	public String getBorrowDescCodeStr() {
		return borrowDescCodeStr;
	}
	public void setBorrowDescCodeStr(String borrowDescCodeStr) {
		this.borrowDescCodeStr = borrowDescCodeStr;
	}
	public Long getBorrowDescDetailCode() {
		return borrowDescDetailCode;
	}
	public void setBorrowDescDetailCode(Long borrowDescDetailCode) {
		this.borrowDescDetailCode = borrowDescDetailCode;
	}
	public String getBorrowDescOther() {
		return borrowDescOther;
	}
	public void setBorrowDescOther(String borrowDescOther) {
		this.borrowDescOther = borrowDescOther;
	}
	public BigDecimal getMaxReturnMoney() {
		return maxReturnMoney;
	}
	public void setMaxReturnMoney(BigDecimal maxReturnMoney) {
		this.maxReturnMoney = maxReturnMoney;
	}
	public BigDecimal getExpectMoney() {
		return expectMoney;
	}
	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}
	public int getExpectTerm() {
		return expectTerm;
	}
	public void setExpectTerm(int expectTerm) {
		this.expectTerm = expectTerm;
	}
	public Long getIsLoop() {
		return isLoop;
	}
	public void setIsLoop(Long isLoop) {
		this.isLoop = isLoop;
	}
	public String getIsLoopStr() {
		return isLoopStr;
	}
	public void setIsLoopStr(String isLoopStr) {
		this.isLoopStr = isLoopStr;
	}
	public String getCusSource() {
		return cusSource;
	}
	public void setCusSource(String cusSource) {
		this.cusSource = cusSource;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Long getManagerId() {
		return managerId;
	}
	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}
	public Long getProductType() {
		return productType;
	}
	public void setProductType(Long productType) {
		this.productType = productType;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getSpecialRemark() {
		return specialRemark;
	}

	public void setSpecialRemark(String specialRemark) {
		this.specialRemark = specialRemark;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	@Override
	public String toString() {
		return "ApplyBillInfoDO{" +
				"id=" + id +
				", cusId=" + cusId +
				", mainId=" + mainId +
				", applyNum='" + applyNum + '\'' +
				", applyTime=" + applyTime +
				", storeOrgId=" + storeOrgId +
				", storeOrgName='" + storeOrgName + '\'' +
				", teamOrgId=" + teamOrgId +
				", teamOrgName='" + teamOrgName + '\'' +
				", teamManagerId=" + teamManagerId +
				", teamManageUname='" + teamManageUname + '\'' +
				", managerUid=" + managerUid +
				", managerUname='" + managerUname + '\'' +
				", serviceUid=" + serviceUid +
				", serviceUname='" + serviceUname + '\'' +
				", expectProductId=" + expectProductId +
				", expectProductName='" + expectProductName + '\'' +
				", expectProductType=" + expectProductType +
				", expectProductTypeStr='" + expectProductTypeStr + '\'' +
				", borrowDescCode=" + borrowDescCode +
				", borrowDescCodeStr='" + borrowDescCodeStr + '\'' +
				", borrowDescDetailCode=" + borrowDescDetailCode +
				", borrowDescOther='" + borrowDescOther + '\'' +
				", maxReturnMoney=" + maxReturnMoney +
				", expectMoney=" + expectMoney +
				", expectTerm=" + expectTerm +
				", isLoop=" + isLoop +
				", isLoopStr='" + isLoopStr + '\'' +
				", cusSource='" + cusSource + '\'' +
				", projectCode='" + projectCode + '\'' +
				", remark='" + remark + '\'' +
				", callCustomerTimeRemark='" + callCustomerTimeRemark + '\'' +
				", serviceRemark='" + serviceRemark + '\'' +
				", callCustomerTimeSta=" + callCustomerTimeSta +
				", callCustomerTimeEnd=" + callCustomerTimeEnd +
				", managerId=" + managerId +
				", productType=" + productType +
				", productId=" + productId +
				", specialRemark='" + specialRemark + '\'' +
				", recommender='" + recommender + '\'' +
				'}';
	}
}
