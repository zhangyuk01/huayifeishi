package com.xyb.order.common.currency.service;

import com.beiming.kun.framework.msg.RestResponse;

/**
 * Created by xieqingyang on 2018/5/6.
 * 初审审核项
 */
public interface AuditCheckItemService {

    /**
     * @param primaryInfoId 申请单ID 必传
     * @param item 审核项编码  AuditCheckItemConstant类中已有定义 必传
     * @return
     */
    RestResponse insertCheckItem(Long primaryInfoId,Integer item)throws Exception ;
}
