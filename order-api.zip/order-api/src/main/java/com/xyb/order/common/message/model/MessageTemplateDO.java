package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 短信模板
 * Created by xieqingyang on 2018/4/11.
 */
public class MessageTemplateDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private Long id;// -- 主键ID
    private String messageTypeId; // -- 短信所属业务类型ID
    private String type; // -- 短信类型
    private String value; // -- 短信内容
    private String remark; // -- 备注短信用途

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMessageTypeId() {
        return messageTypeId;
    }

    public void setMessageTypeId(String messageTypeId) {
        this.messageTypeId = messageTypeId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
