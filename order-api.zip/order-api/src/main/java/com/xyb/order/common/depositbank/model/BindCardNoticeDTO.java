package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * 个人绑卡申请结果通知model
 * @author  wangshicheng 2018年11月26日10:43:19
 */
public class BindCardNoticeDTO implements IBaseModel {


    private static final long serialVersionUID = 4604729250595115112L;

    /**
     *证件类型
     */
    @SignField(order = 2)
    private String cert_type;
    /**
     *证件号码
     */
    @NotEmpty(message = "cert_no不能为空!")
    @SignField(order = 3)
    private String cert_no;
    @NotEmpty(message = "name不能为空!")
    private String name;
    /**
     *电子账户
     */
    @NotEmpty(message = "card_no不能为空!")
    @SignField(order = 4)
    private String card_no;
    /**
     *客户号（开户返回的客户号）
     */
    @NotEmpty(message = "customer_no不能为空!")
    private String customer_no;
    /**
     *三方绑定编号(绑卡是返回的编号，解绑的时候要根据这个绑定编号解绑)
     */
    @NotEmpty(message = "serial_no不能为空!")
    private String serial_no;
    /**
     *银行卡号
     */
    @NotEmpty(message = "bank_card_no不能为空!")
    private String bank_card_no;
    private String mobile;
    /**
     *返回响应码
     */
    private String rsp_code;
    private String bank_name;
    @NotEmpty(message = "bank_id_no不能为空!")
    private String bank_id_no;
    /**
     *账户类型
     */
    private String account_type;
    /**
     *申请流水号
     */
    private String out_serial_no;
    /**
     *交易代码
     */
    private String service;

    public String getCert_type() {
        return cert_type;
    }

    public void setCert_type(String cert_type) {
        this.cert_type = cert_type;
    }

    public String getCert_no() {
        return cert_no;
    }

    public void setCert_no(String cert_no) {
        this.cert_no = cert_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getSerial_no() {
        return serial_no;
    }

    public void setSerial_no(String serial_no) {
        this.serial_no = serial_no;
    }

    public String getBank_card_no() {
        return bank_card_no;
    }

    public void setBank_card_no(String bank_card_no) {
        this.bank_card_no = bank_card_no;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getRsp_code() {
        return rsp_code;
    }

    public void setRsp_code(String rsp_code) {
        this.rsp_code = rsp_code;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getBank_id_no() {
        return bank_id_no;
    }

    public void setBank_id_no(String bank_id_no) {
        this.bank_id_no = bank_id_no;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    @Override
    public String toString() {
        return "BindCardNoticeDTO{" +
                "cert_type='" + cert_type + '\'' +
                ", cert_no='" + cert_no + '\'' +
                ", name='" + name + '\'' +
                ", card_no='" + card_no + '\'' +
                ", customer_no='" + customer_no + '\'' +
                ", serial_no='" + serial_no + '\'' +
                ", bank_card_no='" + bank_card_no + '\'' +
                ", mobile='" + mobile + '\'' +
                ", rsp_code='" + rsp_code + '\'' +
                ", bank_name='" + bank_name + '\'' +
                ", bank_id_no='" + bank_id_no + '\'' +
                ", account_type='" + account_type + '\'' +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", service='" + service + '\'' +
                '}';
    }
}
