package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * Created by xieqingyang on 2018/4/11.
 * 短信渠道商
 */
public class MessageChannelDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private Long id; // -- 主键ID
    private String des;  // -- 渠道描述
    private String channelKey; // -- 渠道账号
    private String channelPassword; // -- 渠道密码
    private String channelAddress; // -- 渠道地址URL
    private String state; // -- 渠道状态

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getChannelKey() {
        return channelKey;
    }

    public void setChannelKey(String channelKey) {
        this.channelKey = channelKey;
    }

    public String getChannelPassword() {
        return channelPassword;
    }

    public void setChannelPassword(String channelPassword) {
        this.channelPassword = channelPassword;
    }

    public String getChannelAddress() {
        return channelAddress;
    }

    public void setChannelAddress(String channelAddress) {
        this.channelAddress = channelAddress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
