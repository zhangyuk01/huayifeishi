package com.xyb.order.pc.outbound.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访产调提交DTO model
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailSubmitPropertySurveyDTO implements IBaseModel {


	/**
	 * 
	 */
	private static final long serialVersionUID = 7854118797388909404L;
	/**申请id*/
	@NotNull(message = "applyId不能为空")
	private Long applyId;
	/**外访产调*/
	private ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO;

	public ApplyVisitPropertySurveyDTO getApplyVisitPropertySurveyDTO() {
		return applyVisitPropertySurveyDTO;
	}

	public void setApplyVisitPropertySurveyDTO(ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO) {
		this.applyVisitPropertySurveyDTO = applyVisitPropertySurveyDTO;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Override
	public String toString() {
		return "OutBoundDetailSubmitPropertySurveyDTO [applyId=" + applyId + ", applyVisitPropertySurveyDTO="
				+ applyVisitPropertySurveyDTO + "]";
	}



}
