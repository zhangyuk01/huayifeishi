package com.xyb.order.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.beiming.kun.utils.DateTimeUtil;

import javax.servlet.http.HttpServletRequest;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.util.*;

/**
 * 获取request中信息
 * @author         xieqingyang
 * @date           2018/8/31 上午10:32
*/
public class RequestUtils {

    /**
     * 日志
     */
    private static final Logger logger = LoggerFactory.getLogger(RequestUtils.class);

    /**
     * 从request中创建Bean
     *
     * @param clazz   Class
     * @param request httpserleterequest
     * @return Object
     */
    @SuppressWarnings("unchecked")
    public static Object getRequestBean(Class clazz, HttpServletRequest request) {
        Object obj = null;
        try {
            obj = clazz.newInstance();
            Field[] fields = clazz.getDeclaredFields();
            Map paraMap = request.getParameterMap();
            Set<String> key = paraMap.keySet();
            logger.debug("--------页面传递参数---------");
            for (Iterator it = key.iterator(); it.hasNext(); ) {
                String k = (String) it.next();
                Object valueObj = paraMap.get(k);
                if (valueObj.getClass().getName().startsWith("[Ljava.lang.String")) {
                    String[] values = (String[]) valueObj;
                    for (int i = 0; i < values.length; i++) {
                        //统一将参数解码
                        String value = URLDecoder.decode(values[i], "UTF-8");
                        //过滤到html页面的空白字符
                        if (value.equals("&nbsp;")) {
                            value = "";
                        }
                        values[i] = value;
                        logger.debug(k + ":" + value + ",");
                    }
                }
            }
            logger.debug("--------页面传递参数---------");
            for (Field field : fields) {
                field.setAccessible(true);
                String fieldName = field.getName();
                String[] paraValues = (String[]) paraMap.get(fieldName);
                if (null == paraValues || paraValues.length <= 0) {
                    continue;
                }
                if (int.class.equals(field.getType())
                        || Integer.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("-?\\d+")) {
                        field.set(obj, new Integer(Integer.parseInt(param)));
//                        field.setInt(obj, Integer.parseInt(param));
                    }
                } else if (long.class.equals(field.getType())
                        || Long.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("-?\\d+")) {
                        field.set(obj, new Long(Long.parseLong(param)));
//                    	field.setLong(obj, lon.longValue());
                    }
                } else if (float.class.equals(field.getType())
                        || Float.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                        field.set(obj, new Float(Float.parseFloat(param)));
//                        field.setFloat(obj, Float.parseFloat(param));
                    }
                } else if (double.class.equals(field.getType())
                        || Double.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                        field.set(obj, new Double(Double.parseDouble(param)));
//                        field.setDouble(obj, Double.parseDouble(param));
                    }
                } else if (String.class.equals(field.getType())) {
                    String param = paraValues[0];
                    field.set(obj, param);
                } else if (Date.class.equals(field.getType())) {
                    String param = paraValues[0];
                    Date value = DateUtil.getDate(Long.parseLong(param));
                    field.set(obj, value);
                } else if (Timestamp.class.equals(field.getType())) {
                    String param = paraValues[0];
                    Date value = DateTimeUtil.getTime(param);
                    if (null != value) {
                        field.set(obj, new Timestamp(value.getTime()));
                    }
                } else if (boolean.class.equals(field.getType())
                        || Boolean.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                        field.set(obj, true);
                    }
                } else if (int[].class.equals(field.getType())
                        || Integer[].class.equals(field.getType())) {
                    Object array = Array.newInstance(int.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        int value = 0;
                        if (param != null && param.matches("-?\\d+")) {
                            value = Integer.parseInt(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (long[].class.equals(field.getType())
                        || Long[].class.equals(field.getType())) {
                    Object array = Array.newInstance(long.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        long value = 0;
                        if (param != null && param.matches("-?\\d+")) {
                            value = Long.parseLong(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (float[].class.equals(field.getType())
                        || Float[].class.equals(field.getType())) {
                    Object array = Array.newInstance(float.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        float value = 0;
                        if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                            value = Float.parseFloat(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (double[].class.equals(field.getType())
                        || Double[].class.equals(field.getType())) {
                    Object array = Array.newInstance(double.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        double value = 0;
                        if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                            value = Double.parseDouble(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (String[].class.equals(field.getType())) {
                    Object array = Array.newInstance(String.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Array.set(array, i, param == null ? "" : param);
                    }
                    field.set(obj, array);
                } else if (Date[].class.equals(field.getType())) {
                    Object array = Array.newInstance(Date.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Array.set(array, i, DateTimeUtil.getDate(param));
                    }
                    field.set(obj, array);
                } else if (Timestamp[].class.equals(field.getType())) {
                    Object array = Array.newInstance(Timestamp.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Date value = DateTimeUtil.getTime(param);
                        if (null != value) {
                            Array.set(array, i, new Timestamp(value.getTime()));
                        }
                    }
                    field.set(obj, array);
                } else if (boolean[].class.equals(field.getType())
                        || Boolean[].class.equals(field.getType())) {
                    Object array = Array.newInstance(boolean.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i] == null ? "" : paraValues[i];
                        boolean value = false;
                        if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                            value = true;
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if ("java.util.List".equals(field.getType().getName())
                        || "java.util.ArrayList".equals(field.getType().getName())
                        || "java.util.LinkedList".equals(field.getType().getName())) {
                    Type type = field.getGenericType();
                    int index1 = type.toString().indexOf("<");
                    int index2 = type.toString().indexOf(">");
                    String typeName = type.toString().substring(index1 + 1, index2);
                    if (typeName.contains("java.lang.Integer")) {
                        List<Integer> list = new ArrayList<Integer>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            int value = 0;
                            if (param != null && param.matches("-?\\d+")) {
                                value = Integer.parseInt(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Long")) {
                        List<Long> list = new ArrayList<Long>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            long value = 0;
                            if (param != null && param.matches("-?\\d+")) {
                                value = Long.parseLong(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Float")) {
                        List<Float> list = new ArrayList<Float>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            float value = 0;
                            if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                                value = Float.parseFloat(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Double")) {
                        List<Double> list = new ArrayList<Double>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            double value = 0;
                            if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                                value = Double.parseDouble(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.String")) {
                        List<String> list = new ArrayList<String>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            list.add(param == null ? "" : param);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.util.Date")) {
                        List<Date> list = new ArrayList<Date>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            list.add(DateTimeUtil.getDate(param));
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.sql.Timestamp")) {
                        List<Timestamp> list = new ArrayList<Timestamp>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            Date value = DateTimeUtil.getTime(param);
                            if (null != value) {
                                list.add(new Timestamp(value.getTime()));
                            }
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Boolean")) {
                        List<Boolean> list = new ArrayList<Boolean>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i] == null ? "" : paraValues[i];
                            boolean value = false;
                            if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                                value = true;
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }

    public static String getURLPart(String url) {
        if (url == null) {
            return url;
        }
        int index = url.lastIndexOf("/");
        if (index != -1) {
            url = url.substring(index + 1);
        }
        index = url.indexOf("?");
        if (index != -1) {
            url = url.substring(0, index);
        }
        //对于"referer:index.do;jsessionid=6CDD0B0F8D340D8268E92810CFD7A499"的情况,IE7
        index = url.indexOf(";");
        if (index != -1) {
            url = url.substring(0, index);
        }
        return url;
    }


    /**
     * 从Http请求中解析出指定前缀的Class
     *
     * @param qz      指定的前缀
     * @param clazz   需要解析为的Class
     * @param request Http请求
     * @return 解析后的Object
     */
    @SuppressWarnings("unchecked")
    public static Object getRequestBean(String qz, Class clazz, HttpServletRequest request) {
        Object obj = null;
        try {
            obj = clazz.newInstance();
            Field[] fields = clazz.getDeclaredFields();
            Map paraMap = request.getParameterMap();
            Set<String> key = paraMap.keySet();
            logger.debug("--------页面传递参数---------");
            for (Iterator it = key.iterator(); it.hasNext(); ) {
                String k = (String) it.next();
                if (k.indexOf(qz) != -1) {
                    Object valueObj = paraMap.get(k);
                    if (valueObj.getClass().getName().startsWith("[Ljava.lang.String")) {
                        String[] values = (String[]) valueObj;
                        for (int i = 0; i < values.length; i++) {
                            //统一将参数解码
                            String value = URLDecoder.decode(values[i], "UTF-8");
                            //过滤到html页面的空白字符
                            if (value.equals("&nbsp;")) {
                                value = "";
                            }
                            values[i] = value;
                            logger.debug(k + ":" + value + ",");
                        }
                    }
                }
            }
            logger.debug("--------页面传递参数---------");
            for (Field field : fields) {
                field.setAccessible(true);
                String fieldName = qz + "_" + field.getName();
                String[] paraValues = (String[]) paraMap.get(fieldName);
                if (null == paraValues || paraValues.length <= 0) {
                    continue;
                }
                if (int.class.equals(field.getType())
                        || Integer.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("-?\\d+")) {
                        field.setInt(obj, Integer.parseInt(param));
                    }
                } else if (long.class.equals(field.getType())
                        || Long.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("-?\\d+")) {
                        field.setLong(obj, Long.parseLong(param));
                    }
                } else if (float.class.equals(field.getType())
                        || Float.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                        field.setFloat(obj, Float.parseFloat(param));
                    }
                } else if (double.class.equals(field.getType())
                        || Double.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                        field.setDouble(obj, Double.parseDouble(param));
                    }
                } else if (String.class.equals(field.getType())) {
                    String param = paraValues[0];
                    field.set(obj, param);
                } else if (Date.class.equals(field.getType())) {
                    String param = paraValues[0];
                    Date value = DateUtil.getDate(Long.parseLong(param));
                    field.set(obj, value);
                } else if (Timestamp.class.equals(field.getType())) {
                    String param = paraValues[0];
                    Date value = DateTimeUtil.getTime(param);
                    if (null != value) {
                        field.set(obj, new Timestamp(value.getTime()));
                    }
                } else if (boolean.class.equals(field.getType())
                        || Boolean.class.equals(field.getType())) {
                    String param = paraValues[0];
                    if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                        field.set(obj, true);
                    }
                } else if (int[].class.equals(field.getType())
                        || Integer[].class.equals(field.getType())) {
                    Object array = Array.newInstance(int.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        int value = 0;
                        if (param != null && param.matches("-?\\d+")) {
                            value = Integer.parseInt(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (long[].class.equals(field.getType())
                        || Long[].class.equals(field.getType())) {
                    Object array = Array.newInstance(long.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        long value = 0;
                        if (param != null && param.matches("-?\\d+")) {
                            value = Long.parseLong(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (float[].class.equals(field.getType())
                        || Float[].class.equals(field.getType())) {
                    Object array = Array.newInstance(float.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        float value = 0;
                        if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                            value = Float.parseFloat(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (double[].class.equals(field.getType())
                        || Double[].class.equals(field.getType())) {
                    Object array = Array.newInstance(double.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        double value = 0;
                        if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                            value = Double.parseDouble(param);
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if (String[].class.equals(field.getType())) {
                    Object array = Array.newInstance(String.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Array.set(array, i, param == null ? "" : param);
                    }
                    field.set(obj, array);
                } else if (Date[].class.equals(field.getType())) {
                    Object array = Array.newInstance(Date.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Array.set(array, i, DateTimeUtil.getDate(param));
                    }
                    field.set(obj, array);
                } else if (Timestamp[].class.equals(field.getType())) {
                    Object array = Array.newInstance(Timestamp.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i];
                        Date value = DateTimeUtil.getTime(param);
                        if (null != value) {
                            Array.set(array, i, new Timestamp(value.getTime()));
                        }
                    }
                    field.set(obj, array);
                } else if (boolean[].class.equals(field.getType())
                        || Boolean[].class.equals(field.getType())) {
                    Object array = Array.newInstance(boolean.class, paraValues.length);
                    for (int i = 0; i < paraValues.length; i++) {
                        String param = paraValues[i] == null ? "" : paraValues[i];
                        boolean value = false;
                        if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                            value = true;
                        }
                        Array.set(array, i, value);
                    }
                    field.set(obj, array);
                } else if ("java.util.List".equals(field.getType().getName())
                        || "java.util.ArrayList".equals(field.getType().getName())
                        || "java.util.LinkedList".equals(field.getType().getName())) {
                    Type type = field.getGenericType();
                    int index1 = type.toString().indexOf("<");
                    int index2 = type.toString().indexOf(">");
                    String typeName = type.toString().substring(index1 + 1, index2);
                    if (typeName.contains("java.lang.Integer")) {
                        List<Integer> list = new ArrayList<Integer>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            int value = 0;
                            if (param != null && param.matches("-?\\d+")) {
                                value = Integer.parseInt(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Long")) {
                        List<Long> list = new ArrayList<Long>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            long value = 0;
                            if (param != null && param.matches("-?\\d+")) {
                                value = Long.parseLong(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Float")) {
                        List<Float> list = new ArrayList<Float>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            float value = 0;
                            if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                                value = Float.parseFloat(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Double")) {
                        List<Double> list = new ArrayList<Double>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            double value = 0;
                            if (param != null && param.matches("(-?\\d+)(\\.\\d*)?")) {
                                value = Double.parseDouble(param);
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.String")) {
                        List<String> list = new ArrayList<String>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            list.add(param == null ? "" : param);
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.util.Date")) {
                        List<Date> list = new ArrayList<Date>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            list.add(DateTimeUtil.getDate(param));
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.sql.Timestamp")) {
                        List<Timestamp> list = new ArrayList<Timestamp>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i];
                            Date value = DateTimeUtil.getTime(param);
                            if (null != value) {
                                list.add(new Timestamp(value.getTime()));
                            }
                        }
                        field.set(obj, list);
                    } else if (typeName.contains("java.lang.Boolean")) {
                        List<Boolean> list = new ArrayList<Boolean>();
                        for (int i = 0; i < paraValues.length; i++) {
                            String param = paraValues[i] == null ? "" : paraValues[i];
                            boolean value = false;
                            if (!"0".equals(param) || "true".equalsIgnoreCase(param)) {
                                value = true;
                            }
                            list.add(value);
                        }
                        field.set(obj, list);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }
}
