package com.xyb.order.pc.apply.already.service;

import java.util.List;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyListExportVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.apply.already.service
 * @description : 合同分配service
 * @createDate : 2018/5/23 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyAlreadyService {
	/**
	 * 申请已办
	 * @param pageNumber 分页信息
	 * @param pageSize 分页信息
	 * @param applyAlreadyQueryDTO 查询条件
	 * @return 返回页面展示数据
	 */
	RestResponse queryApplyAlreadys(Integer pageNumber, Integer pageSize,ApplyAlreadyQueryDTO applyAlreadyQueryDTO);

	/**
	 * 申请已办导出
	 * @param applyAlreadyQueryDTO 导出条件
	 * @return 返回导出内容
	 * @throws Exception 所有异常
	 */
	List<ApplyAlreadyListExportVO> applyAlreadyExport(ApplyAlreadyQueryDTO applyAlreadyQueryDTO) throws Exception;

	/**
	 * 申请已办-复议记录信息
	 * @param applyId 申请单ID
	 * @return 返回复议记录信息
	 */
	RestResponse applyAlreadyRreconsiderInfo(Long applyId);
}
