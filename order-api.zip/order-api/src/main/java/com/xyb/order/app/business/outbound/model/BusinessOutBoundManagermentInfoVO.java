package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 经营信息
 * @createDate : 2018/6/14 17:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundManagermentInfoVO implements IBaseModel {

	private static final long serialVersionUID = 514677713776165510L;

	private Long id;
	/**申请id*/
    private Long visitMainId;
    /**外访前经营公司名称*/
    private String managementCompNameOld;
    /**外访后经营公司名称*/
    private String managementCompName;
    /**外访后经营公司名称是否一致*/
    private Long isManagementCompNameSame;
    /**外访前经营公司电话*/
    private String managementCompTellOld;
	/**外访后经营公司电话区号*/
	private String managementCompTellArea;
    /**外访后经营公司电话*/
    private String managementCompTell;
    /**外访后经营公司电话是否一致*/
    private Long isManagementCompTellSame;
    /**经营公司省*/
    private Long managementCompAddrProvince;

	private String managementCompAddrProvinceStr;
    /**经营公司城市*/
    private Long managementCompAddrCity;

	private String managementCompAddrCityStr;
    /**经营公司区*/
    private Long managementCompAddrArea;

	private String managementCompAddrAreaStr;
    /**经营公司详细地址*/
    private String managementCompAddrDetail;
    /**经营类别（大类2726）*/
    private Long managementCategory;

	private String managementCategoryStr;
    /**经营类别其他(大类2726)*/
    private String managementCategoryQt;

    /**经营地剩余使用时间（大类2727）*/
    private Long managementPlaceRemainingTime;

	private String managementPlaceRemainingTimeStr;
    /**经营面积(大类2615)*/
    private Long managementAcreage;

	private String managementAcreageStr;
    /**经营证明(大类2728)*/
    private String businessCertificate;
    /**其他经营证明*/
    private String businessCertificateQt;
    /**存货品(大类2729)*/
    private Long goodsInStock;

	private String goodsInStockStr;
    /**当日在岗员工人数(大类2730)*/
    private Long currentStaffsOnDuty;

	private String currentStaffsOnDutyStr;

    private String remark;
    /**是否有效（大类2692）*/
    private Integer isValid;
    /**用来相同模块排序（同时插入时间区分不了显示位置）*/
    private Integer sort;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVisitMainId() {
        return visitMainId;
    }

    public void setVisitMainId(Long visitMainId) {
        this.visitMainId = visitMainId;
    }

    public String getManagementCompNameOld() {
        return managementCompNameOld;
    }

    public void setManagementCompNameOld(String managementCompNameOld) {
        this.managementCompNameOld = managementCompNameOld;
    }

    public String getManagementCompName() {
        return managementCompName;
    }

    public void setManagementCompName(String managementCompName) {
        this.managementCompName = managementCompName;
    }

    public Long getIsManagementCompNameSame() {
        return isManagementCompNameSame;
    }

    public void setIsManagementCompNameSame(Long isManagementCompNameSame) {
        this.isManagementCompNameSame = isManagementCompNameSame;
    }

    public String getManagementCompTellOld() {
        return managementCompTellOld;
    }

    public void setManagementCompTellOld(String managementCompTellOld) {
        this.managementCompTellOld = managementCompTellOld;
    }

    public String getManagementCompTellArea() {
        return managementCompTellArea;
    }

    public void setManagementCompTellArea(String managementCompTellArea) {
        this.managementCompTellArea = managementCompTellArea;
    }

    public String getManagementCompTell() {
        return managementCompTell;
    }

    public void setManagementCompTell(String managementCompTell) {
        this.managementCompTell = managementCompTell;
    }

    public Long getIsManagementCompTellSame() {
        return isManagementCompTellSame;
    }

    public void setIsManagementCompTellSame(Long isManagementCompTellSame) {
        this.isManagementCompTellSame = isManagementCompTellSame;
    }

    public Long getManagementCompAddrProvince() {
        return managementCompAddrProvince;
    }

    public void setManagementCompAddrProvince(Long managementCompAddrProvince) {
        this.managementCompAddrProvince = managementCompAddrProvince;
    }

    public String getManagementCompAddrProvinceStr() {
        return managementCompAddrProvinceStr;
    }

    public void setManagementCompAddrProvinceStr(String managementCompAddrProvinceStr) {
        this.managementCompAddrProvinceStr = managementCompAddrProvinceStr;
    }

    public Long getManagementCompAddrCity() {
        return managementCompAddrCity;
    }

    public void setManagementCompAddrCity(Long managementCompAddrCity) {
        this.managementCompAddrCity = managementCompAddrCity;
    }

    public String getManagementCompAddrCityStr() {
        return managementCompAddrCityStr;
    }

    public void setManagementCompAddrCityStr(String managementCompAddrCityStr) {
        this.managementCompAddrCityStr = managementCompAddrCityStr;
    }

    public Long getManagementCompAddrArea() {
        return managementCompAddrArea;
    }

    public void setManagementCompAddrArea(Long managementCompAddrArea) {
        this.managementCompAddrArea = managementCompAddrArea;
    }

    public String getManagementCompAddrAreaStr() {
        return managementCompAddrAreaStr;
    }

    public void setManagementCompAddrAreaStr(String managementCompAddrAreaStr) {
        this.managementCompAddrAreaStr = managementCompAddrAreaStr;
    }

    public String getManagementCompAddrDetail() {
        return managementCompAddrDetail;
    }

    public void setManagementCompAddrDetail(String managementCompAddrDetail) {
        this.managementCompAddrDetail = managementCompAddrDetail;
    }

    public Long getManagementCategory() {
        return managementCategory;
    }

    public void setManagementCategory(Long managementCategory) {
        this.managementCategory = managementCategory;
    }

    public String getManagementCategoryStr() {
        return managementCategoryStr;
    }

    public void setManagementCategoryStr(String managementCategoryStr) {
        this.managementCategoryStr = managementCategoryStr;
    }

    public String getManagementCategoryQt() {
        return managementCategoryQt;
    }

    public void setManagementCategoryQt(String managementCategoryQt) {
        this.managementCategoryQt = managementCategoryQt;
    }

    public Long getManagementPlaceRemainingTime() {
        return managementPlaceRemainingTime;
    }

    public void setManagementPlaceRemainingTime(Long managementPlaceRemainingTime) {
        this.managementPlaceRemainingTime = managementPlaceRemainingTime;
    }

    public String getManagementPlaceRemainingTimeStr() {
        return managementPlaceRemainingTimeStr;
    }

    public void setManagementPlaceRemainingTimeStr(String managementPlaceRemainingTimeStr) {
        this.managementPlaceRemainingTimeStr = managementPlaceRemainingTimeStr;
    }

    public Long getManagementAcreage() {
        return managementAcreage;
    }

    public void setManagementAcreage(Long managementAcreage) {
        this.managementAcreage = managementAcreage;
    }

    public String getManagementAcreageStr() {
        return managementAcreageStr;
    }

    public void setManagementAcreageStr(String managementAcreageStr) {
        this.managementAcreageStr = managementAcreageStr;
    }

    public String getBusinessCertificate() {
        return businessCertificate;
    }

    public void setBusinessCertificate(String businessCertificate) {
        this.businessCertificate = businessCertificate;
    }

    public String getBusinessCertificateQt() {
        return businessCertificateQt;
    }

    public void setBusinessCertificateQt(String businessCertificateQt) {
        this.businessCertificateQt = businessCertificateQt;
    }

    public Long getGoodsInStock() {
        return goodsInStock;
    }

    public void setGoodsInStock(Long goodsInStock) {
        this.goodsInStock = goodsInStock;
    }

    public String getGoodsInStockStr() {
        return goodsInStockStr;
    }

    public void setGoodsInStockStr(String goodsInStockStr) {
        this.goodsInStockStr = goodsInStockStr;
    }

    public Long getCurrentStaffsOnDuty() {
        return currentStaffsOnDuty;
    }

    public void setCurrentStaffsOnDuty(Long currentStaffsOnDuty) {
        this.currentStaffsOnDuty = currentStaffsOnDuty;
    }

    public String getCurrentStaffsOnDutyStr() {
        return currentStaffsOnDutyStr;
    }

    public void setCurrentStaffsOnDutyStr(String currentStaffsOnDutyStr) {
        this.currentStaffsOnDutyStr = currentStaffsOnDutyStr;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "BusinessOutBoundManagermentInfoVO{" +
                "id=" + id +
                ", visitMainId=" + visitMainId +
                ", managementCompNameOld='" + managementCompNameOld + '\'' +
                ", managementCompName='" + managementCompName + '\'' +
                ", isManagementCompNameSame=" + isManagementCompNameSame +
                ", managementCompTellOld='" + managementCompTellOld + '\'' +
                ", managementCompTellArea='" + managementCompTellArea + '\'' +
                ", managementCompTell='" + managementCompTell + '\'' +
                ", isManagementCompTellSame=" + isManagementCompTellSame +
                ", managementCompAddrProvince=" + managementCompAddrProvince +
                ", managementCompAddrProvinceStr='" + managementCompAddrProvinceStr + '\'' +
                ", managementCompAddrCity=" + managementCompAddrCity +
                ", managementCompAddrCityStr='" + managementCompAddrCityStr + '\'' +
                ", managementCompAddrArea=" + managementCompAddrArea +
                ", managementCompAddrAreaStr='" + managementCompAddrAreaStr + '\'' +
                ", managementCompAddrDetail='" + managementCompAddrDetail + '\'' +
                ", managementCategory=" + managementCategory +
                ", managementCategoryStr='" + managementCategoryStr + '\'' +
                ", managementCategoryQt='" + managementCategoryQt + '\'' +
                ", managementPlaceRemainingTime=" + managementPlaceRemainingTime +
                ", managementPlaceRemainingTimeStr='" + managementPlaceRemainingTimeStr + '\'' +
                ", managementAcreage=" + managementAcreage +
                ", managementAcreageStr='" + managementAcreageStr + '\'' +
                ", businessCertificate='" + businessCertificate + '\'' +
                ", businessCertificateQt='" + businessCertificateQt + '\'' +
                ", goodsInStock=" + goodsInStock +
                ", goodsInStockStr='" + goodsInStockStr + '\'' +
                ", currentStaffsOnDuty=" + currentStaffsOnDuty +
                ", currentStaffsOnDutyStr='" + currentStaffsOnDutyStr + '\'' +
                ", remark='" + remark + '\'' +
                ", isValid=" + isValid +
                ", sort=" + sort +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
