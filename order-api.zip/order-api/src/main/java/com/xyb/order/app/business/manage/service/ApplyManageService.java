package com.xyb.order.app.business.manage.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.business.manage.model.ApplyBillInfoDTO;
import com.xyb.order.app.business.manage.model.ApplyCustomerInfoDTO;

/**
 * @ClassName ApplyManageService
 * @author ZhangYu
 * @date 2018年6月13号
 */
public interface ApplyManageService {
	
	/**
	 *  获取客户经理的所有客户信息
	 * @return
	 */
	RestResponse getCustomerList(ApplyCustomerInfoDTO applyCustomerInfoDTO) throws Exception;
	
	/**
	 * 获取客户经理的所有申请单信息 
	 * @return
	 * @throws Exception
	 */
	RestResponse getApplyBillInfoList(ApplyBillInfoDTO applyBillInfoDTO) throws Exception;
	

	/**
	 * 获取客户经理申请单详情信息 
	 * @return
	 * @throws Exception
	 */
	RestResponse getApplyBillDetailInfo(Long applyId) throws Exception;

}
