package com.xyb.order.pc.contract.model;

import javax.validation.constraints.NotNull;


import com.beiming.kun.framework.model.IBaseModel;

public class XybContractDetailDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 839848581707952864L;
	@NotNull(message = "申请id不能为空")
	private Long applyId;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Override
	public String toString() {
		return "XybContractDetailDTO [applyId=" + applyId + "]";
	}

}
