package com.xyb.order.common.material.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class FileDataInfo implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Long id; // id
	private Long applyId; // 申请单id
	private String name; //图片名称
	private String desc; //描述
	private Long fileClassificationId;//文件分类ID
	private String picPath;//文件地址
	private String picGroup;//组
	private Integer sort;// 排序
	private String fileName;//图片真实名称
	private String compressPath;//缩略图地址
	private Long operatorId; //操作人ID
	private Date createTime;//
	private Long createUser;
	private Date modifyTime;
	private Long modifyUser;
	/**是否可删除*/
	private Long isDel;

	private String uploadState;//上传状态
	
	public String getPicGroup() {
		return picGroup;
	}
	public void setPicGroup(String picGroup) {
		this.picGroup = picGroup;
	}
	public String getUploadState() {
		return uploadState;
	}
	public void setUploadState(String uploadState) {
		this.uploadState = uploadState;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Long getFileClassificationId() {
		return fileClassificationId;
	}
	public void setFileClassificationId(Long fileClassificationId) {
		this.fileClassificationId = fileClassificationId;
	}
	public String getPicPath() {
		return picPath;
	}
	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getCompressPath() {
		return compressPath;
	}
	public void setCompressPath(String compressPath) {
		this.compressPath = compressPath;
	}
	public Long getOperatorId() {
		return operatorId;
	}
	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Long getIsDel() {
		return isDel;
	}

	public void setIsDel(Long isDel) {
		this.isDel = isDel;
	}
}
