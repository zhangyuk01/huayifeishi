package com.xyb.order.pc.applybill.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyClientAbandonDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id; //客户放弃ID
	@NotNull(message = "申请表主键ID不能为空")
	private Long mainId;//申请主表ID
	private Long isClientAbandon;
	private String label;//客户放弃原因

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getIsClientAbandon() {
		return isClientAbandon;
	}
	public void setIsClientAbandon(Long isClientAbandon) {
		this.isClientAbandon = isClientAbandon;
	}
	

}
