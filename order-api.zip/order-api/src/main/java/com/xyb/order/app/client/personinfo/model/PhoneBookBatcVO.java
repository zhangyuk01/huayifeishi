package com.xyb.order.app.client.personinfo.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 批次/日志实体类
 * 
 * @author qiaoJinLong
 * @date 2018年9月11日
 */
public class PhoneBookBatcVO implements IBaseModel {

	private static final long serialVersionUID = -5381981437287504088L;

	private Long batchNum;

	private Long clientId;// 客户ID

	private String phoneType;// 手机型号

	private Integer shouldQty;// 客户通讯录总条数

	@Override
	public String toString() {
		return "PhoneBookBatcVO [batchNum=" + batchNum + ", clientId=" + clientId + ", phoneType=" + phoneType
				+ ", shouldQty=" + shouldQty + "]";
	}

	public Integer getShouldQty() {
		return shouldQty;
	}

	public void setShouldQty(Integer shouldQty) {
		this.shouldQty = shouldQty;
	}

	public Long getBatchNum() {
		return batchNum;
	}

	public void setBatchNum(Long batchNum) {
		this.batchNum = batchNum;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

}
