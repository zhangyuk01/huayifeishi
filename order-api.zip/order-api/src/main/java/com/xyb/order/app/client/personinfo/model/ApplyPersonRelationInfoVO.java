package com.xyb.order.app.client.personinfo.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonRelationInfoVO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private PersonBaseRelationInfoDO personBaseRelationInfoDO;
	private List<LinkManRelationInfoDO> familLinkManInfos;
	private List<LinkManRelationInfoDO> workLinkManInfos;
	private List<LinkManRelationInfoDO> urgetLinkManInfos;

	public PersonBaseRelationInfoDO getPersonBaseRelationInfoDO() {
		return personBaseRelationInfoDO;
	}
	public void setPersonBaseRelationInfoDO(PersonBaseRelationInfoDO personBaseRelationInfoDO) {
		this.personBaseRelationInfoDO = personBaseRelationInfoDO;
	}
	public List<LinkManRelationInfoDO> getFamilLinkManInfos() {
		return familLinkManInfos;
	}
	public void setFamilLinkManInfos(List<LinkManRelationInfoDO> familLinkManInfos) {
		this.familLinkManInfos = familLinkManInfos;
	}
	public List<LinkManRelationInfoDO> getWorkLinkManInfos() {
		return workLinkManInfos;
	}
	public void setWorkLinkManInfos(List<LinkManRelationInfoDO> workLinkManInfos) {
		this.workLinkManInfos = workLinkManInfos;
	}
	public List<LinkManRelationInfoDO> getUrgetLinkManInfos() {
		return urgetLinkManInfos;
	}
	public void setUrgetLinkManInfos(List<LinkManRelationInfoDO> urgetLinkManInfos) {
		this.urgetLinkManInfos = urgetLinkManInfos;
	}
	
}
