package com.xyb.order.pc.contract.contracttb.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractTbDO implements IBaseModel {



	/**
	 * 
	 */
	private static final long serialVersionUID = -9064314292449778278L;

	private String applyId;// 申请ID
	private String productName;// 产品名称
	private int productLimit;// 审批期限
	private BigDecimal contractAmount;// 合同金额
	private String borrowDesc;// 借款用途
	private BigDecimal serviceFee;// 服务费
	private String gender;// 性别
	private String birthday;
	private String householdRegister;// 户籍地址 省市区
	private String education;// 学历
	private String marriage;// 婚姻状况
	private String children;// 子女状况
    private String jobType;
	private String xybScore;// 借款人信用宝评分
	private String incomeCity;// 进件城市
	private String saleManager;//销售经理
	private String applyDate;// 申请日期
	private String incomeLevel;// 月收入水平
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductLimit() {
		return productLimit;
	}
	public void setProductLimit(int productLimit) {
		this.productLimit = productLimit;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public String getBorrowDesc() {
		return borrowDesc;
	}
	public void setBorrowDesc(String borrowDesc) {
		this.borrowDesc = borrowDesc;
	}
	public BigDecimal getServiceFee() {
		return serviceFee;
	}
	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getHouseholdRegister() {
		return householdRegister;
	}
	public void setHouseholdRegister(String householdRegister) {
		this.householdRegister = householdRegister;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getMarriage() {
		return marriage;
	}
	public void setMarriage(String marriage) {
		this.marriage = marriage;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getXybScore() {
		return xybScore;
	}
	public void setXybScore(String xybScore) {
		this.xybScore = xybScore;
	}
	public String getIncomeCity() {
		return incomeCity;
	}
	public void setIncomeCity(String incomeCity) {
		this.incomeCity = incomeCity;
	}
	public String getSaleManager() {
		return saleManager;
	}
	public void setSaleManager(String saleManager) {
		this.saleManager = saleManager;
	}
	public String getApplyDate() {
		return applyDate;
	}
	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}
	public String getIncomeLevel() {
		return incomeLevel;
	}
	public void setIncomeLevel(String incomeLevel) {
		this.incomeLevel = incomeLevel;
	}
	@Override
	public String toString() {
		return "XybContractTbDO [applyId=" + applyId + ", productName=" + productName + ", productLimit=" + productLimit
				+ ", contractAmount=" + contractAmount + ", borrowDesc=" + borrowDesc + ", serviceFee=" + serviceFee
				+ ", gender=" + gender + ", birthday=" + birthday + ", householdRegister=" + householdRegister
				+ ", education=" + education + ", marriage=" + marriage + ", children=" + children + ", jobType="
				+ jobType + ", xybScore=" + xybScore + ", incomeCity=" + incomeCity + ", saleManager=" + saleManager
				+ ", applyDate=" + applyDate + ", incomeLevel=" + incomeLevel + "]";
	}


}
