package com.xyb.order.pc.contract.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 接口日志记录数据对象
 * @createDate : 2018/03/28 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class InterfaceLogDO implements IBaseModel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1619254442113870197L;
	private long id; // 主键
    private String interface_name; // 接口名称
    private long apply_id; // 申请id
	/**用户表ID*/
	private long clientId;
    private String apply_num; // 申请单号
    private String invocation; // 调用方式大类2765
    private String request; // 请求参数
    private String response; // 响应
    private String remote_ip; // 远程地址IP
    private Date create_time;//创建时间
    private String create_user;//创建人
    private long state; //是否成功（大类2692）
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getInterface_name() {
		return interface_name;
	}
	public void setInterface_name(String interface_name) {
		this.interface_name = interface_name;
	}
	public long getApply_id() {
		return apply_id;
	}
	public void setApply_id(long apply_id) {
		this.apply_id = apply_id;
	}
	public String getApply_num() {
		return apply_num;
	}
	public void setApply_num(String apply_num) {
		this.apply_num = apply_num;
	}
	public String getInvocation() {
		return invocation;
	}
	public void setInvocation(String invocation) {
		this.invocation = invocation;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getRemote_ip() {
		return remote_ip;
	}
	public void setRemote_ip(String remote_ip) {
		this.remote_ip = remote_ip;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public String getCreate_user() {
		return create_user;
	}
	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}
	public long getState() {
		return state;
	}
	public void setState(long state) {
		this.state = state;
	}

	public long getClientId() {
		return clientId;
	}

	public void setClientId(long clientId) {
		this.clientId = clientId;
	}

	@Override
	public String toString() {
		return "InterfaceLogDO{" +
				"id=" + id +
				", interface_name='" + interface_name + '\'' +
				", apply_id=" + apply_id +
				", clientId=" + clientId +
				", apply_num='" + apply_num + '\'' +
				", invocation='" + invocation + '\'' +
				", request='" + request + '\'' +
				", response='" + response + '\'' +
				", remote_ip='" + remote_ip + '\'' +
				", create_time=" + create_time +
				", create_user='" + create_user + '\'' +
				", state=" + state +
				'}';
	}
}
