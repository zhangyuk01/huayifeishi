package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * @description:    APP消息推送明细表
 * @author:         xieqingyang
 * @createDate:     2018/6/25 下午7:40
*/
public class AppNoticeDetailsDO implements IBaseModel {

    private static final long serialVersionUID = -6867561536291990954L;
    /**主键ID*/
    private Long id;
    /**APP消息模版表ID*/
    private Long mainId;
    /**用户登录信息表ID*/
    private Long userId;
    /**姓名*/
    private String name;
    /**手机号*/
    private String phone;
    /**推送唯一标识*/
    private String deviceToken;
    /**是否已读（大类2692）*/
    private Long state;
    /**标题*/
    private String title;
    /**内容*/
    private String content;
    /**访问连接*/
    private String url;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "AppNoticeDetailsDO{" +
                "id=" + id +
                ", mainId=" + mainId +
                ", userId=" + userId +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", deviceToken='" + deviceToken + '\'' +
                ", state=" + state +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", url='" + url + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
