package com.xyb.order.pc.outbound.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访已办列表页VO  model
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundAlreadyListVO implements IBaseModel {

	/**
	 * 
	 */
	private static final Long serialVersionUID = 78717020163558387L;

	private Long applyId;
	/**申请编号*/
	private String applyNum;
	/**进件机构名称*/
	private String orgName;
	/**客户姓名*/
	private String custName;
	/**手机号码*/
	private String phone;
	/**销售团队*/
	private String saleTeamName;
	/**团队经理*/
	private String teamManagerName;
	/**销售人员*/
	private String saleName;
	/**申请产品*/
	private String applyProductName;
	/**一级授信产品*/
	private String auditEndProductName;
	/**外访类型*/
	private String visitTypeName;
	/**外访返回时间*/
	private Date visitBackDate;
	/**实地外访时间*/
	private Date creditDate;
	/**产调外访时间*/
	private Date visitIndustryDate;
	/**征信负责人*/
	private String visitUidName;
	/**合同生效日期*/
	private Date contractEffectDate;
	/**合同状态*/
	private String contractState;
	/**外访要求*/
	private String visitDemand;
	/**推荐人姓名*/
	private String recommender;
	@JsonIgnore
	private Integer stateCode;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSaleTeamName() {
		return saleTeamName;
	}
	public void setSaleTeamName(String saleTeamName) {
		this.saleTeamName = saleTeamName;
	}
	public String getTeamManagerName() {
		return teamManagerName;
	}
	public void setTeamManagerName(String teamManagerName) {
		this.teamManagerName = teamManagerName;
	}
	public String getSaleName() {
		return saleName;
	}
	public void setSaleName(String saleName) {
		this.saleName = saleName;
	}
	public String getApplyProductName() {
		return applyProductName;
	}
	public void setApplyProductName(String applyProductName) {
		this.applyProductName = applyProductName;
	}
	public String getAuditEndProductName() {
		return auditEndProductName;
	}
	public void setAuditEndProductName(String auditEndProductName) {
		this.auditEndProductName = auditEndProductName;
	}
	public String getVisitTypeName() {
		return visitTypeName;
	}
	public void setVisitTypeName(String visitTypeName) {
		this.visitTypeName = visitTypeName;
	}
	public Date getVisitBackDate() {
		return visitBackDate;
	}
	public void setVisitBackDate(Date visitBackDate) {
		this.visitBackDate = visitBackDate;
	}
	public Date getCreditDate() {
		return creditDate;
	}
	public void setCreditDate(Date creditDate) {
		this.creditDate = creditDate;
	}
	public Date getVisitIndustryDate() {
		return visitIndustryDate;
	}
	public void setVisitIndustryDate(Date visitIndustryDate) {
		this.visitIndustryDate = visitIndustryDate;
	}
	public String getVisitUidName() {
		return visitUidName;
	}
	public void setVisitUidName(String visitUidName) {
		this.visitUidName = visitUidName;
	}
	public Date getContractEffectDate() {
		return contractEffectDate;
	}
	public void setContractEffectDate(Date contractEffectDate) {
		this.contractEffectDate = contractEffectDate;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getVisitDemand() {
		return visitDemand;
	}
	public void setVisitDemand(String visitDemand) {
		this.visitDemand = visitDemand;
	}

	public Integer getStateCode() {
		return stateCode;
	}

	public void setStateCode(Integer stateCode) {
		this.stateCode = stateCode;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	@Override
	public String toString() {
		return "OutBoundAlreadyListVO{" +
				"applyId=" + applyId +
				", applyNum='" + applyNum + '\'' +
				", orgName='" + orgName + '\'' +
				", custName='" + custName + '\'' +
				", phone='" + phone + '\'' +
				", saleTeamName='" + saleTeamName + '\'' +
				", teamManagerName='" + teamManagerName + '\'' +
				", saleName='" + saleName + '\'' +
				", applyProductName='" + applyProductName + '\'' +
				", auditEndProductName='" + auditEndProductName + '\'' +
				", visitTypeName='" + visitTypeName + '\'' +
				", visitBackDate=" + visitBackDate +
				", creditDate=" + creditDate +
				", visitIndustryDate=" + visitIndustryDate +
				", visitUidName='" + visitUidName + '\'' +
				", contractEffectDate=" + contractEffectDate +
				", contractState='" + contractState + '\'' +
				", visitDemand='" + visitDemand + '\'' +
				", recommender='" + recommender + '\'' +
				", stateCode=" + stateCode +
				'}';
	}
}
