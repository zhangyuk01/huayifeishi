package com.xyb.order.pc.creditreport.model;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditVerifyDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Long id; //主键ID
	private Long applyId;//申请单ID
	private Long clientId;//客户ID
	private String workPhone;//单位电话
	private Long workPhoneVerify;//是否核实 
	private String workPhoneResource;//电话来源
	private String workPhoneRemark;//电话核实到相关工作信息
	private Long spouse;//配偶
	private Long workWitness;//工作证明人是否核实
	private Long urgentLinkman1;//紧急联系人是否核实
	private Long urgentLinkman2;//紧急联系人2是否核实
	private Long personallyCompany;//是否亲访单位
	private Long personallyFamily;//是否亲访家庭
	private Long courtImplement;//法院执行信息
	private Long creditInvestigation;//征信是否正常
	private Long businessCircles;//工商是否正常
	private Long callRecord;//通话记录是否正常
	private String salesman;//业务员备注信息
	private String customerService;//客服备注
	

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getClientId() {
		return clientId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	public Long getWorkPhoneVerify() {
		return workPhoneVerify;
	}
	public void setWorkPhoneVerify(Long workPhoneVerify) {
		this.workPhoneVerify = workPhoneVerify;
	}
	public String getWorkPhoneResource() {
		return workPhoneResource;
	}
	public void setWorkPhoneResource(String workPhoneResource) {
		this.workPhoneResource = workPhoneResource;
	}
	public String getWorkPhoneRemark() {
		return workPhoneRemark;
	}
	public void setWorkPhoneRemark(String workPhoneRemark) {
		this.workPhoneRemark = workPhoneRemark;
	}
	public Long getSpouse() {
		return spouse;
	}
	public void setSpouse(Long spouse) {
		this.spouse = spouse;
	}
	public Long getWorkWitness() {
		return workWitness;
	}
	public void setWorkWitness(Long workWitness) {
		this.workWitness = workWitness;
	}
	public Long getUrgentLinkman1() {
		return urgentLinkman1;
	}
	public void setUrgentLinkman1(Long urgentLinkman1) {
		this.urgentLinkman1 = urgentLinkman1;
	}
	public Long getUrgentLinkman2() {
		return urgentLinkman2;
	}
	public void setUrgentLinkman2(Long urgentLinkman2) {
		this.urgentLinkman2 = urgentLinkman2;
	}
	public Long getPersonallyCompany() {
		return personallyCompany;
	}
	public void setPersonallyCompany(Long personallyCompany) {
		this.personallyCompany = personallyCompany;
	}
	public Long getPersonallyFamily() {
		return personallyFamily;
	}
	public void setPersonallyFamily(Long personallyFamily) {
		this.personallyFamily = personallyFamily;
	}
	public Long getCourtImplement() {
		return courtImplement;
	}
	public void setCourtImplement(Long courtImplement) {
		this.courtImplement = courtImplement;
	}
	public Long getCreditInvestigation() {
		return creditInvestigation;
	}
	public void setCreditInvestigation(Long creditInvestigation) {
		this.creditInvestigation = creditInvestigation;
	}
	public Long getBusinessCircles() {
		return businessCircles;
	}
	public void setBusinessCircles(Long businessCircles) {
		this.businessCircles = businessCircles;
	}
	public Long getCallRecord() {
		return callRecord;
	}
	public void setCallRecord(Long callRecord) {
		this.callRecord = callRecord;
	}
	public String getSalesman() {
		return salesman;
	}
	public void setSalesman(String salesman) {
		this.salesman = salesman;
	}
	public String getCustomerService() {
		return customerService;
	}
	public void setCustomerService(String customerService) {
		this.customerService = customerService;
	}
}
