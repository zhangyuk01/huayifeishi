package com.xyb.order.pc.contract.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同重新分配model
 * @createDate : 2018/05/14 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAllocationDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5591352949988002885L;
	/**合同分配人员id*/
	private long userId;
	/**需要分配申请id集合*/
	private List<Long> applyIds;
	/**A:合同重新分配  B:合同审核重新分配*/
	private String type;
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public List<Long> getApplyIds() {
		return applyIds;
	}
	public void setApplyIds(List<Long> applyIds) {
		this.applyIds = applyIds;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "XybContractAllocationDTO [userId=" + userId + ", applyIds=" + applyIds + ", type=" + type + "]";
	}

}
