package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.common.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xieqingyang on 17/6/11.
 * 融360需要的model
 */
public class RongBizData implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**jd,mobile,ec,ibank,chsi,insure,fund,mobile_crawl*/
    private String type;
    /**请求的平台，可取值范围是api,web*/
    private String platform = "web";
    /**姓名，报告必传*/
    private String name;
    /**手机号(运营商报告请与传给抓取服务的手机号一致),报告必传*/
    private String phone;
    /**身份证号码，报告必传*/
    private String idNumber;
    /**调用方生成的用户ID*/
    private String userId;
    /**调用方生成的会话唯一标识id，建议使用流水号生成*/
    private String outUniqueId;
    /**服务器异步通知页面路径*/
    private String notifyUrl;
    /**页面跳转同步通知页面路径*/
    private String returnUrl;
    /**抓取的账户名*/
    private String account;
    /**家庭住址*/
    private String homeAddr;
    /**工作地址*/
    private String companyAddr;
    /**银行名称，传入银行中文名，type=ibank时为必传项*/
    private String bankType;
    /**银行卡号，type=ibank时为必传项*/
    private String bankCard;
    /**H5回退链接地址*/
    private String backUrl;
    /**城市代码（仅在type为insure或fund时有效，填入后跳过城市选择页面）*/
    private String cityCode;

    public Map<String, Object> getMap(){
        Map<String, Object> bizData = new HashMap<>();
        if (StringUtils.isNotNullAndEmpty(this.type)){
            bizData.put("type",this.type);
        }
        if (StringUtils.isNotNullAndEmpty(this.platform)){
            bizData.put("platform",this.platform);
        }
        if (StringUtils.isNotNullAndEmpty(this.name)){
            bizData.put("name",this.name);
        }
        if (StringUtils.isNotNullAndEmpty(this.phone)){
            bizData.put("phone",this.phone);
        }
        if (StringUtils.isNotNullAndEmpty(this.idNumber)){
            bizData.put("idNumber",this.idNumber);
        }
        if (StringUtils.isNotNullAndEmpty(this.userId)){
            bizData.put("userId",this.userId);
        }
        if (StringUtils.isNotNullAndEmpty(this.outUniqueId)){
            bizData.put("outUniqueId",this.outUniqueId);
        }
        if (StringUtils.isNotNullAndEmpty(this.notifyUrl)){
            bizData.put("notifyUrl",this.notifyUrl);
        }
        if (StringUtils.isNotNullAndEmpty(this.returnUrl)){
            bizData.put("returnUrl",this.returnUrl);
        }
        if (StringUtils.isNotNullAndEmpty(this.backUrl)){
            bizData.put("backUrl",this.backUrl);
        }
        if (StringUtils.isNotNullAndEmpty(this.cityCode)){
            bizData.put("cityCode",this.cityCode);
        }
        if (StringUtils.isNotNullAndEmpty(this.account)){
            bizData.put("account",this.account);
        }
        if (StringUtils.isNotNullAndEmpty(this.homeAddr)){
            bizData.put("homeAddr",this.homeAddr);
        }
        if (StringUtils.isNotNullAndEmpty(this.companyAddr)){
            bizData.put("companyAddr",this.companyAddr);
        }
        if (StringUtils.isNotNullAndEmpty(this.bankCard)){
            bizData.put("bankCard",this.bankCard);
        }
        if (StringUtils.isNotNullAndEmpty(this.bankType)){
            bizData.put("bankType",this.bankType);
        }
        return  bizData;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOutUniqueId() {
        return outUniqueId;
    }

    public void setOutUniqueId(String outUniqueId) {
        this.outUniqueId = outUniqueId;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getHomeAddr() {
        return homeAddr;
    }

    public void setHomeAddr(String homeAddr) {
        this.homeAddr = homeAddr;
    }

    public String getCompanyAddr() {
        return companyAddr;
    }

    public void setCompanyAddr(String companyAddr) {
        this.companyAddr = companyAddr;
    }

    public String getBankType() {
        return bankType;
    }

    public void setBankType(String bankType) {
        this.bankType = bankType;
    }

    public String getBankCard() {
        return bankCard;
    }

    public void setBankCard(String bankCard) {
        this.bankCard = bankCard;
    }

    public String getBackUrl() {
        return backUrl;
    }

    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }
}
