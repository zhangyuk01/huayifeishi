package com.xyb.order.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
* @description:    身份证相关工具类
* @author:         xieqingyang
* @createDate:     2018/5/15 下午7:29
*/
public class IdCardUtil {

    /**
     * 判断是否成年
     * @author      xieqingyang
     * @param num
     * @return
     * @exception
     * @date        2018/5/15 下午4:41
     */
    public static boolean ifGrownUp(String num) throws ParseException {
        int year = Integer.parseInt(num.substring(6, 10));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date update = sdf.parse(String.valueOf(year + 18) + num.substring(10, 14));
        Date today = sdf.parse(sdf.format(new Date()));
        return today.after(update);
    }

    /**
     * 判断身份证的生日是否与传入生日一致
     */
    public static boolean ansysic(String num,String birthday){
        String b = num.substring(6,14);
        birthday = birthday.replaceAll("-","");
        if (b.equals(birthday)){
            return true;
        }else {
            return false;
        }
    }

    /**
     * 根据身份证号获得年龄
     * @author      xieqingyang
     * @param num
     * @return
     * @exception
     * @date        2018/5/15 下午7:20
     */
    public static int IdNOToAge(String num){
        int leh = num.length();
        String dates="";
        if (leh == 18) {
            dates = num.substring(6, 10);
            SimpleDateFormat df = new SimpleDateFormat("yyyy");
            String year=df.format(new Date());
            int u=Integer.parseInt(year)-Integer.parseInt(dates);
            return u;
        }else{
            dates = num.substring(6, 8);
            return Integer.parseInt(dates);
        }
    }

    public static String getSex(String idCard){
        // 获取性别
        String id17 = idCard.substring(16, 17);
        if (Integer.parseInt(id17) % 2 != 0) {
            return "男";
        } else {
            return "女";
        }
    }

    public static String getSexShzx(String idCard){
        // 获取性别
        String id17 = idCard.substring(16, 17);
        if (Integer.parseInt(id17) % 2 != 0) {
            return "1";
        } else {
            return "2";
        }
    }

    /**
    * 判断身份证是否在有效期
    * @author      xieqingyang
    * @param idCardEndTime
    * @return
    * @exception
    * @date        2018/5/16 上午10:41
    */
    public static boolean validationIdCard(Date idCardEndTime) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date today = sdf.parse(sdf.format(new Date()));
        return today.after(idCardEndTime);
    }
}
