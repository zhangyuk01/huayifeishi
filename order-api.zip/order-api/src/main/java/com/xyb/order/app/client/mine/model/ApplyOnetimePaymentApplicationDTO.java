package com.xyb.order.app.client.mine.model;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyOnetimePaymentApplicationDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	@NotNull(message="合同ID不能为空")
	private Long contractId;
	private List<ApplyOnetimePaymentApplicationDetailDO> calculateList;

	public Long getContractId() {
		return contractId;
	}

	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}

	public List<ApplyOnetimePaymentApplicationDetailDO> getCalculateList() {
		return calculateList;
	}

	public void setCalculateList(List<ApplyOnetimePaymentApplicationDetailDO> calculateList) {
		this.calculateList = calculateList;
	}
	
}
