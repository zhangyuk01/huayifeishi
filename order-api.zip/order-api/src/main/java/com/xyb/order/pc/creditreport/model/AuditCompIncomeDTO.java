package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class AuditCompIncomeDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Long id;//ID
	private Long custId;//客户ID
	private Long applyId;//申请单ID
	private String publicLogAccount;//对公流水账户名
	private Date publicLogsDate;//对公流水开具日期
	private Date publicLogsDateStart;//对公流水起于
	private Date publicLogsDateEnd;//对公流水止于
	private String card;//卡号
	private Long cardType;//流水类型
	private String cardTypeStr;
	private Double fundMonth0;//企业资金流水当月
	private Double fundMonth1;//企业资金流水往前1个月
	private Double fundMonth2;//企业资金流水往前2个月
	private Double fundMonth3;//企业资金流水往前3个月
	private Double fundMonth4;//企业资金流水往前4个月
	private Double fundMonth5;//企业资金流水往前5个月
	private Double publicAverage;//对公平均流水
	private String publicRemark;//对公流水备注
	
	private Long isDelState;//
	private String isDelStateStr;
	@JsonIgnore	
	private Date createTime;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Date modifyTime;
	@JsonIgnore
	private Long modifyUser;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getPublicLogAccount() {
		return publicLogAccount;
	}
	public void setPublicLogAccount(String publicLogAccount) {
		this.publicLogAccount = publicLogAccount;
	}
	public Date getPublicLogsDate() {
		return publicLogsDate;
	}
	public void setPublicLogsDate(Date publicLogsDate) {
		this.publicLogsDate = publicLogsDate;
	}
	public Date getPublicLogsDateStart() {
		return publicLogsDateStart;
	}
	public void setPublicLogsDateStart(Date publicLogsDateStart) {
		this.publicLogsDateStart = publicLogsDateStart;
	}
	public Date getPublicLogsDateEnd() {
		return publicLogsDateEnd;
	}
	public void setPublicLogsDateEnd(Date publicLogsDateEnd) {
		this.publicLogsDateEnd = publicLogsDateEnd;
	}
	public String getCard() {
		return card;
	}
	public void setCard(String card) {
		this.card = card;
	}
	public Long getCardType() {
		return cardType;
	}
	public void setCardType(Long cardType) {
		this.cardType = cardType;
	}
	public String getCardTypeStr() {
		return cardTypeStr;
	}
	public void setCardTypeStr(String cardTypeStr) {
		this.cardTypeStr = cardTypeStr;
	}
	public Double getFundMonth0() {
		return fundMonth0;
	}
	public void setFundMonth0(Double fundMonth0) {
		this.fundMonth0 = fundMonth0;
	}
	public Double getFundMonth1() {
		return fundMonth1;
	}
	public void setFundMonth1(Double fundMonth1) {
		this.fundMonth1 = fundMonth1;
	}
	public Double getFundMonth2() {
		return fundMonth2;
	}
	public void setFundMonth2(Double fundMonth2) {
		this.fundMonth2 = fundMonth2;
	}
	public Double getFundMonth3() {
		return fundMonth3;
	}
	public void setFundMonth3(Double fundMonth3) {
		this.fundMonth3 = fundMonth3;
	}
	public Double getFundMonth4() {
		return fundMonth4;
	}
	public void setFundMonth4(Double fundMonth4) {
		this.fundMonth4 = fundMonth4;
	}
	public Double getFundMonth5() {
		return fundMonth5;
	}
	public void setFundMonth5(Double fundMonth5) {
		this.fundMonth5 = fundMonth5;
	}
	public Double getPublicAverage() {
		return publicAverage;
	}
	public void setPublicAverage(Double publicAverage) {
		this.publicAverage = publicAverage;
	}
	public String getPublicRemark() {
		return publicRemark;
	}
	public void setPublicRemark(String publicRemark) {
		this.publicRemark = publicRemark;
	}
	public Long getIsDelState() {
		return isDelState;
	}
	public void setIsDelState(Long isDelState) {
		this.isDelState = isDelState;
	}
	public String getIsDelStateStr() {
		return isDelStateStr;
	}
	public void setIsDelStateStr(String isDelStateStr) {
		this.isDelStateStr = isDelStateStr;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

}
