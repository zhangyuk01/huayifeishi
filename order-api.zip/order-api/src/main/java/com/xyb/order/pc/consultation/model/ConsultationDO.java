package com.xyb.order.pc.consultation.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 咨询列表信息
 * @author         xieqingyang
 * @date           2018/10/16 3:04 PM
*/
public class ConsultationDO implements IBaseModel{

    private static final long serialVersionUID = 1L;
    /**申请表id*/
    private Long applyId;
    /**主表id*/
    private Long mainId;
    /**申请编号*/
    private String applyNum;
    /**客户姓名*/
    private String clientName;
    /**客户身份证*/
    private String clientIdCard;
    /**客户电话*/
    private String clientTell;
    /**咨询的产品*/
    private String productName;
    /**销售团队*/
    private String orgTeam;
    /**客户经理*/
    private String managerName;
    /**客服专员id*/
    private Long serviceUid;
    /**客服专员*/
    private String serviceName;
    /**是否分配*/
    private String isAllot;
    /**预审是否通过*/
    private String isApprovalPassed;
    /**推荐人姓名*/
    private String recommender;

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientIdCard() {
        return clientIdCard;
    }

    public void setClientIdCard(String clientIdCard) {
        this.clientIdCard = clientIdCard;
    }

    public String getClientTell() {
        return clientTell;
    }

    public void setClientTell(String clientTell) {
        this.clientTell = clientTell;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getOrgTeam() {
        return orgTeam;
    }

    public void setOrgTeam(String orgTeam) {
        this.orgTeam = orgTeam;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getIsAllot() {
        return isAllot;
    }

    public void setIsAllot(String isAllot) {
        this.isAllot = isAllot;
    }

    public String getIsApprovalPassed() {
        return isApprovalPassed;
    }

    public void setIsApprovalPassed(String isApprovalPassed) {
        this.isApprovalPassed = isApprovalPassed;
    }

    public Long getServiceUid() {
        return serviceUid;
    }

    public void setServiceUid(Long serviceUid) {
        this.serviceUid = serviceUid;
    }

    public String getRecommender() {
        return recommender;
    }

    public void setRecommender(String recommender) {
        this.recommender = recommender;
    }

    @Override
    public String toString() {
        return "ConsultationDO{" +
                "applyId=" + applyId +
                ", mainId=" + mainId +
                ", applyNum='" + applyNum + '\'' +
                ", clientName='" + clientName + '\'' +
                ", clientIdCard='" + clientIdCard + '\'' +
                ", clientTell='" + clientTell + '\'' +
                ", productName='" + productName + '\'' +
                ", orgTeam='" + orgTeam + '\'' +
                ", managerName='" + managerName + '\'' +
                ", serviceUid=" + serviceUid +
                ", serviceName='" + serviceName + '\'' +
                ", isAllot='" + isAllot + '\'' +
                ", isApprovalPassed='" + isApprovalPassed + '\'' +
                ", recommender='" + recommender + '\'' +
                '}';
    }
}
