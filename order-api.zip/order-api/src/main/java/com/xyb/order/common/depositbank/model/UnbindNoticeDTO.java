package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * 解绑通知接口
 * 
 * @author qiaoJinLong
 * @date 2018年11月23日
 */
public class UnbindNoticeDTO implements IBaseModel {

	private static final long serialVersionUID = 4909842090202551515L;
	
	@SignField(order = 2)
	private String card_no; // 电子账户

	private String customer_no;// 客户号
	
	@SignField(order = 3)
	private String bank_card_no;// 银行卡号

	private String serial_no;// 三方绑定编号（绑卡时返回的编号）

	private String out_serial_no;// 申请流水号

	private String sign_date; // 签约日期20180716

	private String sign_time;// 签约时间

	private String sign_flag;// 解约状态 1成功

	@Override
	public String toString() {
		return "UnbindNoticeDTO [card_no=" + card_no + ", customer_no=" + customer_no + ", bank_card_no=" + bank_card_no
				+ ", serial_no=" + serial_no + ", out_serial_no=" + out_serial_no + ", sign_date=" + sign_date
				+ ", sign_time=" + sign_time + ", sign_flag=" + sign_flag + "]";
	}

	public String getCard_no() {
		return card_no;
	}

	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}

	public String getCustomer_no() {
		return customer_no;
	}

	public void setCustomer_no(String customer_no) {
		this.customer_no = customer_no;
	}

	public String getBank_card_no() {
		return bank_card_no;
	}

	public void setBank_card_no(String bank_card_no) {
		this.bank_card_no = bank_card_no;
	}

	public String getSerial_no() {
		return serial_no;
	}

	public void setSerial_no(String serial_no) {
		this.serial_no = serial_no;
	}

	public String getOut_serial_no() {
		return out_serial_no;
	}

	public void setOut_serial_no(String out_serial_no) {
		this.out_serial_no = out_serial_no;
	}

	public String getSign_date() {
		return sign_date;
	}

	public void setSign_date(String sign_date) {
		this.sign_date = sign_date;
	}

	public String getSign_time() {
		return sign_time;
	}

	public void setSign_time(String sign_time) {
		this.sign_time = sign_time;
	}

	public String getSign_flag() {
		return sign_flag;
	}

	public void setSign_flag(String sign_flag) {
		this.sign_flag = sign_flag;
	}



}
