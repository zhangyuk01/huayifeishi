/**
 * 
 */
package com.xyb.order.pc.applybill.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.applybill.model
 * @description : TODO
 * @createDate : 2018年9月3日 下午4:50:43
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyJobInfoOfJinBoAndCpfDO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 745349500537855518L;
	
	/**是否有社保（大类2692）*/
	private Long jinpo;
	/**社保记录状态（大类2642）*/
	private Long jinpoRecord;
	/**社保缴纳单位*/
	private String jinpoCompany;
	/**社保基数*/
	private BigDecimal jinpoBase;
	/**社保月缴存数*/
	private BigDecimal jinpoMonth;
	/**单位社保缴费时长*/
	private Integer jinpoDuration;
	/**公积金缴纳单位*/
	private String cpfCompany;
	/**公积金记录状态（大类2624）*/
	private Long cpfRecord;
	/**公积金缴存基数*/
	private BigDecimal cpfBase;
	/**公积金月缴存数*/
	private BigDecimal cpfMonth;
	/**单位公积金缴费时长*/
	private Integer cpfDuration;
	public Long getJinpo() {
		return jinpo;
	}
	public void setJinpo(Long jinpo) {
		this.jinpo = jinpo;
	}
	public Long getJinpoRecord() {
		return jinpoRecord;
	}
	public void setJinpoRecord(Long jinpoRecord) {
		this.jinpoRecord = jinpoRecord;
	}
	public String getJinpoCompany() {
		return jinpoCompany;
	}
	public void setJinpoCompany(String jinpoCompany) {
		this.jinpoCompany = jinpoCompany;
	}
	public BigDecimal getJinpoBase() {
		return jinpoBase;
	}
	public void setJinpoBase(BigDecimal jinpoBase) {
		this.jinpoBase = jinpoBase;
	}
	public BigDecimal getJinpoMonth() {
		return jinpoMonth;
	}
	public void setJinpoMonth(BigDecimal jinpoMonth) {
		this.jinpoMonth = jinpoMonth;
	}
	public Integer getJinpoDuration() {
		return jinpoDuration;
	}
	public void setJinpoDuration(Integer jinpoDuration) {
		this.jinpoDuration = jinpoDuration;
	}
	public String getCpfCompany() {
		return cpfCompany;
	}
	public void setCpfCompany(String cpfCompany) {
		this.cpfCompany = cpfCompany;
	}
	public Long getCpfRecord() {
		return cpfRecord;
	}
	public void setCpfRecord(Long cpfRecord) {
		this.cpfRecord = cpfRecord;
	}
	public BigDecimal getCpfBase() {
		return cpfBase;
	}
	public void setCpfBase(BigDecimal cpfBase) {
		this.cpfBase = cpfBase;
	}
	public BigDecimal getCpfMonth() {
		return cpfMonth;
	}
	public void setCpfMonth(BigDecimal cpfMonth) {
		this.cpfMonth = cpfMonth;
	}
	public Integer getCpfDuration() {
		return cpfDuration;
	}
	public void setCpfDuration(Integer cpfDuration) {
		this.cpfDuration = cpfDuration;
	}
	@Override
	public String toString() {
		return "ApplyJobInfoOfJinBoAndCpfDO [jinpo=" + jinpo + ", jinpoRecord=" + jinpoRecord + ", jinpoCompany="
				+ jinpoCompany + ", jinpoBase=" + jinpoBase + ", jinpoMonth=" + jinpoMonth + ", jinpoDuration="
				+ jinpoDuration + ", cpfCompany=" + cpfCompany + ", cpfRecord=" + cpfRecord + ", cpfBase=" + cpfBase
				+ ", cpfMonth=" + cpfMonth + ", cpfDuration=" + cpfDuration + "]";
	}
	
}
