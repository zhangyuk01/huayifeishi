package com.xyb.order.app.client.personalcenter.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 我的余额
 * 
 * @author qiaoJinLong
 * @date 2018年9月20日
 */
public class MyBalanceDTO implements IBaseModel {
	private static final long serialVersionUID = -752552509602792794L;

	private double balance;// 总余额

	private double recommendBalance;// 推荐统计金额

	private double qualityBalance;// 质保统计金额

	@Override
	public String toString() {
		return "MyBalanceDTO [balance=" + balance + ", recommendBalance=" + recommendBalance + ", qualityBalance="
				+ qualityBalance + "]";
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getRecommendBalance() {
		return recommendBalance;
	}

	public void setRecommendBalance(double recommendBalance) {
		this.recommendBalance = recommendBalance;
	}

	public double getQualityBalance() {
		return qualityBalance;
	}

	public void setQualityBalance(double qualityBalance) {
		this.qualityBalance = qualityBalance;
	}

}
