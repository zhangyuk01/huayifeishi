package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * @description:    查询合同传入参数
 * @author:         xieqingyang
 * @createDate:     2018/6/26 下午3:43
*/
public class QueryAgreementDTO implements IBaseModel {

    private static final long serialVersionUID = 4657640548773295916L;
    /**页数  从0开始 查询类型为one时必传*/
    private Integer pageNum;

    /**每页条数 查询类型为one时必传*/
    private Integer pageSize;

    /**申请单ID*/
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;

    /**查询类型  one：借款协议 two：其他协议*/
    private String type;

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "QueryAgreementDTO{" +
                "pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", applyId=" + applyId +
                ", type='" + type + '\'' +
                '}';
    }
}
