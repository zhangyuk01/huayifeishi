package com.xyb.order.app.client.quickloan.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author luyang
 * @ClassName QuickLoanRefuseFullDetailDO
 * @description 累计满额拒贷借款人清单
 * @time 2018/12/21 11:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class QuickLoanRefuseFullDetailDO implements IBaseModel {

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 借款人ID
     */
    private Long clientId;
    /**
     * 借款人姓名
     */
    private String clientName;
    /**
     * 身份证号
     */
    private String clientIdcard;
    /**
     * 联系电话
     */
    private String clientPhone;
    /**
     * 累计满额拒贷次数
     */
    private Date applyDate;
    /**
     * 申请次数
     */
    private Date createTime;
    /**
     * 创建时间
     */
    private Long createUser;
    /**
     * 创建人
     */
    private Long orgId;
    /**
     * 修改时间
     */
    private Long productId;
    /**
     * 修改人
     */
    private BigDecimal applyAmount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientIdcard() {
        return clientIdcard;
    }

    public void setClientIdcard(String clientIdcard) {
        this.clientIdcard = clientIdcard;
    }

    public String getClientPhone() {
        return clientPhone;
    }

    public void setClientPhone(String clientPhone) {
        this.clientPhone = clientPhone;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public BigDecimal getApplyAmount() {
        return applyAmount;
    }

    public void setApplyAmount(BigDecimal applyAmount) {
        this.applyAmount = applyAmount;
    }

    @Override
    public String toString() {
        return "QuickLoanRefuseFullDetailDO{" +
                "id=" + id +
                ", clientId=" + clientId +
                ", clientName='" + clientName + '\'' +
                ", clientIdcard='" + clientIdcard + '\'' +
                ", clientPhone='" + clientPhone + '\'' +
                ", applyDate=" + applyDate +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", orgId=" + orgId +
                ", productId=" + productId +
                ", applyAmount=" + applyAmount +
                '}';
    }
}