package com.xyb.order.pc.contract.model.repaymentplan;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 还款计划DO
 * @createDate : 2018/06/01 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractRepaymentPlanDO implements IBaseModel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 367482613436590302L;

	private Long id;

    private Long contractId;

    private Long applyId;

    private Integer productLimit;

    private Date planDate;

    private BigDecimal accountManage;

    private BigDecimal capital;

    private BigDecimal interest;

    private BigDecimal monthReturn;

    private BigDecimal channelMonthReturn;

    private BigDecimal returnAll;

    private Long createUser;

    private Date createTime;

    private Date modifyTime;

    private Long modifyUser;

    private BigDecimal accountService;

    private BigDecimal serviceInterest;

    private Integer totalPeriod;

    private Long accountType;

    private BigDecimal dayInterestPenalty;

    private Integer lateDays;

    private BigDecimal totalInterestPenalty;

    private BigDecimal lateFee;

    private BigDecimal planTotalAmount;

    private BigDecimal actualCapital;

    private BigDecimal actualLateFee;

    private BigDecimal actualInterestPenalty;

    private BigDecimal reduceAmount;

    private BigDecimal actualTotalAmount;

    private BigDecimal remainCapital;

    private BigDecimal remainLateFee;

    private BigDecimal remainInterestPenalty;

    private BigDecimal remainTotalAmount;

    private Date dealDatetime;

    private Integer dealTimes;

    private Long state;

    private Long isCreatePayment;

    private BigDecimal creditAmountMonth;

    private BigDecimal capitalContract;

    private Date verificationDate;

    private Long zhanqi;

    private Long capitalTransfer;

    private Long repayNo;

    private Long isPenalty;

    private Long isOverdueDistribution;

    private Date overdueTime;

    private String remark;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getContractId() {
		return contractId;
	}

	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Integer getProductLimit() {
		return productLimit;
	}

	public void setProductLimit(Integer productLimit) {
		this.productLimit = productLimit;
	}

	public Date getPlanDate() {
		return planDate;
	}

	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}

	public BigDecimal getAccountManage() {
		return accountManage;
	}

	public void setAccountManage(BigDecimal accountManage) {
		this.accountManage = accountManage;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getMonthReturn() {
		return monthReturn;
	}

	public void setMonthReturn(BigDecimal monthReturn) {
		this.monthReturn = monthReturn;
	}

	public BigDecimal getChannelMonthReturn() {
		return channelMonthReturn;
	}

	public void setChannelMonthReturn(BigDecimal channelMonthReturn) {
		this.channelMonthReturn = channelMonthReturn;
	}

	public BigDecimal getReturnAll() {
		return returnAll;
	}

	public void setReturnAll(BigDecimal returnAll) {
		this.returnAll = returnAll;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public BigDecimal getAccountService() {
		return accountService;
	}

	public void setAccountService(BigDecimal accountService) {
		this.accountService = accountService;
	}

	public BigDecimal getServiceInterest() {
		return serviceInterest;
	}

	public void setServiceInterest(BigDecimal serviceInterest) {
		this.serviceInterest = serviceInterest;
	}

	public Integer getTotalPeriod() {
		return totalPeriod;
	}

	public void setTotalPeriod(Integer totalPeriod) {
		this.totalPeriod = totalPeriod;
	}

	public Long getAccountType() {
		return accountType;
	}

	public void setAccountType(Long accountType) {
		this.accountType = accountType;
	}

	public BigDecimal getDayInterestPenalty() {
		return dayInterestPenalty;
	}

	public void setDayInterestPenalty(BigDecimal dayInterestPenalty) {
		this.dayInterestPenalty = dayInterestPenalty;
	}

	public Integer getLateDays() {
		return lateDays;
	}

	public void setLateDays(Integer lateDays) {
		this.lateDays = lateDays;
	}

	public BigDecimal getTotalInterestPenalty() {
		return totalInterestPenalty;
	}

	public void setTotalInterestPenalty(BigDecimal totalInterestPenalty) {
		this.totalInterestPenalty = totalInterestPenalty;
	}

	public BigDecimal getLateFee() {
		return lateFee;
	}

	public void setLateFee(BigDecimal lateFee) {
		this.lateFee = lateFee;
	}

	public BigDecimal getPlanTotalAmount() {
		return planTotalAmount;
	}

	public void setPlanTotalAmount(BigDecimal planTotalAmount) {
		this.planTotalAmount = planTotalAmount;
	}

	public BigDecimal getActualCapital() {
		return actualCapital;
	}

	public void setActualCapital(BigDecimal actualCapital) {
		this.actualCapital = actualCapital;
	}

	public BigDecimal getActualLateFee() {
		return actualLateFee;
	}

	public void setActualLateFee(BigDecimal actualLateFee) {
		this.actualLateFee = actualLateFee;
	}

	public BigDecimal getActualInterestPenalty() {
		return actualInterestPenalty;
	}

	public void setActualInterestPenalty(BigDecimal actualInterestPenalty) {
		this.actualInterestPenalty = actualInterestPenalty;
	}

	public BigDecimal getReduceAmount() {
		return reduceAmount;
	}

	public void setReduceAmount(BigDecimal reduceAmount) {
		this.reduceAmount = reduceAmount;
	}

	public BigDecimal getActualTotalAmount() {
		return actualTotalAmount;
	}

	public void setActualTotalAmount(BigDecimal actualTotalAmount) {
		this.actualTotalAmount = actualTotalAmount;
	}

	public BigDecimal getRemainCapital() {
		return remainCapital;
	}

	public void setRemainCapital(BigDecimal remainCapital) {
		this.remainCapital = remainCapital;
	}

	public BigDecimal getRemainLateFee() {
		return remainLateFee;
	}

	public void setRemainLateFee(BigDecimal remainLateFee) {
		this.remainLateFee = remainLateFee;
	}

	public BigDecimal getRemainInterestPenalty() {
		return remainInterestPenalty;
	}

	public void setRemainInterestPenalty(BigDecimal remainInterestPenalty) {
		this.remainInterestPenalty = remainInterestPenalty;
	}

	public BigDecimal getRemainTotalAmount() {
		return remainTotalAmount;
	}

	public void setRemainTotalAmount(BigDecimal remainTotalAmount) {
		this.remainTotalAmount = remainTotalAmount;
	}

	public Date getDealDatetime() {
		return dealDatetime;
	}

	public void setDealDatetime(Date dealDatetime) {
		this.dealDatetime = dealDatetime;
	}

	public Integer getDealTimes() {
		return dealTimes;
	}

	public void setDealTimes(Integer dealTimes) {
		this.dealTimes = dealTimes;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public Long getIsCreatePayment() {
		return isCreatePayment;
	}

	public void setIsCreatePayment(Long isCreatePayment) {
		this.isCreatePayment = isCreatePayment;
	}

	public BigDecimal getCreditAmountMonth() {
		return creditAmountMonth;
	}

	public void setCreditAmountMonth(BigDecimal creditAmountMonth) {
		this.creditAmountMonth = creditAmountMonth;
	}

	public BigDecimal getCapitalContract() {
		return capitalContract;
	}

	public void setCapitalContract(BigDecimal capitalContract) {
		this.capitalContract = capitalContract;
	}

	public Date getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(Date verificationDate) {
		this.verificationDate = verificationDate;
	}

	public Long getZhanqi() {
		return zhanqi;
	}

	public void setZhanqi(Long zhanqi) {
		this.zhanqi = zhanqi;
	}

	public Long getCapitalTransfer() {
		return capitalTransfer;
	}

	public void setCapitalTransfer(Long capitalTransfer) {
		this.capitalTransfer = capitalTransfer;
	}

	public Long getRepayNo() {
		return repayNo;
	}

	public void setRepayNo(Long repayNo) {
		this.repayNo = repayNo;
	}

	public Long getIsPenalty() {
		return isPenalty;
	}

	public void setIsPenalty(Long isPenalty) {
		this.isPenalty = isPenalty;
	}

	public Long getIsOverdueDistribution() {
		return isOverdueDistribution;
	}

	public void setIsOverdueDistribution(Long isOverdueDistribution) {
		this.isOverdueDistribution = isOverdueDistribution;
	}

	public Date getOverdueTime() {
		return overdueTime;
	}

	public void setOverdueTime(Date overdueTime) {
		this.overdueTime = overdueTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "XybContractRepaymentPlanDO [id=" + id + ", contractId=" + contractId + ", applyId=" + applyId
				+ ", productLimit=" + productLimit + ", planDate=" + planDate + ", accountManage=" + accountManage
				+ ", capital=" + capital + ", interest=" + interest + ", monthReturn=" + monthReturn
				+ ", channelMonthReturn=" + channelMonthReturn + ", returnAll=" + returnAll + ", createUser="
				+ createUser + ", createTime=" + createTime + ", modifyTime=" + modifyTime + ", modifyUser="
				+ modifyUser + ", accountService=" + accountService + ", serviceInterest=" + serviceInterest
				+ ", totalPeriod=" + totalPeriod + ", accountType=" + accountType + ", dayInterestPenalty="
				+ dayInterestPenalty + ", lateDays=" + lateDays + ", totalInterestPenalty=" + totalInterestPenalty
				+ ", lateFee=" + lateFee + ", planTotalAmount=" + planTotalAmount + ", actualCapital=" + actualCapital
				+ ", actualLateFee=" + actualLateFee + ", actualInterestPenalty=" + actualInterestPenalty
				+ ", reduceAmount=" + reduceAmount + ", actualTotalAmount=" + actualTotalAmount + ", remainCapital="
				+ remainCapital + ", remainLateFee=" + remainLateFee + ", remainInterestPenalty="
				+ remainInterestPenalty + ", remainTotalAmount=" + remainTotalAmount + ", dealDatetime=" + dealDatetime
				+ ", dealTimes=" + dealTimes + ", state=" + state + ", isCreatePayment=" + isCreatePayment
				+ ", creditAmountMonth=" + creditAmountMonth + ", capitalContract=" + capitalContract
				+ ", verificationDate=" + verificationDate + ", zhanqi=" + zhanqi + ", capitalTransfer="
				+ capitalTransfer + ", repayNo=" + repayNo + ", isPenalty=" + isPenalty + ", isOverdueDistribution="
				+ isOverdueDistribution + ", overdueTime=" + overdueTime + ", remark=" + remark + "]";
	}


}
