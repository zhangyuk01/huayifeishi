package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @description:    银行卡新增或修改传入参数
 * @author:         xieqingyang
 * @createDate:     2018/7/19 下午6:17
*/
public class BankUpdateDTO implements IBaseModel {

    private static final long serialVersionUID = 4745522971984754478L;
    /**要变更的银行卡信息表ID*/
    private Long bankId;
    /**银行类型*/
    @NotNull(message = "银行类型不能为空")
    private Integer bankType;
    /**银行卡*/
    @NotEmpty(message = "银行卡号错误")
    @Size(min = 16,message = "银行卡号错误")
    private String bankCard;
    /**手机号*/
    @NotEmpty(message = "手机号码错误")
    @Size(min = 11,max = 11,message = "手机号码错误")
    private String phone;

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }

    public String getBankCard() {
        return bankCard;
    }

    public void setBankCard(String bankCard) {
        this.bankCard = bankCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Long getBankId() {
        return bankId;
    }

    public void setBankId(Long bankId) {
        this.bankId = bankId;
    }

    @Override
    public String toString() {
        return "BankUpdateDTO{" +
                "bankId=" + bankId +
                ", bankType=" + bankType +
                ", bankCard='" + bankCard + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
