package com.xyb.order.pc.finance;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @description 批次明细表持久层对象
 * @author luyang
 * @time 2018年4月23日上午10:31:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class FinanceBatchDetailsDO implements IBaseModel {

    /**
	 * 序列化
	 */
	private static final long serialVersionUID = 6502846668093170954L;
	/**
	 * 主键
	 */
	private Long id;
    /**
     * 待交易明细Id
     */
    private Long repaymentId;
    /**
     * 逾期还款表Id
     */
    private Long latepaymentApplicationId;
    /**
     * 合同ID
     */
    private Long contractId;
    /**
     * 银行大类(t_xyb_bank_code表对应字段)
     */
    private Integer bankType;
    /**
     * 开户支行
     */
    private String bankAccountOpen;
    /**
     * 账户名
     */
    private String bankAccount;
    /**
     * 银行账号
     */
    private String refundCardNum;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 状态\n（大类2752）
     */
    private Long state;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private Long modifyUser;
    /**
     * 修改时间
     */
    private Date modifyTime;
    /**
     * 回执单ID
     */
    private String receipt;
    /**
     * 订单号
     */
    private String orderNo;
    /**
     * 划扣平台（大类2526）
     */
    private Long dealPlatform;
    /**
     * 所属机构
     */
    private Long orgId;
    /**
     * 客户id
     */
    private Long custId;
    /**
     * 身份证号
     */
    private String clientIdcard;
    /**
     * 银行预留手机号
     */
    private String mp;
    /**
     * 原因
     */
    private String reasons;
    /**
     * get和set方法
     */
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRepaymentId() {
        return repaymentId;
    }

    public void setRepaymentId(Long repaymentId) {
        this.repaymentId = repaymentId;
    }

    public Long getLatepaymentApplicationId() {
        return latepaymentApplicationId;
    }

    public void setLatepaymentApplicationId(Long latepaymentApplicationId) {
        this.latepaymentApplicationId = latepaymentApplicationId;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }

    public String getBankAccountOpen() {
        return bankAccountOpen;
    }

    public void setBankAccountOpen(String bankAccountOpen) {
        this.bankAccountOpen = bankAccountOpen;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getRefundCardNum() {
        return refundCardNum;
    }

    public void setRefundCardNum(String refundCardNum) {
        this.refundCardNum = refundCardNum;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Long getDealPlatform() {
        return dealPlatform;
    }

    public void setDealPlatform(Long dealPlatform) {
        this.dealPlatform = dealPlatform;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Long getCustId() {
        return custId;
    }

    public void setCustId(Long custId) {
        this.custId = custId;
    }

    public String getClientIdcard() {
        return clientIdcard;
    }

    public void setClientIdcard(String clientIdcard) {
        this.clientIdcard = clientIdcard;
    }

	public String getMp() {
        return mp;
    }

    public void setMp(String mp) {
        this.mp = mp;
    }

    public String getReasons() {
        return reasons;
    }

    public void setReasons(String reasons) {
        this.reasons = reasons;
    }

	@Override
	public String toString() {
		return "FinanceBatchDetailsDO [id=" + id + ", repaymentId=" + repaymentId + ", latepaymentApplicationId="
				+ latepaymentApplicationId + ", contractId=" + contractId + ", bankType=" + bankType
				+ ", bankAccountOpen=" + bankAccountOpen + ", bankAccount=" + bankAccount + ", refundCardNum="
				+ refundCardNum + ", amount=" + amount + ", state=" + state + ", createUser=" + createUser
				+ ", createTime=" + createTime + ", modifyUser=" + modifyUser + ", modifyTime=" + modifyTime
				+ ", receipt=" + receipt + ", orderNo=" + orderNo + ", dealPlatform=" + dealPlatform + ", orgId="
				+ orgId + ", custId=" + custId + ", clientIdcard=" + clientIdcard + ", mp=" + mp + ", reasons="
				+ reasons + "]";
	}
    

}
