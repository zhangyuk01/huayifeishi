package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by xieqingyang on 2018/4/18.
 * 一次查询多个下拉框的model
 */
public class DropDownBoxListDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    @NotNull(message = "传入参数不能为空")
    private List<DropDownBoxDTO> downBoxDTOS;

    public List<DropDownBoxDTO> getDownBoxDTOS() {
        return downBoxDTOS;
    }

    public void setDownBoxDTOS(List<DropDownBoxDTO> downBoxDTOS) {
        this.downBoxDTOS = downBoxDTOS;
    }
}
