package com.xyb.order.pc.contract.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 进件合同审核详情DTO model层
 * @createDate : 2018/3/28 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditDetailDTO implements IBaseModel {
	/**
	 * 
	 */
	private static final Long serialVersionUID = -8001772573274135731L;
	@NotNull(message = "申请id不能为空")
	private Long applyId;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Override
	public String toString() {
		return "XybContractAuditDetailDTO [applyId=" + applyId + "]";
	}
	
}
