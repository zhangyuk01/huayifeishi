package com.xyb.order.pc.applybill.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDTO;

/**
 * @ClassName ApplyBillInfoExternalService(申请表对外接口)
 * @author ZhangYu
 * @date 2018年4月16号
 */
public interface ApplyBillInfoExternalService {

	RestResponse saveApplyLinkManInfo(ApplyLinkmanInfoDTO applyLinkmanInfoDTO);

}
