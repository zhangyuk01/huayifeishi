package com.xyb.order.app.client.cuser.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.cuser.model.CUpdatePhoneDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;

/**
 * @description: 修改客户信息（密码、手机号）
 * @author: xieqingyang
 * @createDate: 2018/8/2 上午11:24
 */
public interface ClinetUserModifyService {

	/**
	 * 忘记密码
	 * 
	 * @author xieqingyang
	 * @param clientUserDTO
	 * @return
	 * @exception @date
	 *                2018/5/9 下午6:18
	 */
	RestResponse forgetPassword(ClientUserUpdateDTO clientUserDTO) throws Exception;

	/**
	 * 修改手机号
	 * 
	 * @author xieqingyang
	 * @param clientUserUpdatePhoneDTO
	 * @return
	 * @exception @date
	 *                2018/5/9 下午6:18
	 */
	RestResponse updatePhone(CUpdatePhoneDTO cUpdatePhoneDTO) throws Exception;

	/**
	 * 修改密码
	 * 
	 * @author xieqingyang
	 * @param clientUserUpdatePasswordDTO
	 * @return
	 * @exception @date
	 *                2018/5/9 下午6:18
	 */
	RestResponse updatePassword(ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO) throws Exception;

	/**
	 * ------------------------------------------------平台调用修改用户可进件时间------------
	 * ------------------------------------
	 */

	/**
	 * @description 修改用户可进件时间
	 * @author xieqingyang
	 * @CreatedDate 2018/8/3 下午8:33
	 * @Version 1.0
	 * @param clientId
	 *            用户ID
	 * @param dayNum
	 *            拒贷天数 可不传 不传为批贷
	 */
	void updateClientAllowableEntryTime(Long clientId, Integer dayNum);

	/**
	 * C端修改手机号身份验证
	 * 
	 * @param encrypt
	 * @return
	 * @throws Exception
	 */
	RestResponse checkID(String encrypt) throws Exception;

}
