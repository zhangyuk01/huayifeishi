package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    捷安推送日志
 * @author:         xieqingyang
 * @createDate:     2018/7/18 下午9:23
*/
public class JieAnLogDO implements IBaseModel {

    private static final long serialVersionUID = -3955175848010133806L;
    private Long id;
    /**订单号*/
    private String orderId;
    /**请求参请求参数字符串数字符串*/
    private String reqPmt;
    /**响应参数字符串*/
    private String respPmt;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**更新时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getReqPmt() {
        return reqPmt;
    }

    public void setReqPmt(String reqPmt) {
        this.reqPmt = reqPmt;
    }

    public String getRespPmt() {
        return respPmt;
    }

    public void setRespPmt(String respPmt) {
        this.respPmt = respPmt;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "JieAnLogDO{" +
                "id=" + id +
                ", orderId='" + orderId + '\'' +
                ", reqPmt='" + reqPmt + '\'' +
                ", respPmt='" + respPmt + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
