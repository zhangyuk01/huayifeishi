package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author : jiangzhongyan
 * @projectName : finance-model
 * @package : com.xyb.loan
 * @description : TODO
 * @createDate : 2017/12/09 15:32
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseResult implements IBaseModel {

    private String code; // 0-调用成功, 1-调用失败
    private String message; // 失败原因
    /**处理结果信息，为json字符串*/
    private String body;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "ResponseResult{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", body='" + body + '\'' +
                '}';
    }
}
