package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;

/**
 * @description: C端用户表
 * @author: xieqingyang
 * @createDate: 2018/5/9 下午2:25
 */
public class ClientUserDO implements IBaseModel {
	private static final long serialVersionUID = 1L;

	private Long id;// -- 主键ID
	private String loginName;// -- 登录ID
	private String name;// -- 姓名
	private String password;// -- 密码
	private String territoriality;// -- 所属地
	private String recommendCode;// -- 推荐码
	private Long state;// -- 是否有效(大类2687)
	private Date createTime;// -- 创建时间
	private Date modifyTime;// -- 修改时间
	private Long createUser;// -- 创建人
	private Long modifyUser;// -- 修改人
	private String deviceToken;// -- 推送唯一标识
	private Long sorcRecommend;// 源推荐人
	private String shortUrl;// 分享短连接
	private int type;
	/** 为修改手机号使用 */
	@JsonIgnore
	private String newLoginName;// -- 待修改的手机号

	@Override
	public String toString() {
		return "ClientUserDO [id=" + id + ", loginName=" + loginName + ", name=" + name + ", password=" + password
				+ ", territoriality=" + territoriality + ", recommendCode=" + recommendCode + ", state=" + state
				+ ", createTime=" + createTime + ", modifyTime=" + modifyTime + ", createUser=" + createUser
				+ ", modifyUser=" + modifyUser + ", deviceToken=" + deviceToken + ", sorcRecommend=" + sorcRecommend
				+ ", shortUrl=" + shortUrl + ", type=" + type + ", newLoginName=" + newLoginName + "]";
	}

	public String getShortUrl() {
		return shortUrl;
	}

	public void setShortUrl(String shortUrl) {
		this.shortUrl = shortUrl;
	}

	public Long getSorcRecommend() {
		return sorcRecommend;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setSorcRecommend(Long sorcRecommend) {
		this.sorcRecommend = sorcRecommend;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTerritoriality() {
		return territoriality;
	}

	public void setTerritoriality(String territoriality) {
		this.territoriality = territoriality;
	}

	public String getRecommendCode() {
		return recommendCode;
	}

	public void setRecommendCode(String recommendCode) {
		this.recommendCode = recommendCode;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getNewLoginName() {
		return newLoginName;
	}

	public void setNewLoginName(String newLoginName) {
		this.newLoginName = newLoginName;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

}
