package com.xyb.order.pc.outbound.model;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访详情暂存detailSaveDTO model
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailSaveDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1321119133504836169L;
	/**申请id*/
	@NotNull(message = "applyId不能为空")
	private long applyId;
	/**实地时间*/
	private Date visitDate;
	/**客户综合描述*/
	private String customerIntegratedDescription;
	/**实地征信工作信息*/
	private ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO;
	/**实地征信家庭信息*/
	private List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDOs;
	/**实地征信经营信息*/
	private List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs;
	/**外访产调*/
	private ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO;
	public long getApplyId() {
		return applyId;
	}
	public void setApplyId(long applyId) {
		this.applyId = applyId;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	public String getCustomerIntegratedDescription() {
		return customerIntegratedDescription;
	}
	public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
		this.customerIntegratedDescription = customerIntegratedDescription;
	}
	public ApplyVisitCreditJobInfoDO getApplyVisitCreditJobInfoDO() {
		return applyVisitCreditJobInfoDO;
	}
	public void setApplyVisitCreditJobInfoDO(ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO) {
		this.applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDO;
	}
	public List<ApplyVisitCreditFamilyInfoDO> getApplyVisitCreditFamilyInfoDOs() {
		return applyVisitCreditFamilyInfoDOs;
	}
	public void setApplyVisitCreditFamilyInfoDOs(List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDOs) {
		this.applyVisitCreditFamilyInfoDOs = applyVisitCreditFamilyInfoDOs;
	}
	public List<ApplyVisitCreditManagermentInfoDO> getApplyVisitCreditManagermentInfoDOs() {
		return applyVisitCreditManagermentInfoDOs;
	}
	public void setApplyVisitCreditManagermentInfoDOs(
			List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs) {
		this.applyVisitCreditManagermentInfoDOs = applyVisitCreditManagermentInfoDOs;
	}
	public ApplyVisitPropertySurveyDO getApplyVisitPropertySurveyDO() {
		return applyVisitPropertySurveyDO;
	}
	public void setApplyVisitPropertySurveyDO(ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO) {
		this.applyVisitPropertySurveyDO = applyVisitPropertySurveyDO;
	}
	@Override
	public String toString() {
		return "OutBoundDetailSaveDTO [applyId=" + applyId + ", visitDate=" + visitDate
				+ ", customerIntegratedDescription=" + customerIntegratedDescription + ", applyVisitCreditJobInfoDO="
				+ applyVisitCreditJobInfoDO + ", applyVisitCreditFamilyInfoDOs=" + applyVisitCreditFamilyInfoDOs
				+ ", applyVisitCreditManagermentInfoDOs=" + applyVisitCreditManagermentInfoDOs
				+ ", applyVisitPropertySurveyDO=" + applyVisitPropertySurveyDO + "]";
	}

}
