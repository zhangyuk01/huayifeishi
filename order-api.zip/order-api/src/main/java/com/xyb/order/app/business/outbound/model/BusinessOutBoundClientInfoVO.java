package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.model
 * @description :
 * @createDate : 2018/6/13 17:28
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundClientInfoVO implements IBaseModel {

    private static final long serialVersionUID = 1445111006305721733L;

    /**客户姓名*/
    private String clientName;
    /**性别*/
    private String gender;

    private String genderStr;
    /**手机号*/
    private String phone;
    /**婚姻情况*/
    private String marriage;

    private String marriageStr;
    /**身份证*/
    private String idCard;
    /**申请产品*/
    private String applyProduct;
    /**户籍住址*/
    private String homeAddress;
    /**家庭住址*/
    private String familyAddress;
    /**单位名称*/
    private String companyName;
    /**单位电话*/
    private String companyPhone;
    /**单位地址*/
    private String companyAddress;
    /**提交时间*/
    private String submitDate;
    /**终审报告*/
    private String endReport;

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMarriage() {
        return marriage;
    }

    public void setMarriage(String marriage) {
        this.marriage = marriage;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getApplyProduct() {
        return applyProduct;
    }

    public void setApplyProduct(String applyProduct) {
        this.applyProduct = applyProduct;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getFamilyAddress() {
        return familyAddress;
    }

    public void setFamilyAddress(String familyAddress) {
        this.familyAddress = familyAddress;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyPhone() {
        return companyPhone;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(String submitDate) {
        this.submitDate = submitDate;
    }

    public String getEndReport() {
        return endReport;
    }

    public void setEndReport(String endReport) {
        this.endReport = endReport;
    }

    public String getGenderStr() {
        return genderStr;
    }

    public void setGenderStr(String genderStr) {
        this.genderStr = genderStr;
    }

    public String getMarriageStr() {
        return marriageStr;
    }

    public void setMarriageStr(String marriageStr) {
        this.marriageStr = marriageStr;
    }

    @Override
    public String toString() {
        return "BusinessOutBoundClientInfoVO{" +
                "clientName='" + clientName + '\'' +
                ", gender='" + gender + '\'' +
                ", genderStr='" + genderStr + '\'' +
                ", phone='" + phone + '\'' +
                ", marriage='" + marriage + '\'' +
                ", marriageStr='" + marriageStr + '\'' +
                ", idCard='" + idCard + '\'' +
                ", applyProduct='" + applyProduct + '\'' +
                ", homeAddress='" + homeAddress + '\'' +
                ", familyAddress='" + familyAddress + '\'' +
                ", companyName='" + companyName + '\'' +
                ", companyPhone='" + companyPhone + '\'' +
                ", companyAddress='" + companyAddress + '\'' +
                ", submitDate='" + submitDate + '\'' +
                ", endReport='" + endReport + '\'' +
                '}';
    }
}
