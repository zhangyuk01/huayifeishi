package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.math.BigDecimal;

/**
 * @description:    法大大需要的个人申请信息
 * @author:         xieqingyang
 * @createDate:     2018/8/1 下午5:42
*/
public class FddClientApplyInFoDTO implements IBaseModel {

    private static final long serialVersionUID = 3669429951156221363L;
    /**申请单ID*/
    private Long applyId;
    /**主表ID*/
    private Long mainId;
    /**借款用途*/
    private String borrowDesc;
    /**申请编号*/
    private String applyNum;
    /**合同金额*/
    private BigDecimal contractMoney;
    /**服务费*/
    private BigDecimal serviceAmount;
    /**产品利率/月*/
    private BigDecimal productProrotion;
    /**用户信息表ID*/
    private Long clientId;

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public String getBorrowDesc() {
        return borrowDesc;
    }

    public void setBorrowDesc(String borrowDesc) {
        this.borrowDesc = borrowDesc;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public BigDecimal getContractMoney() {
        return contractMoney;
    }

    public void setContractMoney(BigDecimal contractMoney) {
        this.contractMoney = contractMoney;
    }

    public BigDecimal getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(BigDecimal serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    public BigDecimal getProductProrotion() {
        return productProrotion;
    }

    public void setProductProrotion(BigDecimal productProrotion) {
        this.productProrotion = productProrotion;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    @Override
    public String toString() {
        return "FddClientApplyInFoDTO{" +
                "applyId=" + applyId +
                ", mainId=" + mainId +
                ", borrowDesc='" + borrowDesc + '\'' +
                ", applyNum='" + applyNum + '\'' +
                ", contractMoney=" + contractMoney +
                ", serviceAmount=" + serviceAmount +
                ", productProrotion=" + productProrotion +
                ", clientId=" + clientId +
                '}';
    }
}
