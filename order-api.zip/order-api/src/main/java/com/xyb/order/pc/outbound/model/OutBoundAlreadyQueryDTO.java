package com.xyb.order.pc.outbound.model;

import java.util.Date;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访已办查询DTO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundAlreadyQueryDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -381782537286111222L;
	
	@JsonIgnore
    private Page page = new Page();// -- 分页
	/**类型A:外访已办：外访人员  B：外访已办：客服经理  C:外访已办：城市经理*/
	private String type;
	/**合同状态*/
	private String contractState;
	/**合同状态集*/
	@JsonIgnore
	private List<Integer> list;
	/**征信负责人(外访人员)*/
	private String visitUid;
	/**外访返回开始时间*/
	private Date visitStartTime;
	/**外访返回结束时间*/
	private Date visitEndTime;
	/**进件机构*/
	private String orgId;
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public List<Integer> getList() {
		return list;
	}
	public void setList(List<Integer> list) {
		this.list = list;
	}
	public String getVisitUid() {
		return visitUid;
	}
	public void setVisitUid(String visitUid) {
		this.visitUid = visitUid;
	}
	public Date getVisitStartTime() {
		return visitStartTime;
	}
	public void setVisitStartTime(Date visitStartTime) {
		this.visitStartTime = visitStartTime;
	}
	public Date getVisitEndTime() {
		return visitEndTime;
	}
	public void setVisitEndTime(Date visitEndTime) {
		this.visitEndTime = visitEndTime;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	@Override
	public String toString() {
		return "OutBoundAlreadyQueryDTO [page=" + page + ", type=" + type + ", contractState=" + contractState
				+ ", list=" + list + ", visitUid=" + visitUid + ", visitStartTime=" + visitStartTime + ", visitEndTime="
				+ visitEndTime + ", orgId=" + orgId + "]";
	}

}
