package com.xyb.order.pc.contract.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description 借款撤销和老系统交互数据对象
 * @author luyang
 * @time 2017年12月28日下午2:42:28
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class ApplyRevokeRequest implements IBaseModel{

	private static final long serialVersionUID = -6216381441356849747L;
	private String applyId;
	private String loginId;
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	

}
