package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditCodeInfo implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3359472901783991014L;
	
	private Long id;
	private String codes;
	private String useLink;
	private Integer refuseNode;
	private String refuseReason;
	private Integer isPrimary;
	private Integer isValid;
	private Integer refuseNotorerDays;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCodes() {
		return codes;
	}
	public void setCodes(String codes) {
		this.codes = codes;
	}
	public String getUseLink() {
		return useLink;
	}
	public void setUseLink(String useLink) {
		this.useLink = useLink;
	}
	public Integer getRefuseNode() {
		return refuseNode;
	}
	public void setRefuseNode(Integer refuseNode) {
		this.refuseNode = refuseNode;
	}
	public String getRefuseReason() {
		return refuseReason;
	}
	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}
	public Integer getIsPrimary() {
		return isPrimary;
	}
	public void setIsPrimary(Integer isPrimary) {
		this.isPrimary = isPrimary;
	}
	public Integer getIsValid() {
		return isValid;
	}
	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}
	public Integer getRefuseNotorerDays() {
		return refuseNotorerDays;
	}
	public void setRefuseNotorerDays(Integer refuseNotorerDays) {
		this.refuseNotorerDays = refuseNotorerDays;
	}
	@Override
	public String toString() {
		return "AuditCodeInfo [id=" + id + ", codes=" + codes + ", useLink=" + useLink + ", refuseNode=" + refuseNode
				+ ", refuseReason=" + refuseReason + ", isPrimary=" + isPrimary + ", isValid=" + isValid
				+ ", refuseNotorerDays=" + refuseNotorerDays + "]";
	}
	
	
	
	

}
