package com.xyb.order.app.client.mine.model;


import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.common.constant.CurrencyConstant;

public class ApplyRecordLogStateDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	/**节点状态*/
	private String logState;
	/**节点状态时间*/
	private String  createTime;
	/**按钮状态名称*/
    private String buttonName = "";
    /**是否有按钮 Y:是 N:否*/
    private String isButton = CurrencyConstant.N;
	
	public String getLogState() {
		return logState;
	}
	public void setLogState(String logState) {
		this.logState = logState;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getButtonName() {
		return buttonName;
	}
	public void setButtonName(String buttonName) {
		this.buttonName = buttonName;
	}
	public String getIsButton() {
		return isButton;
	}
	public void setIsButton(String isButton) {
		this.isButton = isButton;
	}
	
}
