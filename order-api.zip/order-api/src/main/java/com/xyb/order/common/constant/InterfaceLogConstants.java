package com.xyb.order.common.constant;

/**
 * @author : jiangzhongyan
 * @projectName : finance-api
 * @package : com.xyb.com.xyb.order.common.constant
 * @description : 接口日志常量管理包
 * @createDate : 2017/12/12 14:28
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class InterfaceLogConstants {

    /**
     * 接口日志调用类型 1-回调
     */
    public static final String INVOK_TYPE_1 = "2745";
    /**
     * 接口日志调用类型 0-推送
     */
    public static final String INVOK_TYPE_0 = "2744";
    /**
     * 接口日志调用类型 2-查询
     */
    public static final String INVOK_TYPE_2 = "2";

    /**
     * 接口名称 (放款回调接口)
     */
    public static final String LOAN_CALLBACK_INTERFACE_NAME = "loanCallBack";
    /**
     * 接口名称 (换卡通知回调接口)
     */
    public static final String CARD_CHANGE_INTERFACE_NAME = "cardChangeCallBack";
    
    /**
     * 接口名称 (充值结果回调接口)
     */
    public static final String CHARGE_RESULT_INTERFACE_NAME = "chargeResultFromShenZhen";
    
    /**
     * 接口名称 (充值申请接口)
     */
    public static final String CHARGE_APPLY_INTERFACE_NAME = "chargeApplicationToShenZhen";
    
    /**
     * 接口名称 (深圳借款申请通知接口)
     */
    public static final String INTERFACE_APPLY_NAME = "applyCallBack";
    
    /**
     * 接口名称 (获取深圳申请信息接口,老调新)
     */
    public static final String INTERFACE_GET_APPLY_INFO = "getApplyInfo";

    
    /**
     * 接口名称 (合同录入提交推标到深圳接口)
     */
    public static final String INTERFACE_CONTRACT_TB = "contractTb";



    /**
     * 接口名称 (开通存管账户)
     */
    public static final String INTERFACE_OPEN_ACCOUNT = "openAccount";

    /**
     * 接口名称 (修改存管账户密码)
     */
    public static final String INTERFACE_RESET_PASSWORD = "resetPassword";

    /**
     * 接口名称 (修改存管账户银行卡号)
     */
    public static final String INTERFACE_EXCARD = "exCard";

    /**
     * 接口名称 (解绑银行卡)
     */
    public static final String INTERFACE_UNBANKCARD = "unBankCard";

    /**
     * 接口名称 (授权接口)
     */
    public static final String INTERFACE_AUTH = "auth";

    /**
     * 接口名称 (授权接口)
     */
    public static final String INTERFACE_CANCEL_USER_AUTH = "cancelUserAuth";

    /**合同签约相关*/
    /**
     * 借款人声明函&委托扣款授权书、借款人服务协议
     */
    public static final String LOAN_COL = "loanCol";

    /**
     * 个人信息查询、采集授权书
     */
    public static final String PERSONAL_AUTH = "personalAuth";

    /**
     * 查询借款协议
     */
    public static final String QUERY_LOAN_COL = "queryLoanCol";


    /**协议签约相关*/
    /**
     * 支付渠道列表接口
     */
    public static final String GET_PAY_TYPES = "getPayTypes";
    /**
     * 签约接口
     */
    public static final String SIGN = "sign";
    /**
     * 签约确认接口
     */
    public static final String CONFIRM = "confirm";
    /**
     * 渠道完成确认接口
     */
    public static final String CHECK_PAY_STATE = "checkPayState";

    
    /** 深圳还款通知接口*/
    public static final String INTERFACE_REPAYMENT_RESULT_NOTICE_INFO = "repaymentResult";
    
    /** 深圳全额收购通知接口*/
    public static final String INTERFACE_BUY_BACK_NOTICE_INFO = "buyBack";
    
    /**
     * 接口名称 (一次性结清查询接口)
     */
    public static final String QUERY_ONETIME_INTERFACE_NAME = "queryOneTimeAmtFromShenzhen";
    /**
     * 解绑银行卡接口(深圳)
     */
    public static final String ACCOUNT_UNBIND_BANKCARD = "accountUNBindBankCard";
    
    /**
     * 借款撤销通知接口
     */
    public static final String INTERFACE_NOTICE_REVOKE = "noticeRevoke";
    
    /**
     * 借款撤销申请接口
     */
    public static final String INTERFACE_APPLY_REVOKE = "applyRevoke";

}
