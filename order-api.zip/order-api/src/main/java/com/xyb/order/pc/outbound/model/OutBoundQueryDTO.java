package com.xyb.order.pc.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访listQueryDTO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundQueryDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -333162463524335403L;
	@JsonIgnore
    private Page page = new Page();// -- 分页

	@JsonIgnore
	private Long orgId;

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	@Override
	public String toString() {
		return "OutBoundQueryDTO [page=" + page + ", orgId=" + orgId + "]";
	}
	

}
