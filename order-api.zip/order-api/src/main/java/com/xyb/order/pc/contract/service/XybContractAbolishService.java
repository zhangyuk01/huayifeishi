package com.xyb.order.pc.contract.service;


import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractAbolishQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 合同分配service
 * @createDate : 2018/5/02 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractAbolishService {
	
	RestResponse listAbolishContract(Integer pageNumber, Integer pageSize,XybContractAbolishQueryDTO xybContractAbolishQueryDTO) ;

	RestResponse abolishContract(XybContractAbolishDTO xybContractAbolishDTO,String ipAddr,String macAddr) ;

}
