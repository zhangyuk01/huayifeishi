package com.xyb.order.app.client.personinfo.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class PersonBaseRelationInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private Long id; //主键ID
	private String webchat = "";//微信
	private String qq = "";//qq
	private String phone2 = "";//备用手机号
	private String tellArea = "";// -- 家庭固话区号
	private String tell = "";// -- 家庭固话
	private Integer familyCount;
	private Integer workCount;
	private Integer quickCount;
	@JsonIgnore
	private String email;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWebchat() {
		return webchat;
	}

	public void setWebchat(String webchat) {
		this.webchat = webchat;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getTellArea() {
		return tellArea;
	}

	public void setTellArea(String tellArea) {
		this.tellArea = tellArea;
	}

	public String getTell() {
		return tell;
	}

	public void setTell(String tell) {
		this.tell = tell;
	}

	public Integer getFamilyCount() {
		return familyCount;
	}

	public void setFamilyCount(Integer familyCount) {
		this.familyCount = familyCount;
	}

	public Integer getWorkCount() {
		return workCount;
	}

	public void setWorkCount(Integer workCount) {
		this.workCount = workCount;
	}

	public Integer getQuickCount() {
		return quickCount;
	}

	public void setQuickCount(Integer quickCount) {
		this.quickCount = quickCount;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
