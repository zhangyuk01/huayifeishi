package com.xyb.order.common.msg;

/**
 * 需要定义的字典枚举类
 * @author         xieqingyang
 * @date           2018/10/26 2:13 PM
*/
public enum SysDictEnum {

    /**为查询下拉框使用，只有大类*/
    SEX(0L,"",2632L,"性别"),
    USAGE_LOAN(0L,"",2487L,"借款用途"),
    EDUCATION(0L,"",2626L,"学历"),
    MARITAL_STATUS(0L,"",2650L,"婚姻状况"),
    LIVING_CONDITIONS(0L,"",2647L,"居住情况"),
    CO_HABITATION(0L,"",2645L,"共同居住者"),
    RELATIONSHIP_RELATIVES(0L,"",2630L,"关系（配偶、直系）"),
    RELATIONSHIP_QUICK(0L,"",2664L,"关系（紧急联系人）"),
    UNIT_PROPERTIES(0L,"",2623L,"单位性质"),
    ENTERPRISE_SCALE(0L,"",2622L,"企业规模"),
    TYPE_ENTERPRISE(0L,"",2628L,"企业类型"),
    PLACE_BUSINESS(0L,"",2658L,"经营场所"),
    NUMBER_EMPLOYEES(0L,"",2730L,"员工人数"),
    ABANDONMENT(0L,"",2710L,"客户放弃原因"),
    NUMBER_CHILDREN(0L,"",2776L,"子女数量"),
    FLOW_TYPE_PERSONAL(0L,"",2570L,"流水类型（个人收入证明）"),
    FLOW_TYPE_ENTERPRISE(0L,"",2777L,"流水类型（企业收入证明）"),
    REAL_NAME_AUTHENTICATION(0L,"",2778L,"实名认证"),
    PAYMENT_METHOD(0L,"",2720L,"缴费方式"),
    DISTRIBUTION_STATE(0L,"",2583L,"分配状态"),
    UNIT_IMPORT_EXPORT_SITUATION(0L,"",2723L,"单位进出情况"),
    UNIT_TELEPHONE_POSITION(0L,"",2724L,"单位电话位置"),
    TYPE_HOUSE(0L,"",2782L,"房屋类型"),
    OWNERSHIP_HOUSING(0L,"",2783L,"房屋权属"),
    DECORATION_STYLE(0L,"",2722L,"装修风格"),
    BUSINESS_CATEGORY(0L,"",2726L,"经营类别"),
    STOCK_GOODS(0L,"",2729L,"库存货品"),
    NUMBER_EMPLOYEES_SAME_DAY(0L,"",2730L,"当日在岗员工人数"),
    REMAINDER_TIME_OPERATING_LAND(0L,"",2727L,"经营地剩余使用时间"),
    OPERATING_AREA(0L,"",2784L,"经营面积"),
    PROPERTY_HOUSE(0L,"",2733L,"房屋性质"),
    SOURCE_PROPERTY_RIGHTS(0L,"",2734L,"产权来源"),
    MORTGAGE_SITUATION(0L,"",2735L,"抵押次数"),
    COMMON_SITUATION(0L,"",2788L,"共用情况"),
    CONTRACT_REVIEW(0L,"",2795L,"合同审核"),
    ABOLITION_CAUSE(0L,"",2797L,"废除原因"),
    SPECIAL_CASE_CODE(0L,"",2579L,"专案码"),
    BUSINESS_DEPARTMENT_TYPE(0L,"",2689L,"营业部类型"),
    information_confirmation(0L,"",2725L,"在职信息确认"),
    INHABITATION_MARKS(0L,"",2805L,"居住痕迹"),
    BUSINESS_CERTIFICATE(0L,"",2728L,"经营证明"),
    NATURE_MORTGAGES(0L,"",2736L,"抵押权人性质"),
    RESTRICTIONS(0L,"",2737L,"限制情况"),
    CAR_CONTRACT_BACK(0L,"",2493L,"合同退回原因"),
    RECONSIDER(0L,"",2803L,"复议目标"),
    INDUSTRY(0L,"",2738L,"所属行业"),
    DUTY(0L,"",2834L,"职务"),

    /**正常使用*/
    BANK_CARD_BUSINESS_TYPE_3105(3105L,"新增",2833L,"银行卡业务类型"),
    BANK_CARD_BUSINESS_TYPE_3106(3106L,"换卡",2833L,"银行卡业务类型"),
    BANK_CARD_BUSINESS_TYPE_3107(3107L,"设置默认卡",2833L,"银行卡业务类型"),
    BANK_CARD_BUSINESS_TYPE_3108(3108L,"作废",2833L,"银行卡业务类型"),

    BANK_CARD_STATUS_3102(3102L,"待审核",2832L,"银行卡状态"),
    BANK_CARD_STATUS_3103(3103L,"待授权",2832L,"银行卡状态"),
    BANK_CARD_STATUS_3104(3104L,"完成",2832L,"银行卡状态"),

    APP_VERSION_IOS(2529L,"IOS",2715L,"登录设备类型"),
    APP_VERSION_ANDROID(2528L,"Android",2715L,"登录设备类型"),

    JUXINLI_OPERATOR(2873L,"聚信力运营商报告",2791L,"三方类型"),
    JUXINLI_POLICY_REPORT(2874L,"聚信力保单报告",2791L,"三方类型"),
    TIANJI_SOCIAL_SECURITY(2875L,"融360社保",2791L,"三方类型"),
    TIANJI_ACCUMULATION_FUND(2876L,"融360公积金",2791L,"三方类型"),
    TIANJI_INTERNET_BUSINESS(2877L,"融360征信",2791L,"三方类型"),
    SUANHUA_HUMAN_DECENCY(2878L,"算话人行报告",2791L,"三方类型"),
    SUANHUA_REGISTER(2946L,"算话注册账号",2791L,"三方类型"),

    EMPOWERMENT_SUCCESS(2939L,"强制授权成功",2792L,"强授权类型"),
    COMPULSORY_AUTHORIZATION(2940L,"强制授权",2792L,"强授权类型"),
    NON_COMPULSORY_AUTHORIZATION(2941L,"非强制授权",2792L,"强授权类型"),

    APP_TYPE_CLIENT(2527L,"客户端",2714L,"app类型"),
    APP_TYPE_BUSINESS(2526L,"业务端",2714L,"app类型"),

    NOTIFICATION_TYPE_INFORM(2525L,"通知",2713L,"APP推送消息通知类型"),
    NOTIFICATION_TYPE_NOTICE(3082L,"公告",2713L,"APP推送消息通知类型"),

    LOAN_COL_URL(3022L,"《委托扣款授权书》 《借款人声明函》",2818L,"协议类型"),
    LOAN_SERVICE_URL(3023L,"《信用宝借款信息咨询与服务协议》",2818L,"协议类型"),
    AUTHORIZE_URL(3024L,"《个人信息采集、查询、授权书》",2818L,"协议类型"),
    LOAN_URL(3065L,"《借款协议》",2818L,"协议类型"),

    ALREADY_OPENED(3020L,"已开户",2817L,"开户状态"),
    PADDLE_AGREEMENT(3021L,"待签划扣协议",2817L,"开户状态"),
    PENDING_CARD(3054L,"待授权",2817L,"开户状态"),
    TO_AUTHORIZED(3055L,"待绑卡",2817L,"开户状态"),

    IN_CARD_EXCHANGE(3074L,"换卡",2828L,"存管操作类型"),
    CANCELLATION_AUTHORIZATION(3075L,"取消授权",2828L,"存管操作类型"),
    UNTYING(3076L,"解绑",2828L,"存管操作类型"),

    INITIATE_APPLICATION(3080L,"待审核",2829L,"存管操作状态"),
    APPLICATION(3077L,"资料变更中",2829L,"存管操作状态"),
    AUDIT(3078L,"待授权",2829L,"存管操作状态"),
    COMPLETE(3079L,"完成",2829L,"存管操作状态"),

    RISK_STATE_MATERIAL(2783L,"材料补充",2773L,"风险提报状态"),
    RISK_STATE_CHECK(2784L,"签约前核验",2773L,"风险提报状态"),
    RISK_STATE_CONTRACT(2785L,"合同录入中",2773L,"风险提报状态"),
    RISK_STATE_CONTRACT_AUDIT(2786L,"合同审核中",2773L,"风险提报状态"),
    RISK_STATE_BID(2787L,"募标中",2773L,"风险提报状态"),
    RISK_STATE_CHECK_AUDIT(2824L,"签约前核验审核",2773L,"风险提报状态"),

    LOAN_CHANNEL_SHENZHEN(1259L,"信用宝",2545L,"放款渠道"),

    IS_RISK_SUBMIT(2825L,"已提报",2780L,"风险提报结果"),
    NO_RISK_SUBMIT(2826L,"未提报",2780L,"风险提报结果"),

    RISK_SUBMIT_REFUSE_CODE(2811L,"风险提报拒贷",2775L,"拒贷节点"),
    VISIT_REFUSE_CODE(2808L,"外访拒贷",2775L,"拒贷节点"),
    SERVICE_REFUSE_REFUSE_CODE(2868L,"客服拒签",2775L,"拒贷节点"),

    GROUP(2468L,"集团",2566L,"机构类型"),
    DEPARTMENT(2469L,"部门",2566L,"机构类型"),
    BUSINESS_DEPARTMENT(2474L,"营业部",2566L,"机构类型"),
    RESIDENTIAL_QUARTERS(2473L,"小区",2566L,"机构类型"),
    LARGE_AREA(2472L,"大区",2566L,"机构类型"),
    OFFICE(2470L,"办公室",2566L,"机构类型"),
    BRANCH_OFFICE(2471L,"分公司",2566L,"机构类型"),
    BUSINESS_GROUP(2475L,"业务组",2566L,"机构类型"),

    CONSULT_SWITCH(2481L,"咨询自动分件配置",2691L,"机构开关项"),

    OPEN_SWITCH(2478L,"开启",2690L,"开关项"),
    CLOSE_SWITCH(2479L,"关闭",2690L,"开关项"),

    SYS_ADMIN_CODE(1L,"管理员",0L,"无"),
    SERVICE_POST_CODE(2720L,"客服专员",0L,"无"),
    CONTRACT_AUDIT_POST_CODE(2733L,"合同审核人员",0L,"无"),
    TEAM_MANAGEMENT_CODE(2721L,"团队经理",0L,"无"),

    FAMILY_PERSON_LINK(1734L,"家庭联系人",2660L,"联系人类型"),
    WORK_PERSON_LINK(1897L,"工作联系人",2660L,"联系人类型"),
    QUICK_PERSON_LINK(2092L,"紧急联系人",2660L,"联系人类型"),
    OWN_PERSON_LINK(1602L,"借款人",2660L,"联系人类型"),

    YES(2486L,"是",2692L,"是否"),
    NO(2487L,"否",2692L,"是否"),

    IS_VALID(2484L,"有效",2687L,"是否有效"),
    NO_VALID(2485L,"无效",2687L,"是否有效"),
	
	LOAN_CHANNEL_XYB(1259L,"信用宝",2545L,"放款渠道"),
	
	CONTRACT_TYPE_ORIGINAL(2730L,"原始合同",2757L,"合同类型"),

	TB_STATE_WTB(2725L,"未推标",2756L,"推标状态"),
	TB_STATE_TBCG(2726L,"推标成功",2756L,"推标状态"),
	TB_STATE_TBSB(2727L,"推标失败",2756L,"推标状态"),
	
	CONTRACT_STATE_KFJQ(2869L,"客服拒签",2755L,"合同状态"),
	CONTRACT_STATE_HTDFH(2723L,"合同待复核",2755L,"合同状态"),
	CONTRACT_STATE_HTDXG(2724L,"合同待修改",2755L,"合同状态"),
	CONTRACT_STATE_HTJD(2903L,"合同拒贷",2755L,"合同状态"),
	CONTRACT_STATE_HTZF(2722L,"合同作废",2755L,"合同状态"),
	CONTRACT_STATE_HTSX(2761L,"合同生效",2755L,"合同状态"),

	/**合同作废原因*/
	CONTRACT_STATE_HTZF_REASON_EDD(2897L,"额度低",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_LXG(2898L,"利息高",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_SJGC(2899L,"时间过长",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_TQHKFYG(2900L,"提前还款费用高",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_ZJYJJ(2901L,"资金已解决",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_HTMJSB(2938L,"合同募集失败",2797L,"合同废除原因"),
	CONTRACT_STATE_HTZF_REASON_QT(2902L,"其他",2797L,"合同废除原因"),
	
	/**合同退回原因*/
	CONTRACT_BACK_REASON_XXYW(1839L,"信息有误",2493L,"合同退回原因"),
	CONTRACT_BACK_REASON_ZLBQ(1840L,"资料不全",2493L,"合同退回原因"),
	CONTRACT_BACK_REASON_QT(1841L,"其它",2493L,"合同退回原因"),
	
	CONTRACT_AUDIT_TG(2894L,"通过",2795L,"合同审核状态"),
	CONTRACT_AUDIT_TH(2895L,"退回合同专员",2795L,"合同审核状态"),
	CONTRACT_AUDIT_JD(2896L,"拒贷",2795L,"合同审核状态"),
	
	PAY_MENT_DETAILS_DCL(2711L,"待处理",2752L,"待交易明细状态"),
	PAY_MENT_DETAILS_CLZ(2712L,"处理中",2752L,"待交易明细状态"),
	PAY_MENT_DETAILS_CLCG(2713L,"处理成功",2752L,"待交易明细状态"),
	PAY_MENT_DETAILS_CLSB(2714L,"处理失败",2752L,"待交易明细状态"),

    CLIENT_GRADE_ONE(2854L,"1",2786L,"用户等级"),
    CLIENT_GRADE_TWO(2855L,"2",2786L,"用户等级"),
    CLIENT_GRADE_THREE(2856L,"3",2786L,"用户等级"),

	CLIENT_ABANDON(2516L,"资金已解决",2710L,"客户放弃"),
	LIVE_JOIN(2561L,"其他",2645L,"共同居住者"),

	IN_OUT_FLAG_DS(2737L,"代收",2760L,"划扣状态"),
	IN_OUT_FLAG_DF(2738L,"代付",2760L,"划扣状态"),

	JD_NODE_HTSHJD(2943L,"合同审核拒贷",2716L,"拒贷环节"),

    /**实名认证*/
    REAL_AUTH_NAME_ONE(2830L,"本人实名认证",2484L,"实名认证"),
    REAL_AUTH_NAME_TWO(2831L,"非本人实名认证",2484L,"实名认证"),
    REAL_AUTH_NAME_THREE(2832L,"未实名认证",2484L,"实名认证"),

    /**缴费方式*/
    PAY_MENT_TYPE_MONTH(2540L,"月缴",2720L,"缴费频率"),
    PAY_MENT_TYPE_JIDU(2541L,"季缴",2720L,"缴费频率"),
    PAY_MENT_TYPE_BYEAE(2542L,"半年缴",2720L,"缴费频率"),
    PAY_MENT_TYPE_YEAR(2833L,"年缴",2720L,"缴费频率"),

	/**签约前核验类型*/
	SIGN_CHECK_TYPE_DKJQ(2779L,"HY1-贷款结清",2772L,"签约前核验类型"),
	SIGN_CHECK_TYPE_YXHT(2780L,"HY2-宜信合同",2772L,"签约前核验类型"),
	SIGN_CHECK_TYPE_GZZM(2781L,"HY3-工作证明",2772L,"签约前核验类型"),
	
	/**图片类型*/
	IMAGE_TYPE_SFZM(1L,"A0",2922L,"图片类型"),
	IMAGE_TYPE_GZZM(2L,"B0",2922L,"图片类型"),
	IMAGE_TYPE_GRSRZM(3L,"C0",2922L,"图片类型"),
	IMAGE_TYPE_QYSRZM(5L,"E0",2922L,"图片类型"),
	IMAGE_TYPE_ZWTJ(44L,"M0",2922L,"图片类型"),
	
	/**房产抵押情况*/
	MORTGAGE_EXPLAIN_NO(2624L,"无抵押/已解压",2735L,"抵押类型"),
	MORTGAGE_EXPLAIN_ONE(2625L,"一次抵押",2735L,"抵押类型"),
	MORTGAGE_EXPLAIN_TWO(2626L,"二次抵押",2735L,"抵押类型"),
	MORTGAGE_EXPLAIN_THREE(2627L,"三次抵押",2735L,"抵押类型"),
	
	/**债权处置方（大类2758）*/
	CAPITAL_TRANSFER_ONE(2732L,"存管",2758L,"债权处置方"),
	CAPITAL_TRANSFER_TWO(2733L,"资管",2758L,"债权处置方"),
	CAPITAL_TRANSFER_THREE(2852L,"代偿",2758L,"债权处置方"),
	
	/**还款计划状态*/
	CONTRACT_REPAYMENT_PLAN_DHK(2320L,"待还款",2587L,"还款计划状态"),
	
	/**还款计划账户类型*/
	CONTRACT_REPAYMENT_PLAN_ACCOUNT_TYPE_GR(2397L,"客户个人账户",2497L,"还款计划账户类型"),

    /**借款人签约状态*/
    HAVE_SUGNED_CONTRACT(3062L,"已签约",2825L,"借款人签约状态"),
    UNSIGNED(3061L,"未签约",2825L,"借款人签约状态"),
    IN_SIGNING_CONTRACT(3063L,"处理中",2825L,"借款人签约状态"),

	/**外访类型*/
	OUT_BOUND_TYPEONE(2606L,"待外访",2731L,"外访类型"),
	OUT_BOUND_TYPETWO(2607L,"外访中",2731L,"外访类型"),
	OUT_BOUND_TYPETHREE(2608L,"待复核",2731L,"外访类型"),
	OUT_BOUND_TYPEFOUR(2609L,"外访完成",2731L,"外访类型"),
	OUT_BOUND_TYPEFIVE(2610L,"外访退回",2731L,"外访类型"),
	
	/**存管操作类型*/
	DEPOSIT_ACCOUNT_STATEMENT_TYPE_ONE(3074L,"换卡",2828L,"存管操作类型"),
	DEPOSIT_ACCOUNT_STATEMENT_TYPE_TWO(3075L,"取消授权",2828L,"存管操作类型"),
	DEPOSIT_ACCOUNT_STATEMENT_TYPE_THREE(3076L,"解绑",2828L,"存管操作类型"),
	
	/**社保类型*/
	SHEBAO_TYPE_ONE(1424L,"当前有",2642L,"社保状态"),
	SHEBAO_TYPE_TWO(1425L,"近六个月有",2642L,"社保状态"),
	SHEBAO_TYPE_THREE(1426L,"无",2642L,"社保状态"),
	SHEBAO_TYPE_FOUR(1427L,"已停缴",2642L,"社保状态"),
	
	/**公积金类型*/
	GJJ_TYPE_ONE(1428L,"当前有",2624L,"公积金状态"),
	GJJ_TYPE_TWO(1429L,"近六个月有",2624L,"公积金状态"),
	GJJ_TYPE_THREE(1430L,"无",2624L,"公积金状态"),
	GJJ_TYPE_FOUR(1431L,"已停缴",2624L,"公积金状态"),
	
	/**职务*/
	COMP_DUTY(0L,"职务",2834L,"职务类型"),
	
	/**学历*/
	N_10(1593L,"博士及以上",2626L,"学历"),
	N_20(1594L,"硕士",2626L,"学历"),
	N_30(1595L,"本科",2626L,"学历"),
	N_40(1596L,"大专",2626L,"学历"),
	N_50(1597L,"高中专",2626L,"学历"),
	N_60(1598L,"初中及以下",2626L,"学历"),
	
	/**婚姻*/
	N_00(2169L,"丧偶",2650L,"婚姻"),
	N_01(2238L,"未婚",2650L,"婚姻"),
	N_02(2239L,"已婚",2650L,"婚姻"),
	N_03(2240L,"离异",2650L,"婚姻"),
	
	/**职务*/
	DUTY_01(3130L,"单位负责人或局级及以上",2834L,"职位"),
	DUTY_02(3131L,"部门负责人或处级",2834L,"职位"),
	DUTY_03(3132L,"科室负责人或科级",2834L,"职位"),
	DUTY_04(3133L,"普通员工或科员",2834L,"职位"),
	DUTY_05(3134L,"临时工或办事员",2834L,"职位"),
	DUTY_06(3135L,"无",2834L,"职位"),
	
	/**社会关系*/
	RELATION_01(2002L,"父母",2664L,"社会关系"),
	RELATION_02(2003L,"其它亲属",2664L,"社会关系"),
	RELATION_03(2004L,"同事",2664L,"社会关系"),
	RELATION_04(2005L,"朋友",2664L,"社会关系"),
	RELATION_05(2007L,"同学",2664L,"社会关系"),
	RELATION_06(2009L,"子女",2664L,"社会关系"),
	RELATION_07(2010L,"兄弟",2664L,"社会关系"),
	RELATION_08(2011L,"姐妹",2664L,"社会关系"),
	RELATION_09(2012L,"商务合作伙伴",2664L,"社会关系"),
	RELATION_10(3092L,"配偶",2664L,"社会关系"),
	
	/**职业*/
	NATURE_01(1394L,"公务员",2644L,"职业"),
	NATURE_02(1395L,"公益型事业单位人员",2644L,"职业"),
	NATURE_03(1396L,"社会公用事业单位人员",2644L,"职业"),
	NATURE_04(1397L,"金融行业人员",2644L,"职业"),
	NATURE_05(1398L,"其它上市公司及其分支机构的正式工作人员",2644L,"职业"),
	NATURE_06(1399L,"国有独资垄断性行业或行业龙头企业的正式工作人员",2644L,"职业"),
	NATURE_07(1401L,"个体户",2644L,"职业"),
	NATURE_08(1402L,"独资企业",2644L,"职业"),
	NATURE_09(1403L,"合伙企业",2644L,"职业"),
	NATURE_10(1404L,"其它",2644L,"职业"),
	
	/**行业*/
	INDUSTRY_01(3110L,"农、林、牧、渔业",2738L,"行业"),
	INDUSTRY_02(3111L,"采矿业",2738L,"行业"),
	INDUSTRY_03(3112L,"制造业",2738L,"行业"),
	INDUSTRY_04(3113L,"电力、热力、燃气及水生产和供应业",2738L,"行业"),
	INDUSTRY_05(3114L,"建筑业",2738L,"行业"),
	INDUSTRY_06(3115L,"批发和零售业",2738L,"行业"),
	INDUSTRY_07(3116L,"交通运输、仓储和邮政业",2738L,"行业"),
	INDUSTRY_08(3117L,"住宿和餐饮业",2738L,"行业"),
	INDUSTRY_09(3118L,"信息传输、软件和信息技术服务业",2738L,"行业"),
	INDUSTRY_10(3119L,"金融业",2738L,"行业"),
	INDUSTRY_11(3120L,"房地产业",2738L,"行业"),
	INDUSTRY_12(3121L,"租赁和商务服务业",2738L,"行业"),
	INDUSTRY_13(3122L,"科学研究和技术服务业",2738L,"行业"),
	INDUSTRY_14(3123L,"水利、环境和公共设施管理业",2738L,"行业"),
	INDUSTRY_15(3124L,"居民服务、修理和其他服务业",2738L,"行业"),
	INDUSTRY_16(3125L,"教育",2738L,"行业"),
	INDUSTRY_17(3126L,"卫生和社会工作",2738L,"行业"),
	INDUSTRY_18(3127L,"国际组织",2738L,"行业"),
	INDUSTRY_19(3128L,"公共管理、社会保障和社会组织",2738L,"行业"),
	INDUSTRY_20(3129L,"文化、体育和娱乐业",2738L,"行业"),
	
	/**公司性质*/
	COMPDUTY_TYPE_01(1493L,"机关事业单位",2623L,"公司性质"),
	COMPDUTY_TYPE_02(1766L,"国有企业",2623L,"公司性质"),
	COMPDUTY_TYPE_03(1853L,"外资企业",2623L,"公司性质"),
	COMPDUTY_TYPE_04(1991L,"私营企业",2623L,"公司性质");
    Long code;// -- 编号
    String name;// -- 名称
    Long parentCode;// -- 大类编号
    String parentName;// -- 大类名称


    SysDictEnum(Long code,String name,Long parentCode,String parentName) {
        this.code = code;
        this.name = name;
        this.parentCode = parentCode;
        this.parentName = parentName;
    }


    public Long getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public Long getParentCode() {
        return parentCode;
    }

    public String getParentName() {
        return parentName;
    }

    public static String getContractAbolishName(Long code){
		String name = null;
		switch (code.intValue()) {
		case 2897:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_EDD.getName();
			break;
		case 2898:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_LXG.getName();
			break;
		case 2899:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_SJGC.getName();
			break;
		case 2900:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_TQHKFYG.getName();
			break;
		case 2901:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_ZJYJJ.getName();
			break;
		case 2902:
			name = SysDictEnum.CONTRACT_STATE_HTZF_REASON_QT.getName();
			break;
		}
		return name;
	}

    public static String getContractBackName(Long code){
		String name = null;
		switch (code.intValue()) {
		case 1839:
			name = SysDictEnum.CONTRACT_BACK_REASON_XXYW.getName();
			break;
		case 1840:
			name = SysDictEnum.CONTRACT_BACK_REASON_ZLBQ.getName();
			break;
		case 1841:
			name = SysDictEnum.CONTRACT_BACK_REASON_QT.getName();
			break;
		}
		return name;
	}
    
    public static String getContractAuditName(Long code){
		String name = null;
		switch (code.intValue()) {
		case 2894:
			name = SysDictEnum.CONTRACT_AUDIT_TG.getName();
			break;
		case 2895:
			name = SysDictEnum.CONTRACT_AUDIT_TH.getName();
			break;
		case 2896:
			name = SysDictEnum.CONTRACT_AUDIT_JD.getName();
			break;
		}
		return name;
	}
}
