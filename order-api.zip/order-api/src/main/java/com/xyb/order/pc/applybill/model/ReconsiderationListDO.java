package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 复议申请列表数据
 * @author         xieqingyang
 * @date           2018/4/19 2:33 PM
*/
public class ReconsiderationListDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    /**主表id*/
    private Long mainId;
    /**申请表id*/
    private Long applyId;
    /**申请编号*/
    private String applyNum;
    /**专案码*/
    private String projectCode;
    /**批贷时间*/
    private Date endauditOverTime;
    /**批贷金额*/
    private BigDecimal agreeAmount = BigDecimal.ZERO;
    /**期限*/
    private Integer agreeProductLimit = 0;
    /**申请金额*/
    private BigDecimal expectMoney = BigDecimal.ZERO;
    /**申请期限*/
    private Integer expectTerm = 0;
    /**产品名称*/
    private String productName;
    /**当前状态*/
    private String state;
    /**复议次数*/
    private Integer reconsiderationQty;
    /**是否拒贷*/
    private String isRefuse;
    /**拒贷原因*/
    private String refuseValue;
    /**销售团队*/
    private String teamOrg;
    /**销售人员*/
    private String managerName;
    /**复议状态*/
    private String reconsiderState;
    /**是否有操作按钮 Y:有 N：无*/
    private String isReconsider;
    /**客服人员*/
    private String serviceName;
    /**客户姓名*/
    private String clientName;
    /**推荐人姓名*/
    private String recommender;
    /**确认金额*/
    private BigDecimal confirmAmout;
    @JsonIgnore
    private Integer stateCode;

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public Date getEndauditOverTime() {
        return endauditOverTime;
    }

    public void setEndauditOverTime(Date endauditOverTime) {
        this.endauditOverTime = endauditOverTime;
    }

    public BigDecimal getAgreeAmount() {
        return agreeAmount;
    }

    public void setAgreeAmount(BigDecimal agreeAmount) {
        this.agreeAmount = agreeAmount;
    }

    public Integer getAgreeProductLimit() {
        return agreeProductLimit;
    }

    public void setAgreeProductLimit(Integer agreeProductLimit) {
        this.agreeProductLimit = agreeProductLimit;
    }

    public BigDecimal getExpectMoney() {
        return expectMoney;
    }

    public void setExpectMoney(BigDecimal expectMoney) {
        this.expectMoney = expectMoney;
    }

    public Integer getExpectTerm() {
        return expectTerm;
    }

    public void setExpectTerm(Integer expectTerm) {
        this.expectTerm = expectTerm;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getReconsiderationQty() {
        return reconsiderationQty;
    }

    public void setReconsiderationQty(Integer reconsiderationQty) {
        this.reconsiderationQty = reconsiderationQty;
    }

    public String getIsRefuse() {
        return isRefuse;
    }

    public void setIsRefuse(String isRefuse) {
        this.isRefuse = isRefuse;
    }

    public String getRefuseValue() {
        return refuseValue;
    }

    public void setRefuseValue(String refuseValue) {
        this.refuseValue = refuseValue;
    }

    public String getTeamOrg() {
        return teamOrg;
    }

    public void setTeamOrg(String teamOrg) {
        this.teamOrg = teamOrg;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public String getReconsiderState() {
        return reconsiderState;
    }

    public void setReconsiderState(String reconsiderState) {
        this.reconsiderState = reconsiderState;
    }

    public String getIsReconsider() {
        if (NodeStateConstant.RECONSIDERATION_STATE_LIST.contains(this.stateCode) && this.reconsiderationQty < CurrencyConstant.RECONSIDERATION_QTY) {
            return "Y";
        }else {
            return "N";
        }
    }

    public void setIsReconsider(String isReconsider) {
        this.isReconsider = isReconsider;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Integer getStateCode() {
        return stateCode;
    }

    public void setStateCode(Integer stateCode) {
        this.stateCode = stateCode;
    }

    public String getRecommender() {
        return recommender;
    }

    public void setRecommender(String recommender) {
        this.recommender = recommender;
    }

    public BigDecimal getConfirmAmout() {
        return confirmAmout;
    }

    public void setConfirmAmout(BigDecimal confirmAmout) {
        this.confirmAmout = confirmAmout;
    }

    @Override
    public String toString() {
        return "ReconsiderationListDO{" +
                "mainId=" + mainId +
                ", applyId=" + applyId +
                ", applyNum='" + applyNum + '\'' +
                ", projectCode='" + projectCode + '\'' +
                ", endauditOverTime=" + endauditOverTime +
                ", agreeAmount=" + agreeAmount +
                ", agreeProductLimit=" + agreeProductLimit +
                ", expectMoney=" + expectMoney +
                ", expectTerm=" + expectTerm +
                ", productName='" + productName + '\'' +
                ", state='" + state + '\'' +
                ", reconsiderationQty=" + reconsiderationQty +
                ", isRefuse='" + isRefuse + '\'' +
                ", refuseValue='" + refuseValue + '\'' +
                ", teamOrg='" + teamOrg + '\'' +
                ", managerName='" + managerName + '\'' +
                ", reconsiderState='" + reconsiderState + '\'' +
                ", isReconsider='" + isReconsider + '\'' +
                ", serviceName='" + serviceName + '\'' +
                ", clientName='" + clientName + '\'' +
                ", recommender='" + recommender + '\'' +
                ", confirmAmout=" + confirmAmout +
                ", stateCode=" + stateCode +
                '}';
    }
}
