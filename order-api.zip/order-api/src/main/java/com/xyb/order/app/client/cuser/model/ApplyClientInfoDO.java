package com.xyb.order.app.client.cuser.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description: 用户信息
 * @author: xieqingyang
 * @createDate: 2018/5/15 下午1:43
 */
public class ApplyClientInfoDO implements IBaseModel {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String name;
	private Long gender;
	private Date birthday;
	private String idcard;
	private String phone;
	private String address;
	private Integer nation;
	private Long isvalid;
	private Date idcardStartTime;
	private Date idcardEndTime;
	private String idcardPoliceStation;
	private String frontFileKey;
	private String backFileKey;
	private String idcardFrontSide;
	private String idcardBackSide;
	private Long certificationState;
	private Date createTime;
	private Long createUser;
	private Date modifyTime;
	private Long modifyUser;
	private Long clientUserId;
	private Long agreementIsCompleted;
	private String customerId;
	private Date allowableEntryTime;
	private Integer loanQty;// 成功借款次数
	private Long referee;// 推荐人
	private Integer vip;// VIP等级
	private double profitBalance;// 分润余额
	private Long leader;// 虚拟销售团队团长

	public Integer getLoanQty() {
		return loanQty;
	}

	public void setLoanQty(Integer loanQty) {
		this.loanQty = loanQty;
	}

	public Long getReferee() {
		return referee;
	}

	public void setReferee(Long referee) {
		this.referee = referee;
	}

	public Integer getVip() {
		return vip;
	}

	public void setVip(Integer vip) {
		this.vip = vip;
	}

	public double getProfitBalance() {
		return profitBalance;
	}

	public void setProfitBalance(double profitBalance) {
		this.profitBalance = profitBalance;
	}

	public Long getLeader() {
		return leader;
	}

	public void setLeader(Long leader) {
		this.leader = leader;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getGender() {
		return gender;
	}

	public void setGender(Long gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getNation() {
		return nation;
	}

	public void setNation(Integer nation) {
		this.nation = nation;
	}

	public Long getIsvalid() {
		return isvalid;
	}

	public void setIsvalid(Long isvalid) {
		this.isvalid = isvalid;
	}

	public Date getIdcardStartTime() {
		return idcardStartTime;
	}

	public void setIdcardStartTime(Date idcardStartTime) {
		this.idcardStartTime = idcardStartTime;
	}

	public Date getIdcardEndTime() {
		return idcardEndTime;
	}

	public void setIdcardEndTime(Date idcardEndTime) {
		this.idcardEndTime = idcardEndTime;
	}

	public String getIdcardPoliceStation() {
		return idcardPoliceStation;
	}

	public void setIdcardPoliceStation(String idcardPoliceStation) {
		this.idcardPoliceStation = idcardPoliceStation;
	}

	public String getFrontFileKey() {
		return frontFileKey;
	}

	public void setFrontFileKey(String frontFileKey) {
		this.frontFileKey = frontFileKey;
	}

	public String getBackFileKey() {
		return backFileKey;
	}

	public void setBackFileKey(String backFileKey) {
		this.backFileKey = backFileKey;
	}

	public String getIdcardFrontSide() {
		return idcardFrontSide;
	}

	public void setIdcardFrontSide(String idcardFrontSide) {
		this.idcardFrontSide = idcardFrontSide;
	}

	public String getIdcardBackSide() {
		return idcardBackSide;
	}

	public void setIdcardBackSide(String idcardBackSide) {
		this.idcardBackSide = idcardBackSide;
	}

	public Long getCertificationState() {
		return certificationState;
	}

	public void setCertificationState(Long certificationState) {
		this.certificationState = certificationState;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Long getClientUserId() {
		return clientUserId;
	}

	public void setClientUserId(Long clientUserId) {
		this.clientUserId = clientUserId;
	}

	public Long getAgreementIsCompleted() {
		return agreementIsCompleted;
	}

	public void setAgreementIsCompleted(Long agreementIsCompleted) {
		this.agreementIsCompleted = agreementIsCompleted;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Date getAllowableEntryTime() {
		return allowableEntryTime;
	}

	public void setAllowableEntryTime(Date allowableEntryTime) {
		this.allowableEntryTime = allowableEntryTime;
	}

	@Override
	public String toString() {
		return "ApplyClientInfoDO{" + "id=" + id + ", name='" + name + '\'' + ", gender=" + gender + ", birthday="
				+ birthday + ", idcard='" + idcard + '\'' + ", phone='" + phone + '\'' + ", address='" + address + '\''
				+ ", nation=" + nation + ", isvalid=" + isvalid + ", idcardStartTime=" + idcardStartTime
				+ ", idcardEndTime=" + idcardEndTime + ", idcardPoliceStation='" + idcardPoliceStation + '\''
				+ ", frontFileKey='" + frontFileKey + '\'' + ", backFileKey='" + backFileKey + '\''
				+ ", idcardFrontSide='" + idcardFrontSide + '\'' + ", idcardBackSide='" + idcardBackSide + '\''
				+ ", certificationState=" + certificationState + ", createTime=" + createTime + ", createUser="
				+ createUser + ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser + ", clientUserId="
				+ clientUserId + ", agreementIsCompleted=" + agreementIsCompleted + ", customerId='" + customerId + '\''
				+ ", allowableEntryTime=" + allowableEntryTime + '}';
	}
}
