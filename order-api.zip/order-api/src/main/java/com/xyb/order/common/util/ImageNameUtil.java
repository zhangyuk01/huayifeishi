package com.xyb.order.common.util;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @ClassName ImmageNameUtil
 * @author ZhangYu
 * @date 2018年4月17号
 */
public class ImageNameUtil {
	/**
	 * 批量上传图片命名规则 
	 * @param fileName
	 * @return
	 */
	public static Map<String, Object> analyzeFileName(String fileName) {
		boolean result = false;
		int sort=0;
		String first="";
		String second="";
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String[] data = (String[]) fileName.split("-");
		if (data.length == 2) {
			first = data[0];
			second = data[1];
			Pattern pattern = Pattern.compile("[0-9]*");
			Matcher isNum = pattern.matcher(second);
			if (!isNum.matches() || second.length() == 1) {
				result = false;
			}
			if (first.length() == 2) {
				String first1 = first.substring(0, 1);
				String first2 = first.substring(1, 2);
				int ascm = (int) first1.charAt(0);
				int ascm2 = (int)first2.charAt(0);
				if (ascm >= 65 && ascm <= 77) {
					result = true;
				} else {
					result = false;
				}
				if (ascm2 != 48) {
					result = false;
				}
			} else {
				result = false;
			}
		} else {
			result = false;
		}
		String fileCode=first;
		resultMap.put("fileClassificationCode", fileCode);
		if(result){
			sort=Integer.parseInt(second);
			resultMap.put("sort", sort);
			resultMap.put("errorType", "0");
		}else{
			resultMap.put("errorType", "1");
		}
		return resultMap;
	}
}
