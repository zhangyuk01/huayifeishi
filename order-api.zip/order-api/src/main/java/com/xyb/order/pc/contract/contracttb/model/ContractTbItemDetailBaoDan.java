/**
 * 
 */
package com.xyb.order.pc.contract.contracttb.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.contracttb.model
 * @description : TODO
 * @createDate : 2018年8月31日 下午3:23:48
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ContractTbItemDetailBaoDan implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5634758754408249631L;

	/**缴费方式*/
	private String paymentType;
	/**年缴费额*/
	private String paymentYearSum;
	/**投保公司*/
	private String company;
	/**保单生效时间*/
	private String paymentPolicyStartDate;
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentYearSum() {
		return paymentYearSum;
	}
	public void setPaymentYearSum(String paymentYearSum) {
		this.paymentYearSum = paymentYearSum;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getPaymentPolicyStartDate() {
		return paymentPolicyStartDate;
	}
	public void setPaymentPolicyStartDate(String paymentPolicyStartDate) {
		this.paymentPolicyStartDate = paymentPolicyStartDate;
	}
	@Override
	public String toString() {
		return "ContractTbItemDetailBaoDan [paymentType=" + paymentType + ", paymentYearSum=" + paymentYearSum
				+ ", company=" + company + ", paymentPolicyStartDate=" + paymentPolicyStartDate + "]";
	}
	
	
}
