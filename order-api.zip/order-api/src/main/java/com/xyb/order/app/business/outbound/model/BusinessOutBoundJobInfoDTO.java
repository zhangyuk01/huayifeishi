package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访工作信息DTO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundJobInfoDTO implements IBaseModel {

	private static final long serialVersionUID = -3905339419765270913L;

	private Long id;

	/**申请id*/
	@NotNull(message = "visitMainId不能为空")
    private Long visitMainId;

    /**单位名称是否一致（大类2692）*/
    @NotNull(message = "isCompNameSame不能为空")
    private Long isCompNameSame;

    /**外访后单位名称*/
    @NotNull(message = "compName不能为空")
    private String compName;

    /**单位地址是否一致(大类2692)*/
    @NotNull(message = "isCompAddressSame不能为空")
    private Long isCompAddressSame;

    /**外访后单位地址*/
	@NotNull(message = "compAllAddr不能为空")
    private String compAllAddr;

    /**单位地址省*/
    @NotNull(message = "compAddrProvince不能为空")
    private Long compAddrProvince;

    /**单位地址市*/
    @NotNull(message = "compAddrCity不能为空")
    private Long compAddrCity;

    /**单位地址区*/
    @NotNull(message = "compAddrArea不能为空")
    private Long compAddrArea;

    /**单位地址街道门牌详细信息*/
    @NotNull(message = "compAddrDetail不能为空")
    private String compAddrDetail;

    /**单位电话是否一致(大类2692)*/
    @NotNull(message = "isCompTellSame不能为空")
    private Long isCompTellSame;

	/**外访后单位电话区号*/
	@NotNull(message = "compTellArea 不能为空")
	private String compTellArea;

    /**外访后单位电话*/
    @NotNull(message = "compTell 不能为空")
    private String compTell;

    /**进出单位情况（大类2723）*/
    @NotNull(message = "inOutCompType不能为空")
    private Long inOutCompType;

    /**单位电话位置（大类2724）*/
    @NotNull(message = "compTellSeat不能为空")
    private Long compTellSeat;

    /**单位电话位置其他*/
    private String compTellSeatQt;

    /**在职信息确认，多选英文逗号隔开存储(大类2725)*/
    @NotNull(message = "onJobConfirm 不能为空")
    private String onJobConfirm;

    /**备注*/
    private String remark;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public Long getIsCompNameSame() {
		return isCompNameSame;
	}

	public void setIsCompNameSame(Long isCompNameSame) {
		this.isCompNameSame = isCompNameSame;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public Long getIsCompAddressSame() {
		return isCompAddressSame;
	}

	public void setIsCompAddressSame(Long isCompAddressSame) {
		this.isCompAddressSame = isCompAddressSame;
	}

	public String getCompAllAddr() {
		return compAllAddr;
	}

	public void setCompAllAddr(String compAllAddr) {
		this.compAllAddr = compAllAddr;
	}

	public Long getCompAddrProvince() {
		return compAddrProvince;
	}

	public void setCompAddrProvince(Long compAddrProvince) {
		this.compAddrProvince = compAddrProvince;
	}

	public Long getCompAddrCity() {
		return compAddrCity;
	}

	public void setCompAddrCity(Long compAddrCity) {
		this.compAddrCity = compAddrCity;
	}

	public Long getCompAddrArea() {
		return compAddrArea;
	}

	public void setCompAddrArea(Long compAddrArea) {
		this.compAddrArea = compAddrArea;
	}

	public String getCompAddrDetail() {
		return compAddrDetail;
	}

	public void setCompAddrDetail(String compAddrDetail) {
		this.compAddrDetail = compAddrDetail;
	}

	public Long getIsCompTellSame() {
		return isCompTellSame;
	}

	public void setIsCompTellSame(Long isCompTellSame) {
		this.isCompTellSame = isCompTellSame;
	}

	public String getCompTell() {
		return compTell;
	}

	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}

	public Long getInOutCompType() {
		return inOutCompType;
	}

	public void setInOutCompType(Long inOutCompType) {
		this.inOutCompType = inOutCompType;
	}

	public Long getCompTellSeat() {
		return compTellSeat;
	}

	public void setCompTellSeat(Long compTellSeat) {
		this.compTellSeat = compTellSeat;
	}

	public String getCompTellSeatQt() {
		return compTellSeatQt;
	}

	public void setCompTellSeatQt(String compTellSeatQt) {
		this.compTellSeatQt = compTellSeatQt;
	}

	public String getOnJobConfirm() {
		return onJobConfirm;
	}

	public void setOnJobConfirm(String onJobConfirm) {
		this.onJobConfirm = onJobConfirm;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getCompTellArea() {
		return compTellArea;
	}

	public void setCompTellArea(String compTellArea) {
		this.compTellArea = compTellArea;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundJobInfoDTO{" +
				"id=" + id +
				", visitMainId=" + visitMainId +
				", isCompNameSame=" + isCompNameSame +
				", compName='" + compName + '\'' +
				", isCompAddressSame=" + isCompAddressSame +
				", compAllAddr='" + compAllAddr + '\'' +
				", compAddrProvince=" + compAddrProvince +
				", compAddrCity=" + compAddrCity +
				", compAddrArea=" + compAddrArea +
				", compAddrDetail='" + compAddrDetail + '\'' +
				", isCompTellSame=" + isCompTellSame +
				", compTellArea='" + compTellArea + '\'' +
				", compTell='" + compTell + '\'' +
				", inOutCompType=" + inOutCompType +
				", compTellSeat=" + compTellSeat +
				", compTellSeatQt='" + compTellSeatQt + '\'' +
				", onJobConfirm='" + onJobConfirm + '\'' +
				", remark='" + remark + '\'' +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				'}';
	}
}
