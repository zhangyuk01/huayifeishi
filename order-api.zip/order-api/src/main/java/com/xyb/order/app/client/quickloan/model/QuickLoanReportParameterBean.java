package com.xyb.order.app.client.quickloan.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class QuickLoanReportParameterBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 借款人id
	 */
	private Long clientId;
	/**
	 * 借款人姓名
	 */
	private String clientName;
	/**
	 * 身份证号
	 */
	private String clientIdcard;
	/**
	 * 联系电话
	 */
	private String clientPhone;
	/**
	 * 营业部ID
	 */
	private Long orgId;
	/**
	 * 产品id
	 */
	private Long productId;
	/**
	 * 业务类型（2848）
	 */
	private Long businessType;
	/**
	 * 业务金额
	 */
	private BigDecimal businessMoney;
	public Long getClientId() {
		return clientId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientIdcard() {
		return clientIdcard;
	}
	public void setClientIdcard(String clientIdcard) {
		this.clientIdcard = clientIdcard;
	}
	public String getClientPhone() {
		return clientPhone;
	}
	public void setClientPhone(String clientPhone) {
		this.clientPhone = clientPhone;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getBusinessType() {
		return businessType;
	}
	public void setBusinessType(Long businessType) {
		this.businessType = businessType;
	}
	public BigDecimal getBusinessMoney() {
		return businessMoney;
	}
	public void setBusinessMoney(BigDecimal businessMoney) {
		this.businessMoney = businessMoney;
	}
	@Override
	public String toString() {
		return "QuickLoanReportParameterBean [clientId=" + clientId
				+ ", clientName=" + clientName + ", clientIdcard="
				+ clientIdcard + ", clientPhone=" + clientPhone + ", orgId="
				+ orgId + ", productId=" + productId + ", businessType="
				+ businessType + ", businessMoney=" + businessMoney + "]";
	}
	
}
