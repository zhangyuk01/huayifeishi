package com.xyb.order.pc.consultation.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

/**
 * Created by xieqingyang on 2018/3/22.
 * 咨询列表查询条件信息
 */
public class ConsultationDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    @JsonIgnore
    private Page page = new Page();// -- 分页

    private String clientName; //客户姓名
    private String clientIdCard; //客户身份证
    private String clientTell; //客户电话
    private Long isAllot; //是否分配
    private Long serviceUid;// -- 客服专员id

    @JsonIgnore
    private Long orgId;// -- 所属营业部ID
    @JsonIgnore
    private List<Integer> list;

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientIdCard() {
        return clientIdCard;
    }

    public void setClientIdCard(String clientIdCard) {
        this.clientIdCard = clientIdCard;
    }

    public String getClientTell() {
        return clientTell;
    }

    public void setClientTell(String clientTell) {
        this.clientTell = clientTell;
    }

    public Long getIsAllot() {
        return isAllot;
    }

    public void setIsAllot(Long isAllot) {
        this.isAllot = isAllot;
    }

    public Long getServiceUid() {
        return serviceUid;
    }

    public void setServiceUid(Long serviceUid) {
        this.serviceUid = serviceUid;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public List<Integer> getList() {
        return list;
    }

    public void setList(List<Integer> list) {
        this.list = list;
    }
}
