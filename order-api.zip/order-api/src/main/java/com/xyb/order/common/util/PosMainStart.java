package com.xyb.order.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : houlvshuang
 * @projectName : util
 * @package : com.xyb.util
 * @description : 合规项目与深圳交互post工具类
 * @createDate : 2017/12/14 16:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class PosMainStart {
    private static final Logger logger = LoggerFactory.getLogger(PosMainStart.class);

	/**
	 * post方法
	 * @param url  
	 * @param dataJson
	 * @return String
	 * @throws Exception
	 */
	public static String sendPost(String url,String dataJson) throws Exception {
		/** 请求方式一*/
		String result = HttpTools.sendPost(url, dataJson,"utf-8");;
		return result;

	}
	

	
	@Test
	public void getAttr() throws Exception {
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("userId", "2"));
		params.add(new BasicNameValuePair("userId", "IDCARD_P"));
		String data="{\"result\":\"1\",\"applyId\":\"b75960e0-200c-48c4-bba2-f2d53e36d0aa\",\"sysid\":\"oms_gd\",\"submitNode\":\"OMS_ZSTJ\"}";
        String url="http://localhost:8090/xyb_oms_core/process/applybill/cheatPostHandle.do";

		String result = HttpTools.sendPost(url, data,"utf-8");
		System.out.println(result);
	}
}
