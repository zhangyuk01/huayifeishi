package com.xyb.order.pc.applybill.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillInfoAllTempSaveDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private ApplyBillInfoTempSaveDTO applyBillInfoTempSaveDTO; //申请单临时保存对象 
	private ApplyClientInfoTempSaveDTO applyClientInfoTempSaveDTO;//客户临时保存对象
	private ApplyPersonInfoTempSaveDTO applyPersonInfoTempSaveDTO; // 个人信息临时保存对象
	private ApplyJobInfoTempSaveDTO applyJobInfoTempSaveDTO;//工作信息临时保存对象
	private ApplyPrivateInfoTempSaveDTO applyPrivateInfoTempSaveDTO;//私营信息临时保存对象
	
	private List<ApplyLinkmanInfoTempSaveDTO> homeLinkManInfoTempSaveDTO;//家庭联系人临时保存对象
	private List<ApplyLinkmanInfoTempSaveDTO> workLinkManInfoTempSaveDTO;//工作联系人临时保存对象
	private List<ApplyLinkmanInfoTempSaveDTO> urgentLinkManInfoTempSaveDTO;//紧急联系人临时保存对象
	private List<ApplyFamilyChildrenDTO> familyChildrenList;//子女信息
	
	
	public ApplyBillInfoTempSaveDTO getApplyBillInfoTempSaveDTO() {
		return applyBillInfoTempSaveDTO;
	}
	public void setApplyBillInfoTempSaveDTO(ApplyBillInfoTempSaveDTO applyBillInfoTempSaveDTO) {
		this.applyBillInfoTempSaveDTO = applyBillInfoTempSaveDTO;
	}

	public ApplyClientInfoTempSaveDTO getApplyClientInfoTempSaveDTO() {
		return applyClientInfoTempSaveDTO;
	}
	public void setApplyClientInfoTempSaveDTO(ApplyClientInfoTempSaveDTO applyClientInfoTempSaveDTO) {
		this.applyClientInfoTempSaveDTO = applyClientInfoTempSaveDTO;
	}
	public ApplyPersonInfoTempSaveDTO getApplyPersonInfoTempSaveDTO() {
		return applyPersonInfoTempSaveDTO;
	}
	public void setApplyPersonInfoTempSaveDTO(ApplyPersonInfoTempSaveDTO applyPersonInfoTempSaveDTO) {
		this.applyPersonInfoTempSaveDTO = applyPersonInfoTempSaveDTO;
	}
	public ApplyJobInfoTempSaveDTO getApplyJobInfoTempSaveDTO() {
		return applyJobInfoTempSaveDTO;
	}
	public void setApplyJobInfoTempSaveDTO(ApplyJobInfoTempSaveDTO applyJobInfoTempSaveDTO) {
		this.applyJobInfoTempSaveDTO = applyJobInfoTempSaveDTO;
	}
	public ApplyPrivateInfoTempSaveDTO getApplyPrivateInfoTempSaveDTO() {
		return applyPrivateInfoTempSaveDTO;
	}
	public void setApplyPrivateInfoTempSaveDTO(ApplyPrivateInfoTempSaveDTO applyPrivateInfoTempSaveDTO) {
		this.applyPrivateInfoTempSaveDTO = applyPrivateInfoTempSaveDTO;
	}
	public List<ApplyLinkmanInfoTempSaveDTO> getHomeLinkManInfoTempSaveDTO() {
		return homeLinkManInfoTempSaveDTO;
	}
	public void setHomeLinkManInfoTempSaveDTO(List<ApplyLinkmanInfoTempSaveDTO> homeLinkManInfoTempSaveDTO) {
		this.homeLinkManInfoTempSaveDTO = homeLinkManInfoTempSaveDTO;
	}
	public List<ApplyLinkmanInfoTempSaveDTO> getWorkLinkManInfoTempSaveDTO() {
		return workLinkManInfoTempSaveDTO;
	}
	public void setWorkLinkManInfoTempSaveDTO(List<ApplyLinkmanInfoTempSaveDTO> workLinkManInfoTempSaveDTO) {
		this.workLinkManInfoTempSaveDTO = workLinkManInfoTempSaveDTO;
	}
	public List<ApplyLinkmanInfoTempSaveDTO> getUrgentLinkManInfoTempSaveDTO() {
		return urgentLinkManInfoTempSaveDTO;
	}
	public void setUrgentLinkManInfoTempSaveDTO(List<ApplyLinkmanInfoTempSaveDTO> urgentLinkManInfoTempSaveDTO) {
		this.urgentLinkManInfoTempSaveDTO = urgentLinkManInfoTempSaveDTO;
	}
	public List<ApplyFamilyChildrenDTO> getFamilyChildrenList() {
		return familyChildrenList;
	}
	public void setFamilyChildrenList(List<ApplyFamilyChildrenDTO> familyChildrenList) {
		this.familyChildrenList = familyChildrenList;
	}
	
}
