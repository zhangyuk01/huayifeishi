package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditInsuranceAllDTO;

/**
 * @ClassName AuditInsuranceService
 * @author ZhangYu
 * @date 2018年5月4号
 */

public interface AuditInsuranceService {
	
	/**
	 * 根据申请单ID查询保单证明 
	 * @param applyId
	 * @return
	 */
	RestResponse queryAuditInsuranceListByApplyId(Long applyId)throws Exception;
	
	/**
	 * 暂存保单证明清单 
	 * @param auditInsuranceAllDTO
	 * @return
	 */
	RestResponse auditInsuranceTempSave(AuditInsuranceAllDTO auditInsuranceAllDTO)throws Exception;
	
	/**
	 * 根据保单证明ID删除保单信息
	 * @param id
	 * @return
	 */
	RestResponse auditInsuranceDelById(Long id)throws Exception;

}
