package com.xyb.order.pc.creditreport.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditAllPersonalIncomeDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long applyId;
	private List<AuditPersonalIncomeDTO> auditPersonalIncomeDTOs;
	
	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public List<AuditPersonalIncomeDTO> getAuditPersonalIncomeDTOs() {
		return auditPersonalIncomeDTOs;
	}

	public void setAuditPersonalIncomeDTOs(List<AuditPersonalIncomeDTO> auditPersonalIncomeDTOs) {
		this.auditPersonalIncomeDTOs = auditPersonalIncomeDTOs;
	}

}
