package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;

/**
* @description:    算话注册model
* @author:         xieqingyang
* @createDate:     2018/5/17 上午10:14
*/
public class SuanHuaRegisterDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private String retCode;
    private String phone;
    private String activationCode;
    private String iid;
    private String loginname;
    private String loginpwd;


    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getIid() {
        return iid;
    }

    public void setIid(String iid) {
        this.iid = iid;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getLoginpwd() {
        return loginpwd;
    }

    public void setLoginpwd(String loginpwd) {
        this.loginpwd = loginpwd;
    }
}
