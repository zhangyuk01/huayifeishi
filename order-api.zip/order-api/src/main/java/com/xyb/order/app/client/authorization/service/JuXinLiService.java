package com.xyb.order.app.client.authorization.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.authorization.model.JuXinLiBaoDanDTO;
import com.xyb.order.app.client.authorization.model.JuXinLiCollectDTO;

/**
* @description:    聚信力认证相关接口
* @author:         xieqingyang
* @createDate:     2018/5/17 上午10:46
*/
public interface JuXinLiService {


    /**
    * 聚信立提交申请表单获取回执信息（运营商）
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/17 上午11:25
    */
    RestResponse subApplyGetReturnMsg()throws Exception;

    /**
     * @description 调用聚信立数据源采集请求（运营商）
     * @author      xieqingyang
     * @CreatedDate 2018/5/20 上午12:34
     * @Version     1.0
     * @param juXinLiCollectDTO 调用所需参数
     * @return 返回封装数据
     */
    RestResponse getCollectJuXinLi(JuXinLiCollectDTO juXinLiCollectDTO);


    /**
    * 获取支持的数据源具体网站列表(保单)
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/17 上午11:32
    */
    RestResponse getAllInsuranceWebsite();


    /**
    * 提交保险网站数据采集申请接口(保单)
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/17 上午11:33
    */
    RestResponse collectJuXinLiBaoDan(JuXinLiBaoDanDTO juXinLiBaoDanDTO)throws Exception;
}
