package com.xyb.order.pc.outbound.model;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访实地征信与产调提交DTO model
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailSubmitCreditAndPropertySurveyDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4734262252303347112L;
	/**申请id*/
	@Valid
	@NotNull(message = "applyId不能为空")
	private Long applyId;
	/**实地时间*/
	@NotNull(message = "visitDate不能为空")
	private Date visitDate;
	/**客户综合描述*/
	@NotEmpty(message = "customerIntegratedDescription不能为空")
	private String customerIntegratedDescription;
	/**实地征信工作信息*/
	private ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO;
	/**实地征信家庭信息*/
	private List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs;
	/**实地征信经营信息*/
	private List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs;
	/**外访产调*/
	private ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO;
	
	public ApplyVisitCreditJobInfoDTO getApplyVisitCreditJobInfoDTO() {
		return applyVisitCreditJobInfoDTO;
	}
	public void setApplyVisitCreditJobInfoDTO(ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO) {
		this.applyVisitCreditJobInfoDTO = applyVisitCreditJobInfoDTO;
	}
	public List<ApplyVisitCreditFamilyInfoDTO> getApplyVisitCreditFamilyInfoDTOs() {
		return applyVisitCreditFamilyInfoDTOs;
	}
	public void setApplyVisitCreditFamilyInfoDTOs(List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs) {
		this.applyVisitCreditFamilyInfoDTOs = applyVisitCreditFamilyInfoDTOs;
	}
	public List<ApplyVisitCreditManagermentInfoDTO> getApplyVisitCreditManagermentInfoDTOs() {
		return applyVisitCreditManagermentInfoDTOs;
	}
	public void setApplyVisitCreditManagermentInfoDTOs(
			List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs) {
		this.applyVisitCreditManagermentInfoDTOs = applyVisitCreditManagermentInfoDTOs;
	}
	public ApplyVisitPropertySurveyDTO getApplyVisitPropertySurveyDTO() {
		return applyVisitPropertySurveyDTO;
	}
	public void setApplyVisitPropertySurveyDTO(ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO) {
		this.applyVisitPropertySurveyDTO = applyVisitPropertySurveyDTO;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	public String getCustomerIntegratedDescription() {
		return customerIntegratedDescription;
	}
	public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
		this.customerIntegratedDescription = customerIntegratedDescription;
	}
	@Override
	public String toString() {
		return "OutBoundDetailSubmitCreditAndPropertySurveyDTO [applyId=" + applyId + ", visitDate=" + visitDate
				+ ", customerIntegratedDescription=" + customerIntegratedDescription + ", applyVisitCreditJobInfoDTO="
				+ applyVisitCreditJobInfoDTO + ", applyVisitCreditFamilyInfoDTOs=" + applyVisitCreditFamilyInfoDTOs
				+ ", applyVisitCreditManagermentInfoDTOs=" + applyVisitCreditManagermentInfoDTOs
				+ ", applyVisitPropertySurveyDTO=" + applyVisitPropertySurveyDTO + "]";
	}
}
