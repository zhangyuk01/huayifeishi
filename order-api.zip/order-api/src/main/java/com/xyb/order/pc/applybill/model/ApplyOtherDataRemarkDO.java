package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyOtherDataRemarkDO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	private Long id;
	private Long applyId;
	private String remark;
	private Date createTime;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
}
