package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xyb.order.common.constant.CurrencyConstant;

/**
* @description:    CAPP借款记录
* @author:         xieqingyang
* @createDate:     2018/5/18 下午5:20
*/
public class ApplyRecordVO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**主表ID*/
    private Long mainId;
    /**申请ID*/
    private Long applyId;
    /**用户信息表ID*/
    @JsonIgnore
    private Long clientId;
    /**产品名称*/
    private String productName = "";
    /**产品说明*/
    private String remark = "";
    /**申请时间*/
    private String applyTime = "";
    /**显示状态名称*/
    private String state = "";
    /**按钮状态名称*/
    private String buttonName = "";
    /**是否有按钮 Y:是 N:否*/
    private String isButton = CurrencyConstant.N;
    /**按钮code BCCL:补充资料 CKHT:查看合同  QKH:去开户 QBK:去绑卡 QSQ:去授权 QQYHK:去签约划扣协议 QQYXY:去签约借款人声明函&委托扣款授权书、借款人服务协议*/
    private String buttonType = "";
    /**合同废除状态 大类2797*/
    @JsonIgnore
    private String contractAbolition;
    /**放款渠道*/
    @JsonIgnore
    private Long loanChannel;
    /**状态code*/
    @JsonIgnore
    private Integer stateCode;
    /** 签约时间 */
    private String signDate;
    /** 营业部地址 */
    private String orgAddr;
    /** 营业部名称*/
    private String orgName;
    /** 营业部电话*/
    private String orgPhone;
   
    /**remark字段拆开*/
    private BigDecimal expectMoney;
    private Integer expectTerm;
    private String productProportion;
   
    private BigDecimal serviceProportion;
    private BigDecimal minPorductProportion;
    private BigDecimal maxProductProportion;
    
    /**优先合同编号 其次申请编号*/ 
    private String recordNum;
    /**
     * 是否展示蓝色字体（当日已满额，请明日再试）2486：展示；2487：不展示
     */
    private Long isShow;


    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(String applyTime) {
        this.applyTime = applyTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getButtonName() {
        return buttonName;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }

    public String getIsButton() {
        return isButton;
    }

    public void setIsButton(String isButton) {
        this.isButton = isButton;
    }

    public String getButtonType() {
        return buttonType;
    }

    public void setButtonType(String buttonType) {
        this.buttonType = buttonType;
    }

    public String getContractAbolition() {
        return contractAbolition;
    }

    public void setContractAbolition(String contractAbolition) {
        this.contractAbolition = contractAbolition;
    }

    public Long getLoanChannel() {
        return loanChannel;
    }

    public void setLoanChannel(Long loanChannel) {
        this.loanChannel = loanChannel;
    }

    public Integer getStateCode() {
        return stateCode;
    }

    public void setStateCode(Integer stateCode) {
        this.stateCode = stateCode;
    }

    public String getSignDate() {
        return signDate;
    }

    public void setSignDate(String signDate) {
        this.signDate = signDate;
    }

    public String getOrgAddr() {
        return orgAddr;
    }

    public void setOrgAddr(String orgAddr) {
        this.orgAddr = orgAddr;
    }
  

	public Integer getExpectTerm() {
		return expectTerm;
	}

	public void setExpectTerm(Integer expectTerm) {
		this.expectTerm = expectTerm;
	}
	
	public BigDecimal getExpectMoney() {
		return expectMoney;
	}

	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}
	
	public String getProductProportion() {
		return productProportion;
	}

	public void setProductProportion(String productProportion) {
		this.productProportion = productProportion;
	}

	public BigDecimal getServiceProportion() {
		return serviceProportion;
	}

	public void setServiceProportion(BigDecimal serviceProportion) {
		this.serviceProportion = serviceProportion;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	public String getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(String recordNum) {
		this.recordNum = recordNum;
	}
	
	public BigDecimal getMinPorductProportion() {
		return minPorductProportion;
	}

	public void setMinPorductProportion(BigDecimal minPorductProportion) {
		this.minPorductProportion = minPorductProportion;
	}

	public BigDecimal getMaxProductProportion() {
		return maxProductProportion;
	}

	public void setMaxProductProportion(BigDecimal maxProductProportion) {
		this.maxProductProportion = maxProductProportion;
	}

	public String getOrgPhone() {
		return orgPhone;
	}

	public void setOrgPhone(String orgPhone) {
		this.orgPhone = orgPhone;
	}

	public Long getIsShow() {
		return isShow;
	}

	public void setIsShow(Long isShow) {
		this.isShow = isShow;
	}

	@Override
    public String toString() {
        return "ApplyRecordVO{" +
                "mainId=" + mainId +
                ", applyId=" + applyId +
                ", clientId=" + clientId +
                ", productName='" + productName + '\'' +
                ", remark='" + remark + '\'' +
                ", applyTime='" + applyTime + '\'' +
                ", state='" + state + '\'' +
                ", buttonName='" + buttonName + '\'' +
                ", isButton='" + isButton + '\'' +
                ", buttonType='" + buttonType + '\'' +
                ", contractAbolition='" + contractAbolition + '\'' +
                ", loanChannel=" + loanChannel +
                ", stateCode=" + stateCode +
                ", signDate='" + signDate + '\'' +
                ", orgName='" + orgName + '\'' +
                ", orgAddr='" + orgAddr + '\'' +
                ", recordNum='" + recordNum + '\'' +
                ", minPorductProportion='" + minPorductProportion + '\'' +
                ", maxProductProportion='" + maxProductProportion + '\'' +
                ", orgPhone='" + orgPhone + '\'' +
                ", isShow='" + isShow + '\'' +
                '}';
    }
}
