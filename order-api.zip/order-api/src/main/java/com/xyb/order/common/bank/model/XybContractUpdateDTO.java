package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    变更合同表传入参数
 * @author:         xieqingyang
 * @createDate:     2018/7/23 上午11:44
*/
public class XybContractUpdateDTO implements IBaseModel {

    private static final long serialVersionUID = 2312088569408535320L;
    /**客户信息表ID*/
    private Long clientId;
    /**银行类型*/
    private Integer bankType;
    /**账户名称*/
    private String bankAccount;
    /**开户行*/
    private String bankAccountOpen;
    /**银行卡号*/
    private String refundCardNum;
    /**手机号*/
    private String mp;
    /**用户姓名*/
    private String custName;

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getBankAccountOpen() {
        return bankAccountOpen;
    }

    public void setBankAccountOpen(String bankAccountOpen) {
        this.bankAccountOpen = bankAccountOpen;
    }

    public String getRefundCardNum() {
        return refundCardNum;
    }

    public void setRefundCardNum(String refundCardNum) {
        this.refundCardNum = refundCardNum;
    }

    public String getMp() {
        return mp;
    }

    public void setMp(String mp) {
        this.mp = mp;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    @Override
    public String toString() {
        return "XybContractUpdateDTO{" +
                "clientId=" + clientId +
                ", bankType=" + bankType +
                ", bankAccount='" + bankAccount + '\'' +
                ", bankAccountOpen='" + bankAccountOpen + '\'' +
                ", refundCardNum='" + refundCardNum + '\'' +
                ", mp='" + mp + '\'' +
                ", custName='" + custName + '\'' +
                '}';
    }
}
