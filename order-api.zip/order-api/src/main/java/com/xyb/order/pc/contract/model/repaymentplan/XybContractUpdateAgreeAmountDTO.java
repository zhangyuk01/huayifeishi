package com.xyb.order.pc.contract.model.repaymentplan;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同录入修改二级授信金额DTO
 * @createDate : 2018/05/29 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractUpdateAgreeAmountDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7027220508787268547L;
	/**申请id*/
	@NotNull(message = "applyId不能为空")
	private Long applyId;
	/**二级授信金额*/
	@NotNull(message = "newAgreeAmount不能为空")
	private BigDecimal newAgreeAmount;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public BigDecimal getNewAgreeAmount() {
		return newAgreeAmount;
	}
	public void setNewAgreeAmount(BigDecimal newAgreeAmount) {
		this.newAgreeAmount = newAgreeAmount;
	}
	@Override
	public String toString() {
		return "XybContractUpdateAgreeAmountDTO [applyId=" + applyId + ", newAgreeAmount=" + newAgreeAmount + "]";
	}
	
}
