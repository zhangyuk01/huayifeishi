package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by xieqingyang on 2018/4/16.
 * 短信验证码实体类 验证类
 */
public class SendMessageVerificationDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;
    @NotNull(message = "短信类型不能为空")
    private Integer messageTypeId;// -- 短信类型 101：短信通用验证类 102：短信验证次数限制类 103:掌友宝短信验证码 104:新增销售人员短信验证码 105：销售人员修改发送短信验证码
    @NotEmpty(message = "手机号不能为空")
    @Size(min = 11,max = 11,message = "请传入正确的手机号")
    private String phone;// -- 发送短信验证的手机号
    private Integer effectiveNum;// -- 同短信类型有效次数 可传null 如果短信类型为102  默认为5

    public Integer getMessageTypeId() {
        return messageTypeId;
    }

    public void setMessageTypeId(Integer messageTypeId) {
        this.messageTypeId = messageTypeId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getEffectiveNum() {
        return effectiveNum;
    }

    public void setEffectiveNum(Integer effectiveNum) {
        this.effectiveNum = effectiveNum;
    }
}
