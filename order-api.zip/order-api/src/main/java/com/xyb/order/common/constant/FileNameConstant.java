package com.xyb.order.common.constant;

import java.util.Arrays;
import java.util.List;

import com.fr.third.v2.org.apache.poi.ss.formula.functions.Finance;

/**
 * @description:    图片类型常量类
 * @author:         xieqingyang
 * @createDate:     2018/5/30 上午10:32
*/
public class FileNameConstant {

    /**身份证明*/
    public static final String A0= "A0";
    /**工作证明*/
    public static final String B0= "B0";
    /**个人收入证明*/
    public static final String C0= "C0";
    /**经营证明*/
    public static final String D0= "D0";
    /**企业收入证明*/
    public static final String E0= "E0";
    /**核验*/
    public static final String HYA1= "HYA1";
    /**房产证明*/
    public static final String G0= "G0";
    /**通话详单*/
    public static final String H0= "H0";
    /**征信逾期结清证明*/
    public static final String I0= "I0";
    /**工商网和人法网截图*/
    public static final String J0= "J0";
    /**保单证明*/
    public static final String F0= "F0";
    /**退休证明*/
    public static final String L0= "L0";
    /**其他材料*/
    public static final String K0= "K0";
    /**地址*/
    public static final String WA1= "WA1";
    /**合影*/
    public static final String WA2= "WA2";
    /**门厅*/
    public static final String WA3= "WA3";
    /**卧室*/
    public static final String WA4= "WA4";
    /**厨房*/
    public static final String WA5= "WA5";
    /**卫生间*/
    public static final String WA6= "WA6";
    /**客户手持身份证照片*/
    public static final String HTA1= "HTA1";
    /**身份证验证截图*/
    public static final String HTA2= "HTA2";
    /**签署服务记录表照片*/
    public static final String HTB1= "HTB1";
    /**服务表*/
    public static final String HTB2= "HTB2";
    /**联系人手抄或电子版*/
    public static final String HTB3= "HTB3";
    /**签约资料*/
    public static final String HTC1= "HTC1";
    /**其他资料*/
    public static final String HTC2= "HTC2";
    /**地址*/
    public static final String WB1= "WB1";
    /**单位门口*/
    public static final String WB2= "WB2";
    /**合影*/
    public static final String WB3= "WB3";
    /**办公场所*/
    public static final String WB4= "WB4";
    /**在职证明*/
    public static final String WB5= "WB5";
    /**地址*/
    public static final String WC1= "WC1";
    /**单位门口*/
    public static final String WC2= "WC2";
    /**合影*/
    public static final String WC3= "WC3";
    /**经营场所*/
    public static final String WC4= "WC4";
    /**经营单据*/
    public static final String WC5= "WC5";
    /**合影*/
    public static final String WD1= "WD1";
    /**产调单*/
    public static final String WD2= "WD2";
    /**复议*/
    public static final String FYA1= "FYA1";
    /**工位*/
    public static final String WB6="WB6";
    /**合同披露影像*/
    public static final String PLYX2="PLYX2";
    /**自我推荐图片*/
    public static final String M0="M0";
    /**签约前核验图片类型*/
    public static final List<String> SIGNCHECK_IMAGES_TYPE = Arrays.asList(HYA1);
    /**外访图片类型*/
    public static final List<String> OUTBOUND_IMAGES_TYPE = Arrays.asList(WA1,WA2,WA3,WA4,WA5,WA6,WB1,WB2,WB3,WB4,WB5,WC1,WC2,WC3,WC4,WC5,WD1,WD2,WB6);
    /**合同图片类型*/
    public static final List<String> CONTRACT_IMAGES_TYPE = Arrays.asList(HTA1,HTA2,HTB1,HTB2,HTB3,HTC1,HTC2);

}
