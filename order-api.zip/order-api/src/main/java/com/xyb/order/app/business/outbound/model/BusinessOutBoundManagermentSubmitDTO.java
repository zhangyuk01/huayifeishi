package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.model
 * @description :
 * @createDate : 2018/8/6 9:37
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundManagermentSubmitDTO implements IBaseModel{

    private static final long serialVersionUID = 8215670476744168689L;

    /**实地时间*/
    @NotNull(message = "visitDate不能为空")
    private String visitDate;

    /**客户综合描述*/
    @NotNull(message = "customerIntegratedDescription不能为空")
    private String customerIntegratedDescription;

    @NotNull(message = "applyId不能为空")
    private Long applyId;

    @NotNull(message = "visitMainId不能为空")
    private Long visitMainId;

    @NotNull(message = "flag不能为空")
    private String flag;

    public String getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(String visitDate) {
        this.visitDate = visitDate;
    }

    public String getCustomerIntegratedDescription() {
        return customerIntegratedDescription;
    }

    public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
        this.customerIntegratedDescription = customerIntegratedDescription;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getVisitMainId() {
        return visitMainId;
    }

    public void setVisitMainId(Long visitMainId) {
        this.visitMainId = visitMainId;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "BusinessOutBoundManagermentSubmitDTO{" +
                "visitDate='" + visitDate + '\'' +
                ", customerIntegratedDescription='" + customerIntegratedDescription + '\'' +
                ", applyId=" + applyId +
                ", visitMainId=" + visitMainId +
                ", flag='" + flag + '\'' +
                '}';
    }
}
