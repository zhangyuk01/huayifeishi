package com.xyb.order.app.client.personinfo.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonFormat;

public class JobInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long applyId;
	private Long id;//主键ID
	private String compName;//单位名称
	private Long compType;//单位性质
	private String compTypeLabel;//单位性质描述
	private Long industryCode;//行业代码
	private String industryCodeLabel;//行业代码描述
	private Long staffAmount;//企业规模
	private String staffAmountLabel;//企业规模描述
	private String compTellArea;//单位电话区号
	private String compTell;//单位电话
	private String compAllTell;//单位区号+电话
	private Long compAddresProvince;//单位地址省 
	private String compAddresProvinceLabel;//单位地址省描述
	private Long compAddresCity;//单位地址市
	private String compAddresCityLabel;//单位地址市描述
	private Long compAddresArea;//单位地址区
	private String compAddresAreaLabel;//单位地址区描述
	private String compAddres;//单位地址
	private String compAlladdress;//单位全地址
	private String compDept;//部门
	private Long compDuty;//职位
	private String compDutyStr;//职位label
	@JsonFormat(pattern="yyyy-MM-dd",timezone = "GMT+8")
	private Date compJoinDate;//入职日期
	private BigDecimal salary;//薪资收入
	private BigDecimal otherIncome;//其他收入
	/**薪资发放日*/
	private String salaryDelivery;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public Long getCompType() {
		return compType;
	}
	public void setCompType(Long compType) {
		this.compType = compType;
	}
	public String getCompTypeLabel() {
		return compTypeLabel;
	}
	public void setCompTypeLabel(String compTypeLabel) {
		this.compTypeLabel = compTypeLabel;
	}
	public Long getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(Long industryCode) {
		this.industryCode = industryCode;
	}
	public String getIndustryCodeLabel() {
		return industryCodeLabel;
	}
	public void setIndustryCodeLabel(String industryCodeLabel) {
		this.industryCodeLabel = industryCodeLabel;
	}
	public Long getStaffAmount() {
		return staffAmount;
	}
	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}
	public String getStaffAmountLabel() {
		return staffAmountLabel;
	}
	public void setStaffAmountLabel(String staffAmountLabel) {
		this.staffAmountLabel = staffAmountLabel;
	}
	public String getCompTellArea() {
		return compTellArea;
	}
	public void setCompTellArea(String compTellArea) {
		this.compTellArea = compTellArea;
	}
	public String getCompTell() {
		return compTell;
	}
	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}
	public String getCompAllTell() {
		return compAllTell;
	}
	public void setCompAllTell(String compAllTell) {
		this.compAllTell = compAllTell;
	}
	public Long getCompAddresProvince() {
		return compAddresProvince;
	}
	public void setCompAddresProvince(Long compAddresProvince) {
		this.compAddresProvince = compAddresProvince;
	}
	public String getCompAddresProvinceLabel() {
		return compAddresProvinceLabel;
	}
	public void setCompAddresProvinceLabel(String compAddresProvinceLabel) {
		this.compAddresProvinceLabel = compAddresProvinceLabel;
	}
	public Long getCompAddresCity() {
		return compAddresCity;
	}
	public void setCompAddresCity(Long compAddresCity) {
		this.compAddresCity = compAddresCity;
	}
	public String getCompAddresCityLabel() {
		return compAddresCityLabel;
	}
	public void setCompAddresCityLabel(String compAddresCityLabel) {
		this.compAddresCityLabel = compAddresCityLabel;
	}
	public Long getCompAddresArea() {
		return compAddresArea;
	}
	public void setCompAddresArea(Long compAddresArea) {
		this.compAddresArea = compAddresArea;
	}
	public String getCompAddresAreaLabel() {
		return compAddresAreaLabel;
	}
	public void setCompAddresAreaLabel(String compAddresAreaLabel) {
		this.compAddresAreaLabel = compAddresAreaLabel;
	}
	public String getCompAddres() {
		return compAddres;
	}
	public void setCompAddres(String compAddres) {
		this.compAddres = compAddres;
	}
	public String getCompAlladdress() {
		return compAlladdress;
	}
	public void setCompAlladdress(String compAlladdress) {
		this.compAlladdress = compAlladdress;
	}
	public String getCompDept() {
		return compDept;
	}
	public void setCompDept(String compDept) {
		this.compDept = compDept;
	}
	public Long getCompDuty() {
		return compDuty;
	}
	public void setCompDuty(Long compDuty) {
		this.compDuty = compDuty;
	}
	public String getCompDutyStr() {
		return compDutyStr;
	}
	public void setCompDutyStr(String compDutyStr) {
		this.compDutyStr = compDutyStr;
	}
	public Date getCompJoinDate() {
		return compJoinDate;
	}
	public void setCompJoinDate(Date compJoinDate) {
		this.compJoinDate = compJoinDate;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	public BigDecimal getOtherIncome() {
		return otherIncome;
	}
	public void setOtherIncome(BigDecimal otherIncome) {
		this.otherIncome = otherIncome;
	}
	public String getSalaryDelivery() {
		return salaryDelivery;
	}
	public void setSalaryDelivery(String salaryDelivery) {
		this.salaryDelivery = salaryDelivery;
	}
	@Override
	public String toString() {
		return "JobInfoDO [applyId=" + applyId + ", id=" + id + ", compName=" + compName + ", compType=" + compType
				+ ", compTypeLabel=" + compTypeLabel + ", industryCode=" + industryCode + ", industryCodeLabel="
				+ industryCodeLabel + ", staffAmount=" + staffAmount + ", staffAmountLabel=" + staffAmountLabel
				+ ", compTellArea=" + compTellArea + ", compTell=" + compTell + ", compAllTell=" + compAllTell
				+ ", compAddresProvince=" + compAddresProvince + ", compAddresProvinceLabel=" + compAddresProvinceLabel
				+ ", compAddresCity=" + compAddresCity + ", compAddresCityLabel=" + compAddresCityLabel
				+ ", compAddresArea=" + compAddresArea + ", compAddresAreaLabel=" + compAddresAreaLabel
				+ ", compAddres=" + compAddres + ", compAlladdress=" + compAlladdress + ", compDept=" + compDept
				+ ", compDuty=" + compDuty + ", compDutyStr=" + compDutyStr + ", compJoinDate=" + compJoinDate
				+ ", salary=" + salary + ", otherIncome=" + otherIncome + ", salaryDelivery=" + salaryDelivery + "]";
	}


}
