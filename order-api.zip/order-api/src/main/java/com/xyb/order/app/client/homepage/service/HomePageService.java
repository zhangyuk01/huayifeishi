package com.xyb.order.app.client.homepage.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.cuser.model.ApplyLoanDTO;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;

import java.util.List;

/**
* @Description:    C端首页方法
* @Author:         xieqingyang
* @CreateDate:     2018/5/8 下午4:38
*/
public interface HomePageService {

    /**
     * 获取banner图
     *
     * @return
     * @throws
     * @author xieqingyang
     * @date 2018/5/8 下午4:39
     */
    RestResponse queryValidBanners() throws Exception;

    /**
     * 获取产品展示列表
     *
     * @return
     * @throws
     * @author xieqingyang
     * @date 2018/5/12 下午3:39
     */
    RestResponse queryProductList() throws Exception;

    /**
    * 申请借款
    * @author      xieqingyang
    * @param applyLoanDTO
    * @return
    * @exception
    * @date        2018/5/15 下午8:31
    */
    RestResponse applyLoan(ApplyLoanDTO applyLoanDTO)throws Exception;


    /**
     * @param productId 产品ID 选传  可传null
     * @return 产品展示信息
     * @throws Exception 所有异常
     * @description 查询产品展示信息
     * @author xieqingyang
     * @CreatedDate 2018/7/10 上午11:27
     * @Version 1.0
     */
    List<ProductExhibitionDO> queryProductExhibition(Long productId) throws Exception;

    /**
     * 获取填写资料列表
     * @param productId
     * @return
     * @throws Exception
     */
    RestResponse fillList(Long productId) throws Exception;
}

