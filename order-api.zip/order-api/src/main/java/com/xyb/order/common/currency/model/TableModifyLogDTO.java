package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * Created by xieqingyang on 2018/4/2.
 * 保存表修改记录的model
 */
public class TableModifyLogDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private String tableName;// -- 表名称
    private Long tableKey;// -- 表主键
    /**
     * 修改字段 不用传入数据
     */
    private String tableField;
    private String modifyOldValue;// -- 修改前值json格式
    private String modifyNewValue;// -- 修改后值json格式
    private Long createUser;// -- 创建人
    private String[] noNeed;// -- 不需比对的字符串集

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Long getTableKey() {
        return tableKey;
    }

    public void setTableKey(Long tableKey) {
        this.tableKey = tableKey;
    }

    public String getTableField() {
        return tableField;
    }

    public void setTableField(String tableField) {
        this.tableField = tableField;
    }

    public String getModifyOldValue() {
        return modifyOldValue;
    }

    public void setModifyOldValue(String modifyOldValue) {
        this.modifyOldValue = modifyOldValue;
    }

    public String getModifyNewValue() {
        return modifyNewValue;
    }

    public void setModifyNewValue(String modifyNewValue) {
        this.modifyNewValue = modifyNewValue;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public String[] getNoNeed() {
        return noNeed;
    }

    public void setNoNeed(String[] noNeed) {
        this.noNeed = noNeed;
    }
}
