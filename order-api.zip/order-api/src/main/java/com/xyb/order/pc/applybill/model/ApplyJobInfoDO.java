package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 申请单工作信息
 * @author         zhangyu
 * @date           2018/10/17 11:18 AM
*/
public class ApplyJobInfoDO implements IBaseModel{
	
	private static final long serialVersionUID = 1L;

	/**主键id*/
	private Long id; 
	/**申请单ID*/
	private Long applyId;
	/**申请主表ID*/
	private Long mainId; 
	/**客户ID*/
	private Long cusId;
	/**单位名称*/
	private String compName;
	/**单位地址省市*/
	private Long compAddresProvince;
	/**单位地址省市*/
	private String compAddresProvinceStr;
	private Long compAddresCity;
	private String compAddresCityStr;
	private Long compAddresArea;
	private String compAddresAreaStr;
	/**单位地址*/
	private String compAdress; 
	/**单位全地*/
	private String compAllAddress;
	/**所在部门*/
	private String compDept; 
	/**职务*/
	private Long compDuty;
	/**职务中文描述*/
	private String compDutyStr;
	/**单位电话区号*/
	private String compTellArea;
	/**单位电话*/
	private String compTell;
	/**单位区号+固号*/
	private String compAllTell;
	/**入职日期年月日*/
	private Date compJoinDate;
	/**单位性质*/
	private Long compType;
	private String compTypeStr;
	/**企业规模*/
	private Long staffAmount;
	private String staffAmountStr;
	/**行业大类*/
	private Long industryType;
	/**行业代码*/
	private Long industryCode; 
	/**岗位代码*/
	private Long jobsCode; 
	/**雇佣类型*/
	private Long employeeType;
	/**单位编码*/
	private String commZip;
	/**职务*/
	private String post;  
	/**单位工商查询结果*/
	private Long icbcResult;
	/**办公场所*/
	private Long officeSpace;
	/**行业风险类别*/
	private Long riskCategory;
	/**工作性质*/
	private Long jobNature;
	/**股份*/
	private Long share;
	/**企业是否注册*/
	private Long isRegist;
	/**注册金额*/
	private Double registMoney;
	/**是否有社保*/
	private Long jinpo;
	/**社保记录状态*/
	private Long jinpoRecord; 
	/**公积金记录状态*/
	private Long cpfRecord;
	/**自雇人士身份*/
	private Long position; 
	/**薪资收入*/
	private Double salary;
	/**薪资发放日*/
	private String salaryDelivery;
	/**其他收入*/
	private Double otherIncome;
	/**注册时间*/
	private Date registDate;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCompAdress() {
		return compAdress;
	}
	public void setCompAdress(String compAdress) {
		this.compAdress = compAdress;
	}
	public Long getCompAddresProvince() {
		return compAddresProvince;
	}
	public void setCompAddresProvince(Long compAddresProvince) {
		this.compAddresProvince = compAddresProvince;
	}
	public String getCompAddresProvinceStr() {
		return compAddresProvinceStr;
	}
	public void setCompAddresProvinceStr(String compAddresProvinceStr) {
		this.compAddresProvinceStr = compAddresProvinceStr;
	}
	public Long getCompAddresCity() {
		return compAddresCity;
	}
	public void setCompAddresCity(Long compAddresCity) {
		this.compAddresCity = compAddresCity;
	}
	public String getCompAddresCityStr() {
		return compAddresCityStr;
	}
	public void setCompAddresCityStr(String compAddresCityStr) {
		this.compAddresCityStr = compAddresCityStr;
	}
	public Long getCompAddresArea() {
		return compAddresArea;
	}
	public void setCompAddresArea(Long compAddresArea) {
		this.compAddresArea = compAddresArea;
	}
	public String getCompAddresAreaStr() {
		return compAddresAreaStr;
	}
	public void setCompAddresAreaStr(String compAddresAreaStr) {
		this.compAddresAreaStr = compAddresAreaStr;
	}
	public String getCompAllAddress() {
		return compAllAddress;
	}
	public void setCompAllAddress(String compAllAddress) {
		this.compAllAddress = compAllAddress;
	}
	public String getCompDept() {
		return compDept;
	}
	public void setCompDept(String compDept) {
		this.compDept = compDept;
	}

	public Long getCompDuty() {
		return compDuty;
	}

	public void setCompDuty(Long compDuty) {
		this.compDuty = compDuty;
	}

	public String getCompTellArea() {
		return compTellArea;
	}
	public void setCompTellArea(String compTellArea) {
		this.compTellArea = compTellArea;
	}
	public String getCompTell() {
		return compTell;
	}
	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}
	public String getCompAllTell() {
		return compAllTell;
	}
	public void setCompAllTell(String compAllTell) {
		this.compAllTell = compAllTell;
	}
	public Date getCompJoinDate() {
		return compJoinDate;
	}
	public void setCompJoinDate(Date compJoinDate) {
		this.compJoinDate = compJoinDate;
	}
	public Long getCompType() {
		return compType;
	}
	public void setCompType(Long compType) {
		this.compType = compType;
	}
	public String getCompTypeStr() {
		return compTypeStr;
	}
	public void setCompTypeStr(String compTypeStr) {
		this.compTypeStr = compTypeStr;
	}
	public Long getStaffAmount() {
		return staffAmount;
	}
	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}
	public String getStaffAmountStr() {
		return staffAmountStr;
	}
	public void setStaffAmountStr(String staffAmountStr) {
		this.staffAmountStr = staffAmountStr;
	}
	public Long getIndustryType() {
		return industryType;
	}
	public void setIndustryType(Long industryType) {
		this.industryType = industryType;
	}
	public Long getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(Long industryCode) {
		this.industryCode = industryCode;
	}
	public Long getJobsCode() {
		return jobsCode;
	}
	public void setJobsCode(Long jobsCode) {
		this.jobsCode = jobsCode;
	}
	public Long getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(Long employeeType) {
		this.employeeType = employeeType;
	}
	public String getCommZip() {
		return commZip;
	}
	public void setCommZip(String commZip) {
		this.commZip = commZip;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public Long getIcbcResult() {
		return icbcResult;
	}
	public void setIcbcResult(Long icbcResult) {
		this.icbcResult = icbcResult;
	}
	public Long getOfficeSpace() {
		return officeSpace;
	}
	public void setOfficeSpace(Long officeSpace) {
		this.officeSpace = officeSpace;
	}
	public Long getRiskCategory() {
		return riskCategory;
	}
	public void setRiskCategory(Long riskCategory) {
		this.riskCategory = riskCategory;
	}
	public Long getJobNature() {
		return jobNature;
	}
	public void setJobNature(Long jobNature) {
		this.jobNature = jobNature;
	}
	public Long getShare() {
		return share;
	}
	public void setShare(Long share) {
		this.share = share;
	}
	public Long getIsRegist() {
		return isRegist;
	}
	public void setIsRegist(Long isRegist) {
		this.isRegist = isRegist;
	}
	public Double getRegistMoney() {
		return registMoney;
	}
	public void setRegistMoney(Double registMoney) {
		this.registMoney = registMoney;
	}
	public Long getJinpo() {
		return jinpo;
	}
	public void setJinpo(Long jinpo) {
		this.jinpo = jinpo;
	}
	public Long getJinpoRecord() {
		return jinpoRecord;
	}
	public void setJinpoRecord(Long jinpoRecord) {
		this.jinpoRecord = jinpoRecord;
	}
	public Long getCpfRecord() {
		return cpfRecord;
	}
	public void setCpfRecord(Long cpfRecord) {
		this.cpfRecord = cpfRecord;
	}
	public Long getPosition() {
		return position;
	}
	public void setPosition(Long position) {
		this.position = position;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Double getOtherIncome() {
		return otherIncome;
	}
	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}
	public Date getRegistDate() {
		return registDate;
	}
	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}
	public String getSalaryDelivery() {
		return salaryDelivery;
	}
	public void setSalaryDelivery(String salaryDelivery) {
		this.salaryDelivery = salaryDelivery;
	}

	public String getCompDutyStr() {
		return compDutyStr;
	}

	public void setCompDutyStr(String compDutyStr) {
		this.compDutyStr = compDutyStr;
	}

	@Override
	public String toString() {
		return "ApplyJobInfoDO{" +
				"id=" + id +
				", applyId=" + applyId +
				", mainId=" + mainId +
				", cusId=" + cusId +
				", compName='" + compName + '\'' +
				", compAddresProvince=" + compAddresProvince +
				", compAddresProvinceStr='" + compAddresProvinceStr + '\'' +
				", compAddresCity=" + compAddresCity +
				", compAddresCityStr='" + compAddresCityStr + '\'' +
				", compAddresArea=" + compAddresArea +
				", compAddresAreaStr='" + compAddresAreaStr + '\'' +
				", compAdress='" + compAdress + '\'' +
				", compAllAddress='" + compAllAddress + '\'' +
				", compDept='" + compDept + '\'' +
				", compDuty=" + compDuty +
				", compDutyStr='" + compDutyStr + '\'' +
				", compTellArea='" + compTellArea + '\'' +
				", compTell='" + compTell + '\'' +
				", compAllTell='" + compAllTell + '\'' +
				", compJoinDate=" + compJoinDate +
				", compType=" + compType +
				", compTypeStr='" + compTypeStr + '\'' +
				", staffAmount=" + staffAmount +
				", staffAmountStr='" + staffAmountStr + '\'' +
				", industryType=" + industryType +
				", industryCode=" + industryCode +
				", jobsCode=" + jobsCode +
				", employeeType=" + employeeType +
				", commZip='" + commZip + '\'' +
				", post='" + post + '\'' +
				", icbcResult=" + icbcResult +
				", officeSpace=" + officeSpace +
				", riskCategory=" + riskCategory +
				", jobNature=" + jobNature +
				", share=" + share +
				", isRegist=" + isRegist +
				", registMoney=" + registMoney +
				", jinpo=" + jinpo +
				", jinpoRecord=" + jinpoRecord +
				", cpfRecord=" + cpfRecord +
				", position=" + position +
				", salary=" + salary +
				", salaryDelivery='" + salaryDelivery + '\'' +
				", otherIncome=" + otherIncome +
				", registDate=" + registDate +
				'}';
	}
}
