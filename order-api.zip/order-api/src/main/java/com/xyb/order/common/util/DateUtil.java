package com.xyb.order.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

/**
 * 时间工具类
 * @author         xieqingyang
 * @date           2018/8/31 上午10:27
*/
public class DateUtil {

    /**
     * 判断同一年两个日期是否同月
     * @author      xieqingyang
     * @date        2018/8/31 上午10:29
     * @version     1.0
     * @param date1 时间1
     * @param date2 时间2
     * @return 结果
     */
    public static Boolean isSameMonth(LocalDate date1, LocalDate date2) {
        Boolean mark;
        if ((date1.getYear() == date2.getYear()) && (date1.getMonthValue() ==date2.getMonthValue())) {
            mark = true;
        } else {
            mark = false;
        }
        return mark;
    }

    /**
     * 获取日
     * @author      xieqingyang
     * @date        2018/8/31 上午10:29
     * @version     1.0
     * @param date 时间
     * @return 日
     */
    public static int getDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * Date 转 LocalDate
     * @author      xieqingyang
     * @date        2018/8/31 上午10:29
     * @version     1.0
     * @param date 时间
     * @return LocalDate
     */
    public static LocalDate getLocalDate(Date date) {
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDate localDate = instant.atZone(zoneId).toLocalDate();
        return localDate;
    }

    /**
     * 获取当前时间
     * @author      xieqingyang
     * @date        2018/8/31 上午10:30
     * @version     1.0
     * @param localDate localDate
     * @return Date
     */
    public static Date getDate(LocalDate localDate){
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zdt = localDate.atStartOfDay(zoneId);
        Date date = Date.from(zdt.toInstant());
        return date;
    }

    /**
     * 时间戳转Date
     * @author      xieqingyang
     * @date        2018/8/31 上午10:31
     * @version     1.0
     * @param time 时间戳
     * @return Date
     * @throws ParseException 异常信息
     */
    public static Date getDate(long time) throws ParseException {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str=sdf.format(time);
        Date date=sdf.parse(str);
        return date;
    }

    /**
     * @author luyang
     * @param startDate 开始时间
     * @param endDate 结束时间
     */
    public static Long getDays(Date startDate, Date endDate){
        long start = startDate.getTime();
        long end = endDate.getTime();
        long days = (start - end) / (1000 * 60 * 60 * 24);
        return days;
    }

    /**
     * @author luyang
     * @param startDate 开始时间
     * @param endDate 结束时间
     */
    public static Long getHours(Date startDate, Date endDate){
        long start = startDate.getTime();
        long end = endDate.getTime();
        long hours = ((start - end) / (1000 * 60 * 60 * 24))/(1000* 60 * 60);
        return hours;
    }

    /**
     *
     * method_name: getNextDate
     * param: @param startDate
     * param: @param day
     * param: @return
     * describe: 根据传入的天数获取这个天数之后的日期
     * creat_user: zhanghao
     * creat_date: 2018年5月21日下午4:26:57
     *
     */
    public static Date getNextDate(LocalDate startDate, Integer day){
        LocalDate nextDate = startDate.plus(day, ChronoUnit.DAYS);
        return getDate(nextDate);
    }

    /**
     * method_name: getBeforeDate
     * param: @param startDate
     * param: @param day
     * param: @return
     * describe: 根据传入的天数获取这个天数之前的日期
     * creat_user: zhanghao
     * creat_date: 2018年6月6日下午3:36:32
     *
     */
    public static Date getBeforeDate(LocalDate startDate, Integer day){
        LocalDate beforeDate = startDate.minus(day, ChronoUnit.DAYS);
        return getDate(beforeDate);
    }
}
