package com.xyb.order.common.constant;

/**
 * 存管需要的常量
 * @author         xieqingyang
 * @date           2018/11/23 1:59 PM
*/
public class DepositBankConstant {

    /**用户角色-出借角色*/
    public static final String ROLE_TYPE_1 = "1";
    /**用户角色-借款角色*/
    public static final String ROLE_TYPE_2 = "2";
    /**用户角色-代偿角色*/
    public static final String ROLE_TYPE_3 = "3";

    /**交易终端-手机APP*/
    public static final String CLIENT_000001 = "000001";
    /**交易终端-网页*/
    public static final String CLIENT_000002 = "000002";
    /**交易终端-微信*/
    public static final String CLIENT_000003 = "000003";
    /**交易终端-柜面*/
    public static final String CLIENT_000004 = "000004";

    /**绑定卡类型-主卡*/
    public static final String CARD_TYPE_0 = "0";
    /**绑定卡类型-副卡*/
    public static final String CARD_TYPE_1 = "1";
    /**绑定卡类型-已注销*/
    public static final String CARD_TYPE_2 = "2";

    /**账户类型-普通户*/
    public static final String ACCOUNT_TYPE_200201 = "200201";
    /**账户类型-企业户*/
    public static final String ACCOUNT_TYPE_200204 = "200204";

    /**证件号码类型-个人身份证*/
    public static final String IDCARD_TYPE_15 = "15";
    /**证件号码类型-企业证件*/
    public static final String IDCARD_TYPE_01 = "01";

    public static final String SIGN_FLAG_HAVING = "having";
}
