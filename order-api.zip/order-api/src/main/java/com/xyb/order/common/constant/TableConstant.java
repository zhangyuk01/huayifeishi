package com.xyb.order.common.constant;

/**
 * Created by xieqingyang on 2018/4/4.
 * 添加表修改日志所需要的常量类
 */
public class TableConstant {
    public static final String CREDIT_SCORE = "credit_score";
    public static final String T_APP_BANNER = "t_app_banner";
    public static final String T_APP_FEEDBACK = "t_app_feedback";
    public static final String T_APP_FEEDBACK_IMG = "t_app_feedback_img";
    public static final String T_APP_LOCATION = "t_app_location";
    public static final String T_APP_NOTICE_BATCH = "t_app_notice_batch";
    public static final String T_APP_NOTICE_BATCH_DETAILS = "t_app_notice_batch_details";
    public static final String T_APP_NOTICE_TEMPLATE = "t_app_notice_template";
    public static final String T_APP_VERSION = "t_app_version";
    public static final String T_APPLY_BILL_INFO = "t_apply_bill_info";
    public static final String T_APPLY_CLIENT_INFO = "t_apply_client_info";
    public static final String T_APPLY_CONSULT_INFO = "t_apply_consult_info";
    public static final String T_APPLY_FAMILYCHILDREN_INFO = "t_apply_familychildren_info";
    public static final String T_APPLY_HOUSE_INFO = "t_apply_house_info";
    public static final String T_APPLY_INSURANCE_INFO = "t_apply_insurance_info";
    public static final String T_APPLY_JOB_INFO = "t_apply_job_info";
    public static final String T_APPLY_LINKMAN_INFO = "t_apply_linkman_info";
    public static final String T_APPLY_MAIN_INFO = "t_apply_main_info";
    public static final String T_APPLY_PERSONAL_INFO = "t_apply_personal_info";
    public static final String T_APPLY_PRIVATE_INFO = "t_apply_private_info";
    public static final String T_APPLY_public_INFO = "t_apply_public_info";
    public static final String T_APPLY_RECHECK = "t_apply_recheck";
    public static final String T_APPLY_RECONSIDER = "t_apply_reconsider";
    public static final String T_APPLY_RISK_SUBMISSION = "t_apply_risk_submission";
    public static final String T_APPLY_VISIT_CREDIT_FAMILY_INFO = "t_apply_visit_credit_family_info";
    public static final String T_APPLY_VISIT_CREDIT_JOB_INFO = "t_apply_visit_credit_job_info";
    public static final String T_APPLY_VISIT_CREDIT_MANAGEMENT_INFO = "t_apply_visit_credit_management_info";
    public static final String T_APPLY_VISIT_MAIN_INFO = "t_apply_visit_main_info";
    public static final String T_APPLY_VISIT_PROPERTY_SURVEY = "t_apply_visit_property_survey";
    public static final String T_APPLY_PHONE_SPECIFICATIONS =" t_apply_phone_specifications";
    public static final String T_APPLY_SPECIFICATIONS_DETAIL = "t_apply_specifications_detail";
    public static final String T_APPLY_VERIFY = "t_apply_verify";
    public static final String T_APPROVAL_SCOPE_USER = "t_approval_scope_user";
    public static final String T_AUDIT_ADDRESS = "t_audit_address";
    public static final String T_AUDIT_CHECK_ITEM = "t_audit_check_item";
    public static final String T_AUDIT_CODE_INFO = "t_audit_code_info";
    public static final String T_AUDIT_CREDIT_CARD_INFO = "t_audit_credit_card_info";
    public static final String T_AUDIT_CREDIT_COMP_INFO = "t_audit_credit_comp_info";
    public static final String T_AUDIT_CREDIT_PERSONAL_INFO = "t_audit_credit_personal_info";
    public static final String T_AUDIT_CREDIT_REPORT = "t_audit_credit_report";
    public static final String T_AUDIT_END_INFO = "t_audit_end_info";
    public static final String T_AUDIT_ID_PROOF = "t_audit_id_proof";
    public static final String T_AUDIT_INFO = "t_audit_info";
    public static final String T_AUDIT_MATERIAL_DATA = "t_audit_material_data";
    public static final String T_AUDIT_MATERIAL_INFO = "t_audit_material_info";
    public static final String T_AUDIT_OTHER = "t_audit_other";
    public static final String T_AUDIT_OTHER_COURT = "t_audit_other_court";
    public static final String T_AUDIT_OTHER_HOUSE = "t_audit_other_house";
    public static final String T_AUDIT_PRIMARY_INFO = "t_audit_primary_info";
    public static final String T_AUDIT_RECONSIDER = "t_audit_reconsider";
    public static final String T_AUDIT_RULE_REFUSE = "t_audit_rule_refuse";
    public static final String T_AUDIT_SINGLE_RECORD = "t_audit_single_record";
    public static final String T_AUDIT_PERSONAL_INCOME = "t_audit_personal_income";
    public static final String T_AUDIT_COMP_INCOME = "t_audit_comp_income";
    public static final String T_BANK_CHANNEL = "t_bank_channel";
    public static final String T_BANK_TYPE = "t_bank_type";
    public static final String T_BANKCARD_CHANNEL = "t_bankcard_channel";
    public static final String T_BANKLIST = "t_banklist";
    public static final String T_BULLETIN = "t_bulletin";
    public static final String T_BULLETIN_RECEIVE = "t_bulletin_receive";
    public static final String T_CHANNEL_CHANGE_RANGE = "t_channel_change_range";
    public static final String T_COLLECTION_APPLICATION = "t_collection_application";
    public static final String T_COLLECTION_CONTRACT_BASE = "t_collection_contract_base";
    public static final String T_COLLECTION_CONTRACT_TRACE = "t_collection_contract_trace";
    public static final String T_CREDIT_BUSINESS_STATE = "t_credit_business_state";
    public static final String T_CREDIT_BUSINESS_STATE_LIST = "t_credit_business_state_list";
    public static final String T_CREDITTONE_OVERAMOUNT_DICT = "t_credittone_overamount_dict";
    public static final String T_DEPOT_INVALIDE_DATE = "t_depot_invalide_date";
    public static final String T_DEPOT_TIME = "t_depot_time";
    public static final String T_DEPOT_WEEK = "t_depot_week";
    public static final String T_FACTOR_INFO_RECORD = "t_factor_info_record";
    public static final String T_FILE_CLASSIFICATION = "t_file_classification";
    public static final String T_FILE_DATA_INFO = "t_file_data_info";
    public static final String T_FINANCE_BATCH = "t_finance_batch";
    public static final String T_FINANCE_BATCH_DETAILS = "t_finance_batch_details";
    public static final String T_FINANCE_PAYMENT = "t_finance_payment";
    public static final String T_INDUSTRY_DICT = "t_industry_dict";
    public static final String T_INSURANCE = "t_insurance";
    public static final String T_INTERFACE_SWITCH = "t_interface_switch";
    public static final String T_LATEREPAYMENT_APPLICATION = "t_laterepayment_application";
    public static final String T_LATEREPAYMENT_APPLICATION_DETAILS = "t_laterepayment_application_details";
    public static final String T_MENU = "t_menu";
    public static final String T_MESSAGE_CHANNEL = "t_message_channel";
    public static final String T_MESSAGE_CODE = "t_message_code";
    public static final String T_MESSAGE_TEMPLATE = "t_message_template";
    public static final String T_MESSAGE_TYPE = "t_message_type";
    public static final String T_ONETIME_PAYMENT_APPLICATION = "t_onetime_payment_application";
    public static final String T_ORG = "t_org";
    public static final String T_ORG_ADDR_DETAIL = "t_org_addr_detail";
    public static final String T_ORG_CONFIG = "t_org_config";
    public static final String T_ORG_LOANCHANNEL_REL = "t_org_loanchannel_rel";
    public static final String T_ORG_OLD = "t_org_old";
    public static final String T_ORG_PRODUCT = "t_org_product";
    public static final String T_PARAMETER_CONFIG = "t_parameter_config";
    public static final String T_POST = "t_post";
    public static final String T_POST_EXCLUSION = "t_post_exclusion";
    public static final String T_PROCESS_BUSINESS = "t_process_business";
    public static final String T_QUERY_DETAIL_INFO = "t_query_detail_info";
    public static final String T_RACE = "t_race";
    public static final String T_REPORT_OVERDUE_TODAY = "t_report_overdue_today";
    public static final String T_REPORT_REACH_RATE = "t_report_reach_rate";
    public static final String T_REPORT_REIMBURSEMENT_RATE = "t_report_reimbursement_rate";
    public static final String T_ROLE = "t_role";
    public static final String T_ROLE_MENU_REL = "t_role_menu_rel";
    public static final String T_RULE_INFO_RECORD = "t_rule_info_record";
    public static final String T_SCENE = "t_scene";
    public static final String T_SCENE_MENU = "t_scene_menu";
    public static final String T_SEND_PIECE_RANGE = "t_send_piece_range";
    public static final String T_SEND_PIECE_RULE = "t_send_piece_rule";
    public static final String T_SYS_DICT = "t_sys_dict";
    public static final String T_SYS_DICT_LIST = "t_sys_dict_list";
    public static final String T_SYS_DICT_OLD = "t_sys_dict_old";
    public static final String T_TEMP_ORG = "t_temp_org";
    public static final String T_USER = "t_user";
    public static final String T_USER_BUSINESS_QTY = "t_user_business_qty";
    public static final String T_USER_EXT = "t_user_ext";
    public static final String T_USER_POST = "t_user_post";
    public static final String T_USER_SEND_PIECE = "t_user_send_piece";
    public static final String T_USER_TOKEN = "t_user_token";
    public static final String T_XYB_AUDIT_RANGE = "t_xyb_audit_range";
    public static final String T_XYB_BANK_CODE = "t_xyb_bank_code";
    public static final String T_XYB_CHANNEL_BANK = "t_xyb_channel_bank";
    public static final String T_XYB_CHANNEL_CONFIG = "t_xyb_channel_config";
    public static final String T_XYB_CONTRACT = "t_xyb_contract";
    public static final String T_XYB_CONTRACT_AUDIT = "t_xyb_contract_audit";
    public static final String T_XYB_CONTRACT_AUDIT_RECORD = "t_xyb_contract_audit_record";
    public static final String T_XYB_CONTRACT_CHANGE = "t_xyb_contract_change";
    public static final String T_XYB_CONTRACT_CHANGE_EXT = "t_xyb_contract_change_ext";
    public static final String T_XYB_CONTRACT_CHANGE_REVIEW = "t_xyb_contract_change_review";
    public static final String T_XYB_CONTRACT_LENDER = "t_xyb_contract_lender";
    public static final String T_XYB_CONTRACT_LENDER_INFO = "t_xyb_contract_lender_info";
    public static final String T_XYB_CONTRACT_REPAYMENT_PLAN = "t_xyb_contract_repayment_plan";
    public static final String T_XYB_OVERDUE_DEPOT_DETAIL = "t_xyb_overdue_depot_detail";
    public static final String T_XYB_PRODUCT = "t_xyb_product";
    public static final String T_XYB_PRODUCT_EXT = "t_xyb_product_ext";
    public static final String T_XYB_PRODUCT_ORG = "t_xyb_product_org";
    public static final String T_SALE_USER="t_sale_user";
   
    /**通用表忽略字段**/
    public static final String T_FIELD_CREATE_TIME = "createTime";
    public static final String T_FIELD_CREATE_USER = "createUser";
    public static final String T_FIELD_MODIFY_TIME = "modifyTime";
    public static final String T_FIELD_MODIFY_USER = "modifyUser";
    /**申请表忽略字段**/
    public static final String T_FIELD_BORROWDESCCODESTR = "borrowDescCodeStr";
    public static final String T_FIELD_APPLYTIME = "applyTime";
    public static final String T_FIELD_RECOMMENDER = "recommender";

    /**工作信息表忽略字段**/
    public static final String T_FIELD_NATIONSTR = "nationStr";
    public static final String T_FIELD_GENDERSTR = "genderStr";
    /**个人信息忽略字段**/
    public static final String T_FIELD_EDUCATIONSTR = "educationStr";
    public static final String T_FIELD_MARRIAGESTR = "marriageStr";
    public static final String T_FIELD_CHILDRENNUMSTR= "childrenNumStr";
    public static final String T_FIELD_YEARINCOME = "year_income";
    
    /**工作信息忽略字段**/
    public static final String T_FIELD_COMPTYPESTR = "compTypeStr";
    public static final String T_FIELD_COMPDUTYSTR = "compDutyStr";
    /**私营信息忽略字段**/
    public static final String T_FIELD_PALACESTR= "palaceStr";

    /**个人收入和企业收入忽略字段 **/
    public static final String T_FIELD_IS_TEMP_SAVE = "isTempSave";
    public static final String T_FIELD_IS_DEL_STATE = "isDelState";
    /**房产证明忽略字段**/
    public static final String T_FIELD_MORTGAGEEXPLAINSTR = "mortgageexplainstr";
    public static final String T_FIELD_HOUSESHARESTR="houseShareStr";
    public static final String T_FIELD_HOUSEADDRESSPROVINCESTR="houseAddressProvinceStr";
    public static final String T_FIELD_HOUSEADDRESSCITYSTR ="houseAddressCityStr";
    public static final String T_FIELD_HOUSEADDRESSAREASTR = "houseAddressAreaStr";
    public static final String T_FIELD_PRODUCTID = "proudctId";
    /**企业信息忽略字段**/
    public static final String T_FIELD_ENTETYPESTR="enteTypeStr";
    public static final String T_FIELD_STAFFAMOUNTSTR="staffAmountStr";
    /**工作证明页签忽略字段**/
    public static final String T_FIELD_MONTHMONEY="monthMoney";
    public static final String T_FIELD_COMPNAME="compName";
    public static final String T_FIELD_COMPDEPT="compDept";
    public static final String T_FIELD_COMPDUTY="compDuty";
    public static final String T_FIELD_COMPJOINDATE="compJoinDate";
    /**保单证明页签**/
    public static final String T_FIELD_SYSTEMDATE = "systemDate";
    
    public static final String T_IMAGE_BATCH = "Y";
    public static final String T_IMAGE_SIZE = "大于5M，上传失败！";
    public static final String T_IMAGE_NAME_AGAIN = "已存在！";
    public static final String T_IMAGE_NAME_WRONG = "文件名称格式 错误！";
    public static final String T_IMAGE_SUCCESS = "上传成功";
    public static final String T_IMAGE_FAILED = "上传失败";
}
