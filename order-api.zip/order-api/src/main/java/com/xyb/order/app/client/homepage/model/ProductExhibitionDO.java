package com.xyb.order.app.client.homepage.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.math.BigDecimal;
import java.util.Date;

/**
* @description:    产品展示表
* @author:         xieqingyang
* @createDate:     2018/5/12 下午3:24
*/
public class ProductExhibitionDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private Long productId;// -- 产品ID
    private String productName;// -- 产品名称
    private BigDecimal minAmount;// -- 最低金额
    private BigDecimal maxAmount;// -- 最高金额
    private BigDecimal maxProportion;// -- 最高利率
    private BigDecimal minProportion;// -- 最低利率
    private Integer maxAge;// -- 最高年龄
    private Integer minAge;// -- 最低年龄
    private String productLimit;// -- 所有期数 以、分隔
    private String applyCondition;// -- 申请条件
    private String applyData;// -- 申请资料
    private Long isHot;// -- 是否火热 2486：是 2487：否

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(BigDecimal minAmount) {
        this.minAmount = minAmount;
    }

    public BigDecimal getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(BigDecimal maxAmount) {
        this.maxAmount = maxAmount;
    }

    public BigDecimal getMaxProportion() {
        return maxProportion;
    }

    public void setMaxProportion(BigDecimal maxProportion) {
        this.maxProportion = maxProportion;
    }

    public BigDecimal getMinProportion() {
        return minProportion;
    }

    public void setMinProportion(BigDecimal minProportion) {
        this.minProportion = minProportion;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public String getProductLimit() {
        return productLimit;
    }

    public void setProductLimit(String productLimit) {
        this.productLimit = productLimit;
    }

    public String getApplyCondition() {
        return applyCondition;
    }

    public void setApplyCondition(String applyCondition) {
        this.applyCondition = applyCondition;
    }

    public String getApplyData() {
        return applyData;
    }

    public void setApplyData(String applyData) {
        this.applyData = applyData;
    }

    public Long getIsHot() {
        return isHot;
    }

    public void setIsHot(Long isHot) {
        this.isHot = isHot;
    }

    @Override
    public String toString() {
        return "ProductExhibitionDO{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", minAmount=" + minAmount +
                ", maxAmount=" + maxAmount +
                ", maxProportion=" + maxProportion +
                ", minProportion=" + minProportion +
                ", maxAge=" + maxAge +
                ", minAge=" + minAge +
                ", productLimit='" + productLimit + '\'' +
                ", applyCondition='" + applyCondition + '\'' +
                ", applyData='" + applyData + '\'' +
                ", isHot=" + isHot +
                '}';
    }
}
