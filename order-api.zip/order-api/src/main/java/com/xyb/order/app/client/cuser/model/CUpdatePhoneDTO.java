package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @description: 用户修改手机号传入参数
 * @author: xieqingyang
 * @createDate: 2018/5/15 下午6:11
 */
public class CUpdatePhoneDTO implements IBaseModel {

	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "手机号不能为空")
	private String phone;
	@NotEmpty(message = "验证码不能为空")
	private String msgCode;
	@NotEmpty(message = "token不能为空")
	private String token;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		return "ClientUserUpdatePhoneDTO{" + "phone='" + phone + '\'' + ", msgCode='" + msgCode + '\'' + ", token='"
				+ token + '\'' + '}';
	}
}
