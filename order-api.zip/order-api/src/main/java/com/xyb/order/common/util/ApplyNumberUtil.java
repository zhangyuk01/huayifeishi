/*
 *  申请单编号生成规则
 *
 */
package com.xyb.order.common.util;


import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * 
 * @author ZhangYu 
 *
 */
public class ApplyNumberUtil {
	private static int APPLY_NUMBER = 0;
	//申请单编号
	public static synchronized String getsApplyNumber(){
		String applyNumber = "";
		APPLY_NUMBER += 1;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		applyNumber = sdf.format(new Date());
		for(int i=4-String.valueOf(APPLY_NUMBER).length();i>0;i--){
			applyNumber += "0";
		}
		return applyNumber+String.valueOf(APPLY_NUMBER);
	}
}
