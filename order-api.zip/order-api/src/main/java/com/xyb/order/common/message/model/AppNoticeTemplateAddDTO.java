package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * 新增消息model
 * @author         xieqingyang
 * @date           2018/9/4 下午4:04
*/
public class AppNoticeTemplateAddDTO implements IBaseModel {

    private static final long serialVersionUID = 3650459567996288620L;

    /**通知类型(大类2713)*/
    @NotNull(message = "通知类型不能为空")
    private Long type;
    /**标题*/
    @NotEmpty(message = "标题不能为空")
    private String title;
    /**内容*/
    private String content;
    /**访问连接*/
    private String url;
    /**app类型 (大类2714)*/
    @NotNull(message = "app类型不能为空")
    private Long appType;
    /**发布时间*/
    private Date releaseTime;
    /**是否定时发布*/
    @NotNull(message = "是否定时发布不能为空")
    private Long isTiming;
    /**上传附件路径*/
    private String messageFilePath;
    /**上传附件名称*/
    private String messageFileName;
    /**创建人*/
    private Long createUser;
    /**修改人*/
    private Long modifyUser;

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getAppType() {
        return appType;
    }

    public void setAppType(Long appType) {
        this.appType = appType;
    }

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public Long getIsTiming() {
        return isTiming;
    }

    public void setIsTiming(Long isTiming) {
        this.isTiming = isTiming;
    }

    public String getMessageFilePath() {
        return messageFilePath;
    }

    public void setMessageFilePath(String messageFilePath) {
        this.messageFilePath = messageFilePath;
    }

    public String getMessageFileName() {
        return messageFileName;
    }

    public void setMessageFileName(String messageFileName) {
        this.messageFileName = messageFileName;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "AppNoticeTemplateAddDTO{" +
                "type=" + type +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", url='" + url + '\'' +
                ", appType=" + appType +
                ", releaseTime=" + releaseTime +
                ", isTiming=" + isTiming +
                ", messageFilePath='" + messageFilePath + '\'' +
                ", messageFileName='" + messageFileName + '\'' +
                ", createUser=" + createUser +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
