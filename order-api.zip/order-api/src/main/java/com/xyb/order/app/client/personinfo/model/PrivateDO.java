package com.xyb.order.app.client.personinfo.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonFormat;

public class PrivateDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;//主键ID	
	private String enterpriseName;//公司名称
	private Long enteType;//公司类型
	private String enteTypeLabel;//公司类型描述
	@JsonFormat(pattern="yyyy-MM-dd",timezone = "GMT+8")
	private Date regDate;//注册时间
	private Long palace;//营业场所
	private String palaceLabel;//营业场所描述
	private BigDecimal stockRatio;//占股比例
	private Long staffAmount;//企业规模
	private String staffAmountLabel;//企业规模描述

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public Long getEnteType() {
		return enteType;
	}

	public void setEnteType(Long enteType) {
		this.enteType = enteType;
	}

	public String getEnteTypeLabel() {
		return enteTypeLabel;
	}

	public void setEnteTypeLabel(String enteTypeLabel) {
		this.enteTypeLabel = enteTypeLabel;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Long getPalace() {
		return palace;
	}

	public void setPalace(Long palace) {
		this.palace = palace;
	}

	public String getPalaceLabel() {
		return palaceLabel;
	}

	public void setPalaceLabel(String palaceLabel) {
		this.palaceLabel = palaceLabel;
	}

	public BigDecimal getStockRatio() {
		return stockRatio;
	}

	public void setStockRatio(BigDecimal stockRatio) {
		this.stockRatio = stockRatio;
	}

	public Long getStaffAmount() {
		return staffAmount;
	}

	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}

	public String getStaffAmountLabel() {
		return staffAmountLabel;
	}

	public void setStaffAmountLabel(String staffAmountLabel) {
		this.staffAmountLabel = staffAmountLabel;
	}
}
  