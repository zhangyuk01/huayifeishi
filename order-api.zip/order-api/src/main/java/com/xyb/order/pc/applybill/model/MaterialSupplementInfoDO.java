package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.List;

/**
 * @description:    材料补充详细资料
 * @author:         xieqingyang
 * @createDate:     2018/8/3 上午9:38
*/
public class MaterialSupplementInfoDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    /**需补充材料类型*/
    private List<String> materialType;
    /**需补充材料备注*/
    private String auditRemark;
    /**需补充材料提交时间*/
    private Date submitDate;
    /**历史备注*/
    private List<ApplyOtherDataRemarkDO> applyOtherDataRemarkDOs;

    @JsonIgnore
    private Long auditReportId;

    public List<String> getMaterialType() {
        return materialType;
    }

    public void setMaterialType(List<String> materialType) {
        this.materialType = materialType;
    }

    public String getAuditRemark() {
        return auditRemark;
    }

    public void setAuditRemark(String auditRemark) {
        this.auditRemark = auditRemark;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(Date submitDate) {
        this.submitDate = submitDate;
    }

    public List<ApplyOtherDataRemarkDO> getApplyOtherDataRemarkDOs() {
        return applyOtherDataRemarkDOs;
    }

    public void setApplyOtherDataRemarkDOs(List<ApplyOtherDataRemarkDO> applyOtherDataRemarkDOs) {
        this.applyOtherDataRemarkDOs = applyOtherDataRemarkDOs;
    }

    public Long getAuditReportId() {
        return auditReportId;
    }

    public void setAuditReportId(Long auditReportId) {
        this.auditReportId = auditReportId;
    }

    @Override
    public String toString() {
        return "MaterialSupplementInfoDO{" +
                "materialType=" + materialType +
                ", auditRemark='" + auditRemark + '\'' +
                ", submitDate=" + submitDate +
                ", applyOtherDataRemarkDOs=" + applyOtherDataRemarkDOs +
                ", auditReportId=" + auditReportId +
                '}';
    }
}
