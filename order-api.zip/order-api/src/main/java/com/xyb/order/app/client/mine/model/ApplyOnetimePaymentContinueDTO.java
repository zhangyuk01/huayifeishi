package com.xyb.order.app.client.mine.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyOnetimePaymentContinueDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	@NotNull(message="一次结清申请ID不能为空")
	private Long paymentApplicationId;// 一次结清申请Id

	
	public Long getPaymentApplicationId() {
		return paymentApplicationId;
	}
	public void setPaymentApplicationId(Long paymentApplicationId) {
		this.paymentApplicationId = paymentApplicationId;
	}

}
