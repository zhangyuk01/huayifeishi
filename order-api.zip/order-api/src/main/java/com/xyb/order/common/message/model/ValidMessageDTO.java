package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;


/**
 * Created by xieqingyang on 2018/4/16.
 * 验证短信验证码实体类
 */
public class ValidMessageDTO implements IBaseModel{

   private static final long serialVersionUID = 1L;

    @NotEmpty(message = "手机号码不能为空")
    private String phone;// -- 手机号码
    @NotEmpty(message = "短信验证码不能为空")
    private String vCode;// -- 短信验证码
    private Integer validTime;// -- 短信验证码有效时间   可传null
    private String state;// -- 是否当天有效  可传null Y:是  N：否

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getvCode() {
        return vCode;
    }

    public void setvCode(String vCode) {
        this.vCode = vCode;
    }

    public Integer getValidTime() {
        return validTime;
    }

    public void setValidTime(Integer validTime) {
        this.validTime = validTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
