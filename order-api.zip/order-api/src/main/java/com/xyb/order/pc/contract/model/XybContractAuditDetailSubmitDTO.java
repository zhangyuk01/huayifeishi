package com.xyb.order.pc.contract.model;

import javax.validation.Valid;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 进件合同审核详情提交DTO model层
 * @createDate : 2018/3/28 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditDetailSubmitDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -908858118904756826L;
	@Valid
	private XybContractAuditDTO xybContractAuditDTO;
	public XybContractAuditDTO getXybContractAuditDTO() {
		return xybContractAuditDTO;
	}
	public void setXybContractAuditDTO(XybContractAuditDTO xybContractAuditDTO) {
		this.xybContractAuditDTO = xybContractAuditDTO;
	}
	@Override
	public String toString() {
		return "XybContractAuditDetailSubmitDTO [xybContractAuditDTO=" + xybContractAuditDTO + "]";
	}

}
