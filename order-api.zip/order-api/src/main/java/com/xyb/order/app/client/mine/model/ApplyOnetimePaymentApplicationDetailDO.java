package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyOnetimePaymentApplicationDetailDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	/**
	 * 主键
	 */
	private Long id;
	/**
	 * 一次性结清申请ID
	 */
    private Long paymentApplicationId;
    /**
     * 还款计划ID
     */
    private Long repaymentPlanId;
    /**
     * 应还本金
     */
    private BigDecimal shouldPrincipal;
    /**
     * 应还利息
     */
    private BigDecimal shouldInterest;
    /**
     * 应还总额
     */
    private BigDecimal shouldTotal;
    /**
     * 实还本金
     */
    private BigDecimal actualPrincipal;
    /**
     * 实还利息
     */
    private BigDecimal actualInterest;
    /**
     * 实还总额
     */
    private BigDecimal actualTotal;
    /**
     * 减免金额
     */
    private BigDecimal reductionAmount;
    /**
     * 当前期数
     */
    private Integer currentPeriod;
    /**
     * 账户类型（2479）
     */
    private Long accountType;
    /**
     * 处理状态(2752)
     */
    private Long state;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 修改人
     */
    private Long modifyUser;
    /**
     * 修改时间
     */
    private Date modifyTime;
    
    /**
     * 期数 
     */
    private String periodStr;
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPaymentApplicationId() {
		return paymentApplicationId;
	}
	public void setPaymentApplicationId(Long paymentApplicationId) {
		this.paymentApplicationId = paymentApplicationId;
	}
	public Long getRepaymentPlanId() {
		return repaymentPlanId;
	}
	public void setRepaymentPlanId(Long repaymentPlanId) {
		this.repaymentPlanId = repaymentPlanId;
	}
	public BigDecimal getShouldPrincipal() {
		return shouldPrincipal;
	}
	public void setShouldPrincipal(BigDecimal shouldPrincipal) {
		this.shouldPrincipal = shouldPrincipal;
	}
	public BigDecimal getShouldInterest() {
		return shouldInterest;
	}
	public void setShouldInterest(BigDecimal shouldInterest) {
		this.shouldInterest = shouldInterest;
	}
	public BigDecimal getShouldTotal() {
		return shouldTotal;
	}
	public void setShouldTotal(BigDecimal shouldTotal) {
		this.shouldTotal = shouldTotal;
	}
	public BigDecimal getActualPrincipal() {
		return actualPrincipal;
	}
	public void setActualPrincipal(BigDecimal actualPrincipal) {
		this.actualPrincipal = actualPrincipal;
	}
	public BigDecimal getActualInterest() {
		return actualInterest;
	}
	public void setActualInterest(BigDecimal actualInterest) {
		this.actualInterest = actualInterest;
	}
	public BigDecimal getActualTotal() {
		return actualTotal;
	}
	public void setActualTotal(BigDecimal actualTotal) {
		this.actualTotal = actualTotal;
	}
	public BigDecimal getReductionAmount() {
		return reductionAmount;
	}
	public void setReductionAmount(BigDecimal reductionAmount) {
		this.reductionAmount = reductionAmount;
	}
	public Integer getCurrentPeriod() {
		return currentPeriod;
	}
	public void setCurrentPeriod(Integer currentPeriod) {
		this.currentPeriod = currentPeriod;
	}
	public Long getAccountType() {
		return accountType;
	}
	public void setAccountType(Long accountType) {
		this.accountType = accountType;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getPeriodStr() {
		return periodStr;
	}
	public void setPeriodStr(String periodStr) {
		this.periodStr = periodStr;
	}
}
