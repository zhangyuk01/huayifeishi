package com.xyb.order.app.client.authorization.service;

import com.beiming.kun.framework.msg.RestResponse;

/**
* @description:    机-融360认证相关
* @author:         xieqingyang
* @createDate:     2018/5/16 下午6:54
*/
public interface TianJiService {

    /**
    * 融360社保认证
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/16 下午7:04
    */
    RestResponse crawlerInsure()throws Exception;

    /**
     * 融360公积金认证
     * @author      xieqingyang
     * @return
     * @exception
     * @date        2018/5/16 下午7:04
     */
    RestResponse crawlerFund()throws Exception;

    /**
     * 融360征信认证
     * @author      xieqingyang
     * @return
     * @exception
     * @date        2018/5/16 下午7:04
     */
    RestResponse crawlerZX()throws Exception;
}
