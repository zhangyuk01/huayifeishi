package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.List;

/**
* @description:    申请借款后产品展示数据
* @author:         xieqingyang
* @createDate:     2018/5/15 下午8:39
*/
public class ProductExhibitionVO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**产品ID*/
    private Long productId;
    /**产品名称*/
    private String productName = "";
    /**产品费率*/
    private String productRate = "";
    /**产品期限*/
    private String productLimit = "";
    /**产品可借金额*/
    private String productAmount = "";
    /**产品年龄*/
    private String productCondition = "";
    /**申请条件*/
    private String applyCondition = "";
    /**申请资料*/
    private String applyData = "";
    /**服务网点list*/
    private List<ApplyLoanOrgDO> serviceList;
    /**最小金额*/
    private String mixAmount = "";
    /**最大金额*/
    private String maxAmout = "";
    /**是否需要跳转协议签约页面 Y：是 N：否*/
    private String agreementCompleted;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductRate() {
        return productRate;
    }

    public void setProductRate(String productRate) {
        this.productRate = productRate;
    }

    public String getProductLimit() {
        return productLimit;
    }

    public void setProductLimit(String productLimit) {
        this.productLimit = productLimit;
    }

    public String getProductAmount() {
        return productAmount;
    }

    public void setProductAmount(String productAmount) {
        this.productAmount = productAmount;
    }

    public String getProductCondition() {
        return productCondition;
    }

    public void setProductCondition(String productCondition) {
        this.productCondition = productCondition;
    }

    public String getApplyCondition() {
        return applyCondition;
    }

    public void setApplyCondition(String applyCondition) {
        this.applyCondition = applyCondition;
    }

    public String getApplyData() {
        return applyData;
    }

    public void setApplyData(String applyData) {
        this.applyData = applyData;
    }

    public List<ApplyLoanOrgDO> getServiceList() {
        return serviceList;
    }

    public void setServiceList(List<ApplyLoanOrgDO> serviceList) {
        this.serviceList = serviceList;
    }

    public String getMixAmount() {
        return mixAmount;
    }

    public void setMixAmount(String mixAmount) {
        this.mixAmount = mixAmount;
    }

    public String getMaxAmout() {
        return maxAmout;
    }

    public void setMaxAmout(String maxAmout) {
        this.maxAmout = maxAmout;
    }

    public String getAgreementCompleted() {
        return agreementCompleted;
    }

    public void setAgreementCompleted(String agreementCompleted) {
        this.agreementCompleted = agreementCompleted;
    }
}
