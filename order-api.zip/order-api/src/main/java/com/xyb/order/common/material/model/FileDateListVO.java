package com.xyb.order.common.material.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    返回给前段的展示
 * @author:         xieqingyang
 * @createDate:     2018/5/28 下午5:55
*/
public class FileDateListVO implements IBaseModel {

    private static final long serialVersionUID = -7802429858317688111L;
    private Long id;
    /**图片地址*/
    private String picPath;
    /**图片名称*/
    private String name;
    /**上传时间*/
    private Date uploadTime;
    /**是否能删除 true:可删除 false：不可删除*/
    private Boolean isDel;
    /**图片类型*/
    private String type;
    /**是否是文件*/
    private Boolean bfile = false;
    /**文件类型  x：表格 d：文档 p：pdf j:图片*/
    private String fileType = "j";

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPicPath() {
        return picPath;
    }

    public void setPicPath(String picPath) {
        this.picPath = picPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(Date uploadTime) {
        this.uploadTime = uploadTime;
    }

    public Boolean getDel() {
        return isDel;
    }

    public void setDel(Boolean del) {
        isDel = del;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getBfile() {
        return bfile;
    }

    public void setBfile(Boolean bfile) {
        this.bfile = bfile;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    @Override
    public String toString() {
        return "FileDateListVO{" +
                "id=" + id +
                ", picPath='" + picPath + '\'' +
                ", name='" + name + '\'' +
                ", uploadTime=" + uploadTime +
                ", isDel=" + isDel +
                ", type='" + type + '\'' +
                ", bfile=" + bfile +
                ", fileType='" + fileType + '\'' +
                '}';
    }
}
