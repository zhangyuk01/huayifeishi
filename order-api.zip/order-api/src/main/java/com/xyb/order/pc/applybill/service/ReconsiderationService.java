package com.xyb.order.pc.applybill.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.applybill.model.InsertReconsiderationDTO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDTO;

/**
 * 复议申请功能
 * @author         xieqingyang
 * @date           2018/10/16 3:01 PM
*/
public interface ReconsiderationService {

    /**
     * 查询复议申请列表数据
     * @author      xieqingyang
     * @date        2018/10/16 3:00 PM
     * @version     1.0
     * @param pageNumber 每页数量
     * @param pageSize 页码
     * @param reconsiderationListDTO 查询条件
     * @return 列表展示数据
     * @throws Exception 所有异常
     */
    RestResponse queryReconsiderationListPage(Integer pageNumber,Integer pageSize,ReconsiderationListDTO reconsiderationListDTO)throws Exception;

    /**
     * 查询复议详细数据
     * @author      xieqingyang
     * @date        2018/10/16 3:01 PM
     * @version     1.0
     * @param mainId 主表ID
     * @return 返回复议详情数据
     * @throws Exception 所有异常
     */
    RestResponse queryReconsiderationInfo(Long mainId)throws Exception;

    /**
     * 复议提交
     * @author      xieqingyang
     * @date        2018/10/16 3:02 PM
     * @version     1.0
     * @param insertReconsiderationDTO 复议提交数据
     * @return 返回执行结果
     * @throws Exception 所有异常
     */
    RestResponse insertReconsider(InsertReconsiderationDTO insertReconsiderationDTO)throws Exception;
}
