package com.xyb.order.app.client.personalcenter.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;

/**
 * 余额类型查询
 * 
 * @author qiaoJinLong
 * @date 2018年9月20日
 */
public class ClientProfitBalanceDetailDTO implements IBaseModel {

	private static final long serialVersionUID = -5921263118038445328L;

	private Page<ClientProfitBalanceDetailDO> page = new Page<ClientProfitBalanceDetailDO>();

	private Integer type;// 类型 0 /null全部 1 质保，2 推荐， 3 提现

	private Date startTime; // 开始日期

	private Date endTime;// 结束时间

	private String loginId;



	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Page<ClientProfitBalanceDetailDO> getPage() {
		return page;
	}


	@Override
	public String toString() {
		return "ClientProfitBalanceDetailDTO [page=" + page + ", type=" + type + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", loginId=" + loginId + "]";
	}

	public void setPage(Page<ClientProfitBalanceDetailDO> page) {
		this.page = page;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
}
