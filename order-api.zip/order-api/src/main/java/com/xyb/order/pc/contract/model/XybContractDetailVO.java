package com.xyb.order.pc.contract.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractDetailVO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 906198766339848481L;
	/**申请编号*/
	private String applyNum;
	/**借款用途*/
	private long borrowDesc;
	/**借款用途名称*/
	private String borrowDescName;
	/**一级授信金额*/
	private BigDecimal agreeAmount;
	/**二级授信金额*/
	private BigDecimal loanNoney;
	/**一级授信期数*/
	private int agreeTimeLimit;
	/**客户经理*/
	private String saleName;
	/**进件机构*/
	private long orgId;
	/**进件机构名称*/
	private String orgName;
	/**一级授信产品*/
	private long productId;
	/**一级授信产品名称*/
	private String productName;
	/**客服专员*/
	private String serviceName;
	/**客户姓名*/
	private String clientName;
	/**身份证号*/
	private String idCard;
	/**手机号*/
	private String phone;
	/**家庭地址省id*/
	private long proviceId;
	/**家庭地址省名称*/
	private String provinceName;
	/**家庭地址市id*/
	private long cityId;
	/**家庭地址市名称*/
	private String cityName;
	/**家庭地址区id*/
	private long areaId;
	/**家庭地址区名称*/
	private String areaName;
	/**家庭详细地址*/
	private String nowAddress;
	/**终极金额*/
	private BigDecimal contractAmount;
	/**服务费率*/
	private BigDecimal serviceRate;
	/**产品费率*/
	private BigDecimal productRate;
	/**服务费*/
	private BigDecimal serviceAmount;
	/**首期月还*/
	private BigDecimal monthReturnAmount;
	/**是否循环贷*/
	private String isLoopName;

	/**推荐人姓名*/
	private String recommender;
	/**确认金额*/
	private BigDecimal confirmAmout;
	/***服务费*/
	private BigDecimal backServiceCharge;
	
	private XybContractDO xybContractDO;
	
	List<Map<String, Object>> imageTypes;
	
	private XybContractAuditDO xybContractAuditDO;

	public String getApplyNum() {
		return applyNum;
	}

	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}

	public long getBorrowDesc() {
		return borrowDesc;
	}

	public void setBorrowDesc(long borrowDesc) {
		this.borrowDesc = borrowDesc;
	}

	public String getBorrowDescName() {
		return borrowDescName;
	}

	public void setBorrowDescName(String borrowDescName) {
		this.borrowDescName = borrowDescName;
	}

	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}

	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}

	public BigDecimal getLoanNoney() {
		return loanNoney;
	}

	public void setLoanNoney(BigDecimal loanNoney) {
		this.loanNoney = loanNoney;
	}

	public int getAgreeTimeLimit() {
		return agreeTimeLimit;
	}

	public void setAgreeTimeLimit(int agreeTimeLimit) {
		this.agreeTimeLimit = agreeTimeLimit;
	}

	public String getSaleName() {
		return saleName;
	}

	public void setSaleName(String saleName) {
		this.saleName = saleName;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public long getProviceId() {
		return proviceId;
	}

	public void setProviceId(long proviceId) {
		this.proviceId = proviceId;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public long getCityId() {
		return cityId;
	}

	public void setCityId(long cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public long getAreaId() {
		return areaId;
	}

	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getNowAddress() {
		return nowAddress;
	}

	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}

	public BigDecimal getContractAmount() {
		return contractAmount;
	}

	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}

	public BigDecimal getServiceRate() {
		return serviceRate;
	}

	public void setServiceRate(BigDecimal serviceRate) {
		this.serviceRate = serviceRate;
	}

	public BigDecimal getProductRate() {
		return productRate;
	}

	public void setProductRate(BigDecimal productRate) {
		this.productRate = productRate;
	}

	public BigDecimal getServiceAmount() {
		return serviceAmount;
	}

	public void setServiceAmount(BigDecimal serviceAmount) {
		this.serviceAmount = serviceAmount;
	}

	public BigDecimal getMonthReturnAmount() {
		return monthReturnAmount;
	}

	public void setMonthReturnAmount(BigDecimal monthReturnAmount) {
		this.monthReturnAmount = monthReturnAmount;
	}

	public String getIsLoopName() {
		return isLoopName;
	}

	public void setIsLoopName(String isLoopName) {
		this.isLoopName = isLoopName;
	}

	public XybContractDO getXybContractDO() {
		return xybContractDO;
	}

	public void setXybContractDO(XybContractDO xybContractDO) {
		this.xybContractDO = xybContractDO;
	}

	public List<Map<String, Object>> getImageTypes() {
		return imageTypes;
	}

	public void setImageTypes(List<Map<String, Object>> imageTypes) {
		this.imageTypes = imageTypes;
	}

	public XybContractAuditDO getXybContractAuditDO() {
		return xybContractAuditDO;
	}

	public void setXybContractAuditDO(XybContractAuditDO xybContractAuditDO) {
		this.xybContractAuditDO = xybContractAuditDO;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	public BigDecimal getBackServiceCharge() {
		return backServiceCharge;
	}

	public void setBackServiceCharge(BigDecimal backServiceCharge) {
		this.backServiceCharge = backServiceCharge;
	}

	@Override
	public String toString() {
		return "XybContractDetailVO{" +
				"applyNum='" + applyNum + '\'' +
				", borrowDesc=" + borrowDesc +
				", borrowDescName='" + borrowDescName + '\'' +
				", agreeAmount=" + agreeAmount +
				", loanNoney=" + loanNoney +
				", agreeTimeLimit=" + agreeTimeLimit +
				", saleName='" + saleName + '\'' +
				", orgId=" + orgId +
				", orgName='" + orgName + '\'' +
				", productId=" + productId +
				", productName='" + productName + '\'' +
				", serviceName='" + serviceName + '\'' +
				", clientName='" + clientName + '\'' +
				", idCard='" + idCard + '\'' +
				", phone='" + phone + '\'' +
				", proviceId=" + proviceId +
				", provinceName='" + provinceName + '\'' +
				", cityId=" + cityId +
				", cityName='" + cityName + '\'' +
				", areaId=" + areaId +
				", areaName='" + areaName + '\'' +
				", nowAddress='" + nowAddress + '\'' +
				", contractAmount=" + contractAmount +
				", serviceRate=" + serviceRate +
				", productRate=" + productRate +
				", serviceAmount=" + serviceAmount +
				", monthReturnAmount=" + monthReturnAmount +
				", isLoopName='" + isLoopName + '\'' +
				", recommender='" + recommender + '\'' +
				", confirmAmout=" + confirmAmout +
				", backServiceCharge=" + backServiceCharge +
				", xybContractDO=" + xybContractDO +
				", imageTypes=" + imageTypes +
				", xybContractAuditDO=" + xybContractAuditDO +
				'}';
	}
}
