package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访家庭信息 model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundFamilyInfoDO implements IBaseModel {

	private static final long serialVersionUID = -9028543175936740709L;

	private Long id;
	/**申请id*/
    private Long visitMainId;

    /**家庭地址是否一致(大类2692)*/
	@NotNull(message = "isFamilyAddressSame不能为空")
    private Long isFamilyAddressSame;

    /**外放后家庭地址*/
    private String familyAllAddr;

    /**家庭省*/
	@NotNull(message = "familyAddrProvince不能为空")
    private Long familyAddrProvince;

    /**家庭市*/
	@NotNull(message = "familyAddrCity不能为空")
    private Long familyAddrCity;

    /**家庭区*/
	@NotNull(message = "familyAddrArea不能为空")
    private Long familyAddrArea;

    /**家庭地址街道门牌详细信息*/
	@NotNull(message = "familyAddrDetail不能为空")
    private String familyAddrDetail;

    /**家庭电话是否一致(大类2692)*/
	@NotNull(message = "isFamilyTellSame不能为空")
    private Long isFamilyTellSame;

    /**是否有家庭固话（大类2692）*/
    private Long haveFamilyTell;

	/**外访后家庭固话区号*/
	@NotNull(message = "familyTellArea不能为空")
	private String familyTellArea;

    /**外访后家庭固话号码*/
	@NotNull(message = "familyTell不能为空")
    private String familyTell;

    /**房屋类型（大类2533）*/
	@NotNull(message = "houseType不能为空")
    private Long houseType;

    /**现住址居住时间（大类2646*/
    private Long houseTime;

    /**房屋权属（大类2636）*/
	@NotNull(message = "houseOwnershipType不能为空")
    private Long houseOwnershipType;

    /**房屋市值(大类2638)*/
    private Long houseMarketValue;

    /**房屋权属类型是其他时备注*/
    private String houseOwnershipTypeRemark;

    /**装修风格（大类2722）*/
	@NotNull(message = "houseRedecoratedStyle不能为空")
    private Long houseRedecoratedStyle;

    /**共同居住者，多选类型英文逗号隔开(大类2645)*/
	@NotNull(message = "coResident不能为空")
    private String coResident;

    /**共同居住情况备注*/
    private String coResidentRemark;

    /**居住痕迹(大类2805)*/
	@NotNull(message = "residentialTraces不能为空")
    private String residentialTraces;

    /**备注*/
    private String remark;

    /**是否有效（大类2692）*/
    private Integer isValid;

    /**用来相同模块排序（同时插入时间区分不了显示位置）*/
    private Integer sort;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public Long getIsFamilyAddressSame() {
		return isFamilyAddressSame;
	}

	public void setIsFamilyAddressSame(Long isFamilyAddressSame) {
		this.isFamilyAddressSame = isFamilyAddressSame;
	}

	public String getFamilyAllAddr() {
		return familyAllAddr;
	}

	public void setFamilyAllAddr(String familyAllAddr) {
		this.familyAllAddr = familyAllAddr;
	}

	public Long getFamilyAddrProvince() {
		return familyAddrProvince;
	}

	public void setFamilyAddrProvince(Long familyAddrProvince) {
		this.familyAddrProvince = familyAddrProvince;
	}

	public Long getFamilyAddrCity() {
		return familyAddrCity;
	}

	public void setFamilyAddrCity(Long familyAddrCity) {
		this.familyAddrCity = familyAddrCity;
	}

	public Long getFamilyAddrArea() {
		return familyAddrArea;
	}

	public void setFamilyAddrArea(Long familyAddrArea) {
		this.familyAddrArea = familyAddrArea;
	}

	public String getFamilyAddrDetail() {
		return familyAddrDetail;
	}

	public void setFamilyAddrDetail(String familyAddrDetail) {
		this.familyAddrDetail = familyAddrDetail;
	}

	public Long getIsFamilyTellSame() {
		return isFamilyTellSame;
	}

	public void setIsFamilyTellSame(Long isFamilyTellSame) {
		this.isFamilyTellSame = isFamilyTellSame;
	}

	public Long getHaveFamilyTell() {
		return haveFamilyTell;
	}

	public void setHaveFamilyTell(Long haveFamilyTell) {
		this.haveFamilyTell = haveFamilyTell;
	}

	public String getFamilyTell() {
		return familyTell;
	}

	public void setFamilyTell(String familyTell) {
		this.familyTell = familyTell;
	}

	public Long getHouseType() {
		return houseType;
	}

	public void setHouseType(Long houseType) {
		this.houseType = houseType;
	}

	public Long getHouseTime() {
		return houseTime;
	}

	public void setHouseTime(Long houseTime) {
		this.houseTime = houseTime;
	}

	public Long getHouseOwnershipType() {
		return houseOwnershipType;
	}

	public void setHouseOwnershipType(Long houseOwnershipType) {
		this.houseOwnershipType = houseOwnershipType;
	}

	public Long getHouseMarketValue() {
		return houseMarketValue;
	}

	public void setHouseMarketValue(Long houseMarketValue) {
		this.houseMarketValue = houseMarketValue;
	}

	public String getHouseOwnershipTypeRemark() {
		return houseOwnershipTypeRemark;
	}

	public void setHouseOwnershipTypeRemark(String houseOwnershipTypeRemark) {
		this.houseOwnershipTypeRemark = houseOwnershipTypeRemark;
	}

	public Long getHouseRedecoratedStyle() {
		return houseRedecoratedStyle;
	}

	public void setHouseRedecoratedStyle(Long houseRedecoratedStyle) {
		this.houseRedecoratedStyle = houseRedecoratedStyle;
	}

	public String getCoResident() {
		return coResident;
	}

	public void setCoResident(String coResident) {
		this.coResident = coResident;
	}

	public String getCoResidentRemark() {
		return coResidentRemark;
	}

	public void setCoResidentRemark(String coResidentRemark) {
		this.coResidentRemark = coResidentRemark;
	}

	public String getResidentialTraces() {
		return residentialTraces;
	}

	public void setResidentialTraces(String residentialTraces) {
		this.residentialTraces = residentialTraces;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getFamilyTellArea() {
		return familyTellArea;
	}

	public void setFamilyTellArea(String familyTellArea) {
		this.familyTellArea = familyTellArea;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundFamilyInfoDO{" +
				"id=" + id +
				", visitMainId=" + visitMainId +
				", isFamilyAddressSame=" + isFamilyAddressSame +
				", familyAllAddr='" + familyAllAddr + '\'' +
				", familyAddrProvince=" + familyAddrProvince +
				", familyAddrCity=" + familyAddrCity +
				", familyAddrArea=" + familyAddrArea +
				", familyAddrDetail='" + familyAddrDetail + '\'' +
				", isFamilyTellSame=" + isFamilyTellSame +
				", haveFamilyTell=" + haveFamilyTell +
				", familyTellArea='" + familyTellArea + '\'' +
				", familyTell='" + familyTell + '\'' +
				", houseType=" + houseType +
				", houseTime=" + houseTime +
				", houseOwnershipType=" + houseOwnershipType +
				", houseMarketValue=" + houseMarketValue +
				", houseOwnershipTypeRemark='" + houseOwnershipTypeRemark + '\'' +
				", houseRedecoratedStyle=" + houseRedecoratedStyle +
				", coResident='" + coResident + '\'' +
				", coResidentRemark='" + coResidentRemark + '\'' +
				", residentialTraces='" + residentialTraces + '\'' +
				", remark='" + remark + '\'' +
				", isValid=" + isValid +
				", sort=" + sort +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				'}';
	}
}
