package com.xyb.order.app.client.personalcenter.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 疑难解答
 * 
 * @author qiaoJinLong
 * @date 2018年9月18日
 */
public class CommonProblemDTO implements IBaseModel {
	private static final long serialVersionUID = -2143324085175743704L;

	private Long id;// id

	private String title;// 标题

	private String url;// 点击链接

	private String remark;// 备注

	private Integer clicks;

	private Long createUser;// 创建人

	private Date createTime;// 创建时间

	private Date modifyTime;// 修改时间

	private String modifyUser;// 修改时间

	@Override
	public String toString() {
		return "CommonProblemDTO [id=" + id + ", title=" + title + ", url=" + url + ", remark=" + remark + ", clicks="
				+ clicks + ", createUser=" + createUser + ", createTime=" + createTime + ", modifyTime=" + modifyTime
				+ ", modifyUser=" + modifyUser + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getClicks() {
		return clicks;
	}

	public void setClicks(Integer clicks) {
		this.clicks = clicks;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

}
