/*
 * 文 件 名:  ClientManager.java
 * 修 改 人:  chenchong@rong360.com
 * 修改时间:  2016年2月25日
 * 修改内容:  <修改内容>
 */
package com.xyb.order.common.util.tianji.client;


import com.xyb.order.common.util.tianji.client.impl.DefaultRongClient;

/**
 * 
 * @author  chenchong@rong360.com
 * @date  [2016年3月29日]
 */
public class ClientManager {
   
	private static String url = "";
	private static String format = "json";
	private static String charset = "utf-8";
	
    public static RongClient createClient(String appId, String privateKey, boolean isTestEnv) {
    	if (isTestEnv) {
    		url = "https://openapisandbox.rong360.com/gateway";
    	} else {
    		url = "https://openapi.rong360.com/gateway";
    	}
        return new DefaultRongClient(url, appId, privateKey, format, charset, isTestEnv);
    }
    
}
