package com.xyb.order.common.constant;

/**
 * 
* @className : LoanRejectionCodeConstant.java
* @package : com.xyb.order.common.constant
* @description : 自定义拒贷码
* @author : zhanghao
* @createDate : 2018年12月26日上午11:21:46
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
public class LoanRejectionCodeConstant {
	
	/**满额拒贷码*/
	public static final String FULL_REJECTION_CODE = "FULL001";
	/**满额拒贷原因*/
	public static final String FULL_REJECTION_MSG = "满额未通过";
	
}
