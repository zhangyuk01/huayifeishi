package com.xyb.order.pc.contract.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 进件合同审核model层
 * @createDate : 2018/3/28 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditDO implements IBaseModel {

	/**
	 * 
	 */
	private static final Long serialVersionUID = 8309988642003497906L;
	//属性部分
	private Long id; //id
	private Long contractId; //合同信息ID
	private Long applyId; //申请单ID
	private Long contractAuditResult; //审核结果
	private String contractAuditRemark; //审核备注
	private String refuseReason;//拒贷原因
	private Long createUser; //创建人
	private String createName; //创建人
	private Date createTime; //创建时间
	private Date modifyTime; //修改时间
	private Long modifyUser; //修改人
	private String modifyName; //修改人姓名
	private Long isLine; //是否线上（大类2692
	private Long isTempSave;//是暂存（大类2692）
	private String backReason;//退回原因
	private String backReasonName;//退回原因描述
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getContractAuditResult() {
		return contractAuditResult;
	}
	public void setContractAuditResult(Long contractAuditResult) {
		this.contractAuditResult = contractAuditResult;
	}
	public String getContractAuditRemark() {
		return contractAuditRemark;
	}
	public void setContractAuditRemark(String contractAuditRemark) {
		this.contractAuditRemark = contractAuditRemark;
	}
	public String getRefuseReason() {
		return refuseReason;
	}
	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public String getCreateName() {
		return createName;
	}
	public void setCreateName(String createName) {
		this.createName = createName;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getModifyName() {
		return modifyName;
	}
	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}
	public Long getIsLine() {
		return isLine;
	}
	public void setIsLine(Long isLine) {
		this.isLine = isLine;
	}
	public Long getIsTempSave() {
		return isTempSave;
	}
	public void setIsTempSave(Long isTempSave) {
		this.isTempSave = isTempSave;
	}
	public String getBackReason() {
		return backReason;
	}
	public void setBackReason(String backReason) {
		this.backReason = backReason;
	}
	public String getBackReasonName() {
		return backReasonName;
	}
	public void setBackReasonName(String backReasonName) {
		this.backReasonName = backReasonName;
	}
	@Override
	public String toString() {
		return "XybContractAuditDO [id=" + id + ", contractId=" + contractId + ", applyId=" + applyId
				+ ", contractAuditResult=" + contractAuditResult + ", contractAuditRemark=" + contractAuditRemark
				+ ", refuseReason=" + refuseReason + ", createUser=" + createUser + ", createName=" + createName
				+ ", createTime=" + createTime + ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser
				+ ", modifyName=" + modifyName + ", isLine=" + isLine + ", isTempSave=" + isTempSave + ", backReason="
				+ backReason + ", backReasonName=" + backReasonName + "]";
	}

}
