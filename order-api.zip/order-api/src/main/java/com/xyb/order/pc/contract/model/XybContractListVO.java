package com.xyb.order.pc.contract.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同list返回数据model
 * @createDate : 2018/03/29 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractListVO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7316909613826214949L;
	/**申请Id*/
	private Long applyId;
	/**主表id*/
	private Long mainId;
	/**申请编号*/
	private String applyNum;
	/**合同编号*/
	private String contractNum;
	/**进件机构*/
	private String orgName;
	/**客户姓名*/
	private String custName;
	/**身份证号码*/
	private String idCard;
	/**批准日期*/
	private Date updateDate;
	/**终极授信金额*/
	private BigDecimal contractAmount;
	/**一级授信金额*/
	private int agreeAmount;
	/**终极授信期限*/
	private int agreeProductLimit;
	/**一级授信产品*/
	private String agreeProductName;
	/**当前状态*/
	private long isTempSave;
	/**当前状态name*/
	private String isTempSaveName;
	/**合同审核结果*/
	private long contractAuditResult;
	/**合同审核结果*/
	private String contractAuditResultName;
	/**是否签约前核验*/
	private Long signCheck;
	/**是否签约前核验*/
	private String signCheckName;
	/**当前操作人*/
	private String processer;
	/**当前操作人uid*/
	private Long processerUid;
	/**当前登录人ID*/
	private Long loginId;
	/**分配结果  已分配/未分配*/
	private String isAllocation;
	/**确认金额*/
	private BigDecimal confirmAmout;
	/***服务费*/
	private BigDecimal backServiceCharge;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public int getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(int agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public int getAgreeProductLimit() {
		return agreeProductLimit;
	}
	public void setAgreeProductLimit(int agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}
	public String getAgreeProductName() {
		return agreeProductName;
	}
	public void setAgreeProductName(String agreeProductName) {
		this.agreeProductName = agreeProductName;
	}
	public long getIsTempSave() {
		return isTempSave;
	}
	public void setIsTempSave(long isTempSave) {
		this.isTempSave = isTempSave;
	}
	public String getIsTempSaveName() {
		return isTempSaveName;
	}
	public void setIsTempSaveName(String isTempSaveName) {
		this.isTempSaveName = isTempSaveName;
	}
	public long getContractAuditResult() {
		return contractAuditResult;
	}
	public void setContractAuditResult(long contractAuditResult) {
		this.contractAuditResult = contractAuditResult;
	}
	public String getContractAuditResultName() {
		return contractAuditResultName;
	}
	public void setContractAuditResultName(String contractAuditResultName) {
		this.contractAuditResultName = contractAuditResultName;
	}
	public Long getSignCheck() {
		return signCheck;
	}
	public void setSignCheck(Long signCheck) {
		this.signCheck = signCheck;
	}
	public String getSignCheckName() {
		return signCheckName;
	}
	public void setSignCheckName(String signCheckName) {
		this.signCheckName = signCheckName;
	}
	public String getProcesser() {
		return processer;
	}
	public void setProcesser(String processer) {
		this.processer = processer;
	}
	public Long getProcesserUid() {
		return processerUid;
	}
	public void setProcesserUid(Long processerUid) {
		this.processerUid = processerUid;
	}
	public Long getLoginId() {
		return loginId;
	}
	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}
	public String getIsAllocation() {
		return isAllocation;
	}
	public void setIsAllocation(String isAllocation) {
		this.isAllocation = isAllocation;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	public BigDecimal getBackServiceCharge() {
		return backServiceCharge;
	}

	public void setBackServiceCharge(BigDecimal backServiceCharge) {
		this.backServiceCharge = backServiceCharge;
	}

	@Override
	public String toString() {
		return "XybContractListVO{" +
				"applyId=" + applyId +
				", mainId=" + mainId +
				", applyNum='" + applyNum + '\'' +
				", contractNum='" + contractNum + '\'' +
				", orgName='" + orgName + '\'' +
				", custName='" + custName + '\'' +
				", idCard='" + idCard + '\'' +
				", updateDate=" + updateDate +
				", contractAmount=" + contractAmount +
				", agreeAmount=" + agreeAmount +
				", agreeProductLimit=" + agreeProductLimit +
				", agreeProductName='" + agreeProductName + '\'' +
				", isTempSave=" + isTempSave +
				", isTempSaveName='" + isTempSaveName + '\'' +
				", contractAuditResult=" + contractAuditResult +
				", contractAuditResultName='" + contractAuditResultName + '\'' +
				", signCheck=" + signCheck +
				", signCheckName='" + signCheckName + '\'' +
				", processer='" + processer + '\'' +
				", processerUid=" + processerUid +
				", loginId=" + loginId +
				", isAllocation='" + isAllocation + '\'' +
				", confirmAmout=" + confirmAmout +
				", backServiceCharge=" + backServiceCharge +
				'}';
	}
}
