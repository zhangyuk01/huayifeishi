package com.xyb.order.common.constant;

public class FeeRateConstants {

	/**等额本息还款法 (适用于英杰贷、经营贷、工薪贷、业主贷)*/
	public static final String FEE_RATE_CALCULATION_METHOD_1 = "1";
	/**算法一 (适用于旧的合同，具体需要合同部门提供名单)*/
	public static final String FEE_RATE_CALCULATION_METHOD_2 = "2";
	/**算法二 (适用于旧的合同，具体需要合同部门提供名单)*/
	public static final String FEE_RATE_CALCULATION_METHOD_3 = "3";
	/**算法三 (适用于商贷宝、公务贷)*/
	public static final String FEE_RATE_CALCULATION_METHOD_4 = "4";
	/**算法四 (适用于信房贷)*/
	public static final String FEE_RATE_CALCULATION_METHOD_5 = "5";
	/**算法五(适用于网商贷)*/
	public static final String FEE_RATE_CALCULATION_METHOD_6 = "6";
	
	/**先息后本(仓储贷)*/
	public static final String FEE_RATE_CALCULATION_METHOD_7 = "7";
}
