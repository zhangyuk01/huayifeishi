package com.xyb.order.common.fdd.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.fdd.model.FddReturnInFoDTO;

/**
 * 调用法大大接口
 * @author         xieqingyang
 * @date           2018/10/16 5:07 PM
*/
public interface FddService {

    /**
     * 个人ca证书注册
     * @author      xieqingyang
     * @date 2018/7/30 下午6:28
     * @version     1.0
     * @param clientId 用户信息表ID
     * @return 返回所有认证结果
     * @throws Exception 所有异常
     */
    RestResponse invokeSyncPersonAuto(Long clientId)throws Exception;

    /**
     * 法大大合同生成 没有可不传标识 为必传项
     * @author      xieqingyang
     * @date 2018/7/31 下午4:41
     * @version     1.0
     * @param templateId 模版编号
     * @param contractId 合同编号 只允许长度<=32 的英文或数字字符
     * @param docTitle 文档标题
     * @param fontSize 字体大小 可不传 不传则为默认值 9 参考 word 字体设置
     * @param fontType 字体类型 可不传 0-宋体;1-仿宋;2-黑体;3-楷体;4-微软 雅黑
     * @param parameterMap 填充内容 JsonObject 字符串 key 为文本域，value 为要填充的值，value 值传字符类型 示例: {"platformName":"The Earth","borrower":"Boss Horse"}
     * @param dynamicTables 动态表格 可不传
     * @param clientId 客户信息表ID
     * @param operatorUser 操作人
     * @return 返回法大大返回数据 初步解析
     * @throws Exception 所有异常
     */
    RestResponse invokeGenerateContract(String templateId, String contractId, String docTitle, String fontSize, String fontType, String parameterMap, String dynamicTables,Long clientId,Long operatorUser)throws Exception;

    /**
     * 法大大文档签署接口(手动签) 没有可不传标识 为必传项
     * @author      xieqingyang
     * @date 2018/7/31 下午4:59
     * @version     1.0
     * @param transactionId 交易号
     * @param customerId 客户编号
     * @param contractId 合同编号
     * @param docTitle 文档标题
     * @param signKeyword 定位关键字 可不传
     * @param clientId 客户信息表ID
     * @param operatorUser 操作人
     * @return 返回法大大返回数据
     * @throws Exception 所有异常
     */
    String invokeExtSign(String transactionId, String customerId, String contractId, String docTitle, String signKeyword,Long clientId,Long operatorUser)throws Exception;

    /**
     * 法大大用户信息修改接口
     * @author      xieqingyang
     * @date 2018/7/31 下午5:20
     * @version     1.0
     * @param customerId 法大大客户编号
     * @param email 邮箱 可不传
     * @param mobile 手机号码
     * @param clientId 客户信息表ID
     * @param operatorUser 操作人
     * @return 返回结果
     * @throws Exception 所有异常
     */
    RestResponse invokeInfoChange(String customerId, String email, String mobile,Long clientId,Long operatorUser)throws Exception;

    /**
     * 法大大异步或同步返回数据解析
     * @author      xieqingyang
     * @date 2018/8/2 下午1:43
     * @version     1.0
     * @param fddReturnInFoDTO 法大大数据
     * @return 返回处理结果
     */
    RestResponse fddAnalysis(FddReturnInFoDTO fddReturnInFoDTO);
}
