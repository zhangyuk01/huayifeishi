package com.xyb.order.common.util;
import java.lang.reflect.Field;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author ZhangYu
 *
 */
public class ListSortUtil {
   
	/**
	 *对list多个元素按照属性排序 
	 * @param list
	 * @param isAsc
	 *   true 升序  false 降序
	 * @param sortnameArr
	 */
    public static <E> void sort(List<E> list, final boolean isAsc, final String... sortnameArr) {
        Collections.sort(list, new Comparator<E>() {

            public int compare(E a, E b) {
                int ret = 0;
                try {
                    for (int i = 0; i < sortnameArr.length; i++) {
                        ret = ListSortUtil.compareObject(sortnameArr[i], isAsc, a, b);
                        if (0 != ret) {
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return ret;
            }
        });
    }
    
  /**
   *  
   * @param list
   * @param sortnameArr
   * @param typeArr
   */
    public static <E> void sort(List<E> list, final String[] sortnameArr, final boolean[] typeArr) {
        if (sortnameArr.length != typeArr.length) {
            throw new RuntimeException("属性数组元素个数和升降序数组元素个数不等");
        }
        Collections.sort(list, new Comparator<E>() {
            public int compare(E a, E b) {
                int ret = 0;
                try {
                    for (int i = 0; i < sortnameArr.length; i++) {
                        ret = ListSortUtil.compareObject(sortnameArr[i], typeArr[i], a, b);
                        if (0 != ret) {
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return ret;
            }
        });
    }

    /**
     * 对两个对象按照指定属性名称进行排序 
     * @param sortname
     * @param isAsc
     * @param a
     * @param b
     * @return
     * @throws Exception
     */
    private static <E> int compareObject(final String sortname, final boolean isAsc, E a, E b) throws Exception {
        int ret;
        Object value1 = ListSortUtil.forceGetFieldValue(a, sortname);
        Object value2 = ListSortUtil.forceGetFieldValue(b, sortname);
        String str1 = value1.toString();
        String str2 = value2.toString();
        if (value1 instanceof Number && value2 instanceof Number) {
            int maxlen = Math.max(str1.length(), str2.length());
            str1 = ListSortUtil.addZero2Str((Number) value1, maxlen);
            str2 = ListSortUtil.addZero2Str((Number) value2, maxlen);
        } else if (value1 instanceof Date && value2 instanceof Date) {
            long time1 = ((Date) value1).getTime();
            long time2 = ((Date) value2).getTime();
            int maxlen = Long.toString(Math.max(time1, time2)).length();
            str1 = ListSortUtil.addZero2Str(time1, maxlen);
            str2 = ListSortUtil.addZero2Str(time2, maxlen);
        }
        if (isAsc) {
            ret = str1.compareTo(str2);
        } else {
            ret = str2.compareTo(str1);
        }
        return ret;
    }

    /**
     *给数字对象按照指定长度左侧补0 
     * @param numObj
     * @param length
     * @return
     */
    public static String addZero2Str(Number numObj, int length) {
        NumberFormat nf = NumberFormat.getInstance();
        nf.setGroupingUsed(false);
        nf.setMaximumIntegerDigits(length);
        nf.setMinimumIntegerDigits(length);
        return nf.format(numObj);
    }

    /**
     * 获取指定对象的指定属性值 
     * @param obj
     * @param fieldName
     * @return
     * @throws Exception
     */
    public static Object forceGetFieldValue(Object obj, String fieldName) throws Exception {
        Field field = obj.getClass().getDeclaredField(fieldName);
        Object object = null;
        boolean accessible = field.isAccessible();
        if (!accessible) {
            field.setAccessible(true);
            object = field.get(obj);
            field.setAccessible(accessible);
            return object;
        }
        object = field.get(obj);
        return object;
    }
   
    /**
     * 根据对象中的INT类型进行排序
     * @return
     */
    public static<E> void sortByInt(List<E> list,final String param) throws Exception{
    	Collections.sort(list, new Comparator<E>() {
			@Override
			public int compare(E paramT1, E paramT2) {
				Object value1 = null;
                Object value2 = null;
				try {
					value1 = ListSortUtil.forceGetFieldValue(paramT1, param);
					value2 = ListSortUtil.forceGetFieldValue(paramT2, param);
				} catch (Exception e) {
					e.printStackTrace();
				}
			    int a = Integer.parseInt(value1.toString());
			    int b = Integer.parseInt(value2.toString());
			    if(a > b){  
	                return 1;  
	            }else if(a == b){  
	                return 0;  
	            }else{  
	                return -1;  
	            } 
			}
		});
    }
}
