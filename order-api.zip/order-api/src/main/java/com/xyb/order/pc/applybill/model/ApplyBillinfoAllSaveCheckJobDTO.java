package com.xyb.order.pc.applybill.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillinfoAllSaveCheckJobDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private ApplyBillInfoDTO applyBillInfoDTO; //申请单信息
	private ApplyClientInfoDTO applyClientInfoDTO;//客户信息
	private ApplyPersonInfoDTO applyPersonInfoDTO;//个人信息
	private ApplyJobInfoCheckDTO applyJobInfoCheckDTO;
	private ApplyPrivateInfoDTO applyPrivateInfoDTO;//私营信息
	private List<ApplyLinkmanInfoDTO> homeLinkManInfoDTO; //家庭联系人信息
	private List<ApplyLinkmanInfoDTO> workLinkManInfoDTO; //工作联系人信息
	private List<ApplyLinkmanInfoDTO> urgentLinkManInfoDTO; //紧急联系人信息
	private List<ApplyFamilyChildrenDTO> familyChildrenList;//子女信息

	public ApplyBillInfoDTO getApplyBillInfoDTO() {
		return applyBillInfoDTO;
	}
	public void setApplyBillInfoDTO(ApplyBillInfoDTO applyBillInfoDTO) {
		this.applyBillInfoDTO = applyBillInfoDTO;
	}
	public ApplyClientInfoDTO getApplyClientInfoDTO() {
		return applyClientInfoDTO;
	}
	public void setApplyClientInfoDTO(ApplyClientInfoDTO applyClientInfoDTO) {
		this.applyClientInfoDTO = applyClientInfoDTO;
	}
	public ApplyPersonInfoDTO getApplyPersonInfoDTO() {
		return applyPersonInfoDTO;
	}
	public void setApplyPersonInfoDTO(ApplyPersonInfoDTO applyPersonInfoDTO) {
		this.applyPersonInfoDTO = applyPersonInfoDTO;
	}
	public ApplyJobInfoCheckDTO getApplyJobInfoCheckDTO() {
		return applyJobInfoCheckDTO;
	}
	public void setApplyJobInfoCheckDTO(ApplyJobInfoCheckDTO applyJobInfoCheckDTO) {
		this.applyJobInfoCheckDTO = applyJobInfoCheckDTO;
	}
	public ApplyPrivateInfoDTO getApplyPrivateInfoDTO() {
		return applyPrivateInfoDTO;
	}
	public void setApplyPrivateInfoDTO(ApplyPrivateInfoDTO applyPrivateInfoDTO) {
		this.applyPrivateInfoDTO = applyPrivateInfoDTO;
	}
	public List<ApplyLinkmanInfoDTO> getHomeLinkManInfoDTO() {
		return homeLinkManInfoDTO;
	}
	public void setHomeLinkManInfoDTO(List<ApplyLinkmanInfoDTO> homeLinkManInfoDTO) {
		this.homeLinkManInfoDTO = homeLinkManInfoDTO;
	}
	public List<ApplyLinkmanInfoDTO> getWorkLinkManInfoDTO() {
		return workLinkManInfoDTO;
	}
	public void setWorkLinkManInfoDTO(List<ApplyLinkmanInfoDTO> workLinkManInfoDTO) {
		this.workLinkManInfoDTO = workLinkManInfoDTO;
	}
	public List<ApplyLinkmanInfoDTO> getUrgentLinkManInfoDTO() {
		return urgentLinkManInfoDTO;
	}
	public void setUrgentLinkManInfoDTO(List<ApplyLinkmanInfoDTO> urgentLinkManInfoDTO) {
		this.urgentLinkManInfoDTO = urgentLinkManInfoDTO;
	}
	public List<ApplyFamilyChildrenDTO> getFamilyChildrenList() {
		return familyChildrenList;
	}
	public void setFamilyChildrenList(List<ApplyFamilyChildrenDTO> familyChildrenList) {
		this.familyChildrenList = familyChildrenList;
	}
}
