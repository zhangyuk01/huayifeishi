package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * 推送深圳数据model
 * @author         xieqingyang
 * @date           2018/10/18 4:10 PM
*/
public class SignedEntryDTO<T> implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**数据*/
    private T body;
    /**签名*/
    private String sign;
    private String sn;

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    @Override
    public String toString() {
        return "SignedEntryDTO{" +
                "body=" + body +
                ", sign='" + sign + '\'' +
                ", sn='" + sn + '\'' +
                '}';
    }
}
