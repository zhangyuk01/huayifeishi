package com.xyb.order.app.client.authorization.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.authorization.model.IdentityInformationDTO;
import com.xyb.order.app.client.authorization.model.ThreePartyAuthorizationLogDO;

/**
* @description:    认证
* @author:         xieqingyang
* @createDate:     2018/5/12 下午5:14
*/
public interface AuthorizationService {

    /**
    * 查询授权列表
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/14 下午9:12
    */
    RestResponse queryAuthorizationList()throws Exception;

    /**
     * 修改产品必附项信息
     * @param authorizationProductDO 主需要传入model三个字段  isAdditional，modifyUser，authorizationType 具体model中有写
     * @return true 为成功 false为失败  注意捕获下异常
     */
    boolean updateAuthorizationProductAdditional(AuthorizationProductDO authorizationProductDO);

    /**
    * 身份认证接口
    * @author      xieqingyang
    * @param dto
    * @return
    * @exception
    * @date        2018/5/15 下午3:25
    */
    RestResponse identityInformation(IdentityInformationDTO dto)throws Exception;

    /**
    * 添加授权日志
    * @author      xieqingyang
    * @param dto
    * @return
    * @exception
    * @date        2018/5/16 下午5:16
    */
    RestResponse insertAuthorizationLog(ThreePartyAuthorizationLogDO dto)throws Exception;

    /**
     * 添加授权日志 三方回调
     * @author      xieqingyang
     * @param dto
     * @return
     * @exception
     * @date        2018/5/16 下午5:16
     */
    RestResponse insertLog(ThreePartyAuthorizationLogDO dto)throws Exception;

    /**
     * @description 查询是否完成所有申请并提交
     * @author      xieqingyang
     * @CreatedDate 2018/5/24 下午2:43
     * @Version     1.0
     * @return      返回是否完成授权
     */
    RestResponse confirmAuthorization()throws Exception;

    /**
     * @description 地址解析
     * @author      xieqingyang
     * @CreatedDate 2018/7/11 下午3:52
     * @Version     1.0
     * @param address 地址
     * @return  返回解析结果
     * @throws Exception 所有异常
     */
    RestResponse addressSplit(String address) throws Exception;

    /**
     * 查询是否能够授权
     * @description 查询是否能够授权
     * @author      xieqingyang
     * @CreatedDate 2018/7/26 下午3:28
     * @Version     1.0
     * @param  authorizationType 三方类型
     * @return 返回能够进行授权
     * @throws Exception 所有异常
     */
    RestResponse verification(String authorizationType)throws Exception;
}
