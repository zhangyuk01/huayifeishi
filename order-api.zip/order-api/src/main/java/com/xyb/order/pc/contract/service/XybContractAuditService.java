package com.xyb.order.pc.contract.service;


import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 合同审核service
 * @createDate : 2018/4/18 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractAuditService {
	/**
	 * 获取合同审核列表
	 * @param pageNumber
	 * @param pageSize
	 * @param xybContractAuditQueryDTO
	 * @return
	 */
	RestResponse listContractAudit(Integer pageNumber, Integer pageSize,XybContractAuditQueryDTO xybContractAuditQueryDTO) ;
	/**
	 * 合同审核详情
	 * @param xybContractAuditDetailDTO
	 * @return
	 */
	RestResponse updateContractAudit(XybContractAuditDetailDTO xybContractAuditDetailDTO) ;
	/**
	 * 合同审核暂存
	 * @param xybContractAuditDetailSaveDTO
	 * @return
	 */
	RestResponse saveContractAudit(XybContractAuditDetailSaveDTO xybContractAuditDetailSaveDTO) ;
	/**
	 * 合同审核提交
	 * @param xybContractAuditDetailSubmitDTO
	 * @return
	 */
	RestResponse submitContractAudit(XybContractAuditDetailSubmitDTO xybContractAuditDetailSubmitDTO,String macAddr,String ipAddr);

}
