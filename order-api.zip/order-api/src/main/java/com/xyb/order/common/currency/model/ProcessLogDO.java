package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * Created by xieqingyang on 2018/4/17.
 * 流程日志数据model
 */
public class ProcessLogDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    /**处理人*/
    private String operationUser;
    /**处理时间*/
    private Date operationTime;
    /**流程节点*/
    private String businessState;

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getBusinessState() {
        return businessState;
    }

    public void setBusinessState(String businessState) {
        this.businessState = businessState;
    }

    @Override
    public String toString() {
        return "ProcessLogDO{" +
                "operationUser='" + operationUser + '\'' +
                ", operationTime=" + operationTime +
                ", businessState='" + businessState + '\'' +
                '}';
    }
}
