package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * 客户端传输共有信息model
 * @author luyang
 * @date 2018-11-23 13:45:00
 */
public class ClientInfoDTO implements IBaseModel {
    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面
     */
    @NotEmpty(message = "交易终端不能为空")
    private String client;
    /**
     * 客户端ip
     */
    @NotEmpty(message = "客户端ip不能为空")
    private String client_ip;
    /**
     * 电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）
     */
    @NotEmpty(message = "IMEI不能为空")
    private String client_service;

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getClient_ip() {
        return client_ip;
    }

    public void setClient_ip(String client_ip) {
        this.client_ip = client_ip;
    }

    public String getClient_service() {
        return client_service;
    }

    public void setClient_service(String client_service) {
        this.client_service = client_service;
    }

    @Override
    public String toString() {
        return "ClientInfoDTO{" +
                "client='" + client + '\'' +
                ", client_ip='" + client_ip + '\'' +
                ", client_service='" + client_service + '\'' +
                '}';
    }
}
