package com.xyb.order.app.business.manage.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyCustomerInfoVO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	  /**是否有下一页 Y:是 N:否*/
    private String isMore;
	private List<AppCustomerInfoDO> customerList;
	
	public String getIsMore() {
		return isMore;
	}

	public void setIsMore(String isMore) {
		this.isMore = isMore;
	}

	public List<AppCustomerInfoDO> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<AppCustomerInfoDO> customerList) {
		this.customerList = customerList;
	} 
	
}
