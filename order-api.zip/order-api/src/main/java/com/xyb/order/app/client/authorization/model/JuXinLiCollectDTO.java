package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
* @description:    聚信力运营商传入参数
* @author:         xieqingyang
* @createDate:     2018/5/17 上午11:48
*/
public class JuXinLiCollectDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**
     * 申请单id 必填
     */
    private String applyId;
    /**
     * 提交申请处获取的token 必填
     */
    private String token;
    /**
     * 网站账号（移动运营商为手机号码） 必填
     */
    @NotEmpty(message = "网站账号不能为空")
    private String account;
    /**
     * 网站密码 （移动运营商为服务密码） 必填
     */
    @NotEmpty(message = "网站密码不能为空")
    private String password;
    /**
     * 网站短信验证码 必填
     */
    private String captcha;
    /**
     * SUBMIT_CAPTCHA（提交短信验证码）
     * RESEND_CAPTCHA（重发短信验证码）
     * SUBMIT_QUERY_PWD（提交查询密码）【仅北京移动会出现】
     * 必填
     */
    private String type;
    /**
     * 网站英文名称（上个接口返回值中取得） 必填
     */
    private String website;
    /**
     * 网站查询密码（仅北京移动会出现）
     */
    private String queryPwd;

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getQueryPwd() {
        return queryPwd;
    }

    public void setQueryPwd(String queryPwd) {
        this.queryPwd = queryPwd;
    }

    @Override
    public String toString() {
        return "JuXinLiCollectDTO{" +
                "applyId='" + applyId + '\'' +
                ", token='" + token + '\'' +
                ", account='" + account + '\'' +
                ", password='" + password + '\'' +
                ", captcha='" + captcha + '\'' +
                ", type='" + type + '\'' +
                ", website='" + website + '\'' +
                ", queryPwd='" + queryPwd + '\'' +
                '}';
    }
}
