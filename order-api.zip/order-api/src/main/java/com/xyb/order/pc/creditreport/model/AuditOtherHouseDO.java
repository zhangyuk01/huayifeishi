package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditOtherHouseDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //id
	private Long custId;//客户ID
	private Long applyId;//申请单ID
	private String houseAddress;//房产地址
	private String houseHost;//产权所有人
	private Double housePriceCount;//房屋总价
	private Long mortgageExplain;//抵押情况
	private String mortgageExplainStr;
	private String mortgagor;//抵押人
	private Double mortgageAmount;//抵押金额
	private Long houseAddressProvince;//房产地址省
	private String houseAddressProvinceStr;
	private Long houseAddressCity;//房产地址市
	private String houseAddressCityStr;
	private Long houseAddressArea;//房产地址区
	private String houseAddressAreaStr;
	private Double monthRepayAmount;//月还款金额
	private String houseArea;// 建筑面积
	private Long houseShare;//房产公用情况
	private String houseShareStr;
	private String houseShareRemark;//其他备注情况	
	private Long productId;
	private Date purchaseDate;//购买日期
	private String housePurpose;//规划用途


	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getHouseAddress() {
		return houseAddress;
	}
	public void setHouseAddress(String houseAddress) {
		this.houseAddress = houseAddress;
	}
	public String getHouseHost() {
		return houseHost;
	}
	public void setHouseHost(String houseHost) {
		this.houseHost = houseHost;
	}
	public Double getHousePriceCount() {
		return housePriceCount;
	}
	public void setHousePriceCount(Double housePriceCount) {
		this.housePriceCount = housePriceCount;
	}
	public Long getMortgageExplain() {
		return mortgageExplain;
	}
	public void setMortgageExplain(Long mortgageExplain) {
		this.mortgageExplain = mortgageExplain;
	}
	public String getMortgageExplainStr() {
		return mortgageExplainStr;
	}
	public void setMortgageExplainStr(String mortgageExplainStr) {
		this.mortgageExplainStr = mortgageExplainStr;
	}
	public String getMortgagor() {
		return mortgagor;
	}
	public void setMortgagor(String mortgagor) {
		this.mortgagor = mortgagor;
	}
	public Double getMortgageAmount() {
		return mortgageAmount;
	}
	public void setMortgageAmount(Double mortgageAmount) {
		this.mortgageAmount = mortgageAmount;
	}
	public Long getHouseAddressProvince() {
		return houseAddressProvince;
	}
	public void setHouseAddressProvince(Long houseAddressProvince) {
		this.houseAddressProvince = houseAddressProvince;
	}
	public String getHouseAddressProvinceStr() {
		return houseAddressProvinceStr;
	}
	public void setHouseAddressProvinceStr(String houseAddressProvinceStr) {
		this.houseAddressProvinceStr = houseAddressProvinceStr;
	}
	public Long getHouseAddressCity() {
		return houseAddressCity;
	}
	public void setHouseAddressCity(Long houseAddressCity) {
		this.houseAddressCity = houseAddressCity;
	}
	public String getHouseAddressCityStr() {
		return houseAddressCityStr;
	}
	public void setHouseAddressCityStr(String houseAddressCityStr) {
		this.houseAddressCityStr = houseAddressCityStr;
	}
	public Long getHouseAddressArea() {
		return houseAddressArea;
	}
	public void setHouseAddressArea(Long houseAddressArea) {
		this.houseAddressArea = houseAddressArea;
	}
	public String getHouseAddressAreaStr() {
		return houseAddressAreaStr;
	}
	public void setHouseAddressAreaStr(String houseAddressAreaStr) {
		this.houseAddressAreaStr = houseAddressAreaStr;
	}
	public Double getMonthRepayAmount() {
		return monthRepayAmount;
	}
	public void setMonthRepayAmount(Double monthRepayAmount) {
		this.monthRepayAmount = monthRepayAmount;
	}
	public String getHouseArea() {
		return houseArea;
	}
	public void setHouseArea(String houseArea) {
		this.houseArea = houseArea;
	}
	public Long getHouseShare() {
		return houseShare;
	}
	public void setHouseShare(Long houseShare) {
		this.houseShare = houseShare;
	}
	public String getHouseShareStr() {
		return houseShareStr;
	}
	public void setHouseShareStr(String houseShareStr) {
		this.houseShareStr = houseShareStr;
	}
	public String getHouseShareRemark() {
		return houseShareRemark;
	}
	public void setHouseShareRemark(String houseShareRemark) {
		this.houseShareRemark = houseShareRemark;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getHousePurpose() {
		return housePurpose;
	}
	public void setHousePurpose(String housePurpose) {
		this.housePurpose = housePurpose;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	
}
