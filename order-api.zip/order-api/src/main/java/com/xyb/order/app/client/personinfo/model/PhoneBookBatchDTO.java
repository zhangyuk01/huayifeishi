package com.xyb.order.app.client.personinfo.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 批次/日志实体类
 * 
 * @author qiaoJinLong
 * @date 2018年9月11日
 */
public class PhoneBookBatchDTO implements IBaseModel {

	private static final long serialVersionUID = 9007858680314252748L;

	private Long id;

	private Long clientId;// 客户ID

	private int shouldQty;// 应收数量

	private int actualQty;// 实收数量

	private Date createTime;// 创建时间

	private Long createUser;// 创建人

	private Date modifyTime;// 修改时间

	private Long modifyUser;// 修改人

	private String phoneType;// 手机型号

	@Override
	public String toString() {
		return "PhoneBookBatchDTO [id=" + id + ", clientId=" + clientId + ", shouldQty=" + shouldQty + ", actualQty="
				+ actualQty + ", createTime=" + createTime + ", createUser=" + createUser + ", modifyTime=" + modifyTime
				+ ", modifyUser=" + modifyUser + ", phoneType=" + phoneType + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public int getShouldQty() {
		return shouldQty;
	}

	public void setShouldQty(int shouldQty) {
		this.shouldQty = shouldQty;
	}

	public int getActualQty() {
		return actualQty;
	}

	public void setActualQty(int actualQty) {
		this.actualQty = actualQty;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

}
