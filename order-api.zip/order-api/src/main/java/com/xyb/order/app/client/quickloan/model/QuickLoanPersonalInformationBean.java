package com.xyb.order.app.client.quickloan.model;

import java.math.BigDecimal;

public class QuickLoanPersonalInformationBean extends QuickLoanRedisBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 申请借款金额
	 */
	private BigDecimal expectMoney;
	
	public BigDecimal getExpectMoney() {
		return expectMoney;
	}

	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}

	@Override
	public String toString() {
		return "QuickLoanPersonalInformationBean [expectMoney=" + expectMoney
				+ "]";
	}
}
