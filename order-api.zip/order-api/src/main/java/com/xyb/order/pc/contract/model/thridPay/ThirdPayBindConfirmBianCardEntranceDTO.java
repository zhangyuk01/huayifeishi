package com.xyb.order.pc.contract.model.thridPay;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同录入协议支付--确认绑卡DTO
 * @createDate : 2018/05/28 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ThirdPayBindConfirmBianCardEntranceDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6935962510131831234L;
	
	/**申请id*/
	@NotNull(message="applyId 不能为空")
	private Long applyId;
	/**渠道id*/
	@NotNull(message="channelId 不能为空")
	private Long channelId;
	/**预绑卡订单号*/
	@NotEmpty(message="order 不能为空")
	private String order;
	/**短信验证码*/
	@NotEmpty(message="validateCode 不能为空")
	private String validateCode;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getChannelId() {
		return channelId;
	}
	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getValidateCode() {
		return validateCode;
	}
	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}
	@Override
	public String toString() {
		return "ThirdPayBindConfirmBianCardEntranceDTO [applyId=" + applyId + ", channelId=" + channelId + ", order="
				+ order + ", validateCode=" + validateCode + "]";
	}

}
