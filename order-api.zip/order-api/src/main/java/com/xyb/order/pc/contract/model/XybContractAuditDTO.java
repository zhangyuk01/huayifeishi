package com.xyb.order.pc.contract.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 进件合同审核model层
 * @createDate : 2018/4/18 17:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditDTO implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2932327557154412512L;
	//属性部分
	private Long id; //id
	private Long contractId; //合同信息ID
	@NotNull(message="applyId不能为空")
	private Long applyId; //申请单ID
	@NotNull(message="contractAuditResult不能为空")
	private Long contractAuditResult; //审核结果
	private String contractAuditRemark; //审核备注
	private String refuseReason;//拒贷原因code
	private String refuseReasonValue; //拒贷原因描述
	private Long createUser; //创建人
	private String createName; //创建人
	private Date createTime; //创建时间
	private Date modifyTime; //修改时间
	private Long modifyUser; //修改人
	private String modifyName; //修改人姓名
	private Long isLine; //是否线上（大类2692
	private Long isTempSave;//是暂存（大类2692）
	private String backReason;//退回原因(大类2493)
	private String backReasonName;//退回原因中文描述
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getContractAuditResult() {
		return contractAuditResult;
	}
	public void setContractAuditResult(Long contractAuditResult) {
		this.contractAuditResult = contractAuditResult;
	}
	public String getContractAuditRemark() {
		return contractAuditRemark;
	}
	public void setContractAuditRemark(String contractAuditRemark) {
		this.contractAuditRemark = contractAuditRemark;
	}
	public String getRefuseReason() {
		return refuseReason;
	}
	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}
	public String getRefuseReasonValue() {
		return refuseReasonValue;
	}
	public void setRefuseReasonValue(String refuseReasonValue) {
		this.refuseReasonValue = refuseReasonValue;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public String getCreateName() {
		return createName;
	}
	public void setCreateName(String createName) {
		this.createName = createName;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getModifyName() {
		return modifyName;
	}
	public void setModifyName(String modifyName) {
		this.modifyName = modifyName;
	}
	public Long getIsLine() {
		return isLine;
	}
	public void setIsLine(Long isLine) {
		this.isLine = isLine;
	}
	public Long getIsTempSave() {
		return isTempSave;
	}
	public void setIsTempSave(Long isTempSave) {
		this.isTempSave = isTempSave;
	}
	public String getBackReason() {
		return backReason;
	}
	public void setBackReason(String backReason) {
		this.backReason = backReason;
	}
	public String getBackReasonName() {
		return backReasonName;
	}
	public void setBackReasonName(String backReasonName) {
		this.backReasonName = backReasonName;
	}
	@Override
	public String toString() {
		return "XybContractAuditDTO [id=" + id + ", contractId=" + contractId + ", applyId=" + applyId
				+ ", contractAuditResult=" + contractAuditResult + ", contractAuditRemark=" + contractAuditRemark
				+ ", refuseReason=" + refuseReason + ", refuseReasonValue=" + refuseReasonValue + ", createUser="
				+ createUser + ", createName=" + createName + ", createTime=" + createTime + ", modifyTime="
				+ modifyTime + ", modifyUser=" + modifyUser + ", modifyName=" + modifyName + ", isLine=" + isLine
				+ ", isTempSave=" + isTempSave + ", backReason=" + backReason + ", backReasonName=" + backReasonName
				+ "]";
	}

}
