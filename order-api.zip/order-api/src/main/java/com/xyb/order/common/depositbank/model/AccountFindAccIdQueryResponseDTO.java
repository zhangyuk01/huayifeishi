package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Objects;

/**
 * 查询是否开通存管户响应参数
 * @author         xieqingyang
 * @date           2018/12/25 4:25 PM
*/
public class AccountFindAccIdQueryResponseDTO implements IBaseModel {

    private static final long serialVersionUID = 4871090601605851230L;
    /**系统ID 北京2001 深圳3001*/
    private Long sysId;
    /**证件类型, 15 个人身份证 01 企业证件*/
    private String cert_type;
    /**证件号码*/
    private String cert_no;
    /**持卡人姓名*/
    private String name;
    /**客户号*/
    private String customer_no;
    /**电子账号*/
    private String card_no;
    /**开户日期*/
    private String create_date;
    /**交易代码 ,find_account_by_id*/
    private String service;
    /**资产账户ID*/
    private String acctId;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getCert_type() {
        return cert_type;
    }

    public void setCert_type(String cert_type) {
        this.cert_type = cert_type;
    }

    public String getCert_no() {
        return cert_no;
    }

    public void setCert_no(String cert_no) {
        this.cert_no = cert_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCreate_date() {
        return create_date;
    }

    public void setCreate_date(String create_date) {
        this.create_date = create_date;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getAcctId() {
        return acctId;
    }

    public void setAcctId(String acctId) {
        this.acctId = acctId;
    }

    @Override
    public String toString() {
        return "AccountFindAccIdQueryResponseDTO{" +
                "sysId=" + sysId +
                ", cert_type='" + cert_type + '\'' +
                ", cert_no='" + cert_no + '\'' +
                ", name='" + name + '\'' +
                ", customer_no='" + customer_no + '\'' +
                ", card_no='" + card_no + '\'' +
                ", create_date='" + create_date + '\'' +
                ", service='" + service + '\'' +
                ", acctId='" + acctId + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountFindAccIdQueryResponseDTO that = (AccountFindAccIdQueryResponseDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(cert_type, that.cert_type) &&
                Objects.equals(cert_no, that.cert_no) &&
                Objects.equals(name, that.name) &&
                Objects.equals(customer_no, that.customer_no) &&
                Objects.equals(card_no, that.card_no) &&
                Objects.equals(create_date, that.create_date) &&
                Objects.equals(service, that.service) &&
                Objects.equals(acctId, that.acctId);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, cert_type, cert_no, name, customer_no, card_no, create_date, service, acctId);
    }
}
