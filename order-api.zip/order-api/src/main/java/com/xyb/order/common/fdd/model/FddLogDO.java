package com.xyb.order.common.fdd.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    法大大日志
 * @author:         xieqingyang
 * @createDate:     2018/7/30 下午4:22
*/
public class FddLogDO implements IBaseModel {
    private static final long serialVersionUID = -6715216000511925401L;

    /**主键ID*/
    private Long id;
    /**客户信息表ID*/
    private Long clientId;
    /**合同编号*/
    private String contractId;
    /**交易号*/
    private String transactionId;
    /**接口名称*/
    private String interfaceName;
    /**请求参数字符串*/
    private String reqPmt;
    /**响应参数字符串*/
    private String respPmt;
    /**处理结果*/
    private String result;
    /**状态码*/
    private String code;
    /**描述*/
    private String msg;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getReqPmt() {
        return reqPmt;
    }

    public void setReqPmt(String reqPmt) {
        this.reqPmt = reqPmt;
    }

    public String getRespPmt() {
        return respPmt;
    }

    public void setRespPmt(String respPmt) {
        this.respPmt = respPmt;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "FddLogDO{" +
                "id=" + id +
                ", clientId=" + clientId +
                ", contractId=" + contractId +
                ", transactionId='" + transactionId + '\'' +
                ", interfaceName='" + interfaceName + '\'' +
                ", reqPmt='" + reqPmt + '\'' +
                ", respPmt='" + respPmt + '\'' +
                ", result='" + result + '\'' +
                ", code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
