package com.xyb.order.common.bank.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.bank.model.BankUpdateDTO;
import com.xyb.order.common.bank.model.JieAnVerifyParamDTO;

/**
 * @description:    银行卡相关功能
 * @author:         xieqingyang
 * @createDate:     2018/7/18 下午9:15
*/
public interface BankService {

    /**
     * 捷安鉴权接口
     * @description 验证银行卡四要素
     * @author      xieqingyang
     * @createDate  2018/7/19 上午11:41
     * @version     1.0
     * @param jieAnVerifyParamDTO 传入鉴权相关信息
     * @param clientId 客户信息表ID
     * @return 鉴权结果
     * @throws Exception 所有异常
     */
    RestResponse jieAnVerifyAccount(JieAnVerifyParamDTO jieAnVerifyParamDTO,Long clientId)throws Exception;

    /**
     * @description 根据银行卡号获取银行卡信息
     * @author      xieqingyang
     * @CreatedDate 2018/7/19 下午2:36
     * @Version     1.0
     * @param bankId 银行卡号
     * @return 返回银行卡信息
     * @throws Exception 所有异常
     */
    RestResponse getBankInfoByBankId(String bankId)throws Exception;

    /**
     * @description 获取支持的银行卡列表
     * @author      xieqingyang
     * @CreatedDate 2018/7/19 下午4:15
     * @Version     1.0
     * @return  返回银行卡列表信息
     * @throws Exception 所有异常
     */
    RestResponse queryBankIcon()throws Exception;

    /**
     * @description 获得绑卡的用户身份信息
     * @author      xieqingyang
     * @CreatedDate 2018/7/19 下午5:44
     * @Version     1.0
     * @return 返回用户信息
     * @throws Exception 所有异常
     */
    RestResponse getClientInfo()throws Exception;

    /**
     * @description 用户绑卡
     * @author      xieqingyang
     * @CreatedDate 2018/7/19 下午6:22
     * @Version     1.0
     * @param bankUpdateDTO 卡片信息
     * @return 返回结果
     * @throws Exception 所有异常
     */
    RestResponse tieOnCard(BankUpdateDTO bankUpdateDTO)throws Exception;

    /**
     * @description 用户换卡
     * @author      xieqingyang
     * @CreatedDate 2018/7/19 下午6:22
     * @Version     1.0
     * @param bankUpdateDTO 卡片信息
     * @return 返回结果
     * @throws Exception 所有异常
     */
    RestResponse changeCard(BankUpdateDTO bankUpdateDTO)throws Exception;

    /**
     * @description 获取用户银行卡信息
     * @author      xieqingyang
     * @CreatedDate 2018/7/20 下午5:12
     * @Version     1.0
     * @return 返回页面展示信息
     * @throws Exception 所有异常
     */
    RestResponse getBankCardInfo()throws Exception;

    /**
     * @description 获取用户银行卡绑定状态
     * @author      xieqingyang
     * @CreatedDate 2018/7/20 下午5:39
     * @Version     1.0
     * @return  返回状态
     * @throws Exception 所有异常
     */
    RestResponse getBankCardState()throws Exception;
}
