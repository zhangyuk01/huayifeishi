package com.xyb.order.app.client.apply.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyClientDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;
	private String name;
	private String idcard;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
}
