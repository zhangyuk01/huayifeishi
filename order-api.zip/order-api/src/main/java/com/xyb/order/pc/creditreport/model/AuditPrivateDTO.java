package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditPrivateDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String enterpriseName; //企业名称
	private Long enteType;//企业类型
	private String enteTypeStr;
	private String legalPerson;//法人
	private Double stockRatio;//所占股份
	private Date regDate; //成立日期
	
	private Long modifyUser;
	private Date modifyTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEnterpriseName() {
		return enterpriseName;
	}
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	public Long getEnteType() {
		return enteType;
	}
	public void setEnteType(Long enteType) {
		this.enteType = enteType;
	}
	public String getEnteTypeStr() {
		return enteTypeStr;
	}
	public void setEnteTypeStr(String enteTypeStr) {
		this.enteTypeStr = enteTypeStr;
	}
	public String getLegalPerson() {
		return legalPerson;
	}
	public void setLegalPerson(String legalPerson) {
		this.legalPerson = legalPerson;
	}
	public Double getStockRatio() {
		return stockRatio;
	}
	public void setStockRatio(Double stockRatio) {
		this.stockRatio = stockRatio;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}
