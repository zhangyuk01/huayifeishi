package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    捷安传入参数封装
 * @author:         xieqingyang
 * @createDate:     2018/7/19 上午11:14
*/
public class JieAnVerifyParamDTO implements IBaseModel {

    private static final long serialVersionUID = -5395994361270803114L;
    /**银行卡*/
    private String CARD_ID;
    /**身份证号*/
    private String CERT_ID;
    /**身份证名字*/
    private String CERT_NAME;
    /**手机号*/
    private String MP;
    /**产品代号*/
    private String PROD_ID;

    public String getCARD_ID() {
        return CARD_ID;
    }

    public void setCARD_ID(String CARD_ID) {
        this.CARD_ID = CARD_ID;
    }

    public String getCERT_ID() {
        return CERT_ID;
    }

    public void setCERT_ID(String CERT_ID) {
        this.CERT_ID = CERT_ID;
    }

    public String getCERT_NAME() {
        return CERT_NAME;
    }

    public void setCERT_NAME(String CERT_NAME) {
        this.CERT_NAME = CERT_NAME;
    }

    public String getMP() {
        return MP;
    }

    public void setMP(String MP) {
        this.MP = MP;
    }

    public String getPROD_ID() {
        return PROD_ID;
    }

    public void setPROD_ID(String PROD_ID) {
        this.PROD_ID = PROD_ID;
    }

    @Override
    public String toString() {
        return "JieAnVerifyParamDTO{" +
                "CARD_ID='" + CARD_ID + '\'' +
                ", CERT_ID='" + CERT_ID + '\'' +
                ", CERT_NAME='" + CERT_NAME + '\'' +
                ", MP='" + MP + '\'' +
                ", PROD_ID='" + PROD_ID + '\'' +
                '}';
    }
}
