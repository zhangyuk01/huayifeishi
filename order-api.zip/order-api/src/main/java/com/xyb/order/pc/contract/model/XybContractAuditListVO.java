package com.xyb.order.pc.contract.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;


/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同审核list返回数据model
 * @createDate : 2018/05/03 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditListVO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7586835294870269358L;
	/**申请Id*/
	private Long applyId;
	/**申请编号*/
	private String applyNum;
	/**合同编号*/
	private String contractNum;
	/**一级授信产品*/
	private String agreeProductName;
	/**提交审核日期*/
	private Date submitTime;
	/**客户姓名*/
	private String custName;
	/**身份证号码*/
	private String idCard;
	/**终极授信金额*/
	private BigDecimal contractAmount;
	/**终极授信期数*/
	private int agreeProductLimit;
	/**一级授信金额*/
	private BigDecimal agreeAmount;
	/**进件机构*/
	private String orgName;
	/**是否签约前核验*/
	private String signCheck;
	/**当前状态*/
	private Long isTempSave;
	/**当前状态name*/
	private String isTempSaveName;
	/**当前操作人*/
	private String processer;
	/**当前操作人uid*/
	private Long processerUid;
	/**当前登录人ID*/
	private Long loginId;
	/**确认金额*/
	private BigDecimal confirmAmout;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getAgreeProductName() {
		return agreeProductName;
	}
	public void setAgreeProductName(String agreeProductName) {
		this.agreeProductName = agreeProductName;
	}
	public Date getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(Date submitTime) {
		this.submitTime = submitTime;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public int getAgreeProductLimit() {
		return agreeProductLimit;
	}
	public void setAgreeProductLimit(int agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}
	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getSignCheck() {
		return signCheck;
	}
	public void setSignCheck(String signCheck) {
		this.signCheck = signCheck;
	}
	public Long getIsTempSave() {
		return isTempSave;
	}
	public void setIsTempSave(Long isTempSave) {
		this.isTempSave = isTempSave;
	}
	public String getIsTempSaveName() {
		return isTempSaveName;
	}
	public void setIsTempSaveName(String isTempSaveName) {
		this.isTempSaveName = isTempSaveName;
	}
	public String getProcesser() {
		return processer;
	}
	public void setProcesser(String processer) {
		this.processer = processer;
	}
	public Long getProcesserUid() {
		return processerUid;
	}
	public void setProcesserUid(Long processerUid) {
		this.processerUid = processerUid;
	}
	public Long getLoginId() {
		return loginId;
	}
	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	@Override
	public String toString() {
		return "XybContractAuditListVO{" +
				"applyId=" + applyId +
				", applyNum='" + applyNum + '\'' +
				", contractNum='" + contractNum + '\'' +
				", agreeProductName='" + agreeProductName + '\'' +
				", submitTime=" + submitTime +
				", custName='" + custName + '\'' +
				", idCard='" + idCard + '\'' +
				", contractAmount=" + contractAmount +
				", agreeProductLimit=" + agreeProductLimit +
				", agreeAmount=" + agreeAmount +
				", orgName='" + orgName + '\'' +
				", signCheck='" + signCheck + '\'' +
				", isTempSave=" + isTempSave +
				", isTempSaveName='" + isTempSaveName + '\'' +
				", processer='" + processer + '\'' +
				", processerUid=" + processerUid +
				", loginId=" + loginId +
				", confirmAmout=" + confirmAmout +
				'}';
	}
}
