package com.xyb.order.common.depositbank.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.agreement.model.ResultDTO;
import com.xyb.order.common.depositbank.model.*;

/**
 * 存管接口
 * 
 * @author xieqingyang
 * @date 2018/11/22 6:28 PM
 */
public interface DepositBankService {

	/**
	 * 解绑通知接口
	 * 
	 * @param resultDTO 通知数据
	 * @return 返回接收情况结果
	 * @author qiaojinlong
	 * @date 2018/11/26 3:14 PM
	 * @version 1.0
	 */
	RestResponse unBindNotice(ResultDTO<UnbindNoticeDTO> resultDTO);

	/**
	 * 添加存管调用日志
	 * 
	 * @param depositAccountId 存管账户ID
	 * @param interfaceName 接口名称
	 * @param requestMsg 调用信息
	 * @param responseMsg 响应信息
	 * @param createUser 创建人
	 * @author xieqingyang
	 * @date 2018/11/23 5:03 PM
	 * @version 1.0
	 */
	void addLog(Long depositAccountId, String interfaceName, String requestMsg, String responseMsg, Long createUser);

	/**
	 * 存管开户接口
	 * 
	 * @param clientInfoDTO 传入参数
	 * @return 如果成功返回开户页面地址，失败返回失败信息
	 * @throws Exception 所有未捕获（只捕获了深圳接口调用异常）的异常
	 * @author xieqingyang
	 * @date 2018/11/23 4:41 PM
	 * @version 1.0
	 */
	RestResponse accountOpen(ClientInfoDTO clientInfoDTO) throws Exception;

	/**
	 * 重置电子账户交易密码
	 * 
	 * @param clientInfoDTO 传入参数
	 * @return 如果成功返回重置电子账户交易密码页面地址，失败返回失败信息
	 * @throws Exception 所有未捕获（只捕获了深圳接口调用异常）的异常
	 * @author xieqingyang
	 * @date 2018/11/26 11:09 AM
	 * @version 1.0
	 */
	RestResponse accountReqwd(ClientInfoDTO clientInfoDTO) throws Exception;

	/**
	 * 个人绑卡网关接口
	 * 
	 * @param clientInfoDTO  传入参数
	 * @return 如果成功返回个人绑卡页面地址，失败返回失败信息
	 * @throws Exception 所有未捕获（只捕获了深圳接口调用异常）的异常
	 * @author luyang
	 * @date 2018/11/26 11:38 AM
	 * @version 1.0
	 */
	RestResponse bindBankCard(ClientInfoDTO clientInfoDTO) throws Exception;

	/**
	 * 解绑银行卡请求提交
	 * 
	 * @param clientInfoDTO 传入参数
	 * @return 如果成功返回解绑银行卡页面地址，失败返回失败信息
	 * @throws Exception 所有未捕获（只捕获了深圳接口调用异常）的异常
	 * @author fangjie
	 * @date 2018/11/26 11:37 AM
	 * @version 1.0
	 */
	RestResponse unBindBankCardSubmit(ClientInfoDTO clientInfoDTO) throws Exception;

	/**
	 * 个人绑卡注册通知
	 * 
	 * @param resultDTO 通知数据
	 * @return 返回接收通知结果
	 * @author jiangzhongyan
	 * @date 2018/11/26 4:50 PM
	 * @version 1.0
	 */
	RestResponse depositAccountToNotice(ResultDTO<DepositAccountToNoticeDTO> resultDTO);

	/**
	 * 借款人放款手续费和还款金额签约
	 * 
	 * @param clientInfoDTO 传入参数
	 * @return 如果成功返回借款人放款手续费和还款金额签约页面地址，失败返回失败信息
	 * @throws Exception 所有未捕获（只捕获了深圳接口调用异常）的异常
	 * @author xieqingyang
	 * @date 2018/11/26 4:31 PM
	 * @version 1.0
	 */
	RestResponse loanSignContract(ClientInfoDTO clientInfoDTO) throws Exception;

	/**
	 * 个人绑卡网关通知接口
	 * 
	 * @param noticeDto 通知数据
	 * @return 返回接收通知结果
	 * @author wangshicheng
	 * @date 2018/11/26 4:56 PM
	 * @version 1.0
	 */
	RestResponse bindCardNotice(ResultDTO<BindCardNoticeDTO> noticeDto);

	/**
	 * 异步通知签约结果
	 * 
	 * @author jiangzhongyan
	 * @date 2018/11/26 6:06 PM
	 * @version 1.0
	 * @param resultDTO 异步通知信息
	 * @return 返回接收结果
	 */
	RestResponse signingNotification(ResultDTO<SigningNotificationDTO> resultDTO);

	/**
	 * 查询借款人放款手续费和还款金额签约状态
	 * 
	 * @param clientId 用户信息表主键ID
	 * @return 返回是否进行签约 2486-已签约 2487-未签约
	 * @author xieqingyang
	 * @date 2018/11/26 5:00 PM
	 * @version 1.0
	 */
	Long getSignState(Long clientId);

	/**
	 * 查询存管户是否已经开户 已经开户初始化存管账户信息
	 * @author      xieqingyang
	 * @date        2018/12/25 4:22 PM
	 * @version     1.0
	 * @param userId 用户登录信息表ID 可为空
	 * @param clientId 用户信息表ID 不可为空
	 * @param certNo 证件号码 ，必填,18(位数) 不可为空
	 * @param client 交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面 不可为空
	 * @param custom 商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户 可为空
	 * @param clientIp 客户端ip 不可为空
	 * @param clientService 电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA） 不可为空
	 * @return 返回是否查询到有效的账户信息
	 */
	boolean accountFindAccIdQuery(Long userId,Long clientId,String certNo, String client, String custom, String clientIp, String clientService);
}
