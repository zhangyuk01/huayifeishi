package com.xyb.order.pc.contract.model.newrepaymentplan;

import java.math.BigDecimal;
import java.util.Date;

//不同还款方式最小的还款单元
public class RefundUnit {
	
	private Date refundDate; //回款日期
	private Date delimitTime; //划扣日期
	private Date loanPayTime;//到账日期
	private BigDecimal principal; //回款本金
	private BigDecimal interest;  //回款收益
	private BigDecimal principalBal ; //期末剩余本金
	private BigDecimal addInterest ; //加息收益
	private BigDecimal serviceFee = BigDecimal.ZERO;
	
	
	public RefundUnit(Date refundDate,Date delimitTime,Date loanPayTime, BigDecimal principal, BigDecimal interest, BigDecimal principalBal, BigDecimal addInterest) {
		this.refundDate = refundDate;
		this.delimitTime=delimitTime;
		this.loanPayTime=loanPayTime;
		this.principal = principal;
		this.interest = interest;
		this.principalBal = principalBal;
		this.addInterest = addInterest;
	}

	public RefundUnit(Date refundDate, BigDecimal principal, BigDecimal interest, BigDecimal principalBal, BigDecimal addInterest) {
		this.refundDate = refundDate;
		this.principal = principal;
		this.interest = interest;
		this.principalBal = principalBal;
		this.addInterest = addInterest;
	}
	
	/**
	 * 得到回款本金与收益
	 * @return
	 */
	public BigDecimal getTotalRefund() {
		return this.principal.add(this.interest).setScale(2, BigDecimal.ROUND_DOWN);
	}

	public String toString() {
		StringBuilder s  = new StringBuilder();
		s.append("principal: ").append(principal).append(",\t");
		s.append("interest: ").append(interest).append(",\t");
		s.append("total: ").append(principal.add(interest)).append("\t");
		s.append("principalBal: ").append(principalBal).append("\t");
		s.append("addInterest: ").append(addInterest).append("\t");
		return s.toString();
	}
	
	public Date getRefundDate() {
		return refundDate;
	}
	public void setRefundDate(Date refundDate) {
		this.refundDate = refundDate;
	}

	public BigDecimal getPrincipal() {
		return principal;
	}
	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}

	public BigDecimal getInterest() {
		return interest;
	}
	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

	public BigDecimal getPrincipalBal() {
		return principalBal;
	}
	public void setPrincipalBal(BigDecimal principalBal) {
		this.principalBal = principalBal;
	}

	public BigDecimal getAddInterest() {
		return addInterest;
	}
	public void setAddInterest(BigDecimal addInterest) {
		this.addInterest = addInterest;
	}

	public BigDecimal getServiceFee() {
		return serviceFee;
	}
	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}

	public Date getDelimitTime() {
		return delimitTime;
	}

	public void setDelimitTime(Date delimitTime) {
		this.delimitTime = delimitTime;
	}

	public Date getLoanPayTime() {
		return loanPayTime;
	}

	public void setLoanPayTime(Date loanPayTime) {
		this.loanPayTime = loanPayTime;
	}

}
