package com.xyb.order.pc.contract.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 合同service
 * @createDate : 2018/03/28 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractService {
	/**
	 * 获取合同列表
	 * @param pageNumber
	 * @param pageSize
	 * @param xybContractQueryDTO
	 * @return
	 */
	RestResponse listContract(Integer pageNumber, Integer pageSize,XybContractQueryDTO xybContractQueryDTO) ;
	/**
	 * 合同详情页
	 * @param xybContractDetailDTO
	 * @return
	 */
	RestResponse updateContract(XybContractDetailDTO xybContractDetailDTO) ;
	/**
	 * 合同录入列表点操作存管相关校验
	 * @param xybContractDetailDTO
	 * @return
	 */
	RestResponse updateCheck(XybContractDetailDTO xybContractDetailDTO) ;
	/**
	 * 合同暂存
	 * @param xybContractDetailSaveDTO
	 * @return
	 */
	RestResponse saveContract(XybContractDetailSaveDTO xybContractDetailSaveDTO) ;
	/**
	 * 合同提交
	 * @param xybContractDetailSubmitDTO
	 * @return
	 */
	RestResponse submitContract(XybContractDetailSubmitDTO xybContractDetailSubmitDTO,String macAddr,String ipAddr);
	/**
	 * 合同作废
	 * @param xybContractAbolishDTO
	 * @return
	 */
	RestResponse abolishContract(XybContractAbolishDTO xybContractAbolishDTO);
	/***
	 * 1.获取当前用户待绑卡渠道列表
	 * @param thirdPayBindDTO
	 * @return
	 */
	RestResponse getUserNotBindChannel(ThirdPayBindDTO thirdPayBindDTO);
	/**
	 * 2.预绑卡
	 * @param thirdPayBindPreDTO
	 * @return
	 */
	RestResponse preBindCardEntrance(ThirdPayBindPreDTO thirdPayBindPreDTO);
	/**
	 * 3.预绑卡--重发短信
	 * @param thirdPayBindPreResendDTO
	 * @return
	 */
	RestResponse resendMessage(ThirdPayBindPreResendDTO thirdPayBindPreResendDTO);
	/***
	 * 4.确认绑卡
	 * @param thirdPayBindConfirmBianCardEntranceDTO
	 * @return
	 */
	RestResponse confirmBianCardEntrance(ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO);
	/**
	 * 初始化合同信息
	 * @param applyId
	 * @param channelId
	 * @param userId
	 * @return
	 */
	XybContractDO addContract (Long applyId,Long channelId,Long userId,String[] recommendedWordIdS) throws Exception;
	/**
	 * 查询申请已办合同信息
	 * @param applyId
	 * @return
	 */
	RestResponse applyAlreadyContractInfo(Long applyId) ;
	/***
	 * 获取还款计划
	 * @param applyId
	 * @return
	 */
	RestResponse getRepaymentPlans(Long applyId);
}
