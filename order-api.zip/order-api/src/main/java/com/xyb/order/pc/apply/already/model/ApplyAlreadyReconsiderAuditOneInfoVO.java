package com.xyb.order.pc.apply.already.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 申请已办第一次复议审核记录信息
 * @createDate : 2018/06/05 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyReconsiderAuditOneInfoVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5704746330059469476L;
	
	/**复议时间*/
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	private Date reconsiderTime;
	/**复议审核结果*/
	private String reconsiderResult;
	/**复议审核意见*/
	private String reconsideIdear;
	
	public Date getReconsiderTime() {
		return reconsiderTime;
	}

	public void setReconsiderTime(Date reconsiderTime) {
		this.reconsiderTime = reconsiderTime;
	}

	public String getReconsiderResult() {
		return reconsiderResult;
	}

	public void setReconsiderResult(String reconsiderResult) {
		this.reconsiderResult = reconsiderResult;
	}

	public String getReconsideIdear() {
		return reconsideIdear;
	}

	public void setReconsideIdear(String reconsideIdear) {
		this.reconsideIdear = reconsideIdear;
	}

	@Override
	public String toString() {
		return "ApplyAlreadyReconsiderAuditOneInfoVO [reconsiderTime=" + reconsiderTime + ", reconsiderResult="
				+ reconsiderResult + ", reconsideIdear=" + reconsideIdear + "]";
	}

}
