package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    App展示列表信息
 * @author:         xieqingyang
 * @createDate:     2018/6/29 下午3:10
*/
public class AppMessageVO implements IBaseModel {

    private static final long serialVersionUID = -8784298043739279200L;
    /**最后一条标题*/
    private String title = "";
    /**最后一条创建时间*/
    private String createDate = "";
    /**总条数*/
    private Integer totalNum;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public Integer getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Integer totalNum) {
        this.totalNum = totalNum;
    }

    @Override
    public String toString() {
        return "AppMessageVO{" +
                "title='" + title + '\'' +
                ", createDate=" + createDate +
                ", totalNum=" + totalNum +
                '}';
    }
}
