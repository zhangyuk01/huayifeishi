package com.xyb.order.app.client.personinfo.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class PhoneBookBO implements IBaseModel {

	private static final long serialVersionUID = 1L;

	private Long batchNum;// 批次号

	private List<PhoneBookDTO> beans;

	private Long userId;

	@Override
	public String toString() {
		return "PhoneBookBO [batchNum=" + batchNum + ", beans=" + beans + ", userId=" + userId + "]";
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getBatchNum() {
		return batchNum;
	}

	public void setBatchNum(Long batchNum) {
		this.batchNum = batchNum;
	}

	public List<PhoneBookDTO> getBeans() {
		return beans;
	}

	public void setBeans(List<PhoneBookDTO> beans) {
		this.beans = beans;
	}

}
