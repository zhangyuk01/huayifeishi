package com.xyb.order.pc.contract.contracttb.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

public class ContractTbResultItemsDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4130380124706127920L;
	/**code*/
	private String code;
	private String message;
	@SignField(order = 3)
	private String applyId;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	@Override
	public String toString() {
		return "ContractTbResultItemsDTO [code=" + code + ", message=" + message + ", applyId=" + applyId + "]";
	}
	

}
