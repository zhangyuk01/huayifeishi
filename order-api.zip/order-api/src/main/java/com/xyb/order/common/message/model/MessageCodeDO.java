package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * 短信验证码
 * Created by xieqingyang on 2018/4/11.
 */
public class MessageCodeDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private Long id;// -- 主键id
    private String phone; // -- 手机号
    private String code; // -- 验证码
    private String type; // -- 验证码类型
    private String state; // -- 短信有效状态0-有效1-失效
    private String createUid; // -- 创建人
    private String updateUid;; // -- 修改人
    private Date createDate;// -- 创建时间
    private Date updateDate;// -- 修改时间

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCreateUid() {
        return createUid;
    }

    public void setCreateUid(String createUid) {
        this.createUid = createUid;
    }

    public String getUpdateUid() {
        return updateUid;
    }

    public void setUpdateUid(String updateUid) {
        this.updateUid = updateUid;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
