package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @description:    存入推送消息唯一标识
 * @author:         xieqingyang
 * @createDate:     2018/6/26 下午1:59
*/
public class DeviceTokenDTO implements IBaseModel {

    private static final long serialVersionUID = -4480477398131872587L;
    /**唯一标识*/
    @NotEmpty(message = "唯一标识不能为空")
    private String deviceToken;
    /**客户端类型 B:B端 C：C端*/
    @NotEmpty(message = "客户端类型不能为空")
    private String appType;

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    @Override
    public String toString() {
        return "DeviceTokenDTO{" +
                "deviceToken='" + deviceToken + '\'' +
                ", appType='" + appType + '\'' +
                '}';
    }
}
