package com.xyb.order.app.business.outbound.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.business.outbound.model.*;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.service
 * @description :
 * @createDate : 2018/6/13 11:00
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface BusinessOutBoundService {

    /**
     * 获取外访列表
     * @return
     * @throws Exception
     */
    RestResponse getBusinessOutBoundList() throws Exception;

    /**
     * 获取客户信息
     * @param applyMainId
     * @return
     * @throws Exception
     */
    RestResponse getBusinessClientInfo(Long applyMainId) throws Exception;

    /**
     * 获取工作信息
     * @param visitMainId
     * @return
     * @throws Exception
     */
    RestResponse getBusinessJobInfo(Long visitMainId,Long applyMainId) throws Exception;

    /**
     * 获取家庭信息
     * @param visitMainId
     * @return
     * @throws Exception
     */
    RestResponse getBusinessFamilyInfo(Long visitMainId,Long applyMainId) throws Exception;

    /**
     * 获取经营信息
     * @param visitMainId
     * @return
     * @throws Exception
     */
    RestResponse getBusinessManagermentInfo(Long visitMainId,Long applyMainId) throws Exception;

    /**
     * 获取产调信息
     * @param applyId
     * @return
     * @throws Exception
     */
    RestResponse getBusinessPropertySurveyInfo(Long applyId) throws Exception;

    /**
     * 修改新增工作信息
     * @param businessOutBoundJobInfoDTO
     * @return
     * @throws Exception
     */
    RestResponse updateOrAddBusinessJobInfo(BusinessOutBoundJobInfoDTO businessOutBoundJobInfoDTO) throws Exception;

    /**
     * 修改新增家庭信息
     * @param businessOutBoundFamilyInfoDTO
     * @return
     * @throws Exception
     */
    RestResponse updateOrAddBusinessFamilyInfo(BusinessOutBoundFamilyInfoDTO businessOutBoundFamilyInfoDTO) throws Exception;

    /**
     * 修改新增经营信息
     * @param businessOutBoundManagermentInfoDTO
     * @return
     * @throws Exception
     */
    RestResponse updateOrAddBusinessManagermentInfo(BusinessOutBoundManagermentInfoDTO businessOutBoundManagermentInfoDTO) throws Exception;

    /**
     * 修改新增产调信息（提交流程）
     * @param businessOutBoundPropertySurveyDTO
     * @return
     * @throws Exception
     */
    RestResponse updateOrAddBusinessPropertySurveyInfo(BusinessOutBoundPropertySurveyDTO businessOutBoundPropertySurveyDTO) throws Exception;

    /**
     * 外访经营提交
     * @param businessOutBoundManagermentSubmitDTO
     * @return
     */
    RestResponse businessManagermentSubmit(BusinessOutBoundManagermentSubmitDTO businessOutBoundManagermentSubmitDTO) throws Exception;
}