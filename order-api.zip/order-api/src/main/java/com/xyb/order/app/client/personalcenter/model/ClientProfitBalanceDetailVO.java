package com.xyb.order.app.client.personalcenter.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 余额类型查询
 * 
 * @author qiaoJinLong
 * @date 2018年9月20日
 */
public class ClientProfitBalanceDetailVO implements IBaseModel {

	private static final long serialVersionUID = 1819974525260137844L;

	private Integer type;// 类型 0 /null全部 1 质保，2 推荐， 3 提现

	private Date startTime; // 开始日期

	private Date endTime;// 结束时间

	private Integer isExist;// 是否存在page;

	private String loginId;

	private ClientProfitBalanceDetailPage page;

	@Override
	public String toString() {
		return "ClientProfitBalanceDetailVO [type=" + type + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", isExist=" + isExist + ", loginId=" + loginId + ", page=" + page + "]";
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Integer getIsExist() {
		return isExist;
	}

	public void setIsExist(Integer isExist) {
		this.isExist = isExist;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public ClientProfitBalanceDetailPage getPage() {
		return page;
	}

	public void setPage(ClientProfitBalanceDetailPage page) {
		this.page = page;
	}

}
