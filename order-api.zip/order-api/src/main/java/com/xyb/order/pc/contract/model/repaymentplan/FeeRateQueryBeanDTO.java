package com.xyb.order.pc.contract.model.repaymentplan;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 还款计划费率计算DTO
 * @createDate : 2018/06/01 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class FeeRateQueryBeanDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7171832783220230985L;
	private Long productId;// 产品ID
	private Long calculationValue;// 计算方式ID
	private int productLimit;// 期次
	private BigDecimal serviceProportion;// 服务费率
	private BigDecimal productProportion;// 借款利率
	private BigDecimal accountProportion;// 账户管理费率
	private BigDecimal creditProportion;// 信用奖金率
	private BigDecimal actualSum;// 实批金额
	private BigDecimal contractSum;// 合同金额
	private BigDecimal serviceSum;// 服务费
	private BigDecimal creditSum;// 信用奖金费
	private String loanChannel;// 放款渠道 1，信用宝 2，小赢 3，南粤
	private java.util.Date planDate;// 还款日期
	private String contractNum;// 合同编号
	private int repDate;// 还款日
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getCalculationValue() {
		return calculationValue;
	}
	public void setCalculationValue(Long calculationValue) {
		this.calculationValue = calculationValue;
	}
	public int getProductLimit() {
		return productLimit;
	}
	public void setProductLimit(int productLimit) {
		this.productLimit = productLimit;
	}
	public BigDecimal getServiceProportion() {
		return serviceProportion;
	}
	public void setServiceProportion(BigDecimal serviceProportion) {
		this.serviceProportion = serviceProportion;
	}
	public BigDecimal getProductProportion() {
		return productProportion;
	}
	public void setProductProportion(BigDecimal productProportion) {
		this.productProportion = productProportion;
	}
	public BigDecimal getAccountProportion() {
		return accountProportion;
	}
	public void setAccountProportion(BigDecimal accountProportion) {
		this.accountProportion = accountProportion;
	}
	public BigDecimal getCreditProportion() {
		return creditProportion;
	}
	public void setCreditProportion(BigDecimal creditProportion) {
		this.creditProportion = creditProportion;
	}
	public BigDecimal getActualSum() {
		return actualSum;
	}
	public void setActualSum(BigDecimal actualSum) {
		this.actualSum = actualSum;
	}
	public BigDecimal getContractSum() {
		return contractSum;
	}
	public void setContractSum(BigDecimal contractSum) {
		this.contractSum = contractSum;
	}
	public BigDecimal getServiceSum() {
		return serviceSum;
	}
	public void setServiceSum(BigDecimal serviceSum) {
		this.serviceSum = serviceSum;
	}
	public BigDecimal getCreditSum() {
		return creditSum;
	}
	public void setCreditSum(BigDecimal creditSum) {
		this.creditSum = creditSum;
	}
	public String getLoanChannel() {
		return loanChannel;
	}
	public void setLoanChannel(String loanChannel) {
		this.loanChannel = loanChannel;
	}
	public java.util.Date getPlanDate() {
		return planDate;
	}
	public void setPlanDate(java.util.Date planDate) {
		this.planDate = planDate;
	}
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public int getRepDate() {
		return repDate;
	}
	public void setRepDate(int repDate) {
		this.repDate = repDate;
	}
	@Override
	public String toString() {
		return "FeeRateQueryBeanDTO [productId=" + productId + ", calculationValue=" + calculationValue
				+ ", productLimit=" + productLimit + ", serviceProportion=" + serviceProportion + ", productProportion="
				+ productProportion + ", accountProportion=" + accountProportion + ", creditProportion="
				+ creditProportion + ", actualSum=" + actualSum + ", contractSum=" + contractSum + ", serviceSum="
				+ serviceSum + ", creditSum=" + creditSum + ", loanChannel=" + loanChannel + ", planDate=" + planDate
				+ ", contractNum=" + contractNum + ", repDate=" + repDate + "]";
	}

}
