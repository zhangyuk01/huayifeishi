package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 短信验证码
 * Created by xieqingyang on 2018/4/11.
 */
public class MessageCodeDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private String phone; // -- 手机号
    private String code; // -- 验证码
    private String type; // -- 验证码类型
    private String state; // -- 短信有效状态0-有效1-失效
    private Long operationUser; // -- 操作人

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Long getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(Long operationUser) {
        this.operationUser = operationUser;
    }
}
