package com.xyb.order.app.client.quickloan.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author luyang
 * @ClassName QuickLoanBusinessDO
 * @description 优信借进件数据统计
 * @time 2018/12/21 11:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class QuickLoanBusinessDO implements IBaseModel{

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 产品ID
     */
    private Long productId;
    /**
     * 日期
     */
    private Date businessDate;
    /**
     * 申请金额
     */
    private BigDecimal applyMoney;
    /**
     * 批准金额
     */
    private BigDecimal approvalMoney;
    /**
     * 放款金额
     */
    private BigDecimal loanMoney;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 修改时间
     */
    private Date modifyTime;
    /**
     * 修改人
     */
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Date getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(Date businessDate) {
        this.businessDate = businessDate;
    }

    public BigDecimal getApplyMoney() {
        return applyMoney;
    }

    public void setApplyMoney(BigDecimal applyMoney) {
        this.applyMoney = applyMoney;
    }

    public BigDecimal getApprovalMoney() {
        return approvalMoney;
    }

    public void setApprovalMoney(BigDecimal approvalMoney) {
        this.approvalMoney = approvalMoney;
    }

    public BigDecimal getLoanMoney() {
        return loanMoney;
    }

    public void setLoanMoney(BigDecimal loanMoney) {
        this.loanMoney = loanMoney;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "QuickLoanBusinessDO{" +
                "id=" + id +
                ", productId=" + productId +
                ", businessDate=" + businessDate +
                ", applyMoney=" + applyMoney +
                ", approvalMoney=" + approvalMoney +
                ", loanMoney=" + loanMoney +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}