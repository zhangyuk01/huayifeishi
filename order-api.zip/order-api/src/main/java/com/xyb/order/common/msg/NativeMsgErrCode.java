package com.xyb.order.common.msg;

import com.beiming.kun.framework.msg.MessageError;

import org.apache.http.protocol.HTTP;
import org.springframework.http.HttpStatus;

/**
 * Created by xieqingyang on 2018/3/22.
 * 返回话术枚举类
 */
public enum  NativeMsgErrCode implements MessageError {

    //进件管理平台以3000开始
    PARAMETERS_ERROR(3000,HttpStatus.OK, "传入参数有误或缺失。"),
    PHONE_REGISTERED(3001,HttpStatus.OK, "手机号已注册。"),
    IDCARD_REGISTERED(3002,HttpStatus.OK, "身份证号已注册。"),
    LEAVEDATE_PARAMETERS_ERROR(3003,HttpStatus.OK, "离职日期不能为空。"),
    ERROR(3004,HttpStatus.OK,"操作失败"),
    SEND_MESSAGE_ERROR(3005,HttpStatus.OK,"发送短信验证码失败"),
    NO_TEMPLATES_AVAILABLE_FOR_TIME_BEING(3006,HttpStatus.OK,"暂无可用短信模版"),
    NO_AVAILABLE_CHANNEL_MERCHANTS(3007,HttpStatus.OK,"暂无可用短信渠道商"),
    EXCEED_UPPER_LIMIT(3008,HttpStatus.OK,"获取验证码次数已超上限"),
    STATUS_CODE_USER_FAILED(3009,HttpStatus.OK,"验证码错误或验证码已失效"),
    STATUS_CODE_SYSTEM_FAILED(3010,HttpStatus.OK,"验证失败"),
    NOT_SATISFIED_RECONSIDERATION(3011,HttpStatus.OK,"此申请单不满足复议条件"),
    NO_AUTHORITY(3022,HttpStatus.OK,"缺少对应权限"),
	NO_NULL_SALARY_DAY(3033,HttpStatus.OK,"薪资发放日不能为空"),
	NO_NULL_LIVE_JOIN_OTHER(3034,HttpStatus.OK,"共同居住者其他不能为空"),
	NO_NULL_JINPO_BASE(3035,HttpStatus.OK,"社保缴纳基数不能为空"),
	NO_NULL_JINPO_MONTH(3036,HttpStatus.OK,"社保月缴存额不能为空"),
	NO_NULL_JINPO_LATELY(3045,HttpStatus.OK,"社保最近缴存时间不能为空"),
	NO_NULL_JINPO_DURATION(3046,HttpStatus.OK,"社保本单位缴存时长不能为空"),
	NO_NULL_CPF_BASE(3047,HttpStatus.OK,"公积金缴纳基数不能为空 "),
	NO_NULL_CPF_MONTH(3048,HttpStatus.OK,"公积金月缴存额不能为空 "),
	NO_NULL_CPF_LATELY(3049,HttpStatus.OK,"公积金最近缴存时间不能为空"),
	NO_NULL_CPF_DURATION(3050,HttpStatus.OK,"公积金本单位缴存时间不能为空"),
	UNIDENTIFIED_CUS(3051,HttpStatus.OK,"客户信息不存在"),
	UNIDENTIFIED_APPLY(3052,HttpStatus.OK,"申请信息不存在"),
    DEVICE_TYPE_ERROR(3037,HttpStatus.OK,"请传入正确的app系统标识"),
    IDCARD_IS_USE(3038,HttpStatus.OK,"身份证已被使用"),
    UNDER_AGE(3039,HttpStatus.OK,"您的年龄暂不符合借款资格（年龄不小于18周岁）"),
    ERROR_PASSWORD(3040,HttpStatus.OK,"密码错误"),
    NO_SERVICE(3042,HttpStatus.OK,"您当前所在城市没有开通借款服务"),
    LOAN_APPLICATION(3043,HttpStatus.OK,"已有一笔借款申请处理中"),
    NOT_REPAID(3044,HttpStatus.OK,"请还清借款后再申请"),
    IS_CLOSE(3045,HttpStatus.OK,"接口暂未开启"),
    ERROR_PASSWORD_SUANHUA(3046,HttpStatus.OK,"密码必需是6-20位数字字母组合"),
    INCOMPETENCE(3050,HttpStatus.OK,"资质不符"),
    ACCOUNTNOTREGISTERED(3051,HttpStatus.OK,"账号未注册"),
    ILLEGALITY_IDCARD(3052,HttpStatus.OK,"请传入正确格式的身份证"),
    VERIFY_UNSUCCESSFUL(3053,HttpStatus.OK,"身份证认证处理失败"),
    VERIFY_NO_PASS(3054,HttpStatus.OK,"身份证认证不通过"),
    VERIFY_NUM_GO_BEYOND(3055,HttpStatus.OK,"每日只可认证5次"),
    VERIFY_SUCCESS(3056,HttpStatus.OK,"认证通过"),

    NO_NULL_HOUSEHOST(3054,HttpStatus.OK,"房屋证明所有权人不能为空"),
    NO_NULL_HOUSESHARE(3055,HttpStatus.OK,"房屋证明共有情况不能为空"),
    NO_NULL_PURCHASEDATE(3056,HttpStatus.OK,"房屋证明购买时间不能为空"),
    NO_NULL_HOUSEADDRESSPROVINCE(3057,HttpStatus.OK,"房屋证明房产地址省不能为空"),
    NO_NULL_HOUSEADDRESSCITY(3058,HttpStatus.OK,"房屋证明房产地址市不能为空"),
    NO_NULL_HOUSEADDRESSAREA(3059,HttpStatus.OK,"房屋证明房产地址区不能为空"),
    NO_NULL_HOUSEADDRESS(3060,HttpStatus.OK,"房屋证明房产地址不能为空"),
    NO_NULL_HOUSEAREA(3061,HttpStatus.OK,"房屋证明建筑面积不能为空"),
    NO_NULL_HOUSEPURPOSE(3062,HttpStatus.OK,"房屋证明规划用途不能为空"),
    NO_NULL_MORTGAGEEXPLAIN(3063,HttpStatus.OK,"房屋证明 抵押情况不能为空"),
    NO_NULL_MORTGAGOR(3064,HttpStatus.OK,"房屋证明 抵押权人不能为空"),
    NO_NULL_MORTGAGEAMOUNT(3065,HttpStatus.OK,"房屋证明 抵押金额不能为空"),
    NO_NULL_MONTHREPAYAMOUNT(3066,HttpStatus.OK,"房屋证明 月还金额不能为空"),
    NO_NULL_OTHERHOUSE(3067,HttpStatus.OK,"房屋证明 信息不能为空"),

    NO_NULL_INSURANCEMANNAME(3068,HttpStatus.OK,"投保人姓名不能为空"),
    NO_NULL_PASSIVEINSUREMANNAME(3069,HttpStatus.OK,"被保人姓名不能为空"),
    NO_NULL_INSURANCENAME(3070,HttpStatus.OK,"投保公司名称不能为空"),
    NO_NULL_EFFECTIVEDATE(3071,HttpStatus.OK,"保险生效日期不能为空"),
    NO_NULL_PAYMENTTYPE(3072,HttpStatus.OK,"缴费频率不能为空"),
    NO_NULL_PAYMENTYEARAMOUNT(3073,HttpStatus.OK,"年交保费不能为空"),
    NO_NULL_INSURANCE(3074,HttpStatus.OK,"保单信息不能为空"),

    NO_NULL_IMAGE_PERSON(3075,HttpStatus.OK,"请先上传身份证明图片"),
    NO_NULL_IMAGE_WORK(3076,HttpStatus.OK,"请先上传工作证明图片"),
    NO_NULL_IMAGE_HOUSE(3077,HttpStatus.OK,"请先上传房产证明图片"),
    NO_NULL_IMAGE_PHONE(3078,HttpStatus.OK,"请先上传通话详单图片"),
    NO_NULL_IMAGE_BDZM(3079,HttpStatus.OK,"请先上传保单证明图片"),
    NO_NULL_IMAGE_TXZM(3080,HttpStatus.OK,"请先上传退休证明图片"),
    NO_NULL_IMAGE_GFWTP(4111,HttpStatus.OK,"请先上传工商网和人法网截图"),
    NO_NULL_REGTIME(4100,HttpStatus.OK,"开户日期不能为空"),
    NO_NULL_RELIABILITY(4101,HttpStatus.OK,"实名认证不能为空"),
    OUT_EXPECT_SALARY(4102,HttpStatus.OK,"申请金额超出范围"),
    NO_NULL_IMAGE_MINE(6200,HttpStatus.OK,"请先上传自我推荐图片"),

    NO_NULL_JINPOCOMPANY(4105,HttpStatus.OK,"社保缴纳单位不能为空"),
    NO_NULL_CPFCOMPANY(4106,HttpStatus.OK,"公积金缴纳单位不能为空"),

    NON_QUALIFIED_ACCOUNT(3081,HttpStatus.OK,"无符合条件的账户信息"),
    PAYMENT_CHANNELS_CANNOT_EMPTY(3082,HttpStatus.OK,"支付渠道不能为空"),
    PLEASE_CHOOSE_CHANNELS(3083,HttpStatus.OK,"请选择渠道"),
    NO_OPEN_ACCOUNT(3084,HttpStatus.OK,"暂无有效账户"),
    PLEASE_CHOOSE_DEPOSIT_ACCOUNT(3084,HttpStatus.OK,"请选择存管账户"),
    INOPERABLE(3085,HttpStatus.OK,"该银行卡已绑定有效合同"),
    INOPERABLE_BANK(3086,HttpStatus.OK,"无有效银行卡，请先绑定."),
    COMPLETED_AUTHORIZATION(3087,HttpStatus.OK,"已完成授权"),

    UNFINISHED_OPERATION_CHANGE_CARD(3088,HttpStatus.OK,"您当前有未完成的换卡操作，请完成后重试。"),
    UNFINISHED_OPERATION_CANCELLATION_AUTHORIZATION(3089,HttpStatus.OK,"您当前有未完成的取消授权操作，请完成后重试。"),
    UNFINISHED_OPERATION_UNTIE(3090,HttpStatus.OK,"您当前有未完成的解绑操作，请完成后重试。"),
    UNFINISHED_OPERATION(3091,HttpStatus.OK,"您当前有未完成的操作，请完成后重试。"),
    PAGE_NUM_NOT_NULL(3092,HttpStatus.OK,"页数不能为空"),
    PAGE_SIZE_NOT_NULL(3093,HttpStatus.OK,"条数不能为空"),
    NO_VALID_PHONE(3094,HttpStatus.OK,"手机号格式不正确"),
    UNMATCHED_TEMPLATE(3095,HttpStatus.OK,"未匹配到模版"),
    CURRENT_MESSAGES_CANNOT_REVOKED(3096,HttpStatus.OK,"当前消息不能撤销"),
    NO_VALID_RECOMMEND_CODE(3097,HttpStatus.OK,"推荐码已不存在或失效"),
    NO_NULL_BANKCARD(3098,HttpStatus.OK,"银行卡号不能为空"),
    NO_VALID_BANKCARD(3099,HttpStatus.OK,"当前绑定银行卡不支持，请更换其他银行卡"),
    ERROR_BANKCARD(3010,HttpStatus.OK,"银行卡号错误"),
    NO_EXISTENCE(3011,HttpStatus.OK,"银行卡信息不存在"),
    CHANGE_SUCCESS(0,HttpStatus.OK,"变更成功"),
    CHANGE_APPLICATION_HAS_BEEN_SUBMITTED(0,HttpStatus.OK,"变更申请已提交"),
    REFUSE(3012,HttpStatus.OK,"不支持换卡，请拒绝此次申请"),
    EXISTENCE_UNAUTHORIZED_CHANNELS(3013,HttpStatus.OK,"存在未授权渠道"),
    NO_VALID_OPERATION(3014,HttpStatus.OK,"该身份证与原身份证信息不一致，如需更换请联系客服人员!"),
    FILE_CHECK(3015,HttpStatus.OK,"文件内全部为非注册用户手机号，上传失败!"),
    FILE_CHECK_VALID(3016,HttpStatus.OK,""),
    ADDRESS_BOOK_UPLOADED(3017,HttpStatus.OK,"通讯录已上传"),
	NULL_CONTRACT_ID(4212,HttpStatus.OK,"合同ID为空"),
	NULL_SHOULD_ALSO_AMOUNT(4213,HttpStatus.OK,"应还金额不能为空"),
	HK_FAILD(6222,HttpStatus.OK,"划扣失败"),

    CANNOT_DEL(3053,HttpStatus.OK,"存在不可删除图片，请重新选择"),
    SYSTEM_ABNORMALITY(3990,HttpStatus.OK,"系统异常"),
    PLEASE_BANKCARD_AUTHORIZATION_FIRST(3995,HttpStatus.OK,"请先完成绑卡"),
    PLEASE_COMPLETE_AUTHORIZATION_FIRST(3996,HttpStatus.OK,"请先完成授权"),
    HAVE_SIGNED_CONTRACT(3997,HttpStatus.OK,"已签约完成"),
    PLEASE_SIGN_AGREEMENT(3998,HttpStatus.OK,"请先完成协议签署"),
    IDCARD_EXPIRED(3999,HttpStatus.OK,"身份证已过期，请使用最新身份证"),
    
    UNIDENTIFIED_IDENTITY(3999,HttpStatus.OK,"请先完成身份认证"),	
    
	UN_ORGIDS_BY_JOBCITY(3101,HttpStatus.OK,"工作城市无服务网点"),
	UN_JUXINLI_REPORT(3102,HttpStatus.OK,"请先完成聚信立运营商报告授权"),
	UN_JUXINLI_BAODAN(3103,HttpStatus.OK,"请先完成聚信立保单授权"),
	UN_RONG360_SHEBAO(3104,HttpStatus.OK,"请先完成融360社保授权"),
	UN_RONG360_GJJ(3105,HttpStatus.OK,"请先完成融360公积金授权"),
	UN_RONG360_JBRH(3106,HttpStatus.OK,"请先完成融360简版人行授权"),
	UN_SUANHUA_REPORT(3107,HttpStatus.OK,"请先完成算话人行报告授权"),
	
	OUT_EXPECT_SALARY_MIN(3108,HttpStatus.OK,"申请金额不能低于产品最低金额"),
	OUT_EXPECT_SALARY_MAX(3109,HttpStatus.OK,"申请金额不能高于产品最高金额"),
	OUT_EXPECT_SALARY_ACCREDIT_MAX(3110,HttpStatus.OK,"申请金额不能高于预授权金额"),
	
	UN_PRODUCTIDS_FOR_ORGID(3111,HttpStatus.OK,"当前营业部不支持该产品"),
	UN_PERSON_BASE_INFO(3112,HttpStatus.OK,"请先填写完成个人基本信息"),
	UN_FAMILY_CONTACT_INFO(3113,HttpStatus.OK,"请至少填写一个家庭联系人信息"),
	UN_EMERGENCY_CONTACT_INFO(3114,HttpStatus.OK,"请至少填写两个紧急联系人信息"),
	UN_WORK_CONTACT_INFO(3115,HttpStatus.OK,"请至少填写一个工作联系人信息"),
	UN_WORK_INFO(3116,HttpStatus.OK,"请先填写完成个人工作信息"),
	UN_PRIVATE_INFO(3117,HttpStatus.OK,"请先填写完成个人私营信息"),
	UN_BANK_CARD_INFO(3118,HttpStatus.OK,"请先绑定银行卡"),
	UN_BANK_CARD_CHANGE(3119,HttpStatus.OK,"银行卡申请变更中"),
	ID_CARD_OUT_TIME(3120,HttpStatus.OK,"身份证信息已过期"),
	UN_IMG_ZWTJ(3121,HttpStatus.OK,"请先上传自我推荐相关图片"),
	
	ALREADY_PHONE1(3122,HttpStatus.OK,"该手机号已添加"),
	UN_ORGIDS_BY_PRODUCT(3101,HttpStatus.OK,"当前服务网点未开放此产品");
	

    int errCode;
    HttpStatus httpCode;
    private String errMsg;

    NativeMsgErrCode(int errCode, HttpStatus httpCode, String errMsg) {
        this.errCode = errCode;
        this.httpCode = httpCode;
        this.errMsg = errMsg;
    }


    @Override
    public int getErrCode() {
        return errCode;
    }

    @Override
    public HttpStatus getHttpCode() {
        return httpCode;
    }

    @Override
    public String getErrMsg() {
        return errMsg;
    }

    static public HttpStatus getHttpCodeByErrCode(int errCode) {
        for (NativeMsgErrCode mec : NativeMsgErrCode.values()) {
            if (mec.getErrCode() == errCode) {
                return mec.getHttpCode();
            }
        }
        return null;
    }
}
