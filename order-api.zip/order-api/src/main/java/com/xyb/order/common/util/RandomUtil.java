package com.xyb.order.common.util;

import java.util.Random;

public class RandomUtil {
	/**
	 * 产生随机的六位数
	 * 
	 * @return
	 */
	public static String getSix(){
		Random rad = new Random();

		String result = rad.nextInt(1000000) + "";

		if (result.length() != 6) {
			return getSix();
		}
		return result;
	}

	/**
	 * 产生随机的八位数
	 * 
	 * @return
	 */
	public static String getEight(){
		Random rad = new Random();

		String result = rad.nextInt(100000000) + "";

		if (result.length() != 8) {
			return getEight();
		}
		return result;
	}
}
