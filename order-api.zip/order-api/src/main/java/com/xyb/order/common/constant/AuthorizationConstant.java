package com.xyb.order.common.constant;

/**
 * Created by xieqingyang on 2017/8/9.
 */
public class AuthorizationConstant {

    public static final String STATUS_CODE_SUCCESS = "200";
    public static final String CODE = "00";

    /**-------------------法大大参数---------------------------*/
    public static final String FDD_RESULT = "result";
    public static final String FDD_MSG = "msg";
    public static final String FDD_CODE = "code";
    public static final String FDD_CUSTOMER_ID = "customer_id";

    /**成功*/
    public static final String SUCCESS = "success";
    /**失败*/
    public static final String ERROR = "error";

    /**操作成功*/
    public static final String FDD_RESULT_1000 = "1000";
    /**参数缺失或者不合法*/
    public static final String FDD_RESULT_2001 = "2001";
    /**业务异常，失败原因见 msg*/
    public static final String FDD_RESULT_2002 = "2002";
    /**其他错误，请联系法大大*/
    public static final String FDD_RESULT_2003 = "2003";
    /**签章成功*/
    public static final String FDD_RESULT_3000 = "3000";

    /**合同下载地址*/
    public static final String DOWNLOAD_URL = "download_url";
    /**合同查看地址*/
    public static final String VIEWPDF_URL = "viewpdf_url";

    /**融360私钥*/
    public static final String PRIBATEKEY_RONG = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBALlmRwq2pyZ+ACx6\n" +
            "ga2yyM4Ev4a5UAznPjLQ3XrS5zRq09S3dtLaMN5CQofDU4bUf6T4JiviM+S4ds8/\n" +
            "p1ZaqC5OGrZ5akEzzyQKCp0OXQAMx1ppaJv4fKuXk2wLmx41wV//Oul8w/RCjDfy\n" +
            "l9z0yRXg/3i4LgAaeUvYoXI1jLunAgMBAAECgYEAsXNCVe/DBqWc9vV+f0lax01m\n" +
            "H8Xo56DBOJQPGIsafmItRDEhiukJ0wGqehUrMibb0YMtzdzg/G7OUMlFGfMFekNo\n" +
            "izYrIqIodS6H5ju3PSdYpgK1AdJ0up00aOeKb5xSLoU+jDA/j/Hnvuur7+g3CVSh\n" +
            "yyrP1rZJtJu/4Ife7NECQQDeXSsS5vxhGPpcKiLUhB3t+CapPos51Vxz14pYBSAo\n" +
            "53IF5rZCU4u1kszPoR/E1DLvZCPZ80xT+ROTU5CKtTLpAkEA1XGyiTjFl1itj/+M\n" +
            "ZJI0u7T7s89+Z3HYbj95hHWL4VjG/SHdfNdC7bD4XCRGQMeIw2tpQVMINuUP4aws\n" +
            "AMDADwJAT9bt/1R2a7qXMf5jESD6yhXec8gkHzjPgDx0zNPSTz2CwEGtUTVEJYa3\n" +
            "CRnWGUsDmta+1KO51TDKaYyIinUy+QJBALXJnT6D7L3nGAOhqefqIiGQliNh4I2o\n" +
            "B6Z2Rz/KgXVPEEN9eU+fYvBgHlcTygXYK6IMtFufpUpjszAIXH3TrH8CQQDIq/0n\n" +
            "93uLHo1pkpm6I4PDIwrwEPOlsnGqPVX86LsU+y1x9VOaENX6VwiQtIyPiqgUaPuf\n" +
            "HPsPXL79zmvOfDVb";

}
