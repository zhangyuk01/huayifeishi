package com.xyb.order.app.client.personinfo.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonRelationInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private PersonBaseRelationInfoDTO personBaseRelationInfoDTO;
	private List<LinkManRelationInfoDTO> familLinkManInfos;
	private List<LinkManRelationInfoDTO> workLinkManInfos;
	private List<LinkManRelationInfoDTO> urgetLinkManInfos;
	

	public PersonBaseRelationInfoDTO getPersonBaseRelationInfoDTO() {
		return personBaseRelationInfoDTO;
	}
	public void setPersonBaseRelationInfoDTO(PersonBaseRelationInfoDTO personBaseRelationInfoDTO) {
		this.personBaseRelationInfoDTO = personBaseRelationInfoDTO;
	}
	public List<LinkManRelationInfoDTO> getFamilLinkManInfos() {
		return familLinkManInfos;
	}
	public void setFamilLinkManInfos(List<LinkManRelationInfoDTO> familLinkManInfos) {
		this.familLinkManInfos = familLinkManInfos;
	}
	public List<LinkManRelationInfoDTO> getWorkLinkManInfos() {
		return workLinkManInfos;
	}
	public void setWorkLinkManInfos(List<LinkManRelationInfoDTO> workLinkManInfos) {
		this.workLinkManInfos = workLinkManInfos;
	}
	public List<LinkManRelationInfoDTO> getUrgetLinkManInfos() {
		return urgetLinkManInfos;
	}
	public void setUrgetLinkManInfos(List<LinkManRelationInfoDTO> urgetLinkManInfos) {
		this.urgetLinkManInfos = urgetLinkManInfos;
	}

	
}
