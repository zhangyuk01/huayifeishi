package com.xyb.order.pc.applybill.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillInfoVO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private ApplyBillInfoDO applyBillInfoDo; //申请单对象
	private ApplyClientInfoDO applyClientInfoDO;//客户信息
	private ApplyPersonInfoDO applyPersonInfoDo; //个人信息对象
	private ApplyJobInfoDO applyJobInfoDO;//工作信息对象
	private ApplyPrivateInfoDO applyPrivateInfoDo;//私营信息对象
	private List<ApplyLinkmanInfoDO> homeLinkList;//家庭联系人列表
	private List<ApplyLinkmanInfoDO> workLinkList;//工作联系人列表
	private List<ApplyLinkmanInfoDO> urgentLinkList;//紧急联系人列表
	private List<ApplyFamilyChildrenDO> familyChildrenList;//子女信息
	
	
	
	public List<ApplyLinkmanInfoDO> getHomeLinkList() {
		return homeLinkList;
	}
	public void setHomeLinkList(List<ApplyLinkmanInfoDO> homeLinkList) {
		this.homeLinkList = homeLinkList;
	}
	public ApplyClientInfoDO getApplyClientInfoDO() {
		return applyClientInfoDO;
	}
	public void setApplyClientInfoDO(ApplyClientInfoDO applyClientInfoDO) {
		this.applyClientInfoDO = applyClientInfoDO;
	}
	public ApplyJobInfoDO getApplyJobInfoDO() {
		return applyJobInfoDO;
	}
	public void setApplyJobInfoDO(ApplyJobInfoDO applyJobInfoDO) {
		this.applyJobInfoDO = applyJobInfoDO;
	}
	public List<ApplyLinkmanInfoDO> getWorkLinkList() {
		return workLinkList;
	}
	public void setWorkLinkList(List<ApplyLinkmanInfoDO> workLinkList) {
		this.workLinkList = workLinkList;
	}
	public List<ApplyLinkmanInfoDO> getUrgentLinkList() {
		return urgentLinkList;
	}
	public void setUrgentLinkList(List<ApplyLinkmanInfoDO> urgentLinkList) {
		this.urgentLinkList = urgentLinkList;
	}
	public ApplyPrivateInfoDO getApplyPrivateInfoDo() {
		return applyPrivateInfoDo;
	}
	public void setApplyPrivateInfoDo(ApplyPrivateInfoDO applyPrivateInfoDo) {
		this.applyPrivateInfoDo = applyPrivateInfoDo;
	}
	public ApplyBillInfoDO getApplyBillInfoDo() {
		return applyBillInfoDo;
	}
	public void setApplyBillInfoDo(ApplyBillInfoDO applyBillInfoDo) {
		this.applyBillInfoDo = applyBillInfoDo;
	}
	public ApplyPersonInfoDO getApplyPersonInfoDo() {
		return applyPersonInfoDo;
	}
	public void setApplyPersonInfoDo(ApplyPersonInfoDO applyPersonInfoDo) {
		this.applyPersonInfoDo = applyPersonInfoDo;
	}
	public List<ApplyFamilyChildrenDO> getFamilyChildrenList() {
		return familyChildrenList;
	}
	public void setFamilyChildrenList(List<ApplyFamilyChildrenDO> familyChildrenList) {
		this.familyChildrenList = familyChildrenList;
	}
}
