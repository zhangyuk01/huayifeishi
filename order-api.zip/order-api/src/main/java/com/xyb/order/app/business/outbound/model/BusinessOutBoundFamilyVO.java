package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 家庭信息VO
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundFamilyVO implements IBaseModel {

	private static final long serialVersionUID = -3989576933472108073L;

	private Long id;
	/**申请id*/
    private Long visitMainId;
    /**家庭地址是否一致(大类2692)*/
    private Long isFamilyAddressSame;
    /**外放前家庭地址*/
    private String familyAllAddrOld;
    /**外放后家庭地址*/
    private String familyAllAddr;
    /**家庭省*/
    private Long familyAddrProvince;

	private String familyAddrProvinceStr;
    /**家庭市*/
    private Long familyAddrCity;

	private String familyAddrCityStr;
    /**家庭区*/
    private Long familyAddrArea;

	private String familyAddrAreaStr;
    /**家庭地址街道门牌详细信息*/
    private String familyAddrDetail;
    /**家庭电话是否一致(大类2692)*/
    private Long isFamilyTellSame;
    /**是否有家庭固话（大类2692）*/
    private Long haveFamilyTell;
	/**外访前家庭固话区号*/
	private String familyTellAreaOld;
    /**外访前家庭固话号码*/
    private String familyTellOld;
	/**外访后家庭固话区号*/
	private String familyTellArea;
    /**外访后家庭固话号码*/
    private String familyTell;
    /**房屋类型（大类2533）*/
    private Long houseType;

	private String houseTypeStr;
    /**现住址居住时间（大类2646*/
    private Long houseTime;
    /**房屋权属（大类2636）*/
    private Long houseOwnershipType;

	private String houseOwnershipTypeStr;
    /**房屋市值(大类2638)*/
    private Long houseMarketValue;
    /**房屋权属类型是其他时备注*/
    private String houseOwnershipTypeRemark;
    /**装修风格（大类2722）*/
    private Long houseRedecoratedStyle;

	private String houseRedecoratedStyleStr;
    /**共同居住者，多选类型英文逗号隔开(大类2645)*/
    private String coResident;
    /**共同居住情况备注*/
    private String coResidentRemark;
    /**居住痕迹(大类2805)*/
    private String residentialTraces;
    /**备注*/
    private String remark;
    /**是否有效（大类2692）*/
    private Integer isValid;
    /**用来相同模块排序（同时插入时间区分不了显示位置）*/
    private Integer sort;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public Long getIsFamilyAddressSame() {
		return isFamilyAddressSame;
	}

	public void setIsFamilyAddressSame(Long isFamilyAddressSame) {
		this.isFamilyAddressSame = isFamilyAddressSame;
	}

	public String getFamilyAllAddrOld() {
		return familyAllAddrOld;
	}

	public void setFamilyAllAddrOld(String familyAllAddrOld) {
		this.familyAllAddrOld = familyAllAddrOld;
	}

	public String getFamilyAllAddr() {
		return familyAllAddr;
	}

	public void setFamilyAllAddr(String familyAllAddr) {
		this.familyAllAddr = familyAllAddr;
	}

	public Long getFamilyAddrProvince() {
		return familyAddrProvince;
	}

	public void setFamilyAddrProvince(Long familyAddrProvince) {
		this.familyAddrProvince = familyAddrProvince;
	}

	public Long getFamilyAddrCity() {
		return familyAddrCity;
	}

	public void setFamilyAddrCity(Long familyAddrCity) {
		this.familyAddrCity = familyAddrCity;
	}

	public Long getFamilyAddrArea() {
		return familyAddrArea;
	}

	public void setFamilyAddrArea(Long familyAddrArea) {
		this.familyAddrArea = familyAddrArea;
	}

	public String getFamilyAddrDetail() {
		return familyAddrDetail;
	}

	public void setFamilyAddrDetail(String familyAddrDetail) {
		this.familyAddrDetail = familyAddrDetail;
	}

	public Long getIsFamilyTellSame() {
		return isFamilyTellSame;
	}

	public void setIsFamilyTellSame(Long isFamilyTellSame) {
		this.isFamilyTellSame = isFamilyTellSame;
	}

	public Long getHaveFamilyTell() {
		return haveFamilyTell;
	}

	public void setHaveFamilyTell(Long haveFamilyTell) {
		this.haveFamilyTell = haveFamilyTell;
	}

	public String getFamilyTellOld() {
		return familyTellOld;
	}

	public void setFamilyTellOld(String familyTellOld) {
		this.familyTellOld = familyTellOld;
	}

	public String getFamilyTell() {
		return familyTell;
	}

	public void setFamilyTell(String familyTell) {
		this.familyTell = familyTell;
	}

	public Long getHouseType() {
		return houseType;
	}

	public void setHouseType(Long houseType) {
		this.houseType = houseType;
	}

	public Long getHouseTime() {
		return houseTime;
	}

	public void setHouseTime(Long houseTime) {
		this.houseTime = houseTime;
	}

	public Long getHouseOwnershipType() {
		return houseOwnershipType;
	}

	public void setHouseOwnershipType(Long houseOwnershipType) {
		this.houseOwnershipType = houseOwnershipType;
	}

	public Long getHouseMarketValue() {
		return houseMarketValue;
	}

	public void setHouseMarketValue(Long houseMarketValue) {
		this.houseMarketValue = houseMarketValue;
	}

	public String getHouseOwnershipTypeRemark() {
		return houseOwnershipTypeRemark;
	}

	public void setHouseOwnershipTypeRemark(String houseOwnershipTypeRemark) {
		this.houseOwnershipTypeRemark = houseOwnershipTypeRemark;
	}

	public Long getHouseRedecoratedStyle() {
		return houseRedecoratedStyle;
	}

	public void setHouseRedecoratedStyle(Long houseRedecoratedStyle) {
		this.houseRedecoratedStyle = houseRedecoratedStyle;
	}

	public String getCoResident() {
		return coResident;
	}

	public void setCoResident(String coResident) {
		this.coResident = coResident;
	}

	public String getCoResidentRemark() {
		return coResidentRemark;
	}

	public void setCoResidentRemark(String coResidentRemark) {
		this.coResidentRemark = coResidentRemark;
	}

	public String getResidentialTraces() {
		return residentialTraces;
	}

	public void setResidentialTraces(String residentialTraces) {
		this.residentialTraces = residentialTraces;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getFamilyAddrProvinceStr() {
		return familyAddrProvinceStr;
	}

	public void setFamilyAddrProvinceStr(String familyAddrProvinceStr) {
		this.familyAddrProvinceStr = familyAddrProvinceStr;
	}

	public String getFamilyAddrCityStr() {
		return familyAddrCityStr;
	}

	public void setFamilyAddrCityStr(String familyAddrCityStr) {
		this.familyAddrCityStr = familyAddrCityStr;
	}

	public String getFamilyAddrAreaStr() {
		return familyAddrAreaStr;
	}

	public void setFamilyAddrAreaStr(String familyAddrAreaStr) {
		this.familyAddrAreaStr = familyAddrAreaStr;
	}

	public String getHouseTypeStr() {
		return houseTypeStr;
	}

	public void setHouseTypeStr(String houseTypeStr) {
		this.houseTypeStr = houseTypeStr;
	}

	public String getHouseOwnershipTypeStr() {
		return houseOwnershipTypeStr;
	}

	public void setHouseOwnershipTypeStr(String houseOwnershipTypeStr) {
		this.houseOwnershipTypeStr = houseOwnershipTypeStr;
	}

	public String getHouseRedecoratedStyleStr() {
		return houseRedecoratedStyleStr;
	}

	public void setHouseRedecoratedStyleStr(String houseRedecoratedStyleStr) {
		this.houseRedecoratedStyleStr = houseRedecoratedStyleStr;
	}

	public String getFamilyTellAreaOld() {
		return familyTellAreaOld;
	}

	public void setFamilyTellAreaOld(String familyTellAreaOld) {
		this.familyTellAreaOld = familyTellAreaOld;
	}

	public String getFamilyTellArea() {
		return familyTellArea;
	}

	public void setFamilyTellArea(String familyTellArea) {
		this.familyTellArea = familyTellArea;
	}

	@Override
	public String toString() {
		return "BusinessOutBoundFamilyVO{" +
				"id=" + id +
				", visitMainId=" + visitMainId +
				", isFamilyAddressSame=" + isFamilyAddressSame +
				", familyAllAddrOld='" + familyAllAddrOld + '\'' +
				", familyAllAddr='" + familyAllAddr + '\'' +
				", familyAddrProvince=" + familyAddrProvince +
				", familyAddrProvinceStr='" + familyAddrProvinceStr + '\'' +
				", familyAddrCity=" + familyAddrCity +
				", familyAddrCityStr='" + familyAddrCityStr + '\'' +
				", familyAddrArea=" + familyAddrArea +
				", familyAddrAreaStr='" + familyAddrAreaStr + '\'' +
				", familyAddrDetail='" + familyAddrDetail + '\'' +
				", isFamilyTellSame=" + isFamilyTellSame +
				", haveFamilyTell=" + haveFamilyTell +
				", familyTellAreaOld='" + familyTellAreaOld + '\'' +
				", familyTellOld='" + familyTellOld + '\'' +
				", familyTellArea='" + familyTellArea + '\'' +
				", familyTell='" + familyTell + '\'' +
				", houseType=" + houseType +
				", houseTypeStr='" + houseTypeStr + '\'' +
				", houseTime=" + houseTime +
				", houseOwnershipType=" + houseOwnershipType +
				", houseOwnershipTypeStr='" + houseOwnershipTypeStr + '\'' +
				", houseMarketValue=" + houseMarketValue +
				", houseOwnershipTypeRemark='" + houseOwnershipTypeRemark + '\'' +
				", houseRedecoratedStyle=" + houseRedecoratedStyle +
				", houseRedecoratedStyleStr='" + houseRedecoratedStyleStr + '\'' +
				", coResident='" + coResident + '\'' +
				", coResidentRemark='" + coResidentRemark + '\'' +
				", residentialTraces='" + residentialTraces + '\'' +
				", remark='" + remark + '\'' +
				", isValid=" + isValid +
				", sort=" + sort +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				'}';
	}
}