package com.xyb.order.pc.annotation;

import java.lang.annotation.*;

/**
 * @author : jiangzhongyan
 * @projectName : finance-api
 * @package : com.xyb.annotation
 * @description : 验签自定义注解
 * @createDate : 2017/12/16 13:18
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Inherited
@Documented
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SignField {

    /**
     * 字段名称
     * @return
     */
    String name() default "";

    /**
     * 字段描述
     * @return
     */
    String description() default "";

    /**
     * 排序字段
     * @return
     */
    int order() default 0;
}
