package com.xyb.order.app.client.apply.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.apply.model.ApplyDTO;

/**
*  C端客户申请信息
* @author         xieqingyang
* @date           2018/5/12 下午5:13
*/
public interface ApplyService {

    /**
     * 提交借款信息
     * @author      xieqingyang
     * @date        2018/5/12 1:57 PM
     * @version     1.0
     * @param applyDTO 待提交信息
     * @return 操作结果
     * @throws Exception 所有异常
     */
    RestResponse insertApplyInfo(ApplyDTO applyDTO) throws Exception;
}
