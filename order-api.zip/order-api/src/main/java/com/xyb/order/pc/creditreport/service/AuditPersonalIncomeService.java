package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditAllPersonalIncomeDTO;
import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDO;

/**
 * @ClassName AuditPersonalIncomeService
 * @author ZhangYu
 * @date 2018年4月23号
 */
public interface AuditPersonalIncomeService {

	/**
	 * 根据申请单ID查询个人收入证明 
	 * @param applyId
	 * @return
	 */
	 RestResponse queryInfoByApplyId(Long applyId)throws Exception;
	
	 /**
	  * 暂存个人收入证明 
	  * @param auditAllPersonalIncomeDTO
	  * @return
	  */
	 RestResponse updateOrAddInfoByApplyId(AuditAllPersonalIncomeDTO auditAllPersonalIncomeDTO)throws Exception;
	
	 /**
	  * 根据ID查询个人收入证明 
	  * @param id
	  * @return
	  */
	 AuditPersonalIncomeDO queryInfoById(Long id)throws Exception;
	
	 /**
	  * 根据ID修改删除标记状态 
	  * @param id
	  * @return
	  */
	 RestResponse updateDelFlagById(Long id)throws Exception;
	

}
