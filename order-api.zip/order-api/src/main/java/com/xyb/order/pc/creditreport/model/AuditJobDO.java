package com.xyb.order.pc.creditreport.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditJobDO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long cusId;
	private Long applyId;
	private String compName;//单位名称
	private String compDept;//所在部门
	private Long compDuty;//职务
	private String compDutyStr;//职务描述
	private Date compJoinDate;//入职日期
	private BigDecimal monthMoney;//月收入 

	private String jinpoComp;//社保缴纳单位
	private BigDecimal jinpoBase;//社保缴纳基数
	private BigDecimal jinpoMonth;//社保月缴数
	private Date jinpoLately; //社保最早缴存日期
	private Integer jinpoDuration;//社保本单位缴纳时长 

	private String cpfComp;//公积金缴纳单位  
	private BigDecimal cpfBase;//公积金缴纳基数
	private BigDecimal cpfMonth;//公积金月缴数
	private Date cpfLately;//公积金最近缴存日期
	private Integer cpfDuration; //公积金本单位缴存时长

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public String getCompDept() {
		return compDept;
	}

	public void setCompDept(String compDept) {
		this.compDept = compDept;
	}

	public Long getCompDuty() {
		return compDuty;
	}

	public void setCompDuty(Long compDuty) {
		this.compDuty = compDuty;
	}

	public String getCompDutyStr() {
		return compDutyStr;
	}

	public void setCompDutyStr(String compDutyStr) {
		this.compDutyStr = compDutyStr;
	}

	public Date getCompJoinDate() {
		return compJoinDate;
	}

	public void setCompJoinDate(Date compJoinDate) {
		this.compJoinDate = compJoinDate;
	}

	public BigDecimal getMonthMoney() {
		return monthMoney;
	}

	public void setMonthMoney(BigDecimal monthMoney) {
		this.monthMoney = monthMoney;
	}

	public String getJinpoComp() {
		return jinpoComp;
	}

	public void setJinpoComp(String jinpoComp) {
		this.jinpoComp = jinpoComp;
	}

	public BigDecimal getJinpoBase() {
		return jinpoBase;
	}

	public void setJinpoBase(BigDecimal jinpoBase) {
		this.jinpoBase = jinpoBase;
	}

	public BigDecimal getJinpoMonth() {
		return jinpoMonth;
	}

	public void setJinpoMonth(BigDecimal jinpoMonth) {
		this.jinpoMonth = jinpoMonth;
	}

	public Date getJinpoLately() {
		return jinpoLately;
	}

	public void setJinpoLately(Date jinpoLately) {
		this.jinpoLately = jinpoLately;
	}

	public Integer getJinpoDuration() {
		return jinpoDuration;
	}

	public void setJinpoDuration(Integer jinpoDuration) {
		this.jinpoDuration = jinpoDuration;
	}

	public String getCpfComp() {
		return cpfComp;
	}

	public void setCpfComp(String cpfComp) {
		this.cpfComp = cpfComp;
	}

	public BigDecimal getCpfBase() {
		return cpfBase;
	}

	public void setCpfBase(BigDecimal cpfBase) {
		this.cpfBase = cpfBase;
	}

	public BigDecimal getCpfMonth() {
		return cpfMonth;
	}

	public void setCpfMonth(BigDecimal cpfMonth) {
		this.cpfMonth = cpfMonth;
	}

	public Date getCpfLately() {
		return cpfLately;
	}

	public void setCpfLately(Date cpfLately) {
		this.cpfLately = cpfLately;
	}

	public Integer getCpfDuration() {
		return cpfDuration;
	}

	public void setCpfDuration(Integer cpfDuration) {
		this.cpfDuration = cpfDuration;
	}

	@Override
	public String toString() {
		return "AuditJobDO{" +
				"id=" + id +
				", cusId=" + cusId +
				", applyId=" + applyId +
				", compName='" + compName + '\'' +
				", compDept='" + compDept + '\'' +
				", compDuty=" + compDuty +
				", compDutyStr='" + compDutyStr + '\'' +
				", compJoinDate=" + compJoinDate +
				", monthMoney=" + monthMoney +
				", jinpoComp='" + jinpoComp + '\'' +
				", jinpoBase=" + jinpoBase +
				", jinpoMonth=" + jinpoMonth +
				", jinpoLately=" + jinpoLately +
				", jinpoDuration=" + jinpoDuration +
				", cpfComp='" + cpfComp + '\'' +
				", cpfBase=" + cpfBase +
				", cpfMonth=" + cpfMonth +
				", cpfLately=" + cpfLately +
				", cpfDuration=" + cpfDuration +
				'}';
	}
}
