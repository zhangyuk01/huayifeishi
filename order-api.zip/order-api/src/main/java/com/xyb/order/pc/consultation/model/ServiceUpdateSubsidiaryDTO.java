package com.xyb.order.pc.consultation.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * Created by xieqingyang on 2018/4/19.
 * 更改申请单客服人员附属类
 */
public class ServiceUpdateSubsidiaryDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    @NotNull(message = "主表ID不能为空")
    private Long mainId;// -- 主表ID
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;// -- 申请表ID
    @NotEmpty(message = "申请编号不能为空")
    private String applyNum;// -- 申请编号
    private Long oldServiceUid;// -- 原客服人员id
    private String oldServiceName;// -- 原客服人员名称

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public Long getOldServiceUid() {
        return oldServiceUid;
    }

    public void setOldServiceUid(Long oldServiceUid) {
        this.oldServiceUid = oldServiceUid;
    }

    public String getOldServiceName() {
        return oldServiceName;
    }

    public void setOldServiceName(String oldServiceName) {
        this.oldServiceName = oldServiceName;
    }
}
