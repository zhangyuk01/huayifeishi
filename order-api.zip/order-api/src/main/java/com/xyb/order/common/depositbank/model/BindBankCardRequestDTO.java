package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 绑卡网关接口推送深圳数据model
 * @author         xieqingyang
 * @date           2018/11/23 11:10 PM
 */
public class BindBankCardRequestDTO implements IBaseModel{
    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**系统ID 北京2001 深圳3001*/
    private Long sysId;
    /**
     * 绑定卡类型，必填，0：主卡 1：副卡 2：已注销，1(位数)
     */
    @SignField(order = 0)
    private String card_type;
    /**
     * 电子账户，开户返回的电子账户，必填，19(位数)
     */
    @SignField(order = 1)
    private String card_no;
    /**
     * 忘记密码链接，选填，256(位数)
     */
    private String forget_pwd_url;
    /**
     * 成功跳转地址，成功地址，必填，256(位数)
     */
    @SignField(order = 2)
    private String success_url;
    /**
     * 失败跳转地址，失败跳转地址，必填，256(位数)
     */
    @SignField(order = 3)
    private String fail_url;
    /**
     * 交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面
     */
    private String client;
    /**
     * 商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户
     */
    private String custom;
    /**
     * 客户端ip
     */
    private String client_ip;
    /**
     * 电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）
     */
    private String client_service;

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getForget_pwd_url() {
        return forget_pwd_url;
    }

    public void setForget_pwd_url(String forget_pwd_url) {
        this.forget_pwd_url = forget_pwd_url;
    }

    public String getSuccess_url() {
        return success_url;
    }

    public void setSuccess_url(String success_url) {
        this.success_url = success_url;
    }

    public String getFail_url() {
        return fail_url;
    }

    public void setFail_url(String fail_url) {
        this.fail_url = fail_url;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }

    public String getClient_ip() {
        return client_ip;
    }

    public void setClient_ip(String client_ip) {
        this.client_ip = client_ip;
    }

    public String getClient_service() {
        return client_service;
    }

    public void setClient_service(String client_service) {
        this.client_service = client_service;
    }

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BindBankCardRequestDTO that = (BindBankCardRequestDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(card_type, that.card_type) &&
                Objects.equals(card_no, that.card_no) &&
                Objects.equals(forget_pwd_url, that.forget_pwd_url) &&
                Objects.equals(success_url, that.success_url) &&
                Objects.equals(fail_url, that.fail_url) &&
                Objects.equals(client, that.client) &&
                Objects.equals(custom, that.custom) &&
                Objects.equals(client_ip, that.client_ip) &&
                Objects.equals(client_service, that.client_service);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, card_type, card_no, forget_pwd_url, success_url, fail_url, client, custom, client_ip, client_service);
    }

    @Override
    public String toString() {
        return "BindBankCardRequestDTO{" +
                "sysId=" + sysId +
                ", card_type='" + card_type + '\'' +
                ", card_no='" + card_no + '\'' +
                ", forget_pwd_url='" + forget_pwd_url + '\'' +
                ", success_url='" + success_url + '\'' +
                ", fail_url='" + fail_url + '\'' +
                ", client='" + client + '\'' +
                ", custom='" + custom + '\'' +
                ", client_ip='" + client_ip + '\'' +
                ", client_service='" + client_service + '\'' +
                '}';
    }
}
