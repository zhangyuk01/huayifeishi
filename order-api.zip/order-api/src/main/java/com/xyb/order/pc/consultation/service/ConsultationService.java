package com.xyb.order.pc.consultation.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.consultation.model.ConsultationDTO;
import com.xyb.order.pc.consultation.model.ServiceUpdateDTO;

/**
 * 咨询管理接口
 * @author         xieqingyang
 * @date           2018/3/22 11:40 AM
*/
public interface ConsultationService {

    /**
     * 查询咨询列表
     * @param pageNumber 分页参数
     * @param pageSize 分页参数
     * @param consultationDTO 查询条件
     * @return 返回页面列表展示数据
     */
    RestResponse listConsultationPage(Integer pageNumber, Integer pageSize, ConsultationDTO consultationDTO)throws Exception;

    /**
     * 查询咨询详细信息
     * @param applyNum 咨询申请编号
     * @return 返回咨询详情信息
     */
    RestResponse getConsultationInFo(String applyNum,Long applyId)throws Exception;


    /**
     * 营业部咨询自动分配开关
     * @param state 当前状态
     * @return 返回更改状态结果
     */
    RestResponse sortingSwitch(String state)throws Exception;

    /**
     * 更改申请单客服人员
     * @param serviceUpdateDTO 待修改信息
     * @return 返回操作结果
     */
    RestResponse updateConsultService(ServiceUpdateDTO serviceUpdateDTO)throws Exception;

    /**
     * 查询当前营业部的自动分件状态
     * @author      xieqingyang
     * @date 2018/6/14 下午2:55
     * @version     1.0
     * @return         开启或关闭
     * @throws Exception 所有异常
     */
    RestResponse getSwitchState()throws Exception;
}
