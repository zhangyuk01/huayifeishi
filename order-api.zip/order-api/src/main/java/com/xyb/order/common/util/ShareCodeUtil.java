package com.xyb.order.common.util;


/**
* @description:    销售人员推荐码生成
* @author:         xieqingyang
* @createDate:     2018/5/11 下午2:22
*/
public class ShareCodeUtil {

    /**
    * 销售人员推荐码生成
    * @author      xieqingyang
    * @param len
    * @return      String
    * @exception
    * @date        2018/5/11 下午2:23
    */
    public static String generateRandomStr(int len) {
        //字符源，可以根据需要删减
        String generateSource = "23456789ABCDEFGHGKLMNPQRSTUVWXYZ";//去掉1和i ，0和o
        String rtnStr = "";
        for (int i = 0; i < len; i++) {
            //循环随机获得当次字符，并移走选出的字符
            String nowStr = String.valueOf(generateSource.charAt((int) Math.floor(Math.random() * generateSource.length())));
            rtnStr += nowStr;
            generateSource = generateSource.replaceAll(nowStr, "");
        }
        return rtnStr;
    }
}
