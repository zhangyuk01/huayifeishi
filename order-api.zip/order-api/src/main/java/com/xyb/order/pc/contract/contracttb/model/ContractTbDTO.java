package com.xyb.order.pc.contract.contracttb.model;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : finance-api
 * @package : com.xyb.loan.http.api.model
 * @description : 合同推标数据对象封装
 * @createDate : 2017/12/19 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ContractTbDTO implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 619868130716991918L;
	
	private ContractTbBodyDTO body;

	/**验签字符串，根据加签字段生成*/
	private String sign;

	public ContractTbBodyDTO getBody() {
		return body;
	}

	public void setBody(ContractTbBodyDTO body) {
		this.body = body;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	@Override
	public String toString() {
		return "ContractTbDTO [body=" + body + ", sign=" + sign + "]";
	}
	

}
