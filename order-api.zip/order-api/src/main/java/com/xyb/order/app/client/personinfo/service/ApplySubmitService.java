/**
 * 
 */
package com.xyb.order.app.client.personinfo.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.app.client.personinfo.service
 * @description : TODO
 * @createDate : 2018年9月19日 下午3:01:49
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplySubmitService {
	
	/**
	 * 确认借款提交 
	 * @return
	 */
	RestResponse confirmSubmit(ApplySubmitDTO applySubmitDTO);
	
	/**
	 * 提交申请
	 * @return
	 */
	RestResponse applySubmit();
	
}
