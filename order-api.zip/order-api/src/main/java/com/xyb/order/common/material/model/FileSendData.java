package com.xyb.order.common.material.model;

import org.fusesource.hawtbuf.ByteArrayInputStream;

import com.beiming.kun.framework.model.IBaseModel;

public class FileSendData implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private ByteArrayInputStream  inputStream;
	private Long applyId;
	private String fileCode;

	public ByteArrayInputStream getInputStream() {
		return inputStream;
	}
	public void setInputStream(ByteArrayInputStream inputStream) {
		this.inputStream = inputStream;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getFileCode() {
		return fileCode;
	}
	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}
	
	
	


}
