package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordProcessDO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	/**申请单ID*/
	private Long applyId;
	/**主表ID*/
	private Long mainId;
	/**金额*/
	private BigDecimal recordProcessMoney;
	/**期数*/
	private Integer recoreProcessLimit;
	/**费率*/
	private String productProportion;
	 /**显示状态名称*/
    private String stateName = "";
    /**产品名称*/
    private String productName;
   
    
   
    /**申请中申请单状态集合*/
    private List<ApplyRecordLogStateDO> applyRecordLogStateDOs;


	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	
	public Integer getRecoreProcessLimit() {
		return recoreProcessLimit;
	}
	public void setRecoreProcessLimit(Integer recoreProcessLimit) {
		this.recoreProcessLimit = recoreProcessLimit;
	}
	
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public List<ApplyRecordLogStateDO> getApplyRecordLogStateDOs() {
		return applyRecordLogStateDOs;
	}
	public void setApplyRecordLogStateDOs(List<ApplyRecordLogStateDO> applyRecordLogStateDOs) {
		this.applyRecordLogStateDOs = applyRecordLogStateDOs;
	}
	public BigDecimal getRecordProcessMoney() {
		return recordProcessMoney;
	}
	public void setRecordProcessMoney(BigDecimal recordProcessMoney) {
		this.recordProcessMoney = recordProcessMoney;
	}
	public String getProductProportion() {
		return productProportion;
	}
	public void setProductProportion(String productProportion) {
		this.productProportion = productProportion;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
}
