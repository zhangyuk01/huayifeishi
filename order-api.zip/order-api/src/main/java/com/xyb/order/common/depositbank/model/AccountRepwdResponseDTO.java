package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 重置电子账户交易密码响应参数
 * @author         xieqingyang
 * @date           2018/11/26 10:47 AM
*/
public class AccountRepwdResponseDTO implements IBaseModel {

    private static final long serialVersionUID = 5690194559589278047L;
    /**系统ID 北京2001 深圳3001*/
    @SignField(order = 2)
    private Long sysId;
    /**申请流水号，用于交易的唯一性标识，32(位数)*/
    @SignField(order = 3)
    private String out_serial_no;
    /**订单号*/
    @SignField(order = 4)
    private String order_id;
    /**页面跳转url*/
    @SignField(order = 5)
    private String url;


    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountRepwdResponseDTO that = (AccountRepwdResponseDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(out_serial_no, that.out_serial_no) &&
                Objects.equals(order_id, that.order_id) &&
                Objects.equals(url, that.url);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, out_serial_no, order_id, url);
    }

    @Override
    public String toString() {
        return "AccountRepwdResponseDTO{" +
                "sysId=" + sysId +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", order_id='" + order_id + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
