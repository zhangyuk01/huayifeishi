package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    用户银行卡信息换卡申请表
 * @author:         xieqingyang
 * @createDate:     2018/7/20 上午11:38
*/
public class ChangeBankApplyDO implements IBaseModel {

    private static final long serialVersionUID = -8163231366970167311L;
    /**主键ID*/
    private Long id;
    /**用户信息表ID*/
    private Long clientId;
    /**用户银行卡信息表ID*/
    private Long bankInfoId;
    /**银行卡号*/
    private String bankNum;
    /**银行预留手机号*/
    private String phone;
    /**t_xyb_bank_code的bank_type*/
    private Integer bankId;
    /**状态*/
    private Long state;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getBankInfoId() {
        return bankInfoId;
    }

    public void setBankInfoId(Long bankInfoId) {
        this.bankInfoId = bankInfoId;
    }

    public String getBankNum() {
        return bankNum;
    }

    public void setBankNum(String bankNum) {
        this.bankNum = bankNum;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getBankId() {
        return bankId;
    }

    public void setBankId(Integer bankId) {
        this.bankId = bankId;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "ChangeBankApplyDO{" +
                "id=" + id +
                ", clientId=" + clientId +
                ", bankInfoId=" + bankInfoId +
                ", bankNum='" + bankNum + '\'' +
                ", phone='" + phone + '\'' +
                ", bankId=" + bankId +
                ", state=" + state +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
