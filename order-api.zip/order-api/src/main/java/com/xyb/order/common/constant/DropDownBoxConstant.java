package com.xyb.order.common.constant;


/**
 * Created by xieqingyang on 2018/4/18.
 * 下拉框类型
 */
public class DropDownBoxConstant {

    /**省*/
    public static final String PROVINCE = "province";
    /**市*/
    public static final String CITY = "city";
    /**区县*/
    public static final String AREA = "area";
    /**查询当前登录人下满足机构类型的所属机构 数据查看权限*/
    public static final String SUBORDINAT_ORG = "subordinatOrg";
    /**查询当前登录人下满足机构类型的所属机构 机构*/
    public static final String SUBORDINAT = "subordinat";
    /**查询所有 大区/进件机构 根据机构类型*/
    public static final String LARGE_AREA = "largeArea";
    /**查询下属机构*/
    public static final String SUBORDINATES = "subordinates";
    /**查询上级机构*/
    public static final String SUPERIOR = "superior";
    /**根据当前登录人查询下属人员 数据查看权限*/
    public static final String PERSONNEL_BY_ORG = "personnelOrg";
    /**根据当前登录人查询下属人员 机构*/
    public static final String PERSONNEL_BY_USER = "personnel";
    /**根据传入机构ID查询对应的人员*/
    public static final String ENQUIRY_BY_INSTITUTION = "enquiryByInstitution";
    /**查询所有人员*/
    public static final String PERSONNEL_ALL = "personnelALL";
    /**产品(根据营业部查询)*/
    public static final String PRODUCT = "product";
    /**产品*/
    public static final String PRODUCT_ALL = "productAll";
    /**速贷产品*/
    public static final String QUICK_LOAN_PRODUCT_ALL = "quickLoanproductAll";
    /**民族*/
    public static final String NATION = "nation";
    /**所有产品期数*/
    public static final String PRODUCT_LIMIT = "productLimit";
    /**产品期数根据营业部*/
    public static final String PRODUCT_LIMIT_BY_ORG = "productLimitOrg";
    /**从拒贷码*/
    public static final String SUBM_RESON = "submReson";
    /**节点状态（所有）*/
    public static final String STATE_ALL = "stateAll";
    /**风险提报当前状态*/
    public static final String RISK_SUBMIT_STATE = "riskSubmitState";
    /**已办申请状态*/
    public static final String HAVE_DONE_APPLY_STATE = "haveDoneApplyState";
    /**外访状态*/
    public static final String VISIT_STATE = "visitState";
    /**合同废除当前状态*/
    public static final String CONTRACT_ABOLISH_STATE = "contractAbolishState";
    /**区域综合查询状态*/
    public static final String COMPREHENSIVE_QUERY = "comprehensiveQuery";
    /**全量进程表*/
    public static final String FULL_SCALE_PROCESS_TABLE = "fullScaleProcessTable";
    /**综合查询状态*/
    public static final String COMPREHENSIVE_ALL_QUERY = "comprehensiveAllQuery"; 
    /**复议次数*/
    public static final String RECONSIDERATION_QTY = "reconsiderationQty";
    /**银行类型*/
    public static final String BANK_CATEGORY = "BANK_CATEGORY";
    /**全量进程表查询拒贷码 不处理D3 D4类*/
    public static final String SUBM_RESON_FULL_SCALE_PROCESS_TABLE = "submResonFullScaleProcessTable";
    /**综合查询查询拒贷码 处理D3 D4类*/
    public static final String SUBM_RESON_COMPREHENSIVE_ALL_QUERY = "submResonComprehensiveAllQuery";
    /**合同审核当前状态*/
    public static final String CONTRACT_AUDIT_STATE = "contractAuditState";
    /**合同状态*/
    public static final String CONTRACT_STATE = "contractState";
    /**岗位职务*/
    public static final String COMP_DUTY = "compDuty";
    /**速贷综合查询状态*/
    public static final String QUICK_LOAN_STATE = "quickLoanState";
}
