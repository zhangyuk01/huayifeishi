package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.model
 * @description :
 * @createDate : 2018/6/13 14:39
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundListVO implements IBaseModel{

    private static final long serialVersionUID = 5237744056419179817L;

    private String clientName;

    private String applyNum;

    private String status;

    private String visitType;

    private Long  visitMainId;

    private Long  applyMainId;

    private Long  applyId;

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public Long getVisitMainId() {
        return visitMainId;
    }

    public void setVisitMainId(Long visitMainId) {
        this.visitMainId = visitMainId;
    }

    public Long getApplyMainId() {
        return applyMainId;
    }

    public void setApplyMainId(Long applyMainId) {
        this.applyMainId = applyMainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    @Override
    public String toString() {
        return "BusinessOutBoundListVO{" +
                "clientName='" + clientName + '\'' +
                ", applyNum='" + applyNum + '\'' +
                ", status='" + status + '\'' +
                ", visitType='" + visitType + '\'' +
                ", visitMainId=" + visitMainId +
                ", applyMainId=" + applyMainId +
                ", applyId=" + applyId +
                '}';
    }
}
