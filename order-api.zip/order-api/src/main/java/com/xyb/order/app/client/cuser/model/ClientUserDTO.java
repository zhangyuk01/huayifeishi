package com.xyb.order.app.client.cuser.model;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description: 用户注册
 * @author: xieqingyang
 * @createDate: 2018/5/9 下午2:41
 */
public class ClientUserDTO implements IBaseModel {

	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "手机号不能为空")
	private String phone;// -- 手机号
	@NotEmpty(message = "短信验证码不能为空")
	private String msgCode;// -- 短信验证码
	@NotEmpty(message = "密码不能为空")
	private String password;// -- 密码

	private String recommendPhone;// 推荐人手机号

	private String recommendId;// 推荐人Id

	public String getRecommendId() {
		return recommendId;
	}

	public void setRecommendId(String recommendId) {
		this.recommendId = recommendId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRecommendPhone() {
		return recommendPhone;
	}

	public void setRecommendPhone(String recommendPhone) {
		this.recommendPhone = recommendPhone;
	}

	@Override
	public String toString() {
		return "ClientUserDTO [phone=" + phone + ", msgCode=" + msgCode + ", password=" + password + ", recommendPhone="
				+ recommendPhone + ", recommendId=" + recommendId + "]";
	}
}
