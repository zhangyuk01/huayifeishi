package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.List;

/**
* @description:    算话认证传入参数
* @author:         xieqingyang
* @createDate:     2018/5/17 下午3:29
*/
public class SuanHuaDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;
    /**姓名*/
    @JsonIgnore
    private String name;
    /**身份证号*/
    @JsonIgnore
    private String idCard;
    @JsonIgnore
    private Long applyId;
    /**人行登录名*/
    private String loginname;
    /**人行登录密码*/
    private String loginpwd;
    /**人行身份验证码*/
    private String tradecode;
    /**手机号*/
    private String phone;
    /**短信验证码*/
    private String activationCode;
    /**流水号*/
    private String iid;
    /**操作标识 01 02 03*/
    private String retCode;
    /**问题验证标识*/
    private String certifyId;
    /**问题答案*/
    private List<String> answers;
    /**用户银联认证之后的银联认证码*/
    private String verifyCode;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getLoginpwd() {
        return loginpwd;
    }

    public void setLoginpwd(String loginpwd) {
        this.loginpwd = loginpwd;
    }

    public String getTradecode() {
        return tradecode;
    }

    public void setTradecode(String tradecode) {
        this.tradecode = tradecode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getIid() {
        return iid;
    }

    public void setIid(String iid) {
        this.iid = iid;
    }

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getCertifyId() {
        return certifyId;
    }

    public void setCertifyId(String certifyId) {
        this.certifyId = certifyId;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }
}
