package com.xyb.order.pc.creditreport.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditPhoneDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private AuditDetailPhoneDTO auditDetailPhoneDTO;
	private List<AuditPhoneLinkManInfoDTO> auditPhoneLinkManInfoDTOs;//联系人列表

	public AuditDetailPhoneDTO getAuditDetailPhoneDTO() {
		return auditDetailPhoneDTO;
	}
	public void setAuditDetailPhoneDTO(AuditDetailPhoneDTO auditDetailPhoneDTO) {
		this.auditDetailPhoneDTO = auditDetailPhoneDTO;
	}
	public List<AuditPhoneLinkManInfoDTO> getAuditPhoneLinkManInfoDTOs() {
		return auditPhoneLinkManInfoDTOs;
	}
	public void setAuditPhoneLinkManInfoDTOs(List<AuditPhoneLinkManInfoDTO> auditPhoneLinkManInfoDTOs) {
		this.auditPhoneLinkManInfoDTOs = auditPhoneLinkManInfoDTOs;
	}
	
}
