package com.xyb.order.app.business.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @author : weiyuhao
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访工作信息 model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class BusinessOutBoundJobInfoDO implements IBaseModel {

	private static final long serialVersionUID = 5051609377513787757L;

	private Long id;

	/**外访主表id*/
    private Long visitMainId;
    /**单位名称是否一致（大类2692）*/
    private Long isCompNameSame;
    /**外放前单位名称*/
    private String compNameOld;
    /**外访后单位名称*/
    private String compName;
    /**单位地址是否一致(大类2692)*/
    private Long isCompAddressSame;
    /**外放前单位地址*/
    private String compAllAddrOld;
    /**外访后单位地址*/
    private String compAllAddr;
    /**单位地址省*/
    private Long compAddrProvince;
    /**单位地址市*/
    private Long compAddrCity;
    /**单位地址区*/
    private Long compAddrArea;
    /**单位地址街道门牌详细信息*/
    private String compAddrDetail;
    /**单位电话是否一致(大类2692)*/
    private Long isCompTellSame;
    /**外访前单位电话*/
    private String compTellOld;
    /**外访后单位电话*/
    private String compTell;
    /**进出单位情况（大类2723）*/
    private Long inOutCompType;
    /**单位电话位置（大类2724）*/
    private Long compTellSeat;
    /**单位电话位置其他*/
    private String compTellSeatQt;
    /**在职信息确认，多选英文逗号隔开存储(大类2725)*/
    private String onJobConfirm;
    /**备注*/
    private String remark;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public Long getIsCompNameSame() {
		return isCompNameSame;
	}

	public void setIsCompNameSame(Long isCompNameSame) {
		this.isCompNameSame = isCompNameSame;
	}

	public String getCompNameOld() {
		return compNameOld;
	}

	public void setCompNameOld(String compNameOld) {
		this.compNameOld = compNameOld;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public Long getIsCompAddressSame() {
		return isCompAddressSame;
	}

	public void setIsCompAddressSame(Long isCompAddressSame) {
		this.isCompAddressSame = isCompAddressSame;
	}

	public String getCompAllAddrOld() {
		return compAllAddrOld;
	}

	public void setCompAllAddrOld(String compAllAddrOld) {
		this.compAllAddrOld = compAllAddrOld;
	}

	public String getCompAllAddr() {
		return compAllAddr;
	}

	public void setCompAllAddr(String compAllAddr) {
		this.compAllAddr = compAllAddr;
	}

	public Long getCompAddrProvince() {
		return compAddrProvince;
	}

	public void setCompAddrProvince(Long compAddrProvince) {
		this.compAddrProvince = compAddrProvince;
	}

	public Long getCompAddrCity() {
		return compAddrCity;
	}

	public void setCompAddrCity(Long compAddrCity) {
		this.compAddrCity = compAddrCity;
	}

	public Long getCompAddrArea() {
		return compAddrArea;
	}

	public void setCompAddrArea(Long compAddrArea) {
		this.compAddrArea = compAddrArea;
	}

	public String getCompAddrDetail() {
		return compAddrDetail;
	}

	public void setCompAddrDetail(String compAddrDetail) {
		this.compAddrDetail = compAddrDetail;
	}

	public Long getIsCompTellSame() {
		return isCompTellSame;
	}

	public void setIsCompTellSame(Long isCompTellSame) {
		this.isCompTellSame = isCompTellSame;
	}

	public String getCompTellOld() {
		return compTellOld;
	}

	public void setCompTellOld(String compTellOld) {
		this.compTellOld = compTellOld;
	}

	public String getCompTell() {
		return compTell;
	}

	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}

	public Long getInOutCompType() {
		return inOutCompType;
	}

	public void setInOutCompType(Long inOutCompType) {
		this.inOutCompType = inOutCompType;
	}

	public Long getCompTellSeat() {
		return compTellSeat;
	}

	public void setCompTellSeat(Long compTellSeat) {
		this.compTellSeat = compTellSeat;
	}

	public String getCompTellSeatQt() {
		return compTellSeatQt;
	}

	public void setCompTellSeatQt(String compTellSeatQt) {
		this.compTellSeatQt = compTellSeatQt;
	}

	public String getOnJobConfirm() {
		return onJobConfirm;
	}

	public void setOnJobConfirm(String onJobConfirm) {
		this.onJobConfirm = onJobConfirm;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	@Override
	public String toString() {
		return "ApplyVisitCreditJobInfoDO [id=" + id + ", visitMainId=" + visitMainId + ", isCompNameSame="
				+ isCompNameSame + ", compNameOld=" + compNameOld + ", compName=" + compName + ", isCompAddressSame="
				+ isCompAddressSame + ", compAllAddrOld=" + compAllAddrOld + ", compAllAddr=" + compAllAddr
				+ ", compAddrProvince=" + compAddrProvince + ", compAddrCity=" + compAddrCity + ", compAddrArea="
				+ compAddrArea + ", compAddrDetail=" + compAddrDetail + ", isCompTellSame=" + isCompTellSame
				+ ", compTellOld=" + compTellOld + ", compTell=" + compTell + ", inOutCompType=" + inOutCompType
				+ ", compTellSeat=" + compTellSeat + ", compTellSeatQt=" + compTellSeatQt + ", onJobConfirm="
				+ onJobConfirm + ", remark=" + remark + ", createTime=" + createTime + ", createUser=" + createUser
				+ ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser + "]";
	}


}
