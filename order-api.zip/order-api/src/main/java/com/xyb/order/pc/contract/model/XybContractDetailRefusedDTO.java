package com.xyb.order.pc.contract.model;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractDetailRefusedDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6204139040139400771L;
	@NotNull(message="合同id不能为空")
	private Long contractId;
	
	private Long refusedCode;

	public Long getContractId() {
		return contractId;
	}

	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}

	public Long getRefusedCode() {
		return refusedCode;
	}

	public void setRefusedCode(Long refusedCode) {
		this.refusedCode = refusedCode;
	}

	@Override
	public String toString() {
		return "XybContractDetailRefusedDTO [contractId=" + contractId + ", refusedCode=" + refusedCode + "]";
	}

}
