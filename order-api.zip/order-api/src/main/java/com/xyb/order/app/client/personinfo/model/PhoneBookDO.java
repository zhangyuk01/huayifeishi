package com.xyb.order.app.client.personinfo.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 电话簿
 * 
 * @author qiaoJinLong
 * @date 2018年8月23日
 */
public class PhoneBookDO implements IBaseModel {

	private static final long serialVersionUID = -1219209482953190163L;
	private Long clientId; // 申请表id

	private String name; // 姓名

	private String phone;// 手机号

	private String email; // email地址

	private String phoneGroup;// 手机号在手机系统中的分组

	private Date birthday;// 生日

	private String nickname;// 昵称

	private String remark;// 备注

	private String company;// 单位

	private String address;// 地址

	private Date createTime;// 创建时间

	private Long createUser;// 创建人

	private Date modifyTime;// 修改时间

	private Long modifyUser;// 修改人

	private String phoneType;// 手机型号

	private Long isNew;// 是否新增

	private Long mobilePhoneBatchId;// 批次表id

	public Long getIsNew() {
		return isNew;
	}

	public void setIsNew(Long isNew) {
		this.isNew = isNew;
	}

	public Long getMobilePhoneBatchId() {
		return mobilePhoneBatchId;
	}

	public void setMobilePhoneBatchId(Long mobilePhoneBatchId) {
		this.mobilePhoneBatchId = mobilePhoneBatchId;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneGroup() {
		return phoneGroup;
	}

	public void setPhoneGroup(String phoneGroup) {
		this.phoneGroup = phoneGroup;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "PhoneBookDO [clientId=" + clientId + ", name=" + name + ", phone=" + phone + ", email=" + email
				+ ", phoneGroup=" + phoneGroup + ", birthday=" + birthday + ", nickname=" + nickname + ", remark="
				+ remark + ", company=" + company + ", address=" + address + ", createTime=" + createTime
				+ ", createUser=" + createUser + ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser
				+ ", phoneType=" + phoneType + ", isNew=" + isNew + ", mobilePhoneBatchId=" + mobilePhoneBatchId + "]";
	}

}
