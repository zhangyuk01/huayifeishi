package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.List;

/**
 * 协议app展示内容
 * @author         xieqingyang
 * @date           2018/10/18 4:58 PM
*/
public class AgreementInFoVO implements IBaseModel {

    private static final long serialVersionUID = 6262638097711306502L;
    private List<AgreementListVO> list;

    /**协议类型*/
    private Long type;

    public List<AgreementListVO> getList() {
        return list;
    }

    public void setList(List<AgreementListVO> list) {
        this.list = list;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "AgreementInFoVO{" +
                "list=" + list +
                ", type='" + type + '\'' +
                '}';
    }
}
