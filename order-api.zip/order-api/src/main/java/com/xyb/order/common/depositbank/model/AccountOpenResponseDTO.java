package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 存管新开户响应参数
 * @author         xieqingyang
 * @date           2018/11/23 5:15 PM
*/
public class AccountOpenResponseDTO implements IBaseModel {

    private static final long serialVersionUID = 4836078893452545418L;
    /**系统ID*/
    @SignField(order = 2)
    private String sysId;
    /**申请流水号，用于交易的唯一性标识，32(位数)*/
    @SignField(order = 3)
    private String out_serial_no;
    /**订单号*/
    @SignField(order = 4)
    private String order_id;
    /**页面跳转url*/
    @SignField(order = 5)
    private String url;
    /**交易代码,set_password_p*/
    @SignField(order = 6)
    private String service;

    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountOpenResponseDTO that = (AccountOpenResponseDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(out_serial_no, that.out_serial_no) &&
                Objects.equals(order_id, that.order_id) &&
                Objects.equals(url, that.url) &&
                Objects.equals(service, that.service);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, out_serial_no, order_id, url, service);
    }

    @Override
    public String toString() {
        return "AccountOpenResponseDTO{" +
                "sysId='" + sysId + '\'' +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", order_id='" + order_id + '\'' +
                ", url='" + url + '\'' +
                ", service='" + service + '\'' +
                '}';
    }
}
