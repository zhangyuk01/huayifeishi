package com.xyb.order.pc.finance;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @description 待交易明细表持久层对象
 * @author luyang
 * @time 2018年4月17日上午11:47:54
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class FinancePaymentDO implements IBaseModel {

    /**
	 * 序列化
	 */
	private static final long serialVersionUID = 8429452735721590065L;
	/**
	 * 主键ID
	 */
    private Long id;
    /**
     * 合同ID
     */
    private Long contractId;
    /**
     * 客户ID
     */
    private Long cusId;
    /**
     * 逾期还款表ID
     */
    private Long latepaymentApplicationId;
    /**
     * 还款计划表Id
     */
    private Long repaymentPlanId;
    /**
     * 一次性申请结清表Id
     */
    private Long onetimePaymentApplicationId;
    /**
     * 收付标记(大类2760)
     */
    private Long inOutFlag;
    /**
     * 扣款类型（大类2537）
     */
    private Long inType;
    /**
     * 逾期还款类型(大类2588)
     */
    private Long repaymentType;
    /**
     * 账户类型（大类2479）
     */
    private Long accountType;
    /**
     * 交易总额
     */
    private BigDecimal totalAmount;
    /**
     * 银行大类（对应t_xyb_bank_code表）
     */
    private Integer bankType;
    /**
     * 开户支行
     */
    private String bankAccountOpen;
    /**
     * 账户名
     */
    private String bankAccount;
    /**
     * 银行账号
     */
    private String refundCardNum;
    /**
     * 状态(大类2752)
     */
    private Long state;
    /**
     * 交易时间
     */
    private Date dealDatetime;
    /**
     * 所属机构
     */
    private Long orgId;
    /**
     * 正常还款划扣次数
     */
    private Integer deductCount;
    /**
     * 身份证号
     */
    private String clientIdcard;
    /**
     * 银行预留手机号
     */
    private String mp;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private Long modifyUser;
    /**
     * 修改时间
     */
    private Date modifyTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public Long getLatepaymentApplicationId() {
		return latepaymentApplicationId;
	}
	public void setLatepaymentApplicationId(Long latepaymentApplicationId) {
		this.latepaymentApplicationId = latepaymentApplicationId;
	}
	public Long getRepaymentPlanId() {
		return repaymentPlanId;
	}
	public void setRepaymentPlanId(Long repaymentPlanId) {
		this.repaymentPlanId = repaymentPlanId;
	}
	public Long getOnetimePaymentApplicationId() {
		return onetimePaymentApplicationId;
	}
	public void setOnetimePaymentApplicationId(Long onetimePaymentApplicationId) {
		this.onetimePaymentApplicationId = onetimePaymentApplicationId;
	}
	public Long getInOutFlag() {
		return inOutFlag;
	}
	public void setInOutFlag(Long inOutFlag) {
		this.inOutFlag = inOutFlag;
	}
	public Long getInType() {
		return inType;
	}
	public void setInType(Long inType) {
		this.inType = inType;
	}
	public Long getRepaymentType() {
		return repaymentType;
	}
	public void setRepaymentType(Long repaymentType) {
		this.repaymentType = repaymentType;
	}
	public Long getAccountType() {
		return accountType;
	}
	public void setAccountType(Long accountType) {
		this.accountType = accountType;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Integer getBankType() {
		return bankType;
	}
	public void setBankType(Integer bankType) {
		this.bankType = bankType;
	}
	public String getBankAccountOpen() {
		return bankAccountOpen;
	}
	public void setBankAccountOpen(String bankAccountOpen) {
		this.bankAccountOpen = bankAccountOpen;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getRefundCardNum() {
		return refundCardNum;
	}
	public void setRefundCardNum(String refundCardNum) {
		this.refundCardNum = refundCardNum;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	public Date getDealDatetime() {
		return dealDatetime;
	}
	public void setDealDatetime(Date dealDatetime) {
		this.dealDatetime = dealDatetime;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Integer getDeductCount() {
		return deductCount;
	}
	public void setDeductCount(Integer deductCount) {
		this.deductCount = deductCount;
	}
	public String getClientIdcard() {
		return clientIdcard;
	}
	public void setClientIdcard(String clientIdcard) {
		this.clientIdcard = clientIdcard;
	}
	public String getMp() {
		return mp;
	}
	public void setMp(String mp) {
		this.mp = mp;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	@Override
	public String toString() {
		return "FinancePaymentDO [id=" + id + ", contractId=" + contractId + ", cusId=" + cusId
				+ ", latepaymentApplicationId=" + latepaymentApplicationId + ", repaymentPlanId=" + repaymentPlanId
				+ ", onetimePaymentApplicationId=" + onetimePaymentApplicationId + ", inOutFlag=" + inOutFlag
				+ ", inType=" + inType + ", repaymentType=" + repaymentType + ", accountType=" + accountType
				+ ", totalAmount=" + totalAmount + ", bankType=" + bankType + ", bankAccountOpen=" + bankAccountOpen
				+ ", bankAccount=" + bankAccount + ", refundCardNum=" + refundCardNum + ", state=" + state
				+ ", dealDatetime=" + dealDatetime + ", orgId=" + orgId + ", deductCount=" + deductCount
				+ ", clientIdcard=" + clientIdcard + ", mp=" + mp + ", createUser=" + createUser + ", createTime="
				+ createTime + ", modifyUser=" + modifyUser + ", modifyTime=" + modifyTime + "]";
	}


}
