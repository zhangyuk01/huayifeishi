package com.xyb.order.pc.contract.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同审核list查询model
 * @createDate : 2018/03/29 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAuditQueryDTO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7047773076143089666L;
	@JsonIgnore
    private Page page = new Page();// -- 分页
	/**申请编号*/
	private String applyNum;
	/**客户姓名*/
	private String custName;
	/**身份证号*/
	private String idCard;
	/**进件机构id*/
	private Long orgId;
	/**是否签约前核验*/
	private Long signCheck;
	/**终极授信期数*/
	private Long agreeProductLimit; 
	/**是否暂存状态码*/
	private Long isTempSave;
	/**当前登录id*/
	@JsonIgnore
	private Long userId;
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Long getSignCheck() {
		return signCheck;
	}
	public void setSignCheck(Long signCheck) {
		this.signCheck = signCheck;
	}
	public Long getAgreeProductLimit() {
		return agreeProductLimit;
	}
	public void setAgreeProductLimit(Long agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}
	public Long getIsTempSave() {
		return isTempSave;
	}
	public void setIsTempSave(Long isTempSave) {
		this.isTempSave = isTempSave;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "XybContractAuditQueryDTO [page=" + page + ", applyNum=" + applyNum + ", custName=" + custName
				+ ", idCard=" + idCard + ", orgId=" + orgId + ", signCheck=" + signCheck + ", agreeProductLimit="
				+ agreeProductLimit + ", isTempSave=" + isTempSave + ", userId=" + userId + "]";
	}
	
}
