package com.xyb.order.pc.consultation.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by xieqingyang on 2018/3/30.
 * 咨询修改客服人员
 */
public class ServiceUpdateDTO  implements IBaseModel {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "客服人员ID不能为空")
    private Long serviceUid;// -- 待修改客服人员id
    @NotEmpty(message = "客服人员名称不能为空")
    private String serviceName;// -- 待修改客服人员名称
    @NotNull(message = "修改申请单不能为空")
    @Valid
    private List<ServiceUpdateSubsidiaryDTO> applyInFo;
    @JsonIgnore
    private Long userId;// -- 当前登录人ID
    @JsonIgnore
    /**客服经理ID*/
    private Long serviceManagerUid;
    @JsonIgnore
    /**客服经理名称*/
    private String serviceManagerName;

    public Long getServiceUid() {
        return serviceUid;
    }

    public void setServiceUid(Long serviceUid) {
        this.serviceUid = serviceUid;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public List<ServiceUpdateSubsidiaryDTO> getApplyInFo() {
        return applyInFo;
    }

    public void setApplyInFo(List<ServiceUpdateSubsidiaryDTO> applyInFo) {
        this.applyInFo = applyInFo;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getServiceManagerUid() {
        return serviceManagerUid;
    }

    public void setServiceManagerUid(Long serviceManagerUid) {
        this.serviceManagerUid = serviceManagerUid;
    }

    public String getServiceManagerName() {
        return serviceManagerName;
    }

    public void setServiceManagerName(String serviceManagerName) {
        this.serviceManagerName = serviceManagerName;
    }
}
