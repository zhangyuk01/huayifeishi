package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fr.third.org.apache.poi.hssf.record.formula.functions.Int;

import java.util.Date;

/**
 * @description: 用户银行卡信息非存管体系表
 * @author: xieqingyang
 * @createDate: 2018/7/20 上午11:37
 */
public class ClientBankInfoNoDO implements IBaseModel {

	private static final long serialVersionUID = 1284850799009309950L;
	/** 主键ID */
	private Long id;
	/** 用户信息表ID */
	private Long clientId;
	/** 开户人姓名 */
	private String bankRealName;
	/** 开户人身份证号 */
	private String bankIdcard;
	/** 银行卡号 */
	private String bankNum;
	/** 银行名称 */
	private String bankName;
	/** 开户支行 */
	private String bankDeposit;
	/** 开户行总行 */
	private String bankcardBankname;
	/** 银行预留手机号 */
	private String phone;
	/** t_xyb_bank_code的type */
	private Integer bankId;
	/** 是否默认卡（2692） */
	private Long isDefault;
	/** 状态（2692） */
	private Long state;
	/** 创建时间 */
	private Date createTime;
	/** 创建人 */
	private Long createUser;
	/** 修改时间 */
	private Date modifyTime;
	/** 修改人 */
	private Long modifyUser;

	private Integer isState;

	public Integer getIsState() {
		return isState;
	}

	public void setIsState(Integer isState) {
		this.isState = isState;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getBankRealName() {
		return bankRealName;
	}

	public void setBankRealName(String bankRealName) {
		this.bankRealName = bankRealName;
	}

	public String getBankIdcard() {
		return bankIdcard;
	}

	public void setBankIdcard(String bankIdcard) {
		this.bankIdcard = bankIdcard;
	}

	public String getBankNum() {
		return bankNum;
	}

	public void setBankNum(String bankNum) {
		this.bankNum = bankNum;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankDeposit() {
		return bankDeposit;
	}

	public void setBankDeposit(String bankDeposit) {
		this.bankDeposit = bankDeposit;
	}

	public String getBankcardBankname() {
		return bankcardBankname;
	}

	public void setBankcardBankname(String bankcardBankname) {
		this.bankcardBankname = bankcardBankname;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	public Long getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Long isDefault) {
		this.isDefault = isDefault;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	@Override
	public String toString() {
		return "ClientBankInfoNoDO [id=" + id + ", clientId=" + clientId + ", bankRealName=" + bankRealName
				+ ", bankIdcard=" + bankIdcard + ", bankNum=" + bankNum + ", bankName=" + bankName + ", bankDeposit="
				+ bankDeposit + ", bankcardBankname=" + bankcardBankname + ", phone=" + phone + ", bankId=" + bankId
				+ ", isDefault=" + isDefault + ", state=" + state + ", createTime=" + createTime + ", createUser="
				+ createUser + ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser + ", isState=" + isState
				+ "]";
	}
}
