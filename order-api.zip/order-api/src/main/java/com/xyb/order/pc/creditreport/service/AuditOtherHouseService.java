package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDTO;

/**
 * @ClassName AuditOtherHouseService
 * @author ZhangYu
 * @date 2018年4月25号
 */
public interface AuditOtherHouseService {

	/**
	 * 根据申请单ID查询房产信息  
	 * @return
	 */
	public RestResponse queryInfoByApplyId(Long applyId)throws Exception;
	

	/**
	 * 根据ID更新房产信息 
	 * @param id
	 * @return
	 */
	public RestResponse updateOrAddInfoById(AuditOtherHouseDTO auditOtherHouseDTO)throws Exception;


}
