package com.xyb.order.pc.outbound.model;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访实地征信提交DTO model
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailSubmitCreditDTO implements IBaseModel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 347805270442505727L;
	/**申请id*/
	@NotNull(message = "applyId不能为空")
	private Long applyId;
	/**实地时间*/
	@NotNull(message = "visitDate不能为空")
	private Date visitDate;
	/**客户综合描述*/
	@NotEmpty(message = "customerIntegratedDescription不能为空")
	private String customerIntegratedDescription;
	/**实地征信工作信息*/
	@Valid
	private ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO;
	/**实地征信家庭信息*/
	@Valid
	private List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs;
	/**实地征信经营信息*/
	@Valid
	private List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	public String getCustomerIntegratedDescription() {
		return customerIntegratedDescription;
	}
	public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
		this.customerIntegratedDescription = customerIntegratedDescription;
	}
	public ApplyVisitCreditJobInfoDTO getApplyVisitCreditJobInfoDTO() {
		return applyVisitCreditJobInfoDTO;
	}
	public void setApplyVisitCreditJobInfoDTO(ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO) {
		this.applyVisitCreditJobInfoDTO = applyVisitCreditJobInfoDTO;
	}
	public List<ApplyVisitCreditFamilyInfoDTO> getApplyVisitCreditFamilyInfoDTOs() {
		return applyVisitCreditFamilyInfoDTOs;
	}
	public void setApplyVisitCreditFamilyInfoDTOs(List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs) {
		this.applyVisitCreditFamilyInfoDTOs = applyVisitCreditFamilyInfoDTOs;
	}
	public List<ApplyVisitCreditManagermentInfoDTO> getApplyVisitCreditManagermentInfoDTOs() {
		return applyVisitCreditManagermentInfoDTOs;
	}
	public void setApplyVisitCreditManagermentInfoDTOs(
			List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs) {
		this.applyVisitCreditManagermentInfoDTOs = applyVisitCreditManagermentInfoDTOs;
	}
	@Override
	public String toString() {
		return "OutBoundDetailSubmitCreditDTO [applyId=" + applyId + ", visitDate=" + visitDate
				+ ", customerIntegratedDescription=" + customerIntegratedDescription + ", applyVisitCreditJobInfoDTO="
				+ applyVisitCreditJobInfoDTO + ", applyVisitCreditFamilyInfoDTOs=" + applyVisitCreditFamilyInfoDTOs
				+ ", applyVisitCreditManagermentInfoDTOs=" + applyVisitCreditManagermentInfoDTOs + "]";
	}
	

	

}
