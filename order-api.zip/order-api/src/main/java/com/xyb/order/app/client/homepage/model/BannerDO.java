package com.xyb.order.app.client.homepage.model;

import com.beiming.kun.framework.model.IBaseModel;


/**
* @Description:    banner图
* @Author:         xieqingyang
* @CreateDate:     2018/5/8 下午5:33
*/
public class BannerDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private Long id; // -- ID
    private String linkUrl; // -- 活动链接
    private String homeImgPath; // -- 首页活动图片路径
    private String activityImgPath; // -- 活动图片路径
    private String content; // -- 描述
    private String ordinal; // -- 活动序号

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getHomeImgPath() {
        return homeImgPath;
    }

    public void setHomeImgPath(String homeImgPath) {
        this.homeImgPath = homeImgPath;
    }

    public String getActivityImgPath() {
        return activityImgPath;
    }

    public void setActivityImgPath(String activityImgPath) {
        this.activityImgPath = activityImgPath;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getOrdinal() {
        return ordinal;
    }

    public void setOrdinal(String ordinal) {
        this.ordinal = ordinal;
    }
}
