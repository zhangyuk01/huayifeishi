package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordConfrimDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	@NotNull(message = "申请单ID不能为空")
	private Long applyId; 
	@NotNull(message = "主表ID不能为空")
	private Long mainId;
	/**一级授信金额*/
	private BigDecimal agreeAmount;
	private BigDecimal oldAgreeAmount;

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getMainId() {
		return mainId;
	}

	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}

	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}

	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}

	public BigDecimal getOldAgreeAmount() {
		return oldAgreeAmount;
	}

	public void setOldAgreeAmount(BigDecimal oldAgreeAmount) {
		this.oldAgreeAmount = oldAgreeAmount;
	}
}
