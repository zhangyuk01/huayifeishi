package com.xyb.order.app.business.manage.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:   APP客户经理申请单详情信息MODEL  
* @author:        ZhangYu 
* @createDate:    2018/6/13
*/
public class AppBillInfoDetailDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private String applyNum;//申请编号
	private Date applyTime;//申请时间
	private String expectProductName;//申请产品
	private BigDecimal expectMoney;//申请金额
	private BigDecimal contractMoney;//合同金额
	private Integer productLimit;//合同期数
	private Integer paidPeriod;//已还总期数
	private Integer totalLatePeriod;//总逾期数
	
	
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public Date getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}
	public String getExpectProductName() {
		return expectProductName;
	}
	public void setExpectProductName(String expectProductName) {
		this.expectProductName = expectProductName;
	}
	public BigDecimal getExpectMoney() {
		return expectMoney;
	}
	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}
	public BigDecimal getContractMoney() {
		return contractMoney;
	}
	public void setContractMoney(BigDecimal contractMoney) {
		this.contractMoney = contractMoney;
	}
	public Integer getProductLimit() {
		return productLimit;
	}
	public void setProductLimit(Integer productLimit) {
		this.productLimit = productLimit;
	}
	public Integer getPaidPeriod() {
		return paidPeriod;
	}
	public void setPaidPeriod(Integer paidPeriod) {
		this.paidPeriod = paidPeriod;
	}
	public Integer getTotalLatePeriod() {
		return totalLatePeriod;
	}
	public void setTotalLatePeriod(Integer totalLatePeriod) {
		this.totalLatePeriod = totalLatePeriod;
	}


}
