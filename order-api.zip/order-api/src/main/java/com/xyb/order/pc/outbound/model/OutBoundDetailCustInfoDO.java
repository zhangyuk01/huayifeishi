package com.xyb.order.pc.outbound.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

public class OutBoundDetailCustInfoDO implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1148162390745963370L;
	/**客户信息*/
	private String custName;
	/**身份证*/
	private String idCard;
	/**户籍地址*/
	private String homeAddress;
	/**家庭地址*/
	private String nowAddress;
	/**单位名称*/
	private String compName;
	/**单位地址*/
	private String compAddress;
	/**申请产品*/
	private String applyProductName;
	/**手机号码*/
	private String phone;
	/**性别*/
	private String gender;
	/**婚姻状况*/
	private String marriage;
	/**单位电话*/
	private String compTell;
	/**终审报告最近一次提交时间*/
	private Date endSubmitTime;
	/**终审报告*/
	private String endRemark;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getNowAddress() {
		return nowAddress;
	}
	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCompAddress() {
		return compAddress;
	}
	public void setCompAddress(String compAddress) {
		this.compAddress = compAddress;
	}
	public String getApplyProductName() {
		return applyProductName;
	}
	public void setApplyProductName(String applyProductName) {
		this.applyProductName = applyProductName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMarriage() {
		return marriage;
	}
	public void setMarriage(String marriage) {
		this.marriage = marriage;
	}

	public String getCompTell() {
		return compTell;
	}

	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}

	public Date getEndSubmitTime() {
		return endSubmitTime;
	}

	public void setEndSubmitTime(Date endSubmitTime) {
		this.endSubmitTime = endSubmitTime;
	}

	public String getEndRemark() {
		return endRemark;
	}

	public void setEndRemark(String endRemark) {
		this.endRemark = endRemark;
	}

	@Override
	public String toString() {
		return "OutBoundDetailCustInfoDO{" +
				"custName='" + custName + '\'' +
				", idCard='" + idCard + '\'' +
				", homeAddress='" + homeAddress + '\'' +
				", nowAddress='" + nowAddress + '\'' +
				", compName='" + compName + '\'' +
				", compAddress='" + compAddress + '\'' +
				", applyProductName='" + applyProductName + '\'' +
				", phone='" + phone + '\'' +
				", gender='" + gender + '\'' +
				", marriage='" + marriage + '\'' +
				", compTell='" + compTell + '\'' +
				", endSubmitTime=" + endSubmitTime +
				", endRemark='" + endRemark + '\'' +
				'}';
	}
}
