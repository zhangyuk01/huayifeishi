package com.xyb.order.pc.outbound.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访listVOmodel
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundListVO implements IBaseModel {

	/**
	 * 
	 */
	private static final Long serialVersionUID = 7800781869190043635L;
	/**申请id*/
	private Long applyId;
	/**主表id*/
	private long applyMainId;
	/**申请编号*/
	private String applyNum;
	/**客户姓名*/
	private String custName;
	/**客户手机号*/
	private String phone;
	/**申请时间*/
	private Date outBoundApplyDate;
	/**申请类型*/
	private String type;
	/**当前操作人*/
	private String processer;
	/**产品id*/
	private Long productId;
	/**当前操作人uid*/
	private Long processerUid;
	/**当前登录人ID*/
	private Long loginId;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public long getApplyMainId() {
		return applyMainId;
	}
	public void setApplyMainId(long applyMainId) {
		this.applyMainId = applyMainId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getOutBoundApplyDate() {
		return outBoundApplyDate;
	}
	public void setOutBoundApplyDate(Date outBoundApplyDate) {
		this.outBoundApplyDate = outBoundApplyDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getProcesser() {
		return processer;
	}
	public void setProcesser(String processer) {
		this.processer = processer;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getProcesserUid() {
		return processerUid;
	}

	public void setProcesserUid(Long processerUid) {
		this.processerUid = processerUid;
	}

	public Long getLoginId() {
		return loginId;
	}

	public void setLoginId(Long loginId) {
		this.loginId = loginId;
	}

	@Override
	public String toString() {
		return "OutBoundListVO{" +
				"applyId=" + applyId +
				", applyMainId=" + applyMainId +
				", applyNum='" + applyNum + '\'' +
				", custName='" + custName + '\'' +
				", phone='" + phone + '\'' +
				", outBoundApplyDate=" + outBoundApplyDate +
				", type='" + type + '\'' +
				", processer='" + processer + '\'' +
				", productId=" + productId +
				", processerUid=" + processerUid +
				", loginId=" + loginId +
				'}';
	}
}
