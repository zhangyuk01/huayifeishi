package com.xyb.order.pc.applybill.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDTO;
import com.xyb.order.pc.applybill.model.ApplyBillinfoAllSaveCheckJobDTO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDTO;

/**
 * 申请单相关功能
 * @author         ZhangYu
 * @date           2018/3/26 3:27 PM
*/
public interface ApplyBillInfoService {

	/**
	 * 申请单列表信息
	 * @author      xieqingyang
	 * @date        2018/10/16 3:27 PM
	 * @version     1.0
	 * @param pageNumber 分页参数
	 * @param pageSize 分页参数
	 * @param applyBillInfoQueryDTO 查询条件
	 * @return 列表数据
	 * @throws Exception 所有异常
	 */
	RestResponse applyBillInfoQueryPage(Integer pageNumber,Integer pageSize,ApplyBillInfoQueryDTO applyBillInfoQueryDTO) throws Exception;

	/**
	 * 申请单详情信息
	 * @author      xieqingyang
	 * @date        2018/10/16 3:26 PM
	 * @version     1.0
	 * @param mainId 主表ID
	 * @return 申请单详情信息
	 * @throws Exception 所有异常
	 */
	RestResponse updateDetailBillInfoData(Long mainId) throws Exception;

	/**
	 * 申请单暂存
	 * @author      xieqingyang
	 * @date        2018/10/16 3:26 PM
	 * @version     1.0
	 * @param applyBillInfoAllTempSaveDTO 待暂存数据
	 * @return 返回暂存结果
	 * @throws Exception 所有异常
	 */
	RestResponse addOrUpdateAll(ApplyBillInfoAllTempSaveDTO applyBillInfoAllTempSaveDTO) throws Exception;

	/**
	 * 申请单保存(下一步)
	 * @author      xieqingyang
	 * @date        2018/10/16 3:25 PM
	 * @version     1.0
	 * @param applyBillInfoAllSaveDTO 待保存数据
	 * @return 返回执行结果
	 * @throws Exception 所有异常
	 */
	RestResponse addOrUpdateAll(ApplyBillInfoAllSaveDTO applyBillInfoAllSaveDTO) throws Exception;

	/**
	 * 申请单保存校验工作信息(下一步)
	 * @author      xieqingyang
	 * @date        2018/10/16 3:25 PM
	 * @version     1.0
	 * @param applyBillinfoAllSaveCheckJobDTO 待保存数据
	 * @return 返回执行结果
	 * @throws Exception 所有异常
	 */
	RestResponse addOrUpdateAll(ApplyBillinfoAllSaveCheckJobDTO applyBillinfoAllSaveCheckJobDTO) throws Exception;

	/**
	 * 客户放弃原因
	 * @author      xieqingyang
	 * @date        2018/10/16 3:25 PM
	 * @version     1.0
	 * @return 返回放弃原因
	 * @throws Exception 所有异常
	 */
	RestResponse queryClientAbandonReason() throws Exception;

	/**
	 * 客户确认放弃功能
	 * @author      xieqingyang
	 * @date        2018/10/16 3:24 PM
	 * @version     1.0
	 * @param applyClientAbandonDTO 条件
	 * @return 返回执行结果
	 * @throws Exception 所有异常
	 */
	RestResponse confirmClientAbandon(ApplyClientAbandonDTO applyClientAbandonDTO) throws Exception;

	/**
	 * 删除联系人信息
	 * @author      xieqingyang
	 * @date        2018/10/16 3:24 PM
	 * @version     1.0
	 * @param id 联系人表ID
	 * @return 删除结果
	 * @throws Exception 所有异常
	 */
    RestResponse updateLinkManDelFlagById(Long id) throws Exception;

	/**
	 * 提交审核
	 * @author      xieqingyang
	 * @date 2018/5/25 下午6:52
	 * @version     1.0
	 * @param applyId 申请单ID
	 * @param mainId 主表ID
	 * @return 返回通用数据结构
	 */
	RestResponse onSubmintOutline(Long applyId,Long mainId,Long projectCode)throws Exception;


	/**
	 * 材料补充提交功能
	 * @author      xieqingyang
	 * @date 2018/5/28 上午10:51
	 * @version     1.0
	 * @param applyId 申请单ID
	 * @param projectCode 专案码
	 * @return 返回通用数据格式（成功或失败）
	 * @throws Exception 抛出所有异常
	 */
	RestResponse onSubmint(Long applyId,Long projectCode) throws Exception;
}
