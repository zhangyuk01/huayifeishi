package com.xyb.order.pc.contract.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同废除list查询model
 * @createDate : 2018/05/11 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractAbolishQueryDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7802081179957699287L;
	@JsonIgnore
    private Page page = new Page();// -- 分页
	/**申请编号*/
	private String applyNum;
	/**客户姓名*/
	private String custName;
	/**身份证号*/
	private String idCard;
	/**状态码*/
	private Long state;
	/**登录id*/
	@JsonIgnore
	private long loginId;
	@JsonIgnore
	/**机构id*/
	private Long orgId;
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	public long getLoginId() {
		return loginId;
	}
	public void setLoginId(long loginId) {
		this.loginId = loginId;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	@Override
	public String toString() {
		return "XybContractAbolishQueryDTO [page=" + page + ", applyNum=" + applyNum + ", custName=" + custName
				+ ", idCard=" + idCard + ", state=" + state + ", loginId=" + loginId + ", orgId=" + orgId + "]";
	}
	
}
