package com.xyb.order.pc.outbound.model;

import java.util.Date;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访detailVO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class OutBoundDetailVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7517174602759346274L;
	
	/**客户信息*/
	private OutBoundDetailCustInfoDO outBoundDetailCustInfoDO;
	/**终审报告最近一次提交时间*/
	private Date endSubmitTime;
	/**终审报告*/
	private String endRemark;
	/**外访类型*/
	private String visitType;
	/**实地征信类型*/
	private String visitCreditType;
	/**实地时间*/
	private Date visitDate;
	/**客户综合描述*/
	private String customerIntegratedDescription;
	/**实地征信工作信息*/
	private ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO;
	/**实地征信家庭信息*/
	private List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDO;
	/**实地征信经营信息*/
	private List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs;
	/**外访产调*/
	private ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO;
	public OutBoundDetailCustInfoDO getOutBoundDetailCustInfoDO() {
		return outBoundDetailCustInfoDO;
	}
	public void setOutBoundDetailCustInfoDO(OutBoundDetailCustInfoDO outBoundDetailCustInfoDO) {
		this.outBoundDetailCustInfoDO = outBoundDetailCustInfoDO;
	}
	public Date getEndSubmitTime() {
		return endSubmitTime;
	}
	public void setEndSubmitTime(Date endSubmitTime) {
		this.endSubmitTime = endSubmitTime;
	}
	public String getEndRemark() {
		return endRemark;
	}
	public void setEndRemark(String endRemark) {
		this.endRemark = endRemark;
	}
	public String getVisitType() {
		return visitType;
	}
	public void setVisitType(String visitType) {
		this.visitType = visitType;
	}
	public String getVisitCreditType() {
		return visitCreditType;
	}
	public void setVisitCreditType(String visitCreditType) {
		this.visitCreditType = visitCreditType;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	public String getCustomerIntegratedDescription() {
		return customerIntegratedDescription;
	}
	public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
		this.customerIntegratedDescription = customerIntegratedDescription;
	}
	public ApplyVisitCreditJobInfoDO getApplyVisitCreditJobInfoDO() {
		return applyVisitCreditJobInfoDO;
	}
	public void setApplyVisitCreditJobInfoDO(ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO) {
		this.applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDO;
	}
	public List<ApplyVisitCreditFamilyInfoDO> getApplyVisitCreditFamilyInfoDO() {
		return applyVisitCreditFamilyInfoDO;
	}
	public void setApplyVisitCreditFamilyInfoDO(List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDO) {
		this.applyVisitCreditFamilyInfoDO = applyVisitCreditFamilyInfoDO;
	}
	public List<ApplyVisitCreditManagermentInfoDO> getApplyVisitCreditManagermentInfoDOs() {
		return applyVisitCreditManagermentInfoDOs;
	}
	public void setApplyVisitCreditManagermentInfoDOs(
			List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs) {
		this.applyVisitCreditManagermentInfoDOs = applyVisitCreditManagermentInfoDOs;
	}
	public ApplyVisitPropertySurveyDO getApplyVisitPropertySurveyDO() {
		return applyVisitPropertySurveyDO;
	}
	public void setApplyVisitPropertySurveyDO(ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO) {
		this.applyVisitPropertySurveyDO = applyVisitPropertySurveyDO;
	}
	@Override
	public String toString() {
		return "OutBoundDetailVO [outBoundDetailCustInfoDO=" + outBoundDetailCustInfoDO + ", endSubmitTime="
				+ endSubmitTime + ", endRemark=" + endRemark + ", visitType=" + visitType + ", visitCreditType="
				+ visitCreditType + ", visitDate=" + visitDate + ", customerIntegratedDescription="
				+ customerIntegratedDescription + ", applyVisitCreditJobInfoDO=" + applyVisitCreditJobInfoDO
				+ ", applyVisitCreditFamilyInfoDO=" + applyVisitCreditFamilyInfoDO
				+ ", applyVisitCreditManagermentInfoDOs=" + applyVisitCreditManagermentInfoDOs
				+ ", applyVisitPropertySurveyDO=" + applyVisitPropertySurveyDO + "]";
	}

}
