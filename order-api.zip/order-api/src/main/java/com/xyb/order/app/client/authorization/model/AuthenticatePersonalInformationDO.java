package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import java.util.List;

/**
* @description:    认证相关个人信息
* @author:         xieqingyang
* @createDate:     2018/5/16 下午7:25
*/
public class AuthenticatePersonalInformationDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private String name;
    private String phone;
    private String idcard;
    private String familyAddress;
    private String workPhone;
    private String workAddress;
    private String familyPhone;
    private List<AuthenticateLinkmanDO> linkmanDOS;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getFamilyAddress() {
        return familyAddress;
    }

    public void setFamilyAddress(String familyAddress) {
        this.familyAddress = familyAddress;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public String getFamilyPhone() {
        return familyPhone;
    }

    public void setFamilyPhone(String familyPhone) {
        this.familyPhone = familyPhone;
    }

    public List<AuthenticateLinkmanDO> getLinkmanDOS() {
        return linkmanDOS;
    }

    public void setLinkmanDOS(List<AuthenticateLinkmanDO> linkmanDOS) {
        this.linkmanDOS = linkmanDOS;
    }
}
