package com.xyb.order.pc.deposit.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    非存管体系用户变更银行卡列表数据
 * @author:         xieqingyang
 * @createDate:     2018/7/20 下午7:16
*/
public class BankChangeVO implements IBaseModel {

    private static final long serialVersionUID = -1254468386390236639L;
    /**变更信息表ID*/
    private Long id;
    /**用户姓名*/
    private String clientName;
    /**身份证号*/
    private String idCard;
    /**手机号码*/
    private String phone;
    /**申请时间*/
    private Date applyTime;
    /**申请类型*/
    private String applyType;
    /**借款状态*/
    private String contractSettleState;
    /**变更状态描述*/
    private String bankChangestate;
    /**变更状态code*/
    private Long bankChangestateCode;
    /**处理人*/
    private String operationUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getApplyType() {
        return applyType;
    }

    public void setApplyType(String applyType) {
        this.applyType = applyType;
    }

    public String getContractSettleState() {
        return contractSettleState;
    }

    public void setContractSettleState(String contractSettleState) {
        this.contractSettleState = contractSettleState;
    }

    public String getBankChangestate() {
        return bankChangestate;
    }

    public void setBankChangestate(String bankChangestate) {
        this.bankChangestate = bankChangestate;
    }

    public Long getBankChangestateCode() {
        return bankChangestateCode;
    }

    public void setBankChangestateCode(Long bankChangestateCode) {
        this.bankChangestateCode = bankChangestateCode;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    @Override
    public String toString() {
        return "BankChangeVO{" +
                "id=" + id +
                ", clientName='" + clientName + '\'' +
                ", idCard='" + idCard + '\'' +
                ", phone='" + phone + '\'' +
                ", applyTime=" + applyTime +
                ", applyType='" + applyType + '\'' +
                ", contractSettleState='" + contractSettleState + '\'' +
                ", bankChangestate='" + bankChangestate + '\'' +
                ", bankChangestateCode=" + bankChangestateCode +
                ", operationUser='" + operationUser + '\'' +
                '}';
    }
}
