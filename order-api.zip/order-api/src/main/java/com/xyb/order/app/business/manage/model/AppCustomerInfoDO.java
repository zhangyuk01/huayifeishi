package com.xyb.order.app.business.manage.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:   APP客户经理客户信息MODEL  
* @author:        ZhangYu 
* @createDate:    2018/6/13
*/
public class AppCustomerInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;
	private String name;
	private String phone;
	private String idcard;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	
}
