package com.xyb.order.app.client.quickloan.service;

import java.math.BigDecimal;

/**
 * 
* @className : MaintainFullSignService.java
* @package : com.xyb.order.app.client.quickloan.service
* @description : sso维护满额标志service
* @author : zhanghao
* @createDate : 2018年12月27日下午2:17:37
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
public interface MaintainFullSignService {

	/**
	 * 
	     * method_name: maintainFullSign
	     * param: @param key
	     * param: @param dayLimit
	     * param: @param ruleSwitch
	     * param: @return
	     * describe: 维护满额标志方法
	     * creat_user: zhanghao
	     * creat_date: 2018年12月27日下午2:19:45
	 * @throws Exception 
	     *
	 */
	Boolean maintainFullSign(BigDecimal dayLimit, Long ruleSwitch) throws Exception;
}
