package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

public class DepositAccountStateVO implements IBaseModel {

	private static final long serialVersionUID = -1643379180029924591L;
	/**
	 * 是否开通存管户
	 */
	private Integer isOpen = 1;
	/**
	 * 是否绑卡
	 */
	private Integer isBind = 1;
	/**
	 * 是否签约
	 */
	private Integer isSign = 1;
	/**
	 * 合同是否生效
	 */
	private Integer isValid = 1;

	@Override
	public String toString() {
		return "DepositAccountStateVO [isOpen=" + isOpen + ", isBind=" + isBind + ", isSign=" + isSign + ", isValid="
				+ isValid + "]";
	}

	public Integer getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(Integer isOpen) {
		this.isOpen = isOpen;
	}

	public Integer getIsBind() {
		return isBind;
	}

	public void setIsBind(Integer isBind) {
		this.isBind = isBind;
	}

	public Integer getIsSign() {
		return isSign;
	}

	public void setIsSign(Integer isSign) {
		this.isSign = isSign;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

}
