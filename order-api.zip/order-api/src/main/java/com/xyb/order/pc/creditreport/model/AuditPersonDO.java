package com.xyb.order.pc.creditreport.model;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditPersonDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private String name;
	private String idcard;
	private String validTime;
	private String homeAllAddress;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getValidTime() {
		return validTime;
	}
	public void setValidTime(String validTime) {
		this.validTime = validTime;
	}
	public String getHomeAllAddress() {
		return homeAllAddress;
	}
	public void setHomeAllAddress(String homeAllAddress) {
		this.homeAllAddress = homeAllAddress;
	}

}
