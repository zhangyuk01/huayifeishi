/**
 * 
 */
package com.xyb.order.common.constant;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.common.constant
 * @description : TODO
 * @createDate : 2019年1月4日 下午2:11:39
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class TongDunDictConstant {
	/**一  学历*/
	/**1.高中以下*/
	public static final String PRE_HIGH_SCHOOL = "PRE_HIGH_SCHOOL";
	/**2.高中/中专*/
	public static final String HIGH_SCHOOL = "HIGH_SCHOOL";
	/**3.大专*/
	public static final String JUNIOR_COLLEGE = "JUNIOR_COLLEGE";
	/**4.本科*/
	public static final String UNDER_GRADUATE = "UNDER_GRADUATE";
	/**5.研究生*/
	public static final String POST_GRADUATE = "POST_GRADUATE";
	
	/**二 婚姻关系*/
	/**1.未婚*/
	public static final String SPINSTERHOOD = "SPINSTERHOOD";
	/**2.已婚*/
	public static final String MARRIED = "MARRIED";
	/**3.离异*/
	public static final String DIVORCED = "DIVORCED";
	/**4.丧偶*/
	public static final String WIDOWED = "WIDOWED";
	/**5.再婚*/
	public static final String REMARRY = "REMARRY";
	/**6.复婚*/
	public static final String REMARRY_FORMER = "REMARRY_FORMER";
	
	/**三 职位表*/
	/**1.高级资深人员*/
	public static final String ADVANCED = "ADVANCED";
	/**2.中级技术人员*/
	public static final String INTERMEDIATES = "INTERMEDIATES";
	/**3.初级、助理人员*/
	public static final String BEGINNERS = "BEGINNERS";
	/**4.见习专员*/
	public static final String PRACTICE = "PRACTICE";
	/**5.高层管理人员*/
	public static final String SENIOR = "SENIOR";
	/**6.中层管理人员*/
	public static final String MIDDLE = "MIDDLE";
	/**7.基层管理人员*/
	public static final String JUNIOR = "JUNIOR";
	/**8.普通员工*/
	public static final String NORMAL = "NORMAL";
	
	/**四 社会关系表*/
	/**1.父亲*/
	public static final String father = "father";
	/**2.母亲*/
	public static final String mother = "mother";
	/**3.配偶*/
	public static final String spouse = "spouse";
	/**4.子女*/
	public static final String child = "child";
	/**5.其他亲属*/
	public static final String other_relative = "other_relative";
	/**6.朋友*/
	public static final String friend = "friend";
	/**7.同事*/
	public static final String coworker = "coworker";
	/**8.其他*/
	public static final String others = "others";
}
