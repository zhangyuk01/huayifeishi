package com.xyb.order.pc.contract.service;


import com.xyb.order.common.currency.model.ResponseResult;
import com.xyb.order.pc.contract.model.ApplyRevokeDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.service
 * @description : 深圳借款撤销通知service
 * @createDate : 2018/5/10 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyRevokeService {
		
	/**
	 * 接收深圳借款撤销通知
	 */
	ResponseResult receiveApplyRevokeNotice(ApplyRevokeDTO applyRevokeDTO);
}
