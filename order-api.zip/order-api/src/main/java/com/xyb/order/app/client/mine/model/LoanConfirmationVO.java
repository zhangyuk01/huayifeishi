package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    借款确认信息
 * @author:         xieqingyang
 * @createDate:     2018/5/24 下午12:58
*/
public class LoanConfirmationVO implements IBaseModel {

    private static final long serialVersionUID = -2001185331906388241L;

    /**借款产品*/
    private String productName;
    /**借款金额*/
    private String amount;
    /**借款期限*/
    private String trim;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTrim() {
        return trim;
    }

    public void setTrim(String trim) {
        this.trim = trim;
    }

    @Override
    public String toString() {
        return "LoanConfirmationVO{" +
                "productName='" + productName + '\'' +
                ", amount='" + amount + '\'' +
                ", trim='" + trim + '\'' +
                '}';
    }
}
