package com.xyb.order.app.client.personinfo.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDTO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatcVO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDTO;

/**
 * @ClassName ApplyPersonService
 * @author ZhangYu
 * @date 2018年5月22号
 */
public interface ApplyPersonService {

	/**
	 * 获取个人基本基本信息
	 * 
	 * @return
	 */
	RestResponse getApplyPersonBaseInfo() throws Exception;

	/**
	 * 新增或者修改个人基本信息
	 * 
	 * @return
	 * @throws Exception
	 */
	RestResponse addOrUpdatePersonBaseInfo(ApplyPersonBaseInfoDTO applyPersonBaseInfoDTO) throws Exception;

	/**
	 * @description 个人联系人信息页面个人信息
	 * @author xieqingyang
	 * @CreatedDate 2018/5/30 下午6:45
	 * @Version 1.0
	 * @throws Exception
	 *             所有异常
	 */
	RestResponse getLinkPersonInfo() throws Exception;

	/**
	 * 获取个人联系列表信息信息
	 * 
	 * @return 返回通用格式数据 包含联系人列表所需信息（联系人ID，手机号，姓名）
	 * @throws Exception
	 *             所有异常
	 */
	RestResponse getApplyPersonRelationInfo(Long contactType) throws Exception;

	/**
	 * @description 根据联系人ID查询联系人信息
	 * @author xieqingyang
	 * @CreatedDate 2018/5/30 下午7:07
	 * @Version 1.0
	 * @return 返回联系人信息
	 * @throws Exception
	 */
	RestResponse getLinkManInfoById(Long id) throws Exception;

	/**
	 * 新增或修改个人联系人信息
	 * 
	 * @return
	 * @throws Exception
	 */
	RestResponse saveOrUpdateRelationInfo(LinkManRelationInfoDTO linkManRelationInfoDTO) throws Exception;

	/**
	 * 新增或修改个人联系人信息页的个人信息
	 * 
	 * @return
	 * @throws Exception
	 */
	RestResponse addOrUpdatePersonRelationInfo(PersonBaseRelationInfoDTO personBaseRelationInfoDTO) throws Exception;

	/**
	 * 保存电话簿
	 * 
	 * @param phoneBookBO
	 * @return
	 * @throws Exception
	 */
	RestResponse addPhoneBookInfos(PhoneBookBO phoneBookBO) throws Exception;

	/**
	 * 判断是否已上传过电话簿
	 * 
	 * @param bean
	 * @return
	 */
	RestResponse getPhoneBookAddressBatch(PhoneBookBatcVO phoneBookBatcVO) throws Exception;
	/**
	 * 判断该联系人是否新增
	 * 
	 * @param phoneBookDTO
	 * @return
	 */
	RestResponse queryAndAddPhoneBookInfo(PhoneBookDTO phoneBookDTO) throws Exception;

}
