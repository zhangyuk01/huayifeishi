package com.xyb.order.common.util;

/**
 * @author : houlvshuang
 * @projectName : util
 * @package : com.xyb.order.common.uti
 * @description : 生成唯一数= 时间戳+8位随机数+随机6位字母数字
 * @createDate : 2017/12/14 16:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class TimestampIDUtil {
    private static byte[] lock = new byte[0];  
    
    // 位数，默认是8位  
    private final static long w = 100000000;  
  
    public static String createID() {  
        long r = 0;  
        synchronized (lock) {  
            r = (long) ((Math.random() + 1) * w);  
        }  
  
        return System.currentTimeMillis() + String.valueOf(r).substring(1) + ShareCodeUtil.generateRandomStr(6);  
    }  
}
