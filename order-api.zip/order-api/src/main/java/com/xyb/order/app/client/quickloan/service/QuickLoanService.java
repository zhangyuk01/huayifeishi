package com.xyb.order.app.client.quickloan.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyInfoDTO;

/**
 * 速贷
 * 
 * @author qiaoJinLong
 * @date 2018年12月18日
 */
public interface QuickLoanService {

	/**
	 * 保存/修改申请信息
	 * 
	 * @param applyInfo
	 * @return
	 * @throws Exception
	 */
	RestResponse saveOrUpdateApplyInfo(QuickLoanApplyInfoDTO applyInfo) throws Exception;

	RestResponse getApplyInfo() throws Exception;

}
