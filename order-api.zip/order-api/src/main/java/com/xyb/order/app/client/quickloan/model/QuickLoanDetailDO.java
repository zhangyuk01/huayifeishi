package com.xyb.order.app.client.quickloan.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author luyang
 * @ClassName QuickLoanDetailDO
 * @description 优信借进件数据明细
 * @time 2018/12/21 11:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class QuickLoanDetailDO implements IBaseModel {

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 借款人ID
     */
    private Long clientId;
    /**
     * 借款人姓名
     */
    private String clientName;
    /**
     * 营业部ID
     */
    private Long orgId;
    /**
     * 产品
     */
    private Long productId;
    /**
     * 业务类型（2848）
     */
    private Long businessType;
    /**
     * 业务金额
     */
    private BigDecimal businessMoney;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Long createUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Long businessType) {
        this.businessType = businessType;
    }

    public BigDecimal getBusinessMoney() {
        return businessMoney;
    }

    public void setBusinessMoney(BigDecimal businessMoney) {
        this.businessMoney = businessMoney;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    @Override
    public String toString() {
        return "QuickLoanDetailDO{" +
                "id=" + id +
                ", clientId=" + clientId +
                ", clientName='" + clientName + '\'' +
                ", orgId=" + orgId +
                ", productId=" + productId +
                ", businessType=" + businessType +
                ", businessMoney=" + businessMoney +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                '}';
    }
}