package com.xyb.order.pc.creditreport.model;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditOtherMaterialDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long applyId; //申请单ID
	private String otherMaterialRemark;//其他材料说明
	
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getOtherMaterialRemark() {
		return otherMaterialRemark;
	}
	public void setOtherMaterialRemark(String otherMaterialRemark) {
		this.otherMaterialRemark = otherMaterialRemark;
	}
	
	

}
