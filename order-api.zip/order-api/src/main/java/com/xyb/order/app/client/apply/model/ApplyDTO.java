package com.xyb.order.app.client.apply.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.NotNull;
import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
* @description:   App借款申请MODEL  
* @author:        ZhangYu 
* @createDate:    2018/5/18 
*/
public class ApplyDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	private Long id; //申请单ID
	private Long mainId; //主表ID
	private Long applyId;// 申请单ID
	private String applyNum;//申请单编号
	private Long managerId;//客户经理ID
	private String manageName;//客户经理姓名
	private Long clientId;//客户ID
	private String clientIdCard;//客户身份证号
	private String ClientRealName;//客户真实姓名
	private Integer state;//主表状态

	@NotNull(message ="申请借款金额不能为空")
	private BigDecimal expectMoney; //申请借款金额
	@NotNull(message = "借款用途信息不能为空")
	private Long borrowDescCode;//借款用途
	@NotNull(message="借款期数不能为空")
	private Integer expectTerm;//借款期数
	@NotNull(message ="营业部信息不能为空")
	private Long storeOrgId;//营业部ID
	@NotNull(message = "申请产品ID不能为空")
	private Long expectProductId;//申请产品ID
	
	@JsonIgnore
	private Long teamManagerId;
	@JsonIgnore
	private String teamManagerUname; 
	@JsonIgnore
	private Long teamOrgId;
	@JsonIgnore
	private String teamOrgName;
	@JsonIgnore
	private Long isLoop;

	@JsonIgnore
	private Date createTime; //创建时间
	@JsonIgnore
	private Long createUser; //创建人 
	@JsonIgnore
	private Date modifyTime; //修改时间
	@JsonIgnore
	private Long modifyUser; //修改人
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public Long getClientId() {
		return clientId;
	}
	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
	public String getClientIdCard() {
		return clientIdCard;
	}
	public void setClientIdCard(String clientIdCard) {
		this.clientIdCard = clientIdCard;
	}
	public String getClientRealName() {
		return ClientRealName;
	}
	public void setClientRealName(String clientRealName) {
		ClientRealName = clientRealName;
	}
	public Long getManagerId() {
		return managerId;
	}
	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}
	public String getManageName() {
		return manageName;
	}
	public void setManageName(String manageName) {
		this.manageName = manageName;
	}
	public Long getExpectProductId() {
		return expectProductId;
	}
	public void setExpectProductId(Long expectProductId) {
		this.expectProductId = expectProductId;
	}
	public BigDecimal getExpectMoney() {
		return expectMoney;
	}
	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}
	public Long getBorrowDescCode() {
		return borrowDescCode;
	}
	public void setBorrowDescCode(Long borrowDescCode) {
		this.borrowDescCode = borrowDescCode;
	}
	public Integer getExpectTerm() {
		return expectTerm;
	}
	public void setExpectTerm(Integer expectTerm) {
		this.expectTerm = expectTerm;
	}
	public Long getStoreOrgId() {
		return storeOrgId;
	}
	public void setStoreOrgId(Long storeOrgId) {
		this.storeOrgId = storeOrgId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Long getTeamManagerId() {
		return teamManagerId;
	}
	public void setTeamManagerId(Long teamManagerId) {
		this.teamManagerId = teamManagerId;
	}
	public String getTeamManagerUname() {
		return teamManagerUname;
	}
	public void setTeamManagerUname(String teamManagerUname) {
		this.teamManagerUname = teamManagerUname;
	}
	public Long getTeamOrgId() {
		return teamOrgId;
	}
	public void setTeamOrgId(Long teamOrgId) {
		this.teamOrgId = teamOrgId;
	}

	public String getTeamOrgName() {
		return teamOrgName;
	}

	public void setTeamOrgName(String teamOrgName) {
		this.teamOrgName = teamOrgName;
	}
	public Long getIsLoop() {
		return isLoop;
	}
	public void setIsLoop(Long isLoop) {
		this.isLoop = isLoop;
	}
}
