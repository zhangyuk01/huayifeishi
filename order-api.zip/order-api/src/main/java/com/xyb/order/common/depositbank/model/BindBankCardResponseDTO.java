package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * 绑卡网关接口推送深圳数据model
 * @author         luyang
 * @date           2018/11/23 15:10 PM
 */
public class BindBankCardResponseDTO implements IBaseModel {

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 系统ID 北京2001 深圳3001
     */
    @SignField(order = 2)
    private String sysId;
    /**
     * 申请流水号，用于交易的唯一性标识，32(位数)
     */
    @SignField(order = 3)
    private String out_serial_no;
    /**
     * 订单号
     */
    @SignField(order = 4)
    private String order_id;
    /**
     *  页面跳转url(点击跳转到银行页面)
     */
    @SignField(order = 5)
    private String url;

    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "BindBankCardResponseDTO{" +
                "sysId='" + sysId + '\'' +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", order_id='" + order_id + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
