package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;


/**
 * Created by xieqingyang on 2018/4/27.
 * main表日志
 */
public class MainLogDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private Long mainId;// -- 主表ID
    private Integer businessState;// -- 状态ID
    private String businessStateName;// -- 状态名称
    private Long modifyUser;// -- 操作人ID
    private String modifyUserName;// -- 操作人名称

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Integer getBusinessState() {
        return businessState;
    }

    public void setBusinessState(Integer businessState) {
        this.businessState = businessState;
    }

    public String getBusinessStateName() {
        return businessStateName;
    }

    public void setBusinessStateName(String businessStateName) {
        this.businessStateName = businessStateName;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getModifyUserName() {
        return modifyUserName;
    }

    public void setModifyUserName(String modifyUserName) {
        this.modifyUserName = modifyUserName;
    }
}
