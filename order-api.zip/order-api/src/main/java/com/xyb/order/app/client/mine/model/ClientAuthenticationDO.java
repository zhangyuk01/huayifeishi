package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
* @description:    客户认证信息
* @author:         xieqingyang
* @createDate:     2018/5/14 下午3:07
*/
public class ClientAuthenticationDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**客户信息表id*/
    private Long id;
    /**身份是否认证 Y:是  N：否*/
    private String certificationState;
    /**个人信息采集使用协议是否签约完成*/
    private Long agreementCompleted;
    /**身份证号*/
    private String idCard;
    /**身份证有效期止*/
    private Date idCardEndTime;
    /**身份证上的住址*/
    private String address;
    /**姓名*/
    private String name;
    /**法大大用户ID*/
    private String customerId;
    /**用户可再次进件时间*/
    private Date allowableEntryTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCertificationState() {
        return certificationState;
    }

    public void setCertificationState(String certificationState) {
        this.certificationState = certificationState;
    }

    public Long getAgreementCompleted() {
        return agreementCompleted;
    }

    public void setAgreementCompleted(Long agreementCompleted) {
        this.agreementCompleted = agreementCompleted;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Date getIdCardEndTime() {
        return idCardEndTime;
    }

    public void setIdCardEndTime(Date idCardEndTime) {
        this.idCardEndTime = idCardEndTime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Date getAllowableEntryTime() {
        return allowableEntryTime;
    }

    public void setAllowableEntryTime(Date allowableEntryTime) {
        this.allowableEntryTime = allowableEntryTime;
    }
    
    @Override
    public String toString() {
        return "ClientAuthenticationDO{" +
                "id=" + id +
                ", certificationState='" + certificationState + '\'' +
                ", agreementCompleted=" + agreementCompleted +
                ", idCard='" + idCard + '\'' +
                ", idCardEndTime=" + idCardEndTime +
                ", address='" + address + '\'' +
                ", name='" + name + '\'' +
                ", customerId='" + customerId + '\'' +
                ", allowableEntryTime=" + allowableEntryTime +
                '}';
    }
}
