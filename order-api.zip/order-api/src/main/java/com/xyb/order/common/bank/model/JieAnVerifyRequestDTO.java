package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    验证请求参数
 * @author:         xieqingyang
 * @createDate:     2018/7/19 上午11:20
*/
public class JieAnVerifyRequestDTO implements IBaseModel {

    private static final long serialVersionUID = 4729470557332017704L;
    /**01*/
    private String versionId;
    /**UTF-8*/
    private String chrSet;
    /**客户号*/
    private String custId;
    /**订单号，由商户系统产生的交易请求唯一标识码，不 能含有中文字符。 组成规则:商户简称+YYYYMMDD+流水号*/
    private String ordId;
    /**STD_VERI*/
    private String transType;
    /**业务类型，可以为空，由商户自己定义，用于区分订 单类型*/
    private String busiType;
    /**商户私有域，可以为空，由商户自己定义，平台原样 返回*/
    private String merPriv;
    /**返回 URL 地址，可以为空，如果不为空，平台将交易 响应异步通过该地址返回*/
    private String retUrl;
    /**Json 字符串，包含和交易相关的请求数据*/
    private String jsonStr;
    /**签名串*/
    private String macStr;

    public String getVersionId() {
        return versionId;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getChrSet() {
        return chrSet;
    }

    public void setChrSet(String chrSet) {
        this.chrSet = chrSet;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getOrdId() {
        return ordId;
    }

    public void setOrdId(String ordId) {
        this.ordId = ordId;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getBusiType() {
        return busiType;
    }

    public void setBusiType(String busiType) {
        this.busiType = busiType;
    }

    public String getMerPriv() {
        return merPriv;
    }

    public void setMerPriv(String merPriv) {
        this.merPriv = merPriv;
    }

    public String getRetUrl() {
        return retUrl;
    }

    public void setRetUrl(String retUrl) {
        this.retUrl = retUrl;
    }

    public String getJsonStr() {
        return jsonStr;
    }

    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }

    public String getMacStr() {
        return macStr;
    }

    public void setMacStr(String macStr) {
        this.macStr = macStr;
    }

    @Override
    public String toString() {
        return "JieAnVerifyRequestDTO{" +
                "versionId='" + versionId + '\'' +
                ", chrSet='" + chrSet + '\'' +
                ", custId='" + custId + '\'' +
                ", ordId='" + ordId + '\'' +
                ", transType='" + transType + '\'' +
                ", busiType='" + busiType + '\'' +
                ", merPriv='" + merPriv + '\'' +
                ", retUrl='" + retUrl + '\'' +
                ", jsonStr='" + jsonStr + '\'' +
                ", macStr='" + macStr + '\'' +
                '}';
    }
}
