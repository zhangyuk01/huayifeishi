package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;
import java.util.Objects;

/**
 * 存管接口调用日志表
 * @author         xieqingyang
 * @date           2018/11/23 10:18 AM
*/
public class DepositAccountInterfaceLogDO implements IBaseModel {

    private static final long serialVersionUID = 2578932546801639625L;
    /**主键ID*/
    private Long id;
    /**存管账户ID*/
    private Long depositAccountId;
    /**接口名称*/
    private String interfaceName;
    /**调用信息*/
    private String requestMsg;
    /**响应信息*/
    private String responseMsg;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDepositAccountId() {
        return depositAccountId;
    }

    public void setDepositAccountId(Long depositAccountId) {
        this.depositAccountId = depositAccountId;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getRequestMsg() {
        return requestMsg;
    }

    public void setRequestMsg(String requestMsg) {
        this.requestMsg = requestMsg;
    }

    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DepositAccountInterfaceLogDO that = (DepositAccountInterfaceLogDO) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(depositAccountId, that.depositAccountId) &&
                Objects.equals(interfaceName, that.interfaceName) &&
                Objects.equals(requestMsg, that.requestMsg) &&
                Objects.equals(responseMsg, that.responseMsg) &&
                Objects.equals(createTime, that.createTime) &&
                Objects.equals(createUser, that.createUser);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, depositAccountId, interfaceName, requestMsg, responseMsg, createTime, createUser);
    }

    @Override
    public String toString() {
        return "DepositAccountInterfaceLogDO{" +
                "id=" + id +
                ", depositAccountId=" + depositAccountId +
                ", interfaceName='" + interfaceName + '\'' +
                ", requestMsg='" + requestMsg + '\'' +
                ", responseMsg='" + responseMsg + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                '}';
    }
}
