package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * Created by xieqingyang on 2018/4/25.
 * 材料补充列表查询条件
 */
public class MaterialSupplementListDO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private Long mainId;// -- 主表ID
    private Long applyId;// -- 申请单ID
    private String applyNum;// -- 申请编号
    private String clientName;// -- 客户姓名
    private String idCard;// -- 身份证号
    private String product;// -- 申请产品
    private Date submitApplyToAuditTime;// -- 申请日期
    private Date requestDate;// -- 申请材料补充时间
    private String teamOrgName;// -- 销售团队
    /**系统审核结果*/
    private String auditResult;

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getApplyNum() {
        return applyNum;
    }

    public void setApplyNum(String applyNum) {
        this.applyNum = applyNum;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Date getSubmitApplyToAuditTime() {
        return submitApplyToAuditTime;
    }

    public void setSubmitApplyToAuditTime(Date submitApplyToAuditTime) {
        this.submitApplyToAuditTime = submitApplyToAuditTime;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public String getTeamOrgName() {
        return teamOrgName;
    }

    public void setTeamOrgName(String teamOrgName) {
        this.teamOrgName = teamOrgName;
    }

    public String getAuditResult() {
        return auditResult;
    }

    public void setAuditResult(String auditResult) {
        this.auditResult = auditResult;
    }
}
