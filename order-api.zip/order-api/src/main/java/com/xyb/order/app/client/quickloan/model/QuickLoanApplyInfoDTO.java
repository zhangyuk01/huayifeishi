package com.xyb.order.app.client.quickloan.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 速贷申请信息
 * 
 * @author qiaoJinLong
 * @date 2018年12月20日
 */
public class QuickLoanApplyInfoDTO implements IBaseModel {
	@Override
	public String toString() {
		return "QuickLoanApplyInfoDTO [jobInfo=" + jobInfo + ", personInfo=" + personInfo + ", contactInfo="
				+ contactInfo + "]";
	}

	private static final long serialVersionUID = 1L;
	/**
	 * 工作信息
	 */
	private QuickLoanApplyJobDTO jobInfo;
	/**
	 * 个人信息
	 */
	private QuickLoanApplyPersonInfoDTO personInfo;
	/**
	 * 联系信息
	 */
	private QuickLoanContactInfoDO contactInfo;

	public QuickLoanApplyJobDTO getJobInfo() {
		return jobInfo;
	}

	public void setJobInfo(QuickLoanApplyJobDTO jobInfo) {
		this.jobInfo = jobInfo;
	}

	public QuickLoanApplyPersonInfoDTO getPersonInfo() {
		return personInfo;
	}

	public void setPersonInfo(QuickLoanApplyPersonInfoDTO personInfo) {
		this.personInfo = personInfo;
	}

	public QuickLoanContactInfoDO getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(QuickLoanContactInfoDO contactInfo) {
		this.contactInfo = contactInfo;
	}

}
