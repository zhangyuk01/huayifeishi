package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 
 * @author qiaoJinLong
 * @date 2018年9月19日
 */
public class ApplyClientInfoDTO implements IBaseModel {

	private static final long serialVersionUID = 1L;

	private Long id;

	private Integer loanQty;// 成功借款次数

	private Double profitBalance;// 分润余额

	private Long modifyUser;// 修改人

	@Override
	public String toString() {
		return "ApplyClientInfoDTO [id=" + id + ", loanQty=" + loanQty + ", profitBalance=" + profitBalance
				+ ", modifyUser=" + modifyUser + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getLoanQty() {
		return loanQty;
	}

	public void setLoanQty(Integer loanQty) {
		this.loanQty = loanQty;
	}

	public Double getProfitBalance() {
		return profitBalance;
	}

	public void setProfitBalance(Double profitBalance) {
		this.profitBalance = profitBalance;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

}