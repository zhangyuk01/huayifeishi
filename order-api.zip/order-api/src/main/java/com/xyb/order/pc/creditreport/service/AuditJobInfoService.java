package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditJobDTO;

/**
 * @ClassName AuditJobInfoService
 * @author ZhangYu
 * @date 2018年5月7号
 */
public interface AuditJobInfoService {

	/**
	 * 根据申请单ID查询工作证明信息 
	 * @param applyId
	 * @return
	 */
	RestResponse queryAuditJobInfo(Long applyId)throws Exception;

	/**
	 * 更新或者添加工作证明信息 
	 * @param auditJobDTO
	 * @return
	 */
	RestResponse updateOrAddAuditJobInfo(AuditJobDTO auditJobDTO)throws Exception;

}
