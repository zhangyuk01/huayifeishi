package com.xyb.order.app.client.personalcenter.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDTO;
import com.xyb.order.app.client.personalcenter.model.RewardDistributionDTO;
import com.xyb.order.common.message.model.SendMessageVerificationDTO;

/**
 * 我的/个人中心
 * 
 * @author qiaoJinLong
 * @date 2018年9月13日
 */
public interface PersonalCenterService {

	/**
	 * 获取个人信息、是否认证 、邀请人
	 * 
	 * @return
	 * @throws Exception
	 */
	public RestResponse getPersonalInfo() throws Exception;

	/**
	 * 发送短信
	 * 
	 * @param phone
	 * @return
	 */
	public RestResponse SendMessageVerification(SendMessageVerificationDTO messageDTO) throws Exception;

	/**
	 * 添加推荐人
	 * 
	 * @param phone
	 * @return
	 */
	public RestResponse addReferee(String phone) throws Exception;

	/**
	 * 获取推荐人和好友
	 * 
	 * @return
	 */
	RestResponse getMyFriendsAndReferee() throws Exception;

	/**
	 * 获取疑难解答列表
	 * 
	 * @param num
	 * @return
	 * @throws Exception
	 */
	public RestResponse getProblem(Integer num) throws Exception;

	/**
	 * 更新点击数
	 * 
	 * @param id
	 * @return
	 */
	public RestResponse updateClicks(Long id) throws Exception;

	/**
	 * 更新推荐奖励 节点 放款成功
	 * 
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	public RestResponse updateUserRefereeReward(RewardDistributionDTO dto) throws Exception;

	/**
	 * 更新质保奖励 节点 正常回款
	 * 
	 * @param dto
	 * @throws Exception
	 */
	public RestResponse updateUserQualityReward(RewardDistributionDTO dto) throws Exception;

	/**
	 * 查看余额
	 * 
	 * @return
	 */
	public RestResponse queryBalance() throws Exception;

	/**
	 * 查看流水
	 * 
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	public RestResponse queryClientProfitBalanceDetail(ClientProfitBalanceDetailDTO dto) throws Exception;

	/**
	 * 获取分享链接
	 * 
	 * @return
	 */
	public RestResponse getShareUrl() throws Exception;

	/**
	 * 是否显示设置推荐人
	 * 
	 * @return
	 */

	public RestResponse querywhetherShowSetReferee() throws Exception;
}
