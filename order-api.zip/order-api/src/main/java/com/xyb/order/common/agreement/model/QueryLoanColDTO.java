package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * 查询借款协议model
 * @author         xieqingyang
 * @date           2018/10/18 4:11 PM
*/
public class QueryLoanColDTO implements IBaseModel {

    private static final long serialVersionUID = -3797294500188887748L;
    /**系统id*/
    @SignField(order = 0)
    private Long sysId;
    /**北京标的id*/
    @SignField(order = 1)
    private String applyId;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    @Override
    public String toString() {
        return "QueryLoanColDTO{" +
                "sysId=" + sysId +
                ", applyId='" + applyId + '\'' +
                '}';
    }
}
