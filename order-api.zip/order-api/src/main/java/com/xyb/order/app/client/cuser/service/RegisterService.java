package com.xyb.order.app.client.cuser.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.cuser.model.ClientUserDTO;

/**
* @description:    C端app用户注册、忘记密码功能
* @author:         xieqingyang
* @createDate:     2018/5/9 下午2:10
*/
public interface RegisterService {

    /**
    * C端app用户注册
    * @author      xieqingyang
    * @param clientUserDTO
    * @return
    * @exception
    * @date        2018/5/9 下午2:46
    */
    RestResponse register(ClientUserDTO clientUserDTO)throws Exception;
}
