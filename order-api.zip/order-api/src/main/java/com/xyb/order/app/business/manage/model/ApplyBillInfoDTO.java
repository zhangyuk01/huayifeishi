package com.xyb.order.app.business.manage.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private String searchConditon;
	private Integer page;

	public String getSearchConditon() {
		return searchConditon;
	}
	public void setSearchConditon(String searchConditon) {
		this.searchConditon = searchConditon;
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}

}
