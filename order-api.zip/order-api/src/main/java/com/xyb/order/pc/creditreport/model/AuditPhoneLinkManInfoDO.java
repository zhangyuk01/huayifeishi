package com.xyb.order.pc.creditreport.model;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditPhoneLinkManInfoDO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	private Long id; //主键ID
	private Long custId;//客户ID
	private Long applyPhoneId;//通话详单ID
	private Long linkManId;//联系人主键ID
	private String linkManName;//联系人姓名
	private String linkManPhone;//联系人电话
	private Long relationCode;//联系人关系代码
	private String relationCodeStr; 
	private Integer month1; //当前月
	private Integer month2;//当前月-1
	private Integer month3;//当前月-2
	private Integer month1Qty;//第一个月通话次数
	private Integer month2Qty;//第二个月通话次数
	private Integer month3Qty;//第三个月通话次数
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getApplyPhoneId() {
		return applyPhoneId;
	}
	public void setApplyPhoneId(Long applyPhoneId) {
		this.applyPhoneId = applyPhoneId;
	}
	public Long getLinkManId() {
		return linkManId;
	}
	public void setLinkManId(Long linkManId) {
		this.linkManId = linkManId;
	}
	public String getLinkManName() {
		return linkManName;
	}
	public Integer getMonth1Qty() {
		return month1Qty;
	}
	public void setMonth1Qty(Integer month1Qty) {
		this.month1Qty = month1Qty;
	}
	public Integer getMonth2Qty() {
		return month2Qty;
	}
	public void setMonth2Qty(Integer month2Qty) {
		this.month2Qty = month2Qty;
	}
	public Integer getMonth3Qty() {
		return month3Qty;
	}
	public void setMonth3Qty(Integer month3Qty) {
		this.month3Qty = month3Qty;
	}
	public void setLinkManName(String linkManName) {
		this.linkManName = linkManName;
	}
	public Long getRelationCode() {
		return relationCode;
	}
	public void setRelationCode(Long relationCode) {
		this.relationCode = relationCode;
	}
	public String getRelationCodeStr() {
		return relationCodeStr;
	}
	public void setRelationCodeStr(String relationCodeStr) {
		this.relationCodeStr = relationCodeStr;
	}
	public String getLinkManPhone() {
		return linkManPhone;
	}
	public void setLinkManPhone(String linkManPhone) {
		this.linkManPhone = linkManPhone;
	}
	public Integer getMonth1() {
		return month1;
	}
	public void setMonth1(Integer month1) {
		this.month1 = month1;
	}
	public Integer getMonth2() {
		return month2;
	}
	public void setMonth2(Integer month2) {
		this.month2 = month2;
	}
	public Integer getMonth3() {
		return month3;
	}
	public void setMonth3(Integer month3) {
		this.month3 = month3;
	}
	
}
