package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.client.mine.model
 * @description :
 * @createDate : 2018/8/23 11:49
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ReferrerInfoVO implements IBaseModel{

    private static final long serialVersionUID = -8449131037596653682L;

    /** 推荐人姓名 */
    private String  referrerName;
    /** 推荐人电话 */
    private String  referrerPhone;

    public String getReferrerName() {
        return referrerName;
    }

    public void setReferrerName(String referrerName) {
        this.referrerName = referrerName;
    }

    public String getReferrerPhone() {
        return referrerPhone;
    }

    public void setReferrerPhone(String referrerPhone) {
        this.referrerPhone = referrerPhone;
    }

    @Override
    public String toString() {
        return "ReferrerInfoVO{" +
                "referrerName='" + referrerName + '\'' +
                ", referrerPhone='" + referrerPhone + '\'' +
                '}';
    }
}
