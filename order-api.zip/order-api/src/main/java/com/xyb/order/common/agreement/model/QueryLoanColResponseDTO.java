package com.xyb.order.common.agreement.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.List;

/**
 * 查询借款协议响应模型
 * @author         xieqingyang
 * @date           2018/10/18 5:11 PM
*/
public class QueryLoanColResponseDTO implements IBaseModel {

    private static final long serialVersionUID = 1262261330671297643L;
    @SignField(order = 0)
    private Long sysId;
    /**标的申请ID*/
    @SignField(order = 1)
    private String applyId;
    /**应传协议份数*/
    @SignField(order = 2)
    private Integer expCount;
    /**实际传协议份数*/
    @SignField(order = 3)
    private Integer actCount;
    @SignField(order = 4)
    private List<ContractBriefDTO> loanContracts;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    public Integer getExpCount() {
        return expCount;
    }

    public void setExpCount(Integer expCount) {
        this.expCount = expCount;
    }

    public Integer getActCount() {
        return actCount;
    }

    public void setActCount(Integer actCount) {
        this.actCount = actCount;
    }

    public List<ContractBriefDTO> getLoanContracts() {
        return loanContracts;
    }

    public void setLoanContracts(List<ContractBriefDTO> loanContracts) {
        this.loanContracts = loanContracts;
    }

    @Override
    public String toString() {
        return "QueryLoanColResponseDTO{" +
                "sysId=" + sysId +
                ", applyId='" + applyId + '\'' +
                ", expCount=" + expCount +
                ", actCount=" + actCount +
                ", loanContracts=" + loanContracts +
                '}';
    }
}
