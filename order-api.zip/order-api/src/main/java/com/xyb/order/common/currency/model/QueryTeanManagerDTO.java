package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    根据营业部查询团队经理方法
 * @author:         xieqingyang
 * @createDate:     2018/7/17 下午3:08
*/
public class QueryTeanManagerDTO implements IBaseModel {

    private static final long serialVersionUID = 836749537906613671L;
    /**销售团队ID*/
    private Long teamOrgId;
    /**进件机构ID*/
    private Long storeOrgId;

    public Long getTeamOrgId() {
        return teamOrgId;
    }

    public void setTeamOrgId(Long teamOrgId) {
        this.teamOrgId = teamOrgId;
    }

    public Long getStoreOrgId() {
        return storeOrgId;
    }

    public void setStoreOrgId(Long storeOrgId) {
        this.storeOrgId = storeOrgId;
    }

    @Override
    public String toString() {
        return "QueryTeanManagerDTO{" +
                "teamOrgId=" + teamOrgId +
                ", storeOrgId=" + storeOrgId +
                '}';
    }
}
