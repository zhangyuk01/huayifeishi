package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import java.util.Date;

/**
 * @description:    银行卡信息
 * @author:         xieqingyang
 * @createDate:     2018/6/8 上午10:28
*/
public class ClientBankInFoDO implements IBaseModel {
    private static final long serialVersionUID = -1648143607246089261L;
    /**主键ID*/
    private Long id;
    /**存管账户表(t_deposit_account_statement_info)ID*/
    private Long depositId;
    /**开户人姓名*/
    private String bankRealName;
    /**开户人身份证号*/
    private String bankIdcard;
    /**银行卡号*/
    private String bankNum;
    /**银行名称*/
    private String bankName;
    /**开户支行*/
    private String bankDeposit;
    /**开户行总行*/
    private String bankcardBankname;
    /**银行预留手机号*/
    private String phone;
    /**t_xyb_bank_code的type*/
    private Integer bankId;
    /**有效状态(大类2687)*/
    private Long state;
    /**银行卡描述*/
    private String description;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDepositId() {
        return depositId;
    }

    public void setDepositId(Long depositId) {
        this.depositId = depositId;
    }

    public String getBankRealName() {
        return bankRealName;
    }

    public void setBankRealName(String bankRealName) {
        this.bankRealName = bankRealName;
    }

    public String getBankIdcard() {
        return bankIdcard;
    }

    public void setBankIdcard(String bankIdcard) {
        this.bankIdcard = bankIdcard;
    }

    public String getBankNum() {
        return bankNum;
    }

    public void setBankNum(String bankNum) {
        this.bankNum = bankNum;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankDeposit() {
        return bankDeposit;
    }

    public void setBankDeposit(String bankDeposit) {
        this.bankDeposit = bankDeposit;
    }

    public String getBankcardBankname() {
        return bankcardBankname;
    }

    public void setBankcardBankname(String bankcardBankname) {
        this.bankcardBankname = bankcardBankname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getBankId() {
        return bankId;
    }

    public void setBankId(Integer bankId) {
        this.bankId = bankId;
    }

    public Long getState() {
        return state;
    }

    public void setState(Long state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "ClientBankInFoDO{" +
                "id=" + id +
                ", depositId=" + depositId +
                ", bankRealName='" + bankRealName + '\'' +
                ", bankIdcard='" + bankIdcard + '\'' +
                ", bankNum='" + bankNum + '\'' +
                ", bankName='" + bankName + '\'' +
                ", bankDeposit='" + bankDeposit + '\'' +
                ", bankcardBankname='" + bankcardBankname + '\'' +
                ", phone='" + phone + '\'' +
                ", bankId=" + bankId +
                ", state=" + state +
                ", description='" + description + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}
