package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;
import javax.validation.constraints.NotNull;

/**
* @description:    申请借款传入参数
* @author:         xieqingyang
* @createDate:     2018/5/15 下午8:47
*/
public class ApplyLoanDTO implements IBaseModel {
    private static final long serialVersionUID = 1L;

    @NotNull(message = "产品ID不能为空")
    private Long productId;
    private String city;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
