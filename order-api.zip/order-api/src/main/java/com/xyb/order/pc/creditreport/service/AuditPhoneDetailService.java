package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditPhoneDTO;

/**
 * @ClassName AuditPhoneDetailService
 * @author ZhangYu
 * @date 2018年4月28号
 */
public interface AuditPhoneDetailService {

	/**
	 * 查询通话信息详单 
	 * @param applyId
	 * @return
	 */
	public RestResponse queryPhoneDetailInfoByApplyId(Long applyId)throws Exception;
	

	/**
	 * 暂存通话详单信息 
	 * @param auditPhoneDTO
	 * @return
	 */
	public RestResponse auditPhoneInfoSave(AuditPhoneDTO auditPhoneDTO)throws Exception;

}
