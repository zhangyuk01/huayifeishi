package com.xyb.order.pc.apply.already.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.apply.already.model
 * @description : 申请已办列表VO model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyListVO implements IBaseModel {

	private static final long serialVersionUID = 8402804057560762433L;

	/**申请编号*/
	private String applyNum;
	/**申请id*/
	private Long applyId;
	/**主表id*/
	private Long mainId;
	/**产品id*/
	private Long productId;
	/**客戶姓名*/
	private String custName;
	/**手机号*/
	private String phone;
	/**身份证号*/
	private String idCard;
	/**销售团队*/
	private String saleTeamName;
	/**销售人员*/
	private String saleUserName;
	/**客服人员*/
	private String serviceName;
	/**申请产品*/
	private String applyProductName;
	/**是否循环贷*/
	private String isLoopName;
	/**是否签约前核验*/
	private String isSignCheck;
	/**当前状态*/
	private String stateName;
	@JsonIgnore
	private Integer stateCode;
	/**进件时间*/
	private Date incomeTime;
	/**审批时间*/
	private Date auditEndTime;
	/**一级授信产品*/
	private String agreeProductName;
	/**一级授信金额*/
	private BigDecimal agreeAmount;
	/**一级授信期数*/
	private int agreeProductLimit;
	/**费率*/
	private String serviceProportion;
	/**是否拒贷*/
	private String isRefuse;
	/**拒贷原因*/
	private String refuseReason;
	/**合同生效日期*/
	private Date contractTakeEffectTime;
	/**终极授信金额*/
	private BigDecimal contractAmount;
	/**月还金额*/
	private BigDecimal monthReturnAmount;
	/**还款日*/
	private int repayDay;
	/**是否已结清*/
	private String isSettle;
	/**复议次数*/
	private int reconsiderationQty;
	/**第一次复议日期*/
	private Date oneReconsiderationTime;
	/**第二次复议日期*/
	private Date towReconsiderationTime;
	/**进件机构名称*/
	private String orgName;
	/**进件机构*/
	private Long orgId;
	/**外访类型*/
	private String visitTypeName;

	/**推荐人姓名*/
	private String recommender;
	/**确认金额*/
	private BigDecimal confirmAmout;

	public String getApplyNum() {
		return applyNum;
	}
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getSaleTeamName() {
		return saleTeamName;
	}
	public void setSaleTeamName(String saleTeamName) {
		this.saleTeamName = saleTeamName;
	}
	public String getSaleUserName() {
		return saleUserName;
	}
	public void setSaleUserName(String saleUserName) {
		this.saleUserName = saleUserName;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getApplyProductName() {
		return applyProductName;
	}
	public void setApplyProductName(String applyProductName) {
		this.applyProductName = applyProductName;
	}
	public String getIsLoopName() {
		return isLoopName;
	}
	public void setIsLoopName(String isLoopName) {
		this.isLoopName = isLoopName;
	}
	public String getIsSignCheck() {
		return isSignCheck;
	}
	public void setIsSignCheck(String isSignCheck) {
		this.isSignCheck = isSignCheck;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Integer getStateCode() {
		return stateCode;
	}
	public void setStateCode(Integer stateCode) {
		this.stateCode = stateCode;
	}
	public Date getIncomeTime() {
		return incomeTime;
	}
	public void setIncomeTime(Date incomeTime) {
		this.incomeTime = incomeTime;
	}
	public Date getAuditEndTime() {
		return auditEndTime;
	}
	public void setAuditEndTime(Date auditEndTime) {
		this.auditEndTime = auditEndTime;
	}
	public String getAgreeProductName() {
		return agreeProductName;
	}
	public void setAgreeProductName(String agreeProductName) {
		this.agreeProductName = agreeProductName;
	}
	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public int getAgreeProductLimit() {
		return agreeProductLimit;
	}
	public void setAgreeProductLimit(int agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}
	public String getServiceProportion() {
		return serviceProportion;
	}
	public void setServiceProportion(String serviceProportion) {
		this.serviceProportion = serviceProportion;
	}
	public String getIsRefuse() {
		return isRefuse;
	}
	public void setIsRefuse(String isRefuse) {
		this.isRefuse = isRefuse;
	}
	public String getRefuseReason() {
		return refuseReason;
	}
	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}
	public Date getContractTakeEffectTime() {
		return contractTakeEffectTime;
	}
	public void setContractTakeEffectTime(Date contractTakeEffectTime) {
		this.contractTakeEffectTime = contractTakeEffectTime;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public BigDecimal getMonthReturnAmount() {
		return monthReturnAmount;
	}
	public void setMonthReturnAmount(BigDecimal monthReturnAmount) {
		this.monthReturnAmount = monthReturnAmount;
	}
	public int getRepayDay() {
		return repayDay;
	}
	public void setRepayDay(int repayDay) {
		this.repayDay = repayDay;
	}
	public String getIsSettle() {
		return isSettle;
	}
	public void setIsSettle(String isSettle) {
		this.isSettle = isSettle;
	}
	public int getReconsiderationQty() {
		return reconsiderationQty;
	}
	public void setReconsiderationQty(int reconsiderationQty) {
		this.reconsiderationQty = reconsiderationQty;
	}
	public Date getOneReconsiderationTime() {
		return oneReconsiderationTime;
	}
	public void setOneReconsiderationTime(Date oneReconsiderationTime) {
		this.oneReconsiderationTime = oneReconsiderationTime;
	}
	public Date getTowReconsiderationTime() {
		return towReconsiderationTime;
	}
	public void setTowReconsiderationTime(Date towReconsiderationTime) {
		this.towReconsiderationTime = towReconsiderationTime;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public String getVisitTypeName() {
		return visitTypeName;
	}
	public void setVisitTypeName(String visitTypeName) {
		this.visitTypeName = visitTypeName;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	public BigDecimal getConfirmAmout() {
		return confirmAmout;
	}

	public void setConfirmAmout(BigDecimal confirmAmout) {
		this.confirmAmout = confirmAmout;
	}

	@Override
	public String toString() {
		return "ApplyAlreadyListVO{" +
				"applyNum='" + applyNum + '\'' +
				", applyId=" + applyId +
				", mainId=" + mainId +
				", productId=" + productId +
				", custName='" + custName + '\'' +
				", phone='" + phone + '\'' +
				", idCard='" + idCard + '\'' +
				", saleTeamName='" + saleTeamName + '\'' +
				", saleUserName='" + saleUserName + '\'' +
				", serviceName='" + serviceName + '\'' +
				", applyProductName='" + applyProductName + '\'' +
				", isLoopName='" + isLoopName + '\'' +
				", isSignCheck='" + isSignCheck + '\'' +
				", stateName='" + stateName + '\'' +
				", stateCode=" + stateCode +
				", incomeTime=" + incomeTime +
				", auditEndTime=" + auditEndTime +
				", agreeProductName='" + agreeProductName + '\'' +
				", agreeAmount=" + agreeAmount +
				", agreeProductLimit=" + agreeProductLimit +
				", serviceProportion='" + serviceProportion + '\'' +
				", isRefuse='" + isRefuse + '\'' +
				", refuseReason='" + refuseReason + '\'' +
				", contractTakeEffectTime=" + contractTakeEffectTime +
				", contractAmount=" + contractAmount +
				", monthReturnAmount=" + monthReturnAmount +
				", repayDay=" + repayDay +
				", isSettle='" + isSettle + '\'' +
				", reconsiderationQty=" + reconsiderationQty +
				", oneReconsiderationTime=" + oneReconsiderationTime +
				", towReconsiderationTime=" + towReconsiderationTime +
				", orgName='" + orgName + '\'' +
				", orgId=" + orgId +
				", visitTypeName='" + visitTypeName + '\'' +
				", recommender='" + recommender + '\'' +
				", confirmAmout=" + confirmAmout +
				'}';
	}
}
