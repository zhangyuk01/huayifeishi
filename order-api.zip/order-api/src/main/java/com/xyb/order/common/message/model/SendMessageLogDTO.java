package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 短信日志
 * Created by xieqingyang on 2018/4/11.
 */
public class SendMessageLogDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    private String phone; // -- 手机号
    private String returnValue; // -- 发送短信的漫道返回值
    private String returnCode; // -- 运营商返回码
    private String returnTime; // -- 运营商返回码生成时间
    private String messageChannel; // -- 短信渠道运营商
    private String messageTypeId; // -- 短信类型ID
    private Long messageTemplateId; // -- 短信模板ID
    private Long businessId; // -- 短信所对应业务ID如合同号，验证类可为null
    private String valueCount; // -- 统计短信字数
    private Long operationUser; // -- 操作人

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getReturnValue() {
        return returnValue;
    }

    public void setReturnValue(String returnValue) {
        this.returnValue = returnValue;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnTime() {
        return returnTime;
    }

    public void setReturnTime(String returnTime) {
        this.returnTime = returnTime;
    }

    public String getMessageChannel() {
        return messageChannel;
    }

    public void setMessageChannel(String messageChannel) {
        this.messageChannel = messageChannel;
    }

    public String getMessageTypeId() {
        return messageTypeId;
    }

    public void setMessageTypeId(String messageTypeId) {
        this.messageTypeId = messageTypeId;
    }

    public Long getMessageTemplateId() {
        return messageTemplateId;
    }

    public void setMessageTemplateId(Long messageTemplateId) {
        this.messageTemplateId = messageTemplateId;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public String getValueCount() {
        return valueCount;
    }

    public void setValueCount(String valueCount) {
        this.valueCount = valueCount;
    }

    public Long getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(Long operationUser) {
        this.operationUser = operationUser;
    }
}
