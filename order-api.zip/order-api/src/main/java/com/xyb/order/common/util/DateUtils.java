/*
 *  Copyright 2012, Tera-soft Co., Ltd.  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TERA-SOFT CO.,
 *  LTD.  THE CONTENTS OF THIS FILE MAY NOT BE DISCLOSED TO THIRD
 *  PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART,
 *  WITHOUT THE PRIOR WRITTEN PERMISSION OF TERA-SOFT CO., LTD
 *
 */
package com.xyb.order.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Pattern;


/**
 * @author Administrator
 * 
 */
public class DateUtils {

    /**
     * DEFAULT_TIME_PATTERN
     */
    public static final String DEFAULT_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * DEFAULT_DATE_PATTERN
     */
    public static final String DEFAULT_DATE_PATTERN = "yyyy-MM-dd";
    
    /**
     * DEFAULT_MONTH_PATTERN
     */
    public static final String DEFAULT_MONTH_PATTERN = "yyyy-MM";

    /**
     * 8位的日期格式
     */
    public static final String EIGHT_BIT_DATE_PATTERN = "yyyyMMdd";

    static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    public static final String TEN_BIT_DATE_PATTERN = "yyyy/MM/dd";

    /**
     * 毫秒
     */
    public static final String DEFAULT_SECONDTIME_PATTERN = "yyyy-MM-dd HH:mm:ss.S";

    /**
     * 获取Date
     * 
     * @param year
     *            year
     * @param month
     *            month
     * @param day
     *            day
     * @return Date
     */
    public static Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, day, 0, 0, 0);
        return cal.getTime();
    }

    /**
     * 获取Date
     * 
     * @param dateStr
     *            dateStr
     * @param pattern
     *            pattern
     * @return Date
     * @throws ParseException
     *             ParseException
     */
    public static Date getDate(String dateStr, String pattern) throws ParseException {
        DateFormat format = new SimpleDateFormat(pattern);
        return format.parse(dateStr);
    }

    /**
     * 获取Date
     * 
     * @param timeStr
     *            timeStr
     * @return Date
     */
    public static Date getTime(String timeStr) {
        if (null == timeStr || timeStr.equals("")) {
            return null;
        }

        int length = timeStr.length();
        if (7 == length) {
            timeStr = timeStr + "-01 00:00:00";
        }
        if (10 == length) {
            timeStr = timeStr + " 00:00:00";
        }
        if (length > 7 && length < 10) {
            String[] str = timeStr.split("-");
            if (null == str || str.length != 3) {
                return null;
            }
            if (1 == str[1].length()) {
                str[1] = "0" + str[1];
            }
            if (1 == str[2].length()) {
                str[2] = "0" + str[2];
            }
            timeStr = str[0] + "-" + str[1] + "-" + str[2] + " 00:00:00";
        }

        String regex = "[0-9]{4}-[0-9]{1,2}-[0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2}";
        Pattern pattern = Pattern.compile(regex);
        if (!pattern.matcher(timeStr).matches()) {
            return null;
        }

        DateFormat format = new SimpleDateFormat(DEFAULT_TIME_PATTERN);
        try {
            return format.parse(timeStr);
        } catch (Exception e) {
            System.out.println("--------- DateUtils.getTime() 出现异常! -----------");
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 通过指定的一种格式, 返回Date时间类型
     * 
     * @param dateStr
     *            时间格式为 yyyy/MM/dd 或者 yyyy MM dd 或者 yyyy-MM-dd格式的数据类型.
     *            2003/12/15
     * @return Date
     */
    public static Date getDate(String dateStr) {
        if (null == dateStr || dateStr.equals("")) {
            return null;
        }
        dateStr = dateStr.trim();
        char c = 0;
        for (int i = 0; i < dateStr.length(); i++) {
            c = dateStr.charAt(i);
            if (!StringUtils.isNumber(c)) {
                break;
            }
        }
        if (StringUtils.isNumber(c)) {
            return null;
        }
        StringTokenizer tokenYmd = new StringTokenizer(dateStr, Character.toString(c));
        int year = Integer.parseInt(tokenYmd.nextToken().trim());
        int month = Integer.parseInt(tokenYmd.nextToken().trim());
        String dayStr = tokenYmd.nextToken().trim();
        int index;
        for (index = 0; index < dayStr.length(); index++) {
            c = dayStr.charAt(index);
            if (!StringUtils.isNumber(c)) {
                break;
            }
        }
        int day = Integer.parseInt(dayStr.substring(0, index));
        // added by wallace
        int hour = 0;
        int min = 0;
        int sec = 0;

        if (dateStr.length() > 10) {
            String hms = dateStr.substring(10);
            StringTokenizer tokenHms = new StringTokenizer(hms, ":");
            hour = Integer.parseInt(tokenHms.nextToken().trim());
            min = Integer.parseInt(tokenHms.nextToken().trim());
            sec = Integer.parseInt(tokenHms.nextToken().trim());
        }
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * 通过指定的一种格式, 返回Date时间类型
     * 
     * @param str
     *            时间格式为 yyyyMMdd 或者 yyyyMM 或者 yyyy格式的数据类型. 20031215
     * @return Date
     */
    public static Date getDateYMD(String str) {
        // 设置年月日
        int year = 0, mm = 0, dd = 1;
        Calendar cal = Calendar.getInstance();

        if (str == null || "".equals(str) || str.length() < 4) {
            return null;
        }

        // 设置年月日
        try {
            year = Integer.parseInt(str.substring(0, 4));
            mm = Integer.parseInt(str.substring(4, 6)) - 1;
            dd = Integer.parseInt(str.substring(6, 8));
        } catch (Exception e) {
            e.printStackTrace();
        }
        cal.set(year, mm, dd, 0, 0, 0);
        return cal.getTime();
    }

    /**
     * Date转字符串
     * 
     * @param date
     *            date
     * @param pattern
     *            pattern
     * @return String
     */
    public static String toString(Date date, String pattern) {
        if (null == date) {
            return null;
        }

        DateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);
    }

    /**
     * toTimeString
     * 
     * @param date
     *            date
     * @return String
     */
    public static String toTimeString(Date date) {
        return toString(date, DEFAULT_TIME_PATTERN);
    }

    /**
     * toDateString
     * 
     * @param time
     *            long
     * @return String
     */
    public static String toDateString(long time) {
        return toDateString(new Date(time));
    }

    /**
     * toTimeString
     * 
     * @param time
     *            long
     * @return String
     */
    public static String toTimeString(long time) {
        return toTimeString(new Date(time));
    }

    /**
     * @param date
     *            date
     * @return String
     */
    public static String toDateString(Date date) {
        return toString(date, DEFAULT_DATE_PATTERN);
    }

    /**
     * getDayRange
     * 
     * @param beginDate
     *            beginDate
     * @param endDate
     *            endDate
     * @return int
     */
    public static int getDayRange(Date beginDate, Date endDate) {
        // double result = (endDate.getTime() - beginDate.getTime()) / (1000 *
        // 3600 * 24.0) + 1;
        // if (result < 0) {
        // result += -1;
        // }
        // return (int) result;
        int flag = 1;
        Calendar start = getCalendarAtDateBegin(beginDate);
        Calendar end = getCalendarAtDateBegin(endDate);
        if (start.after(end)) {
            flag = -1;
            Calendar temp = start;
            start = end;
            end = temp;
        }
        int dayRange = 0;
        while (start.before(end)) {
            start.add(Calendar.DAY_OF_MONTH, 1);
            dayRange++;
        }
        return dayRange * flag;
    }
    /**
     * 格式化月份,返回格式:"yyyy-MM"
     * 
     * @param date
     *            date
     * @return String
     */
    public static String formatMonth(Date date) {
        if (null == date) {
            return null;
        }
        try {
            DateFormat simpleDateFormat = new SimpleDateFormat(DEFAULT_MONTH_PATTERN);
            String newDate = simpleDateFormat.format(date);
            return newDate;
        } catch (Exception e) {
            return null;
        }
    }
    /**
     * 格式化日期,返回格式:"yyyy-MM-dd"
     * 
     * @param date
     *            date
     * @return String
     */
    public static String formatDate(Date date) {
        if (null == date) {
            return null;
        }
        try {
            DateFormat simpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN);
            String newDate = simpleDateFormat.format(date);
            return newDate;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 格式化日期,返回格式:"yyyy-MM-dd hh:mm:ss"
     * 
     * @param date
     *            date
     * @return String
     */
    public static String formatTime(Date date) {
        if (null == date) {
            return null;
        }
        try {
            DateFormat simpleDateFormat = new SimpleDateFormat(DEFAULT_TIME_PATTERN);
            String newDate = simpleDateFormat.format(date);
            return newDate;
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * 格式化日期,返回格式:"yyyyMMdd"
     * 
     * @param date
     *            date
     * @return String
     */
    public static String formatDateYMD(Date date) {
        if (null == date) {
            return null;
        }
        try {
            DateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
            String newDate = simpleDateFormat.format(date);
            return newDate;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 月数，不足一月加1 getMonthRange
     * 
     * @param beginDate
     *            beginDate
     * @param endDate
     *            endDate
     * @return int
     */
    public static int getRoundUpMonthRange(Date beginDate, Date endDate) {
        // Calendar calendar = Calendar.getInstance();
        // calendar.setTime(beginDate);
        // int beginYear = calendar.get(Calendar.YEAR);
        // int beginMonth = calendar.get(Calendar.MONTH);
        // int beginDay = calendar.get(Calendar.DAY_OF_MONTH);
        // calendar.setTime(endDate);
        // int endYear = calendar.get(Calendar.YEAR);
        // int endMonth = calendar.get(Calendar.MONTH);
        // int endDay = calendar.get(Calendar.DAY_OF_MONTH);
        // int monthRange = (endYear - beginYear) * 12 + (endMonth -
        // beginMonth);
        // if (endDay > beginDay) {
        // return monthRange + 1;
        // }
        // return monthRange;
        int flag = 1;
        Calendar start = getCalendarAtDateBegin(beginDate);
        Calendar end = getCalendarAtDateBegin(endDate);
        if (start.after(end)) {
            flag = -1;
            Calendar temp = start;
            start = end;
            end = temp;
        }
        int monthRange = 0;
        while (start.before(end)) {
            start.add(Calendar.MONTH, 1);
            monthRange++;
        }
        return monthRange * flag;
    }

    /**
     * 月数，不足一月不计
     * 
     * @param beginDate
     *            beginDate
     * @param endDate
     *            endDate
     * @return int
     */
    public static int getMonthRange(java.util.Date beginDate, java.util.Date endDate) {
        // Calendar calendar = Calendar.getInstance();
        // calendar.setTime(beginDate);
        // int beginYear = calendar.get(Calendar.YEAR);
        // int beginMonth = calendar.get(Calendar.MONTH);
        // int beginDay = calendar.get(Calendar.DAY_OF_MONTH);
        // calendar.setTime(endDate);
        // int endYear = calendar.get(Calendar.YEAR);
        // int endMonth = calendar.get(Calendar.MONTH);
        // int endDay = calendar.get(Calendar.DAY_OF_MONTH);
        // int monthRange = (endYear - beginYear) * 12 + (endMonth -
        // beginMonth);
        // if (endDay < beginDay) {
        // return monthRange - 1;
        // }
        // return monthRange;

        int flag = 1;
        Calendar start = getCalendarAtDateBegin(beginDate);
        Calendar end = getCalendarAtDateBegin(endDate);
        if (start.after(end)) {
            flag = -1;
            Calendar temp = start;
            start = end;
            end = temp;
        }
        int monthRange = 0;
        while (start.before(end)) {
            start.add(Calendar.MONTH, 1);
            monthRange++;
        }
        if (start.after(end)) {
            monthRange--;
        }
        return monthRange * flag;
    }

    /**
     * 月数，不足一月不计（兼容用，以后用上面的两个）
     * 
     * @param beginDate
     *            beginDate
     * @param endDate
     *            endDate
     * @return int
     */
    public static int getDepreciationMonthRange(java.util.Date beginDate, java.util.Date endDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(beginDate);
        int beginYear = calendar.get(Calendar.YEAR);
        int beginMonth = calendar.get(Calendar.MONTH);
        int beginDay = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.setTime(endDate);
        int endYear = calendar.get(Calendar.YEAR);
        int endMonth = calendar.get(Calendar.MONTH);
        int endDay = calendar.get(Calendar.DAY_OF_MONTH);
        int monthRange = (endYear - beginYear) * 12 + (endMonth - beginMonth);
        if (endDay < beginDay) {
            return monthRange - 1;
        }
        return monthRange;
    }

    /**
     * 以天为单位，如果两种是同一天就返回0 date1小于date2就返回-1 date1大于date2就返回1
     * 
     * @param date1
     *            date1
     * @param date2
     *            date2
     * @return int
     */
    public static int compareDate(Date date1, Date date2) {

        Calendar cal1 = getCalendarAtDateBegin(date1);
        Calendar cal2 = getCalendarAtDateBegin(date2);
        if (cal1.before(cal2)) {
            return -1;
        }
        if (cal1.after(cal2)) {
            return 1;
        }
        return 0;
    }

    /**
     * 得到这天的最开始时间 ０点０分０秒
     * 
     * @param date
     *            date
     * @return Calendar
     */
    public static Calendar getCalendarAtDateBegin(Date date) {
        Calendar cal = getCalendar(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal;
    }

    /**
     * Date得到Calendar
     * 
     * @param date
     *            date
     * @return Calendar
     */
    public static Calendar getCalendar(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }

    /**
     * getYearRange 不足一年算一年
     * 
     * @param beginDate
     *            beginDate
     * @param endDate
     *            endDate
     * @return int
     */
    public static int getYearRange(Date beginDate, Date endDate) {
        Calendar startCalendar = getCalendar(beginDate);
        Calendar endCalendar = getCalendar(endDate);
        int yearRange = 0;
        while (compareDate(startCalendar.getTime(), endCalendar.getTime()) <= 0) {
            startCalendar.add(Calendar.YEAR, 1);
            yearRange++;
        }
        return yearRange;
    }

    /**
     * Date 增加小时
     * 
     * @param date
     *            日期
     * @param day
     *            增加的天数
     * @return Date
     */
    public static Date addHour(Date date, int hour) {
        if (date == null || hour == 0) {
            return date;
        }
        Calendar calendar = getCalendar(date);
        calendar.add(Calendar.HOUR_OF_DAY, hour);
        return calendar.getTime();
    }
    
    /**
     * Date 增加几天
     * 
     * @param date
     *            日期
     * @param day
     *            增加的天数
     * @return Date
     */
    public static Date addDay(Date date, int day) {
    	if (date == null || day == 0) {
    		return date;
    	}
    	Calendar calendar = getCalendar(date);
    	calendar.add(Calendar.DAY_OF_YEAR, day);
    	return calendar.getTime();
    }

    /**
     * Date 增加几个月
     * 
     * @param date
     *            日期
     * @param month
     *            增加的月数
     * @return Date
     */
    public static Date addMonth(Date date, int month) {
        if (date == null || month == 0) {
            return date;
        }
        Calendar calendar = getCalendar(date);
        calendar.add(Calendar.MONTH, month);
        return calendar.getTime();
    }

    /**
     * 获取当前时间的日期
     * 
     * @return 日期
     */
    public static Date getDateNow() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * 获取当前的日期时间
     * 
     * @return 时间
     */
    public static Date getDateTimeNow() {
        Calendar cal = Calendar.getInstance();
        return cal.getTime();
    }
    
    /**
     * 获取当前的日期时间  时:分:秒
     * 
     * @return 时间
     */
    public static String getDateTimeNowOfHMS(Date date) {
    	Calendar cal = getCalendar(date);
    	int h = cal.get(Calendar.HOUR_OF_DAY);//获取小时
    	int m = cal.get(Calendar.MINUTE);//获取分钟
    	int s = cal.get(Calendar.SECOND);//获取秒
    	return h + ":" + m +":" + s;
    }

    /**
     * 获取月份
     * 
     * @param date
     *            日期
     * @return 月份
     */
    public static int getMonth(Date date) {
        if (date == null) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return (calendar.get(Calendar.MONTH) + 1);
    }

    /**
     * 获取年
     * 
     * @param date
     *            日期
     * @return 年
     */
    public static int getYear(Date date) {
        if (date == null) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.YEAR);
    }

    /**
     * 获取日
     * 
     * @param date
     *            日期
     * @return 日
     */
    public static int getDay(Date date) {
        if (date == null) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * 
     * 根据提供的日期查找该日期的上一个还款日
     * 
     * @return
     * @author chl
     * @date 2014年8月27日
     */
    public static Date getPlanDate(Date date) {
        if (date == null) {
            return date;
        }
        int year = getYear(date);
        int month = getMonth(date);
        int day = getDay(date);

        if (month == 1) {
            if (day < 10) {
                return getDate(year - 1, 12, 30);
            } else if (10 <= day && day < 20) {
                return getDate(year, month, 10);
            } else if (20 <= day && day < 30) {
                return getDate(year, month, 20);
            } else if (30 <= day) {
                return getDate(year, month, 30);
            }
        } else if (month == 3) {
            if ((year % 4 != 0) || ((year % 100 == 0) && (year % 400 != 0))) {
                if (day < 10) {
                    return getDate(year, month - 1, 28);
                } else if (10 <= day && day < 20) {
                    return getDate(year, month, 10);
                } else if (20 <= day && day < 30) {
                    return getDate(year, month, 20);
                } else if (30 <= day) {
                    return getDate(year, month, 30);
                }
            } else {
                if (day < 10) {
                    return getDate(year, month - 1, 29);
                } else if (10 <= day && day < 20) {
                    return getDate(year, month, 10);
                } else if (20 <= day && day < 30) {
                    return getDate(year, month, 20);
                } else if (30 <= day) {
                    return getDate(year, month, 30);
                }
            }

        } else if (month == 2) {
            if ((year % 4 != 0) || ((year % 100 == 0) && (year % 400 != 0))) {
                if (day < 10) {
                    return getDate(year, month - 1, 30);
                } else if (10 <= day && day < 20) {
                    return getDate(year, month, 10);
                } else if (20 <= day && day < 28) {
                    return getDate(year, month, 20);
                } else if (28 <= day) {
                    return getDate(year, month, 28);
                }
            } else {
                if (day < 10) {
                    return getDate(year, month - 1, 30);
                } else if (10 <= day && day < 20) {
                    return getDate(year, month, 10);
                } else if (20 <= day && day < 29) {
                    return getDate(year, month, 20);
                } else if (29 <= day) {
                    return getDate(year, month, 29);
                }
            }

        } else {
            if (day < 10) {
                return getDate(year, month - 1, 30);
            } else if (10 <= day && day < 20) {
                return getDate(year, month, 10);
            } else if (20 <= day && day < 30) {
                return getDate(year, month, 20);
            } else if (30 <= day) {
                return getDate(year, month, 30);
            }

        }

        return date;
    }

    /**
     * 
     * 根据提供的日期查找该日期的下一个还款日
     * 
     * @return
     * @author chl
     * @date 2014年8月27日
     */
    public static Date getNextPlanDate(Date date) {
        if (date == null) {
            return date;
        }
        int year = getYear(date);
        int month = getMonth(date);
        int day = getDay(date);
        if (month == 2) {
            if ((year % 4 != 0) || ((year % 100 == 0) && (year % 400 != 0))) {
                if (day <= 10) {
                    return getDate(year, month, 10);
                } else if (10 < day && day <= 20) {
                    return getDate(year, month, 20);
                } else if (20 < day && day <= 28) {
                    return getDate(year, month, 28);
                }
            } else {
                if (day <= 10) {
                    return getDate(year, month, 10);
                } else if (10 < day && day <= 20) {
                    return getDate(year, month, 20);
                } else if (20 < day && day <= 29) {
                    return getDate(year, month, 29);
                }
            }

        } else if (month == 12) {

            if (day <= 10) {
                return getDate(year, month, 10);
            } else if (10 < day && day <= 20) {
                return getDate(year, month, 20);
            } else if (20 < day && day <= 30) {
                return getDate(year, month, 30);
            } else if (day > 30) {
                return getDate(year + 1, 1, 10);
            }

        } else {
            if (day <= 10 || day > 30) {
                return getDate(year, month, 10);
            } else if (10 < day && day <= 20) {
                return getDate(year, month, 20);
            } else if (20 < day && day <= 30) {
                return getDate(year, month, 30);
            } else if (day > 30) {
                return getDate(year, month + 1, 10);
            }

        }

        return date;
    }

    /**
     * 
     * 根据月份查询该月的两个还款日（10和20）和上月最后一次还款日（30或28）
     * 
     * @param date
     * @return
     * @author chl
     * @date 2014年11月21日
     */
    public static List<Date> getPlanDates(Date date) {
        List<Date> dates = new ArrayList<Date>(0);
        if (date == null) {
            return dates;
        }
        int year = getYear(date);
        int month = getMonth(date);

        if (month == 1) {
            Date d1 = getDate(year - 1, 12, 30);
            Date d2 = getDate(year, 1, 10);
            Date d3 = getDate(year, 1, 20);
            dates.add(d1);
            dates.add(d2);
            dates.add(d3);
        } else if (month == 3) {
            if ((year % 4 != 0) || ((year % 100 == 0) && (year % 400 != 0))) {
                Date d1 = getDate(year, 2, 28);
                Date d2 = getDate(year, 3, 10);
                Date d3 = getDate(year, 3, 20);
                dates.add(d1);
                dates.add(d2);
                dates.add(d3);
            } else {
                Date d1 = getDate(year, 2, 29);
                Date d2 = getDate(year, 3, 10);
                Date d3 = getDate(year, 3, 20);
                dates.add(d1);
                dates.add(d2);
                dates.add(d3);
            }

        } else {
            Date d1 = getDate(year, month - 1, 30);
            Date d2 = getDate(year, month, 10);
            Date d3 = getDate(year, month, 20);
            dates.add(d1);
            dates.add(d2);
            dates.add(d3);

        }

        return dates;
    }
/**
 * 获取本月的3个 还款日   yyyy-MM-dd 格式
 * lisheng
 * @param date  今天
 * @return
 */
    public static List<String> getThisMonthPlanDates(Date date) {
        List<String> dates = new ArrayList<String>(0);
        if (date == null) {
            return dates;
        }
        int year = getYear(date);
        int month = getMonth(date);
        if (month == 2) {
            if ((year % 4 != 0) || ((year % 100 == 0) && (year % 400 != 0))) {
                String d1 = toString(getDate(year, month, 10),DEFAULT_DATE_PATTERN);
                String d2 = toString(getDate(year, month, 20),DEFAULT_DATE_PATTERN);
                String d3 = toString(getDate(year, month, 28),DEFAULT_DATE_PATTERN);
                dates.add(d1);
                dates.add(d2);
                dates.add(d3);
            } else {
                String d1 = toString(getDate(year, month, 10),DEFAULT_DATE_PATTERN);
                String d2 = toString(getDate(year, month, 20),DEFAULT_DATE_PATTERN);
                String d3 = toString(getDate(year, month, 29),DEFAULT_DATE_PATTERN);
                dates.add(d1);
                dates.add(d2);
                dates.add(d3);
            }

        } else {
        	String d1 = toString(getDate(year, month, 10),DEFAULT_DATE_PATTERN);
            String d2 = toString(getDate(year, month, 20),DEFAULT_DATE_PATTERN);
            String d3 = toString(getDate(year, month, 30),DEFAULT_DATE_PATTERN);
            dates.add(d1);
            dates.add(d2);
            dates.add(d3);
        }

        return dates;
    }
    
    /**
     * 时间差，用毫秒度量 date1<date2
     * 
     * @param date1
     * @param date2
     * @return date2-date1
     */
    public static long getDeltaMilliseconds(Date date1, Date date2) {
        return date2.getTime() - date1.getTime();
    }

    /**
     * 时间差，用天度量 date1<date2
     * 
     * @param date1
     * @param date2
     * @return date2-date1
     */
    public static int getDeltaDays(Date date1, Date date2) {
        return (int) (getDeltaMilliseconds(date1, date2) / 1000 / 60 / 60 / 24);
    }
    
    /** 
     *  
     * @param 要转换的毫秒数 
     * @return 该毫秒数转换为 * days * hours * minutes * seconds 后的格式 
     * @author fy.zhang 
     */  
    public static String formatDuring(long mss) {  
    	StringBuffer str = new StringBuffer();
    	if (mss == 0) {
    		str.append("0时0分0秒");
        }else{
            long days = mss / (1000 * 60 * 60 * 24);  
            long hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);  
            long minutes = (mss % (1000 * 60 * 60)) / (1000 * 60);  
            long seconds = (mss % (1000 * 60)) / 1000;  
            
            if(days >= 1){
            	str.append(days+"天");
            }
            if(hours >= 1){
            	str.append(hours+"时");
            }
            if(minutes >= 1){
            	str.append(minutes+"分");
            }
            if(seconds >= 1){
            	str.append(seconds+"秒");
            }
            
        }
    	return str.toString();
    }  
    /** 
     *  
     * @param begin 时间段的开始 
     * @param end   时间段的结束 
     * @return  输入的两个Date类型数据之间的时间间格用* days * hours * minutes * seconds的格式展示 
     * @author fy.zhang 
     */  
    public static String formatDuring(Date begin, Date end) {  
        return formatDuring(end.getTime() - begin.getTime());  
    } 
    

    /**
     * 获取月份起始日期
     * 
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date getMinMonthDate(Date d) throws ParseException {

        String date = DateUtils.toString(d, DEFAULT_DATE_PATTERN);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateFormat.parse(date));
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        return DateUtils.getDate(dateFormat.format(calendar.getTime()), DEFAULT_DATE_PATTERN);
    }

    /**
     * 获取月份最后日期
     * 
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date getMaxMonthDate(Date d) throws ParseException {
        String date = DateUtils.toString(d, DEFAULT_DATE_PATTERN);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateFormat.parse(date));
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

        return DateUtils.getDate(dateFormat.format(calendar.getTime()), "yyyy-MM-dd");
    }

    /**
     * zmy add
     * 
     * @param commDate
     * @return 返回日期格式：yyyy-MM-dd HH:mm:ss
     */

    public static Date getRealCommDate(String commDate) {
        // String returnTime="YYYY-MM-DD HH:mm:ss";
        try {
            if (!StringUtils.isNullOrEmpty(commDate)) {
                Calendar calendar = Calendar.getInstance();
                Long timeL = Long.valueOf(commDate);
                calendar.setTimeInMillis(timeL);
                return DateUtils.getDate(calendar.getTime().toLocaleString(), DateUtils.DEFAULT_TIME_PATTERN);

            } else {
                return DateUtils.getDate(Calendar.getInstance().toString(), DateUtils.DEFAULT_TIME_PATTERN);
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * zmy add
     * 
     * @param commDate
     * @return 毫秒日期
     */

    public static String getRealCommSecondsDate(String commDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        try {
            if (!StringUtils.isNullOrEmpty(commDate)) {
                Calendar calendar = Calendar.getInstance();
                Long timeL = Long.valueOf(commDate);
                calendar.setTimeInMillis(timeL);
                System.err.println(sdf.format(calendar.getTimeInMillis()));
                return sdf.format(calendar.getTimeInMillis());

            } else {
                return sdf.format(Calendar.getInstance().getTimeInMillis());
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static int getWeekDay(Date date) {
        if (date == null) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * 
     * 获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天
     * 
     * @param startDate
     * @param endDate
     * @return
     * @author chl
     * @date 2015年4月8日
     */
    public static int getDutyDays(Date startDate, Date endDate) {
        int result = 0;
        while (startDate.compareTo(endDate) <= 0) {
            if (getWeekDay(startDate) != 7 && getWeekDay(startDate) != 1) {
                result++;
            }
            startDate = addDay(startDate, 1);
        }
        return result;
    }
    
    /** 
	 * 判断时间是否在时间段内 
	 *  
	 * @param date 
	 *            当前时间 yyyy-MM-dd HH:mm:ss 
	 * @param strDateBegin 
	 *            开始时间 00:00:00 
	 * @param strDateEnd 
	 *            结束时间 00:05:00 
	 * @return boolean
	 */  
	public static boolean isInDate(Date date, String strDateBegin,  
	        String strDateEnd) {  
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
	    String strDate = sdf.format(date);  
	    // 截取当前时间时分秒  
	    int strDateH = Integer.parseInt(strDate.substring(11, 13));  
	    int strDateM = Integer.parseInt(strDate.substring(14, 16));  
	    int strDateS = Integer.parseInt(strDate.substring(17, 19));  
	    // 截取开始时间时分秒  
	    int strDateBeginH = Integer.parseInt(strDateBegin.substring(0, 2));  
	    int strDateBeginM = Integer.parseInt(strDateBegin.substring(3, 5));  
	    int strDateBeginS = Integer.parseInt(strDateBegin.substring(6, 8));  
	    // 截取结束时间时分秒  
	    int strDateEndH = Integer.parseInt(strDateEnd.substring(0, 2));  
	    int strDateEndM = Integer.parseInt(strDateEnd.substring(3, 5));  
	    int strDateEndS = Integer.parseInt(strDateEnd.substring(6, 8));  
	    if ((strDateH >= strDateBeginH && strDateH <= strDateEndH)) {  
	        	// 当前时间小时数在开始时间和结束时间小时数之间  
	        if (strDateH >= strDateBeginH && strDateH < strDateEndH) {  
	            return true;
	            // 当前时间小时数等于开始时间小时数，分钟数在开始和结束之间  
	        } else if (strDateH == strDateBeginH && strDateM >= strDateBeginM  
	                && strDateM <= strDateEndM) {  
	            return true;  
	            // 当前时间小时数等于开始时间小时数，分钟数等于开始时间分钟数，秒数在开始和结束之间  
	        } else if (strDateH == strDateBeginH && strDateM == strDateBeginM  
	                && strDateS >= strDateBeginS && strDateS <= strDateEndS) {  
	            return true;  
	         // 当前时间小时数大等于开始时间小时数，等于结束时间小时数，分钟数小等于结束时间分钟数  
	        }else if (strDateH >= strDateBeginH && strDateH == strDateEndH  
                    && strDateM <= strDateEndM) {  
                return true;  
                // 当前时间小时数大等于开始时间小时数，等于结束时间小时数，分钟数等于结束时间分钟数，秒数小等于结束时间秒数  
            } else if (strDateH >= strDateBeginH && strDateH == strDateEndH  
                    && strDateM == strDateEndM && strDateS <= strDateEndS) {  
                return true; 
	        } else {  
	            return false;  
	        }  
	    } else {  
	        return false;  
	    }  
	}
	
	 /**
     * 得到这天的指定时间 ０分０秒（格式化时分秒为指定时间 ）
     * 
     * @param date
     *            date
     * @return Calendar
     */
    public static Date formatDate(Date date,String appointTime) {
    	int hour=0;
    	if(StringUtils.isNotNullAndEmpty(appointTime)){
    		hour=Integer.parseInt(appointTime.substring(0,2));
    	}
        Calendar cal = getCalendar(date);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    
    /**
     * 
     * 获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天
     * 
     * @param startDate
     * @param endDate
     * @return 
     * @author dxc
     * @date 2015年11月4日19:14:10
     */
    public static int getDuty(Date startDate, Date endDate) {
        int result = 0;
        while (startDate.compareTo(endDate) <= 0) {
            if (getWeekDay(startDate) != 7 && getWeekDay(startDate) != 1) {
                result++;
            }
            Calendar calendar = getCalendar(startDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            startDate = calendar.getTime();
        }
        return result;
    }
    
    /**
     * 时间差，用毫秒度量 date1<date2
     * 周六天不计算在内
     * 
     * @param date1
     * @param date2
     * @return date2-date1
     */
    public static long getDeltaMilli(Date startDate, Date endDate) {
    	 int weekDay = 0;
    	//一天换算成毫秒
     	long dayTime=24*60*60*1000;
     	Date start=startDate;
     	Date end=endDate;
    	while (start.compareTo(end) <= 0) {
             if (getWeekDay(start) == 7 || getWeekDay(start) == 1) {
            	 weekDay++;
             }
             Calendar calendar = getCalendar(start);
             calendar.add(Calendar.DAY_OF_YEAR, 1);
             calendar.set(Calendar.HOUR_OF_DAY, 0);
             calendar.set(Calendar.MINUTE, 0);
             calendar.set(Calendar.SECOND, 0);
             calendar.set(Calendar.MILLISECOND, 0);
             start = calendar.getTime();
    	}
    	return endDate.getTime() - startDate.getTime()-weekDay*dayTime;
    }
    
    /**
	 * 计算出两个日期之间的有效工作时间
	 * @param map
	 * @return
	 * @throws Exception 
	 */
	public static long getRangeTime(Date startTime,Date endTime) throws Exception {
		String dayStart="00:00:00";
		String morStart="09:00:00";
		String morEnd="12:00:00";
		String noonStart="13:00:00";
		String noonEnd="18:00:00";
		String dayEnd="24:00:00";
		
		String inAM_PM=null;
		String nowAM_PM=null;
		long range = 0L;
		if(startTime !=null && endTime != null && endTime.after(startTime)){
			//格式化开始时间
			if(DateUtils.isInDate(startTime, dayStart, morEnd)){
				inAM_PM = "AM";
				if(DateUtils.isInDate(startTime, dayStart, morStart)){
					startTime=DateUtils.formatDate(startTime,morStart);//零点到九点之前进件计算时按09：00：00计算
				}
			}else{
				inAM_PM = "PM";
				if(DateUtils.isInDate(startTime, morEnd, noonStart)){
					startTime=DateUtils.formatDate(startTime,noonStart);//12:00到13：00之间按13：00计算
				}else if(DateUtils.isInDate(startTime, noonEnd, dayEnd)){
					//如果在18：00后则从第二天09：00开始计算
					startTime = DateUtils.addDay(startTime,1);//加一天
					startTime = DateUtils.formatDate(startTime,morStart);//格式化时分秒为9：00
					inAM_PM = "AM";
				}
				
			}
			//b.当前时间处理
			if(DateUtils.isInDate(endTime, dayStart, morEnd)){
				nowAM_PM = "AM";
				if(DateUtils.isInDate(endTime, dayStart, morStart)){
					endTime=DateUtils.formatDate(endTime,morStart);//零点到九点之前进件计算时按09：00：00计算
				}
			}else{
				nowAM_PM = "PM";
				if(DateUtils.isInDate(endTime, morEnd, noonStart)){
					endTime=DateUtils.formatDate(endTime,noonStart);//12:00到13：00之间按13：00计算
				}else if(DateUtils.isInDate(endTime, noonEnd, dayEnd)){
					//如果在18：00后则从第二天09：00开始计算
					endTime = DateUtils.addDay(endTime,1);//加一天
					endTime = DateUtils.formatDate(endTime,morStart);//格式化时分秒为9：00
					nowAM_PM = "AM";
				}
			}
			//计算有效时长
			//a.获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天   备注：1时(h)=3600000毫秒(ms)
			int dutyday = DateUtils.getDuty(startTime,endTime);
			//计算有效时长，毫秒
			if(dutyday <= 1){//同一天
				if(inAM_PM.equals(nowAM_PM) ){
					range = DateUtils.getDeltaMilli(startTime, endTime);
				}else if("AM".equals(inAM_PM) && "PM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim-3600000;//去除中午休息时间
				}
			}else if(dutyday >= 1){
				if(inAM_PM.equals(nowAM_PM)){
					long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-(dutyday-1)*3600000;
				}else if("AM".equals(inAM_PM) && "PM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-dutyday*3600000;
				}else if("PM".equals(inAM_PM) && "AM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000;
				}
			}
		}
		return range;
	}
	
	
	/**
	 * 计算出两个日期之间的有效工作时间(审批时效功能)
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws Exception
	 */
	public static long myGetRangeTime(String applyid,Date startTime,Date endTime) throws Exception {
		String dayStart="00:00:00";
		String morStart="09:00:00";
		String morEnd="12:00:00";
		String noonStart="13:00:00";
		String noonEnd="18:00:00";
		String dayEnd="24:00:00";

		String inAM_PM=null;
		String nowAM_PM=null;
		long range = 0L;
		if(startTime !=null && endTime != null && endTime.after(startTime)){
			//格式化开始时间
			if(DateUtils.isInDate(startTime, dayStart, morEnd)){
				inAM_PM = "AM";
				if(DateUtils.isInDate(startTime, dayStart, morStart)){
					startTime=DateUtils.formatDate(startTime,morStart);//零点到九点之前进件计算时按09：00：00计算
				}
			}else{
				inAM_PM = "PM";
				if(DateUtils.isInDate(startTime, morEnd, noonStart)){
					startTime=DateUtils.formatDate(startTime,noonStart);//12:00到13：00之间按13：00计算
				}else if(DateUtils.isInDate(startTime, noonEnd, dayEnd)){
					//如果在18：00后则从第二天09：00开始计算
					startTime = DateUtils.addDay(startTime,1);//加一天
					startTime = DateUtils.formatDate(startTime,morStart);//格式化时分秒为9：00
					inAM_PM = "AM";
				}
				
			}
			//b.当前时间处理
			if(DateUtils.isInDate(endTime, dayStart, morEnd)){
				nowAM_PM = "AM";
				if(DateUtils.isInDate(endTime, dayStart, morStart)){
					endTime=DateUtils.formatDate(endTime,morStart);//零点到九点之前进件计算时按09：00：00计算
				}
			}else{
				nowAM_PM = "PM";
				if(DateUtils.isInDate(endTime, morEnd, noonStart)){
					endTime=DateUtils.formatDate(endTime,noonStart);//12:00到13：00之间按13：00计算
				}else if(DateUtils.isInDate(endTime, noonEnd, dayEnd)){
					//如果在18：00后则从第二天09：00开始计算
					endTime = DateUtils.addDay(endTime,1);//加一天
					endTime = DateUtils.formatDate(endTime,morStart);//格式化时分秒为9：00
					nowAM_PM = "AM";
				}
			}	
			//计算有效时长
			//a.获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天   备注：1时(h)=3600000毫秒(ms)
			int dutyday = DateUtils.getDuty(startTime,endTime);
			//计算有效时长，毫秒
			if(dutyday <= 1){//同一天
				if(inAM_PM.equals(nowAM_PM) ){
					range = DateUtils.getDeltaMilli(startTime, endTime);
				}else if("AM".equals(inAM_PM) && "PM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim-3600000;//去除中午休息时间
				}
			}else if(dutyday >= 1){
				if("AM".equals(inAM_PM) && "AM".equals(nowAM_PM)){
					long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-(dutyday-1)*3600000;
				}else if("PM".equals(inAM_PM) && "PM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-(dutyday-1)*3600000;
				}else if("AM".equals(inAM_PM) && "PM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-dutyday*3600000;
				}else if("PM".equals(inAM_PM) && "AM".equals(nowAM_PM)){
				    long interim = DateUtils.getDeltaMilli(startTime, endTime);
				    range = interim - (dutyday-1) * 15 * 3600000-(dutyday-1)*3600000;
				}
			}
		}
		return range;
	}	
	
	public static String getAkdTime(String time) throws Exception{
		if(StringUtils.isNullOrEmpty(time)){
			return "";
		}else{	
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			Date d =  sdf.parse(time);
			return DateUtils.formatTime(d);
		}
	}	
	/*
	 * 时间戳转换为时间
	 */
	public static String parseDate(String time)
	{
		Date date=new Date(Long.parseLong(time));
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str=format.format(date);
		return str;
	}
	
	
	/*
	 * 获取十分钟前时间
	 */
	public static String getBeforeMin(String date,int min) throws ParseException{
		
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date1 =sdf.parse(date);
		Calendar c = Calendar.getInstance();
		c.setTime(date1);
		c.add(Calendar.MINUTE, min);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String mDateTime=formatter.format(c.getTime());
		String strStart=mDateTime.substring(0, 16);//2007-10-29 09:30
		
		return mDateTime;
	}
	
	/**
	 * 指定时间 是否过期
	 * @param now
	 * @param pre
	 * @param days
	 * @return
	 */
	public static boolean isExpired(Date now,Date pre,int days){
		if(pre != null){
			long diff = now.getTime() - pre.getTime();
			long preDays = diff / (1000 * 60 * 60 * 24);
			return preDays >= days;
		}else{
			return false;
		}
	}
	
	/**
	 * 日期增加-按日增加
	 * 
	 * @param date
	 * @param days
	 * @return java.util.Date
	 */
	public static Date dateIncreaseByDay(Date date, int days) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}
	/**
	 * 新
	 * 计算出两个日期之间的有效工作时间(审批时效功能)
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws Exception
	 */
	
	public static long myGetRangeTimeNew(String applyid,Date startTime,Date endTime) throws Exception {
		String dayStart="00:00:00";
		String morStart="09:00:00";
		String noonEnd="18:00:00";
		String dayEnd="24:00:00";
		long range = 0L;
		//计算有效时长
		//a.获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天   备注：1时(h)=3600000毫秒(ms)
		int dutyDay = DateUtils.getDutyNew(startTime,endTime);
		// 1、开始时间0-9
		if(DateUtils.isInDate(startTime, dayStart, morStart)){
			// 零点到九点之前进件计算时按09：00：00计算
			if(DateUtils.isInDate(endTime, dayStart, morStart)){// 结束时间 0-9
				range = dutyDay*9*3600000;
			}else if(DateUtils.isInDate(endTime, morStart, noonEnd)){// 结束时间 9-18
				Date endTime9 = DateUtils.formatDate(endTime,morStart);
				range = DateUtils.getDeltaMilliNew(endTime9, endTime) 
						+ dutyDay*9*3600000;
			}else if(DateUtils.isInDate(endTime, noonEnd, dayEnd)){// 结束时间 18-24
				range = (dutyDay+1)*9*3600000;
				if(getWeekDay(endTime)==1 || getWeekDay(endTime)==7){
					range = range - 9*3600000;
				}
			}
		}
		// 2、开始时间9-18
		else if(DateUtils.isInDate(startTime, morStart, noonEnd)){
			if(DateUtils.isInDate(endTime, dayStart, morStart)){// 结束时间 0-9
				// 获取开始时间的  18:00 时间
				Date noonEnd18 = DateUtils.formatDate(startTime,noonEnd);
				range = DateUtils.getDeltaMilliNew(startTime, noonEnd18)
						+ (dutyDay-1)*9*3600000;
			}else if(DateUtils.isInDate(endTime, morStart, noonEnd)){// 结束时间 9-18
				Date startTime9 = DateUtils.formatDate(startTime,morStart);
				Date endTime9 = DateUtils.formatDate(endTime,morStart);
				range = DateUtils.getDeltaMilliNew(endTime9, endTime)
						- DateUtils.getDeltaMilliNew(startTime9, startTime)
						+ dutyDay*9*3600000;
				if(getWeekDay(endTime)==1 || getWeekDay(endTime)==7){
					range = range - 9*3600000;
				}
			}else if(DateUtils.isInDate(endTime, noonEnd, dayEnd)){// 结束时间 18-24
				Date noonEnd18 = DateUtils.formatDate(startTime,noonEnd);
				range = DateUtils.getDeltaMilliNew(startTime, noonEnd18) 
						+ dutyDay*9*3600000;
				if(getWeekDay(endTime)==1 || getWeekDay(endTime)==7){
					range = range - 9*3600000;
				}
			}
		}
		// 3、开始时间18-24
		else if(DateUtils.isInDate(startTime, noonEnd, dayEnd)){
			if(DateUtils.isInDate(endTime, dayStart, morStart)){// 结束时间 0-9
				range = (dutyDay-1)*9*3600000;
			}else if(DateUtils.isInDate(endTime, morStart, noonEnd)){// 结束时间 9-18
				Date endTime9 = DateUtils.formatDate(endTime,morStart);
				range = DateUtils.getDeltaMilliNew(endTime9, endTime)
						+ (dutyDay-1)*9*3600000;
			}else if(DateUtils.isInDate(endTime, noonEnd, dayEnd)){// 结束时间 18-24
				range = dutyDay*9*3600000 ;
				if(getWeekDay(endTime)==1 || getWeekDay(endTime)==7){
					range = range - 9*3600000;
				}
			}
		}
		if(range<0){
			range = 0;
		}
		return range;
	}
	
	/**
     * 新
     * 获取两个日期之间差几个工作日（工作日为周一到周五） 差值包含当天
     * 
     * @param startDate
     * @param endDate
     * @return 
     * @author dxc
     * @date 2015年11月4日19:14:10
     */
    public static int getDutyNew(Date startDate, Date endDate) {
        int result = 0;
        // a.首先处理  开始时间为   开始天 最大时间
        Calendar c = getCalendar(startDate);
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 0);
        startDate = c.getTime();
        // b.判断结束时间    是不是 周末
        if(getWeekDay(endDate) != 7 && getWeekDay(endDate) != 1){
        	 while (startDate.compareTo(endDate) <= 0) {
                 if (getWeekDay(startDate) != 7 && getWeekDay(startDate) != 1) {
                     result++;
                 }
                 Calendar calendar = getCalendar(startDate);
                 calendar.add(Calendar.DAY_OF_YEAR, 1);
                 startDate = calendar.getTime();
             }
        }else{
        	while (getWeekDay(endDate) == 7 || getWeekDay(endDate) == 1) {
                Calendar calendar = getCalendar(endDate);
                calendar.add(Calendar.DAY_OF_YEAR, -1);
                calendar.set(Calendar.HOUR_OF_DAY, 23);
                calendar.set(Calendar.MINUTE, 59);
                calendar.set(Calendar.SECOND, 59);
                calendar.set(Calendar.MILLISECOND, 999);
                endDate = calendar.getTime();
            }
        	while (startDate.compareTo(endDate) <= 0) {
                if (getWeekDay(startDate) != 7 && getWeekDay(startDate) != 1) {
                    result++;
                }
                Calendar calendar = getCalendar(startDate);
                calendar.add(Calendar.DAY_OF_YEAR, 1);
                startDate = calendar.getTime();
            }
        }
       
        return result;
    }
	/**
	 * 
	 * 新
     * 时间差，用毫秒度量 date1<date2
     * 
     * @param date1
     * @param date2
     * @return date2-date1
     */
    public static long getDeltaMilliNew(Date startDate, Date endDate) {
    	return endDate.getTime() - startDate.getTime();
    }
	
    /**
     * 
     * 根据提供的  信用宝还款日期date 来查找"南粤"该日期的下一个还款日
     * 
     * @return
     * @author chl
     * @date 2014年8月27日
     */
    public static Date getNYNextPlanDate(Date date) {
        if (date == null) {
            return date;
        }
    	//不是最后一期，则取当前日期的下一个24号
    	int year = getYear(date);
        int month = getMonth(date);
        int day = getDay(date);
		if(day <= 24){
        	//当前日期<=24号，则取本月24号
        	return getDate(year, month, 24);
        }else{
        	//取下个月24号
        	return getDate(year, month + 1, 24);
        }
    }
    
    /**
     * 计算两个日期差几天
     * @param startDate
     * @param endDate
     * @return
     */
    public static int getDutyNew2(Date startDate, Date endDate) {
        int result = 0;
        // a.首先处理  开始时间为   开始天 最大时间
        Calendar c = getCalendar(startDate);
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 0);
        startDate = c.getTime();
        while (startDate.compareTo(endDate) <= 0) {
        	result++;
            Calendar calendar = getCalendar(startDate);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            startDate = calendar.getTime();
        }
        return result;
    }
   
    /**
     * 判断今天是否是还款日
     * @param now
     * @return
     */
    public static boolean isPlanDate(String nowDate){
		List<String> listDates =  getThisMonthPlanDates(new Date());
		boolean nowIsPlanDate = listDates.contains(nowDate);
		return nowIsPlanDate;
	}
    /**
     * 判断某天是否是还款日
     * @param now
     * @return
     * @throws ParseException 
     */
    public static boolean isPlanDateOneDay(String nowDate) throws ParseException{
    	DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
    	Date date = format1.parse(nowDate);
		List<String> listDates =  getThisMonthPlanDates(date);
		boolean nowIsPlanDate = listDates.contains(nowDate);
		return nowIsPlanDate;
	}
}
