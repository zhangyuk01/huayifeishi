package com.xyb.order.common.material.service;

import java.util.List;
import java.util.Map;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.material.model.FileDataDelDTO;
import com.xyb.order.common.material.model.FileDataInfo;
import com.xyb.order.common.material.model.FileSeeDTO;

/**
 * @ClassName FileDataInfoService
 * @author ZhangYu
 * @date 2018年4月17号
 */
public interface FileDataInfoService {
	/**
	 * 添加图片数据信息
	 * @param fileDataInfo
	 */
	FileDataInfo addFileDataInfo(FileDataInfo fileDataInfo);
    
    /**
     * 判断图片数据是否存在 
     * @param fileName
     * @param fileClassificationId
     * @param applyId
     * @return
     */
	int fileIsExit(String fileName,Long fileClassificationId,Long applyId);
	
	/**
	 * 单个图片上传返回最大ID 
	 * @param paramMap
	 * @return
	 */
	int findFileDataInfoMaxSort(Map<String, Object> paramMap);

	/**
	 * @description APP上传图片 (身份证通用接口)
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/28 下午7:44
	 * @Version     1.0
	 * @param imageFiles
	 * @param applyId
	 * @param fileCode
	 * @return
	 * @throws Exception
	 */
	RestResponse uploadAppImageFile(String imageFiles,Long applyId,String fileCode) throws Exception;

	/**
	 * @description 查询图片通用接口
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/28 下午7:42
	 * @Version     1.0
	 * @param   fileSeeDTO    传入参数包含fileType类型（集合）、applyId申请单ID
	 * @return 返回图片信息集合
	 * @throws Exception 返回所有异常
	 */
	RestResponse queryFileDataInfoList(FileSeeDTO fileSeeDTO)throws Exception;

	/**
	 * @description 删除图片
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/30 下午4:12
	 * @Version     1.0
	 * @param fileDataDelDTO 删除图片信息
	 * @return 返回删除结果
	 * @throws Exception 返回所有异常
	 */
	RestResponse fileDataDel(FileDataDelDTO fileDataDelDTO)throws Exception;

	/**
	 * @description 根据图片类型批量修改图片可删除属性
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/30 上午9:52
	 * @Version     1.0
	 * @param applyId 申请单ID  不能为空
	 * @param fileType 图片类型不能为空
	 * @param userId 修改人ID
	 */
	boolean updateFileState(Long applyId,Long userId,List<String> fileType);

	/**
	 * 根据图片地址删除图片接口
	 * @author      xieqingyang
	 * @date        2018/9/3 下午4:52
	 * @version     1.0
	 * @param filePath 文件地址
	 * @return 返回处理结果
	 */
	RestResponse delFile(String filePath);
}
