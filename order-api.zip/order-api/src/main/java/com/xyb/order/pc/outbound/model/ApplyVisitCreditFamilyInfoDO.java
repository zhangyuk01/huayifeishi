package com.xyb.order.pc.outbound.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访家庭信息 model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyVisitCreditFamilyInfoDO implements IBaseModel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 6849749393865644513L;

	private Long id;
	/**申请id*/
    private Long visitMainId;
    /**家庭地址是否一致(大类2692)*/
    private Long isFamilyAddressSame;
    /**外放前家庭地址*/
    private String familyAllAddrOld;
    /**外放后家庭地址*/
    private String familyAllAddr;
    /**家庭省*/
    private Long familyAddrProvince;
    /**家庭市*/
    private Long familyAddrCity;
    /**家庭市label*/
    private String familyAddrCityLabel;
    /**家庭区*/
    private Long familyAddrArea;
    /**家庭去label*/
    private String familyAddrAreaLabel;
    /**家庭地址街道门牌详细信息*/
    private String familyAddrDetail;
    /**家庭电话是否一致(大类2692)*/
    private Long isFamilyTellSame;
    /**是否有家庭固话（大类2692）*/
    private Long haveFamilyTell;
    /**外访前家庭固话号码*/
    private String familyTellOld;
    /**区号*/
    private String areaCode; 
    /**外访后家庭固话号码*/
    private String familyTell;
    /**房屋类型（大类2533）*/
    private Long houseType;
    /**现住址居住时间（大类2646*/
    private Long houseTime;
    /**房屋权属（大类2636）*/
    private Long houseOwnershipType;
    /**房屋市值(大类2638)*/
    private String houseMarketValue;
    /**房屋权属类型是其他时备注*/
    private String houseOwnershipTypeRemark;
    /**装修风格（大类2722）*/
    private Long houseRedecoratedStyle;
    /**共同居住者，多选类型英文逗号隔开(大类2645)*/
    private String coResident;
    /**共同居住情况备注*/
    private String coResidentRemark;
    /**居住痕迹(大类2805)*/
    private String residentialTraces;
    /**备注*/
    private String remark;
    /**是否有效（大类2692）*/
    private Integer isValid;
    /**用来相同模块排序（同时插入时间区分不了显示位置）*/
    private Integer sort;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVisitMainId() {
		return visitMainId;
	}

	public void setVisitMainId(Long visitMainId) {
		this.visitMainId = visitMainId;
	}

	public Long getIsFamilyAddressSame() {
		return isFamilyAddressSame;
	}

	public void setIsFamilyAddressSame(Long isFamilyAddressSame) {
		this.isFamilyAddressSame = isFamilyAddressSame;
	}

	public String getFamilyAllAddrOld() {
		return familyAllAddrOld;
	}

	public void setFamilyAllAddrOld(String familyAllAddrOld) {
		this.familyAllAddrOld = familyAllAddrOld;
	}

	public String getFamilyAllAddr() {
		return familyAllAddr;
	}

	public void setFamilyAllAddr(String familyAllAddr) {
		this.familyAllAddr = familyAllAddr;
	}

	public Long getFamilyAddrProvince() {
		return familyAddrProvince;
	}

	public void setFamilyAddrProvince(Long familyAddrProvince) {
		this.familyAddrProvince = familyAddrProvince;
	}

	public Long getFamilyAddrCity() {
		return familyAddrCity;
	}

	public void setFamilyAddrCity(Long familyAddrCity) {
		this.familyAddrCity = familyAddrCity;
	}

	public String getFamilyAddrCityLabel() {
		return familyAddrCityLabel;
	}

	public void setFamilyAddrCityLabel(String familyAddrCityLabel) {
		this.familyAddrCityLabel = familyAddrCityLabel;
	}

	public Long getFamilyAddrArea() {
		return familyAddrArea;
	}

	public void setFamilyAddrArea(Long familyAddrArea) {
		this.familyAddrArea = familyAddrArea;
	}

	public String getFamilyAddrAreaLabel() {
		return familyAddrAreaLabel;
	}

	public void setFamilyAddrAreaLabel(String familyAddrAreaLabel) {
		this.familyAddrAreaLabel = familyAddrAreaLabel;
	}

	public String getFamilyAddrDetail() {
		return familyAddrDetail;
	}

	public void setFamilyAddrDetail(String familyAddrDetail) {
		this.familyAddrDetail = familyAddrDetail;
	}

	public Long getIsFamilyTellSame() {
		return isFamilyTellSame;
	}

	public void setIsFamilyTellSame(Long isFamilyTellSame) {
		this.isFamilyTellSame = isFamilyTellSame;
	}

	public Long getHaveFamilyTell() {
		return haveFamilyTell;
	}

	public void setHaveFamilyTell(Long haveFamilyTell) {
		this.haveFamilyTell = haveFamilyTell;
	}

	public String getFamilyTellOld() {
		return familyTellOld;
	}

	public void setFamilyTellOld(String familyTellOld) {
		this.familyTellOld = familyTellOld;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getFamilyTell() {
		return familyTell;
	}

	public void setFamilyTell(String familyTell) {
		this.familyTell = familyTell;
	}

	public Long getHouseType() {
		return houseType;
	}

	public void setHouseType(Long houseType) {
		this.houseType = houseType;
	}

	public Long getHouseTime() {
		return houseTime;
	}

	public void setHouseTime(Long houseTime) {
		this.houseTime = houseTime;
	}

	public Long getHouseOwnershipType() {
		return houseOwnershipType;
	}

	public void setHouseOwnershipType(Long houseOwnershipType) {
		this.houseOwnershipType = houseOwnershipType;
	}

	public String getHouseMarketValue() {
		return houseMarketValue;
	}

	public void setHouseMarketValue(String houseMarketValue) {
		this.houseMarketValue = houseMarketValue;
	}

	public String getHouseOwnershipTypeRemark() {
		return houseOwnershipTypeRemark;
	}

	public void setHouseOwnershipTypeRemark(String houseOwnershipTypeRemark) {
		this.houseOwnershipTypeRemark = houseOwnershipTypeRemark;
	}

	public Long getHouseRedecoratedStyle() {
		return houseRedecoratedStyle;
	}

	public void setHouseRedecoratedStyle(Long houseRedecoratedStyle) {
		this.houseRedecoratedStyle = houseRedecoratedStyle;
	}

	public String getCoResident() {
		return coResident;
	}

	public void setCoResident(String coResident) {
		this.coResident = coResident;
	}

	public String getCoResidentRemark() {
		return coResidentRemark;
	}

	public void setCoResidentRemark(String coResidentRemark) {
		this.coResidentRemark = coResidentRemark;
	}

	public String getResidentialTraces() {
		return residentialTraces;
	}

	public void setResidentialTraces(String residentialTraces) {
		this.residentialTraces = residentialTraces;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsValid() {
		return isValid;
	}

	public void setIsValid(Integer isValid) {
		this.isValid = isValid;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	@Override
	public String toString() {
		return "ApplyVisitCreditFamilyInfoDO [id=" + id + ", visitMainId=" + visitMainId + ", isFamilyAddressSame="
				+ isFamilyAddressSame + ", familyAllAddrOld=" + familyAllAddrOld + ", familyAllAddr=" + familyAllAddr
				+ ", familyAddrProvince=" + familyAddrProvince + ", familyAddrCity=" + familyAddrCity
				+ ", familyAddrCityLabel=" + familyAddrCityLabel + ", familyAddrArea=" + familyAddrArea
				+ ", familyAddrAreaLabel=" + familyAddrAreaLabel + ", familyAddrDetail=" + familyAddrDetail
				+ ", isFamilyTellSame=" + isFamilyTellSame + ", haveFamilyTell=" + haveFamilyTell + ", familyTellOld="
				+ familyTellOld + ", areaCode=" + areaCode + ", familyTell=" + familyTell + ", houseType=" + houseType
				+ ", houseTime=" + houseTime + ", houseOwnershipType=" + houseOwnershipType + ", houseMarketValue="
				+ houseMarketValue + ", houseOwnershipTypeRemark=" + houseOwnershipTypeRemark
				+ ", houseRedecoratedStyle=" + houseRedecoratedStyle + ", coResident=" + coResident
				+ ", coResidentRemark=" + coResidentRemark + ", residentialTraces=" + residentialTraces + ", remark="
				+ remark + ", isValid=" + isValid + ", sort=" + sort + ", createTime=" + createTime + ", createUser="
				+ createUser + ", modifyTime=" + modifyTime + ", modifyUser=" + modifyUser + "]";
	}


}
