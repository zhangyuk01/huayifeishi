package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * 协议信息表
 * @author      xieqingyang
 * @date        2018/6/11 下午6:36
*/
public class AgreementInFoDO implements IBaseModel {

    private static final long serialVersionUID = 1834612019290941102L;
    /**主键ID*/
    private Long id;
    /**客户表ID*/
    private Long cusId;
    /**申请单ID*/
    private Long applyId;
    /**是否有效 大类2687 2484：有效  2485：无效*/
    private Long isValid;
    /**协议类型 大类2818 3022：个人授权协议 3023：服务协议 3024：借款协议*/
    private Long agreementType;
    /**查看地址*/
    private String lookAddress;
    /**下载地址*/
    private String downloadAddress;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;
    /**法大大合同ID*/
    private String contractId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCusId() {
        return cusId;
    }

    public void setCusId(Long cusId) {
        this.cusId = cusId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getIsValid() {
        return isValid;
    }

    public void setIsValid(Long isValid) {
        this.isValid = isValid;
    }

    public Long getAgreementType() {
        return agreementType;
    }

    public void setAgreementType(Long agreementType) {
        this.agreementType = agreementType;
    }

    public String getLookAddress() {
        return lookAddress;
    }

    public void setLookAddress(String lookAddress) {
        this.lookAddress = lookAddress;
    }

    public String getDownloadAddress() {
        return downloadAddress;
    }

    public void setDownloadAddress(String downloadAddress) {
        this.downloadAddress = downloadAddress;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    @Override
    public String toString() {
        return "AgreementInFoDO{" +
                "id=" + id +
                ", cusId=" + cusId +
                ", applyId=" + applyId +
                ", isValid=" + isValid +
                ", agreementType=" + agreementType +
                ", lookAddress='" + lookAddress + '\'' +
                ", downloadAddress='" + downloadAddress + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                ", contractId='" + contractId + '\'' +
                '}';
    }
}
