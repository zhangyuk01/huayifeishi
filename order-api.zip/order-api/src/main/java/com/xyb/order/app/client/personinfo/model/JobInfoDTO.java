package com.xyb.order.app.client.personinfo.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

public class JobInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id;//主键ID
	@JsonIgnore
	private Long applyId;//申请单ID
	@JsonIgnore
	private Long cusId;//客户ID
	@NotEmpty(message = "单位名称不能为空")
	private String compName;//单位名称
	@NotNull(message = "单位性质不能为空")
	private Long compType;//单位性质
	@NotNull(message = "行业代码不能为空")
	private Long industryCode;//行业代码
	@NotEmpty(message = "企业规模不能为空")
	private String staffAmount;//企业规模
	@NotEmpty(message = "单位电话区号不能为空")
	private String compTellArea;//单位电话区号
	@NotEmpty(message = "单位电话不能为空")
	private String compTell;//单位电话
	@NotEmpty(message = "单位区号+电话不能为空")
	private String compAllTell;//单位区号+电话
	@NotNull(message = "单位地址省不能为空")
	private Long compAddresProvince;//单位地址省
	@NotNull(message = "单位地址市不能为空")
	private Long compAddresCity;//单位地址市
	@NotNull(message = "单位地址区不能为空")
	private Long compAddresArea;//单位地址区
	@NotEmpty(message = "单位地址不能为空")
	private String compAddres;//单位地址
	@NotEmpty(message = "单位全地址不能为空")
	private String compAlladdress;//单位全地址
	@NotEmpty(message = "部门不能为空")
	private String compDept;//部门
	@NotEmpty(message = "职位不能为空")
	private String compDuty;//职位
	@NotNull(message = "入职日期不能为空")
	private String compJoinDate;//入职日期
	@NotNull(message = "薪资收入不能为空")
	private BigDecimal salary;//薪资收入
	@NotNull(message = "其他收入不能为空")
	private BigDecimal otherIncome;//其他收入
	/**薪资发放日*/
	@NotEmpty(message = "薪资发放日不能为空")
	private String salaryDelivery;
	@JsonIgnore
	private Date createTime;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Date modifyTime;
	@JsonIgnore
	private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public Long getCompType() {
		return compType;
	}

	public void setCompType(Long compType) {
		this.compType = compType;
	}

	public Long getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(Long industryCode) {
		this.industryCode = industryCode;
	}

	public String getStaffAmount() {
		return staffAmount;
	}

	public void setStaffAmount(String staffAmount) {
		this.staffAmount = staffAmount;
	}

	public String getCompTellArea() {
		return compTellArea;
	}

	public void setCompTellArea(String compTellArea) {
		this.compTellArea = compTellArea;
	}

	public String getCompTell() {
		return compTell;
	}

	public void setCompTell(String compTell) {
		this.compTell = compTell;
	}

	public String getCompAllTell() {
		return compAllTell;
	}

	public void setCompAllTell(String compAllTell) {
		this.compAllTell = compAllTell;
	}

	public Long getCompAddresProvince() {
		return compAddresProvince;
	}

	public void setCompAddresProvince(Long compAddresProvince) {
		this.compAddresProvince = compAddresProvince;
	}

	public Long getCompAddresCity() {
		return compAddresCity;
	}

	public void setCompAddresCity(Long compAddresCity) {
		this.compAddresCity = compAddresCity;
	}

	public Long getCompAddresArea() {
		return compAddresArea;
	}

	public void setCompAddresArea(Long compAddresArea) {
		this.compAddresArea = compAddresArea;
	}

	public String getCompAddres() {
		return compAddres;
	}

	public void setCompAddres(String compAddres) {
		this.compAddres = compAddres;
	}

	public String getCompAlladdress() {
		return compAlladdress;
	}

	public void setCompAlladdress(String compAlladdress) {
		this.compAlladdress = compAlladdress;
	}

	public String getCompDept() {
		return compDept;
	}

	public void setCompDept(String compDept) {
		this.compDept = compDept;
	}

	public String getCompDuty() {
		return compDuty;
	}

	public void setCompDuty(String compDuty) {
		this.compDuty = compDuty;
	}

	public String getCompJoinDate() {
		return compJoinDate;
	}

	public void setCompJoinDate(String compJoinDate) {
		this.compJoinDate = compJoinDate;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public BigDecimal getOtherIncome() {
		return otherIncome;
	}

	public void setOtherIncome(BigDecimal otherIncome) {
		this.otherIncome = otherIncome;
	}

	public String getSalaryDelivery() {
		return salaryDelivery;
	}

	public void setSalaryDelivery(String salaryDelivery) {
		this.salaryDelivery = salaryDelivery;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
}
