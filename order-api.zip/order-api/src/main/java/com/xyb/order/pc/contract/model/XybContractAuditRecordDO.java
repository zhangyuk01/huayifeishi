package com.xyb.order.pc.contract.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractAuditRecordDO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final Long serialVersionUID = -63467747617650514L;
	private Long id;
	private Long applyId;
	private Long contractId;
	/**合同审核主键*/
	private Long contractAuditId;
	/**处理方式*/
	private String disposeResult;
	/**记录信息*/
	private String recordInfo;
	/**记录人*/
	private String recordName;
	/**创建者姓名*/
	private Long createUser;
	/**创建时间*/
	private Date createTime;
	/**修改人*/
	private Long modifyUser;
	/**修改时间*/
	private Date modifyTime;
	/**合同退回原因*/
	private String backReason;
	/**合同退回原因中文描述*/
	private String backReasonName;
	/**拒贷原因*/
	private String refuseReason;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}
	public Long getContractAuditId() {
		return contractAuditId;
	}
	public void setContractAuditId(Long contractAuditId) {
		this.contractAuditId = contractAuditId;
	}
	public String getDisposeResult() {
		return disposeResult;
	}
	public void setDisposeResult(String disposeResult) {
		this.disposeResult = disposeResult;
	}
	public String getRecordInfo() {
		return recordInfo;
	}
	public void setRecordInfo(String recordInfo) {
		this.recordInfo = recordInfo;
	}
	public String getRecordName() {
		return recordName;
	}
	public void setRecordName(String recordName) {
		this.recordName = recordName;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getBackReason() {
		return backReason;
	}
	public void setBackReason(String backReason) {
		this.backReason = backReason;
	}
	public String getBackReasonName() {
		return backReasonName;
	}
	public void setBackReasonName(String backReasonName) {
		this.backReasonName = backReasonName;
	}
	public String getRefuseReason() {
		return refuseReason;
	}
	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}
	@Override
	public String toString() {
		return "XybContractAuditRecordDO [id=" + id + ", applyId=" + applyId + ", contractId=" + contractId
				+ ", contractAuditId=" + contractAuditId + ", disposeResult=" + disposeResult + ", recordInfo="
				+ recordInfo + ", recordName=" + recordName + ", createUser=" + createUser + ", createTime="
				+ createTime + ", modifyUser=" + modifyUser + ", modifyTime=" + modifyTime + ", backReason="
				+ backReason + ", backReasonName=" + backReasonName + ", refuseReason=" + refuseReason + "]";
	}

}
