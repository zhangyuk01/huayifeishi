package com.xyb.order.app.business.manage.model;

import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillinfoVO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	/**是否有下一页 Y:是 N:否*/
	private String isMore;
	List<AppBillInfoDO> appBillInfoDOs;

	public String getIsMore() {
		return isMore;
	}
	public void setIsMore(String isMore) {
		this.isMore = isMore;
	}
	public List<AppBillInfoDO> getAppBillInfoDOs() {
		return appBillInfoDOs;
	}
	public void setAppBillInfoDOs(List<AppBillInfoDO> appBillInfoDOs) {
		this.appBillInfoDOs = appBillInfoDOs;
	}
	
}
