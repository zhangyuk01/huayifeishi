package com.xyb.order.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author : houlvshuang
 * @projectName : util
 * @package : com.xyb.util
 * @description : 合规项目与深圳交互post工具类
 * @createDate : 2017/12/14 16:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class HttpTools {
    private static final Logger logger = LoggerFactory.getLogger(HttpTools.class);

	private static final String DEFAULT_CHARSET = "UTF-8";
	/**设置建立连接超时时间-2分钟*/
	private static final int DEFAULT_CONNECT_TIMEOUT = 1000 * 2 * 60;
	/**设置建立连接超时时间-2分钟*/
	private static final int DEFAULT_SOCKET_TIMEOUT = 1000 * 2 * 60;

	static CloseableHttpClient httpClient = null;

	static {
		ConnectionSocketFactory plainsf = PlainConnectionSocketFactory.getSocketFactory();
		LayeredConnectionSocketFactory sslsf = SSLConnectionSocketFactory.getSocketFactory();
		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory> create().register("http", plainsf)
				.register("https", sslsf).build();
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);

		RequestConfig config = RequestConfig.custom().setConnectTimeout(DEFAULT_CONNECT_TIMEOUT).setSocketTimeout(DEFAULT_SOCKET_TIMEOUT)
				.build();

		httpClient = HttpClients.custom().setConnectionManager(cm).setDefaultRequestConfig(config).build();
	}

	/**
	 * 发送get请求
	 * 
	 * @param url
	 * @return
	 */
	public static String sendGet(String url) {
		CloseableHttpResponse response = null;
		String ret = null;
		HttpGet httpGet = new HttpGet(url);
		try {
			response = httpClient.execute(httpGet, HttpClientContext.create());
			HttpEntity entity = response.getEntity();
			ret = EntityUtils.toString(entity, DEFAULT_CHARSET);
			/**确保完全接收*/
			EntityUtils.consume(entity);
		} catch (Exception e) {
			logger.error("sendGet方法发送get请求失败,接口地址:"+url,e);
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error("get请求处理失败"+url,e);
				}
			}
		}
		return ret;
	}

	/**
	 * 发送post请求
	 * 
	 * @param url
	 * @return
	 */
	public static String sendPost(List<NameValuePair> params, String url) {
		CloseableHttpResponse response = null;
		String ret = null;
		HttpPost httpPost = new HttpPost(url);
		try {
			if (params != null && params.size() > 0) {
				UrlEncodedFormEntity urlform = new UrlEncodedFormEntity(params, DEFAULT_CHARSET);
				httpPost.setEntity(urlform);
			}
			response = httpClient.execute(httpPost, HttpClientContext.create());
			HttpEntity entity = response.getEntity();
			ret = EntityUtils.toString(entity, DEFAULT_CHARSET);
			/**确保完全接收*/
			EntityUtils.consume(entity);
		} catch (Exception e) {
			logger.error("sendPost方法发送post请求失败,接口地址:"+url,e);
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error("post请求处理失败"+url,e);
				}
			}
		}
		return ret;
	}

	public static String sendPostStream(String url, String param) {
		CloseableHttpResponse response = null;
		String ret = null;
		HttpPost httpPost = new HttpPost(url);
		try {
			if (param != null) {
				StringEntity paramEntity = new StringEntity(param, DEFAULT_CHARSET);
				httpPost.setEntity(paramEntity);
			}

			response = httpClient.execute(httpPost, HttpClientContext.create());
			HttpEntity entity = response.getEntity();
			ret = EntityUtils.toString(entity, DEFAULT_CHARSET);
			// 确保接收完全
			EntityUtils.consume(entity);
		} catch (Exception e) {
			logger.error("sendPostStream方法发送post请求失败,接口地址:"+url,e);
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
					logger.error("post请求处理失败"+url,e);
				}
			}
		}
		return ret;
	}

	public static String sendPost(Map<String, String> params, String url) {
		/**设置参数*/
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		Iterator<Entry<String, String>> iterator = params.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, String> elem = (Entry<String, String>) iterator.next();
			list.add(new BasicNameValuePair(elem.getKey(), elem.getValue()));
		}
		return sendPost(list, url);
	}

	public static String sendPost(String url, String p, String charset) throws Exception{
		OutputStream out = null;
		BufferedReader in = null;
		String result = "";
		try {
			URL realUrl = new URL(url);
			HttpURLConnection conn = getConnection(realUrl);

			conn.setRequestProperty("Content-Type", "application/json");
			conn.addRequestProperty("accept", "*/*");
			conn.addRequestProperty("connection", "Keep-Alive");
			conn.addRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = conn.getOutputStream();
			if (p != null) {
				// 发送请求参数
				out.write(p.getBytes(charset));
				// flush输出流的缓冲
				out.flush();
			}
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(new InputStreamReader(
					conn.getInputStream(), charset));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			logger.error("sendPost方法发送post请求失败,接口地址:"+url,e);
			throw new RuntimeException("post请求失败", e);
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				logger.error("post请求处理失败"+url,ex);

			}
		}
		return result;
	}
	
	static public HttpURLConnection getConnection(URL url) throws Exception{
		HttpURLConnection connection = null;
		try {
			System.setProperty("https.protocols","TLSv1");
			if (url.getProtocol().toUpperCase().startsWith("HTTPS")) {
				SSLContext ctx = SSLContext.getInstance("TLSv1");
				ctx.init(new KeyManager[0],
						new TrustManager[] { new X509TrustManager() {

							@Override
							public void checkClientTrusted(
									X509Certificate[] arg0, String arg1)
									throws CertificateException {
							}

							@Override
							public void checkServerTrusted(
									X509Certificate[] arg0, String arg1)
									throws CertificateException {
							}

							@Override
							public X509Certificate[] getAcceptedIssuers() {
								return null;
							}

						} }, new SecureRandom());

				HttpsURLConnection conn = (HttpsURLConnection) url
						.openConnection();
				conn.setSSLSocketFactory(ctx.getSocketFactory());
				conn.setConnectTimeout(30000);//修改为30秒 原来为10秒
				conn.setReadTimeout(30000);//修改为30秒 原来为10秒

				conn.setHostnameVerifier(new HostnameVerifier() {
					@Override
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				});

				connection = conn;
			} else {
				connection = (HttpURLConnection) url.openConnection();
			}

		} catch (Exception e) {
			logger.error("getConnection方法发送post请求失败,接口地址:"+url,e);
		}

		return connection;
	}

}
