package com.xyb.order.app.client.quickloan.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;

/**
 * 
* @className : ApplySubmitOptionService.java
* @package : com.xyb.order.app.client.personinfo.service
* @description : 申请选择提交接口
* @author : zhanghao
* @createDate : 2018年12月18日下午3:35:39
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
public interface ApplySubmitOptionService {

	/**
	 * 确认申请选择业务逻辑方法 
	 * @return
	 */
	RestResponse confirmSubmitOption(ApplySubmitDTO applySubmitDTO);
	
	/**
	 * 申请选择业务逻辑方法 
	 * @return
	 */
	RestResponse applySubmitOption();
	
}
