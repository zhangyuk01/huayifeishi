package com.xyb.order.pc.applybill.model;
import java.util.Date;
import com.beiming.kun.framework.model.IBaseModel;

/**
 * 申请单列表页数据
 * @author         zhangyu
 * @date           2018/10/16 4:31 PM
*/
public class ApplyBillInfoQueryDO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	/**申请主表ID*/
	private Long mainId;
	/**申请id*/
	private Long applyId;
	/**资询id*/
	private Long consultId;
	/**客户姓名*/
	private String name; 
	/**手机号码*/
	private String tell; 
	/**身份证号*/
	private String idcard; 
	/**营业组ID*/
	private String orgId; 
	/**销售团队*/
	private String orgTeam; 
	/**销售人员*/
	private String serviceName; 
	/**咨询日期*/
	private Date consultDate; 
	/**产品*/
	private String productName; 
	/**进件状态*/
	private Long state; 
	/**当前登录用户id*/
	private String loginId;
	/**营业组ID*/
	private String teamOrgId;
	/**进件时间*/
	private Date applyTime; 
	/**退回原因*/
	private String rejectReason;
	/**系统审核结果*/
	private String auditResult;
	/**推荐人姓名*/
	private String recommender;

	public Long getMainId() {
		return mainId;
	}

	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getConsultId() {
		return consultId;
	}

	public void setConsultId(Long consultId) {
		this.consultId = consultId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTell() {
		return tell;
	}

	public void setTell(String tell) {
		this.tell = tell;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getOrgTeam() {
		return orgTeam;
	}

	public void setOrgTeam(String orgTeam) {
		this.orgTeam = orgTeam;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getConsultDate() {
		return consultDate;
	}

	public void setConsultDate(Date consultDate) {
		this.consultDate = consultDate;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Long getState() {
		return state;
	}

	public void setState(Long state) {
		this.state = state;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getTeamOrgId() {
		return teamOrgId;
	}

	public void setTeamOrgId(String teamOrgId) {
		this.teamOrgId = teamOrgId;
	}

	public Date getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public String getAuditResult() {
		return auditResult;
	}

	public void setAuditResult(String auditResult) {
		this.auditResult = auditResult;
	}

	public String getRecommender() {
		return recommender;
	}

	public void setRecommender(String recommender) {
		this.recommender = recommender;
	}

	@Override
	public String toString() {
		return "ApplyBillInfoQueryDO{" +
				"mainId=" + mainId +
				", applyId=" + applyId +
				", consultId=" + consultId +
				", name='" + name + '\'' +
				", tell='" + tell + '\'' +
				", idcard='" + idcard + '\'' +
				", orgId='" + orgId + '\'' +
				", orgTeam='" + orgTeam + '\'' +
				", serviceName='" + serviceName + '\'' +
				", consultDate=" + consultDate +
				", productName='" + productName + '\'' +
				", state=" + state +
				", loginId='" + loginId + '\'' +
				", teamOrgId='" + teamOrgId + '\'' +
				", applyTime=" + applyTime +
				", rejectReason='" + rejectReason + '\'' +
				", auditResult='" + auditResult + '\'' +
				", recommender='" + recommender + '\'' +
				'}';
	}
}
