package com.xyb.order.pc.creditreport.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class AuditDetailPhoneDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id;//主键ID
	private Long custId; //客户ID
	private Long applyId;//申请单ID
	private Date openDate;//开户日期
	private Long realAuth;//实名认证
	private String realAuthStr;
	private String remark;//电话详单备注
	private Integer month1; //当前月
	private Integer month2; //当前月-1
	private Integer month3; //当前月-2

	private Date createTime;//创建时间
	private Long createUser;//创建人
	private Date modifyTime;//修改时间
	private Long modifyUser;//修改人

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public Long getRealAuth() {
		return realAuth;
	}
	public void setRealAuth(Long realAuth) {
		this.realAuth = realAuth;
	}
	public String getRealAuthStr() {
		return realAuthStr;
	}
	public void setRealAuthStr(String realAuthStr) {
		this.realAuthStr = realAuthStr;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getMonth1() {
		return month1;
	}
	public void setMonth1(Integer month1) {
		this.month1 = month1;
	}
	public Integer getMonth2() {
		return month2;
	}
	public void setMonth2(Integer month2) {
		this.month2 = month2;
	}
	public Integer getMonth3() {
		return month3;
	}
	public void setMonth3(Integer month3) {
		this.month3 = month3;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
}
