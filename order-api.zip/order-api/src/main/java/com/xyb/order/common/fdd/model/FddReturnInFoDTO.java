package com.xyb.order.common.fdd.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @description:    法大大返回数据model
 * @author:         xieqingyang
 * @createDate:     2018/8/2 上午11:57
*/
public class FddReturnInFoDTO implements IBaseModel {

    private static final long serialVersionUID = -8947564637551962840L;
    /**交易号*/
    @NotEmpty(message = "交易号不能为空")
    private String transaction_id;

    /**合同编号*/
    @NotEmpty(message = "合同编号不能为空")
    private String contract_id;

    /**签章结果代码 3000(签章成功)3001(签章失败)*/
    @NotEmpty(message = "签章结果代码不能为空")
    private String result_code;

    /**签章结果描述 签章结果描述信息*/
    @NotEmpty(message = "签章结果描述不能为空")
    private String result_desc;

    /**下载地址 下载签署后的合同*/
    private String download_url;

    /**查看地址 查看签署后的合同*/
    private String viewpdf_url;

    /**请求时间 yyyyMMddHHmmss*/
    @NotEmpty(message = "请求时间不能为空")
    private String timestamp;

    /**摘要 Base64( SHA1(
     app_id
     +MD5(timestamp) +SHA1(app_secret+transacti
     on_id) )
     )
     建议接入平台方进行校验*/
    @NotEmpty(message = "摘要不能为空")
    private String msg_digest;

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getContract_id() {
        return contract_id;
    }

    public void setContract_id(String contract_id) {
        this.contract_id = contract_id;
    }

    public String getResult_code() {
        return result_code;
    }

    public void setResult_code(String result_code) {
        this.result_code = result_code;
    }

    public String getResult_desc() {
        return result_desc;
    }

    public void setResult_desc(String result_desc) {
        this.result_desc = result_desc;
    }

    public String getDownload_url() {
        return download_url;
    }

    public void setDownload_url(String download_url) {
        this.download_url = download_url;
    }

    public String getViewpdf_url() {
        return viewpdf_url;
    }

    public void setViewpdf_url(String viewpdf_url) {
        this.viewpdf_url = viewpdf_url;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getMsg_digest() {
        return msg_digest;
    }

    public void setMsg_digest(String msg_digest) {
        this.msg_digest = msg_digest;
    }

    @Override
    public String toString() {
        return "FddReturnInFoDTO{" +
                "transaction_id='" + transaction_id + '\'' +
                ", contract_id='" + contract_id + '\'' +
                ", result_code='" + result_code + '\'' +
                ", result_desc='" + result_desc + '\'' +
                ", download_url='" + download_url + '\'' +
                ", viewpdf_url='" + viewpdf_url + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", msg_digest='" + msg_digest + '\'' +
                '}';
    }
}
