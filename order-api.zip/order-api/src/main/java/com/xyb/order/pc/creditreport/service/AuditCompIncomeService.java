package com.xyb.order.pc.creditreport.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.model.AuditAllCompIncomeDTO;

/**
 * @ClassName AuditCompIncomeService
 * @author ZhangYu
 * @date 2018年4月23号
 */

public interface AuditCompIncomeService {

	/**
	 * 根据申请单ID查询企业收入证明 
	 * @param applyId
	 * @return
	 */
	RestResponse queryInfoByApplyId(Long applyId)throws Exception;
	
	 /**
	  * 暂存企业收入证明
	  * @param auditAllCompIncomeDTO
	  * @return
	  */
	 RestResponse updateOrAddInfoByApplyId(AuditAllCompIncomeDTO auditAllCompIncomeDTO)throws Exception;
	 
	 /**
	  * 根据ID修改删除标记状态 
	  * @param id
	  * @return
	  */
	 RestResponse updateAlreadyDelFlagById(Long id)throws Exception;
	

}
