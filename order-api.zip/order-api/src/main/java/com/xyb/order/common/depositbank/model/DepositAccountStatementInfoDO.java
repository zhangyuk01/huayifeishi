package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;
import java.util.Objects;

/**
 * 存管账户信息表
 * @author         xieqingyang
 * @date           2018/11/23 10:20 AM
*/
public class DepositAccountStatementInfoDO implements IBaseModel {

    private static final long serialVersionUID = 3009510514634171847L;
    /**主键ID*/
    private Long id;
    /**用户信息表主键ID*/
    private Long clientId;
    /**资产系统借款人账户ID*/
    private Long accId;
    /**客户银行卡ID*/
    private Long clientBankId;
    /**是否有效*/
    private Long isValid;
    /**存管开户平台*/
    private Long openPlatform;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;
    /**修改时间*/
    private Date modifyTime;
    /**修改人*/
    private Long modifyUser;
    /**电子账户(开户返回的电子账户)*/
    private String cardNo;
    /**客户号*/
    private String customerNo;
    /**三方绑定编号*/
    private String serialNo;
    /**借款人放款手续费和还款金额签约状态  大类2692*/
    private Long isSign;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getAccId() {
        return accId;
    }

    public void setAccId(Long accId) {
        this.accId = accId;
    }

    public Long getClientBankId() {
        return clientBankId;
    }

    public void setClientBankId(Long clientBankId) {
        this.clientBankId = clientBankId;
    }

    public Long getIsValid() {
        return isValid;
    }

    public void setIsValid(Long isValid) {
        this.isValid = isValid;
    }

    public Long getOpenPlatform() {
        return openPlatform;
    }

    public void setOpenPlatform(Long openPlatform) {
        this.openPlatform = openPlatform;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Long getIsSign() {
        return isSign;
    }

    public void setIsSign(Long isSign) {
        this.isSign = isSign;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DepositAccountStatementInfoDO that = (DepositAccountStatementInfoDO) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(clientId, that.clientId) &&
                Objects.equals(accId, that.accId) &&
                Objects.equals(clientBankId, that.clientBankId) &&
                Objects.equals(isValid, that.isValid) &&
                Objects.equals(openPlatform, that.openPlatform) &&
                Objects.equals(createTime, that.createTime) &&
                Objects.equals(createUser, that.createUser) &&
                Objects.equals(modifyTime, that.modifyTime) &&
                Objects.equals(modifyUser, that.modifyUser) &&
                Objects.equals(cardNo, that.cardNo) &&
                Objects.equals(customerNo, that.customerNo) &&
                Objects.equals(serialNo, that.serialNo) &&
                Objects.equals(isSign,that.isSign);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, clientId, accId, clientBankId, isValid, openPlatform, createTime, createUser, modifyTime, modifyUser, cardNo, customerNo, serialNo, isSign);
    }

    @Override
    public String toString() {
        return "DepositAccountStatementInfoDO{" +
                "id=" + id +
                ", clientId=" + clientId +
                ", accId=" + accId +
                ", clientBankId=" + clientBankId +
                ", isValid=" + isValid +
                ", openPlatform=" + openPlatform +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                ", cardNo='" + cardNo + '\'' +
                ", customerNo='" + customerNo + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", isSign=" + isSign +
                '}';
    }
}
