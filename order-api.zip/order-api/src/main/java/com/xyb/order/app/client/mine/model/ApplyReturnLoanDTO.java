package com.xyb.order.app.client.mine.model;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyReturnLoanDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	@NotNull(message="还款计划表ID不能为空")
	private Long id;//还款计划表ID
	
	private Integer currendPeriod;//当前期数

	private BigDecimal shouldAlsoAmount;//应还金额

	@NotNull(message="当前状态不能为空")
	private Long currentPaymentStatus;//当前应还状态 2320-待还款  2322-逾期中
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getCurrendPeriod() {
		return currendPeriod;
	}
	public void setCurrendPeriod(Integer currendPeriod) {
		this.currendPeriod = currendPeriod;
	}
	public BigDecimal getShouldAlsoAmount() {
		return shouldAlsoAmount;
	}
	public void setShouldAlsoAmount(BigDecimal shouldAlsoAmount) {
		this.shouldAlsoAmount = shouldAlsoAmount;
	}
	public Long getCurrentPaymentStatus() {
		return currentPaymentStatus;
	}
	public void setCurrentPaymentStatus(Long currentPaymentStatus) {
		this.currentPaymentStatus = currentPaymentStatus;
	}
}
