package com.xyb.order.common.material.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * @description:    app上传图片传入参数
 * @author:         xieqingyang
 * @createDate:     2018/7/5 下午6:23
*/
public class FileUploadAppDTO implements IBaseModel {

    private static final long serialVersionUID = -6082801847399811544L;
    /**图片信息*/
    @NotEmpty(message = "图片信息不能为空")
    private String imageFiles;
    /**申请单ID*/
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;
    /**图片类型*/
    @NotEmpty(message = "图片类型不能为空")
    private String fileCode;

    public String getImageFiles() {
        return imageFiles;
    }

    public void setImageFiles(String imageFiles) {
        this.imageFiles = imageFiles;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getFileCode() {
        return fileCode;
    }

    public void setFileCode(String fileCode) {
        this.fileCode = fileCode;
    }

    @Override
    public String toString() {
        return "FileUploadAppDTO{" +
                "imageFiles='" + imageFiles + '\'' +
                ", applyId=" + applyId +
                ", fileCode='" + fileCode + '\'' +
                '}';
    }
}
