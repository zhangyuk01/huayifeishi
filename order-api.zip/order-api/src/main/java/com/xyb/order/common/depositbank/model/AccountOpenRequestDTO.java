package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 存管新开户请求参数
 * @author         xieqingyang
 * @date           2018/11/23 4:00 PM
*/
public class AccountOpenRequestDTO implements IBaseModel {

    private static final long serialVersionUID = 6044377774809219023L;
    /**系统ID 北京2001 深圳3001*/
    private Long sysId;
    /**账户类型，必填，账户类型(普通户200201,企业户200204)，6(位数)*/
    @SignField(order = 0)
    private String account_type;
    /**用户角色，必填1：出借角色，2：借款角色，3：代偿角色，1(位数)*/
    @SignField(order = 1)
    private String role_type;
    /**成功跳转地址，必填，成功地址，256(位数)*/
    @SignField(order = 2)
    private String success_url;
    /**失败跳转地址，必填，失败跳转地址，256(位数)*/
    @SignField(order = 3)
    private String fail_url;
    /**手机号*/
    @SignField(order = 4)
    private String mobile;
    /**交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面*/
    private String client;
    /**商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户*/
    private String custom;
    /**客户端ip*/
    private String client_ip;
    /**电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）*/
    private String client_service;
    /**身份证*/
    private String idCard;
    /**证件号码类型，默认个人身份证//"15","个人身份证","01","企业证件"*/
    private String idCardType;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getRole_type() {
        return role_type;
    }

    public void setRole_type(String role_type) {
        this.role_type = role_type;
    }

    public String getSuccess_url() {
        return success_url;
    }

    public void setSuccess_url(String success_url) {
        this.success_url = success_url;
    }

    public String getFail_url() {
        return fail_url;
    }

    public void setFail_url(String fail_url) {
        this.fail_url = fail_url;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }

    public String getClient_ip() {
        return client_ip;
    }

    public void setClient_ip(String client_ip) {
        this.client_ip = client_ip;
    }

    public String getClient_service() {
        return client_service;
    }

    public void setClient_service(String client_service) {
        this.client_service = client_service;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getIdCardType() {
        return idCardType;
    }

    public void setIdCardType(String idCardType) {
        this.idCardType = idCardType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountOpenRequestDTO that = (AccountOpenRequestDTO) o;
        return Objects.equals(sysId, that.sysId) &&
                Objects.equals(account_type, that.account_type) &&
                Objects.equals(role_type, that.role_type) &&
                Objects.equals(success_url, that.success_url) &&
                Objects.equals(fail_url, that.fail_url) &&
                Objects.equals(mobile, that.mobile) &&
                Objects.equals(client, that.client) &&
                Objects.equals(custom, that.custom) &&
                Objects.equals(client_ip, that.client_ip) &&
                Objects.equals(client_service, that.client_service) &&
                Objects.equals(idCard, that.idCard) &&
                Objects.equals(idCardType,that.idCardType);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, account_type, role_type, success_url, fail_url, mobile, client, custom, client_ip, client_service, idCard, idCardType);
    }

    @Override
    public String toString() {
        return "AccountOpenRequestDTO{" +
                "sysId=" + sysId +
                ", account_type='" + account_type + '\'' +
                ", role_type='" + role_type + '\'' +
                ", success_url='" + success_url + '\'' +
                ", fail_url='" + fail_url + '\'' +
                ", mobile='" + mobile + '\'' +
                ", client='" + client + '\'' +
                ", custom='" + custom + '\'' +
                ", client_ip='" + client_ip + '\'' +
                ", client_service='" + client_service + '\'' +
                ", idCard='" + idCard + '\'' +
                ", idCardType='" + idCardType + '\'' +
                '}';
    }
}
