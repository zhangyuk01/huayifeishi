package com.xyb.order.pc.consultation.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.math.BigDecimal;

/**
 * Created by xieqingyang on 2018/3/26.
 */
public class ConsultationInFoDO  implements IBaseModel {

    private static final long serialVersionUID = 1L;

    // -- 个人信息
    private String product; // --申请产品
    private BigDecimal expectMoney = BigDecimal.ZERO;// -- 申请借款金额
    private String name; // --客户姓名
    private String idCard; // --身份证
    private String tell; // --手机号
    private String hometownAddress;// -- 本市住址地址

    // -- 单位信息
    private String workName;// -- 工作单位名称
    private String workPhone;// -- 工作单位电话
    private String workPhoneAreaCode;// -- 工作电话区号

    private String workAddress;// -- 工作单位详细地址

    // -- 联系人信息
    private String familyContactName;// -- 家庭联系人
    private String familyContactPhone;// -- 家庭联系人电话
    private String familyContactRelationship;// -- 家庭联系人与本人关系

    private String workCertificateName;// -- 工作证明人
    private String workCertificatePhone;// -- 工作证明人电话
    private String workCertificateRelationship;// -- 工作证明人与本人关系

    private String emergencyContactName;// -- 紧急联系人
    private String emergencyContactPhone;// -- 紧急联系人电话
    private String emergencyContactRelationship;// -- 紧急联系人与本人关系

    // -- 工作人信息
    private String area; // --营业部
    private String dept; // --团队
    private String teamManager;// --团队经理
    private String manager;// --客户经理

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public BigDecimal getExpectMoney() {
        return expectMoney;
    }

    public void setExpectMoney(BigDecimal expectMoney) {
        this.expectMoney = expectMoney;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getTell() {
        return tell;
    }

    public void setTell(String tell) {
        this.tell = tell;
    }

    public String getHometownAddress() {
        return hometownAddress;
    }

    public void setHometownAddress(String hometownAddress) {
        this.hometownAddress = hometownAddress;
    }

    public String getWorkName() {
        return workName;
    }

    public void setWorkName(String workName) {
        this.workName = workName;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    public String getWorkPhoneAreaCode() {
        return workPhoneAreaCode;
    }

    public void setWorkPhoneAreaCode(String workPhoneAreaCode) {
        this.workPhoneAreaCode = workPhoneAreaCode;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public String getFamilyContactName() {
        return familyContactName;
    }

    public void setFamilyContactName(String familyContactName) {
        this.familyContactName = familyContactName;
    }

    public String getFamilyContactPhone() {
        return familyContactPhone;
    }

    public void setFamilyContactPhone(String familyContactPhone) {
        this.familyContactPhone = familyContactPhone;
    }

    public String getFamilyContactRelationship() {
        return familyContactRelationship;
    }

    public void setFamilyContactRelationship(String familyContactRelationship) {
        this.familyContactRelationship = familyContactRelationship;
    }

    public String getWorkCertificateName() {
        return workCertificateName;
    }

    public void setWorkCertificateName(String workCertificateName) {
        this.workCertificateName = workCertificateName;
    }

    public String getWorkCertificatePhone() {
        return workCertificatePhone;
    }

    public void setWorkCertificatePhone(String workCertificatePhone) {
        this.workCertificatePhone = workCertificatePhone;
    }

    public String getWorkCertificateRelationship() {
        return workCertificateRelationship;
    }

    public void setWorkCertificateRelationship(String workCertificateRelationship) {
        this.workCertificateRelationship = workCertificateRelationship;
    }

    public String getEmergencyContactName() {
        return emergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactPhone() {
        return emergencyContactPhone;
    }

    public void setEmergencyContactPhone(String emergencyContactPhone) {
        this.emergencyContactPhone = emergencyContactPhone;
    }

    public String getEmergencyContactRelationship() {
        return emergencyContactRelationship;
    }

    public void setEmergencyContactRelationship(String emergencyContactRelationship) {
        this.emergencyContactRelationship = emergencyContactRelationship;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getTeamManager() {
        return teamManager;
    }

    public void setTeamManager(String teamManager) {
        this.teamManager = teamManager;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }
}
