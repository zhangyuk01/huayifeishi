package com.xyb.order.app.client.personinfo.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class PrivateDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private String id;//主键ID
	@JsonIgnore
	private Long applyId;//申请单ID
	@JsonIgnore
	private Long cusId;//客户ID
	private String enterpriseName;//公司名称
	private Long enteType;//公司类型
	private String regDate;//注册时间
	private Long palace;//营业场所
	private BigDecimal stockRatio;//占股比例
	private Long staffAmount;//企业规模

	@JsonIgnore
	private Date createTime;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Date modifyTime;
	@JsonIgnore
	private Long modifyUser;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getEnterpriseName() {
		return enterpriseName;
	}
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}
	public Long getEnteType() {
		return enteType;
	}
	public void setEnteType(Long enteType) {
		this.enteType = enteType;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public Long getPalace() {
		return palace;
	}
	public void setPalace(Long palace) {
		this.palace = palace;
	}
	public BigDecimal getStockRatio() {
		return stockRatio;
	}
	public void setStockRatio(BigDecimal stockRatio) {
		this.stockRatio = stockRatio;
	}
	public Long getStaffAmount() {
		return staffAmount;
	}
	public void setStaffAmount(Long staffAmount) {
		this.staffAmount = staffAmount;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	
}
