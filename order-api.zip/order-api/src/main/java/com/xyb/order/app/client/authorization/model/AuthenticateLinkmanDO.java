package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* 认证相关联系人信息
* @author         xieqingyang
* @date           2018/5/16 下午7:31
*/
public class AuthenticateLinkmanDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private String name;
    private String phone;
    private Long type;
    private Long relation;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public Long getRelation() {
        return relation;
    }

    public void setRelation(Long relation) {
        this.relation = relation;
    }
}
