package com.xyb.order.app.client.mine.model;


import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordProcessDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	private String userId;
	
	private List<Integer> list;
	
	public List<Integer> getList() {
		return list;
	}

	public void setList(List<Integer> list) {
		this.list = list;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
