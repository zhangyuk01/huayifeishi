package com.xyb.order.pc.apply.already.model;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 申请已办合同信息
 * @createDate : 2018/06/05 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyAlreadyContractInfoVO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7243366106236834585L;

	/**合同编号*/
	private String contractNum;
	/**客户姓名*/
	private String custName;
	/**批贷金额*/
	private BigDecimal agreeAmount;
	/**批贷期限*/
	private int agreeLimit;
	/**批贷产品*/
	private String agreeProductName;
	/**月还金额*/
	private BigDecimal monthRepaymentMoney;
	/**合同生效时间*/
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date loanTime;
	/**合同失效时间(最后还款日)*/
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date lastPlanDate;
	/**还款日*/
	private int repDate;
	public String getContractNum() {
		return contractNum;
	}
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public int getAgreeLimit() {
		return agreeLimit;
	}
	public void setAgreeLimit(int agreeLimit) {
		this.agreeLimit = agreeLimit;
	}
	public String getAgreeProductName() {
		return agreeProductName;
	}
	public void setAgreeProductName(String agreeProductName) {
		this.agreeProductName = agreeProductName;
	}
	public BigDecimal getMonthRepaymentMoney() {
		return monthRepaymentMoney;
	}
	public void setMonthRepaymentMoney(BigDecimal monthRepaymentMoney) {
		this.monthRepaymentMoney = monthRepaymentMoney;
	}
	public Date getLoanTime() {
		return loanTime;
	}
	public void setLoanTime(Date loanTime) {
		this.loanTime = loanTime;
	}
	public Date getLastPlanDate() {
		return lastPlanDate;
	}
	public void setLastPlanDate(Date lastPlanDate) {
		this.lastPlanDate = lastPlanDate;
	}
	public int getRepDate() {
		return repDate;
	}
	public void setRepDate(int repDate) {
		this.repDate = repDate;
	}
	@Override
	public String toString() {
		return "ApplyAlreadyContractInfoVO [contractNum=" + contractNum + ", custName=" + custName + ", agreeAmount="
				+ agreeAmount + ", agreeLimit=" + agreeLimit + ", agreeProductName=" + agreeProductName
				+ ", monthRepaymentMoney=" + monthRepaymentMoney + ", loanTime=" + loanTime + ", lastPlanDate="
				+ lastPlanDate + ", repDate=" + repDate + "]";
	}
	
}
