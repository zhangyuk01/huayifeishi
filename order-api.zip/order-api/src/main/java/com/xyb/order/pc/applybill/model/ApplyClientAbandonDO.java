package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyClientAbandonDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //客户放弃ID
	private String label;//客户放弃原因

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}

}
