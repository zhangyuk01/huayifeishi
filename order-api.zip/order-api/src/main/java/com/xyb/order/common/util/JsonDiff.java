package com.xyb.order.common.util;

import com.xyb.order.common.currency.model.TableModifyLogDTO;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.io.IOUtils;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.*;


/**
 * Created by xieqingyang on 2017/8/17.
 * 比对两个字符串的不同
 */
public class JsonDiff {

    private Map<String,Object> diffMap = new HashMap<>();
    private List<TableModifyLogDTO> modifyLogDTOS = new ArrayList<TableModifyLogDTO>();
    private String tableName;// -- 表名称
    private Long tableKey;// -- 表主键
    private Long createUser;// -- 创建人
    private Map<String,Object> noNeedMap = new HashMap<>();// -- 不需要比对的字符串集

    /**
     * @param oldValue 原数据json串（已保存数据）
     * @param newValue 新数据json串（待保存数据）
     */
    public void getDiff(String oldValue, String newValue){
        JSONObject json1 =  JSONObject.fromObject(oldValue);
        JSONObject json2 =  JSONObject.fromObject(newValue);
        compareJson(json1, json2,null);
    }

    public void compareJson(JSONObject json1, JSONObject json2,String key) {
        Iterator<String> i = json1.keys();
        while (i.hasNext()) {
            key =  i.next();
            if (!noNeedMap.containsKey(key)) {
                compareJson(json1.get(key), json2.get(key),key);
            }
        }
    }
    public void compareJson(Object json1, Object json2, String key) {
        if (json1 instanceof JSONObject && json2 instanceof JSONObject) {
            compareJson((JSONObject) json1, (JSONObject) json2, key);
        } else if (json1 instanceof JSONArray && json2 instanceof JSONArray) {
            compareJson((JSONArray) json1, (JSONArray) json2, key);
        } else if (json1 instanceof String && json2 instanceof String) {
            compareJson((String) json1, (String) json2, key);
        } else {
            compareJson(json1.toString(), json2.toString(), key);
        }
    }
    public void compareJson(String str1, String str2, String key) {
         if (!str1.equals(str2)) {
            if (!StringUtils.isNullOrEmpty(str1)) {
                TableModifyLogDTO modifyLogDTO = new TableModifyLogDTO();
                modifyLogDTO.setCreateUser(createUser);
                modifyLogDTO.setTableField(key);
                modifyLogDTO.setTableKey(tableKey);
                modifyLogDTO.setTableName(tableName);
                modifyLogDTO.setModifyNewValue(str2);
                modifyLogDTO.setModifyOldValue(str1);
                modifyLogDTOS.add(modifyLogDTO);
            }
            diffMap.put(key, str2);
        }
    }
    public void compareJson(JSONArray json1,JSONArray json2,String key) {
        Iterator i1= json1.iterator();
        Iterator i2= json2.iterator();
        while ( i1.hasNext()) {
            compareJson(i1.next(), i2.next(),key);
        }
    }

    public boolean getState(){
        if (diffMap == null || diffMap.size() == 0){
            return false;
        }else {
            return true;
        }
    }

    public JSONObject getJson(String url) {
        try {
            URL url1 = new URL(url);
            InputStream in = url1.openStream();
            OutputStream out = new ByteArrayOutputStream();
            IOUtils.copy(in, out);
            String aa = out.toString();
            in.close();
            out.close();
            return JSONObject.fromObject(aa);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JSONObject();
    }

    private Map<String,Object> list2Map(String[] ss){
        Map<String,Object> noNeedMap = new HashMap<>();
        for (String s:ss){
            noNeedMap.put(s,"");
        }
        return noNeedMap;
    }

    public void setNoNeedMap(String[] noNeedMap) {
        this.noNeedMap = list2Map(noNeedMap);
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public void setTableKey(Long tableKey) {
        this.tableKey = tableKey;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public List<TableModifyLogDTO> getModifyLogDTOS() {
        return modifyLogDTOS;
    }
}
