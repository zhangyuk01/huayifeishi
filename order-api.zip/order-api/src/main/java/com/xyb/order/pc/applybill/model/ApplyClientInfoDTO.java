package com.xyb.order.pc.applybill.model;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyClientInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id; //id
	private Long applyId;//申请单ID
	private Long mainId; //申请主表ID
	@NotEmpty(message = "姓名不能为空")
	private String name; //姓名
	@NotNull(message = "性别不能为空")
	private Long gender; //性别
	private String genderStr;
	@NotNull(message = "出生日期不能为空")
	private Date birthday; //出生日期
	private String idcard; //身份证号
	private String phone; //手机号
	@NotNull(message = "民族不能为空")
	private Integer nation; //民族
	private String nationStr;
	private String address; //身份证上的住址
	private Long isvalid; //身份证是否在有效期 0 无效 1 有效
	private String isValidStr;
	@NotNull(message = "身份证有效日期起始日期不能为空")
	private Date idcardStartTime; //有效日期
	@NotNull(message = "身份证有效日期终止日期不能为空")
	private Date idcardEndTime; //有效日期
	@NotEmpty(message = "身份证签发机关不能为空")
	private String idcardPoliceStation;// 身份证签发机关
	private String frontFileKey;//图片上传正面Key
	private String backFileKey;//图片上传背面Key
	private String idcardFrontSide; //身份证正面图片存储路径
	private String idcardBackSide; //身份证背面图片存储路径
	private String certificationState; //身份信息认证状态 0-未认证 1-已认证
	private Date createTime;
	private Date modifyTime;
	private Long modifyUser;
	private Long createUser;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getGender() {
		return gender;
	}
	public void setGender(Long gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getNation() {
		return nation;
	}
	public void setNation(Integer nation) {
		this.nation = nation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getIsvalid() {
		return isvalid;
	}
	public void setIsvalid(Long isvalid) {
		this.isvalid = isvalid;
	}
	public String getIsValidStr() {
		return isValidStr;
	}
	public void setIsValidStr(String isValidStr) {
		this.isValidStr = isValidStr;
	}
	public Date getIdcardStartTime() {
		return idcardStartTime;
	}
	public void setIdcardStartTime(Date idcardStartTime) {
		this.idcardStartTime = idcardStartTime;
	}
	public Date getIdcardEndTime() {
		return idcardEndTime;
	}
	public void setIdcardEndTime(Date idcardEndTime) {
		this.idcardEndTime = idcardEndTime;
	}
	public String getIdcardPoliceStation() {
		return idcardPoliceStation;
	}
	public void setIdcardPoliceStation(String idcardPoliceStation) {
		this.idcardPoliceStation = idcardPoliceStation;
	}
	public String getFrontFileKey() {
		return frontFileKey;
	}
	public void setFrontFileKey(String frontFileKey) {
		this.frontFileKey = frontFileKey;
	}
	public String getBackFileKey() {
		return backFileKey;
	}
	public void setBackFileKey(String backFileKey) {
		this.backFileKey = backFileKey;
	}
	public String getIdcardFrontSide() {
		return idcardFrontSide;
	}
	public void setIdcardFrontSide(String idcardFrontSide) {
		this.idcardFrontSide = idcardFrontSide;
	}
	public String getIdcardBackSide() {
		return idcardBackSide;
	}
	public void setIdcardBackSide(String idcardBackSide) {
		this.idcardBackSide = idcardBackSide;
	}
	public String getCertificationState() {
		return certificationState;
	}
	public void setCertificationState(String certificationState) {
		this.certificationState = certificationState;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getGenderStr() {
		return genderStr;
	}
	public void setGenderStr(String genderStr) {
		this.genderStr = genderStr;
	}
	public String getNationStr() {
		return nationStr;
	}
	public void setNationStr(String nationStr) {
		this.nationStr = nationStr;
	}
}
