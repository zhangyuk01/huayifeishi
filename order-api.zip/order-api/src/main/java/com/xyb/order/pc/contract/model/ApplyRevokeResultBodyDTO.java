/**
 * 
 */
package com.xyb.order.pc.contract.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : TODO
 * @createDate : 2018年12月3日 下午4:04:45
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
/**
 * @author xyb
 *
 */
public class ApplyRevokeResultBodyDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7863563220167669750L;
	/**系统id*/
	@SignField(order = 3)
	private String sysId;
	/**申请ID*/
	@SignField(order = 2)
	private Long applyId;
	/**借款人资产账户ID*/
	@SignField(order = 4)
	private Long acctId;
	/**返回地址*/
	private String returnUrl;
	public String getSysId() {
		return sysId;
	}
	public void setSysId(String sysId) {
		this.sysId = sysId;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getAcctId() {
		return acctId;
	}
	public void setAcctId(Long acctId) {
		this.acctId = acctId;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	@Override
	public String toString() {
		return "ApplyRevokeResultBodyDTO [sysId=" + sysId + ", applyId=" + applyId + ", acctId=" + acctId
				+ ", returnUrl=" + returnUrl + "]";
	}
	


}
