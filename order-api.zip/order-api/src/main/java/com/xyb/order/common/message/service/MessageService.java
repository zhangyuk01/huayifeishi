package com.xyb.order.common.message.service;


import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.message.model.*;

import java.util.List;
import java.util.Map;

/**
 * 消息相关
 * @author         xieqingyang
 * @date           2018/10/19 5:26 PM
*/
public interface MessageService {

    /**——------——————————————————————————————————————————————————短信验证码————————————————————————————————————————————————————————————————————*/
    /**
     * 获取短信验证码（验证类）
     * @author      xieqingyang
     * @date        2018/10/19 5:26 PM
     * @version     1.0
     * @param messageDTO 发送所需条件
     * @return 返回发送结果
     * @throws Exception 所有异常
     */
    RestResponse getMessageCode(SendMessageVerificationDTO messageDTO) throws Exception;

    /**
     * 获取短信验证码（通知类）
     * @author      xieqingyang
     * @date        2018/10/19 5:27 PM
     * @version     1.0
     * @param messageDTO 发送所需条件
     * @return 返回发送结果
     */
    RestResponse getMessageCode(SendMessageCurrencyDTO messageDTO);

    /**
     * 验证短信验证码
     * @author      xieqingyang
     * @date        2018/10/19 5:27 PM
     * @version     1.0
     * @param validMessageDTO 待验证数据
     * @return 返回验证结果
     * @throws Exception 所有异常
     */
    RestResponse validateMessageCode(ValidMessageDTO validMessageDTO) throws Exception;

    /**
     * 验证短信验证码  进件自用
     * @author      xieqingyang
     * @date        2018/10/19 5:30 PM
     * @version     1.0
     * @param phone 手机号码
     * @param vCode 短信验证码
     * @param validTime 短信验证码有效时间   可传null
     * @param state 是否当天有效  可传null Y:是  N：否
     * @param userId 登录人id
     * @return 返回验证结果
     */
    RestResponse validateMessageCode(String phone, String vCode, Integer validTime, String state,Long userId);

    /**——------——————————————————————————————————————————————————app推送消息————————————————————————————————————————————————————————————————————*/
    /**
     * 存储推送消息唯一标识
     * @author      xieqingyang
     * @date 2018/6/26 下午2:11
     * @version     1.0
     * @param deviceTokenDTO 传入参数
     * @return 返回执行结果
     * @throws Exception 所有异常
     */
    RestResponse addDeviceToken(DeviceTokenDTO deviceTokenDTO)throws Exception;

    /**
     * pc消息列表
     * @author      xieqingyang
     * @date 2018/6/27 上午9:41
     * @version     1.0
     * @param noticeQueryDTO 查询条件
     * @return 返回列表数据
     * @throws Exception 所有异常
     */
    RestResponse queryNoticeList(Integer pageNumber, Integer pageSize,NoticeQueryDTO noticeQueryDTO)throws Exception;

    /**
     * 查询消息详情数据
     * @author      xieqingyang
     * @date 2018/6/27 下午1:52
     * @version     1.0
     * @param templateId 消息模版ID
     * @return 返回消息模版信息
     * @throws Exception 所有异常
     */
    RestResponse getNoticeInfo(Long templateId)throws Exception;

    /**
     * 添加消息模版
     * @author      xieqingyang
     * @date 2018/6/27 下午2:16
     * @version     1.0
     * @param appNoticeTemplateAddDTO 模版消息
     * @return 返回执行结果
     * @throws Exception 所有异常
     */
    RestResponse addNoticeInfo(AppNoticeTemplateAddDTO appNoticeTemplateAddDTO)throws Exception;

    /**
     * 获取B端用户信息数量
     * @author      xieqingyang
     * @date        2018/9/4 上午11:21
     * @version     1.0
     * @param list 手机号
     * @return 数量
     */
    int getUserCount(List<String> list);

    /**
     * 获取C端用户信息数量
     * @author      xieqingyang
     * @date 2018/9/4 上午11:21
     * @version     1.0
     * @param list 手机号
     * @return 用户信息
     */
    int getClientUserCount(List<String> list);

    /**
     * 撤销消息
     * @author      xieqingyang
     * @date 2018/6/27 下午8:36
     * @version     1.0
     * @param templateId 消息模版ID
     * @return
     * @throws Exception
     */
    RestResponse revokeNotice(Long templateId)throws Exception;


    /**
     * 测试发送短信验证码
     * @author      xieqingyang
     * @date 2018/7/30 下午6:05
     * @version     1.0
     * @param phone 手机号
     * @param code 验证码
     * @return 返回成功
     */
    RestResponse test(String phone,String code);

    /**——------——————————————————————————————————————————————————app查询消息————————————————————————————————————————————————————————————————————*/

    /**
     * 查询app消息首页（公告、消息）信息
     * @author      xieqingyang
     * @date 2018/6/29 下午4:20
     * @version     1.0
     * @param appMessageQueryDTO 传入参数
     * @throws Exception 所有异常
     */
    RestResponse getMessageInFo(AppMessageQueryDTO appMessageQueryDTO)throws Exception;

    /**
     * 查询app消息列表
     * @author      xieqingyang
     * @date 2018/6/29 下午4:21
     * @version     1.0
     * @param appMessageQueryDTO 传入参数
     * @throws Exception 所有异常
     */
    RestResponse getMessageList(AppMessageQueryDTO appMessageQueryDTO)throws Exception;

    /**——------——————————————————————————————————————————————————对外接口调用————————————————————————————————————————————————————————————————————*/
    /**
     * 友盟推送消息
     * @author      xieqingyang
     * @date 2018/7/2 上午10:39
     * @version     1.0
     * @param templateId 消息模版ID 必传（t_app_notice_template表ID） 增加消息模版时注意通知类型为消息
     * @param phone 推送手机号 必传
     * @param paraMap 消息内通需替换的字段需替换的字段   key为模版中需替换的字符   value为替换值 如果没有可传null
     * @param userId 创建人
     * @return 返回结果  result不为0  则为失败  description：为失败原因描述 result为0 时则为成功
     */
    RestResponse sendMessage(Long templateId,String phone,Map<String,Object> paraMap,Long userId);
}
