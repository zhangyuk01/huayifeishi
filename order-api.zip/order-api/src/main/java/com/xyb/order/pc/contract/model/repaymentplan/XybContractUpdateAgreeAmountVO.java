package com.xyb.order.pc.contract.model.repaymentplan;

import java.math.BigDecimal;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同录入修改二级授信金额VO
 * @createDate : 2018/05/29 17:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class XybContractUpdateAgreeAmountVO implements IBaseModel {


	/**
	 * 
	 */
	private static final long serialVersionUID = -963280625681282948L;
	
	/**终极授信金额*/
	private BigDecimal contractAmount;
	/**服务费*/
	private BigDecimal serviceAmount;
	/**首期月还*/
	private BigDecimal monthReturnAmount;
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public BigDecimal getServiceAmount() {
		return serviceAmount;
	}
	public void setServiceAmount(BigDecimal serviceAmount) {
		this.serviceAmount = serviceAmount;
	}
	public BigDecimal getMonthReturnAmount() {
		return monthReturnAmount;
	}
	public void setMonthReturnAmount(BigDecimal monthReturnAmount) {
		this.monthReturnAmount = monthReturnAmount;
	}
	@Override
	public String toString() {
		return "XybContractUpdateAmountVO [contractAmount=" + contractAmount + ", serviceAmount=" + serviceAmount
				+ ", monthReturnAmount=" + monthReturnAmount + "]";
	}


}
