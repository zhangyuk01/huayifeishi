package com.xyb.order.app.client.personalcenter.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 客户流水
 * 
 * @author qiaoJinLong
 * @date 2018年9月19日
 */
public class ClientProfitBalanceDetailDO implements IBaseModel {

	private static final long serialVersionUID = -1584406809678585247L;

	private Long id;

	private Long clientId;// 用户Id t_client_user 主键

	private Long incomeExpenses;// 收支方式（2751）2709 支出，2708收入

	private Long businessType;// 业务类型（2844） 3193推荐奖励，3194质保奖励

	private double amount;// 金额

	private double balance;// 余额

	private Long orderId;// 关联业务单ID

	private String remark;// 备注

	private Date createTime;// 创建时间

	private String dateFormatCreateTime;// 创建时间格式化

	private Long createUser;// 创建人

	@Override
	public String toString() {
		return "ClientProfitBalanceDetailDO [id=" + id + ", clientId=" + clientId + ", incomeExpenses=" + incomeExpenses
				+ ", businessType=" + businessType + ", amount=" + amount + ", balance=" + balance + ", orderId="
				+ orderId + ", remark=" + remark + ", createTime=" + createTime + ", dateFormatCreateTime="
				+ dateFormatCreateTime + ", createUser=" + createUser + "]";
	}

	public String getDateFormatCreateTime() {
		return dateFormatCreateTime;
	}

	public void setDateFormatCreateTime(String dateFormatCreateTime) {
		this.dateFormatCreateTime = dateFormatCreateTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public Long getIncomeExpenses() {
		return incomeExpenses;
	}

	public void setIncomeExpenses(Long incomeExpenses) {
		this.incomeExpenses = incomeExpenses;
	}

	public Long getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Long businessType) {
		this.businessType = businessType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

}
