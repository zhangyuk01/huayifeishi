package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * 协议app展示内容
 * @author         xieqingyang
 * @date           2018/10/18 4:58 PM
*/
public class AgreementListVO implements IBaseModel {

    private static final long serialVersionUID = -2272585114008364555L;
    /**名称*/
    private String name;
    /**查看地址*/
    private String lookAddress;
    /**下载地址*/
    private String downloadAddress;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLookAddress() {
        return lookAddress;
    }

    public void setLookAddress(String lookAddress) {
        this.lookAddress = lookAddress;
    }

    public String getDownloadAddress() {
        return downloadAddress;
    }

    public void setDownloadAddress(String downloadAddress) {
        this.downloadAddress = downloadAddress;
    }

    @Override
    public String toString() {
        return "AgreementListVO{" +
                "name='" + name + '\'' +
                ", lookAddress='" + lookAddress + '\'' +
                ", downloadAddress='" + downloadAddress + '\'' +
                '}';
    }
}
