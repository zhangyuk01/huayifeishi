package com.xyb.order.pc.applybill.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Joiner;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.SysDictEnum;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by xieqingyang on 2018/4/24.
 * 复议提交model
 */
public class InsertReconsiderationDTO implements IBaseModel{

    private static final long serialVersionUID = 1L;

    @NotNull(message = "主表id不能为空")
    private Long mainId;// -- 主表ID
    @NotNull(message = "申请单ID不能为空")
    private Long applyId;// -- 申请单ID
    @NotNull(message = "复议目标不能为空")
    private List<Long> reconsiderList;// -- 复议目标
    @NotNull(message = "复议目标中文描述不能为空")
    private List<String> reconsiderRemarkList;// -- 复议目标中文描述
    @NotEmpty(message = "不能为空")
    private String reconsiderRemark;// -- 复议申请
    @NotNull(message = "当前节点状态不能为空")
    private Integer state;// -- 当前节点状态
    @JsonIgnore
    private Long modifyUser;// -- 操作人ID

    public Long getMainId() {
        return mainId;
    }

    public void setMainId(Long mainId) {
        this.mainId = mainId;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getReconsiderList() {
        return Joiner.on(",").join(reconsiderList);
    }

    public void setReconsiderList(List<Long> reconsiderList) {
        this.reconsiderList = reconsiderList;
    }

    public String getReconsiderRemarkList() {
        return Joiner.on(",").join(reconsiderRemarkList);
    }

    public void setReconsiderRemarkList(List<String> reconsiderRemarkList) {
        this.reconsiderRemarkList = reconsiderRemarkList;
    }

    public String getReconsiderRemark() {
        return reconsiderRemark;
    }

    public void setReconsiderRemark(String reconsiderRemark) {
        this.reconsiderRemark = reconsiderRemark;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }
}
