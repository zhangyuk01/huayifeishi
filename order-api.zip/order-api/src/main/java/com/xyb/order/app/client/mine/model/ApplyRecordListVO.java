package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.List;

/**
* @description:    cpp客户申请列表信息
* @author:         xieqingyang
* @createDate:     2018/5/18 下午6:23
*/
public class ApplyRecordListVO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**是否有下一页 Y:是 N:否*/
    private String isMore = "";

    private List<ApplyRecordVO> applyRecordVOS;

    public String getIsMore() {
        return isMore;
    }

    public void setIsMore(String isMore) {
        this.isMore = isMore;
    }

    public List<ApplyRecordVO> getApplyRecordVOS() {
        return applyRecordVOS;
    }

    public void setApplyRecordVOS(List<ApplyRecordVO> applyRecordVOS) {
        this.applyRecordVOS = applyRecordVOS;
    }
}
