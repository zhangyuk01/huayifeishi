package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.model.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wordnik.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @description:    查询消息模版详情传入参数
 * @author:         xieqingyang
 * @createDate:     2018/6/26 下午8:45
*/
public class NoticeQueryDTO implements IBaseModel {

    private static final long serialVersionUID = -8297254453919792380L;

    @JsonIgnore
    private Page page = new Page();

    /**标题*/
    @ApiModelProperty(value = "标题")
    private String title;
    /**通知类型*/
    @ApiModelProperty(value = "通知类型")
    private Long type;
    /**创建时间开始*/
    @ApiModelProperty(value = "创建时间开始")
    private Date createDateStr;
    /**创建时间结束*/
    @ApiModelProperty(value = "创建时间结束")
    private Date createDateEnd;
    /**是否定时*/
    @ApiModelProperty(value = "是否定时")
    private Long isTiming;
    /**app类型 2526 B端 2527 C端*/
    @NotNull(message = "app类型不能为空")
    @ApiModelProperty(value = "app类型 2526 B端 2527 C端")
    private Long appType;

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public Date getCreateDateStr() {
        return createDateStr;
    }

    public void setCreateDateStr(Date createDateStr) {
        this.createDateStr = createDateStr;
    }

    public Date getCreateDateEnd() {
        return createDateEnd;
    }

    public void setCreateDateEnd(Date createDateEnd) {
        this.createDateEnd = createDateEnd;
    }

    public Long getIsTiming() {
        return isTiming;
    }

    public void setIsTiming(Long isTiming) {
        this.isTiming = isTiming;
    }

    public Long getAppType() {
        return appType;
    }

    public void setAppType(Long appType) {
        this.appType = appType;
    }

    @Override
    public String toString() {
        return "NoticeQueryDTO{" +
                "page=" + page +
                ", title='" + title + '\'' +
                ", type=" + type +
                ", createDateStr=" + createDateStr +
                ", createDateEnd=" + createDateEnd +
                ", isTiming=" + isTiming +
                ", appType=" + appType +
                '}';
    }
}
