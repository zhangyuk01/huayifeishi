package com.xyb.order.app.client.quickloan.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;


/**
 * @author luyang
 * @ClassName QuickLoanRefuseFullDO
 * @description 满额拒贷
 * @time 2018/12/21 11:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class QuickLoanRefuseFullDO implements IBaseModel {

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 产品Id
     */
    private Long productId;
    /**
     * 累计1次申请人数
     */
    private Integer totalOne;
    /**
     * 累计2次申请人数
     */
    private Integer totalTwo;
    /**
     * 累计3次及以上申请人数
     */
    private Integer totalThree;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 修改日期
     */
    private Date modifyTime;
    /**
     * 修改人
     */
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Integer getTotalOne() {
        return totalOne;
    }

    public void setTotalOne(Integer totalOne) {
        this.totalOne = totalOne;
    }

    public Integer getTotalTwo() {
        return totalTwo;
    }

    public void setTotalTwo(Integer totalTwo) {
        this.totalTwo = totalTwo;
    }

    public Integer getTotalThree() {
        return totalThree;
    }

    public void setTotalThree(Integer totalThree) {
        this.totalThree = totalThree;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

    @Override
    public String toString() {
        return "QuickLoanRefuseFullDO{" +
                "id=" + id +
                ", productId=" + productId +
                ", totalOne=" + totalOne +
                ", totalTwo=" + totalTwo +
                ", totalThree=" + totalThree +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                ", modifyTime=" + modifyTime +
                ", modifyUser=" + modifyUser +
                '}';
    }
}