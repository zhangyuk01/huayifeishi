package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;

import java.util.Objects;

/**
 * 重置电子账户交易密码请求参数
 * @author         xieqingyang
 * @date           2018/11/26 10:45 AM
*/
public class AccountRepwdRequestDTO implements IBaseModel {

    private static final long serialVersionUID = -4139931889894995369L;
    /**系统ID 北京2001 深圳3001*/
    private Long sysId;
    /**电子账户,必填，开户返回的电子账户，19(位数*/
    @SignField(order = 1)
    private String card_no;
    /**客户号，11(位数)*/
    @SignField(order = 0)
    private String customer_no;
    @SignField(order = 2)
    private String success_url;
    /**失败跳转地址，必填，失败跳转地址，256(位数)*/
    @SignField(order = 3)
    private String fail_url;
    /**交易终端 ,必填，000001手机APP 000002网页 000003微信 000004柜面*/
    private String client;
    /**商户自定义数据——可选,用于传递商户自定义数据，商户上传的数据会直接返回给商户*/
    private String custom;
    /**客户端ip*/
    private String client_ip;
    /**电脑端上送MAC地址，如果获取不到就上送：pc_client，移动端上送IMEI，ios获取不到IMEI就上送：广告ID（IDFA）*/
    private String client_service;

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getSuccess_url() {
        return success_url;
    }

    public void setSuccess_url(String success_url) {
        this.success_url = success_url;
    }

    public String getFail_url() {
        return fail_url;
    }

    public void setFail_url(String fail_url) {
        this.fail_url = fail_url;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getCustom() {
        return custom;
    }

    public void setCustom(String custom) {
        this.custom = custom;
    }

    public String getClient_ip() {
        return client_ip;
    }

    public void setClient_ip(String client_ip) {
        this.client_ip = client_ip;
    }

    public String getClient_service() {
        return client_service;
    }

    public void setClient_service(String client_service) {
        this.client_service = client_service;
    }

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountRepwdRequestDTO that = (AccountRepwdRequestDTO) o;
        return Objects.equals(sysId,that.sysId) &&
                Objects.equals(card_no, that.card_no) &&
                Objects.equals(customer_no, that.customer_no) &&
                Objects.equals(success_url, that.success_url) &&
                Objects.equals(fail_url, that.fail_url) &&
                Objects.equals(client, that.client) &&
                Objects.equals(custom, that.custom) &&
                Objects.equals(client_ip, that.client_ip) &&
                Objects.equals(client_service, that.client_service);
    }

    @Override
    public int hashCode() {

        return Objects.hash(sysId, card_no, customer_no, success_url, fail_url, client, custom, client_ip, client_service);
    }

    @Override
    public String toString() {
        return "AccountRepwdRequestDTO{" +
                "sysId=" + sysId +
                ", card_no='" + card_no + '\'' +
                ", customer_no='" + customer_no + '\'' +
                ", success_url='" + success_url + '\'' +
                ", fail_url='" + fail_url + '\'' +
                ", client='" + client + '\'' +
                ", custom='" + custom + '\'' +
                ", client_ip='" + client_ip + '\'' +
                ", client_service='" + client_service + '\'' +
                '}';
    }
}
