package com.xyb.order.pc.applybill.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonInfoTempSaveDTO implements IBaseModel {
	private static final long serialVersionUID = 1L;

	private Long id; //主键id
	private Long applyId; //申请表主键
	private Long mainId; //申请主表ID
	private Long cusId;//客户基本信息表主键
	private String validTime;//身份证有效期
	private String phone1;//手机号1
	private String phone2;//手机号2
	private Long education; //最高学历
	private String educationStr;
	private String qq; //qq
	private String webchat; //微信
	private Long homeTownProvince; //户籍地址省
	private String homeTownProvinceStr;//户籍地址省
	private Long homeTownCity; //户籍地址市
	private String homeTownCityStr;//户籍地址市
	private Long homeTownArea; //户籍地址区县
	private String homeTownAreaStr;//户籍地址区县
	private String homeTown; //户籍详细地址
	private String homeTownAllAddress;//户籍全地址
	private Long nowAddressProvince; //目前住址省
	private String nowAddressProvinceStr;//目前地址省
	private Long nowAddressCity; //目前住址市
	private String nowAddressCityStr;//目前地址市
	private Long nowAddressArea; //目前住址区县
	private String nowAddressAreaStr;//目前地址区县
	private String nowAddress; //目前住址
	private String nowAllAddress;//住宅全地址
	private String tellArea; //固话区号
	private String tell; //房产(本人/亲属)固话
	private String allTell;//区号+固话
	private Long liveCase; //居住情况
	private String liveCaseStr;//
	private Long marriage; //婚姻状况
	private String marriageStr;
	private String liveJoin; //共同居住者
	private String liveJoins; //共同居住者
	private String liveJoinOther;//共同居住着其他
	private Long children; //子女情况
	private Long childrenNum; //子女数量
	private String childrenNumStr;
	private Integer childrenAgeStart; //子女情况
	private Integer childrenAgeEnd; //子女情况
	private String payRoolDay;//薪资发放日
	private Date createTime;
	private Long createUser;
	private Date modifyTime;
	private Long modifyUser;
	private String yearIncome;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getMainId() {
		return mainId;
	}
	public void setMainId(Long mainId) {
		this.mainId = mainId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getValidTime() {
		return validTime;
	}
	public void setValidTime(String validTime) {
		this.validTime = validTime;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public Long getEducation() {
		return education;
	}
	public void setEducation(Long education) {
		this.education = education;
	}
	public String getEducationStr() {
		return educationStr;
	}
	public void setEducationStr(String educationStr) {
		this.educationStr = educationStr;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getWebchat() {
		return webchat;
	}
	public void setWebchat(String webchat) {
		this.webchat = webchat;
	}
	public Long getHomeTownProvince() {
		return homeTownProvince;
	}
	public void setHomeTownProvince(Long homeTownProvince) {
		this.homeTownProvince = homeTownProvince;
	}
	public String getHomeTownProvinceStr() {
		return homeTownProvinceStr;
	}
	public void setHomeTownProvinceStr(String homeTownProvinceStr) {
		this.homeTownProvinceStr = homeTownProvinceStr;
	}
	public Long getHomeTownCity() {
		return homeTownCity;
	}
	public void setHomeTownCity(Long homeTownCity) {
		this.homeTownCity = homeTownCity;
	}
	public String getHomeTownCityStr() {
		return homeTownCityStr;
	}
	public void setHomeTownCityStr(String homeTownCityStr) {
		this.homeTownCityStr = homeTownCityStr;
	}
	public Long getHomeTownArea() {
		return homeTownArea;
	}
	public void setHomeTownArea(Long homeTownArea) {
		this.homeTownArea = homeTownArea;
	}
	public String getHomeTownAreaStr() {
		return homeTownAreaStr;
	}
	public void setHomeTownAreaStr(String homeTownAreaStr) {
		this.homeTownAreaStr = homeTownAreaStr;
	}
	public String getHomeTown() {
		return homeTown;
	}
	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}
	public String getHomeTownAllAddress() {
		return homeTownAllAddress;
	}
	public void setHomeTownAllAddress(String homeTownAllAddress) {
		this.homeTownAllAddress = homeTownAllAddress;
	}
	public Long getNowAddressProvince() {
		return nowAddressProvince;
	}
	public void setNowAddressProvince(Long nowAddressProvince) {
		this.nowAddressProvince = nowAddressProvince;
	}
	public String getNowAddressProvinceStr() {
		return nowAddressProvinceStr;
	}
	public void setNowAddressProvinceStr(String nowAddressProvinceStr) {
		this.nowAddressProvinceStr = nowAddressProvinceStr;
	}
	public Long getNowAddressCity() {
		return nowAddressCity;
	}
	public void setNowAddressCity(Long nowAddressCity) {
		this.nowAddressCity = nowAddressCity;
	}
	public String getNowAddressCityStr() {
		return nowAddressCityStr;
	}
	public void setNowAddressCityStr(String nowAddressCityStr) {
		this.nowAddressCityStr = nowAddressCityStr;
	}
	public Long getNowAddressArea() {
		return nowAddressArea;
	}
	public void setNowAddressArea(Long nowAddressArea) {
		this.nowAddressArea = nowAddressArea;
	}
	public String getNowAddressAreaStr() {
		return nowAddressAreaStr;
	}
	public void setNowAddressAreaStr(String nowAddressAreaStr) {
		this.nowAddressAreaStr = nowAddressAreaStr;
	}
	public String getNowAddress() {
		return nowAddress;
	}
	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}
	public String getNowAllAddress() {
		return nowAllAddress;
	}
	public void setNowAllAddress(String nowAllAddress) {
		this.nowAllAddress = nowAllAddress;
	}
	public String getTellArea() {
		return tellArea;
	}
	public void setTellArea(String tellArea) {
		this.tellArea = tellArea;
	}
	public String getTell() {
		return tell;
	}
	public void setTell(String tell) {
		this.tell = tell;
	}
	public String getAllTell() {
		return allTell;
	}
	public void setAllTell(String allTell) {
		this.allTell = allTell;
	}
	public Long getLiveCase() {
		return liveCase;
	}
	public void setLiveCase(Long liveCase) {
		this.liveCase = liveCase;
	}
	public String getLiveCaseStr() {
		return liveCaseStr;
	}
	public void setLiveCaseStr(String liveCaseStr) {
		this.liveCaseStr = liveCaseStr;
	}
	public String getLiveJoin() {
		return liveJoin;
	}
	public void setLiveJoin(String liveJoin) {
		this.liveJoin = liveJoin;
	}
	public String getLiveJoins() {
		return liveJoins;
	}
	public void setLiveJoins(String liveJoins) {
		this.liveJoins = liveJoins;
	}
	public String getLiveJoinOther() {
		return liveJoinOther;
	}
	public void setLiveJoinOther(String liveJoinOther) {
		this.liveJoinOther = liveJoinOther;
	}
	public Long getMarriage() {
		return marriage;
	}
	public void setMarriage(Long marriage) {
		this.marriage = marriage;
	}
	public String getMarriageStr() {
		return marriageStr;
	}
	public void setMarriageStr(String marriageStr) {
		this.marriageStr = marriageStr;
	}
	public Long getChildren() {
		return children;
	}
	public void setChildren(Long children) {
		this.children = children;
	}
	
	public Long getChildrenNum() {
		return childrenNum;
	}
	public void setChildrenNum(Long childrenNum) {
		this.childrenNum = childrenNum;
	}
	public Integer getChildrenAgeStart() {
		return childrenAgeStart;
	}
	public void setChildrenAgeStart(Integer childrenAgeStart) {
		this.childrenAgeStart = childrenAgeStart;
	}
	public Integer getChildrenAgeEnd() {
		return childrenAgeEnd;
	}
	public void setChildrenAgeEnd(Integer childrenAgeEnd) {
		this.childrenAgeEnd = childrenAgeEnd;
	}
	
	public String getPayRoolDay() {
		return payRoolDay;
	}
	public void setPayRoolDay(String payRoolDay) {
		this.payRoolDay = payRoolDay;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getChildrenNumStr() {
		return childrenNumStr;
	}
	public void setChildrenNumStr(String childrenNumStr) {
		this.childrenNumStr = childrenNumStr;
	}
	public String getYearIncome() {
		return yearIncome;
	}
	public void setYearIncome(String yearIncome) {
		this.yearIncome = yearIncome;
	}
}
