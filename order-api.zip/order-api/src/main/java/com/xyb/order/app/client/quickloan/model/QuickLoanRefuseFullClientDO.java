package com.xyb.order.app.client.quickloan.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;


/**
 * @author luyang
 * @ClassName QuickLoanRefuseFullClientDO
 * @description 累计满额拒贷借款人清单
 * @time 2018/12/21 11:45
 * @modificationHistory <记录修改历史记录 who where what>
 */
public class QuickLoanRefuseFullClientDO implements IBaseModel {

    /**
     * 序列化
     */
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 借款人ID
     */
    private Long clientId;
    /**
     * 借款人姓名
     */
    private String clientName;
    /**
     * 身份证号
     */
    private String clientIdcard;
    /**
     * 联系电话
     */
    private String clientPhone;
    /**
     * 产品id
     */
    private Long productId;
    /**
     * 累计满额拒贷次数
     */
    private Integer totalQty;
    /**
     * 申请次数
     */
    private Integer applyQty;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private Long createUser;
    /**
     * 修改时间
     */
    private Date modifyTime;
    /**
     * 修改人
     */
    private Long modifyUser;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientIdcard() {
        return clientIdcard;
    }

    public void setClientIdcard(String clientIdcard) {
        this.clientIdcard = clientIdcard;
    }

    public String getClientPhone() {
        return clientPhone;
    }

    public void setClientPhone(String clientPhone) {
        this.clientPhone = clientPhone;
    }

    public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Integer getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(Integer totalQty) {
        this.totalQty = totalQty;
    }

    public Integer getApplyQty() {
        return applyQty;
    }

    public void setApplyQty(Integer applyQty) {
        this.applyQty = applyQty;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Long getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(Long modifyUser) {
        this.modifyUser = modifyUser;
    }

	@Override
	public String toString() {
		return "QuickLoanRefuseFullClientDO [id=" + id + ", clientId="
				+ clientId + ", clientName=" + clientName + ", clientIdcard="
				+ clientIdcard + ", clientPhone=" + clientPhone
				+ ", productId=" + productId + ", totalQty=" + totalQty
				+ ", applyQty=" + applyQty + ", createTime=" + createTime
				+ ", createUser=" + createUser + ", modifyTime=" + modifyTime
				+ ", modifyUser=" + modifyUser + "]";
	}


}