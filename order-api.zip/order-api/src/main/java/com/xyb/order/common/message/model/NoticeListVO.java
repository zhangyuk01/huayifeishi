package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

/**
 * @description:    消息app展示
 * @author:         xieqingyang
 * @createDate:     2018/6/26 下午8:39
*/
public class NoticeListVO implements IBaseModel {

    private static final long serialVersionUID = -8131901625871505568L;
    /**发布时间*/
    @JsonFormat(pattern="yyyy-MM-dd HH:mm",timezone = "GMT+8")
    private Date releaseTime;
    /**标题*/
    private String title;
    /**主题内容*/
    private String content;
    /**H5链接*/
    private String url;
    /**通知类型*/
    private String type;
    /**通知设备*/
    private String equipmentType;
    /**创建日期*/
    @JsonFormat(pattern="yyyy-MM-dd",timezone = "GMT+8")
    private Date createTime;
    /**创建人*/
    private String createName;
    /**状态*/
    private String state;
    /**是否定时发送*/
    private String isTiming;
    /**消息模版ID*/
    private Long templateId;

    public Date getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(Date releaseTime) {
        this.releaseTime = releaseTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateName() {
        return createName;
    }

    public void setCreateName(String createName) {
        this.createName = createName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getIsTiming() {
        return isTiming;
    }

    public void setIsTiming(String isTiming) {
        this.isTiming = isTiming;
    }

    public Long getTemplateId() {
        return templateId;
    }

    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }

    @Override
    public String toString() {
        return "NoticeListVO{" +
                "releaseTime=" + releaseTime +
                ", title=" + title +
                ", content=" + content +
                ", url=" + url +
                ", type=" + type +
                ", equipmentType=" + equipmentType +
                ", createTime=" + createTime +
                ", createName=" + createName +
                ", state=" + state +
                ", isTiming=" + isTiming +
                ", templateId=" + templateId +
                '}';
    }
}
