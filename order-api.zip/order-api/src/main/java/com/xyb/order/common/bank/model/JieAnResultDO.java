package com.xyb.order.common.bank.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @description:    捷安返回结果解析model
 * @author:         xieqingyang
 * @createDate:     2018/7/19 上午9:53
*/
public class JieAnResultDO implements IBaseModel {

    private static final long serialVersionUID = 6102195107597454793L;
    /**主键ID*/
    private String id;
    /**客户信息表ID*/
    private Long clientId;
    /**捷安版本号*/
    private String versionId;
    /**捷安客户号*/
    private String custId;
    /**订单号*/
    private String orderId;
    /**交易类型: STD_VERI-标准校验，MD_VERI-多维验证，REPORT-报告*/
    private String transType;
    /**商户私有域*/
    private String merPriv;
    /**银行卡号*/
    private String cardId;
    /**身份证号*/
    private String certId;
    /**身份证姓名*/
    private String certName;
    /**银行预留手机号*/
    private String mP;
    /**产品代码: CARD4-银行卡四要素，CARD3CN-银行卡三要素*/
    private String prodId;
    /**返回码*/
    private String respCode;
    /**返回码描述*/
    private String respDesc;
    /**捷安返回唯一标识*/
    private String resTxnId;
    /**校验码*/
    private String macStr;
    /**创建时间*/
    private Date createTime;
    /**创建人*/
    private Long createUser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getVersionId() {
        return versionId;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getMerPriv() {
        return merPriv;
    }

    public void setMerPriv(String merPriv) {
        this.merPriv = merPriv;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getCertId() {
        return certId;
    }

    public void setCertId(String certId) {
        this.certId = certId;
    }

    public String getCertName() {
        return certName;
    }

    public void setCertName(String certName) {
        this.certName = certName;
    }

    public String getmP() {
        return mP;
    }

    public void setmP(String mP) {
        this.mP = mP;
    }

    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    public String getRespCode() {
        return respCode;
    }

    public void setRespCode(String respCode) {
        this.respCode = respCode;
    }

    public String getRespDesc() {
        return respDesc;
    }

    public void setRespDesc(String respDesc) {
        this.respDesc = respDesc;
    }

    public String getResTxnId() {
        return resTxnId;
    }

    public void setResTxnId(String resTxnId) {
        this.resTxnId = resTxnId;
    }

    public String getMacStr() {
        return macStr;
    }

    public void setMacStr(String macStr) {
        this.macStr = macStr;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Long createUser) {
        this.createUser = createUser;
    }

    @Override
    public String toString() {
        return "JieAnResultDO{" +
                "id='" + id + '\'' +
                ", clientId='" + clientId + '\'' +
                ", versionId='" + versionId + '\'' +
                ", custId='" + custId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", transType='" + transType + '\'' +
                ", merPriv='" + merPriv + '\'' +
                ", cardId='" + cardId + '\'' +
                ", certId='" + certId + '\'' +
                ", certName='" + certName + '\'' +
                ", mP='" + mP + '\'' +
                ", prodId='" + prodId + '\'' +
                ", respCode='" + respCode + '\'' +
                ", respDesc='" + respDesc + '\'' +
                ", resTxnId='" + resTxnId + '\'' +
                ", macStr='" + macStr + '\'' +
                ", createTime=" + createTime +
                ", createUser=" + createUser +
                '}';
    }
}
