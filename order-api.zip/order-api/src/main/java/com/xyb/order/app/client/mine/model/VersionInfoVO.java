package com.xyb.order.app.client.mine.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:    我的信息
* @author:         xieqingyang
* @createDate:     2018/5/12 下午6:35
*/
public class VersionInfoVO implements IBaseModel {

    private static final long serialVersionUID = 1L;
    /**版本信息*/
    /**版本号*/
    private String versionCode;
    /**版本名称*/
    private String versionName;
    /**更新摘要*/
    private String remark;
    /**更新地址*/
    private String updateUrl;
    /**是否强制 Y：是 N：否*/
    private String need;
    /**是否展示 Y：是 N：否*/
    private String isShow;

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUpdateUrl() {
        return updateUrl;
    }

    public void setUpdateUrl(String updateUrl) {
        this.updateUrl = updateUrl;
    }

    public String getNeed() {
        return need;
    }

    public void setNeed(String need) {
        this.need = need;
    }

    public String getIsShow() {
        return isShow;
    }

    public void setIsShow(String isShow) {
        this.isShow = isShow;
    }


}
