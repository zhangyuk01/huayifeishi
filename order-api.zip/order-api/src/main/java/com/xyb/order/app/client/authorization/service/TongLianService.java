package com.xyb.order.app.client.authorization.service;

import com.xyb.order.app.client.authorization.model.TongLianLogDTO;
import com.xyb.order.app.client.authorization.model.TongLianVerifyInfoDO;

import java.util.Map;

/**
 * @author : weiyuhao
 * @projectName : 通联身份认证接口
 * @package : com.xyb.order.app.client.authorization.service
 * @description :
 * @createDate : 2018/9/25 9:55
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface TongLianService {

    /**
     * 通联身份证校验
     * @param tongLianVerifyInfoDO
     * @return
     * @throws Exception
     */
     Map verifyIdCard(TongLianVerifyInfoDO tongLianVerifyInfoDO)throws Exception;

    /**
     * 保存通联认证调用日志
     * @throws Exception
     */
    void addVerifyLog(TongLianLogDTO tongLianLogDTO) throws Exception;

    /**
     *  获取当天认证次数
     * @return
     * @throws Exception
     */
    int getVerifyCountQuantityByIdCard (TongLianVerifyInfoDO tongLianVerifyInfoDO) throws  Exception;
}
