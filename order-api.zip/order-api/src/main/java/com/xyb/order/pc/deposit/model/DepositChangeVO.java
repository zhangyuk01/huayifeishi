package com.xyb.order.pc.deposit.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.model
 * @description : 资料变更审核列表
 * @createDate : 2018/06/29 15:36
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class DepositChangeVO implements IBaseModel {

    private static final long serialVersionUID = 1233670329497464846L;
    /**
     * id : id
     * depositChangeState : 变更状态code
     * depositChangeStateStr : 变更状态
     * depositChangeType : 申请类型code
     * depositChangeTypeStr : 申请类型
     * operationUser : 处理人
     * applyTime : 申请时间
     * openPlatform : 放款平台
     * clientName : 客户姓名
     * idCard : 身份证号
     * phone : 电话号
     * contractSettleState : 借款状态
     */

    private Long id;
    private Long applyId;
    private Long depositChangeState;
    private String depositChangeStateStr;
    private Long depositChangeType;
    private String depositChangeTypeStr;
    private String operationUser;
    private Date applyTime;
    private String openPlatform;
    private String clientName;
    private String idCard;
    private String phone;
    private String contractSettleState;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public Long getDepositChangeState() {
        return depositChangeState;
    }

    public void setDepositChangeState(Long depositChangeState) {
        this.depositChangeState = depositChangeState;
    }

    public String getDepositChangeStateStr() {
        return depositChangeStateStr;
    }

    public void setDepositChangeStateStr(String depositChangeStateStr) {
        this.depositChangeStateStr = depositChangeStateStr;
    }

    public Long getDepositChangeType() {
        return depositChangeType;
    }

    public void setDepositChangeType(Long depositChangeType) {
        this.depositChangeType = depositChangeType;
    }

    public String getDepositChangeTypeStr() {
        return depositChangeTypeStr;
    }

    public void setDepositChangeTypeStr(String depositChangeTypeStr) {
        this.depositChangeTypeStr = depositChangeTypeStr;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getOpenPlatform() {
        return openPlatform;
    }

    public void setOpenPlatform(String openPlatform) {
        this.openPlatform = openPlatform;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContractSettleState() {
        return contractSettleState;
    }

    public void setContractSettleState(String contractSettleState) {
        this.contractSettleState = contractSettleState;
    }

    @Override
    public String toString() {
        return "DepositChangeVO{" +
                "id=" + id +
                ",  applyId=" + applyId +
                ", depositChangeState=" + depositChangeState +
                ", depositChangeStateStr='" + depositChangeStateStr + '\'' +
                ", depositChangeType=" + depositChangeType +
                ", depositChangeTypeStr='" + depositChangeTypeStr + '\'' +
                ", operationUser='" + operationUser + '\'' +
                ", applyTime=" + applyTime +
                ", openPlatform='" + openPlatform + '\'' +
                ", clientName='" + clientName + '\'' +
                ", idCard='" + idCard + '\'' +
                ", phone='" + phone + '\'' +
                ", contractSettleState='" + contractSettleState + '\'' +
                '}';
    }
}
