package com.xyb.order.pc.applybill.model;

import java.math.BigDecimal;
import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyBillMainInfoDO implements IBaseModel {
	
	/**
	 * 
	 */
	private static final Long serialVersionUID = 9111040255699700982L;
	private Long id;
	/**申请来源（大类2709）*/
	private Long applySouce;
	/**申请借款产品ID*/
	private Long expectProductId;
	/**产品名称*/
	private String expectProductName;
	/**产品分类（大类2578）*/
	private Long expectProductType;
	/**申请借款金额*/
	private BigDecimal expectMoney;
	/**申请借款期数*/
	private Integer expectTerm;
	/**申请时间*/
	private Date applyTime;
	/**客户id*/
	private Long clientId;
	/**用户等级（大类2786）*/
	private Long clientGrade;
	/**身份证号*/
	private String clientIdcard;
	/**真实姓名*/
	private String clientRealName;
	/**客户实名标志（大类2692）*/
	private Long clientRealFlag;
	/**用户是否逾期标志(大类2692)*/
	private Long overdueFlag;
	/**用户逾期级别*/
	private String overdueLeven;
	/**咨询id*/
	private Long cousultId;
	/**申请id*/
	private Long applyId;
	/**合同Id*/
	private Long contractId;
	/**大区id*/
	private Long districtOrgId;
	/**小区id*/
	private Long branchDistrictOrgId;
	/**营业部id*/
	private Long storeOrgId;
	/**营业组id*/
	private Long teamOrgId;
	/**客户经理Id*/
	private Long managerUid;
	/**客户经理姓名*/
	private String managerUname;
	/**团队经理*/
	private Long teamManagerId;
	/**团队经理姓名*/
	private String teamManagerUname;
	/**客服经理id*/
	private Long serviveManagerUid;
	/**客服经理*/
	private String serviveManagerName;
	/**客服专员Id*/
	private Long serviceUid;
	/**客服专员姓名*/
	private String serviceName;
	/**合同专员*/
	private Long contractUid;
	/**合同审核专员*/
	private Long contractReviewUid;
	/**初审人员id*/
	private Long auditPrimaryUid;
	/**初审人员姓名*/
	private String auditPrimaryUname;
	/**终审人员id*/
	private Long auditEndUid;
	/**终审人员姓名*/
	private String auditEndUname;
	/**外访次数*/
	private Integer visitCount;
	/**是否拒贷(大类2692)*/
	private Long isResuse;
	/**拒贷码*/
	private String refuseCode;
	/**拒贷原因*/
	private String refuseValue;
	/**批贷产品*/
	private Long agreeProductId;
	/**批贷期限*/
	private Integer agreeProductLimit;
	/**批贷金额*/
	private BigDecimal agreeAmount;
	/**'放款渠道(大类2545)*/
	private Long loanChannelId;
	/**放款金额*/
	private BigDecimal loanMoney;
	/**是否剥离标志(大类2692)*/
	private Long overFlag;
	/**剥离时间*/
	private Date overTime;
	/**咨询时间：客户提交申请的时间*/
	private Date submitConsultTime;
	/**进件时间：申请提交审核初审时间*/
	private Date submitApplyToAuditTime;
	/**申请审批时间：终审批贷或拒贷时间*/
	private Date endauditOverTime;
	/**合同编号*/
	private String contractNum;
	/**合同金额*/
	private BigDecimal contractMoney;
	/**合同审批时间：合同提交财务时间*/
	private Date contractAuditAdoptTime;
	/**放款时间：财务抓盘提交三方放款时间*/
	private Date financeGiveLoanTime;
	/**到账时间：放款回盘时间*/
	private Date accountingDateTime;
	/**状态-流程节点*/
	private Integer state;
	/**上一步状态（发生回溯操作时）*/
	private Integer previous;
	/**客户是否放弃(大类2692)*/
	private Long clientAbandon;
	/**放弃原因(大类2710)*/
	private Long abandonReason;
	/**创建时间*/
	private Date createTime;
	/**创建人Id*/
	private Long createUser;
	/**最后修改时间*/
	private Date modifyTime;
	/**最后修改人*/
	private Long modifyUser;
	/**提交复议时间：客户提交复议时间*/
	private Date submitReconsiderTime;
	/**提交签约前核验时间：客服提交核验时间*/
	private Date submitSignatoryVerificationTime;
	/**申请编号*/
	private String applyNum;
	/**是否循环借款(大类2692)*/
	private Long isLoop;
	/**是否签约前核验（大类2692）*/
	private Long isSignCheck;
	/**签约前核验类型（大类2772）*/
	private String signCheckContent;
	/**销售团队名称*/
	private String teamOrgName;
	/**批贷产品名称*/
	private String agreeProductName;
	/**月还金额*/
	private BigDecimal monthRepaymentMoney;
	/**费率类型（对应产品明细表费率类型）*/
	private String serviceProportionType;
	/**违例审批类型(大类2597)*/
	private Long unauthorized;
	/**专案码*/
	private Long projectCode;
	/**风险提报结果（大类2780）*/
	private Long isRiskHand;
	/**已办申请状态（大类2774）*/
	private Long applyStatus;
	/**政策码*/
	private Long policyCode;
	/**预审是否通过（大类2781）*/
	private Long isApprovalPassed;
	/**复议次数*/
	private Integer reconsiderationQty;
	/**协商标志（大类2692）*/
	private Long consultFlag;
	/**协商内容（大类2530）*/
	private String consultContext;
	/**是否实地征信（大类2692）*/
	private Long isIndeedCredit;
	/**实地征信内容（大类2771）*/
	private String indeedCreditContext;
	/**产品利率*/
	private BigDecimal productProportion;
	/**服务费率*/
	private BigDecimal  serviceProportion;
	/**外访提交终审时间*/
	private Date visitSubmitAuditTime;
	/**系统审核是否通过（2692）*/
	private Long isSysAuditPass;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplySouce() {
		return applySouce;
	}

	public void setApplySouce(Long applySouce) {
		this.applySouce = applySouce;
	}

	public Long getExpectProductId() {
		return expectProductId;
	}

	public void setExpectProductId(Long expectProductId) {
		this.expectProductId = expectProductId;
	}

	public String getExpectProductName() {
		return expectProductName;
	}

	public void setExpectProductName(String expectProductName) {
		this.expectProductName = expectProductName;
	}

	public Long getExpectProductType() {
		return expectProductType;
	}

	public void setExpectProductType(Long expectProductType) {
		this.expectProductType = expectProductType;
	}

	public BigDecimal getExpectMoney() {
		return expectMoney;
	}

	public void setExpectMoney(BigDecimal expectMoney) {
		this.expectMoney = expectMoney;
	}

	public Integer getExpectTerm() {
		return expectTerm;
	}

	public void setExpectTerm(Integer expectTerm) {
		this.expectTerm = expectTerm;
	}

	public Date getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public Long getClientGrade() {
		return clientGrade;
	}

	public void setClientGrade(Long clientGrade) {
		this.clientGrade = clientGrade;
	}

	public String getClientIdcard() {
		return clientIdcard;
	}

	public void setClientIdcard(String clientIdcard) {
		this.clientIdcard = clientIdcard;
	}

	public String getClientRealName() {
		return clientRealName;
	}

	public void setClientRealName(String clientRealName) {
		this.clientRealName = clientRealName;
	}

	public Long getClientRealFlag() {
		return clientRealFlag;
	}

	public void setClientRealFlag(Long clientRealFlag) {
		this.clientRealFlag = clientRealFlag;
	}

	public Long getOverdueFlag() {
		return overdueFlag;
	}

	public void setOverdueFlag(Long overdueFlag) {
		this.overdueFlag = overdueFlag;
	}

	public String getOverdueLeven() {
		return overdueLeven;
	}

	public void setOverdueLeven(String overdueLeven) {
		this.overdueLeven = overdueLeven;
	}

	public Long getCousultId() {
		return cousultId;
	}

	public void setCousultId(Long cousultId) {
		this.cousultId = cousultId;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getContractId() {
		return contractId;
	}

	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}

	public Long getDistrictOrgId() {
		return districtOrgId;
	}

	public void setDistrictOrgId(Long districtOrgId) {
		this.districtOrgId = districtOrgId;
	}

	public Long getBranchDistrictOrgId() {
		return branchDistrictOrgId;
	}

	public void setBranchDistrictOrgId(Long branchDistrictOrgId) {
		this.branchDistrictOrgId = branchDistrictOrgId;
	}

	public Long getStoreOrgId() {
		return storeOrgId;
	}

	public void setStoreOrgId(Long storeOrgId) {
		this.storeOrgId = storeOrgId;
	}

	public Long getTeamOrgId() {
		return teamOrgId;
	}

	public void setTeamOrgId(Long teamOrgId) {
		this.teamOrgId = teamOrgId;
	}

	public Long getManagerUid() {
		return managerUid;
	}

	public void setManagerUid(Long managerUid) {
		this.managerUid = managerUid;
	}

	public String getManagerUname() {
		return managerUname;
	}

	public void setManagerUname(String managerUname) {
		this.managerUname = managerUname;
	}

	public Long getTeamManagerId() {
		return teamManagerId;
	}

	public void setTeamManagerId(Long teamManagerId) {
		this.teamManagerId = teamManagerId;
	}

	public String getTeamManagerUname() {
		return teamManagerUname;
	}

	public void setTeamManagerUname(String teamManagerUname) {
		this.teamManagerUname = teamManagerUname;
	}

	public Long getServiveManagerUid() {
		return serviveManagerUid;
	}

	public void setServiveManagerUid(Long serviveManagerUid) {
		this.serviveManagerUid = serviveManagerUid;
	}

	public String getServiveManagerName() {
		return serviveManagerName;
	}

	public void setServiveManagerName(String serviveManagerName) {
		this.serviveManagerName = serviveManagerName;
	}

	public Long getServiceUid() {
		return serviceUid;
	}

	public void setServiceUid(Long serviceUid) {
		this.serviceUid = serviceUid;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Long getContractUid() {
		return contractUid;
	}

	public void setContractUid(Long contractUid) {
		this.contractUid = contractUid;
	}

	public Long getContractReviewUid() {
		return contractReviewUid;
	}

	public void setContractReviewUid(Long contractReviewUid) {
		this.contractReviewUid = contractReviewUid;
	}

	public Long getAuditPrimaryUid() {
		return auditPrimaryUid;
	}

	public void setAuditPrimaryUid(Long auditPrimaryUid) {
		this.auditPrimaryUid = auditPrimaryUid;
	}

	public String getAuditPrimaryUname() {
		return auditPrimaryUname;
	}

	public void setAuditPrimaryUname(String auditPrimaryUname) {
		this.auditPrimaryUname = auditPrimaryUname;
	}

	public Long getAuditEndUid() {
		return auditEndUid;
	}

	public void setAuditEndUid(Long auditEndUid) {
		this.auditEndUid = auditEndUid;
	}

	public String getAuditEndUname() {
		return auditEndUname;
	}

	public void setAuditEndUname(String auditEndUname) {
		this.auditEndUname = auditEndUname;
	}

	public Integer getVisitCount() {
		return visitCount;
	}

	public void setVisitCount(Integer visitCount) {
		this.visitCount = visitCount;
	}

	public Long getIsResuse() {
		return isResuse;
	}

	public void setIsResuse(Long isResuse) {
		this.isResuse = isResuse;
	}

	public String getRefuseCode() {
		return refuseCode;
	}

	public void setRefuseCode(String refuseCode) {
		this.refuseCode = refuseCode;
	}

	public String getRefuseValue() {
		return refuseValue;
	}

	public void setRefuseValue(String refuseValue) {
		this.refuseValue = refuseValue;
	}

	public Long getAgreeProductId() {
		return agreeProductId;
	}

	public void setAgreeProductId(Long agreeProductId) {
		this.agreeProductId = agreeProductId;
	}

	public Integer getAgreeProductLimit() {
		return agreeProductLimit;
	}

	public void setAgreeProductLimit(Integer agreeProductLimit) {
		this.agreeProductLimit = agreeProductLimit;
	}

	public BigDecimal getAgreeAmount() {
		return agreeAmount;
	}

	public void setAgreeAmount(BigDecimal agreeAmount) {
		this.agreeAmount = agreeAmount;
	}

	public Long getLoanChannelId() {
		return loanChannelId;
	}

	public void setLoanChannelId(Long loanChannelId) {
		this.loanChannelId = loanChannelId;
	}

	public BigDecimal getLoanMoney() {
		return loanMoney;
	}

	public void setLoanMoney(BigDecimal loanMoney) {
		this.loanMoney = loanMoney;
	}

	public Long getOverFlag() {
		return overFlag;
	}

	public void setOverFlag(Long overFlag) {
		this.overFlag = overFlag;
	}

	public Date getOverTime() {
		return overTime;
	}

	public void setOverTime(Date overTime) {
		this.overTime = overTime;
	}

	public Date getSubmitConsultTime() {
		return submitConsultTime;
	}

	public void setSubmitConsultTime(Date submitConsultTime) {
		this.submitConsultTime = submitConsultTime;
	}

	public Date getSubmitApplyToAuditTime() {
		return submitApplyToAuditTime;
	}

	public void setSubmitApplyToAuditTime(Date submitApplyToAuditTime) {
		this.submitApplyToAuditTime = submitApplyToAuditTime;
	}

	public Date getEndauditOverTime() {
		return endauditOverTime;
	}

	public void setEndauditOverTime(Date endauditOverTime) {
		this.endauditOverTime = endauditOverTime;
	}

	public String getContractNum() {
		return contractNum;
	}

	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	public BigDecimal getContractMoney() {
		return contractMoney;
	}

	public void setContractMoney(BigDecimal contractMoney) {
		this.contractMoney = contractMoney;
	}

	public Date getContractAuditAdoptTime() {
		return contractAuditAdoptTime;
	}

	public void setContractAuditAdoptTime(Date contractAuditAdoptTime) {
		this.contractAuditAdoptTime = contractAuditAdoptTime;
	}

	public Date getFinanceGiveLoanTime() {
		return financeGiveLoanTime;
	}

	public void setFinanceGiveLoanTime(Date financeGiveLoanTime) {
		this.financeGiveLoanTime = financeGiveLoanTime;
	}

	public Date getAccountingDateTime() {
		return accountingDateTime;
	}

	public void setAccountingDateTime(Date accountingDateTime) {
		this.accountingDateTime = accountingDateTime;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getPrevious() {
		return previous;
	}

	public void setPrevious(Integer previous) {
		this.previous = previous;
	}

	public Long getClientAbandon() {
		return clientAbandon;
	}

	public void setClientAbandon(Long clientAbandon) {
		this.clientAbandon = clientAbandon;
	}

	public Long getAbandonReason() {
		return abandonReason;
	}

	public void setAbandonReason(Long abandonReason) {
		this.abandonReason = abandonReason;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public Date getSubmitReconsiderTime() {
		return submitReconsiderTime;
	}

	public void setSubmitReconsiderTime(Date submitReconsiderTime) {
		this.submitReconsiderTime = submitReconsiderTime;
	}

	public Date getSubmitSignatoryVerificationTime() {
		return submitSignatoryVerificationTime;
	}

	public void setSubmitSignatoryVerificationTime(Date submitSignatoryVerificationTime) {
		this.submitSignatoryVerificationTime = submitSignatoryVerificationTime;
	}

	public String getApplyNum() {
		return applyNum;
	}

	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}

	public Long getIsLoop() {
		return isLoop;
	}

	public void setIsLoop(Long isLoop) {
		this.isLoop = isLoop;
	}

	public Long getIsSignCheck() {
		return isSignCheck;
	}

	public void setIsSignCheck(Long isSignCheck) {
		this.isSignCheck = isSignCheck;
	}

	public String getSignCheckContent() {
		return signCheckContent;
	}

	public void setSignCheckContent(String signCheckContent) {
		this.signCheckContent = signCheckContent;
	}

	public String getTeamOrgName() {
		return teamOrgName;
	}

	public void setTeamOrgName(String teamOrgName) {
		this.teamOrgName = teamOrgName;
	}

	public String getAgreeProductName() {
		return agreeProductName;
	}

	public void setAgreeProductName(String agreeProductName) {
		this.agreeProductName = agreeProductName;
	}

	public BigDecimal getMonthRepaymentMoney() {
		return monthRepaymentMoney;
	}

	public void setMonthRepaymentMoney(BigDecimal monthRepaymentMoney) {
		this.monthRepaymentMoney = monthRepaymentMoney;
	}

	public String getServiceProportionType() {
		return serviceProportionType;
	}

	public void setServiceProportionType(String serviceProportionType) {
		this.serviceProportionType = serviceProportionType;
	}

	public Long getUnauthorized() {
		return unauthorized;
	}

	public void setUnauthorized(Long unauthorized) {
		this.unauthorized = unauthorized;
	}

	public Long getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(Long projectCode) {
		this.projectCode = projectCode;
	}

	public Long getIsRiskHand() {
		return isRiskHand;
	}

	public void setIsRiskHand(Long isRiskHand) {
		this.isRiskHand = isRiskHand;
	}

	public Long getApplyStatus() {
		return applyStatus;
	}

	public void setApplyStatus(Long applyStatus) {
		this.applyStatus = applyStatus;
	}

	public Long getPolicyCode() {
		return policyCode;
	}

	public void setPolicyCode(Long policyCode) {
		this.policyCode = policyCode;
	}

	public Long getIsApprovalPassed() {
		return isApprovalPassed;
	}

	public void setIsApprovalPassed(Long isApprovalPassed) {
		this.isApprovalPassed = isApprovalPassed;
	}

	public Integer getReconsiderationQty() {
		return reconsiderationQty;
	}

	public void setReconsiderationQty(Integer reconsiderationQty) {
		this.reconsiderationQty = reconsiderationQty;
	}

	public Long getConsultFlag() {
		return consultFlag;
	}

	public void setConsultFlag(Long consultFlag) {
		this.consultFlag = consultFlag;
	}

	public String getConsultContext() {
		return consultContext;
	}

	public void setConsultContext(String consultContext) {
		this.consultContext = consultContext;
	}

	public Long getIsIndeedCredit() {
		return isIndeedCredit;
	}

	public void setIsIndeedCredit(Long isIndeedCredit) {
		this.isIndeedCredit = isIndeedCredit;
	}

	public String getIndeedCreditContext() {
		return indeedCreditContext;
	}

	public void setIndeedCreditContext(String indeedCreditContext) {
		this.indeedCreditContext = indeedCreditContext;
	}

	public BigDecimal getProductProportion() {
		return productProportion;
	}

	public void setProductProportion(BigDecimal productProportion) {
		this.productProportion = productProportion;
	}

	public BigDecimal getServiceProportion() {
		return serviceProportion;
	}

	public void setServiceProportion(BigDecimal serviceProportion) {
		this.serviceProportion = serviceProportion;
	}

	public Date getVisitSubmitAuditTime() {
		return visitSubmitAuditTime;
	}

	public void setVisitSubmitAuditTime(Date visitSubmitAuditTime) {
		this.visitSubmitAuditTime = visitSubmitAuditTime;
	}

	public Long getIsSysAuditPass() {
		return isSysAuditPass;
	}

	public void setIsSysAuditPass(Long isSysAuditPass) {
		this.isSysAuditPass = isSysAuditPass;
	}

	@Override
	public String toString() {
		return "ApplyBillMainInfoDO{" +
				"id=" + id +
				", applySouce=" + applySouce +
				", expectProductId=" + expectProductId +
				", expectProductName='" + expectProductName + '\'' +
				", expectProductType=" + expectProductType +
				", expectMoney=" + expectMoney +
				", expectTerm=" + expectTerm +
				", applyTime=" + applyTime +
				", clientId=" + clientId +
				", clientGrade=" + clientGrade +
				", clientIdcard='" + clientIdcard + '\'' +
				", clientRealName='" + clientRealName + '\'' +
				", clientRealFlag=" + clientRealFlag +
				", overdueFlag=" + overdueFlag +
				", overdueLeven='" + overdueLeven + '\'' +
				", cousultId=" + cousultId +
				", applyId=" + applyId +
				", contractId=" + contractId +
				", districtOrgId=" + districtOrgId +
				", branchDistrictOrgId=" + branchDistrictOrgId +
				", storeOrgId=" + storeOrgId +
				", teamOrgId=" + teamOrgId +
				", managerUid=" + managerUid +
				", managerUname='" + managerUname + '\'' +
				", teamManagerId=" + teamManagerId +
				", teamManagerUname='" + teamManagerUname + '\'' +
				", serviveManagerUid=" + serviveManagerUid +
				", serviveManagerName='" + serviveManagerName + '\'' +
				", serviceUid=" + serviceUid +
				", serviceName='" + serviceName + '\'' +
				", contractUid=" + contractUid +
				", contractReviewUid=" + contractReviewUid +
				", auditPrimaryUid=" + auditPrimaryUid +
				", auditPrimaryUname='" + auditPrimaryUname + '\'' +
				", auditEndUid=" + auditEndUid +
				", auditEndUname='" + auditEndUname + '\'' +
				", visitCount=" + visitCount +
				", isResuse=" + isResuse +
				", refuseCode='" + refuseCode + '\'' +
				", refuseValue='" + refuseValue + '\'' +
				", agreeProductId=" + agreeProductId +
				", agreeProductLimit=" + agreeProductLimit +
				", agreeAmount=" + agreeAmount +
				", loanChannelId=" + loanChannelId +
				", loanMoney=" + loanMoney +
				", overFlag=" + overFlag +
				", overTime=" + overTime +
				", submitConsultTime=" + submitConsultTime +
				", submitApplyToAuditTime=" + submitApplyToAuditTime +
				", endauditOverTime=" + endauditOverTime +
				", contractNum='" + contractNum + '\'' +
				", contractMoney=" + contractMoney +
				", contractAuditAdoptTime=" + contractAuditAdoptTime +
				", financeGiveLoanTime=" + financeGiveLoanTime +
				", accountingDateTime=" + accountingDateTime +
				", state=" + state +
				", previous=" + previous +
				", clientAbandon=" + clientAbandon +
				", abandonReason=" + abandonReason +
				", createTime=" + createTime +
				", createUser=" + createUser +
				", modifyTime=" + modifyTime +
				", modifyUser=" + modifyUser +
				", submitReconsiderTime=" + submitReconsiderTime +
				", submitSignatoryVerificationTime=" + submitSignatoryVerificationTime +
				", applyNum='" + applyNum + '\'' +
				", isLoop=" + isLoop +
				", isSignCheck=" + isSignCheck +
				", signCheckContent='" + signCheckContent + '\'' +
				", teamOrgName='" + teamOrgName + '\'' +
				", agreeProductName='" + agreeProductName + '\'' +
				", monthRepaymentMoney=" + monthRepaymentMoney +
				", serviceProportionType='" + serviceProportionType + '\'' +
				", unauthorized=" + unauthorized +
				", projectCode=" + projectCode +
				", isRiskHand=" + isRiskHand +
				", applyStatus=" + applyStatus +
				", policyCode=" + policyCode +
				", isApprovalPassed=" + isApprovalPassed +
				", reconsiderationQty=" + reconsiderationQty +
				", consultFlag=" + consultFlag +
				", consultContext='" + consultContext + '\'' +
				", isIndeedCredit=" + isIndeedCredit +
				", indeedCreditContext='" + indeedCreditContext + '\'' +
				", productProportion=" + productProportion +
				", serviceProportion=" + serviceProportion +
				", visitSubmitAuditTime=" + visitSubmitAuditTime +
				", isSysAuditPass=" + isSysAuditPass +
				'}';
	}
}
