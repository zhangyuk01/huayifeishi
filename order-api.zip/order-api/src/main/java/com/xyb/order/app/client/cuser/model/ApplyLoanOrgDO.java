package com.xyb.order.app.client.cuser.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
* @description:    申请借款营业部
* @author:         xieqingyang
* @createDate:     2018/5/15 下午9:03
*/
public class ApplyLoanOrgDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    /**营业部ID*/
    private Long orgId;
    /**营业部名称*/
    private String serviceNetwork = "";
    /**服务网点描述*/
    private String serviceDes = "";

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }

    public String getServiceNetwork() {
        return serviceNetwork;
    }

    public void setServiceNetwork(String serviceNetwork) {
        this.serviceNetwork = serviceNetwork;
    }

    public String getServiceDes() {
        return serviceDes;
    }

    public void setServiceDes(String serviceDes) {
        this.serviceDes = serviceDes;
    }
}
