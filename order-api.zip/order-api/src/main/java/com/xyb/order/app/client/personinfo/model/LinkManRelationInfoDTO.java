package com.xyb.order.app.client.personinfo.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class LinkManRelationInfoDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private String id;//主键ID
	@JsonIgnore
	private Long applyId;//申请单ID
	@JsonIgnore
	private Long cusId;//客户ID
	@NotNull(message = "联系人姓名不能为空")
	private String name;//联系人姓名
	@NotNull(message = "联系人关系不能为空")
	private Long relation;//联系人关系
	@NotNull(message = "联系人手机号不能为空")
	@Size(min = 11,max = 11,message = "请传入正确的手机号")
	private String phone1;//联系人手机号
	private String idcard;//联系人身份证号
	private String compName;//联系人公司
	private Long isSelfAddr;//是否与本人相同地址
	@NotNull(message = "联系人省不能为空")
	private Long province;//联系人省
	@NotNull(message = "联系人市不能为空")
	private Long city;//联系人市
	@NotNull(message = "联系人区不能为空")
	private Long area;//联系人区
	@NotEmpty(message = "联系人地址不能为空")
	private String address;//联系人地址
	@NotEmpty(message = "联系人全地址不能为空")
	private String allAddress;//联系人全地址
	@NotNull(message = "是否知晓申请不能为空")
	private Long isKnowLoan;//是否知晓申请
	@NotNull(message = "联系人关系类型不能为空")
	private Long contactType;//联系人关系类型
	private String phoneType;//手机型号
	private Long  batchNum;//批次号
	/**职务*/
	private String duty;
	@JsonIgnore
	private Date createTime;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Date modifyTime;
	@JsonIgnore
	private Long modifyUser;


	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

	public Long getBatchNum() {
		return batchNum;
	}

	public void setBatchNum(Long batchNum) {
		this.batchNum = batchNum;
	}

	@Override
	public String toString() {
		return "LinkManRelationInfoDTO [id=" + id + ", applyId=" + applyId + ", cusId=" + cusId + ", name=" + name
				+ ", relation=" + relation + ", phone1=" + phone1 + ", idcard=" + idcard + ", compName=" + compName
				+ ", isSelfAddr=" + isSelfAddr + ", province=" + province + ", city=" + city + ", area=" + area
				+ ", address=" + address + ", allAddress=" + allAddress + ", isKnowLoan=" + isKnowLoan
				+ ", contactType=" + contactType + ", phoneType=" + phoneType + ", batchNum=" + batchNum + ", duty="
				+ duty + ", createTime=" + createTime + ", createUser=" + createUser + ", modifyTime=" + modifyTime
				+ ", modifyUser=" + modifyUser + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getCusId() {
		return cusId;
	}

	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getRelation() {
		return relation;
	}

	public void setRelation(Long relation) {
		this.relation = relation;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public Long getIsSelfAddr() {
		return isSelfAddr;
	}

	public void setIsSelfAddr(Long isSelfAddr) {
		this.isSelfAddr = isSelfAddr;
	}

	public Long getProvince() {
		return province;
	}

	public void setProvince(Long province) {
		this.province = province;
	}

	public Long getCity() {
		return city;
	}

	public void setCity(Long city) {
		this.city = city;
	}

	public Long getArea() {
		return area;
	}

	public void setArea(Long area) {
		this.area = area;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAllAddress() {
		return allAddress;
	}

	public void setAllAddress(String allAddress) {
		this.allAddress = allAddress;
	}

	public Long getIsKnowLoan() {
		return isKnowLoan;
	}

	public void setIsKnowLoan(Long isKnowLoan) {
		this.isKnowLoan = isKnowLoan;
	}

	public Long getContactType() {
		return contactType;
	}

	public void setContactType(Long contactType) {
		this.contactType = contactType;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
}
