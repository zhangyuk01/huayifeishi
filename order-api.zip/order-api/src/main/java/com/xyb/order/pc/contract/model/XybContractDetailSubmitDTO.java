package com.xyb.order.pc.contract.model;

import javax.validation.Valid;

import com.beiming.kun.framework.model.IBaseModel;

public class XybContractDetailSubmitDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1521286315523526088L;
	
	@Valid
	private XybContractDTO xybContractDTO;

	public XybContractDTO getXybContractDTO() {
		return xybContractDTO;
	}

	public void setXybContractDTO(XybContractDTO xybContractDTO) {
		this.xybContractDTO = xybContractDTO;
	}

	@Override
	public String toString() {
		return "XybContractDetailSubmitDTO [xybContractDTO=" + xybContractDTO + "]";
	}

}
