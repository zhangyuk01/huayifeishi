package com.xyb.order.pc.contract.contracttb.model;


import java.math.BigDecimal;
import java.util.List;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @author : houlvshuang
 * @projectName : finance-api
 * @package : com.xyb.loan.http.api.model
 * @description : 合同推标数据对象封装
 * @createDate : 2018/8/6 14:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ContractTbItemDetail implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6469408525252199044L;
	/**申请Id*/
	private String applyId;
	/**产品id*/
	private String productId;
	/**合同金额*/
	private BigDecimal contractAmount;
	/**借款用途*/
	private String borrowDesc;
	/**利率,月利率*/
	private BigDecimal interestRate;
	/**服务费*/
	private BigDecimal serviceFee;
	/**账户管理费*/
	private BigDecimal managerFee;
	/**还款方式*/
	private String returnType;
	/**出生日期，YYYY-MM-DD*/
	private String birthday;
	/**户籍地址，省+市+区县+详细地址（all_address)*/
	private String householdRegister;
	/**学历*/
	private String education;
	/**婚否*/
	private String marriage;
	/**是否有小孩*/
	private String children;
	/**收入级别*/
	private String incomeLevel;
	/**房子信息*/
	private String houseInfo;
	/**车信息*/
	private String carInfo;
	/**有无其他信用贷款*/
	private String otherLoan;
	/**信用卡数量*/
	private String creditCard;
	/**信用卡额度*/
	private String creditLimit;
	/**身份证*/
	private String idcard;
	/**手机号码*/
	private String phone1;
	/**评分*/
	private String xybScore;
	/**审批金额*/
	private String agreeAmount;
	/**借款期限*/
	private String productLimit;
	/**姓名*/
	private String name;
	/**进件机构*/
	private String incomeCity;
	/**团队经理*/
	private String saleManager;
	/**信用报告附件URL集合*/
	private List<ContractTbItemList> creditReportURLList;
	/**工作证明附件URL集合*/
	private List<ContractTbItemList> workProveURLList;
	/**个人收入证明附件URL集合*/
	private List<ContractTbItemList> incomeProveURLList;
	/**居住证明附件URL集合*/
	private List<ContractTbItemList> liveProveURLList;
	/**借款合同附件URL集合*/
	private List<ContractTbItemList> contractURLList;
	/**身份证附件URL集合*/
	private List<ContractTbItemList> idcardURLList;
	/**披露影像URL集合*/
	private List<ContractTbItemList> announceURLList;
	/**自我推荐URL集合*/
	private List<ContractTbItemList> selfRecommendURLList;
	/**征信报告严重逾期次数*/
	private String seriousOverdueNum;
	/**征信报告待偿银行贷款笔数*/
	private String reportWaitLoanNum;
	/**征信报告待偿银行贷款金额*/
	private String reportWaitLoanAmt;
	/**征信报告逾期次数*/
	private String reportOverdueNum;
	/**征信报告逾期金额*/
	private BigDecimal reportOverdueAmt;
	/**当前负债金额，保留小数2位*/
	private Double currLiabilities;
	/** 计算借款人还款每期收取的服务费，如无则为0.0000, 小数最大精度后4位 例如0.1114 或者 0.1200*/
	private String repayFeeRate;
	/**[必填][String]政策风险*/
	private String policyRisk;
	/**[必填][String]市场风险*/
	private String marketRisk;
	/**[必填][String]信用风险*/
	private String creditRisk;
	/**工作性质，中文描述*/
	private String jobType;
	/**申请日期 如2017-08-25*/
	private String applyDate;
	/**年收入 以元为单位*/
	private String yearIncome;
	/**未销户信用卡数量*/
	private Integer creditNum;
	/**公积金状态 (暂无、正常缴纳)*/
	private String fundStatus;
	/**社保状态(暂无、正常缴纳)*/
	private String insureStatus;
	/**历史逾期次数*/
	private String overDueNum;
	/**历史逾期金额*/
	private String overDueAmt;
	/**借款人主体性质(默认 自然人)*/
	private String borrowerSubject;
	/**证件类型(默认 身份证)*/
	private String certificateType;
	/**借款人标签*/
	private String borrowerLabel;
	/**公积金城市*/
	private String fundCity;
	/**公积金缴纳基数*/
	private String fundBaseMoney;
	/**公积金月申报金额*/
	private String fundMonthMoney;
	/**公积金缴纳单位名称*/
	private String gjjComName;
	/**公积金本单位缴存时长/月*/
	private String cpfDuration;
	/**社保城市*/
	private String insureCity;
	/**社保缴纳基数*/
	private String baseRmb;
	/**社保月申报金额*/
	private String insureMonthMoney;
	/**社保缴纳单位名称*/
	private String insureComName;
	/**社保本单位缴存时长/月*/
	private String jinpoDuration;
	/**保单*/
	private List<ContractTbItemDetailBaoDan> baoDanList;
	/**入网时长*/
	private String phoneUsedTime;
	/**近六个月月均话费消费*/
	private String avgAmountM6;
	/**朋友圈主要活跃地址是否与居住地址一致*/
	private String friendAndAddress;
	/**法院黑名单检查*/
	private String courtBlack;
	/**法院号码通话情况*/
	private String courtContactCourt;
	/**金融服务类机构黑名单检查*/
	private String financialBlack;
	/**黑中介分数*/
	private Integer phoneGrayScore;
	/**直接联系人中黑名单人数*/
	private Integer contactsClass1BlacklistCnt;
	/**近3月本人查询次数*/
	private String selfQueriesM3;
	/**近3月贷款审核查询次数*/
	private String loanQueriesM3;
	/**信用卡额度使用率*/
	private String creditLimitUseRate;
	/**信用卡逾期总金额*/
	private BigDecimal creditOverAmts;
	/**信用卡60个月内逾期超过90天的次数*/
	private String creditCountsM60D90;
	/**月还贷款总额*/
	private String loanBalancesMonth;
	/**月还房贷金额*/
	private String loanBalancesMortgageMonth;
	/**月还车贷金额*/
	private String loanBalancesCarMonth;
	/**月还其他贷总余额*/
	private String loanBalancesOtherMonth;
	/**贷款60个月内逾期超过90天的次数(月数)*/
	private String loanCountsM60D90;
	/**是否是风险定价标*/
	private String riskBid;
	/**风险等级*/
	private String riskLevel;
	/**推荐语*/
	private String dcRecommendText;
//	/**银行类别*/
//	private Long bankType;
//	/**银行卡户名*/
//	private String bankAccount;
//	/**银行卡卡号*/
//	private String bankCardNum;
//	/**银行预留手机号*/
//	private String bankMp;
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public BigDecimal getContractAmount() {
		return contractAmount;
	}
	public void setContractAmount(BigDecimal contractAmount) {
		this.contractAmount = contractAmount;
	}
	public String getBorrowDesc() {
		return borrowDesc;
	}
	public void setBorrowDesc(String borrowDesc) {
		this.borrowDesc = borrowDesc;
	}
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public BigDecimal getServiceFee() {
		return serviceFee;
	}
	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}
	public BigDecimal getManagerFee() {
		return managerFee;
	}
	public void setManagerFee(BigDecimal managerFee) {
		this.managerFee = managerFee;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getHouseholdRegister() {
		return householdRegister;
	}
	public void setHouseholdRegister(String householdRegister) {
		this.householdRegister = householdRegister;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getMarriage() {
		return marriage;
	}
	public void setMarriage(String marriage) {
		this.marriage = marriage;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public String getIncomeLevel() {
		return incomeLevel;
	}
	public void setIncomeLevel(String incomeLevel) {
		this.incomeLevel = incomeLevel;
	}
	public String getHouseInfo() {
		return houseInfo;
	}
	public void setHouseInfo(String houseInfo) {
		this.houseInfo = houseInfo;
	}
	public String getCarInfo() {
		return carInfo;
	}
	public void setCarInfo(String carInfo) {
		this.carInfo = carInfo;
	}
	public String getOtherLoan() {
		return otherLoan;
	}
	public void setOtherLoan(String otherLoan) {
		this.otherLoan = otherLoan;
	}
	public String getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	public String getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getXybScore() {
		return xybScore;
	}
	public void setXybScore(String xybScore) {
		this.xybScore = xybScore;
	}
	public String getAgreeAmount() {
		return agreeAmount;
	}
	public void setAgreeAmount(String agreeAmount) {
		this.agreeAmount = agreeAmount;
	}
	public String getProductLimit() {
		return productLimit;
	}
	public void setProductLimit(String productLimit) {
		this.productLimit = productLimit;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIncomeCity() {
		return incomeCity;
	}
	public void setIncomeCity(String incomeCity) {
		this.incomeCity = incomeCity;
	}
	public String getSaleManager() {
		return saleManager;
	}
	public void setSaleManager(String saleManager) {
		this.saleManager = saleManager;
	}
	public List<ContractTbItemList> getCreditReportURLList() {
		return creditReportURLList;
	}
	public void setCreditReportURLList(List<ContractTbItemList> creditReportURLList) {
		this.creditReportURLList = creditReportURLList;
	}
	public List<ContractTbItemList> getWorkProveURLList() {
		return workProveURLList;
	}
	public void setWorkProveURLList(List<ContractTbItemList> workProveURLList) {
		this.workProveURLList = workProveURLList;
	}
	public List<ContractTbItemList> getIncomeProveURLList() {
		return incomeProveURLList;
	}
	public void setIncomeProveURLList(List<ContractTbItemList> incomeProveURLList) {
		this.incomeProveURLList = incomeProveURLList;
	}
	public List<ContractTbItemList> getLiveProveURLList() {
		return liveProveURLList;
	}
	public void setLiveProveURLList(List<ContractTbItemList> liveProveURLList) {
		this.liveProveURLList = liveProveURLList;
	}
	public List<ContractTbItemList> getContractURLList() {
		return contractURLList;
	}
	public void setContractURLList(List<ContractTbItemList> contractURLList) {
		this.contractURLList = contractURLList;
	}
	public List<ContractTbItemList> getIdcardURLList() {
		return idcardURLList;
	}
	public void setIdcardURLList(List<ContractTbItemList> idcardURLList) {
		this.idcardURLList = idcardURLList;
	}
	public List<ContractTbItemList> getAnnounceURLList() {
		return announceURLList;
	}
	public void setAnnounceURLList(List<ContractTbItemList> announceURLList) {
		this.announceURLList = announceURLList;
	}
	public List<ContractTbItemList> getSelfRecommendURLList() {
		return selfRecommendURLList;
	}
	public void setSelfRecommendURLList(List<ContractTbItemList> selfRecommendURLList) {
		this.selfRecommendURLList = selfRecommendURLList;
	}
	public String getSeriousOverdueNum() {
		return seriousOverdueNum;
	}
	public void setSeriousOverdueNum(String seriousOverdueNum) {
		this.seriousOverdueNum = seriousOverdueNum;
	}
	public String getReportWaitLoanNum() {
		return reportWaitLoanNum;
	}
	public void setReportWaitLoanNum(String reportWaitLoanNum) {
		this.reportWaitLoanNum = reportWaitLoanNum;
	}
	public String getReportWaitLoanAmt() {
		return reportWaitLoanAmt;
	}
	public void setReportWaitLoanAmt(String reportWaitLoanAmt) {
		this.reportWaitLoanAmt = reportWaitLoanAmt;
	}
	public String getReportOverdueNum() {
		return reportOverdueNum;
	}
	public void setReportOverdueNum(String reportOverdueNum) {
		this.reportOverdueNum = reportOverdueNum;
	}
	public BigDecimal getReportOverdueAmt() {
		return reportOverdueAmt;
	}
	public void setReportOverdueAmt(BigDecimal reportOverdueAmt) {
		this.reportOverdueAmt = reportOverdueAmt;
	}
	public Double getCurrLiabilities() {
		return currLiabilities;
	}
	public void setCurrLiabilities(Double currLiabilities) {
		this.currLiabilities = currLiabilities;
	}
	public String getRepayFeeRate() {
		return repayFeeRate;
	}
	public void setRepayFeeRate(String repayFeeRate) {
		this.repayFeeRate = repayFeeRate;
	}
	public String getPolicyRisk() {
		return policyRisk;
	}
	public void setPolicyRisk(String policyRisk) {
		this.policyRisk = policyRisk;
	}
	public String getMarketRisk() {
		return marketRisk;
	}
	public void setMarketRisk(String marketRisk) {
		this.marketRisk = marketRisk;
	}
	public String getCreditRisk() {
		return creditRisk;
	}
	public void setCreditRisk(String creditRisk) {
		this.creditRisk = creditRisk;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getApplyDate() {
		return applyDate;
	}
	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}
	public String getYearIncome() {
		return yearIncome;
	}
	public void setYearIncome(String yearIncome) {
		this.yearIncome = yearIncome;
	}
	public Integer getCreditNum() {
		return creditNum;
	}
	public void setCreditNum(Integer creditNum) {
		this.creditNum = creditNum;
	}
	public String getFundStatus() {
		return fundStatus;
	}
	public void setFundStatus(String fundStatus) {
		this.fundStatus = fundStatus;
	}
	public String getInsureStatus() {
		return insureStatus;
	}
	public void setInsureStatus(String insureStatus) {
		this.insureStatus = insureStatus;
	}
	public String getOverDueNum() {
		return overDueNum;
	}
	public void setOverDueNum(String overDueNum) {
		this.overDueNum = overDueNum;
	}
	public String getOverDueAmt() {
		return overDueAmt;
	}
	public void setOverDueAmt(String overDueAmt) {
		this.overDueAmt = overDueAmt;
	}
	public String getBorrowerSubject() {
		return borrowerSubject;
	}
	public void setBorrowerSubject(String borrowerSubject) {
		this.borrowerSubject = borrowerSubject;
	}
	public String getCertificateType() {
		return certificateType;
	}
	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}
	public String getBorrowerLabel() {
		return borrowerLabel;
	}
	public void setBorrowerLabel(String borrowerLabel) {
		this.borrowerLabel = borrowerLabel;
	}
	public String getFundCity() {
		return fundCity;
	}
	public void setFundCity(String fundCity) {
		this.fundCity = fundCity;
	}
	public String getFundBaseMoney() {
		return fundBaseMoney;
	}
	public void setFundBaseMoney(String fundBaseMoney) {
		this.fundBaseMoney = fundBaseMoney;
	}
	public String getFundMonthMoney() {
		return fundMonthMoney;
	}
	public void setFundMonthMoney(String fundMonthMoney) {
		this.fundMonthMoney = fundMonthMoney;
	}
	public String getGjjComName() {
		return gjjComName;
	}
	public void setGjjComName(String gjjComName) {
		this.gjjComName = gjjComName;
	}
	public String getCpfDuration() {
		return cpfDuration;
	}
	public void setCpfDuration(String cpfDuration) {
		this.cpfDuration = cpfDuration;
	}
	public String getInsureCity() {
		return insureCity;
	}
	public void setInsureCity(String insureCity) {
		this.insureCity = insureCity;
	}
	public String getBaseRmb() {
		return baseRmb;
	}
	public void setBaseRmb(String baseRmb) {
		this.baseRmb = baseRmb;
	}
	public String getInsureMonthMoney() {
		return insureMonthMoney;
	}
	public void setInsureMonthMoney(String insureMonthMoney) {
		this.insureMonthMoney = insureMonthMoney;
	}
	public String getInsureComName() {
		return insureComName;
	}
	public void setInsureComName(String insureComName) {
		this.insureComName = insureComName;
	}
	public String getJinpoDuration() {
		return jinpoDuration;
	}
	public void setJinpoDuration(String jinpoDuration) {
		this.jinpoDuration = jinpoDuration;
	}
	public List<ContractTbItemDetailBaoDan> getBaoDanList() {
		return baoDanList;
	}
	public void setBaoDanList(List<ContractTbItemDetailBaoDan> baoDanList) {
		this.baoDanList = baoDanList;
	}
	public String getPhoneUsedTime() {
		return phoneUsedTime;
	}
	public void setPhoneUsedTime(String phoneUsedTime) {
		this.phoneUsedTime = phoneUsedTime;
	}
	public String getAvgAmountM6() {
		return avgAmountM6;
	}
	public void setAvgAmountM6(String avgAmountM6) {
		this.avgAmountM6 = avgAmountM6;
	}
	public String getFriendAndAddress() {
		return friendAndAddress;
	}
	public void setFriendAndAddress(String friendAndAddress) {
		this.friendAndAddress = friendAndAddress;
	}
	public String getCourtBlack() {
		return courtBlack;
	}
	public void setCourtBlack(String courtBlack) {
		this.courtBlack = courtBlack;
	}
	public String getCourtContactCourt() {
		return courtContactCourt;
	}
	public void setCourtContactCourt(String courtContactCourt) {
		this.courtContactCourt = courtContactCourt;
	}
	public String getFinancialBlack() {
		return financialBlack;
	}
	public void setFinancialBlack(String financialBlack) {
		this.financialBlack = financialBlack;
	}
	public Integer getPhoneGrayScore() {
		return phoneGrayScore;
	}
	public void setPhoneGrayScore(Integer phoneGrayScore) {
		this.phoneGrayScore = phoneGrayScore;
	}
	public Integer getContactsClass1BlacklistCnt() {
		return contactsClass1BlacklistCnt;
	}
	public void setContactsClass1BlacklistCnt(Integer contactsClass1BlacklistCnt) {
		this.contactsClass1BlacklistCnt = contactsClass1BlacklistCnt;
	}
	public String getSelfQueriesM3() {
		return selfQueriesM3;
	}
	public void setSelfQueriesM3(String selfQueriesM3) {
		this.selfQueriesM3 = selfQueriesM3;
	}
	public String getLoanQueriesM3() {
		return loanQueriesM3;
	}
	public void setLoanQueriesM3(String loanQueriesM3) {
		this.loanQueriesM3 = loanQueriesM3;
	}
	public String getCreditLimitUseRate() {
		return creditLimitUseRate;
	}
	public void setCreditLimitUseRate(String creditLimitUseRate) {
		this.creditLimitUseRate = creditLimitUseRate;
	}
	public BigDecimal getCreditOverAmts() {
		return creditOverAmts;
	}
	public void setCreditOverAmts(BigDecimal creditOverAmts) {
		this.creditOverAmts = creditOverAmts;
	}
	public String getCreditCountsM60D90() {
		return creditCountsM60D90;
	}
	public void setCreditCountsM60D90(String creditCountsM60D90) {
		this.creditCountsM60D90 = creditCountsM60D90;
	}
	public String getLoanBalancesMonth() {
		return loanBalancesMonth;
	}
	public void setLoanBalancesMonth(String loanBalancesMonth) {
		this.loanBalancesMonth = loanBalancesMonth;
	}
	public String getLoanBalancesMortgageMonth() {
		return loanBalancesMortgageMonth;
	}
	public void setLoanBalancesMortgageMonth(String loanBalancesMortgageMonth) {
		this.loanBalancesMortgageMonth = loanBalancesMortgageMonth;
	}
	public String getLoanBalancesCarMonth() {
		return loanBalancesCarMonth;
	}
	public void setLoanBalancesCarMonth(String loanBalancesCarMonth) {
		this.loanBalancesCarMonth = loanBalancesCarMonth;
	}
	public String getLoanBalancesOtherMonth() {
		return loanBalancesOtherMonth;
	}
	public void setLoanBalancesOtherMonth(String loanBalancesOtherMonth) {
		this.loanBalancesOtherMonth = loanBalancesOtherMonth;
	}
	public String getLoanCountsM60D90() {
		return loanCountsM60D90;
	}
	public void setLoanCountsM60D90(String loanCountsM60D90) {
		this.loanCountsM60D90 = loanCountsM60D90;
	}
	public String getRiskBid() {
		return riskBid;
	}
	public void setRiskBid(String riskBid) {
		this.riskBid = riskBid;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
	public String getDcRecommendText() {
		return dcRecommendText;
	}
	public void setDcRecommendText(String dcRecommendText) {
		this.dcRecommendText = dcRecommendText;
	}
	@Override
	public String toString() {
		return "ContractTbItemDetail [applyId=" + applyId + ", productId=" + productId + ", contractAmount="
				+ contractAmount + ", borrowDesc=" + borrowDesc + ", interestRate=" + interestRate + ", serviceFee="
				+ serviceFee + ", managerFee=" + managerFee + ", returnType=" + returnType + ", birthday=" + birthday
				+ ", householdRegister=" + householdRegister + ", education=" + education + ", marriage=" + marriage
				+ ", children=" + children + ", incomeLevel=" + incomeLevel + ", houseInfo=" + houseInfo + ", carInfo="
				+ carInfo + ", otherLoan=" + otherLoan + ", creditCard=" + creditCard + ", creditLimit=" + creditLimit
				+ ", idcard=" + idcard + ", phone1=" + phone1 + ", xybScore=" + xybScore + ", agreeAmount="
				+ agreeAmount + ", productLimit=" + productLimit + ", name=" + name + ", incomeCity=" + incomeCity
				+ ", saleManager=" + saleManager + ", creditReportURLList=" + creditReportURLList
				+ ", workProveURLList=" + workProveURLList + ", incomeProveURLList=" + incomeProveURLList
				+ ", liveProveURLList=" + liveProveURLList + ", contractURLList=" + contractURLList + ", idcardURLList="
				+ idcardURLList + ", announceURLList=" + announceURLList + ", selfRecommendURLList="
				+ selfRecommendURLList + ", seriousOverdueNum=" + seriousOverdueNum + ", reportWaitLoanNum="
				+ reportWaitLoanNum + ", reportWaitLoanAmt=" + reportWaitLoanAmt + ", reportOverdueNum="
				+ reportOverdueNum + ", reportOverdueAmt=" + reportOverdueAmt + ", currLiabilities=" + currLiabilities
				+ ", repayFeeRate=" + repayFeeRate + ", policyRisk=" + policyRisk + ", marketRisk=" + marketRisk
				+ ", creditRisk=" + creditRisk + ", jobType=" + jobType + ", applyDate=" + applyDate + ", yearIncome="
				+ yearIncome + ", creditNum=" + creditNum + ", fundStatus=" + fundStatus + ", insureStatus="
				+ insureStatus + ", overDueNum=" + overDueNum + ", overDueAmt=" + overDueAmt + ", borrowerSubject="
				+ borrowerSubject + ", certificateType=" + certificateType + ", borrowerLabel=" + borrowerLabel
				+ ", fundCity=" + fundCity + ", fundBaseMoney=" + fundBaseMoney + ", fundMonthMoney=" + fundMonthMoney
				+ ", gjjComName=" + gjjComName + ", cpfDuration=" + cpfDuration + ", insureCity=" + insureCity
				+ ", baseRmb=" + baseRmb + ", insureMonthMoney=" + insureMonthMoney + ", insureComName=" + insureComName
				+ ", jinpoDuration=" + jinpoDuration + ", baoDanList=" + baoDanList + ", phoneUsedTime=" + phoneUsedTime
				+ ", avgAmountM6=" + avgAmountM6 + ", friendAndAddress=" + friendAndAddress + ", courtBlack="
				+ courtBlack + ", courtContactCourt=" + courtContactCourt + ", financialBlack=" + financialBlack
				+ ", phoneGrayScore=" + phoneGrayScore + ", contactsClass1BlacklistCnt=" + contactsClass1BlacklistCnt
				+ ", selfQueriesM3=" + selfQueriesM3 + ", loanQueriesM3=" + loanQueriesM3 + ", creditLimitUseRate="
				+ creditLimitUseRate + ", creditOverAmts=" + creditOverAmts + ", creditCountsM60D90="
				+ creditCountsM60D90 + ", loanBalancesMonth=" + loanBalancesMonth + ", loanBalancesMortgageMonth="
				+ loanBalancesMortgageMonth + ", loanBalancesCarMonth=" + loanBalancesCarMonth
				+ ", loanBalancesOtherMonth=" + loanBalancesOtherMonth + ", loanCountsM60D90=" + loanCountsM60D90
				+ ", riskBid=" + riskBid + ", riskLevel=" + riskLevel + ", dcRecommendText=" + dcRecommendText + "]";
	}
	
}
