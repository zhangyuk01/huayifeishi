package com.xyb.order.pc.creditreport.model;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyPersonTationQueryDO implements IBaseModel{
	private static final long serialVersionUID = 1L;

	private Long id; //主键ID
	private Long applyId; //申请单ID
	private Integer queryType;//查询类型
	private Integer queryQty;//查询次数

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Integer getQueryType() {
		return queryType;
	}
	public void setQueryType(Integer queryType) {
		this.queryType = queryType;
	}
	public Integer getQueryQty() {
		return queryQty;
	}
	public void setQueryQty(Integer queryQty) {
		this.queryQty = queryQty;
	}
	

}
