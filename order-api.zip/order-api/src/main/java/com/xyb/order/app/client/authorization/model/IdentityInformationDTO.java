package com.xyb.order.app.client.authorization.model;

import com.beiming.kun.framework.model.IBaseModel;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
* @description:    身份认证信息
* @author:         xieqingyang
* @createDate:     2018/5/15 下午2:57
*/
public class IdentityInformationDTO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "姓名不能为空")
    private String name;
    @NotEmpty(message = "身份证号不能为空")
    @Size(min = 18,max = 18,message = "请传入正确格式的身份证")
    private String idcard;
    @NotEmpty(message = "性别不能为空")
    private String gender;
    @NotEmpty(message = "民族不能为空")
    private String nation;
    @NotEmpty(message = "生日不能为空")
    private String birthday;
    @NotEmpty(message = "住址不能为空")
    private String address;
    @NotEmpty(message = "签发机关不能为空")
    private String idcardPoliceStation;
    @NotEmpty(message = "有效期开始时间不能为空")
    private String idcardStartTime;
    @NotEmpty(message = "有效期结束时间不能为空")
    private String idcardEndTime;
    @NotEmpty(message = "身份证正面图片信息不能为空")
    private String idcardFrontSide;
    @NotEmpty(message = "身份证反面图片信息不能为空")
    private String idcardBackSide;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIdcardPoliceStation() {
        return idcardPoliceStation;
    }

    public void setIdcardPoliceStation(String idcardPoliceStation) {
        this.idcardPoliceStation = idcardPoliceStation;
    }

    public String getIdcardStartTime() {
        return idcardStartTime;
    }

    public void setIdcardStartTime(String idcardStartTime) {
        this.idcardStartTime = idcardStartTime;
    }

    public String getIdcardEndTime() {
        return idcardEndTime;
    }

    public void setIdcardEndTime(String idcardEndTime) {
        this.idcardEndTime = idcardEndTime;
    }

    public String getIdcardFrontSide() {
        return idcardFrontSide;
    }

    public void setIdcardFrontSide(String idcardFrontSide) {
        this.idcardFrontSide = idcardFrontSide;
    }

    public String getIdcardBackSide() {
        return idcardBackSide;
    }

    public void setIdcardBackSide(String idcardBackSide) {
        this.idcardBackSide = idcardBackSide;
    }
}
