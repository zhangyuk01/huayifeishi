package com.xyb.order.app.business.buser.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @ClassName ClientBuserDO(B端用户表)
 * @author ZhangYu
 * @date 2018年6月25号
 */
public class ClientBuserDO implements IBaseModel{

	private static final long serialVersionUID = 1L;
	
	private Long id;// -- 主键ID
	private String loginId;// -- 登录ID
	private String name;// -- 姓名
	private String password;// -- 密码
	private String mobile; // -- 手机号
	private String idcard; // -- 身份证号
	private Long orgId;// -- 所属机构
	private Long dataOrgId; // -- 数据权限
	private Long state;// -- 是否有效(大类2687)
	private String recommendCode;// -- 推荐码
	private Long  isFirstLand;// --是否首次登陆(大类2692) 
	private Date createTime;// -- 创建时间
	private Date modifyTime;// -- 修改时间
	private Long createUser;// -- 创建人
	private Long modifyUser;// -- 修改人
	private String deviceToken;//
	
	/**为修改手机号使用*/
    @JsonIgnore
    private String newMobile;// -- 待修改的手机号
	

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public Long getOrgId() {
		return orgId;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Long getDataOrgId() {
		return dataOrgId;
	}
	public void setDataOrgId(Long dataOrgId) {
		this.dataOrgId = dataOrgId;
	}
	public Long getState() {
		return state;
	}
	public void setState(Long state) {
		this.state = state;
	}
	public String getRecommendCode() {
		return recommendCode;
	}
	public void setRecommendCode(String recommendCode) {
		this.recommendCode = recommendCode;
	}
	public Long getIsFirstLand() {
		return isFirstLand;
	}
	public void setIsFirstLand(Long isFirstLand) {
		this.isFirstLand = isFirstLand;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getNewMobile() {
		return newMobile;
	}
	public void setNewMobile(String newMobile) {
		this.newMobile = newMobile;
	}
	public String getDeviceToken() {
		return deviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	
}
