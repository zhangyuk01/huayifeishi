package com.xyb.order.pc.contract.model.thridPay;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.contract.model
 * @description : 合同录入预绑卡重发短信DTO
 * @createDate : 2018/05/28 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ThirdPayBindPreResendDTO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8821184284529851988L;
	/**申请id*/
	@NotNull(message="applyId 不能为空")
	private Long applyId;
	/**渠道id*/
	@NotNull(message="channelId 不能为空")
	private Long channelId;
	/**预绑卡订单号*/
	@NotEmpty(message="order 不能为空")
	private String order;
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getChannelId() {
		return channelId;
	}
	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	@Override
	public String toString() {
		return "ThirdPayBindPreResendDTO [applyId=" + applyId + ", channelId=" + channelId + ", order=" + order + "]";
	}
	
}
