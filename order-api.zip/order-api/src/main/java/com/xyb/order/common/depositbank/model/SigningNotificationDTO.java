package com.xyb.order.common.depositbank.model;

import com.beiming.kun.framework.model.IBaseModel;
import com.xyb.order.pc.annotation.SignField;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.common.depositbank.model
 * @description : 签约结果通知 参数model
 * @createDate : 2018/11/26 16:43
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class SigningNotificationDTO implements IBaseModel {

    private static final long serialVersionUID = -7264179429042116055L;

    /**
     * card_no : 电子账户
     * out_serial_no : 流水号
     * sign_flag : 签约状态(having(签约),revoking(未签约))
     * payment_amount : 放款手续费签约金额
     * repayment_amount : 还款签约金额
     * payment_start_time : 放款手续费签约开始时间(10位时间戳)
     * repayment_start_time : 还款签约开始时间(10位时间戳)
     * payment_end_time : 放款手续费签约结束时间(10位时间戳)
     * repayment_end_time : 还款签约结束时间(10位时间戳)
     * sign_date : 签约日期(yyyy-MM-dd)
     * sign_time : 签约时间(HH:mm:ss)
     */

    @NotEmpty(message = "card_no 不能为空!")
    @SignField(order = 2)
    private String card_no;
    @SignField(order = 3)
    private String out_serial_no;
    @NotEmpty(message = "sign_flag 不能为空!")
    private String sign_flag;
    private String payment_amount;
    private String repayment_amount;
    private String payment_start_time;
    private String repayment_start_time;
    private String payment_end_time;
    private String repayment_end_time;
    private String sign_date;
    private String sign_time;

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getOut_serial_no() {
        return out_serial_no;
    }

    public void setOut_serial_no(String out_serial_no) {
        this.out_serial_no = out_serial_no;
    }

    public String getSign_flag() {
        return sign_flag;
    }

    public void setSign_flag(String sign_flag) {
        this.sign_flag = sign_flag;
    }

    public String getPayment_amount() {
        return payment_amount;
    }

    public void setPayment_amount(String payment_amount) {
        this.payment_amount = payment_amount;
    }

    public String getRepayment_amount() {
        return repayment_amount;
    }

    public void setRepayment_amount(String repayment_amount) {
        this.repayment_amount = repayment_amount;
    }

    public String getPayment_start_time() {
        return payment_start_time;
    }

    public void setPayment_start_time(String payment_start_time) {
        this.payment_start_time = payment_start_time;
    }

    public String getRepayment_start_time() {
        return repayment_start_time;
    }

    public void setRepayment_start_time(String repayment_start_time) {
        this.repayment_start_time = repayment_start_time;
    }

    public String getPayment_end_time() {
        return payment_end_time;
    }

    public void setPayment_end_time(String payment_end_time) {
        this.payment_end_time = payment_end_time;
    }

    public String getRepayment_end_time() {
        return repayment_end_time;
    }

    public void setRepayment_end_time(String repayment_end_time) {
        this.repayment_end_time = repayment_end_time;
    }

    public String getSign_date() {
        return sign_date;
    }

    public void setSign_date(String sign_date) {
        this.sign_date = sign_date;
    }

    public String getSign_time() {
        return sign_time;
    }

    public void setSign_time(String sign_time) {
        this.sign_time = sign_time;
    }

    @Override
    public String toString() {
        return "SigningNotificationDTO{" +
                "card_no='" + card_no + '\'' +
                ", out_serial_no='" + out_serial_no + '\'' +
                ", sign_flag='" + sign_flag + '\'' +
                ", payment_amount='" + payment_amount + '\'' +
                ", repayment_amount='" + repayment_amount + '\'' +
                ", payment_start_time='" + payment_start_time + '\'' +
                ", repayment_start_time='" + repayment_start_time + '\'' +
                ", payment_end_time='" + payment_end_time + '\'' +
                ", repayment_end_time='" + repayment_end_time + '\'' +
                ", sign_date='" + sign_date + '\'' +
                ", sign_time='" + sign_time + '\'' +
                '}';
    }
}
