package com.xyb.order.common.currency.model;

import com.beiming.kun.framework.model.IBaseModel;

import java.util.Date;

/**
* @description:    app版本信息
* @author:         xieqingyang
* @createDate:     2018/5/14 上午11:32
*/
public class AppVersionDO implements IBaseModel {

    private static final long serialVersionUID = 1L;

    private Long id;
    private Long appType;// -- app类型（大类2714）
    private Long deviceType;// -- 登录设备类型（大类2715）
    private Integer versionCode;// -- 版本号
    private String versionName;// -- 版本名称
    private String remark;// -- 更新摘要
    private String updateUrl;// -- 更新地址
    private Long need;// -- 是否强制（大类2692）
    private Long isShow;// -- 是否展示（大类2692）
    private Date createDate;// -- 创建日期
    private Date modifyTime;// -- 最后修改时间
    private String createUser;// -- 创建人
    private String modifyUser;// -- 最后修改人

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAppType() {
        return appType;
    }

    public void setAppType(Long appType) {
        this.appType = appType;
    }

    public Long getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Long deviceType) {
        this.deviceType = deviceType;
    }

    public Integer getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(Integer versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getUpdateUrl() {
        return updateUrl;
    }

    public void setUpdateUrl(String updateUrl) {
        this.updateUrl = updateUrl;
    }

    public Long getNeed() {
        return need;
    }

    public void setNeed(Long need) {
        this.need = need;
    }

    public Long getIsShow() {
        return isShow;
    }

    public void setIsShow(Long isShow) {
        this.isShow = isShow;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser;
    }
}
