package com.xyb.order.pc.outbound.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.model
 * @description : 外访主表 model
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public class ApplyVisitMainInfoDO implements IBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7936897156196179674L;


    private Long id;

    private Long applyId;

    private Long visitState;

    private Long visitType;

    private Long submitVisitNode;

    private Long visitUid;

    private Long visitCheckUid;

    private Date visitDate;

    private String customerIntegratedDescription;

    private Date visitIndustryDate;

    private String industryDescription;

    private Long auditUser;

    private Long visitReason;

    private String isTempSave;

    private Date createTime;

    private Long createUser;

    private Date modifyTime;

    private Long modifyUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	public Long getVisitState() {
		return visitState;
	}

	public void setVisitState(Long visitState) {
		this.visitState = visitState;
	}

	public Long getVisitType() {
		return visitType;
	}

	public void setVisitType(Long visitType) {
		this.visitType = visitType;
	}

	public Long getSubmitVisitNode() {
		return submitVisitNode;
	}

	public void setSubmitVisitNode(Long submitVisitNode) {
		this.submitVisitNode = submitVisitNode;
	}

	public Long getVisitUid() {
		return visitUid;
	}

	public void setVisitUid(Long visitUid) {
		this.visitUid = visitUid;
	}

	public Long getVisitCheckUid() {
		return visitCheckUid;
	}

	public void setVisitCheckUid(Long visitCheckUid) {
		this.visitCheckUid = visitCheckUid;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public String getCustomerIntegratedDescription() {
		return customerIntegratedDescription;
	}

	public void setCustomerIntegratedDescription(String customerIntegratedDescription) {
		this.customerIntegratedDescription = customerIntegratedDescription;
	}

	public Date getVisitIndustryDate() {
		return visitIndustryDate;
	}

	public void setVisitIndustryDate(Date visitIndustryDate) {
		this.visitIndustryDate = visitIndustryDate;
	}

	public String getIndustryDescription() {
		return industryDescription;
	}

	public void setIndustryDescription(String industryDescription) {
		this.industryDescription = industryDescription;
	}

	public Long getAuditUser() {
		return auditUser;
	}

	public void setAuditUser(Long auditUser) {
		this.auditUser = auditUser;
	}

	public Long getVisitReason() {
		return visitReason;
	}

	public void setVisitReason(Long visitReason) {
		this.visitReason = visitReason;
	}

	public String getIsTempSave() {
		return isTempSave;
	}

	public void setIsTempSave(String isTempSave) {
		this.isTempSave = isTempSave;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Long getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	@Override
	public String toString() {
		return "ApplyVisitMainInfoDO [id=" + id + ", applyId=" + applyId + ", visitState=" + visitState + ", visitType="
				+ visitType + ", submitVisitNode=" + submitVisitNode + ", visitUid=" + visitUid + ", visitCheckUid="
				+ visitCheckUid + ", visitDate=" + visitDate + ", customerIntegratedDescription="
				+ customerIntegratedDescription + ", visitIndustryDate=" + visitIndustryDate + ", industryDescription="
				+ industryDescription + ", auditUser=" + auditUser + ", visitReason=" + visitReason + ", isTempSave="
				+ isTempSave + ", createTime=" + createTime + ", createUser=" + createUser + ", modifyTime="
				+ modifyTime + ", modifyUser=" + modifyUser + "]";
	}


}
