package com.xyb.order.app.client.mine.model;

import org.hibernate.validator.constraints.NotEmpty;

import com.beiming.kun.framework.model.IBaseModel;

public class ApplyRecordQueryDTO implements IBaseModel{

	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "请求类型不能为空")
	private String applyRecordType;

	private Integer page;

	public String getApplyRecordType() {
		return applyRecordType;
	}

	public void setApplyRecordType(String applyRecordType) {
		this.applyRecordType = applyRecordType;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}
	
}
