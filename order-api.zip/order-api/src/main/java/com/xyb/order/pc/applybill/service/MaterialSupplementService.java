package com.xyb.order.pc.applybill.service;

import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.applybill.model.MaterialSupplementListDTO;

/**
 * 材料补充接口
 * @author         xieqingyang
 * @date           2018/4/25 11:46 AM
*/
public interface MaterialSupplementService {

    /**
     * 查询材料补充列表
     * @param pageNumber 分页信息
     * @param pageSize 分页信息
     * @param materialSupplementListDTO 查询条件
     * @return 列表展示数据
     */
    RestResponse listMaterialSupplementPage(Integer pageNumber, Integer pageSize, MaterialSupplementListDTO materialSupplementListDTO) throws Exception;

    /**
     * 查询材料补充详细信息
     * @param mainId 主表ID
     * @return 返回详细信息
     */
    RestResponse getMaterialSupplementInFo(Long mainId) throws Exception;
}
