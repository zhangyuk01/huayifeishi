package com.xyb.order.common.message.model;

import com.beiming.kun.framework.model.IBaseModel;

/**
 * @description:    发送消息时使用用户信息
 * @author:         xieqingyang
 * @createDate:     2018/6/28 下午2:54
*/
public class UserDTO implements IBaseModel {

    private static final long serialVersionUID = 6066300675136714142L;
    /**用户ID*/
    private Long id;
    /**姓名*/
    private String name;
    /**手机号*/
    private String phone;
    /**友盟唯一标识*/
    private String deviceToken;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", deviceToken='" + deviceToken + '\'' +
                '}';
    }
}
