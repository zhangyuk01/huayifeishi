package com.xyb.order.app.client.personinfo.model;

import java.util.Date;

import com.beiming.kun.framework.model.IBaseModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.NotEmpty;

public class PersonBaseRelationInfoDTO implements IBaseModel{
	private static final long serialVersionUID = 1L;
	
	private String id; //主键ID
	@JsonIgnore
	private Long applyId;
	@JsonIgnore
	private Long cusId;
	private String webchat;//微信
	private String qq;//qq
	private String phone2;//备用手机号
	private String tellArea;// -- 家庭固话区号
	private String tell;// -- 家庭固话
	@JsonIgnore
	private Date createTime;
	@JsonIgnore
	private Long createUser;
	@JsonIgnore
	private Date modifyTime;
	@JsonIgnore
	private Long modifyUser;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Long getCusId() {
		return cusId;
	}
	public void setCusId(Long cusId) {
		this.cusId = cusId;
	}
	public String getWebchat() {
		return webchat;
	}
	public void setWebchat(String webchat) {
		this.webchat = webchat;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Long getCreateUser() {
		return createUser;
	}
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(Long modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getTellArea() {
		return tellArea;
	}

	public void setTellArea(String tellArea) {
		this.tellArea = tellArea;
	}

	public String getTell() {
		return tell;
	}

	public void setTell(String tell) {
		this.tell = tell;
	}
}
