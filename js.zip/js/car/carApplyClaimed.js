function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
var basePath = getRootPath();

//列表点击流程处理控制
function isClaimed(apply_id,state){
  var flag = false;
  $.ajax({
       type : "POST",
       url : basePath+"/car/common/isClaimed.do",
       async:false,
       data : {
    	   		'applyId':apply_id,
    	   		'currentState':state
       		  },
       success : function(data) {
                	if ("true"!=data.success) {
						alert(data.message);
						return;
					}else{
						flag = true;
					}
                  },
              
        error : function() {
                  alert("加载失败");
              }
   });
  
  return flag;
}