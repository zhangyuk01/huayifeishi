function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
var basePath = getRootPath();//获取项目根路径

//开启遮罩
function showLoading(){
	$.blockUI({
		message : "<img src="+basePath+"/img/loading.gif /><h4><strong>处理中,请稍后....</strong></h4>",
		css : {
			background : 'none',
			color : '#000',
			border : 'none'
		},
		overlayCSS : {
			backgroundColor : '#C5E1F0',
			opacity : '0.6'
		}
	});
}

//关闭遮罩
function hideLoading(){
	$.unblockUI();
}
