function getValidator(){
	   var  validator = $("#carApplyBillForm").validate({
	        rules : {
	        	//借款需求
	            "carApplyBillInfo_borrowMoney":{required:true,number:true,maxlength:13},
	            "carApplyBillInfo_productName":{required:true},
	            "carApplyBillInfo_productLimit":{required:true},
	            "carApplyBillInfo_borrowDesc":{number:true},
	            //"carApplyBillInfo_borrowDescOther":{required:true,maxlength:40},
	            //个人信息
	            "clientInfo_name":{required:true,maxlength:10},
	            "clientInfo_gender":{required:true},
	            "clientInfo_birthday":{required:true},
	            "clientInfo_idcard":{required:true,minlength:18,maxlength:18,isIdCardNo:true},
	            "clientInfo_idcard2":{required:true,minlength:18,maxlength:18,equalTo:"#clientInfo_idcard",isIdCardNo:true},
	            "carApplyPersonalInfo_mobile":{required:true,minlength:11,digits:true,maxlength:12},
	            "carApplyPersonalInfo_idcardValidity":{required:true},
	            "carApplyPersonalInfo_homeTownProvince":{required:true},
	            "carApplyPersonalInfo_homeTownCity":{required:true},
	            "carApplyPersonalInfo_homeTownArea":{required:true},
	            "carApplyPersonalInfo_homeTownAddress":{required:true},
	            "carApplyPersonalInfo_temporaryResidencePermit":{required:true},
	            "carApplyPersonalInfo_nowAddressProvince":{required:true},
	            "carApplyPersonalInfo_nowAddressCity":{required:true},
	            "carApplyPersonalInfo_nowAddressArea":{required:true},
	            "carApplyPersonalInfo_nowAddress":{required:true},
	            //"carApplyPersonalInfo_nowCityPhone":{required:true,maxlength:50},
	            "carApplyPersonalInfo_beginLiveDate":{required:true},
	            "carApplyPersonalInfo_comeCityDate":{required:true},
	            "carApplyPersonalInfo_familySupportCount":{required:true,maxlength:5,number:true},
	            "carApplyPersonalInfo_maritalStatus":{required:true},
	            "carApplyPersonalInfo_childHas":{required:true},
	            "carApplyPersonalInfo_education":{required:true},
	            "carApplyPersonalInfo_creditCardQuota":{required:true,number:true},
	            "carApplyPersonalInfo_houseProperty":{required:true},
	            "carApplyPersonalInfo_rent":{number:true},
	            //"carApplyPersonalInfo_housePropertyOther":{required:true},
	            //工作信息
	            "carApplyCompInfo_compName":{required:true},
	           //"carApplyCompInfo_compDept":{required:true},
	            "carApplyCompInfo_compTellArea":{required:true,number:true},
	            "carApplyCompInfo_compTell":{required:true,number:true},
	            "carApplyCompInfo_compAddressProvince":{required:true},
	            "carApplyCompInfo_compAddressCity":{required:true},
	            "carApplyCompInfo_compAddressArea":{required:true},
	            "carApplyCompInfo_compAddress":{required:true},
	           //"carApplyCompInfo_dutyLevel":{required:true},
	           //"carApplyCompInfo_monthSalary":{required:true,number:true},
	           // "carApplyCompInfo_otherSalary":{required:true,number:true},
	           // "carApplyCompInfo_startServiceDate":{required:true}, 
	            "carApplyCompInfo_compProperty":{required:true},
	            
	            //联系人信息
	            //"carApplyLinkmanInfoSpouse_name":{required:true},
	        	//"carApplyLinkmanInfoSpouse_relation":{required:true},
	        	//"carApplyLinkmanInfoSpouse_tell":{required:true,number:true},
	        	//"carApplyLinkmanInfoSpouse_province":{required:true},
	        	//"carApplyLinkmanInfoSpouse_city":{required:true},
	        	//"carApplyLinkmanInfoSpouse_area":{required:true},
	        	//"carApplyLinkmanInfoSpouse_address":{required:true},
	        	"carApplyLinkmanInfoHome_name":{required:true},
	        	"carApplyLinkmanInfoHome_relation":{required:true},
	        	"carApplyLinkmanInfoHome_tell":{required:true,number:true},
	        	"carApplyLinkmanInfoHome_province":{required:true},
	        	"carApplyLinkmanInfoHome_city":{required:true},
	        	"carApplyLinkmanInfoHome_area":{required:true},
	        	"carApplyLinkmanInfoHome_address":{required:true},
	        	"carApplyLinkmanInfoOther_name":{required:true},
	        	"carApplyLinkmanInfoOther_compName":{required:true},
	        	"carApplyLinkmanInfoOther_tell":{required:true,number:true},
	        	"carApplyLinkmanInfoOther_province":{required:true},
	        	"carApplyLinkmanInfoOther_city":{required:true},
	        	"carApplyLinkmanInfoOther_area":{required:true},
	        	"carApplyLinkmanInfoOther_address":{required:true},
	        	//工作人员填写
	        	"carApplyBillInfo_deptId":{required:true},
	        	"carApplyBillInfo_userId":{required:true},
	        	"carApplyBillInfo_uidSale":{required:true},
	        	"carApplyBillInfo_uidService":{required:true},
	        	"carApplyBillInfo_cusSource":{required:true},
	        	//"carApplyBillInfo_cusSourceDesc":{required:true},
	        	//"carApplyBillInfo_serviceRemark":{required:true,maxlength:50}
	        	
	        },
	        messages:{
	            //借款需求
	            "carApplyBillInfo_borrowMoney":{required:"请输入借款金额",number:"借款金额必须为数字"},
	            "carApplyBillInfo_productName":{required:"请选择产品名称"},
	            "carApplyBillInfo_productLimit":{required:"请选择产品期限"},
	            "carApplyBillInfo_borrowDesc":{number:"请选择借款用途"},
	           // "carApplyBillInfo_borrowDescOther":{required:"请输入其他借款用途"},
	            //个人信息
	            "clientInfo_name":{required:"请输入姓名"},
	            "clientInfo_gender":{required:"请选择性别"},
	            "clientInfo_birthday":{required:"请选择出生日期"},
	            "clientInfo_idcard":{required:"请输入身份证号"},
	            "clientInfo_idcard2":{required:"请输入身份证号确认",equalTo:"两次输入身份证号不一致"},
	            "carApplyPersonalInfo_mobile":{required:"请输入手机号码",digits:"手机号码必须为整数"},
	            "carApplyPersonalInfo_idcardValidity":{required:"请选择证件截止日期"},
	            "carApplyPersonalInfo_homeTownProvince":{required:"请选择户籍地址省"},
	            "carApplyPersonalInfo_homeTownCity":{required:"请选择户籍地址市"},
	            "carApplyPersonalInfo_homeTownArea":{required:"请选择户籍地址区"},
	            "carApplyPersonalInfo_homeTownAddress":{required:"请输入详细户籍地址"},
	            "carApplyPersonalInfo_temporaryResidencePermit":{required:"请选择暂住证"},
	            "carApplyPersonalInfo_nowAddressProvince":{required:"请选择本市地址省"},
	            "carApplyPersonalInfo_nowAddressCity":{required:"请选择本市地址市"},
	            "carApplyPersonalInfo_nowAddressArea":{required:"请选择本市地址区"},
	            "carApplyPersonalInfo_nowAddress":{required:"请填写详细本市地址"},
	            //"carApplyPersonalInfo_nowCityPhone":{required:"请填写本市住址电话"},
	            "carApplyPersonalInfo_beginLiveDate":{required:"请选择起始居住时间"},
	            "carApplyPersonalInfo_comeCityDate":{required:"请选择初始本市年份"},
	            "carApplyPersonalInfo_familySupportCount":{required:"请填写供养亲属人数",number:"供养亲属人数必须为数字"},
	            "carApplyPersonalInfo_maritalStatus":{required:"请选择婚姻状况"},
	            "carApplyPersonalInfo_childHas":{required:"请选择子女"},
	            "carApplyPersonalInfo_education":{required:"请选择学历"},
	            "carApplyPersonalInfo_creditCardQuota":{required:"请填写信用卡最高额度",number:"信用卡最高额度必须为数字"},
	            "carApplyPersonalInfo_houseProperty":{required:"请选择房产"},
	            "carApplyPersonalInfo_rent":{number:"每月租金必须为数字"},
	           // "carApplyPersonalInfo_housePropertyOther":{required:"请填写房产其他"},
	            //工作信息
	            "carApplyCompInfo_compName":{required:"请填写单位名称"},
	            //"carApplyCompInfo_compDept":{required:"请填写所在部门"},
	            "carApplyCompInfo_compTellArea":{required:"请填写单位电话(区号)",number:"单位电话(区号)必须为数字"},
	            "carApplyCompInfo_compTell":{required:"请填写单位电话",number:"单位电话必须为数字"},
	            "carApplyCompInfo_compAddressProvince":{required:"请选择单位地址省"},
	            "carApplyCompInfo_compAddressCity":{required:"请选择单位地址市"},
	            "carApplyCompInfo_compAddressArea":{required:"请选择单位地址区"},
	            "carApplyCompInfo_compAddress":{required:"请填写详细单位地址"},
	            //"carApplyCompInfo_dutyLevel":{required:"请填写职业级别"},
	            //"carApplyCompInfo_monthSalary":{required:"请填写月基本薪金",number:"月基本薪金必须为数字"},
	            //"carApplyCompInfo_otherSalary":{required:"请填写其他收入",number:"其他收入必须为数字"},
	           // "carApplyCompInfo_startServiceDate":{required:"请选择入职时间"}, 
	            "carApplyCompInfo_compProperty":{required:"请选择单位性质"},
	            
	            //联系人信息
//	            "carApplyLinkmanInfoSpouse_name":{required:"请填写配偶姓名"},
//	        	"carApplyLinkmanInfoSpouse_relation":{required:"请选择配偶与本人关系"},
//	        	"carApplyLinkmanInfoSpouse_tell":{required:"请填写配偶联系电话",number:"配偶联系电话必须为数字"},
//	        	"carApplyLinkmanInfoSpouse_province":{required:"请选择配偶家庭地址省"},
//	        	"carApplyLinkmanInfoSpouse_city":{required:"请选择配偶家庭地址市"},
//	        	"carApplyLinkmanInfoSpouse_area":{required:"请选择配偶家庭地址区"},
//	        	"carApplyLinkmanInfoSpouse_address":{required:"请填写配偶详细家庭地址"},
	        	"carApplyLinkmanInfoHome_name":{required:"请填写直系亲属姓名"},
	        	"carApplyLinkmanInfoHome_relation":{required:"请选择直系亲属与本人关系"},
	        	"carApplyLinkmanInfoHome_tell":{required:"请填写直系亲属联系电话",number:"直系亲属联系电话必须为数字"},
	        	"carApplyLinkmanInfoHome_province":{required:"请选择直系亲属家庭地址省"},
	        	"carApplyLinkmanInfoHome_city":{required:"请选择直系亲属家庭地址市"},
	        	"carApplyLinkmanInfoHome_area":{required:"请选择直系亲属家庭地址区"},
	        	"carApplyLinkmanInfoHome_address":{required:"请填写直系亲属详细家庭地址"},
	        	"carApplyLinkmanInfoOther_name":{required:"请填写其它联系人姓名"},
	        	"carApplyLinkmanInfoOther_compName":{required:"请填写其它联系人工作单位"},
	        	"carApplyLinkmanInfoOther_tell":{required:"请填写其它联系人联系电话",number:"其它联系人联系电话必须为数字"},
	        	"carApplyLinkmanInfoOther_province":{required:"请选择其它联系人家庭地址省"},
	        	"carApplyLinkmanInfoOther_city":{required:"请选择其它联系人家庭地址市"},
	        	"carApplyLinkmanInfoOther_area":{required:"请选择其它联系人家庭地址区"},
	        	"carApplyLinkmanInfoOther_address":{required:"请填写其它联系人详细家庭地址"},
	        	//工作人员填写
	        	"carApplyBillInfo_deptId":{required:"请选择销售团队"},
	        	"carApplyBillInfo_userId":{required:"请选择团队经理"},
	        	"carApplyBillInfo_uidSale":{required:"请选择销售人员"},
	        	"carApplyBillInfo_uidService":{required:"请选择客服专员"},
	        	"carApplyBillInfo_cusSource":{required:"请选择客户来源"},
	        	//"carApplyBillInfo_cusSourceDesc":{required:"请填写其他客户来源"},
	        	//"carApplyBillInfo_serviceRemark":{required:"请填写备注"}
	        }
	    }); 
	   return validator;
}

//js获取项目根路径，如： http://localhost:8083/oms
function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
var basePath = getRootPath();//获取项目根路径

//身份证号校验
jQuery.validator.addMethod('isIdCardNo', function(value, element) {
        return this.optional(element) || isIdCardNo(value);
    },"请输入正确的身份证号码");
    
//提交 验证客户身份证存在
function checkIdcardWhenSubmit(){
  var idcard = $("#clientInfo_idcard").val();
  var flag = false;
  $.ajax({
       type : "POST",
       url : basePath+"/process/applybill/checkCustomerExist.do",
       async:false,
       data : {'idcard':idcard},
       success : function(data) {
                if(data==''||data=='null'){
                      flag = true;
                  }else{
                      var r = window.confirm("存在该客户,是否将客户信息显示到申请单？");
                      if(r==true){
                          $("#clientInfo_name").val(data.name);
                          $("#clientInfo_gender").val(data.gender);
                          $("#clientInfo_birthday").val(data.birthday);
                          $("#clientInfo_idcard").val(data.idcard);
                          $("#clientInfo_idcard2").val(data.idcard);
                          $("#clientInfo_id").val(data.id);
                          //申请单客户id 
                          $("#carApplyBillInfo_cusId").val(data.id);
                          flag = true;
                      }
                  }
              },
        error : function() {
                  alert("不存在该客户!");
              }
   });
  
  return flag;
}

//判断是否上传
function isUplodified(){
	var flag = false;
    var applyId = $("#carApplyBillInfo_id").val(); 
	  $.ajax({
	       type : "POST",
	       url : basePath+"/car/common/isUplodified.do",
	       async:false,
	       data : {
	    	   		'applyId':applyId,
	    	   		'fileCode':'CAR_APPLY'
	       		  },
	       success : function(data) {
	                	if ("NO"==data.isUplodified) {
							alert("请上传图片再提交");
							return;
						}else{
							flag = true;
						}
	                  },
	              
	        error : function() {
	                  alert("加载失败");
	              }
	   });
	  return flag;
}
//ie8支持indexOf方法
function ie8IndexOf(){
	if (!Array.prototype.indexOf)
	{
	  Array.prototype.indexOf = function(elt , from)
	  {
	    var len = this.length >>> 0;

	    var from = Number(arguments[1]) || 0;
	    from = (from < 0)
	         ? Math.ceil(from)
	         : Math.floor(from);
	    if (from < 0)
	      from += len;

	    for (; from < len; from++)
	    {
	      if (from in this &&
	          this[from] === elt)
	        return from;
	    }
	    return -1;
	  };
	}
}
//保存申请表信息(暂存)
function saveCarInfo(isTmpSave){
	
	//如果身份证号输入且不一致，不允许暂存
	var idcard1=$("#clientInfo_idcard").val();
	var idcard2=$("#clientInfo_idcard2").val();
	if((idcard1!='' && idcard1!=null)|| (idcard2!='' && idcard2!=null)){
		if(idcard1!=idcard2){
			alert("身份证号不一致，请重新输入！");
			return;
		}
	}
	$("#clientInfo_isTmpSave").val(isTmpSave);//客户基本信息表暂存标识复赋值
	$("#tmpSave").attr("disabled",true);
	$("#goNext").attr("disabled",true);
	if(isTmpSave=="Y"){
		var  params = $('#carApplyBillForm').serialize();
		$.ajax({
			type : "POST",
			url :  basePath+"/car/process/carapplybill/save.do?isTmpSave="+isTmpSave,
			data : encodeURI(params),
			success : function(data) {
				if ("OK" == data.code) {
					alert("保存数据成功!");
					$("#clientInfo_id").val(data.clientInfo.id);
	                window.location.reload();
				}else{
					 alert("保存数据失败!");
	                 $("#tmpSave").removeAttr("disabled");
					 $("#goNext").removeAttr("disabled");
				}
				
			},
			error : function() {
				alert("保存数据失败!");
	            $("#tmpSave").removeAttr("disabled");
				$("#goNext").removeAttr("disabled");
			}
		});
	}else{
		var  validator = getValidator();
		if (true == validator.form()) {
			if(isUplodified()){
			if(!confirm("确认提交吗？")){
				$("#tmpSave").removeAttr("disabled");
				$("#goNext").removeAttr("disabled");
				return;
			}
			//if(checkIdcardWhenSubmit()){
				$("#clientInfo_isTmpSave").val('N');
				var  params = $('#carApplyBillForm').serialize();
				showLoading();
				$.ajax({
					type : "POST",
					url :  basePath+"/car/process/carapplybill/save.do?isTmpSave="+isTmpSave,
					data : encodeURI(params),
					success : function(data) {
						if ("OK" == data.code) {
							hideLoading();
							$("#clientInfo_id").val(data.clientInfo.id);
							
							// 提示规则展示
							var map = data.returnMap;
							var keys = new Array();
							$.each(map, function(key, value) {
								keys.push(key);
							});

							ie8IndexOf();// 解决ie8不支持indexOf

							// 禁止进件
							if (keys.indexOf('JD')!=-1) {
								var denyInfo = "";
								$.each(map, function(key, value) {
									for (var i = 0; i < value.length; i++) {
										if (key == 'JD') {
											denyInfo += (i+1) + "、" + value[i]
													+ "<br/>";
										}
									}
								});
								$("#carApplyBillForm").css("display", "none");
								$("#ruleArea").css("display", "");
								$("#ruleShowArea").css("display","");
		                		$("#showRuleInfo").html("该申请单违反进件规则，已拒件<br/>"+denyInfo);
		                		$("input[name='goBackList']").css("display","");
		                		return;
							}
							
							// 审核提示信息
							if ((keys.indexOf('SQSHTS')!=-1)
									|| (keys.indexOf('CLSHTS')!=-1)|| (keys.indexOf('LJ')!=-1)) {
								var applyInfo = "";
								var carAuditInfo = "";
								var carLJInfo="";
								if (keys.indexOf('SQSHTS')!=-1) {
									applyInfo += "申请审核提示规则：<br/>";
								}
								if (keys.indexOf('CLSHTS')!=-1) {
									carAuditInfo += "车辆审核提示规则：<br/>";
								}
								if (keys.indexOf('LJ')!=-1) {
									carLJInfo += "车贷拦截提示规则：<br/>";
								}
								
								$.each(map, function(key, value) {
									for (var i = 0; i < value.length; i++) {
										if (key == 'SQSHTS') {
											applyInfo += (i+1) + "、" + value[i]
													+ "<br/>";
										} 
										if (key == 'CLSHTS') {
											carAuditInfo += (i+1) + "、" + value[i]
													+ "<br/>";
										}
										if (key == 'LJ') {
											carLJInfo += (i+1) + "、" + value[i]
													+ "<br/>";
										}
									}
								});
								$("#carApplyBillForm").css("display","none");
								$("#ruleArea").css("display", "");
								$("#ruleTitle").css("display", "");
								$("#ruleShowArea").css("display", "");
								$("#showRuleInfo").html(applyInfo+carAuditInfo+carLJInfo);
								$("input[name='confirmSubmit']").css("display", "");
								if (keys.indexOf('LJ')!=-1) {
									$("input[name='confirmSubmit']").css("display", "none");
								}
								$("input[name='backToApply']").css("display", "");
								
								$("#applyId").val(data.applyId);
								$("#consultId").val(data.consultId);
								$("#idCard").val(data.clientInfo.idcard);
								$("#isCheatRefused").val(data.isCheatRefused);
								
								return;
							}
							
							alert("提交成功!");
			                window.location = basePath+"/car/process/carapplybill/query.do";
						}else{
							 alert("提交失败!");
							 hideLoading();
							 $("#tmpSave").removeAttr("disabled");
							 $("#goNext").removeAttr("disabled");
						}
					},
					error : function() {
						alert("提交失败!");
						hideLoading();
						$("#tmpSave").removeAttr("disabled");
						$("#goNext").removeAttr("disabled");
					}
				});
			//}
			}else {
				$("#tmpSave").removeAttr("disabled");
				$("#goNext").removeAttr("disabled");
			}
		}else{
			$("#tmpSave").removeAttr("disabled");
			$("#goNext").removeAttr("disabled");
		
		}
	}

}

//违反进件规则拒件后返回列表
function backList(){
	 window.location = basePath+"/car/process/carapplybill/query.do";
}

//确认提交
function confirmSubmit(){
	if(!confirm("您确认提交吗?")){
		return;
	}
	$("#confirmSubmit").attr("disabled", true);
	var applyId = $("#applyId").val();
	var isCheatRefused = $("#isCheatRefused").val();
	$.ajax({
        type : "POST",
        url : basePath + "/car/process/carapplybill/confirmSubmit.do",
        data : {'applyId':applyId,'isCheatRefused':isCheatRefused},
        success : function(data) {
			alert(data.message);
        	if ("true" == data.success) {
        		window.location = basePath+"/car/process/carapplybill/query.do";
			} else {
				 $("#confirmSubmit").removeAttr("disabled");
			}
        },
        error : function() {
            alert("保存数据失败!");
            $("#confirmSubmit").removeAttr("disabled");
        }
	});
}

//返回申请
function backToApply(){
	var applyId = $("#applyId").val();
	var consultId = $("#consultId").val();
	var idCard = $("#idCard").val();
	window.location = basePath+"/car/process/carapplybill/update.do?applyId="
			+ applyId + '&consultId=' + consultId + "&idCard=" + idCard;
}

//获取销售团队下拉列表信息
function getSaleTeamByAreaID(){
	var areaId=$("#carApplyBillInfo_areaId").val();//管辖机构ID
	var deptId=$("#deptId").val();//团队ID（回显）
	$.getJSON(basePath+"/sys/org/getSaleTeamByPID.do",{orgId:areaId},function(data){
  	  var temp;
        temp = "<option value=''>--请选择--</option>";
        $("#carApplyBillInfo_deptId").html(temp);
         if(data){
          	 var num = data.length;
               for(var i=0;i<num;i++){
                     if(data[i].orgId==deptId){
                          temp += "<option value='"+ data[i].orgId+"' selected='selected' >"+data[i].orgName+"</option>";
                      }else{
                          temp += "<option value=" + data[i].orgId+ ">" + data[i].orgName + "</option>"; 
                      }
                     $("#carApplyBillInfo_deptId").html(temp);
               }
           }
       });
}
//获取团队经理下拉列表内容
function getTeamManager(deptId,userId,isUpdate){
    $.getJSON(basePath+"/sys/user/getUserByOrgAndRole.do",{orgId:deptId,roleName:'车贷-团队经理'},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#carApplyBillInfo_userId").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].loginId == userId){
                 temp += "<option value='"+ data[i].loginId+"' selected='selected' >"+data[i].name+"</option>";
              }else{
                 temp += "<option value=" + data[i].loginId+ ">" + data[i].name + "</option>"; 
              }
               
          	  $("#carApplyBillInfo_userId").html(temp);
           }
       });
    if(!isUpdate){
    	getSalesUserByOrg(deptId,'');
    }
}
//获取销售人员下拉列表内容
function getSalesUserByOrg(orgId,value){
    $.getJSON(basePath+"/process/saleuser/getSalesUserByOrg.do?random="+Math.random(),{orgId:orgId},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#carApplyBillInfo_uidSale").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].id==value){
          		 temp += "<option value='"+ data[i].id+"' selected='selected' >"+data[i].name+"</option>";
             }else{
                 temp += "<option value=" + data[i].id+ ">" + data[i].name + "</option>"; 
             }
            $("#carApplyBillInfo_uidSale").html(temp);
           }
       });
}

function openLoading(){
    $('#loading').window('open');
    $("#loading").attr("class","");
    $("div[class='panel window']").css("position","absolute");
    $("div[class='panel window']").attr("class","");
    $("div[class='window-shadow']").attr("class","");
}

$(function(){

	getSaleTeamByAreaID();//获取销售团队
	getTeamManager($("#deptId").val(),$("#userId").val(),true);//获取团队经理
	getSalesUserByOrg($("#deptId").val(),$("#uidSale").val());//获取销售人员
	//户籍地址回显
	getCommenCity("carApplyPersonalInfo_homeTownCity",$("#hidden_personalInfo_homeTownProvince").val(),$("#hidden_personalInfo_homeTownCity").val(),'carApplyPersonalInfo_homeTownArea',false);
    getCountryByCity("carApplyPersonalInfo_homeTownArea",$("#hidden_personalInfo_homeTownCity").val(),$("#hidden_personalInfo_homeTownArea").val());
    //本市地址回显
    getCommenCity("carApplyPersonalInfo_nowAddressCity",$("#hidden_personalInfo_nowProvince").val(),$("#hidden_personalInfo_nowCity").val(),'hidden_personalInfo_nowArea',false);
    getCountryByCity("carApplyPersonalInfo_nowAddressArea",$("#hidden_personalInfo_nowCity").val(),$("#hidden_personalInfo_nowArea").val());
    //单位地址回显 
    getCommenCity("carApplyCompInfo_compAddressCity",$("#hidden_carApplyCompInfo_Province").val(),$("#hidden_carApplyCompInfo_City").val(),'carApplyCompInfo_compAddressArea',false);
    getCountryByCity("carApplyCompInfo_compAddressArea",$("#hidden_carApplyCompInfo_City").val(),$("#hidden_carApplyCompInfo_Area").val());
    //联系人--配偶家庭地址回显
    getCommenCity("carApplyLinkmanInfoSpouse_city",$("#hidden_carApplyLinkmanInfoSpouse_Province").val(),$("#hidden_carApplyLinkmanInfoSpouse_City").val(),'carApplyLinkmanInfoSpouse_area',false);
    getCountryByCity("carApplyLinkmanInfoSpouse_area",$("#hidden_carApplyLinkmanInfoSpouse_City").val(),$("#hidden_carApplyLinkmanInfoSpouse_Area").val());
    //联系人--直系亲属家庭地址回显
    getCommenCity("carApplyLinkmanInfoHome_city",$("#hidden_carApplyLinkmanInfoHome_Province").val(),$("#hidden_carApplyLinkmanInfoHome_City").val(),'carApplyLinkmanInfoHome_area',false);
    getCountryByCity("carApplyLinkmanInfoHome_area",$("#hidden_carApplyLinkmanInfoHome_City").val(),$("#hidden_carApplyLinkmanInfoHome_Area").val());
    //联系人--其他 家庭地址回显
    getCommenCity("carApplyLinkmanInfoOther_city",$("#hidden_carApplyLinkmanInfoOther_Province").val(),$("#hidden_carApplyLinkmanInfoOther_City").val(),'carApplyLinkmanInfoOther_area',false);
    getCountryByCity("carApplyLinkmanInfoOther_area",$("#hidden_carApplyLinkmanInfoOther_City").val(),$("#hidden_carApplyLinkmanInfoOther_Area").val());
    
});
