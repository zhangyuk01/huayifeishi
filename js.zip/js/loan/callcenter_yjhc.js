	//签入
	function login(){
		window.parent.login();
	} 
	//签出
 	 function loginOut(){
 	 	window.parent.callLongOut();
 	 	$("#unbusy").attr('disabled',true);
 	 	$("#busy127").attr('disabled',true);
 	 	$("#busy126").attr('disabled',true);
 	 	$("#busy128").attr('disabled',true);
 	 	$("#callinner").attr('disabled',true);
 	 	$("#callouter").attr('disabled',true);
 	 	$("#hold").attr('disabled',true);
 	 	$("#hangup").attr('disabled',true);
 	 	$("#loginOut").attr('disabled',true);
 	 	$("#inner").hide();
 	 	$("#outer").hide();
 	 }
 	 //置忙 
 	 function busy(){
 		window.parent.busy();
 		$("#busy127").attr('disabled',true);
 		$("#busy126").attr('disabled',true);
 	 	$("#busy128").attr('disabled',true);
 	 	$("#unbusy").attr('disabled',false);
 	 }
 	 //置闲
 	 function unbusy(){
 	 	window.parent.unbusy();
 	 	$("#unbusy").attr('disabled',true);
 	 	$("#busy127").attr('disabled',false);
 		$("#busy126").attr('disabled',false);
 	 	$("#busy128").attr('disabled',false);
 	 }
 	 //挂断
 	 function hangup(){
 	 	window.parent.hangup();
 	 	$("#hangup").attr('disabled',true);
 	 }
	 //保持
	 function hold(){
		 window.parent.hold();
		 $('#hold').hide();
		 $('#restore').show();
	 }	 
 	 //恢复
	 function restore(){
		 window.parent.restore();
		 $('#restore').hide();
		 $('#hold').show();
	 }	 
 	 //内呼
 	 function callinner(){
 	 	$("#outer").hide();
 	 	$("#inner").show();
	 	$.ajax({
			url: "https://manage3s.icsoc.net/v2/wintelapi/api/agent/free",
			data: {vcc_code: 1015090801},
			dataType: 'jsonp',
			timeout: 5000,
			async: false,
			jsonp: 'jsonpcallback',
			success: function (response) {
				var resCode = response.code || '';
				if (resCode == 200) {
					var resData = response.data || {};
					if(resData.length>1){
						$("#innerNumber").empty();
						$.each(resData, function (index, value) {
							if (value.ag_num != window.parent.wincall.loginInfo.agentNum) {
								$("#innerNumber").append("<option value='"+value.ag_id+"'>"+value.ag_num+"</option>");
							}
						});
					}
				} else {
					window.parent.wincall.log(response);
				}
			}
		}); 	 	
 	 }
 	 //外呼
 	 function callouter(){
 	 	$("#inner").hide();
 	 	$("#outer").show();
 	 }
 	 //内呼呼叫
 	 function callIn(){
 	 	window.parent.hjnx($("#innerNumber").val());
 	 }
 	 //外呼呼叫
 	 function callOut(){
 	 	window.parent.yjhc($("#outerNumber").val().replace("-","").replace(/ /g,""));
 	 }
 	 //挂断按钮可用
 	 function hangupAble(){
 	 	$("#hangup").attr('disabled',false);
 	 }
 	 //挂断按钮不可用
 	 function hangupDisable(){
 	 	$("#hangup").attr('disabled',true);
 	 }
 	 //保持按钮可用
 	 function holdAble(){
 	 	$("#hold").attr('disabled',false);
 	 }
 	 //保持按钮不可用
 	 function holdDisable(){
 	 	$("#hold").attr('disabled',true);
 	 }
 	 //签入成功
 	 function loginSuccess(){
 	 	$("#tools").show();
 	 }
 	 //
 	 function showCallMsg(msg){
		$("#callInfo").html(msg);
	 }
	 //内呼按钮不可用
 	 function callinnerDisable(){
 	 	$("#callinner").attr('disabled',true);
 	 }
	 //暂时离开按钮不可用
 	 function busy126Disable(){
 	 	$("#busy126").attr('disabled',true);
 	 }
	 //小休按钮不可用
 	 function busy127Disable(){
 	 	$("#busy127").attr('disabled',true);
 	 }
	 //事后处理按钮不可用
 	 function busy128Disable(){
 	 	$("#busy128").attr('disabled',true);
 	 }
	 //外呼按钮不可用
 	 function callouterDisable(){
 	 	$("#callouter").attr('disabled',true);
 	 }
 	 //签入按钮不可用
 	 function loginDisable(){
 		 $("#login").attr('disabled',true);
 	 }
 	 //签入按钮可用
 	 function loginAble(){
 		 $("#login").attr('disabled',false);
 	 }
 	 //签出按钮可用
 	 function loginOutAble(){
 		 $("#loginOut").attr('disabled',false);
 	 }
	 //内呼按钮可用
 	 function callinnerAble(){
 	 	$("#callinner").attr('disabled',false);
 	 }
	 //暂时离开按钮可用
 	 function busy126Able(){
 	 	$("#busy126").attr('disabled',false);
 	 }
	 //小休按钮可用
 	 function busy127Able(){
 	 	$("#busy127").attr('disabled',false);
 	 }
	 //事后处理按钮可用
 	 function busy128Able(){
 	 	$("#busy128").attr('disabled',false);
 	 }
	 //外呼按钮可用
 	 function callouterAble(){
 	 	$("#callouter").attr('disabled',false);
 	 } 
 	 //保持按钮出现,恢复按钮消失
 	 function holdshow(){
 		 $('#restore').hide();
		 $('#hold').show();
 	 } 	
 	function showPhoneAddress(phone,address){
		$.messager.lays(300, 200);
		$.messager.show('来电提醒', phone+" "+address, 0);
	}		
	function showInnerCaller(phone){
		$.messager.lays(300, 200);
		$.messager.show('来电提醒', phone, 0);
	}
