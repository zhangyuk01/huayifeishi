$(function(){
	//当前的分数
	var curNum = $("#creditScore").val(); 
	//显示当前分数
	$(".percentNum").text(curNum);
	
	//获得一个彩虹条的宽度
	var oWidth = $(".lv01").width();
	
	if(curNum <= 350){
		
		//改变指针显示的位置
		$(".percentNum").css("left", "0");
		
	}else if(curNum > 350 && curNum <= 497){ //LV10
		
		//指针移动距离
		var numPosition =(curNum - 350) / 147 * oWidth;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 497 && curNum <= 514){ //LV09
		
		//指针移动距离
		var numPosition = (curNum - 497) / 17 * oWidth + oWidth;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 514 && curNum <= 529){ //LV08
		
		//指针移动距离
		var numPosition = (curNum - 514) / 15 * oWidth + oWidth * 2;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 529 && curNum <= 542){ //LV07
		
		//指针移动距离
		var numPosition = (curNum - 529) / 13 * oWidth + oWidth * 3;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 542 && curNum <= 555){ //LV06
		
		//指针移动距离
		var numPosition = (curNum - 542) / 13 * oWidth + oWidth * 4;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 555 && curNum <= 568){ //LV05
		
		//指针移动距离
		var numPosition = (curNum - 555) / 13 * oWidth + oWidth * 5;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 568 && curNum <= 582){ //LV04
		
		//指针移动距离
		var numPosition = (curNum - 568) / 14 * oWidth + oWidth * 6;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 582 && curNum <= 597){ //LV03
		
		//指针移动距离
		var numPosition = (curNum - 582) / 15 * oWidth + oWidth * 7;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 597 && curNum <= 617){ //LV02
		
		//指针移动距离
		var numPosition = (curNum - 597) / 20 * oWidth + oWidth * 8;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 617 && curNum <= 901){ //LV01
		console.log($(".lv01").clientWidth);
		//指针移动距离
		var numPosition = (curNum - 617) / 280 * oWidth + oWidth * 9;
		
		//改变指针显示的位置
		$(".percentNum").css("left", numPosition);
		
	}else if(curNum > 901){
		
		//改变指针显示的位置
		$(".percentNum").css("left", "99.9%");
		
	}
	
	
})