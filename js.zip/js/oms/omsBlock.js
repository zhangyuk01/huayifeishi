//开启遮罩
function showLoading(){
	$.blockUI({
		message : "<img src='../../img/loading.gif' /><h4><strong>操作中,请稍后....</strong></h4>",
		css : {
			background : 'none',
			color : '#000',
			border : 'none'
		},
		overlayCSS : {
			backgroundColor : '#C5E1F0',
			opacity : '0.6'
		}
	});
}

//关闭遮罩
function hideLoading(){
	$.unblockUI();
}
