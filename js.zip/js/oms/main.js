// JavaScript Document

/*  弹出页面上层  */
function tanchu(n){
$(function() {

		$("#tan_content"+n).fadeIn();
		$("body").append("<div class='graybg'></div>");
		var b_width,d_width,b_height;
		b_width = $(window).width();
		w_height = $(window).height();
		b_height = $("html").height();
		d_width = $("#tan_content"+n).width();
		$(".graybg").css("height",w_height);
		$("#tan_content"+n).css("left",b_width/2-d_width/2);
		$(window).resize(function(){
			b_width = $(window).width();
			$("#tan_content"+n).css("left",b_width/2-d_width/2);
		});	
	$(".closeLabel").click(function(){
		$("#tan_content"+n).hide();
		$(".graybg").remove();
		return false;
	});
});
}
