/**
 * 放大输入框内字符
 * @author  create by zhangkl at 2014-06-06
 * 事实监听input输入框内容改变并将input框的值赋值到另外一个id内
 * 绑定id为testID 的input框：
 *    $('#testID').zoomListen(
		 {
			 targetHtml_ID:"test123"//需要html到的模块ID
		});
 * targetHtml_ID : 绑定的输入框输入的内容复制到的模块ID
 * html_before_str : 
 * html_after_str : 
 **/
(function($){
	$.fn.zoomListen = function(options){
	var defaults ={
			targetHtml_ID:"ID",
			tip_str_mod:"",//ie下input框内默认提示需要进行判断否则会把默认提示放大 
			html_before_str:"",
			html_after_str:"",
			format_flag:false,
 			value :0
		};
	var options = $.extend(defaults,options);
	var bind_view_id = this.get(0).id;
	var _offset = $(this).offset();
	var objh = $(this).height()+6;
	var objw = $(this).width()*1.5;
	
	 
	   if($.browser.msie) { 
			this.get(0).attachEvent("onpropertychange",function (o){
				
				  
				var otval = $.trim(o.srcElement.value);
				if(otval==options.tip_str_mod){
					otval="";
				}
				var otvalLen = otval.length;
	 		     if(options.format_flag && otvalLen>0){
	 		    	otval = _format(otval);
	 		     }

	 		    var obj = o.srcElement;
	        	var _offset = $(obj).offset();
	        	var X =  _offset.left;
	 			var Y =  _offset.top;

				if(options.targetHtml_ID!='ID')document.getElementById( options.targetHtml_ID).innerHTML =options.html_before_str +otval+options.html_after_str;
 				
				 _setupView(otval,bind_view_id);
	 			   
				 if(otvalLen<1){
					 $("#appendDiv"+bind_view_id).hide();
					 
				 }else{
					 _setupView(otval,bind_view_id);
					 $("#appendDiv"+bind_view_id).show();
				 }
				 
				 $("#"+bind_view_id)
				 //.attr('autocomplete', 'off') // disable IE's autocomplete feature
				 .blur( this._blur = function(){
			            $(document).one('click', function(){
			            	$("#appendDiv"+bind_view_id).hide();
			            });
			        })
			        .on('click', function(){
			        	var obj = o.srcElement;
			        	var _offset = $(obj).offset();
			        	var X =  _offset.left;
			 			var Y =  _offset.top;
			        	$("#appendDiv"+bind_view_id).css({"width":objw,"left":X  ,  "top":Y+objh  });
			        	if(otvalLen>0){
			        		_setupView(otval,bind_view_id);
			        		 $("#appendDiv"+bind_view_id).show();
			        	 }else{
			        		 $("#appendDiv"+bind_view_id).html("");
			        		 $("#appendDiv"+bind_view_id).hide();
			        	 }
			        	
			        	 
			        });
				 
				 $("#appendDiv"+bind_view_id).css({"width":objw,"left":X  ,  "top":Y+objh  });
              }); 
			return this;
		}else{ 
			
 		    this.get(0).addEventListener("input",function(o){
 		     var otval = $.trim(o.target.value);
 		     if(options.format_flag && otval.length>0){
 		    	otval = _format(otval);
 		     }
			 var X = $(this).offset().left;
			 var Y = $(this).offset().top;
 		    if(options.targetHtml_ID!='ID')document.getElementById( options.targetHtml_ID).innerHTML =options.html_before_str +otval+options.html_after_str;
			
			 _setupView(otval,bind_view_id);
			 
			 if(otval.length<1){
				 $("#appendDiv"+bind_view_id).hide();
			 }else{
				 _setupView(otval,bind_view_id);
				 $("#appendDiv"+bind_view_id).show();
			 }
			 $(this)
			 .attr('autocomplete', 'off') // disable IE's autocomplete feature
			 .blur(this._blur = function(){
		            $(document).one('click', function(){
		            	$("#appendDiv"+bind_view_id).hide();
		            });
		        })
		        .on('click', function(){
		        	var otval = $.trim(o.target.value);
		 		     if(options.format_flag && otval.length>0){
		 		    	otval = _format(otval);
		 		     }
					 var X = $(this).offset().left;
					 var Y = $(this).offset().top;
		        	
		        	$("#appendDiv"+bind_view_id).css({"width":objw,"left":X  ,  "top":Y+objh  });
		        	 if(otval.length>0){
		        		 _setupView(otval,bind_view_id);
			        	 $("#appendDiv"+bind_view_id).show();
			        	 }else{
			        		 $("#appendDiv"+bind_view_id).html("");
			        		 $("#appendDiv"+bind_view_id).hide();
			        	 }
		        });
			 
			 $("#appendDiv"+bind_view_id).css({"width":objw,"left":X  ,  "top":Y+objh  });
		    },false);
 		    return this;
	 }
	
	   
	};
	//格式化输入的电话号码 加“-” 变为3-4-4格式
	var _format = function(t) {
		var r = [];
		var tz = t.split("");
		var i = function(e, t, i) {
			var n = [];
			var c = e.length;
			i = i ? t + i: c;
			i = Math.min(i, c);
			for (var a = t; a < i; a++) {
				n.push(e[a])
			}
			if (n.length) {
				r.push(n.join(""))
			}
		};

		i(tz, 0, 3);
		i(tz, 3, 3);
		i(tz, 6, 4);
		i(tz, 10, 4);
		i(tz, 14, 4);
		//i(tz, 7);
		 
		return r.join(" ");
	};
	 
	var _setupView = function(t,bind_view_id){
        var that = this;
        var viewHtm = "<div id='appendDiv"+bind_view_id+"' style='position: absolute;z-index: 1;height:26px;background: none repeat scroll 0 0 #FFFFFF;border: 1px solid #AFAFAF;text-align: left;line-height: 24px;color:#fb7403;font-size:20px;font-weight: bold;font-family:'微软雅黑','黑体';'>"+t+"</div>";
        if($("#appendDiv"+bind_view_id).html()!=undefined){
        	$("#appendDiv"+bind_view_id).html(t);
        }else{
        	$("body").prepend(viewHtm);
        }
    };
	
})(jQuery);