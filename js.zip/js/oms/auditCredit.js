//------------实地征信------------------------

//js获取项目根路径，如： http://localhost:8083/oms
function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
var basePath = getRootPath();//获取项目根路径


//表单提交方法
function submit(button) {
    if (button == "N") {//判断所点击的按钮是不是暂存
    	$("#state").val("");//如果是，把表单的状态更改为请选择
    }
    $(".formSata").val($("#processState").val());//把按钮上绑定的状态赋值给表单隐藏域的formSata（因为按钮不在表单里，这是为了实现动态加载页面内容）
    //如果点击的是提交按钮，而没有选择下一步操作的步骤，提示用户选择
    if (button == "Y" &&  $("#state").val() == '' ) {
        alert("请选择提交操作处理结果");
        return false;
    }
    // 验证插件初始化配置征信表单
    var validator = $("#auditCreditForm").validate({
        rules : {
            credit_spotCreditDate : {required : true}
        },
        messages : {
            credit_spotCreditDate : {required : "请选择征信实地时间"}
        }
    });

    // 验证插件初始化配置产调表单
    var validator1 = $("#auditReportForm").validate({
        rules : {
            visithouse_transferTime : {required : true},
            visithouse_transferCom : {required : true},
            visithouse_transferMan : {required : true}
        },
        messages : {
            visithouse_transferTime : {required : "请输入产调时间"},
            visithouse_transferCom : {required : "请输入产调部门"},
            visithouse_transferMan : {required : "请输入外访人员"}
        }
    });
    /* ===表单验证信息初始化结束=== */
    if (button == "Y" && $("#state").val() == 'BPHDCJD') {
        var r = window.confirm("您确认客户不配合调查拒贷吗？");
        if (r == false) {
            return false;
        }
    }
    //form插件序列化表单
    var auditCreditFormParams = $("#auditCreditForm").serialize();//征信
    var auditReportFormParams = $("#auditReportForm").serialize();//产调
    var params = auditCreditFormParams + '&' + auditReportFormParams;
    //如果是产调操作，判断插件验证产调表单是否返回ture，如果是执行提交方法
    if ($("#processState").val() == 'G09' && true == validator1.form()) {
         doSubmit (button);
    }
    // 如果是产调操作，判断插件验证征信表单是否返回ture，如果是执行提交方法
    if ($("#processState").val() == 'G08' && true == validator.form()) {
         doSubmit (button);
    }
    // 如果是外访操作，判断插件验证征信表单是否返回ture，如果是执行提交方法
    if ($("#processState").val() == 'C05' && true == validator.form() && true == validator1.form()) {
    	doSubmit (button);
    }
    // 如果是外访操作，判断插件验证征信表单是否返回ture，如果是执行提交方法
    if ($("#processState").val() == 'C07' && true == validator.form() && true == validator1.form()) {
    	doSubmit (button);
    }
    //如果是征信和产调，判断插件验证征信和产调表单是否返回ture，如果是执行提交方法
    if ($("#processState").val() == 'G07' && true == validator.form()
            && true == validator1.form()) {     
        doSubmit (button);
    }
   //表单提方法
    function doSubmit(button) {
    	var state = $("#state").val();
    	var radioState = $("input:radio[name='state']:checked").val();
    	var isSign = $("#isSign").val();
    	if(isSign == "" && radioState == undefined){
    		alert('请选择处理结果!');
    		return;
    	}
    	//有条件签约 处理结果
    	if(radioState == 'YTJQYPD' || radioState == 'YTJQYJD' || radioState == 'YTJQYTJ'){  
    		state = radioState;
    	}else{
    		if(state == ''){
    			alert('请选择处理结果!');
    			return;
    		}
    	}
        if(button=='Y'){
        	if(!confirm("确认提交吗？")){
            	return;
            }
        }
    	$(".button2").attr("disabled", true);
        $.ajax({
            type : "POST",
            url : basePath+'/process/creditreport/save.do',
            data : encodeURI(params+"&isSubmit="+button+"&submitResult="+state+"&formSata="+$("#processState").val() + "&applyId=" + $("#applyId").val() + "&refuseCode=" + $("#JDCode").val()),
            success : function(data) {
                if ($("#processState").val() == 'G07' || $("#processState").val() == 'G08' || $("#processState").val() == 'C07' || $("#processState").val() == 'C05'){
                    $("#creditId").val(data.creditId);
                    $("#client_id").val(data.clientId);
                    $("#family_id").val(data.familyId);
                    $("#manage_id").val(data.manageId);
                    $("#comp_id").val(data.compId);
                }
                if ($("#processState").val() == 'G07' || $("#processState").val() == 'G09' || $("#processState").val() == 'C07' || $("#processState").val() == 'C05'){
                    $("#houseId").val(data.houseId);
                }
                if (data.success == 'false') {
                    alert("操作失败");
                    $(".button2").removeAttr("disabled");
                }else{
                    alert("操作成功");
                     if(button=='N'){
                    	 $(".button2").removeAttr("disabled");
                     }
                    if (data.success == 'true') {
                        psuccess();
                    }
                }
            },
            error : function(data) {
                alert("操作失败");
                $(".button2").removeAttr("disabled");
            }
        });
     }
}
 	

$(function(){
	//================================================页面初始化=========================================
	var client_borrowReason= $("input[name='client_borrowReason']:checked").val();//借款原因初始化
	if(client_borrowReason==undefined){
		$(".jkyy_1").hide(); 
	    $(".jkyy_2").hide(); 
	}else if(client_borrowReason=='1'){
		$(".jkyy_1").show(); 
	    $(".jkyy_2").hide();  
	}else{
		$(".jkyy_2").show(); 
	   $(".jkyy_1").hide();
	}
	
	var client_isOtherCompBorrow= $("input[name='client_isOtherCompBorrow']:checked").val();//是否有在其它小贷公司借款初始化
	if(client_isOtherCompBorrow==undefined  || client_isOtherCompBorrow=='N' ){
		$(".jkgs_ct").hide();
		//button1 fl 
		$("#addBorrowComp").hide();
	}else{
		$(".jkgs_ct").show(); 
		$("#addBorrowComp").show();
	}
	
	var comp_jobLevel= $("input[name='comp_jobLevel']:checked").val();//职业级别初始化
	if(comp_jobLevel==undefined ){
		$(".jg_ct").hide();
		$(".qt_ct").hide(); 
	}else if(comp_jobLevel=='1'){
		$(".jg_ct").show(); 
		$(".qt_ct").hide(); 
	}else{
		$(".qt_ct").show(); 
		$(".jg_ct").hide();
	}
	
	//==========================市区回显==================================
	
	//家庭地址
	getCommenCity("family_addressCity",$("#hidden_family_addressProvince").val(),$("#hidden_family_addressCity").val(),'family_addressArea',false);
    getCountryByCity("family_addressArea",$("#hidden_family_addressCity").val(),$("#hidden_family_addressArea").val());
    //公司地址
	getCommenCity("credit_compAddrCity1",$("#hidden_manageAddress_compAddrProvince1").val(),$("#hidden_manageAddress_compAddrCity1").val(),'credit_compAddrArea1',false);
	getCountryByCity("credit_compAddrArea1",$("#hidden_manageAddress_compAddrCity1").val(),$("#hidden_manageAddress_compAddrArea1").val());
	getCommenCity("credit_compAddrCity2",$("#hidden_manageAddress_compAddrProvince2").val(),$("#hidden_manageAddress_compAddrCity2").val(),'credit_compAddrArea2',false);
	getCountryByCity("credit_compAddrArea2",$("#hidden_manageAddress_compAddrCity2").val(),$("#hidden_manageAddress_compAddrArea2").val());
	getCommenCity("credit_compAddrCity3",$("#hidden_manageAddress_compAddrProvince3").val(),$("#hidden_manageAddress_compAddrCity3").val(),'credit_compAddrArea3',false);
	getCountryByCity("credit_compAddrArea3",$("#hidden_manageAddress_compAddrCity3").val(),$("#hidden_manageAddress_compAddrArea3").val());
	//单位地址
	getCommenCity("comp_addrCity",$("#hidden_comp_addrProvince").val(),$("#hidden_comp_addrCity").val(),'comp_addrArea',false);
	getCountryByCity("comp_addrArea",$("#hidden_comp_addrCity").val(),$("#hidden_comp_addrArea").val());
	
	//=================页面切换控制======================================================
	$("input[name='client_borrowReason']").change(function(){//借款原因切换
		if ($(this).val()=='1'){
	   		$(".jkyy_1").show(); 
	    	$(".jkyy_2").hide();              
	 	}else{
		 	$(".jkyy_2").show(); 
	    	$(".jkyy_1").hide();
		 }
	});

	$("input[name='client_isOtherCompBorrow']").change(function(){//是否有在其它小贷公司借款
		if ($(this).val()=='Y'){
	   		$(".jkgs_ct").show();   
	   		$("#addBorrowComp").show();   
	 	}else{
	    	$(".jkgs_ct").hide();
	    	$("#addBorrowComp").hide();
		}
	});

	$("input[name='comp_jobLevel']").change(function(){//职业级别
		if ($(this).val()=='1'){
			$(".jg_ct").show(); 
			$(".qt_ct").hide();  
		}else{
			$(".qt_ct").show(); 
			$(".jg_ct").hide();
		}
	}); 
	
	
	//======================================动态添加及删除===========================
	
	//借款公司 add
	$(".add_jkgs").click(function(){
		var size=$(".jkgs_ct tr:visible").length;
		if(size==0){
			$(".jkgs_ct").find("#jkClone").after($("#jkClone").html());
			$(".jkgs_ct").find("tr:last").find("input[name='credit_otherBorrowDel']").val("N");//新增删除标志置为“N”
			
		}else{
			$(".jkgs_ct").find("tr:last").after($("#jkClone").html());
			$(".jkgs_ct").find("tr:last").find("input[name='credit_otherBorrowDel']").val("N");//新增删除标志置为“N”
		}
		
	}); 
	//借款公司 delete
	$("input[name='jkDeleteButton']").live('click', function(){
		var size=$(".jkgs_ct tr:visible").length;
		if(size==2){
			alert("最少保留一条借款公司信息！");
			return;		
		}
		$(this).closest("tr").hide().find("input[name='credit_otherBorrowDel']").val("Y");
        $(this).closest("tr").prev("tr").hide();
	});
	//家庭概况 add
	$(".add_familycy").click(function(){
		var size=$(".family_ct tr:visible").length;
		if(size==0){
			$(".family_ct").find("#familyDetailClone").after($("#familyDetailClone").html());
			$(".family_ct").find("tr:last").find("input[name='credit_familyDetailDel']").val("N");//新增删除标志置为“N”
			
		}else{
			$(".family_ct").find("tr:last").after($("#familyDetailClone").html());
			$(".family_ct").find("tr:last").find("input[name='credit_familyDetailDel']").val("N");//新增删除标志置为“N”
		}
	}); 
	//家庭概况 delete
	$(".del_jkgs").live('click', function(){
		var size=$(".family_ct tr:visible").length;
		if(size==2){
			alert("最少保留一条家庭概况信息！");
			return;		
		}
		$(this).closest("tr").hide().find("input[name='credit_familyDetailDel']").val("Y");
        $(this).closest("tr").prev("tr").hide();
	});
	//工作证明人 add
	$(".addworker").click(function(){
		var size=$(".work_ct tr:visible").length;
		if(size==0){
			$(".work_ct").find("#workProveClone").after($("#workProveClone").html());
			$(".work_ct").find("tr:last").find("input[name='credit_workProveDel']").val("N");//新增删除标志置为“N”
			
		}else{
			$(".work_ct").find("tr:last").after($("#workProveClone").html());
			$(".work_ct").find("tr:last").find("input[name='credit_workProveDel']").val("N");//新增删除标志置为“N”
		}
	});
	//工作证明人 delete
	$(".del_zmr").live('click', function(){
		var size=$(".work_ct tr:visible").length;
		if(size==2){
			alert("最少保留一条工作证明人信息！");
			return;		
		}
		$(this).closest("tr").hide().find("input[name='credit_workProveDel']").val("Y");
        $(this).closest("tr").prev("tr").hide();
	});
	
	//经营部地址删除
	$(".del_manageAddress").live('click',function(){
		var addrType=$(this).attr("addrType");
		$("#manageAddress"+addrType).closest("table").find("input[name='credit_manageAddressDel']").val('Y');
		$("#manageAddress"+addrType).hide();
		
		
	});
	
});
//==========================输入框动态显示==================================
//居住性质【家庭信息】切换，动态显示输入框
function familyLiveNatureChange(natureValue){
	if(natureValue=='1'){
		$("#family_liveNature_value1").css("display","block");
		$("#family_liveNature_value2").css("display","none");
		$("#family_liveNature_value3").css("display","none");
		$("#family_liveNature_value4").css("display","none");
	}else if(natureValue=='2'){
		$("#family_liveNature_value2").css("display","block");
		$("#family_liveNature_value1").css("display","none");
		$("#family_liveNature_value3").css("display","none");
		$("#family_liveNature_value4").css("display","none");
	}else if(natureValue=='5'){
		$("#family_liveNature_value3").css("display","block");
		$("#family_liveNature_value1").css("display","none");
		$("#family_liveNature_value2").css("display","none");
		$("#family_liveNature_value4").css("display","none");
	}else if(natureValue=='8'){
		$("#family_liveNature_value4").css("display","block");
		$("#family_liveNature_value1").css("display","none");
		$("#family_liveNature_value2").css("display","none");
		$("#family_liveNature_value3").css("display","none");
	}else{
		$("#family_liveNature_value1").css("display","none");
		$("#family_liveNature_value2").css("display","none");
		$("#family_liveNature_value3").css("display","none");
		$("#family_liveNature_value4").css("display","none");
	}
}
//房产归属【家庭信息】切换，动态显示输入框
function familyHouseBelongChange(value){
	if(value=='5'){
		$("#family_houseBelongOther").css("display","block");
	}else{
		$("#family_houseBelongOther").css("display","none");
	}
}
//房产套型【家庭信息】切换，动态显示输入框
function familyHouseTypeChange(value){
	if(value=='7'){
		$("#family_houseTypeOther").css("display","block");
	}else{
		$("#family_houseTypeOther").css("display","none");
	}
}
//客厅使用【家庭信息】切换，动态显示输入框
function familyLivingroomUseChange(value){
	if(value=='3'){
		$("#family_livingroomOther").css("display","block");
	}else{
		$("#family_livingroomOther").css("display","none");
	}
}
//卧室使用【家庭信息】切换，动态显示输入框
function familyBedroomUseChange(value){
	if(value=='3'){
		$("#family_bedroomUseOther").css("display","block");
	}else{
		$("#family_bedroomUseOther").css("display","none");
	}
}
//厨房使用【家庭信息】切换，动态显示输入框
function familyKtichenUseChange(value){
	if(value=='3'){
		$("#family_kitchenUseOther").css("display","block");
	}else{
		$("#family_kitchenUseOther").css("display","none");
	}
}
//卫生间使用【家庭信息】切换，动态显示输入框
function familyToiletUseChange(value){
	if(value=='3'){
		$("#family_toiletUseOther").css("display","block");
	}else{
		$("#family_toiletUseOther").css("display","none");
	}
}
//综合判断【家庭信息】切换，动态显示输入框
function familySyntheticJudgmentChange(value){
	if(value=='3'){
		$("#family_syntheticJudgmentOther").css("display","block");
	}else{
		$("#family_syntheticJudgmentOther").css("display","none");
	}
}
//车产按揭【家庭信息】切换，动态显示输入框
function familyCarMortgageChange(value){
	if(value=='Y'){
		$("#family_carMortgage1").css("display","block");
	}else{
		$("#family_carMortgage1").css("display","none");
	}
}
//其他房产套型【家庭信息】切换，动态显示输入框
function familyOtherHouseTypeChange(value){
	if(value=='7'){
		$("#family_otherHouseTypeOther").css("display","block");
	}else{
		$("#family_otherHouseTypeOther").css("display","none");
	}
}
//其他房产性质【家庭信息】切换，动态显示输入框
function familyOtherHousePropertyChange(value){
	if(value=='1'){
		$("#family_otherHouseProperty1").css("display","block");
		$("#family_otherHouseProperty2").css("display","none");
	}else if(value=='2'){
		$("#family_otherHouseProperty2").css("display","block");
		$("#family_otherHouseProperty1").css("display","none");
	}else{
		$("#family_otherHouseProperty1").css("display","none");
		$("#family_otherHouseProperty2").css("display","none");
	}
}
//检验方法【销售额】切换，动态显示输入框
function manageTestMethodChange(value){
	if(value=='1'||value== '2'||value=='3'){
		$("#manage_manageTestMethodOther").css("display","block");
	}else{
		$("#manage_manageTestMethodOther").css("display","none");
	}
}
//检验方法【毛利润】切换，动态显示输入框
function grossTestMethodChange(value){
	if(value=='1'||value== '2'||value=='3'){
		$("#manage_grossTestMethodOther").css("display","block");
	}else{
		$("#manage_grossTestMethodOther").css("display","none");
	}
}
//房产性质【经营信息】切换，动态显示输入框
function manageHouseNatureChange(value,type){
	//alert(value+"=="+type);
	if(value=='1'){
		$("#credit_houseNature1_"+type).css("display","block");
		$("#credit_houseNature2_"+type).css("display","none");
		$("#credit_houseNatureOther"+type).css("display","none");
	}else if(value=='4'){
		$("#credit_houseNature2_"+type).css("display","block");
		$("#credit_houseNature1_"+type).css("display","none");
		$("#credit_houseNatureOther"+type).css("display","none");
	}else if(value=='5'){
		$("#credit_houseNatureOther"+type).css("display","block");
		$("#credit_houseNature1_"+type).css("display","none");
		$("#credit_houseNature2_"+type).css("display","none");
	}else{
		$("#credit_houseNatureOther"+type).css("display","none");
		$("#credit_houseNature1_"+type).css("display","none");
		$("#credit_houseNature2_"+type).css("display","none");
	}
}
//共同居住者【家庭信息】，动态显示输入框
function changeLivePersons(value){
	if(value=='4'){
		$("#family_livePersonsOther").css("display","block");
	}else{
		$("#family_livePersonsOther").css("display","none");
	}
}

//打开实地征信上传页面
function openCreditUpload(applyId){
	if(applyId==''){
		alert("申请单编号为空！");
		return;
	}
	url = basePath+"/process/creditreport/openCreditUpload.do?applyId="+applyId+"&op='1'";//op=1上传
	var title=applyId.replace(/\-/g, "");//将applyId作为新打开页面的title，防止重复打开页面，title中不允许有'-'符号，所以将此替换。
	window.open(url,title);
	return;
}

//执行完成，返回到任务列表页面
function psuccess() {
    var url = basePath+"/process/creditreport/list.do";
    window.location = url;
    return;
}


$(document).ready(function(){
	// ==============页面动态输入框回显=======================
	familyLiveNatureChange($("#hidden_family_liveNature").val());//居住性质【家庭信息】
	familyHouseBelongChange($("#hidden_family_houseBelong").val());//房产归属【家庭信息】
	familyHouseTypeChange($("#hidden_family_houseType").val());//房产套型【家庭信息】
	familyLivingroomUseChange($("#hidden_family_livingroomUse").val());//客厅使用【家庭信息】
	familyBedroomUseChange($("#hidden_family_bedroomUse").val());//卧室使用【家庭信息】
	familyKtichenUseChange($("#hidden_family_ktichenUse").val());//厨房使用【家庭信息】
	familyToiletUseChange($("#hidden_family_toiletUse").val());//卫生间使用【家庭信息】
	familySyntheticJudgmentChange($("#hidden_family_syntheticJudgment").val());//综合判断【家庭信息】
	familyCarMortgageChange($("#hidden_family_carMortgage").val());//车产按揭【家庭信息】
	familyOtherHouseTypeChange($("#hidden_family_otherHouseType").val());//其他房产套型【家庭信息】
	familyOtherHousePropertyChange($("#hidden_family_otherHouseProperty").val());//其他房产性质【家庭信息】
	manageTestMethodChange($("#hidden_manage_manageTestMethod").val());//检验方法【销售额】
	grossTestMethodChange($("#hidden_manage_grossTestMethod").val());//检验方法【毛利润】
	manageHouseNatureChange($("#hidden_manageAddress_houseNature1").val(),'1');//房产性质1【经营信息】
	manageHouseNatureChange($("#hidden_manageAddress_houseNature2").val(),'2');//房产性质2【经营信息】
	manageHouseNatureChange($("#hidden_manageAddress_houseNature3").val(),'3');//房产性质3【经营信息】
	changeLivePersons($("#hidden_family_livePersons").val());//共同居住人【其他】
	//================动态添加默认添加一行===============================
	//默认添加一行贷款公司信息  
	var size=$(".jkgs_ct tr:visible").length;
	if(size==0){
		$(".jkgs_ct").find("#jkClone").after($("#jkClone").html());
		$(".jkgs_ct").find("tr:last").find("input[name='credit_otherBorrowDel']").val("N");//新增删除标志置为“N”
	} 
	//默认添加一行家庭概括信息
	var size2=$(".family_ct tr:visible").length;
	if(size2==0){
		$(".family_ct").find("#familyDetailClone").after($("#familyDetailClone").html());
		$(".family_ct").find("tr:last").find("input[name='credit_familyDetailDel']").val("N");//新增删除标志置为“N”
	}
	//默认添加一行工作证明人信息
	var size3=$(".work_ct tr:visible").length;
	if(size3==0){
		$(".work_ct").find("#workProveClone").after($("#workProveClone").html());
		$(".work_ct").find("tr:last").find("input[name='credit_workProveDel']").val("N");//新增删除标志置为“N”
		
	}
	//经营部2 3回显
	var creditId=$("#creditId").val();
	if(creditId!=null && creditId!=''){
		if($("#hidden_manageAddress2").val()==''){
			$("#manageAddress2").hide();
			$("#manageAddress2").find("input[name='credit_manageAddressDel']").val('Y');
		}
		if($("#hidden_manageAddress3").val()==''){
			$("#manageAddress3").hide();
			$("#manageAddress3").find("input[name='credit_manageAddressDel']").val('Y');
		}
	}
	
	//进入页面触发省市下拉菜单读取数据
    $("#plantAddrProvince").trigger('change');
    $("#workAddrProvince").trigger('change');
    $("#regAddrProvince").trigger('change');
});

