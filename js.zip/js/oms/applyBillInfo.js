var allPhone = [];
function getValidator(){
	   var  validator = $("#applyBillForm").validate({
	        rules : {
	        	"jobInfo_industryType":{required:true},
//	        	"jobInfo_industryCode":{required:true},
	        	"jobInfo_jobsCode":{required:true},
	        	
	            "applyBillInfo_borrowDescCode":{required:true,maxlength:40},
	            "applyBillInfo_borrowDescInfo":{required:true,maxlength:40},
	            "jobInfo_compDept":{required:true},
	            "jobInfo_compDutyCode":{required:true},
	            "applyBillInfo_maxReturnMoney":{required:true,number:true,maxlength:13},
	            "privateInfo_stockRatio":{number:true,maxlength:5},
	            "applyBillInfo_borrowMin":{required:true,number:true,maxlength:13},
	           // "applyBillInfo_borrowMax":{required:true,number:true,maxlength:13},
	            "applyBillInfo_productType":{required:true},
	            "applyBillInfo_productId":{required:true},
	            "applyBillInfo_refundLimit":{required:true,maxlength:10},
	            "clientInfo_name":{required:true,maxlength:15},
	            "clientInfo_gender":{required:true},
	            "personalInfo_phone1":{required:true,minlength:11,digits:true,maxlength:11},
	            "personalInfo_phone2":{minlength:11,digits:true,maxlength:11,isExidPhone:true},
	            "clientInfo_birthday":{required:true},
	            "clientInfo_idcard":{required:true,minlength:18,maxlength:18,isIdCardNo:true},
	            "clientInfo_idcard2":{required:true,minlength:18,maxlength:18,equalTo:"#clientInfo_idcard",isIdCardNo:true},
	            "personalInfo_validTime":{required:true},
	            "personalInfo_homeTown":{required:true},
	            "personalInfo_nowAddress":{required:true},
	            "personalInfo_education":{required:true},
	            //"personalInfo_isOpen":{required:true},
	            "personalInfo_tell":{maxlength:50,isExidPhone:true},
	            "personalInfo_email":{required:true,email:true,maxlength:50},
	            "personalInfo_liveCase":{required:true},
	            "personalInfo_liveJoin":{required:true},
	            
	            "personalInfo_homeTownProvince":{required:true},
	            "personalInfo_homeTownCity":{required:true},
	            "personalInfo_homeTownArea":{required:true},
	            "personalInfo_nowAddressProvince":{required:true},
	            "personalInfo_nowAddressCity":{required:true},
	            "personalInfo_nowAddressArea":{required:true},
	            "jobInfo_compAddresProvince":{required:true},
	            "jobInfo_compAddresCity":{required:true},
	            "jobInfo_compAddresArea":{required:true},
	            
	            "personalInfo_yearIncome":{required:true,number:true,maxlength:16},
	            //"applyPersonalInfo.creditLimit":{number:true,maxlength:16},
	            "personalInfo_marriage":{required:true},
	            //"personalInfo_children":{required:true},
	            //"personalInfo_providerNum":{required:true},
	            //工作信息验证
	            "jobInfo_compName":{required:true},
	            "jobInfo_compAddres":{required:true},
	            "jobInfo_compTellArea":{required:true,number:true},
	            "jobInfo_compTell":{required:true,isExidPhone:true},
	            "jobInfo_compJoinDate":{required:true},

	            //联系人
	            "linkman_name":{required:true},
	            "linkman_phone":{required:true,minlength:11,digits:true,maxlength:11},
	            "linkman_relationCode":{required:true},

	            "applyBillInfo_uidSale":{required:true},
	            "applyBillInfo_applyDate":{required:true},
	            "applyBillInfo_areaId":{required:true},
	           // "applyBillInfo_deptId":{required:true},
	            "applyBillInfo_userId":{required:true},
	            "applyBillInfo_cusSouce":{required:true},
	            
	            "applyBillInfo_unauthorize":{required:true},
	            //其他信息
	            "applyBillInfo_isCopyIn":{required:true},
	            
	            "applyBillInfo_isFlydeal":{required:true},
	            "jobInfo_occupation":{required:true},
	            "personalInfo_familyZip":{required:true,number:true,minlength:6,maxlength:6},
	            "jobInfo_commZip":{required:true,number:true,minlength:6,maxlength:6},
	            "jobInfo_compType":{required:true},
	            "jobInfo_employeeType":{required:true}
	        },
	        messages:{
	        	"jobInfo_industryType":{required:"请选择行业！"},
//	        	"jobInfo_industryCode":{required:"请选择行业二级分类！"},
	        	"jobInfo_jobsCode":{required:"请选择岗位分类！"},
	        	
	            "applyBillInfo_borrowDescCode":{required:"请选择借款用途"},
	            "applyBillInfo_borrowDescInfo":{required:"请选择详细用途"},
	            "jobInfo_compDept":{required:"请输入所在部门"},
	            "jobInfo_compDutyCode":{required:"请选择担任职务"},
	            "applyBillInfo_maxReturnMoney":{required:"请输入每月最高还款额度",number:"最高还款额度必须为数字"},
	            "applyBillInfo_borrowMin":{required:"请输入最低借款额度",number:"最低还款额度必须为数字"},
	            //"applyBillInfo_borrowMax":{required:"请输入最高借款额度",number:"最高还款额度必须为数字"},
	            "applyBillInfo_productType":{required:"请选择产品类型"},
	            "applyBillInfo_productId":{required:"请选择产品"},
	            "applyBillInfo_refundLimit":{required:"请输入还款期限"},
	            "clientInfo_name":{required:"请输入姓名"},
	            "clientInfo_gender":{required:"请选择性别"},
	            "clientInfo_birthday":{required:"请选择出生日期"},
	            "personalInfo_phone1":{required:"请输入手机号1",minlength:"手机号码格式不正确",digits:"手机号必须为整数",maxlength:"手机号码格式不正确"},
	            "personalInfo_phone2":{digits:"手机号必须为整数"},
	            "clientInfo_idcard":{required:"请输入身份证号"},
	            "clientInfo_idcard2":{required:"请输入身份证号确认",equalTo:"两次输入身份证号不一致"},
	            "personalInfo_validTime":{required:"请选择证件有效期"},
	            "personalInfo_education":{required:"请选择最高学历"},
	            //"":{required:"请选择是否可让家人知晓"},
	            "personalInfo_email":{required:"请输入电子邮箱地址",email:"电子邮箱地址格式不正确"},
	            "personalInfo_liveCase":{required:"请选择居住情况"},
	            "personalInfo_liveJoin":{required:"请选择共同居住者"},
	            "personalInfo_homeTown":{required:"请输入户籍地址"},
	            "personalInfo_nowAddress":{required:"请输入本市地址"},
	            "personalInfo_yearIncome":{required:"请输入个人年收入",number:"个人年收入必须为数字"},
	            //"applyPersonalInfo.creditLimit":{number:"信用卡最高额度必须为数字"},
	            "personalInfo_marriage":{required:"请选择婚姻状况"},
	            //"personalInfo_children":{required:"请选择子女情况"},
	            //"personalInfo_providerNum":{required:"请选择供养人数量"},
	            //工作信息验证
	            "jobInfo_compName":{required:"请输入单位名称"},
	            "jobInfo_compAddres":{required:"请输入单位地址"},
	            "jobInfo_compTellArea":{required:"请输入单位电话区号"},
	            "jobInfo_compTell":{required:"请输入单位电话"},
	            "jobInfo_compJoinDate":{required:"请输入入职时间"},

	            //联系人
	            "linkman_phone":{required:"请输入联系人电话",minlength:"手机号码格式不正确",digits:"手机号必须为整数",maxlength:"手机号码格式不正确"},
	            "linkman_name":{required:"请输入联系人姓名"},
	            "linkman_relationCode":{required:"请输入与本人关系"},
	            
	            "applyBillInfo_uidSale":{required:"请选择销售人员"},
	            "applyBillInfo_applyDate":{required:"请选择申请时间"},
	            "applyBillInfo_areaId":{required:"请选择进件机构"},
	           // "applyBillInfo_deptId":{required: "请选择销售团队"},
	            "applyBillInfo_userId":{required:"请选择团队经理"},
	            "applyBillInfo_cusSource":{required:"请输入客户来源"},
	            
	            //"applyBillInfo_unauthorized":{required:"请选择违例审批"},
	            "applyBillInfo_isCopyIn":{required:"请选择是否复印件进件"},
	            "applyBillInfo_isFlydeal":{required:"请选择是否飞单"},
	            "jobInfo_occupation":{required:"请选择职业"},
	            "personalInfo_familyZip":{required:"请输入住宅邮编",number:"住宅邮编必须为数字",minlength:"住宅邮编必须是6位数字",maxlength:"住宅邮编必须是6位数字"},
	            "jobInfo_commZip":{required:"请输入单位邮编",number:"单位邮编必须为数字",minlength:"单位邮编必须是6位数字",maxlength:"单位邮编必须是6位数字"},
	            "jobInfo_compType":{required:"请选择单位性质"},
	            "jobInfo_employeeType":{required:"请选择雇佣类型"}
	        }
	    }); 
	   return validator;
}


//js获取项目根路径，如： http://localhost:8083/oms
function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}

var basePath = getRootPath();//获取项目根路径

function initApplyBillInfo(type) {
	var state= $("#hidden_applyBillInfo_status").val();
	
    //如果不是暂存 即初始录入时 
    if(state!='Y'&&state!='N'){
    	//将所有控件设为 disabled
        $("input:not(#checkCustomerButt,#customerExist)").attr("disabled","disabled");
        $("select").attr("disabled","disabled");
        $("textarea").attr("disabled","disabled");
    }
    if(state=='Y'){
    	//暂存后客户姓名、身份证号码、确认身份证号码、手机号码、证件有效期不能修改
        $("#clientInfo_name").attr("readonly","readonly");
        $("#personalInfo_phone1").attr("readonly","readonly");
        $("#clientInfo_idcard").attr("readonly","readonly");
        $("#clientInfo_idcard2").attr("readonly","readonly");
    }
    
    var clientState= $("#clientInfo_isTmpSave").val();
    //if(clientState=='N'){
   // 	$("#clientInfo_name,#clientInfo_gender,#clientInfo_birthday,#clientInfo_idcard,#clientInfo_idcard2,#clientInfo_validTime").attr("disabled","disabled");
    //}
	
    //回显联系人所有省市区级联
	$(".province").each(function (){
		var value = $(this).attr("province");
	    var id = $(this).attr("tempid");

	    getCommenCity("linkman_city_"+id,$(this).attr("province"),$(this).attr("city"),"linkman_area_"+id,false);
	    getCountryByCity("linkman_area_"+id,$(this).attr("city"),$(this).attr("area"));
	});

    //回显共同借贷 多选框
    checkBoxesShow("personalInfo_liveJoin","personalInfo_liveJoins");
    // 删除有价资产(需求)
    //checkBoxesShow("personalInfo_validAssets","personalInfo_validAssetsArray");
   
	//户籍地址回显
    getCommenCity("htCity",$("#hidden_personalInfo_homeTownProvince").val(),$("#hidden_personalInfo_homeTownCity").val(),'htCounty',false);
    getCountryByCity("htCounty",$("#hidden_personalInfo_homeTownCity").val(),$("#hidden_personalInfo_homeTownArea").val());

    //本市地址回显
    getCommenCity("tccardCity",$("#hidden_personalInfo_nowAddressProvince").val(),$("#hidden_personalInfo_nowAddressCity").val(),'tccardCounty',false);
    getCountryByCity("tccardCounty",$("#hidden_personalInfo_nowAddressCity").val(),$("#hidden_personalInfo_nowAddressArea").val());
    //销售团队
    getSaleTeamByPID($("#hidden_applyBillInfo_areaId").val(),$("#hidden_applyBillInfo_deptId").val());
    //getTeamManager($("#hidden_applyBillInfo_deptId").val(),$("#hidden_applyBillInfo_userId").val(),true);//团队经理
    getSalesUserByOrg($("#hidden_applyBillInfo_deptId").val(),$("#hidden_applyBillInfo_uidSale").val());//销售人员
    //getTeamManagerHd($("#hidden_applyBillInfo_deptId").val(),$("#hidden_applyBillInfo_userId").val(),true,$("#hidden_isHd").val());//团队经理
    getTeamManagerByChannel($("#hidden_applyBillInfo_deptId").val(),$("#hidden_applyBillInfo_userId").val(),true,$("#channel").val());//团队经理

   
    //单位地址回显 
    getCommenCity("jobInfo_city",$("#hidden_jobInfo_province").val(),$("#hidden_jobInfo_city").val(),'jobInfo_area',false);
    getCountryByCity("jobInfo_area",$("#hidden_jobInfo_city").val(),$("#hidden_jobInfo_area").val());

    //产品期限回显
    getProductLimitOnly24And36($("#hidden_applyBillInfo_productId").val(),$("#hidden_applyBillInfo_refundLimit").val(),$("#hidden_applyBillInfo_areaId").val(),$("#hidden_applyBillInfo_refundLimit").val(),type);
    //回显产品
    getProductByType('applyBillInfo_productId',$("#hidden_applyBillInfo_productType").val(),$("#hidden_applyBillInfo_productId").val(),'consultId');
    //宅易贷隐藏上传图片按钮
    jQuery.validator.addMethod('isIdCardNo', function(value, element) {
        return this.optional(element) || isIdCardNo(value);
    },"请输入正确的身份证号码");
    
    //验证是否只有中文
    jQuery.validator.addMethod("isChinese", function(value, element) {       
        return this.optional(element) || /^[\u0391-\uFFE5]+$/.test(value);       
    }, "姓名不合法!");
    
    //验证是否有效的手机号码
//    jQuery.validator.addMethod('isValidPhone', function(value, element) {
//		var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
//		if(!myreg.test(value) && value != '') 
//		{ 
//			return this.optional(element) || false;
//		}else{
//			return this.optional(element) || true;
//		} 
//	},"手机号码格式不正确!");
    
   // 验证一个月内 的申请或者咨询 存在相同的手机号
    jQuery.validator.addMethod('isNotExistSamePhone', function(value, element) {
    	var consultId = $("#consultId").val();
		var applyId = $("#hiddenApplyId").val();
		var flag = 1;
				$.ajax({
		            type : "POST",
		            url : basePath+"/process/applybill/isExistSamePhone.do",
		            data : {'applyId':applyId,'consultId':consultId,'tell':value},
		            async : false, // 同步方法，如果用异步的话，flag永远为1
		            success : function(data) {
		            	if (data.success == 'true') {
							flag = 0;
						}
		            },
		            error : function() {
		                alert("判断手机号存在异常!");
		            }
		        });
				if (flag == 0) {
					return this.optional(element) || false;
				} else {
					return this.optional(element) || true;
				}

    },"该手机号一个月内存在申请或咨询");
    
//  验证是否有效的手机号码
    jQuery.validator.addMethod('isValidPhone', function(value, element) {
		var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
		if(!myreg.test(value) && value != '') 
		{ 
			return this.optional(element) || false;
		}else{
			return this.optional(element) || true;
		} 
	},"手机号码格式不正确!");
    
    // 验证电话号码是否重复
	    jQuery.validator.addMethod('isExidPhone', function(value, element) {
	    	var personalInfo_phone1= $("#personalInfo_phone1").val();
	    	var personalInfo_phone2= $("#personalInfo_phone2").val();
	    	var personalInfo_tell=$("#personalInfo_tell").val();
	    	var jobInfo_compTell=$("#jobInfo_compTell").val();
	    	allPhone = [];
	    	// 兼容浏览器支持
	    	if(!Array.indexOf)
	    	{
	    	    Array.prototype.indexOf = function(obj)
	    	    {              
	    	        for(var i=0; i<this.length; i++)
	    	        {
	    	            if(this[i]==obj)
	    	            {
	    	                return i;
	    	            }
	    	        }
	    	        return -1;
	    	    }
	    	}
	    	
	    	if(personalInfo_phone1!=""){
	    		allPhone.push(personalInfo_phone1);
	    	}
	    	if(personalInfo_phone2!=""){
	    		if(allPhone.indexOf(personalInfo_phone2)>=0){
	    			if(personalInfo_phone2==value)
	    			return this.optional(element) || false;}
	    		 else{
	    			allPhone.push(personalInfo_phone2);}
	    	}
	    	if(personalInfo_tell!=""){
	    		if(allPhone.indexOf(personalInfo_tell)>=0){
	    			if(personalInfo_tell==value)
	    			return this.optional(element) || false;}
	    		 else{
	    			allPhone.push(personalInfo_tell);}
	    	}
	    	
	    	if(jobInfo_compTell!=""){
	    		if(allPhone.indexOf(jobInfo_compTell)>=0){
	    			if(jobInfo_compTell==value)
	    			return this.optional(element) || false;}
	    		 else{
	    			allPhone.push(jobInfo_compTell);}
	    	}
	    	
	    	return this.optional(element) || true;
	    	    
	        },"此号码已存在");
	}
	
	// 验证客户存在
	function checkCustomerExist(){
		var idcard = $("#customerExist").val();
		if($.trim(idcard)==''){
			alert("身份证不能为空");
		}else{
			if(isIdCardNo(idcard)){
				//所有输入控件置为可用
		        $("input[id!='clientInfo_birthday']").attr("disabled",false);
		        $("select[id!='channel_n']").attr("disabled",false);
		        $("textarea").attr("disabled",false);
		        $("#clientInfo_gender").attr("disabled",true);

				$.ajax({
		            type : "POST",
		            url : basePath+"/process/applybill/checkCustomerExist.do",
		            data : {'idcard':idcard},
		            success : function(data) {
		                if(data==''||data=='null'){
		                    alert("不存在该客户");
		                }else{
		                    var r = window.confirm("存在该客户,是否将客户信息显示到申请单？");
		                    if(r==true){
		                        $("#clientInfo_name").val(data.name);
		                        $("#clientInfo_gender").val(data.gender);
		                        $("#clientInfo_birthday").val(data.birthday);
		                        $("#clientInfo_idcard").val(data.idcard);
		                        $("#clientInfo_idcard2").val(data.idcard);
		                        //$("#clientInfo_validTime").val(data.validTime);
		                        
		                        $("#clientInfo_id").val(data.id);
		                        //$("#clientInfo_name,#clientInfo_gender,#clientInfo_birthday,#clientInfo_idcard,#clientInfo_idcard2,#clientInfo_validTime").attr("disabled","disabled");
		                        //申请单客户id 
		                        $("#applyBillInfo_cusId").val(data.id);
		                    }
		                }
		            },
		            error : function() {
		                alert("不存在该客户!");
		            }
		        });
		    }else{
		    	alert("请输入正确格式的身份证");
			}
		}
	}
	
	var temp = 1;
	//动态添加联系人
	function linkManAutoAdd(obj,type){
	    var title;
	    if(type=='1'){
	        title="家庭联系人";	
	     }else if(type=='2'){
	    	title = "工作证明人";
	      }else if(type=='3'){
	    	title ="紧急联系人";
	       }
	    var x = " <tr><td colspan='6' class='title'><input name='linkman_contactType' type='hidden'  value='"+type+"' />"+
	    "<input name='linkman_id' type='hidden' /><div class='table-addlxr'><label>&nbsp;&nbsp;&nbsp;新增"+title+"</label><input name='' type='button' value='删除' "+
	    " class='button2 fl' onclick='deleteLinkMan(this)' /></div>"
	    
	    var id = $(obj).attr("tempid");

		var _tmpTr = $("input[name='linkman_contactType'][value='"+type+"']:last").closest("tr");

		var _tmpAddLinkman = "";
		    _tmpAddLinkman = _tmpAddLinkman + "<tr>" + $(_tmpTr).next("tr").html() + "</tr>";
		    
		x=x+_tmpAddLinkman+"</td></tr>";
		
		//将拼接好的元素放到其后
		$(_tmpTr).next("tr").after(x);

	    //获得新添加的元素对象
		var newAdded = $(_tmpTr).next("tr").next("tr").next("tr");

		temp ++;
	    var idnew = $(newAdded).find(".province").attr("tempid")+temp;
	    
	    //改变默认的 省市区select控件的 changge事件 及id
	    $(newAdded).find(".province").attr("onchange","");
	    $(newAdded).find(".province").attr("tempid",idnew);
	    $(newAdded).find(".province").attr("id",'linkman_province_'+idnew);
	    $(newAdded).find(".city").attr("onchange","");
	    $(newAdded).find(".city").attr("id",'linkman_city_'+idnew);
	    $(newAdded).find(".area").attr("id",'linkman_area_'+idnew);
		$(newAdded).find(".province").change(function (){getCommenCity('linkman_city_'+idnew,this.value,'','linkman_area_'+idnew,true);});
		$(newAdded).find(".city").change(function (){getCountryByCity('linkman_area_'+idnew,this.value,'');});
		
		$(newAdded).find("select,input[type='text']").each(function(){
			$(this).val("");
			$(this).attr("readonly",false);
		});
		
		$(newAdded).find(".province").each(function (){getCommenCity('linkman_city_'+idnew,'','','linkman_area_'+idnew,true);});
		$(newAdded).find(".city").each(function (){getCountryByCity('linkman_area_'+idnew,'','');});

	}
	
	function toUploadFile(applyNum,applyId){
//		var applyBillInfo_productId = $("#applyBillInfo_productId").val();
//		var code = $("#hidden_code").val();
//		alert(applyBillInfo_productId);
//		if(!applyBillInfo_productId){
//			alert("请选择申请产品！");
//			return;
//		}
		var applyId = $("#hiddenApplyId").val();
		var applyNum = $("#hiddenApplyNum").val();
		var consultId = $("#consultId").val();
	    if(applyId!=''){
	    	var url = basePath+"/process/applybill/uploadImage.do?applyNum="+applyNum+"&applyId="+applyId+"&consultId="+consultId+"&flag=1";
	    	myopen(url,"uploadpic");
	    }
	}
	
	function myopen(winurl,winname){
	       objWin__ = window.open( winurl,winname, "scrollbars=yes,status=yes,resizable=yes,top=0,left=0,width="+(screen.availWidth-10)+",height="+(screen.availHeight-55));
			objWin__ .focus();
			return true;
	}
	
	//多选框回显
    function checkBoxesShow(boxesName,valueTextId){
             //多选框的回显
            var _arr = $("#"+valueTextId).val().split(",");
            var _chks = $("input[name='"+boxesName+"']");
            for (var i = 0; i < _chks.length; i++) {
              for (var j = 0; j < _arr.length; j++) {
                if (_arr[j] == _chks[i].value) {
                  _chks[i].checked = true;
                }
              }
           }
    }

    // 多选框提交赋值
  function sumbitCheckBoxes(boxesName,valueTextId){
          var _chks = $("input[name='"+boxesName+"']");
          var temp;
          for (var i = 0; i < _chks.length; i++) {
                if(_chks[i].checked){                       
                     if(temp!=null){
                         temp+=_chks[i].value+",";
                     }else{
                         temp=_chks[i].value+",";
                     }
                 }
           }               
           $("#"+valueTextId).val(temp);
  }
  
  
  

//级联销售团队
function getSaleTeamByPID(orgId,value)
{
    $.getJSON(basePath+"/sys/org/getSaleTeamByPID.do",{orgId:orgId},function(data){
  	  var temp;
        temp = "<option value=''>--请选择--</option>";
        $("#applyBillInfo_deptId").html(temp);
         if(data){
          	 var num = data.length;
               for(var i=0;i<num;i++){
                     if(data[i].orgId==value){
                          temp += "<option value='"+ data[i].orgId+"' selected='selected' >"+data[i].orgName+"</option>";
                      }else{
                          temp += "<option value=" + data[i].orgId+ ">" + data[i].orgName + "</option>"; 
                      }
                     $("#applyBillInfo_deptId").html(temp);
               }
           }
       });
}
/**
 * 
 * @param orgId
 * @param value
 * @param isUpdate 是否回显
 * @return
 */
function getTeamManager(orgId,value,isUpdate){
    $.getJSON(basePath+"/sys/user/getUserByOrgAndRole.do",{orgId:orgId,roleName:'团队经理'},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#applyBillInfo_userId").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].loginId==value){
                 temp += "<option value='"+ data[i].loginId+"' selected='selected' >"+data[i].name+"</option>";
              }else{
                 temp += "<option value=" + data[i].loginId+ ">" + data[i].name + "</option>"; 
              }
               
          	  $("#applyBillInfo_userId").html(temp);
           }
       });
    if(!isUpdate){
    	getSalesUserByOrg(orgId,'');
    }
}

function getTeamManagerByChannel(orgId,value,isUpdate,channel){
	var orgName = '';
	switch(parseInt(channel)){
		case 2:
			orgName = "好贷团队经理";
			break;
		case 6:
			orgName = "融360团队经理";
			break;
		default:
			orgName = "团队经理";
	}
    $.getJSON(basePath+"/sys/user/getUserByOrgAndRole.do?a=Math.random()",{orgId:orgId,roleName:orgName},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#applyBillInfo_userId").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].loginId==value){
                 temp += "<option value='"+ data[i].loginId+"' selected='selected' >"+data[i].name+"</option>";
              }else{
                 temp += "<option value=" + data[i].loginId+ ">" + data[i].name + "</option>"; 
              }
               
          	  $("#applyBillInfo_userId").html(temp);
           }
       });
    if(!isUpdate){
    	getSalesUserByOrg(orgId,'');
    }
}

/**
 * 
 * @param orgId
 * @param value
 * @param isUpdate 是否回显
 * @return
 */
function getTeamManagerHd(orgId,value,isUpdate,isHd){
	var orgName = '';
	if(isHd=='Y')
		{
		    orgName='好贷团队经理';
		}else{
			orgName='团队经理';
		}
    $.getJSON(basePath+"/sys/user/getUserByOrgAndRole.do",{orgId:orgId,roleName:orgName},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#applyBillInfo_userId").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].loginId==value){
                 temp += "<option value='"+ data[i].loginId+"' selected='selected' >"+data[i].name+"</option>";
              }else{
                 temp += "<option value=" + data[i].loginId+ ">" + data[i].name + "</option>"; 
              }
               
          	  $("#applyBillInfo_userId").html(temp);
           }
       });
    if(!isUpdate){
    	getSalesUserByOrg(orgId,'');
    }
}


//关联销售
function getSalesUserByOrg(orgId,value){
	var saleUserPath="";
//	var isHd=$("#hidden_isHd").val();
//	if(isHd=='Y')
//	{
//		saleUserPath="getSalesUserByOrgHd.do";
//	}else{
		saleUserPath="getSalesUserByOrg.do";
	//}

    $.getJSON(basePath+"/process/saleuser/"+saleUserPath+"?random="+Math.random(),{orgId:orgId},function(data){
           var num = data.length;
           var temp;
           temp = "<option value=''>--请选择--</option>";
           $("#applyBillInfo_uidSale").html(temp);
           for(var i=0;i<num;i++){
          	 if(data[i].id==value){
          		 temp += "<option value='"+ data[i].id+"' selected='selected' >"+data[i].name+"</option>";
             }else{
                 temp += "<option value=" + data[i].id+ ">" + data[i].name + "</option>"; 
             }
            $("#applyBillInfo_uidSale").html(temp);
           }
       });
}



//提交 验证客户身份证存在
function checkIdcardWhenSubmit(){
  var idcard = $("#clientInfo_idcard").val();
  var flag = false;
  $.ajax({
       type : "POST",
       url : basePath+"/process/applybill/checkCustomerExist.do",
       async:false,
       data : {'idcard':idcard},
       success : function(data) {
                if(data==''||data=='null'){
                      flag = true;
                  }else{
                      var r = window.confirm("存在该客户,是否将客户信息显示到申请单？");
                      if(r==true){
                          $("#clientInfo_name").val(data.name);
                          $("#clientInfo_gender").val(data.gender);
                          $("#clientInfo_birthday").val(data.birthday);
                          $("#clientInfo_idcard").val(data.idcard);
                          $("#clientInfo_idcard2").val(data.idcard);
//                        $("#clientInfo_validTime").val(data.validTime);
                          
                          $("#clientInfo_id").val(data.id);
                          //$("#clientInfo_name,#clientInfo_gender,#clientInfo_birthday,#clientInfo_idcard,#clientInfo_idcard2,#clientInfo_validTime").attr("disabled","disabled");
                          //申请单客户id 
                          $("#applyBillInfo_cusId").val(data.id);
                          
                          flag = true;
                      }
                  }
              },
        error : function() {
                  alert("不存在该客户!");
              }
   });
  
  return flag;
}

function checkLinkmanName(value){
	var reg = /^[\u0391-\uFFE5]+$/;
	if(reg.test(value)){
		return false;
	}else{
		return true;
	}	
}

//验证联系人信息
function checkLinkmanInfo(){
	
	//兼容浏览器支持
	if(!Array.indexOf)
	{
	    Array.prototype.indexOf = function(obj)
	    {              
	        for(var i=0; i<this.length; i++)
	        {
	            if(this[i]==obj)
	            {
	                return i;
	            }
	        }
	        return -1;
	    }
	}
	
	var flag = 0;
	$(document).find(".linkman_name_home").each(function(){
		if($.trim($(this).val())==''){
            alert("请输入家庭联系人姓名");
            $(this).focus();
            flag = 1;
            return false;
         }
    	});
    if(flag==1){
        return false;
    }
	
	$(document).find(".linkman_phone_home").each(function(){
        if($.trim($(this).val())==''){
            alert("请输入家庭联系人电话");
            $(this).focus();
            flag = 1;
            return false ;
         }
        if(allPhone.indexOf($(this).val())>=0){
        	 alert("此号码已存在");
             $(this).focus();
             flag = 1;
             return false ;}
        else{
        	allPhone.push($(this).val());
        }
        });
	 if(flag==1){
         return false;
     }
	 $(document).find(".linkman_phone_home").each(function(){
         if($.trim($(this).val())==''){
             alert("请输入家庭联系人电话");
             $(this).focus();
             flag = 1;
             return false ;
          }
         });
      if(flag==1){
          return false;
      }

      $(document).find(".linkman_name_job").each(function(){
          if($.trim($(this).val())==''){
              alert("请输入工作证明人姓名");
              $(this).focus();
              flag = 1;
              return false ;
           }
          });
       if(flag==1){
           return false;
       }
      $(document).find(".linkman_phone_job").each(function(){
    	  var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
          if($.trim($(this).val())==''){
              alert("请输入工作证明人电话");
              $(this).focus();
              flag = 1;
              return false ;
           }
          if(!myreg.test($(this).val()) && $(this).val() != ''){
        	  alert("手机号码格式不正确");
	          $(this).focus();
	          flag = 1;
	          return false ;
          }
          if(allPhone.indexOf($(this).val())>=0){
         	 alert("此号码已存在");
              $(this).focus();
              flag = 1;
              return false ;}
         else{
         	allPhone.push($(this).val());
         }
          });
      
      $(document).find(".linkman_name_urgent").each(function(){
          if($.trim($(this).val())==''){
              alert("请输入紧急联系人姓名");
              $(this).focus();
              flag = 1;
              return false ;
           }
          });
       if(flag==1){
           return false;
       }
      $(document).find(".linkman_phone_urgent").each(function(){
    	  var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
          if($.trim($(this).val())==''){
              alert("请输入紧急联系人电话");
              $(this).focus();
              flag = 1;
              return false ;
           }
          if(!myreg.test($(this).val()) && $(this).val() != ''){
        	  alert("手机号码格式不正确");
	          $(this).focus();
	          flag = 1;
	          return false ;
          }
          if(allPhone.indexOf($(this).val())>=0){
         	 alert("此号码已存在");
              $(this).focus();
              flag = 1;
              return false ;}
         else{
         	allPhone.push($(this).val());
         }
          });
      
        if(flag==1){
            return false;
        }else{
     	   return true;
        }
       
}
