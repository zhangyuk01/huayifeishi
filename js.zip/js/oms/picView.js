$(function(){
	var i=0,//大图编号
		len=img.length,//img数组的长度
		cur=0;//当前图片编号
		j=7,//默认显示小图个数
		page=0,//小图的页码
		$s_next=$("#smallImg-next"),//小图下一页
		$s_pre=$("#smallImg-pre"),//小图上一页
		box=$("#smallImg-box").width(),//显示的长度
		$ul=$("#smallImg-ul"),//小图外层
		$imgLi=$ul.find("li"),//小图li
		html=_html="";//存放载入的代码	
		if(len>0){	
			$("#detailImg-box").append("<a style='cursor: pointer;' onclick='seePic(\""+img[0].href+"\")' class=\"detailImg_1\"><img title=\""+img[0].title+"\" src=\""+img[0].src+"\"></a><p>"+img[0].time+"</p>");
		}
	//大图	
	$("#detailImg-next").click(function(){
		++i;
		if(i==len){
			i = 0;
		}
		detailImg_click($s_next,i,len);
		
	});
	$("#detailImg-pre").click(function(){
		--i;
		if(i==-1){
			i = len-1;
		}
		detailImg_click($s_pre,i,len);
	});
	//小图
	if(len>0){
		var a = 0;
		if(len>j){
			a=j;
		}else{
			a=len;
		}
		for(var k=0;k<a;k++){
			var _k=k%len;
			s_html(_k);
			html+=h;
		}
	}
	$ul.append(html);
	$(".smallImg_1").addClass("cur");	
	//小图下一页
	$("#smallImg-next").click(function(){
		if(!$ul.is(":animated")){
			if(len>j){
				page++;
				var a=page*j,_a;
				for(var k=0;k<j;k++,a++){
					smallImg_click(a,_a,len,i);
					_html+=h;
				}
				$ul.append(_html);
				$ul.css({"left":0,"right":"auto"});
				$ul.animate({left:-box},1600,function(){
					$ul.find("li:lt("+j+")").detach();
					$ul.css("left",0);
					_html="";
				});//动画执行后,再删除前9个li,将left设回0
				$("#smallImg-ul li").click(function(){//三处一样，不知道这个要怎么优化？？？
					var _this=$(this);
					i=_this.attr("class").replace(/[^0-9]/ig,"")-1;
					img_info(i);
					s_a_r(_this,"cur");
					cur=i;
				});
			}else{
				alert("已经是最后一页啦！");
			}
			
		}
	});
	//小图上一页
	$("#smallImg-pre").click(function(){
		if(!$ul.is(":animated")){
			if(len>j){
				page--;
				var a=(page-1)*j,_a,c;
				for(var k=0;k<j;k++,a--){
					smallImg_click(a,_a,len,i);
					_html=h+_html;
				}
				$ul.prepend(_html).css({"right":box,"left":"auto"});
				$ul.animate({right:0},1600,function(){
					$ul.find("li:gt("+(j-1)+")").detach();//删除后9个li,从8开始
					_html="";
				});
				$("#smallImg-ul li").click(function(){
					var _this=$(this);
					i=_this.attr("class").replace(/[^0-9]/ig,"")-1;
					img_info(i);
					s_a_r(_this,"cur");
					cur=i;
				});
			}else{
				alert("已经是第一页啦！");
			}
		}
			
	});
	//点击小图
	$("#smallImg-ul li").click(function(){
		var _this=$(this);
		i=_this.attr("class").replace(/[^0-9]/ig,"")-1;
		img_info(i);
		s_a_r(_this,"cur");
		cur=i;
	});
});

//大图图片信息
function img_info(i){
	var href=img[i].href,
		alt=img[i].alt,
		src=img[i].src,
		title=img[i].title,
		time=img[i].time,
		$main=$("#detailImg-box");
	$main.find("a").attr({"onclick":"seePic(\""+href+"\")"});
	//$main.find("a").attr({"href":href,"class":"detailImg_"+(i+1)});
	$main.find("img").attr({"alt":alt,"src":src,"title":title});
	$main.find("p").text(time);
}
function s_a_r(o,c){
	o.addClass(c).siblings().removeClass(c);	
}
//大图左右点击
function i_cur(i,len){
	i=i%len;
	if(i<0){
		i=len+i;
	}
	return i;	
}
function detailImg_click($pn,i,len){
	i_cur(i,len);
	
	img_info(i);
	var imgCur=$(".smallImg_"+(i+1));
	if(!imgCur.html()){
		$pn.click();
	} 
	s_a_r($(".smallImg_"+(i+1)),"cur");//小图选中
}
//小图左右点击
function smallImg_click(a,_a,len,i){
	_a=a;
	_a=a%len;
	if(_a<0){
		_a+=len;
	}
	c=_a==i?"cur":"";
	s_html(_a,c);
}
function s_html(_a,c){
	return h="<li class=\"smallImg_"+(_a+1)+" "+c+"\"><a><img title=\""+img[_a].title+"\" src=\""+img[_a].smallSrc+"\"></a></li>";
}