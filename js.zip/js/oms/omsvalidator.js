//更该验证插件默认提示方式
$.validator.setDefaults({
    onsubmit: false,
    onkeyup: false,
    onclick: false,
    onfocusout: false,
    showErrors:function(errorMap, errorList){
        if (errorList.length > 0) {
            alert(errorList[0].message);
            $(errorList[0].element).trigger("focus");
        }
    }
});