$(function(){
	var screenWidth = $("body").width();
	if(screenWidth > 1350){
		$(".easyui-layout.layout").css("height", "900px");
		$(".panel-body.panel-body-noheader.panel-body-noborder").css("height", "674px");
		$("#leftContent, #t1.easyui-tabs.tabs-container, #rightContent.panel-body.panel-body-noheader.panel-body-noborder.layout-body.panel-noscroll, #t2.easyui-tabs.tabs-container").css("height", "714px");
		$(".tabs-panels").css("height", "684px");
		$(".panel-body.panel-body-noheader.panel-body-noborder.layout-body.panel-noscroll").css("height" ,"714px");
	}
});