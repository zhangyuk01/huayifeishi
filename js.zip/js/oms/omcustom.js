
var basePath = getRootPath();//获取项目根路径
//开启遮罩
function showLoading(){
	$.blockUI({
		message : "<img src='../../img/loading.gif' /><h4><strong>操作中,请稍后....</strong></h4>",
		css : {
			background : 'none',
			color : '#000',
			border : 'none'
		},
		overlayCSS : {
			backgroundColor : '#C5E1F0',
			opacity : '0.6'
		}
	});
}

//关闭遮罩
function hideLoading(){
	$.unblockUI();
}

//js获取项目根路径，如： http://localhost:8083/oms
function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
/**
 * 根据code 查询省份
 * id:区县 select控件的id值
 * code: 城市的code
 * value: 数据回显时区县的code
 * 
 */
function getProvinceByCode(id,code,value){
	var basePath =getRootPath();
	    $.ajax({
	    type : "post",
	    url : basePath+"/common/sysdict/getCountryByCity.do",
	    dataType : "json",
	    data:{"id":code,"random":new Date().getTime()},
	    cache:false,
	    success : function(data, textStatus) {
	         var options="<option value='' selected='selected' >--请选择--</option>";
	            for(var i=0;i<data.length;i++){
	                if(data[i].areaid==value){
	                    options += "<option value='"+data[i].areaid+"' selected='selected' >"+data[i].area+"</option>";
	                }else{
	                    options += "<option value='"+data[i].areaid+"' >"+data[i].area+"</option>";
	                }
	            }
	            $("#"+id).html(options);
	        }
	  });
	}


/**
 * 根据省份code 查询城市 
 * id:城市 select控件的id值
 * code: 省份的code
 * value: 数据回显时的城市的code
 * countyId：区县select控件的id值
 * isUpdate: 是否更新区县
 */
function getCommenCity(id,code,value,countyId,isUpdate){
  var basePath = getRootPath();
  $.ajax({
  type : "post",
  url : basePath+"/common/sysdict/getCityByProvince.do",
  dataType : "json",
  data:{"id":code},
  cache:false,
  success : function(data, textStatus) {
  	 var options="<option value='' selected='selected' >--请选择--</option>";
  	
          for(var i=0;i<data.length;i++){
              if(data[i].cityid==value){
                  options += "<option value='"+data[i].cityid+"' selected='selected' >"+data[i].city+"</option>";
              }else{
                  options += "<option value='"+data[i].cityid+"' >"+data[i].city+"</option>";
              }
          }
          $("#"+id).html(options);
          if(isUpdate){
        	  options="<option value='' selected='selected' >--请选择--</option>";
         	 $("#"+countyId).html(options);
         }
          
      }
  
   
  });
}

/**
 * 根据城市code 查询区县
 * id:区县 select控件的id值
 * code: 城市的code
 * value: 数据回显时区县的code
 * 
 */
function getCountryByCity(id,code,value){
	var basePath =getRootPath();
	    $.ajax({
	    type : "post",
	    url : basePath+"/common/sysdict/getCountryByCity.do",
	    dataType : "json",
	    data:{"id":code,"random":new Date().getTime()},
	    cache:false,
	    success : function(data, textStatus) {
	         var options="<option value='' selected='selected' >--请选择--</option>";
	            for(var i=0;i<data.length;i++){
	                if(data[i].areaid==value){
	                    options += "<option value='"+data[i].areaid+"' selected='selected' >"+data[i].area+"</option>";
	                }else{
	                    options += "<option value='"+data[i].areaid+"' >"+data[i].area+"</option>";
	                }
	            }
	            $("#"+id).html(options);
	        }
	  });
	}


/**
 * 备注加时间(日期 加时分秒)，双击文本域触发 
 * 参数为 文本域 id
 */ 
function addTimeInTextarea(id){
    var myDate = new Date().Format("yyyy-MM-dd hh:mm:ss");  
    var time = myDate.toLocaleString();
    var content = $("#"+id).val();
    if($.trim(content)==''){
    	$("#"+id).val("时间："+time);
    }else{
    	$("#"+id).val(content+"\r\n时间："+time);
    }
}
//对Date的扩展，将 Date 转化为指定格式的String
//月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
//年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
//例子： 
//(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
//(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
Date.prototype.Format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}


/*
 * 根据产品类型查询产品列表
 * id : 产品select控件id
 * type : 产品分类值
   value: 产品id值
 */
function getProductByType(id,type,value,consultId){
	var consultId = $("#"+consultId).val();
	var applyId = $("#applyId").val();
	var basePath =getRootPath();
	if($.trim(type)!=''){
		$.getJSON(basePath+"/product/product/queryProductListByType.do",
	            {type:type,consultId:consultId,applyId:applyId}, 
	            function(data){
	                
	                 var num = data.length;
	                 var temp="<option value=''>--请选择--</option>";
	                 $("#"+id).html(temp);
	                 for(var i=0;i<num;i++){
	                      if(data[i].id==value){
	                          temp += "<option value='" + data[i].id + "' selected='selected'  >" + data[i].productName + "</option>"; 
	                      }else{
	                    	  if(data[i].productAndAge=="1"){//年龄不符合该产品限制,禁选
		                          temp += "<option value=" + data[i].id + " disabled='disabled'>" + data[i].productName + "</option>"; 
	                    	  }else{
		                          temp += "<option value=" + data[i].id + " >" + data[i].productName + "</option>"; 
	                    	  }
	                      }
	                 }
	                $("#"+id).html(temp);
	                saveBtnFlag();
	                getProductByTypeLoan();
	            }
	        );
	}
}

function getProductByTypeLoan(){
    var proName = $("#productName").val();
	if(proName == "宅易贷"){
		$("#endProductType").attr("disabled",true);
		$("#endProductId").attr("disabled",true);
	}
}

function deleteLinkMan(obj,id){
	var basePath =getRootPath();
     if(id&&id!=''){
    	 var r = window.confirm("确定要删除联系人吗？");
         if(r==true){
	    	 $.getJSON(basePath+"/process/applybill/deleteLinkmanById.do",
	                 {id:id}, 
	                 function(data){
	                	 if ("true" == data.success) {
	                         alert("删除联系人成功!");
	                         var _tmpTr = $(obj).closest("tr");
	                         $(_tmpTr).next("tr").remove();
	                         $(_tmpTr).empty();
	                         window.location.reload();
	                     } else {
	                         alert("删除联系人失败!");
	                     }
	                 }
	      );
       }
     }else{
    	 var _tmpTr = $(obj).closest("tr");
         $(_tmpTr).next("tr").remove();
         $(_tmpTr).remove();   
      }
}

//产品期限
function getProductLimit(productId,value,areaId,applyRefundLimit,type){
    $.getJSON(basePath+"/product/feerate/queryProductLimitByProductId.do",
        {productId:productId,areaId:areaId,applyRefundLimit:applyRefundLimit,type:type}, 
        function(data){
             var num = data.length;
             var temp="<option value=''>--请选择--</option>";
             $("#refundLimit").html(temp);
             for(var i=0;i<num;i++){
        		 if(data[i].id==value){
        			 temp += "<option value='" + data[i].id + "' selected='selected' >" + data[i].productLimit + "</option>"; 
        		 }else{
        			 temp += "<option value=" + data[i].id + " >" + data[i].productLimit + "</option>"; 
        		 }
             }
            $("#refundLimit").html(temp);
            saveBtnFlag();
        }
    );
}

//产品期限-只显示24/36期
function getProductLimitOnly24And36(productId,value,areaId,applyRefundLimit,type){
	$.getJSON(basePath+"/product/feerate/queryProductLimitByProductIdOnly24And36.do",
	        {productId:productId,areaId:areaId,applyRefundLimit:applyRefundLimit,type:type,only24And36:1}, 
	        function(data){
	             var num = data.length;
	             var temp="<option value=''>--请选择--</option>";
	             $("#refundLimit").html(temp);
	             for(var i=0;i<num;i++){
	        		 if(data[i].id==value){
	        			 temp += "<option value='" + data[i].id + "' selected='selected' >" + data[i].productLimit + "</option>"; 
	        		 }else{
        				 temp += "<option value=" + data[i].id + " >" + data[i].productLimit + "</option>"; 
	        		 }
	             }
	            $("#refundLimit").html(temp);
	            saveBtnFlag();
	        }
	);
}

//宅易贷隐藏上传图片按钮
function saveBtnFlag(){
	var proName = $("#applyBillInfo_productId option:selected").html();
	if(proName == '宅易贷'){
		$("#saveBtnFlag").val("0");
		$("#uploadFile").hide();
	}else{
		$("#saveBtnFlag").val("1");
		$("#uploadFile").show();
	}
}

//行业及岗位代码
function getIndustryCode(id,code,value){

    $.getJSON(basePath+"/common/industryDict/getIndustryByPCode.do",
        {code:code}, 
        function(data){
             var num = data.length;
             var temp="<option value=''>--请选择--</option>";
             $("#"+id).html(temp);
             if(id=='industry'){
                 $("#jobs").html(temp);
             }
             
             for(var i=0;i<num;i++){
                  if(data[i].code==value){
                	  temp += "<option value='" + data[i].code + "' selected='selected' >" + data[i].code+data[i].name + "</option>"; 
                  }else{
                	  temp += "<option value=" + data[i].code + " >" + data[i].code+data[i].name + "</option>"; 
                  }
             }
             
             if(code.substr(0,1)!='I'){
            	 $("#privateBusinessCode").val("");
            	 $("#privateBusinessCode").attr("disabled","disabled"); 
             }else{
            	 $("#privateBusinessCode").removeAttr("disabled");
             }
            
            $("#"+id).html(temp);
            
        }
    );
}


//弹出新窗口 并防止重复打开
function uploadImageAll(node,apply_id,window_id) {
	var url = basePath+'/car/common/picoprate/uploadImage.do?op=1&node=';
	if($.trim(node)==''){
		alert("提交环节为空");
		return false;
	}
	if($.trim(apply_id)==''){
		alert("申请单id为空");
		return false;
	}
	if($.trim(window_id)==''){
		alert("窗口id为空");
		return false;
	}
	
	url = url+node+'&applyIdVal='+apply_id;
	var title=window_id.replace(/\-/g, "");//将applyId作为新打开页面的title，防止重复打开页面，title中不允许有'-'符号，所以将此替换。
	window.open(url,title);
	return;
}


function iFrameHeight(fId) {
	var ifm= document.getElementById(fId);
	var subWeb = document.frames ? document.frames[fId].document : ifm.contentDocument;
	if(ifm != null && subWeb != null) {
		ifm.height = subWeb.body.scrollHeight;
		ifm.width = subWeb.body.scrollWidth;
	}
}
/**
 * 根据渠道类型查询营业部
 * @param id
 * @param code
 * @param value
 */
function getDepartmentByChannel(value,loginId){
	var basePath =getRootPath();
	    $.ajax({
	    type : "post",
	    url : basePath+"/common/sysdict/getDepartmentByChannel.do",
	    dataType : "json",
	    data:{"type":value,"loginId":loginId},
	    cache:false,
	    success : function(data) {
	         var options="<option value='' selected='selected' >--请选择--</option>";
	            for(var i=0;i<data.length;i++){
	            	options += "<option value='"+data[i].orgId+"' >"+data[i].orgName+"</option>";
	            }
	            $("#orgId").html(options);
	        }
	  });
	}