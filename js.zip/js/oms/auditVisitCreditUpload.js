//------------实地征信------------------------

//js获取项目根路径，如： http://localhost:8083/oms
function getRootPath(){
    //获取当前网址，如： http://localhost:8083/uimcardprj/share/meun.jsp
    var curWwwPath=window.document.location.href;
    //获取主机地址之后的目录，如： uimcardprj/share/meun.jsp
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    //获取主机地址，如： http://localhost:8083
    var localhostPaht=curWwwPath.substring(0,pos);
    //获取带"/"的项目名，如：/uimcardprj
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    return(localhostPaht+projectName);
}
var basePath = getRootPath();//获取项目根路径



//==============================================附件上传====================================
// visitType 外访图片类型 ==VISIT_02 实地征信, VISIT_01 产调  加载图片
function initTheClassifiPics(applyId, visitType) {
    if (applyId == "") {
        return false;
    }
    $.ajax({
        type : "POST",
        url : basePath+ "/process/creditreport/getSurveyByApplyId.do",
        data : {
            "applyId" : applyId,
            "visitType" : visitType
        },
        success : function(data) {
            var obj = eval(data);
            var num = obj.length;
            var html = [];
            for ( var i = 0; i < num; i++) {
                var id = obj[i].id;// 附件ID
                var applyId = obj[i].applyId;// 申请单ID
                var type = "picid";// 所属类型
                var smaillFileName = obj[i].compressPath;// 缩略图全名称（带后缀）
                var bigFileName = obj[i].name;// 原图全名称（带后缀）
                var fileName = obj[i].fileName;// 图片名称（不带后缀）
                var picPath = obj[i].picPath;// 图片路径
                var suffix = smaillFileName.substring(smaillFileName.indexOf(".") + 1).toLowerCase();// 图片后缀
                var imgSrc = picPath.substring(1);

                if(suffix=='pdf' || suffix=='zip' || suffix=='rar' || suffix=='xlsx' || suffix=='xls' || suffix=='docx' || suffix=='doc'){
                    var defaultPicPath = "";
                    if(suffix=='docx' || suffix=='doc'){
                        defaultPicPath = basePath+"/img/oms/word.png";
                    }else if(suffix=='xlsx' || suffix=='xls'){
                        defaultPicPath = basePath+"/img/oms/excel.png";
                    }else if(suffix=='zip' || suffix=='rar'){
                        defaultPicPath = basePath+"/img/oms/zip.png";
                    }else if(suffix=='pdf'){
                        defaultPicPath = basePath+"/img/oms/pdf.png";															
                    }
                    html.push("<input type='checkbox' id='"+bigFileName+"' name='"+type+"' value ='"+id+"' ><a href = '"+basePath+"/"+imgSrc+"/"+bigFileName+"' target='_blank'><img src='"+defaultPicPath+"' title='"+fileName+"' style = 'width:150px;height:150px;'/></a>");
                }else{
                    if(smaillFileName == null){
                        html.push("<input type='checkbox' id='"+bigFileName+"' name='"+type+"' value ='"+id+"' ><a href =  '"+basePath+"/"+imgSrc+"/"+bigFileName+"' target='_blank'><img src= '"+basePath+"/"+imgSrc+"/"+bigFileName+"' title='"+fileName+"' style = 'width:150px;height:150px;'/></a>");
                    }else{
                        html.push("<input type='checkbox' id='"+bigFileName+"' name='"+type+"' value ='"+id+"' ><a href =  '"+basePath+"/"+imgSrc+"/"+bigFileName+"' target='_blank'><img src= '"+basePath+"/"+imgSrc+"/"+bigFileName+"' title='"+fileName+"' style = 'width:150px;height:150px;'/></a>");
                    }
                }
                if((i+1)%4==0){
                    html.push("</br>");
                }
            }
            var photoid= "#photo_"+visitType;
            $(photoid).append(html.join(""));
        },
        error : function() {

        }
    });

}
// 加载图片数据
function initAllPics() {
	var applyId = $("#applyId").val(); 
    $(":file").each(function(){
        var fileClassifiCode = $(this).attr('id');
        initTheClassifiPics(applyId,fileClassifiCode);
    });
}

//var name = "${jsessionid}";
function startUpload() {
    $('#file_upload').uploadify('upload', '*');
}
//全选
function allSelect(id){
	$("#photo_"+id).find("input[name='picid']").prop('checked',true);
}
//反选
function revSelect(id){
	var selected = $("#photo_"+id+" input[type='checkbox']:checked");
	var unSelected = $("#photo_"+id+" input[type='checkbox']:not(:checked)");
	selected.prop('checked',false);
	unSelected.prop('checked',true);
}
// 删除图片
function deletePics(id,type) {
    if(type=='1'){
        var params = $("#auditCreditForm").serialize();
    }
    if(type=='2'){
        var params = $("#auditReportForm").serialize();
    }
    var applyId = $("#applyId").val();
    var needDeletePic = "";
    if($("#photo_"+id).find("input:checked").length<1){
    	return false;
    }
    var pics = [];
    $("#photo_"+id).find("input:checked").each(function(){                 
    	pics.push(this.value);
    });
    var temp='';
    for(var i=0;i<pics.length;i++){       
        temp=temp+"picid="+pics[i];
        if(i<pics.length-1){
        	temp=temp+'&';
        }
        
    }
  var r = window.confirm("您确定删除这些图片？");
  if(r==true){
      $.ajax({
          type: "get",
          url : basePath + "/process/creditreport/deletePicsByPicId.do",
          dataType: "html",
          data:encodeURI(temp),             
          cache: false,
          success: function(data, textStatus){
              alert("删除成功");
              var photoid= "#photo_"+id;
              $(photoid).html("");
              initTheClassifiPics($("#applyId").val(),id);
          }
      });
  } 
}

$(document).ready(function(){
    initAllPics();
});
