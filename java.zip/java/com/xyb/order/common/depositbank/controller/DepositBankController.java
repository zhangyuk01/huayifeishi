package com.xyb.order.common.depositbank.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.agreement.model.DepositBankResultDTO;
import com.xyb.order.common.agreement.model.ResultDTO;
import com.xyb.order.common.depositbank.model.BindCardNoticeDTO;
import com.xyb.order.common.depositbank.model.ClientInfoDTO;
import com.xyb.order.common.depositbank.model.DepositAccountToNoticeDTO;
import com.xyb.order.common.depositbank.model.SigningNotificationDTO;
import com.xyb.order.common.depositbank.model.UnbindNoticeDTO;
import com.xyb.order.common.depositbank.service.DepositBankService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * 存管银行相关功能出口
 *
 * @author xieqingyang
 * @date 2018/11/22 6:21 PM
 */
@Controller
@RequestMapping("/order/depositbank")
public class DepositBankController {

    private static final Logger logger = LoggerFactory.getLogger(DepositBankController.class);

    @Reference
    private DepositBankService depositBankService;

    @AutoValid
    @ApiOperation(value = "存管开户接口", response = RestResponse.class)
    @RequestMapping(value = "accountOpen", method = RequestMethod.POST)
    public Object accountOpen(@RequestBody @Valid ClientInfoDTO clientInfoDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositBankService.accountOpen(clientInfoDTO);
        } catch (Exception e) {
            logger.error("存管开户接口异常", e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "个人绑卡网关接口", response = RestResponse.class)
    @RequestMapping(value = "bindBankCard", method = RequestMethod.POST)
    public Object bindBankCard(@RequestBody @Valid ClientInfoDTO clientInfoDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositBankService.bindBankCard(clientInfoDTO);
        } catch (Exception e) {
            logger.error("个人绑卡接口异常", e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "解绑银行卡请求提交", response = RestResponse.class)
    @RequestMapping(value = "/unBindBankCardSubmit", method = RequestMethod.POST)
    public Object unBindBankCardSubmit(@RequestBody @Valid ClientInfoDTO clientInfoDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositBankService.unBindBankCardSubmit(clientInfoDTO);
        } catch (Exception e) {
            logger.error("解绑银行卡请求提交", e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "重置电子账户交易密码", response = RestResponse.class)
    @RequestMapping(value = "accountReqwd", method = RequestMethod.POST)
    public Object accountReqwd(@RequestBody @Valid ClientInfoDTO clientInfoDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositBankService.accountReqwd(clientInfoDTO);
        } catch (Exception e) {
            logger.error("重置电子账户交易密码接口异常", e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "借款人放款手续费和还款金额签约", response = RestResponse.class)
    @RequestMapping(value = "loanSignContract", method = RequestMethod.POST)
    public Object loanSignContract(@RequestBody @Valid ClientInfoDTO clientInfoDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositBankService.loanSignContract(clientInfoDTO);
        } catch (Exception e) {
            logger.error("借款人放款手续费和还款金额签约接口异常", e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "个人绑卡注册通知", response = DepositBankResultDTO.class)
    @PostMapping(value = "/openapi/depositAccountToNotice")
    public Object depositAccountToNotice(@RequestBody @Valid ResultDTO<DepositAccountToNoticeDTO> resultDTO, BindingResult result) {
        RestResponse response = depositBankService.depositAccountToNotice(resultDTO);
        return new ResponseEntity<>(response.getData(), response.getHttpcode());
    }

	@AutoValid
	@ApiOperation(value = " 解绑卡通知", response = DepositBankResultDTO.class)
	@RequestMapping(value = "/openapi/unBindNotice", method = RequestMethod.POST)
	public Object unBindNotice(@RequestBody ResultDTO<UnbindNoticeDTO> resultDTO) {
		RestResponse response = depositBankService.unBindNotice(resultDTO);
		 return new ResponseEntity<>(response.getData(), response.getHttpcode());

    }

    @AutoValid
    @ApiOperation(value = "个人绑卡网关通知接口", response = DepositBankResultDTO.class)
    @RequestMapping(value = "/openapi/bindCardNotice", method = RequestMethod.POST)
    public Object bindCardNotice(@RequestBody @Valid ResultDTO<BindCardNoticeDTO> noticeDto, BindingResult result) {
        RestResponse response = depositBankService.bindCardNotice(noticeDto);
        return new ResponseEntity<>(response.getData(), response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "异步通知签约结果", response = DepositBankResultDTO.class)
    @PostMapping(value = "/openapi/signingnotification")
    public Object signingNotification(@RequestBody @Valid ResultDTO<SigningNotificationDTO> resultDTO, BindingResult result) {
        RestResponse response = depositBankService.signingNotification(resultDTO);
        return new ResponseEntity<>(response.getData(), response.getHttpcode());
    }

}
