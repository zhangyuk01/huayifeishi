package com.xyb.order.common.message.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.fr.third.v2.org.apache.poi.hssf.usermodel.HSSFWorkbook;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Cell;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Row;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Sheet;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Workbook;
import com.fr.third.v2.org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.message.model.*;
import com.xyb.order.common.message.service.MessageService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.FileUtils;
import com.xyb.order.common.util.StringUtils;
import com.xyb.service.FastFileStorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 消息相关
 * @author         xieqingyang
 * @date           2018/6/26 下午1:56
*/
@Controller
@RequestMapping("/order/message")
@Api(value = "消息相关接口",description = "消息相关接口")
public class MessageController {

    private static final Logger log = LoggerFactory.getLogger(MessageController.class);
    @Reference
    private MessageService messageService;
    @Autowired
    private FastFileStorageService fastFileStorageService;

    /**——------——————————————————————————————————————————————————短信验证码————————————————————————————————————————————————————————————————————*/
    @ApiOperation(value = "发送短信验证码",response = RestResponse.class)
    @AutoValid
    @RequestMapping(value = "openapi/getMessageCode",method = RequestMethod.POST)
    public Object getMessageCode(@RequestBody @Valid SendMessageVerificationDTO sendMessageVerificationDTO, BindingResult result){
        RestResponse response;
        try {
            response = messageService.getMessageCode(sendMessageVerificationDTO);
        } catch (Exception e) {
            log.error("发送短信验证码异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    /**——------——————————————————————————————————————————————————app推送消息————————————————————————————————————————————————————————————————————*/
    @AutoValid
    @ApiOperation(value = "存储推送消息唯一标识",response = RestResponse.class)
    @RequestMapping(value = "addDeviceToken",method = {RequestMethod.GET,RequestMethod.POST})
    public Object addDeviceToken(@RequestBody @Valid DeviceTokenDTO deviceTokenDTO,BindingResult result){
        RestResponse response;
        try {
            response = messageService.addDeviceToken(deviceTokenDTO);
        }catch (Exception e){
            log.error("存储推送消息唯一标识异常：",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "pc消息列表",response = NoticeListVO.class)
    @RequestMapping(value = "queryNoticeList/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object queryNoticeList(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid NoticeQueryDTO noticeQueryDTO,BindingResult result){
        RestResponse response;
        try {
            response = messageService.queryNoticeList(pageNumber,pageSize,noticeQueryDTO);
        }catch (Exception e){
            log.error("消息列表异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "查询消息详情数据",response = AppNoticeTemplateDO.class)
    @RequestMapping(value = "getNoticeInfo/{templateId}",method = RequestMethod.GET)
    public Object getNoticeInfo(@PathVariable Long templateId){
        RestResponse response;
        try {
            response = messageService.getNoticeInfo(templateId);
        }catch (Exception e){
            log.error("查询消息详情数据异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @AutoValid
    @RepeatTokenValid
    @ApiOperation(value = "新增推送消息",response = RestResponse.class)
    @RequestMapping(value = "addNoticeInfo",method = RequestMethod.POST)
    public Object addNoticeInfo(@RequestBody @Valid AppNoticeTemplateAddDTO appNoticeTemplateAddDTO,BindingResult result){
        RestResponse response;
        try {
            response = messageService.addNoticeInfo(appNoticeTemplateAddDTO);
        }catch (Exception e){
            log.error("新增推送消息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,HttpStatus.OK);
    }

    @ApiOperation(value = "撤销消息",response = RestResponse.class)
    @RequestMapping(value = "revokeNotice/{templateId}",method = RequestMethod.GET)
    public Object revokeNotice(@PathVariable Long templateId){
        RestResponse response;
        try {
            response = messageService.revokeNotice(templateId);
        }catch (Exception e){
            log.error("撤销消息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,HttpStatus.OK);
    }

    @ApiOperation(value = "添加消息附件上传",response = RestResponse.class)
    @RequestMapping(value = "uploadMessageFile/{appType}",method = {RequestMethod.GET,RequestMethod.POST})
    public Object uploadMessageFile(@PathVariable("appType") Long appType,HttpServletRequest request){
        RestResponse response;
        try {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
            MultipartFile file = multipartHttpServletRequest.getFile("file");
            // -- 获取文件属性
            Long fileSize = file.getSize();
            String fileFullName = file.getOriginalFilename();
            // -- 判断文件是否超过规定大小
            if (fileSize > 5242880) {
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription("文件大小不可超出5M，上传失败!");
                return new ResponseEntity<RestResponse>(response,response.getHttpcode());
            }
            InputStream is = file.getInputStream();
            Workbook wb = null;
            // -- 判断文件类型是否符合标准
            if(fileFullName.endsWith(".xls")) {
                wb = new HSSFWorkbook(is);
            }else if(fileFullName.endsWith(".xlsx")) {
                wb = new XSSFWorkbook(is);
            }else {
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription("文件格式错误!");
                return new ResponseEntity<RestResponse>(response,response.getHttpcode());
            }
            // -- 手机号集合
            List<String> phones = new ArrayList<>();
            // 创建工作表sheet
            Sheet sheet = wb.getSheetAt(0);
            int rows = sheet.getPhysicalNumberOfRows();
            if (rows <= 1){
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription("模版错误!");
                return new ResponseEntity<RestResponse>(response,response.getHttpcode());
            }else {
                Row row = sheet.getRow(0);
                Cell cell = row.getCell(0);
                if (!"手机号码".equals(cell.getStringCellValue()==null?"":cell.getStringCellValue().trim().replace(" ",""))){
                    response = new RestResponse(MsgErrCode.FAIL);
                    response.setDescription("模版错误!");
                    return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                }else {
                    // 获取表头的单元格个数
                    int cells = 1;
                    //从第X行开始获取手机号
                    for(int i = 2 ;i < rows; i++) {
                        // 创建对象
                        row = sheet.getRow(i);
                        int index =0;
                        while(index < cells){
                            cell = row.getCell(index);
                            if(null == cell){
                                cell = row.createCell(index);
                            }
                            cell.setCellType(Cell.CELL_TYPE_STRING);
                            String value =  (null == cell.getStringCellValue()?"":cell.getStringCellValue().trim().replace(" ",""));
                            if (!FileUtils.isNumeric(value) || value.length() != 11){
                                response = new RestResponse(MsgErrCode.FAIL);
                                response.setDescription("文件内包含非法手机号，上传失败!");
                                return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                            }
                            if (StringUtils.isNotNullAndEmpty(value)) {
                                phones.add(value);
                            }
                            index++;
                        }
                    }
                    // -- 判断文件内是否空数据
                    if (phones.size() < 1){
                        response = new RestResponse(MsgErrCode.FAIL);
                        response.setDescription("未检测到数据，上传失败!");
                        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                    }
                    // -- 判断文件内是否包含未存在手机号
                    int count;
                    if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appType)){
                        count = messageService.getClientUserCount(phones);
                    }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appType)){
                        count = messageService.getUserCount(phones);
                    }else {
                        response = new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
                        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                    }
                    if (count == 0){
                        response = new RestResponse(NativeMsgErrCode.FILE_CHECK);
                        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                    }else {
                        // -- 保存文件
                        ResultFileInfo uploadFile = fastFileStorageService.uploadFile(file, null);
                        if (count == phones.size()){
                            response = new RestResponse(MsgErrCode.SUCCESS);
                        }else {
                            response = new RestResponse(NativeMsgErrCode.FILE_CHECK_VALID);
                            response.setDescription("文件内包含"+(phones.size()-count)+"个非注册用户手机号!");
                        }
                        // -- 图片全路径
                        String fullAllPath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");
                        response.setData(fullAllPath);
                        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("添加消息附件上传异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            return new ResponseEntity<RestResponse>(response,response.getHttpcode());
        }
    }

    @ApiOperation("测试")
    @RequestMapping(value = "openapi/test/{phone}/{code}",method = RequestMethod.GET)
    public Object test(@PathVariable("phone") String phone, @PathVariable("code") String code){
        RestResponse response = messageService.test(phone,code);
        return new ResponseEntity<RestResponse>(response,HttpStatus.OK);
    }

    /**——------——————————————————————————————————————————————————app查询消息————————————————————————————————————————————————————————————————————*/
    @AutoValid
    @ApiOperation(value = "查询app消息首页（公告、消息）信息",response = AppMessageVO.class)
    @RequestMapping(value = "getMessageInFo",method = RequestMethod.POST)
    public Object getMessageInFo(@RequestBody @Valid AppMessageQueryDTO appMessageQueryDTO,BindingResult result){
        RestResponse response;
        try {
            response = messageService.getMessageInFo(appMessageQueryDTO);
        }catch (Exception e){
            log.error("查询app消息首页（公告、消息）信息异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,HttpStatus.OK);
    }

    @AutoValid
    @ApiOperation(value = "查询app消息列表",response = AppMessageListInFoVO.class)
    @RequestMapping(value = "getMessageList",method = RequestMethod.POST)
    public Object getMessageList(@RequestBody @Valid AppMessageQueryDTO appMessageQueryDTO,BindingResult result){
        RestResponse response;
        try {
            response = messageService.getMessageList(appMessageQueryDTO);
        }catch (Exception e){
            log.error("查询app消息列表异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,HttpStatus.OK);
    }
}
