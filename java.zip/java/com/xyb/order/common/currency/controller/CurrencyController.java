package com.xyb.order.common.currency.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.auth.bulletin.model.Bulletin;
import com.xyb.order.common.currency.model.DropDownBoxListDTO;
import com.xyb.order.common.currency.model.ProcessLogDO;
import com.xyb.order.common.currency.model.QueryProductLimitByProductIdAndOrgIdDTO;
import com.xyb.order.common.currency.model.QueryTeanManagerDTO;
import com.xyb.order.common.currency.service.CurrencyService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * 通用接口
 * @author         xieqingyang
 * @date           2018/10/18 1:58 PM
*/
@Controller
@RequestMapping("/order/currency")
public class CurrencyController {

    private static final Logger log = LoggerFactory.getLogger(CurrencyController.class);

    @Reference
    private CurrencyService currencyService;

    @ApiOperation(value = "获取令牌环",response = RestResponse.class)
    @RepeatTokenFactory
    @RequestMapping(value = "getTken",method = RequestMethod.GET)
    public Object getTken(){
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "获取流程日志",response = ProcessLogDO.class)
    @RequestMapping(value = "queryProcessLog/{mainId}",method = RequestMethod.GET)
    public Object queryProcessLog(@PathVariable Long mainId){
        RestResponse response;
        try {
            response = this.currencyService.queryProcessLog(mainId);
        } catch (Exception e) {
            log.error("获取流程日志异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "获取下拉框")
    @RequestMapping(value = "queryDropDownBox",method = RequestMethod.POST)
    public Object queryDropDownBox(@RequestBody @Valid DropDownBoxListDTO dropDownBoxDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.currencyService.queryDropDownBox(dropDownBoxDTO);
        } catch (Exception e) {
            log.error("查询下拉框异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "根据营业部和产品查询产品期限")
    @RequestMapping(value = "queryProductLimitByOrg",method = RequestMethod.POST)
    public Object queryProductLimitByOrg(@RequestBody @Valid QueryProductLimitByProductIdAndOrgIdDTO dto, BindingResult result){
        RestResponse response;
        try {
            response = this.currencyService.queryProductLimitByOrg(dto);
        } catch (Exception e) {
        	log.error("查询产品期限异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "获取公告",response = Bulletin.class)
    @RequestMapping(value = "findBulletin/{pageNumber}/{pageSize}",method = RequestMethod.GET)
    public Object findBulletin(@PathVariable Integer pageNumber, @PathVariable Integer pageSize){
        RestResponse response;
        try {
            response = currencyService.findBulletin(pageNumber, pageSize);
        }catch (Exception e){
            log.error("获取公告接口异常：",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "根据机构ID查询团队经理")
    @RequestMapping(value = "findTeamManagerByOrgId",method = RequestMethod.POST)
    public Object findTeamManagerByOrgId(@RequestBody QueryTeanManagerDTO queryTeanManagerDTO){
        RestResponse response;
        try {
            response = currencyService.findTeamManagerByOrgId(queryTeanManagerDTO);
        }catch (Exception e){
            log.error("根据机构ID查询团队经理异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }
}
