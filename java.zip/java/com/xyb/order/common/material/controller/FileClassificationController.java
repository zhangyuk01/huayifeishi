package com.xyb.order.common.material.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.beiming.kun.framework.annotation.AutoValid;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.material.model.*;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.xyb.auth.user.model.User;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.common.material.service.FileClassificationService;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.ImageNameUtil;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.service.FastFileStorageService;
import com.xyb.util.SessionUtil;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * @ClassName FileClassificationController(文件上传)
 * @author ZhangYu
 * @date 2018年4月16号
 */

@Controller
@RequestMapping("/order/material")
public class FileClassificationController{

	private final static Logger logger = Logger.getLogger(FileClassificationController.class);
	@Reference
	private FileClassificationService fileClassificationService;
	@Reference
	private FileDataInfoService fileDataInfoService;
	@Autowired
	private FastFileStorageService fastFileStorageService;

	/**
	 * PC端图片上传
	 * @param isBatch
	 * @param applyId
	 * @param fileCode
	 * @return
	 */
    @RequestMapping(value="/uploadPcImageFile/{isBatch}/{applyId}/{fileCode}",method = {RequestMethod.POST,RequestMethod.GET})
	public Object uploadPcImageFile(@PathVariable String isBatch, @PathVariable Long applyId, @PathVariable String fileCode,HttpServletRequest request){
		System.out.println("开始");
		String thisMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
		List<MultipartFile> files = multipartHttpServletRequest.getFiles("files");
			logger.info(thisMethodName + ":start");
			User user = SessionUtil.getLoginUser(User.class);
			Long userId = user.getId();
			List<FileDataInfo> fileDataInfoList= new ArrayList<FileDataInfo>();//用来返回图片信息
			/**批量上传**/
			if (TableConstant.T_IMAGE_BATCH.equals(isBatch)) {
				logger.info("===========================pc端批量上传start===============================");
				for (MultipartFile mf: files) {
					Long imageSize = mf.getSize();
					String fileFullName = mf.getOriginalFilename();
					String fileName = fileFullName.substring(0,fileFullName.lastIndexOf("."));
					FileDataInfo fileDataInfo = new FileDataInfo();
					fileDataInfo.setApplyId(applyId);
					fileDataInfo.setFileName(fileFullName);
					fileDataInfo.setName(fileName);
					if (imageSize <= 5242880) {
						Map<String, Object> analyzeFileMap = ImageNameUtil.analyzeFileName(fileName);
						String fileClassificationCode=(String)analyzeFileMap.get("fileClassificationCode");
						Long fileClassificationId = this.fileClassificationService.getImageIdByCode(fileClassificationCode);
						fileDataInfo.setFileClassificationId(fileClassificationId);
						if("0".equals(analyzeFileMap.get("errorType"))){
							Integer sort = (Integer)analyzeFileMap.get("sort");
							/**查询缓存**/
							if (RedisUtil.get(RedisConstant.IMAGE_APPLY + String.valueOf(applyId)+"_"+fileClassificationCode+"_"+fileFullName) != null) {
								fileDataInfo.setUploadState(TableConstant.T_IMAGE_NAME_AGAIN);//缓存中存在图片信息
							}else{
								int count = this.fileDataInfoService.fileIsExit(fileFullName, fileClassificationId, applyId);
								if(count>0){
									fileDataInfo.setUploadState(TableConstant.T_IMAGE_NAME_AGAIN);//数据库中存在图片信息
								}else{
									try {
										/**1.将文件上传到服务器*/
										logger.info("==========fast 开启===============");
										ResultFileInfo uploadFile = fastFileStorageService.uploadFile(mf, null);
										logger.info("==========fast 结束===============");
										String group = uploadFile.getGroup();//图片组
										String fullAllPath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");//图片全路径
										/**2.保存图片信息到数据库*/
										fileDataInfo.setPicGroup(group);
										fileDataInfo.setPicPath(fullAllPath);
										fileDataInfo.setSort(sort);
										fileDataInfo.setOperatorId(userId);
										fileDataInfo.setCreateUser(userId);
										fileDataInfo.setModifyUser(userId);
										fileDataInfo.setIsDel(SysDictEnum.YES.getCode());
										fileDataInfo.setCreateTime(new Date());
										fileDataInfo = this.fileDataInfoService.addFileDataInfo(fileDataInfo);
										fileDataInfo.setIsDel(SysDictEnum.YES.getCode());
										/**3.添加图片信息到缓存*/
										String key = RedisConstant.IMAGE_APPLY + String.valueOf(applyId)+"_"+fileClassificationCode+"_"+fileFullName;
										String bean2json = JsonUtil.object2json(fileDataInfo);
										RedisUtil.setex(key, RedisConstant.IMAGE_CACHE_TIME, bean2json);
										fileDataInfo.setUploadState(TableConstant.T_IMAGE_SUCCESS);
									}catch(Exception e){
										logger.error("-----------上传图片错误---------",e);
										fileDataInfo.setUploadState(TableConstant.T_IMAGE_FAILED);
									}
								}
							}
						}else{
							fileDataInfo.setUploadState(TableConstant.T_IMAGE_NAME_WRONG);
						}
					}else{
						fileDataInfo.setUploadState(TableConstant.T_IMAGE_SIZE);
					}
					fileDataInfoList.add(fileDataInfo);
				}
			}
			/**单独上传&&多张图片上传相同类别下**/
			else{
				logger.info("===========================pc端非批量上传start===============================");
				for (MultipartFile mf: files) {
					long imageSize = mf.getSize();
					String fileFullName = mf.getOriginalFilename();
					String fileName=fileFullName.substring(0,fileFullName.lastIndexOf("."));

					FileDataInfo fileDataInfo = new FileDataInfo();
					fileDataInfo.setApplyId(applyId);
					fileDataInfo.setFileName(fileFullName);
					fileDataInfo.setName(fileName);
					if (imageSize <= 5242880) {
						String fileClassificationCode=fileCode;
						Long fileClassificationId = this.fileClassificationService.getImageIdByCode(fileClassificationCode);
						fileDataInfo.setFileClassificationId(fileClassificationId); 
						/**查询缓存**/
						if (RedisUtil.get(RedisConstant.IMAGE_APPLY + String.valueOf(applyId)+"_"+fileClassificationCode+"_"+fileFullName) != null) {
							fileDataInfo.setUploadState(TableConstant.T_IMAGE_NAME_AGAIN);//缓存中存在图片信息
						}else{
							int count = this.fileDataInfoService.fileIsExit(fileFullName, fileClassificationId, applyId);
							if(count>0){
								fileDataInfo.setUploadState(TableConstant.T_IMAGE_NAME_AGAIN);//数据库中存在图片信息
							}else{
								try{
									/**1.将文件上传到服务器*/
									logger.info("==========fast 开启===============");
									ResultFileInfo uploadFile = fastFileStorageService.uploadFile(mf, null);
									logger.info("==========fast 结束===============");
									String group = uploadFile.getGroup();//图片组
									String fullAllPath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");//图片全路径
									Map<String, Object> paraMap = new HashMap<>();
									paraMap.put("applyId", applyId);
									paraMap.put("fileCode", fileCode);
									int maxSort=fileDataInfoService.findFileDataInfoMaxSort(paraMap);
									fileDataInfo.setSort(maxSort+1);
									fileDataInfo.setPicGroup(group);
									fileDataInfo.setPicPath(fullAllPath);
									fileDataInfo.setOperatorId(userId);
									fileDataInfo.setCreateUser(userId);
									fileDataInfo.setModifyUser(userId);
									fileDataInfo.setIsDel(SysDictEnum.YES.getCode());
									fileDataInfo.setCreateTime(new Date());
									/**2.保存图片信息到数据库*/
									fileDataInfo = fileDataInfoService.addFileDataInfo(fileDataInfo);
									fileDataInfo.setIsDel(SysDictEnum.YES.getCode());
									/**3.添加图片信息到缓存*/
									String key = RedisConstant.IMAGE_APPLY + String.valueOf(applyId)+"_"+fileClassificationCode+"_"+fileFullName;
									String bean2json = JsonUtil.object2json(fileDataInfo);
									RedisUtil.setex(key, RedisConstant.IMAGE_CACHE_TIME, bean2json);
									fileDataInfo.setUploadState(TableConstant.T_IMAGE_SUCCESS);
								}catch(Exception e){
									logger.error("-----------上传图片错误---------",e);
									fileDataInfo.setUploadState(TableConstant.T_IMAGE_FAILED);
								}
							}
						}
					}else{
						fileDataInfo.setUploadState(TableConstant.T_IMAGE_SIZE);
					}
					fileDataInfoList.add(fileDataInfo);
				}
			}
			logger.info("=============================pc端上传图片结束===========================");
			RestResponse response =  new RestResponse(MsgErrCode.SUCCESS, fileDataInfoList);
			return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
    
    /**
     * APP端图片上传
     * @param fileUploadAppDTO
     * @throws Exception 
     */
    @AutoValid
    @ApiOperation(value = "app上传图片")
    @RequestMapping(value="/uploadFileImage",method = {RequestMethod.POST,RequestMethod.GET})
	public Object uploadAppImageFile(@RequestBody @Valid FileUploadAppDTO fileUploadAppDTO, BindingResult result) throws Exception{
    	RestResponse response;
    	try {
			response = this.fileDataInfoService.uploadAppImageFile(fileUploadAppDTO.getImageFiles(), fileUploadAppDTO.getApplyId(), fileUploadAppDTO.getFileCode());
		}catch (Exception e){
    		logger.error("APP端图片上传接口异常",e);
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "查询图片通用接口",response = FileDateListVO.class)
    @RequestMapping(value = "queryFileDataInfoList",method = RequestMethod.POST)
    public Object queryFileDataInfoList(@RequestBody @Valid FileSeeDTO fileSeeDTO, BindingResult result){
    	RestResponse response;
    	try {
    		response = fileDataInfoService.queryFileDataInfoList(fileSeeDTO);
		}catch (Exception e){
    		logger.error("查询图片接口异常",e);
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@AutoValid
	@ApiOperation(value = "删除图片接口",response = FileDateListVO.class)
	@RequestMapping(value = "fileDataDel",method = RequestMethod.POST)
	public Object fileDataDel(@RequestBody @Valid FileDataDelDTO fileDataDelDTO, BindingResult result){
		RestResponse response;
		try {
			response = fileDataInfoService.fileDataDel(fileDataDelDTO);
		}catch (Exception e){
			logger.error("删除图片接口异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "根据图片地址删除图片接口",response = RestResponse.class)
	@RequestMapping(value = "delFile",method = RequestMethod.GET)
	public Object delFile(@RequestParam(value = "filePath") String filePath){
		RestResponse response;
		try {
			response = fileDataInfoService.delFile(filePath);
		}catch (Exception e){
			logger.error("根据图片地址删除图片接口异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
}
