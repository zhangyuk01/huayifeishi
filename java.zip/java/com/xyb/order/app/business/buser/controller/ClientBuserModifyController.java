package com.xyb.order.app.business.buser.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.business.buser.service.ClinetBuserModifyService;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePhoneDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * @ClassName ClientBuserModifyController(B端用户修改手机号密码)
 * @author ZhangYu
 * @date 2018年6月25号
 */

@Controller
@RequestMapping("order/bapp/clinetBuserModify")
public class ClientBuserModifyController {
	private static final Logger log = LoggerFactory.getLogger(ClientBuserModifyController.class);
	@Reference
	private ClinetBuserModifyService clinetBuserModifyService; 
	
	
	@AutoValid
	@ApiOperation(value = "B端用户修改手机号",response = RestResponse.class)
	@RequestMapping(value = "updatePhone",method = RequestMethod.POST)
	public Object updatePhone(@RequestBody @Valid ClientUserUpdatePhoneDTO clientUserUpdatePhoneDTO, BindingResult result){
		RestResponse response;
		try {
			response = clinetBuserModifyService.updatePhone(clientUserUpdatePhoneDTO);
		}catch (Exception e){
			e.printStackTrace();
			log.error("B端用户修改手机号异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}
	
	@AutoValid
    @ApiOperation(value = "B端用户修改密码",response = RestResponse.class)
    @RequestMapping(value = "updatePassword",method = RequestMethod.POST)
    public Object updatePassword(@RequestBody @Valid ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO, BindingResult result){
        RestResponse response;
        try {
            response = clinetBuserModifyService.updatePassword(clientUserUpdatePasswordDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("B端用户修改密码异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
	
	@ApiOperation(value = "B端用户忘记密码",response = RestResponse.class)
	@AutoValid
	@RequestMapping(value = "openapi/cAppUserForgerPassword",method = RequestMethod.POST)
	public Object forgetPassword(@RequestBody @Valid ClientUserUpdateDTO clientUserDTO, BindingResult result){
		RestResponse response;
		try {
			response = clinetBuserModifyService.forgetPassword(clientUserDTO);
		}catch (Exception e){
			e.printStackTrace();
			log.error("B端用户忘记密码异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	

}
