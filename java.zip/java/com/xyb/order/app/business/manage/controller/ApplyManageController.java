package com.xyb.order.app.business.manage.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.business.manage.model.AppBillInfoDO;
import com.xyb.order.app.business.manage.model.AppBillInfoDetailDO;
import com.xyb.order.app.business.manage.model.AppCustomerInfoDO;
import com.xyb.order.app.business.manage.model.ApplyBillInfoDTO;
import com.xyb.order.app.business.manage.model.ApplyCustomerInfoDTO;
import com.xyb.order.app.business.manage.service.ApplyManageService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * @ClassName ApplyManageController
 * @author ZhangYu
 * @date 2018年6月13号
 */
@Controller
@RequestMapping("order/capp/manage")
public class ApplyManageController {
	  private static final Logger log = LoggerFactory.getLogger(ApplyManageController.class);

	  @Reference
	  private ApplyManageService applyManageService;
	  
	  @ApiOperation(value = "获取客户经理的客户信息",response = AppCustomerInfoDO.class)
	  @RequestMapping(value = "getCustomerInfos", method={RequestMethod.POST, RequestMethod.GET})
	  public Object getCustomerInfos(@RequestBody ApplyCustomerInfoDTO applyCustomerInfoDTO){
		  RestResponse response;
		  try {
			  response = this.applyManageService.getCustomerList(applyCustomerInfoDTO);
		  } catch (Exception e) {
			  e.printStackTrace();
			  log.error("获取客户经理客户信息错误:"+e);
			  response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		  }
		  return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	  }

	  @ApiOperation(value = "获取客户经理的申请单信息",response = AppBillInfoDO.class)
	  @RequestMapping(value = "getApplyBillInfos", method={RequestMethod.POST, RequestMethod.GET})
	  public Object getApplyBillInfos(@RequestBody ApplyBillInfoDTO applyBillInfoDTO) {
		  RestResponse response;
		  try {
			  response = this.applyManageService.getApplyBillInfoList(applyBillInfoDTO);
		  } catch (Exception e) {
			  e.printStackTrace();
			  log.error("获取客户经理的申请单信息错误:"+e);
			  response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		  }
		  return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	  }

	  @ApiOperation(value = "获取客户经理的申请单详情信息",response = AppBillInfoDetailDO.class)
	  @RequestMapping(value = "getApplyBillDetailInfo/{applyId}", method={RequestMethod.POST, RequestMethod.GET})
	  public Object getApplyBillDetailInfo(@PathVariable Long applyId){
		  RestResponse response;
		  try {
			response = this.applyManageService.getApplyBillDetailInfo(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取客户经理的申请单详情信息错误:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		  return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	  }


}
