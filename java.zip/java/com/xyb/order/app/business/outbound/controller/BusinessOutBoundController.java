package com.xyb.order.app.business.outbound.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.business.outbound.model.*;
import com.xyb.order.app.business.outbound.service.BusinessOutBoundService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.controller
 * @description :
 * @createDate : 2018/6/13 10:44
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("order/app/outbound")
public class BusinessOutBoundController {

    private static final Logger log = LoggerFactory.getLogger(BusinessOutBoundController.class);

    @Reference
    private BusinessOutBoundService businessOutBoundService;

    @ApiOperation(value = "获取外访列表")
    @RequestMapping(value = "getBusinessOutBoundList",method = RequestMethod.POST)
    public Object getBusinessOutBoundList(){
        RestResponse  response;
        try {
            response = businessOutBoundService.getBusinessOutBoundList();
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取外访列表接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取客户基本信息")
    @RequestMapping(value = "getBusinessClientInfo/{applyMainId}",method = RequestMethod.POST)
    public Object getBusinessClientInfo(@PathVariable Long applyMainId){
        RestResponse  response;
        try {
            response   =  businessOutBoundService.getBusinessClientInfo(applyMainId);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取客户基本信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取工作信息")
    @RequestMapping(value = "getBusinessJobInfo/{visitMainId}/{applyMainId}",method = RequestMethod.POST)
    public Object getBusinessJobInfo(@PathVariable Long visitMainId,@PathVariable Long applyMainId){
        RestResponse  response;
        try {
            response   =  businessOutBoundService.getBusinessJobInfo(visitMainId,applyMainId);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取工作信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取家庭信息")
    @RequestMapping(value = "getBusinessFamilyInfo/{visitMainId}/{applyMainId}",method = RequestMethod.POST)
    public Object getBusinessFamilyInfo(@PathVariable Long visitMainId,@PathVariable Long applyMainId){
        RestResponse  response;
        try {
            response =  businessOutBoundService.getBusinessFamilyInfo(visitMainId,applyMainId);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取家庭信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取经营信息")
    @RequestMapping(value = "getBusinessManagermentInfo/{visitMainId}/{applyMainId}",method = RequestMethod.POST)
    public Object getBusinessManagermentInfo(@PathVariable Long visitMainId,@PathVariable Long applyMainId){
        RestResponse  response;
        try {
            response =  businessOutBoundService.getBusinessManagermentInfo(visitMainId,applyMainId);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取经营信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取产调信息")
    @RequestMapping(value = "getBusinessPropertySurveyInfo/{applyId}",method = RequestMethod.POST)
    public  Object getBusinessPropertySurveyInfo(@PathVariable Long applyId){
        RestResponse  response;
        try {
            response  =  businessOutBoundService.getBusinessPropertySurveyInfo(applyId);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取产调信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "修改新增工作信息")
    @RequestMapping(value = "updateOrAddBusinessJobInfo",method = RequestMethod.POST)
    public Object updateOrAddBusinessJobInfo(@RequestBody @Valid BusinessOutBoundJobInfoDTO businessOutBoundJobInfoDTO, BindingResult result){
        RestResponse  response;
        try {
            response  =  businessOutBoundService.updateOrAddBusinessJobInfo(businessOutBoundJobInfoDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("修改新增工作信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "修改新增家庭信息")
    @RequestMapping(value = "updateOrAddBusinessFamilyInfo",method = RequestMethod.POST)
    public Object updateOrAddBusinessFamilyInfo(@RequestBody @Valid BusinessOutBoundFamilyInfoDTO businessOutBoundFamilyInfoDTO, BindingResult result){
        RestResponse  response;
        try {
            response   =  businessOutBoundService.updateOrAddBusinessFamilyInfo(businessOutBoundFamilyInfoDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("修改新增家庭信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "修改新增经营信息")
    @RequestMapping(value = "updateOrAddBusinessManagermentInfo",method = RequestMethod.POST)
    public Object updateOrAddBusinessManagermentInfo(@RequestBody @Valid BusinessOutBoundManagermentInfoDTO businessOutBoundManagermentInfoDTO, BindingResult result){
        RestResponse  response;
        try {
            response =  businessOutBoundService.updateOrAddBusinessManagermentInfo(businessOutBoundManagermentInfoDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("修改新增经营信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "修改新增产调信息,触发提交流程")
    @RequestMapping(value = "updateOrAddBusinessPropertySurveyInfo",method = RequestMethod.POST)
    public Object updateOrAddBusinessPropertySurveyInfo(@RequestBody @Valid BusinessOutBoundPropertySurveyDTO businessOutBoundPropertySurveyDTO, BindingResult result){
        RestResponse  response;
        try {
            response  =  businessOutBoundService.updateOrAddBusinessPropertySurveyInfo(businessOutBoundPropertySurveyDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("修改新增产调信息接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "外访经营提交")
    @RequestMapping(value = "businessManagermentSubmit",method = RequestMethod.POST)
    public Object businessManagermentSubmit(@RequestBody @Valid BusinessOutBoundManagermentSubmitDTO businessOutBoundManagermentSubmitDTO,BindingResult result){
        RestResponse  response;
        try {
            response  =  businessOutBoundService.businessManagermentSubmit(businessOutBoundManagermentSubmitDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("外访经营提交接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

}