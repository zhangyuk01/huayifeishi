package com.xyb.order.app.client.personinfo.controller;

import com.beiming.kun.framework.annotation.AutoValid;
import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.model.JobInfoDTO;
import com.xyb.order.app.client.personinfo.model.PrivateDO;
import com.xyb.order.app.client.personinfo.model.PrivateDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.personinfo.service.ApplyJobService;

import javax.validation.Valid;

/**
 * @ClassName ApplyJobController
 * @author ZhangYu
 * @date 2018年5月22号
 */
@Controller
@RequestMapping("order/capp/job")
public class ApplyJobController {

	private static final Logger log = LoggerFactory.getLogger(ApplyJobController.class);		
	@Reference
	private ApplyJobService applyJobService;

	@ApiOperation(value = "个人工作信息",response = JobInfoDO.class)
	@RequestMapping(value = "getJobInfo", method={RequestMethod.POST, RequestMethod.GET})
	public Object getJobInfo(){
		RestResponse response;
		try {
			 response = this.applyJobService.getApplyJobInfo();
		} catch (Exception e) {
            log.error("个人基本信息查询报错",e);
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "个人私营信息",response = PrivateDO.class)
	@RequestMapping(value = "getPrivateInfo", method={RequestMethod.POST, RequestMethod.GET})
	public Object getPrivateInfo(){
		RestResponse response;
		try {
			 response = this.applyJobService.getPrivateInfo();
		} catch (Exception e) {
            log.error("个人私营信息报错",e);
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@AutoValid
	@ApiOperation(value = "个人工作信息保存",response = RestResponse.class)
	@RequestMapping(value = "saveOrUpdateJobInfo",method = RequestMethod.POST)
	public Object saveOrUpdateJobInfo(@RequestBody @Valid JobInfoDTO  jobInfoDTO, BindingResult result){
		RestResponse response;
		try {
		   response = this.applyJobService.addOrUpdateJobInfo(jobInfoDTO);
		} catch (Exception e) {
            log.error("个人工作信息保存报错",e);
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "私营信息保存",response = RestResponse.class)
	@RequestMapping(value = "saveOrUpdatePrivateInfo",method = RequestMethod.POST)
	public Object saveOrUpdatePrivateInfo(@RequestBody PrivateDTO privateDTO){
		RestResponse response;
		try {
		   response = this.applyJobService.addOrUpdatePrivateInfo(privateDTO);
		} catch (Exception e) {
            log.error("私营信息保存报错",e);
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
//	@ApiOperation(value = "客户确认提交",response = RestResponse.class)
//	@RequestMapping(value = "onSubmit",method = {RequestMethod.GET,RequestMethod.POST})
//	public Object onSubmit(){
//		RestResponse response;
//		try {
//			response = this.applyJobService.onSubmit();
//		}catch (Exception e){
//			e.printStackTrace();
//			log.info("客户提交到待授权节点失败");
//			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
//		}
//		return new ResponseEntity<RestResponse>(response,response.getHttpcode());
//	}


}
