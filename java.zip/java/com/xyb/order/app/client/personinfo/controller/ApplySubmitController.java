/**
 * 
 */
package com.xyb.order.app.client.personinfo.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.model.IBaseModel;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;
import com.xyb.order.app.client.personinfo.service.ApplySubmitService;
import com.xyb.order.app.client.quickloan.service.ApplySubmitOptionService;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.app.client.personinfo.controller
 * @description : TODO
 * @createDate : 2018年9月19日 下午2:55:44
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("order/capp/submit")
public class ApplySubmitController implements IBaseModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8298524212892122990L;
	@Reference
	private ApplySubmitOptionService applySubmitOptionService;
	
	/**
	 * 提交申请
	 * @param result
	 * @return
	 */
	@ApiOperation(value = "提交申请",response = RestResponse.class)
	@RequestMapping(value = "applySubmit",method = RequestMethod.GET)
	public Object applySubmit(){
		RestResponse response = this.applySubmitOptionService.applySubmitOption();
		return new ResponseEntity<RestResponse>(response,response.getHttpcode());
	}
	
	/**
	 * 确认借款提交
	 * @param ApplySubmitDTO
	 * @param result
	 * @return
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "确认借款提交",response = RestResponse.class)
	@RequestMapping(value = "confirmSubmit",method = RequestMethod.POST)
	public Object confirmSubmit(@RequestBody @Valid ApplySubmitDTO applySubmitDTO, BindingResult result){
		RestResponse response = this.applySubmitOptionService.confirmSubmitOption(applySubmitDTO);
		return new ResponseEntity<RestResponse>(response,response.getHttpcode());
	}

}
