package com.xyb.order.app.client.personinfo.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDTO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatcVO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDTO;
import com.xyb.order.app.client.personinfo.service.ApplyPersonService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * @ClassName ApplyPersonService
 * @author ZhangYu
 * @date 2018年5月22号
 */
@Controller
@RequestMapping("order/capp/person")
public class ApplyPersonController {

	private static final Logger log = LoggerFactory.getLogger(ApplyPersonController.class);

	@Reference
	private ApplyPersonService applyPersonService;

	@ApiOperation(value = "个人基本信息", response = ApplyPersonBaseInfoDO.class)
	@RequestMapping(value = "getPersonInfo", method = { RequestMethod.POST, RequestMethod.GET })
	public Object getPersonInfo() {
		RestResponse response;
		try {
			response = this.applyPersonService.getApplyPersonBaseInfo();
		} catch (Exception e) {
			log.error("个人基本信息查询报错",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@AutoValid
	@ApiOperation(value = "个人基本信息保存", response = RestResponse.class)
	@RequestMapping(value = "saveOrUpdatePersonInfo", method = RequestMethod.POST)
	public Object saveOrUpdatePersonInfo(@RequestBody @Valid ApplyPersonBaseInfoDTO applyPersonBaseInfoDTO,
			BindingResult result) {
		RestResponse response;
		try {
			response = this.applyPersonService.addOrUpdatePersonBaseInfo(applyPersonBaseInfoDTO);
		} catch (Exception e) {
			log.error("个人基本信息保存报错",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "个人联系人信息页面个人信息", response = PersonBaseRelationInfoDO.class)
	@RequestMapping(value = "getLinkPersonInfo", method = { RequestMethod.POST, RequestMethod.GET })
	public Object getLinkPersonInfo() {
		RestResponse response;
		try {
			response = this.applyPersonService.getLinkPersonInfo();
		} catch (Exception e) {
			log.error("查询个人联系人信息页面个人信息异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "根据联系人类型查询联系人列表信息")
	@RequestMapping(value = "getPersonRelationInfo/{contactType}", method = { RequestMethod.POST, RequestMethod.GET })
	public Object getPersonRelationInfo(@PathVariable Long contactType) {
		RestResponse response;
		try {
			response = this.applyPersonService.getApplyPersonRelationInfo(contactType);
		} catch (Exception e) {
			log.error("根据联系人类型查询联系人列表信息接口异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "根据联系人ID查询联系人信息", response = LinkManRelationInfoDO.class)
	@RequestMapping(value = "getLinkManInfoById/{id}", method = { RequestMethod.POST, RequestMethod.GET })
	public Object getLinkManInfoById(@PathVariable Long id) {
		RestResponse response;
		try {
			response = this.applyPersonService.getLinkManInfoById(id);
		} catch (Exception e) {
			log.error("根据联系人ID查询联系人信息接口异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@AutoValid
	@ApiOperation(value = "联系信息保存", response = RestResponse.class)
	@RequestMapping(value = "saveOrUpdateRelationInfo", method = RequestMethod.POST)
	public Object saveOrUpdateRelationInfo(@RequestBody @Valid LinkManRelationInfoDTO linkManRelationInfoDTO,
			BindingResult result) {
		RestResponse response;
		try {
			response = this.applyPersonService.saveOrUpdateRelationInfo(linkManRelationInfoDTO);
		} catch (Exception e) {
			log.error("联系信息保存报错",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "联系人列表页的个人信息保存", response = RestResponse.class)
	@RequestMapping(value = "saveOrUpdatePersonRelationInfo", method = RequestMethod.POST)
	public Object saveOrUpdatePersonRelationInfo(@RequestBody PersonBaseRelationInfoDTO personBaseRelationInfoDTO) {
		RestResponse response;
		try {
			response = this.applyPersonService.addOrUpdatePersonRelationInfo(personBaseRelationInfoDTO);
		} catch (Exception e) {
			log.error("联系人列表页的个人信息报错",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}

	@ApiOperation(value = "验证是否需要上传通讯录", response = RestResponse.class)
	@RequestMapping(value = "checkPhoneBook", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> savePhoneBook(@RequestBody PhoneBookBatcVO bean) {

		RestResponse response;
		try {
			response = this.applyPersonService.getPhoneBookAddressBatch(bean);
		} catch (Exception e) {
			log.error("获取通讯录数据异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "保存用户通讯录", response = RestResponse.class)
	@RequestMapping(value = "savePhoneBook", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> savePhoneBook(@RequestBody PhoneBookBO phoneBookBO) {
		RestResponse response;
		try {
			response = this.applyPersonService.addPhoneBookInfos(phoneBookBO);
		} catch (Exception e) {
			log.error("电话簿保存异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "验证选择的联系人是否已经添加", response = RestResponse.class)
	@RequestMapping(value = "checkPhoneExist", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> checkPhoneExist(@RequestBody PhoneBookDTO phoneBookDTO) {
		RestResponse response;
		try {
			response = this.applyPersonService.queryAndAddPhoneBookInfo(phoneBookDTO);
		} catch (Exception e) {
			log.error("新增联系人异常",e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}

}
