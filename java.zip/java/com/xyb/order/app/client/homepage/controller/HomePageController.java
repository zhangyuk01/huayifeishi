package com.xyb.order.app.client.homepage.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.cuser.model.ApplyLoanDTO;
import com.xyb.order.app.client.cuser.model.ProductExhibitionVO;
import com.xyb.order.app.client.homepage.model.BannerDO;
import com.xyb.order.app.client.homepage.model.ProductListVO;
import com.xyb.order.app.client.homepage.service.HomePageService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* C端首页接口
* @author         xieqingyang
* @date           2018/5/8 下午3:59
*/
@Controller
@RequestMapping("order/capp/homepage")
public class HomePageController {

    private final static Logger log = LoggerFactory.getLogger(HomePageController.class);

    @Reference
    private HomePageService homePageService;

    @ApiOperation(value = "获得banner活动图",response = BannerDO.class)
    @RequestMapping(value = "openapi/queryValidBanners", method={RequestMethod.POST, RequestMethod.GET})
    public Object queryValidBanners(){
        RestResponse response;
        try {
            response = homePageService.queryValidBanners();
        } catch (Exception e) {
            log.error("查询banner图异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "产品展示列表",response = ProductListVO.class)
    @RequestMapping(value = "openapi/queryProductList",method = RequestMethod.POST)
    public Object queryProductList(){
        RestResponse response;
        try {
            response = homePageService.queryProductList();
        } catch (Exception e) {
            log.error("查询产品展示列表异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "申请借款",response = ProductExhibitionVO.class)
    @AutoValid
    @RequestMapping(value = "applyLoan",method = RequestMethod.POST)
    public Object applyLoan(@RequestBody @Valid ApplyLoanDTO applyLoanDTO, BindingResult result){
        RestResponse response;
        try {
            response = homePageService.applyLoan(applyLoanDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("申请借款异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
    }

    @ApiOperation(value = "获取填写资料列表")
    @RequestMapping(value = "getFillList/{productId}",method = RequestMethod.POST)
    public Object fillList(@PathVariable Long productId){
        RestResponse response;
        try {
            response = homePageService.fillList(productId);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("获取填写资料列表异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
    }
}
