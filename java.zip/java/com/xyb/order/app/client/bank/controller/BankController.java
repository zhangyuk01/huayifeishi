package com.xyb.order.app.client.bank.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.DesUtil;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.common.bank.model.BankCardInfoVO;
import com.xyb.order.common.bank.model.BankUpdateDTO;
import com.xyb.order.common.bank.model.XybBankCodeDO;
import com.xyb.order.common.bank.service.BankService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * capp银行卡相关信息
 * @author         xieqingyang
 * @date           2018/7/19 下午3:52
*/
@Controller
@RequestMapping(value = "/order/capp/bank")
public class BankController {

    private static final Logger log = LoggerFactory.getLogger(BankController.class);

    @Reference
    private BankService bankService;

    @ApiOperation(value = "根据银行卡号获取银行卡信息",response = XybBankCodeDO.class)
    @RequestMapping(value = "getBankInfoByBankId/{bankId}",method = RequestMethod.POST)
    public Object getBankInfoByBankId(@PathVariable("bankId") String bankId){
        RestResponse response;
        try {
            response = bankService.getBankInfoByBankId(bankId);
        }catch (Exception e){
            log.error("根据银行卡号获取银行卡信息接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取支持的银行卡列表",response = XybBankCodeDO.class)
    @RequestMapping(value = "queryBankIcon",method = RequestMethod.POST)
    public Object queryBankIcon(){
        RestResponse response;
        try {
            response = bankService.queryBankIcon();
        }catch (Exception e){
            log.error("获取支持的银行卡列表接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获得绑卡的用户身份信息",response = ClientAuthenticationDO.class)
    @RequestMapping(value = "getClientInfo",method = RequestMethod.POST)
    public Object getClientInfo(){
        RestResponse response;
        try {
            response = bankService.getClientInfo();
        }catch (Exception e){
            log.error("获得换卡的用户身份信息接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "用户绑卡",response = RestResponse.class)
    @RequestMapping(value = "tieOnCard",method = RequestMethod.POST)
    public Object tieOnCard(@RequestBody @Valid BankUpdateDTO bankUpdateDTO, BindingResult result){
        RestResponse response;
        try {
            response = bankService.tieOnCard(bankUpdateDTO);
        }catch (Exception e){
            log.error("用户绑卡接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "用户换卡",response = RestResponse.class)
    @RequestMapping(value = "changeCard",method = RequestMethod.POST)
    public Object changeCard(@RequestBody @Valid BankUpdateDTO bankUpdateDTO, BindingResult result){
        RestResponse response;
        try {
            response = bankService.changeCard(bankUpdateDTO);
        }catch (Exception e){
            log.error("用户换卡接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取用户银行卡信息",response = BankCardInfoVO.class)
    @RequestMapping(value = "getBankCardInfo",method = RequestMethod.POST)
    public Object getBankCardInfo(){
        RestResponse response;
        try {
            response = bankService.getBankCardInfo();
        }catch (Exception e){
            log.error("获取用户银行卡信息接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "获取用户银行卡绑定状态",response = RestResponse.class)
    @RequestMapping(value = "getBankCardState",method = RequestMethod.POST)
    public Object getBankCardState(){
        RestResponse response;
        try {
            response = bankService.getBankCardState();
        }catch (Exception e){
            log.error("获取用户银行卡绑定状态接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }
}
