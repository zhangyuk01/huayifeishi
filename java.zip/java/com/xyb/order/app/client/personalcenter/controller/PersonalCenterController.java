package com.xyb.order.app.client.personalcenter.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.model.Page;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDO;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDTO;
import com.xyb.order.app.client.personalcenter.model.PersonalInfoDTO;
import com.xyb.order.app.client.personalcenter.service.PersonalCenterService;
import com.xyb.order.common.message.model.SendMessageVerificationDTO;
import com.xyb.order.common.message.service.MessageService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * 我的/个人中心
 * 
 * @author qiaoJinLong
 * @date 2018年9月13日
 */
@Controller
@RequestMapping("order/capp/center")
public class PersonalCenterController {
	private static final Logger log = LoggerFactory.getLogger(PersonalCenterController.class);
	@Reference
	private MessageService messageService;
	@Reference
	private PersonalCenterService personalCenterService;

	/**
	 * 获取个人信息
	 * 
	 * @return
	 */
	@ApiOperation(value = "查询我的信息", response = PersonalInfoDTO.class)
	@RequestMapping(value = "personalInfo", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> getPersonalInfo() {
		RestResponse response;
		try {
			response = personalCenterService.getPersonalInfo();
		} catch (Exception e) {
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("C端获取用户个人信息异常", e);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	/**
	 * 发送短信验证码
	 */
	@ApiOperation(value = "发送登陆短信验证码", response = RestResponse.class)
	@AutoValid
	@RequestMapping(value = "openapi/sendcode", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> getMessageCode(
			@RequestBody @Valid SendMessageVerificationDTO sendMessageVerificationDTO, BindingResult result) {
		RestResponse response;
		try {
			response = personalCenterService.SendMessageVerification(sendMessageVerificationDTO);
		} catch (Exception e) {
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("C端发送登陆短信异常", e);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	/**
	 * 添加推荐人
	 */
	@ApiOperation(value = "添加推荐人", response = RestResponse.class)
	@AutoValid
	@RequestMapping(value = "setReferee/{phone}", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> addReferee(@PathVariable("phone") String phone) {
		RestResponse response;
		try {
			response = personalCenterService.addReferee(phone);
		} catch (Exception e) {
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("C端添加异常推荐人异常", e);
		}

		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 获取我的好友与推荐人
	 */
	@ApiOperation(value = "获取我的好友与推荐人", response = RestResponse.class)
	@RequestMapping(value = "getFriendsAndReferee", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> getMyFriendsAndReferee() {
		RestResponse response;
		try {
			response = personalCenterService.getMyFriendsAndReferee();
		} catch (Exception e) {
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("C端获取我的好友与联系人异常！", e);
		}

		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 获取疑难解答
	 * 
	 * @return
	 */
	@ApiOperation(value = "获取疑难解答列表", response = RestResponse.class)
	@RequestMapping(value = "openapi/getProblems/{num}", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> getProblems(@PathVariable("num") Integer num) {
		RestResponse response;
		try {
			response = personalCenterService.getProblem(num);
		} catch (Exception e) {
			log.error("获取疑难解答列表异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 更新点击数
	 * 
	 * @return
	 */
	@ApiOperation(value = "更新点击数", response = RestResponse.class)
	@RequestMapping(value = "openapi/setclicks/{id}", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> updateClicks(@PathVariable("id") Long id) {
		RestResponse response;
		try {
			response = personalCenterService.updateClicks(id);
		} catch (Exception e) {
			log.error("更新点击数异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 查看我的奖励金余额
	 * 
	 * @return
	 */
	@ApiOperation(value = "查看我的奖励金余额", response = RestResponse.class)
	@RequestMapping(value = "showBalance", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> queryBalance() {
		RestResponse response;
		try {

			response = personalCenterService.queryBalance();
		} catch (Exception e) {
			log.error("查看我的奖励金余额", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 获取我的流水信息
	 * 
	 * @return
	 */
	@ApiOperation(value = "获取我的流水信息", response = RestResponse.class)
	@RequestMapping(value = "showBalanceDetai/{pageNumber}/{pageSize}", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> queryClientProfitBalanceDetai(@PathVariable("pageNumber") Integer pageNumber,
			@PathVariable("pageSize") Integer pageSize, @RequestBody ClientProfitBalanceDetailDTO dto) {
		RestResponse response;
		try {
			Page<ClientProfitBalanceDetailDO> page = dto.getPage();
			page.setPageNumber(pageNumber);
			page.setPageSize(pageSize);
			dto.setPage(page);
			response = personalCenterService.queryClientProfitBalanceDetail(dto);
		} catch (Exception e) {
			log.error("查看我的奖励金余额", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 获取获取分享链接
	 * 
	 * @return
	 */
	@ApiOperation(value = "获取获取分享链接", response = RestResponse.class)
	@RequestMapping(value = "getShareUrl", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> getShareUrl() {
		RestResponse response;
		try {
			response = personalCenterService.getShareUrl();
		} catch (Exception e) {
			log.error("获取获取分享链接异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

	/**
	 * 判断是否显示设置推荐人
	 * 
	 * @return
	 */
	@ApiOperation(value = "判断是否显示设置推荐人", response = RestResponse.class)
	@RequestMapping(value = "whetherShowSetReferee", method = RequestMethod.POST)
	public ResponseEntity<RestResponse> whetherShowSetReferee() {
		RestResponse response;
		try {
			response = personalCenterService.querywhetherShowSetReferee();
		} catch (Exception e) {
			log.error("判断是否显示设置推荐人异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

}
