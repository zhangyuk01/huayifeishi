package com.xyb.order.app.client.apply.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.apply.service.ApplyService;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
* 客户申请信息
* @author         xieqingyang
* @date           2018/5/12 下午5:08
*/
@Controller
@RequestMapping("order/capp/apply")
public class ApplyController {

    private static final Logger log = LoggerFactory.getLogger(ApplyController.class);

    @Reference
    private ApplyService applyService;

   
    @ApiOperation(value = "借款信息修改",response = RestResponse.class)
    @AutoValid
    @RequestMapping(value = "updateExpectInfo",method = RequestMethod.POST)
    public Object updateExpectInfo(@RequestBody @Valid ApplyDTO applyDTO,BindingResult result){
    	RestResponse response;
    	try {
		    response = this.applyService.insertApplyInfo(applyDTO);
		} catch (Exception e) {
            log.error("借款信息修改报错",e);
			response = new RestResponse(MsgErrCode.FAIL);
		}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    
}
