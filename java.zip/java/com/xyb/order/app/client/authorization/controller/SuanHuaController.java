package com.xyb.order.app.client.authorization.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.authorization.model.SuanHuaDTO;
import com.xyb.order.app.client.authorization.model.SuanHuaRegisterDTO;
import com.xyb.order.app.client.authorization.service.SuanHuaService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* 算话认证接口
* @author         xieqingyang
* @date           2018/5/16 下午9:28
*/
@Controller
@RequestMapping("order/suanhua")
public class SuanHuaController {

    private static final Logger log = LoggerFactory.getLogger(SuanHuaController.class);

    @Reference
    private SuanHuaService suanHuaService;

    @ApiOperation(value = "算话注册",response = RestResponse.class)
    @RequestMapping(value = "register",method = RequestMethod.POST)
    public Object register(@RequestBody SuanHuaRegisterDTO dto){
        RestResponse response;
        try {
            response = suanHuaService.register(dto);
        }catch (Exception e){
            log.error("算话注册异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
    }

    @ApiOperation(value = "算话申请",response = RestResponse.class)
    @RequestMapping(value = "suanhuaPush",method = RequestMethod.POST)
    public Object suanhuaPush(@RequestBody SuanHuaDTO suanHuaDTO, BindingResult result){
        RestResponse response;
        try {
            response = suanHuaService.suanhuaPush(suanHuaDTO);
        }catch (Exception e){
            log.error("算话申请异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @RepeatTokenValid
    @ApiOperation(value = "算话提取",response = RestResponse.class)
    @RequestMapping(value = "invokExtractReport",method = RequestMethod.POST)
    public Object invokExtractReport(@RequestBody SuanHuaDTO suanHuaDTO, BindingResult result){
        RestResponse response;
        try {
            response = suanHuaService.invokExtractReport(suanHuaDTO);
        }catch (Exception e){
            log.error("算话提取异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
