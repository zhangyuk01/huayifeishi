package com.xyb.order.app.client.authorization.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.authorization.model.ThreePartyAuthorizationLogDO;
import com.xyb.order.app.client.authorization.service.AuthorizationService;
import com.xyb.order.app.client.authorization.service.TianJiService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
* 天机-融360认证相关
* @author         xieqingyang
* @date           2018/5/16 下午6:43
*/
@Controller
@RequestMapping("order/tianji")
public class TianJiController {

    private static final Logger log = LoggerFactory.getLogger(TianJiController.class);

    @Reference
    private TianJiService tianJiService;
    @Reference
    private AuthorizationService authorizationService;

    @RepeatTokenValid
    @ApiOperation(value = "融360社保认证",response = RestResponse.class)
    @RequestMapping(value = "crawlerInsure", method={RequestMethod.POST, RequestMethod.GET})
    public Object crawlerInsure(){
        RestResponse response;
        try {
            response = tianJiService.crawlerInsure();
        }catch (Exception e){
            log.error("融360社保认证异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "融360公积金认证",response = RestResponse.class)
    @RequestMapping(value = "crawlerFund", method={RequestMethod.POST, RequestMethod.GET})
    public Object crawlerFund(){
        RestResponse response;
        try {
            response = tianJiService.crawlerFund();
        }catch (Exception e){
            log.error("融360公积金认证异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "融360征信认证",response = RestResponse.class)
    @RequestMapping(value = "crawlerZX", method={RequestMethod.POST, RequestMethod.GET})
    public Object crawlerZX(){
        RestResponse response;
        try {
            response = tianJiService.crawlerZX();
        }catch (Exception e){
            log.error("融360征信认证异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RequestMapping(value = "openapi/shebaoJump/{applyId}/{loginId}/{type}")
    public String rong360Jump(@PathVariable String applyId,@PathVariable String loginId,@PathVariable String type){
        try {
            ThreePartyAuthorizationLogDO logDO = new ThreePartyAuthorizationLogDO();
            logDO.setApplyId(Long.valueOf(applyId));
            logDO.setCreateUser(Long.valueOf(loginId));
            logDO.setAuthorizationType(Long.valueOf(type));
            logDO.setIsSuccess(SysDictEnum.YES.getCode());
            authorizationService.insertLog(logDO);
        }catch (Exception e){
            log.error("添加认证日志失败"+"applyId="+applyId+"&loginId="+loginId+"&type="+type);
            log.error("添加认证日志失败",e);
        }
        return "/authJump.jsp";
    }
}
