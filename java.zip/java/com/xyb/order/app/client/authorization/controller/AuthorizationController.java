package com.xyb.order.app.client.authorization.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.authorization.model.AuthorizationListVO;
import com.xyb.order.app.client.authorization.model.IdentityInformationDTO;
import com.xyb.order.app.client.authorization.model.ThreePartyAuthorizationLogDO;
import com.xyb.order.app.client.authorization.service.AuthorizationService;
import com.xyb.order.app.client.personinfo.model.PersonalAddressDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* 认证
* @author       xieqingyang
* @date         2018/5/12 下午5:08
*/
@Controller
@RequestMapping("order/capp/authorization")
public class AuthorizationController {

    private static final Logger log = LoggerFactory.getLogger(AuthorizationController.class);

    @Reference
    private AuthorizationService authorizationService;

    @ApiOperation(value = "查询三方列表",response = AuthorizationListVO.class)
    @RequestMapping(value = "queryAuthorizationList", method={RequestMethod.POST, RequestMethod.GET})
    public Object queryAuthorizationList(){
        RestResponse response;
        try {
            response = authorizationService.queryAuthorizationList();
        }catch (Exception e){
            log.error("查询三方列表异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

//    @ApiOperation(value = "授权页确认借款",response = RestResponse.class)
//    @RequestMapping(value = "confirmAuthorization", method={RequestMethod.POST, RequestMethod.GET})
//    public Object confirmAuthorization(){
//        RestResponse response;
//        try {
//            response = authorizationService.confirmAuthorization();
//        }catch (Exception e){
//            log.error("授权列表确认功能异常",e);
//            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
//        }
//        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
//    }

    @AutoValid
    @ApiOperation(value = "身份认证接口",response = RestResponse.class)
    @RequestMapping(value = "IdentityInformation", method={RequestMethod.POST, RequestMethod.GET})
    public Object IdentityInformation(@RequestBody @Valid IdentityInformationDTO dto, BindingResult result){
        RestResponse response;
        try {
            response = authorizationService.identityInformation(dto);
        }catch (Exception e){
            log.error("身份认证接口异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "添加第三方授权结果日志",response = RestResponse.class)
    @RequestMapping(value = "insertAuthorizationLog",method = RequestMethod.POST)
    public Object insertAuthorizationLog(@RequestBody @Valid ThreePartyAuthorizationLogDO dto, BindingResult result){
        RestResponse response;
        try {
            response = authorizationService.insertAuthorizationLog(dto);
        }catch (Exception e){
            log.error("身份认证接口异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "地址解析",response = PersonalAddressDTO.class)
    @RequestMapping(value = "addressSplit/{address}",method={RequestMethod.POST, RequestMethod.GET})
    public Object addressSplit(@PathVariable String address){
        RestResponse response;
        try {
            response = authorizationService.addressSplit(address);
        }catch (Exception e){
            log.error("地址解析接口异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "查询是否能够授权",response = RestResponse.class)
    @RequestMapping(value = "verification/{authorizationType}",method = RequestMethod.POST)
    public Object verification(@PathVariable("authorizationType") String authorizationType){
        RestResponse response;
        try {
            response = authorizationService.verification(authorizationType);
        }catch (Exception e){
            log.error("查询是否能够授权接口异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }
}
