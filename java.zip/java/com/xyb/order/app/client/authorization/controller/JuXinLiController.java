package com.xyb.order.app.client.authorization.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.authorization.model.JuXinLiBaoDanDTO;
import com.xyb.order.app.client.authorization.model.JuXinLiCollectDTO;
import com.xyb.order.app.client.authorization.service.JuXinLiService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* 聚信力相关接口
* @author         xieqingyang
* @date           2018/5/17 上午10:44
*/
@Controller
@RequestMapping("order/juxinli")
public class JuXinLiController {

    private static final Logger log = LoggerFactory.getLogger(JuXinLiController.class);

    @Reference
    private JuXinLiService juXinLiService;


    @ApiOperation(value = "聚信立提交申请表单获取回执信息（运营商）",response = RestResponse.class)
    @RequestMapping(value = "subApplyGetReturnMsg", method={RequestMethod.POST, RequestMethod.GET})
    public Object subApplyGetReturnMsg(){
        RestResponse response;
        try {
            response = juXinLiService.subApplyGetReturnMsg();
        }catch (Exception e){
            log.error("聚信立提交申请表单获取回执信息（运营商）异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "调用聚信立数据源采集请求（运营商）",response = RestResponse.class)
    @AutoValid
    @RequestMapping(value = "getCollectJuXinLi",method = RequestMethod.POST)
    public Object getCollectJuXinLi(@RequestBody @Valid JuXinLiCollectDTO juXinLiCollectDTO, BindingResult result){
        RestResponse response;
        try {
            response = juXinLiService.getCollectJuXinLi(juXinLiCollectDTO);
        }catch (Exception e){
            log.error("调用聚信立数据源采集请求（运营商）异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "获取支持的数据源具体网站列表(保单)",response = RestResponse.class)
    @RequestMapping(value = "getAllInsuranceWebsite", method={RequestMethod.POST, RequestMethod.GET})
    public Object getAllInsuranceWebsite(){
        RestResponse response;
        try {
            response = juXinLiService.getAllInsuranceWebsite();
        }catch (Exception e){
            log.error("获取支持的数据源具体网站列表(保单)异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "提交保险网站数据采集申请接口(保单)",response = RestResponse.class)
    @RequestMapping(value = "collectJuXinLiBaoDan",method = RequestMethod.POST)
    public Object collectJuXinLiBaoDan(@RequestBody @Valid JuXinLiBaoDanDTO juXinLiBaoDanDTO,BindingResult result){
        RestResponse response;
        try {
            response = juXinLiService.collectJuXinLiBaoDan(juXinLiBaoDanDTO);
        }catch (Exception e){
            log.error("提交保险网站数据采集申请接口(保单)异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
