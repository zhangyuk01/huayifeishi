package com.xyb.order.app.client.authorization.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.RequestUtils;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.authorization.model.AgreementInFoVO;
import com.xyb.order.app.client.authorization.model.QueryAgreementDTO;
import com.xyb.order.app.client.authorization.service.ContractSignService;
import com.xyb.order.common.fdd.model.FddReturnInFoDTO;
import com.xyb.order.common.fdd.service.FddService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * 签约相关功能
 * @author      xieqingyang
 * @date        2018/6/9 上午11:36
*/
@Controller
@RequestMapping("/order/signContract")
public class ContractSignController {

    private static final Logger logger = LoggerFactory.getLogger(ContractSignController.class);

    @Reference
    private ContractSignService contractSignService;
    @Reference
    private FddService fddService;

    @ApiOperation(value = "签约个人信息查询、采集授权书")
    @RequestMapping(value = "personalAuth",method = {RequestMethod.GET,RequestMethod.POST})
    public Object personalAuth(){
        RestResponse response;
        try {
            response = contractSignService.personalAuth();
        }catch (Exception e){
            logger.error("个人信息查询、采集授权书接口异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "签约借款人声明函&委托扣款授权书、借款人服务协议等其他协议--还包括借款服务协议")
    @RequestMapping(value = "loanCol",method = {RequestMethod.GET,RequestMethod.POST})
    public Object loanCol(){
        RestResponse response;
        try {
            response = contractSignService.loanCol();
        }catch (Exception e){
            logger.error("签约借款人声明函&委托扣款授权书、借款人服务协议接口异常",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "查询合同",response = AgreementInFoVO.class)
    @RequestMapping(value = "queryAgreementInFo",method = RequestMethod.POST)
    public Object queryAgreementInFo(@RequestBody @Valid QueryAgreementDTO queryAgreementDTO, BindingResult result){
        RestResponse response;
        try {
            response = contractSignService.queryAgreementInFo(queryAgreementDTO);
        }catch (Exception e){
            logger.error("查看合同异常:",e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "法大大同步回调接口",response = AgreementInFoVO.class)
    @RequestMapping(value = "openapi/fddReturnUrl/{contractId}",method = RequestMethod.GET)
    public String fddReturnUrl(@PathVariable("contractId") String contractId, HttpServletRequest request){
        logger.info("法大大同步回调接口");
        FddReturnInFoDTO foDTO = (FddReturnInFoDTO)RequestUtils.getRequestBean(FddReturnInFoDTO.class,request);
        foDTO.setContract_id(contractId);
        fddService.fddAnalysis(foDTO);
        return "/authJump.jsp";
    }

    @ApiOperation(value = "法大大异步回调接口",response = AgreementInFoVO.class)
    @RequestMapping(value = "openapi/fddNotifyUrl",method = RequestMethod.POST)
    public Object fddNotifyUrl(@RequestBody @Valid FddReturnInFoDTO fddReturnInFoDTO,BindingResult result){
        RestResponse response;
        HttpStatus httpStatus;
        logger.info("法大大异步回调接口开始");
        if (result.hasErrors()){
            response = new RestResponse(MsgErrCode.FAIL);
            httpStatus = HttpStatus.EXPECTATION_FAILED;
        }else {
            response = fddService.fddAnalysis(fddReturnInFoDTO);
            if (response.getResult() == 0){
                httpStatus = HttpStatus.OK;
            }else {
                httpStatus = HttpStatus.EXPECTATION_FAILED;
            }
        }
        return new ResponseEntity<RestResponse>(response,httpStatus);
    }
}
