package com.xyb.order.app.client.quickloan.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyInfoDTO;
import com.xyb.order.app.client.quickloan.service.QuickLoanService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * 速贷申请信息
 * 
 * @author qiaoJinLong
 * @date 2018年12月18日
 */

@Controller
@RequestMapping("order/capp/quick/loans")
public class QuickLoanController {
	private static final Logger log = LoggerFactory.getLogger(QuickLoanController.class);

	@Reference
	private QuickLoanService quickLoanService;

	/**
	 * 获取申请信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "getApplyInfo", method = RequestMethod.POST)
	@ApiOperation(value = "获取申请信息", response = QuickLoanApplyInfoDTO.class)
	private ResponseEntity<RestResponse> getApplyInfo() {
		RestResponse response = null;
		try {
			response = quickLoanService.getApplyInfo();
		} catch (Exception e) {
			e.printStackTrace();
			log.info("速贷查询个人信息异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	/**
	 * 保存/更新申请信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "saveApplyInfo", method = RequestMethod.POST)
	@ApiOperation(value = "保存/修改信息", response = QuickLoanApplyInfoDTO.class)
	private ResponseEntity<RestResponse> saveOrUpdateApplyInfo(@RequestBody QuickLoanApplyInfoDTO applyInfo) {
		RestResponse response = null;
		try {
			response = quickLoanService.saveOrUpdateApplyInfo(applyInfo);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("速贷保存信息异常", e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());

	}

}
