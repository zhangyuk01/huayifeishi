package com.xyb.order.app.client.cuser.controller;

import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.cuser.model.CUpdatePhoneDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.common.msg.NativeMsgErrCode;

/**
 * 修改客户信息（密码、手机号）
 * @author	 xieqingyang
 * @date     2018/5/9 下午7:58
 */
@Controller
@RequestMapping("order/capp/clinetUserModify")
public class ClinetUserModifyController {

	private static final Logger log = LoggerFactory.getLogger(ClinetUserModifyController.class);

	@Reference
	private ClinetUserModifyService clinetUserModifyService;


	@ApiOperation(value = "C端用户忘记密码", response = RestResponse.class)
	@AutoValid
	@RequestMapping(value = "openapi/cAppUserForgerPassword", method = RequestMethod.POST)
	public Object forgetPassword(@RequestBody @Valid ClientUserUpdateDTO clientUserDTO, BindingResult result) {
		RestResponse response;
		try {
			response = clinetUserModifyService.forgetPassword(clientUserDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("C端用户忘记密码异常:" + e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}



	@AutoValid
	@ApiOperation(value = "C端用户修改密码", response = RestResponse.class)
	@RequestMapping(value = "updatePassword", method = RequestMethod.POST)
	public Object updatePassword(@RequestBody @Valid ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO,
			BindingResult result) {
		RestResponse response;
		try {
			response = clinetUserModifyService.updatePassword(clientUserUpdatePasswordDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("C端用户修改密码异常:" + e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@AutoValid
	@ApiOperation(value = "C端用户修改手机号", response = RestResponse.class)
	@RequestMapping(value = "updatePhone", method = RequestMethod.POST)
	public Object updatePhone(@RequestBody @Valid CUpdatePhoneDTO clientUserUpdatePhoneDTO, BindingResult result) {
		RestResponse response;
		try {
			response = clinetUserModifyService.updatePhone(clientUserUpdatePhoneDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("C端用户修改手机号异常:" + e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}

	@AutoValid
	@ApiOperation(value = "C端修改手机号前，身份校验", response = RestResponse.class)
	@RequestMapping(value = "checkId", method = RequestMethod.POST)
	public Object checkId(@RequestBody Map<String, String> map) {
		RestResponse response;
		try {
			response = clinetUserModifyService.checkID(map.get("password"));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("修改手机号前，身份校验:" + e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}
}
