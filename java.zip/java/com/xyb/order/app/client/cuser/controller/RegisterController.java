package com.xyb.order.app.client.cuser.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.cuser.model.ClientUserDTO;
import com.xyb.order.app.client.cuser.service.RegisterService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* C端app用户注册、忘记密码功能
* @author         xieqingyang
* @date           2018/5/9 上午10:56
*/
@Controller
@RequestMapping("order/capp/register")
public class RegisterController {

    private static final Logger log = LoggerFactory.getLogger(RegisterController.class);

    @Reference
    private RegisterService registerService;

    @ApiOperation(value = "C端用户注册",response = RestResponse.class)
    @AutoValid
    @RequestMapping(value = "openapi/cAppUserRegister",method = RequestMethod.POST)
    public Object register(@RequestBody @Valid ClientUserDTO clientUserDTO, BindingResult result){
        RestResponse response;
        try {
            response = registerService.register(clientUserDTO);
        }catch (Exception e){
            log.error("C端用户注册异常",e);
            log.error("C端用户注册异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
