package com.xyb.order.app.client.mine.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.app.client.mine.model.*;
import com.xyb.order.app.client.mine.service.MineService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
* 我的
* @author         xieqingyang
* @date           2018/5/12 下午5:09
*/
@Controller
@RequestMapping("order/capp/mine")
public class MineController {

    private static final Logger log = LoggerFactory.getLogger(MineController.class);

    @Reference
    private MineService mineService;

    @ApiOperation(value = "查询我的信息",response = ClientAuthenticationDO.class)
    @RequestMapping(value = "queryDepositoryState",method = RequestMethod.POST)
    public Object queryMineInfo(){
        RestResponse response;
        try {
            response = mineService.queryMineInfo();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询我的信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "查询版本信息",response = VersionInfoVO.class)
    @RequestMapping(value = "openapi/queryAppVersion/{deviceType}",method = RequestMethod.POST)
    public Object queryAppVersion(@PathVariable String deviceType){
        RestResponse response;
        try {
            response = mineService.queryAppVersion(deviceType);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询版本信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "获取借款记录",response = ApplyRecordVO.class)
    @RequestMapping(value = "getApplyRecord",method = RequestMethod.POST)
    public Object getApplyRecord(@RequestBody ApplyRecordQueryDTO applyRecordQueryDTO){
        RestResponse response;
        try {
        	response = mineService.getApplyRecord(applyRecordQueryDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("获取借款记录异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "查询确认借款信息数据",response = ApplyRecordConfrimDO.class)
    @RequestMapping(value = "getApplyRecordConfirmationInfo/{mainId}/{applyId}",method = RequestMethod.POST)
    public Object getApplyRecordConfirmInfo(@PathVariable Long mainId,@PathVariable Long applyId){
        RestResponse response; 
        try {
        	response = mineService.getApplyRecordConfirmInfo(mainId,applyId);
		} catch (Exception e) {
            e.printStackTrace();
            log.info("查询确认借款数据信息异常");
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
   
    @ApiOperation(value = "提交确认借款",response = RestResponse.class)
    @RequestMapping(value = "getApplyRecordConfirm",method = RequestMethod.POST)
    public Object getApplyRecordConfirm(@RequestBody @Valid ApplyRecordConfrimDTO applyRecordConfrimDTO,BindingResult result){
    	RestResponse response;
    	try {
    		response = mineService.getApplyRecordConfirm(applyRecordConfrimDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("提交确认借款异常");
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
    }
    
    @ApiOperation(value = "立即还款接口",response = RestResponse.class)
    @RequestMapping(value = "getApplyReturnLoan",method = RequestMethod.POST)
    public Object getApplyReturnLoan(@RequestBody @Valid ApplyReturnLoanDTO applyReturnLoanDTO,BindingResult result){
    	RestResponse response;
    	try {
    		response = mineService.getApplyReturnLoan(applyReturnLoanDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("提交立即还款异常");
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "逾期中弹框接口",response = RestResponse.class)
    @RequestMapping(value = "getOutTimeContinue/{planId}",method = RequestMethod.POST)
    public Object getOutTimeContinue(@PathVariable Long planId){
    	RestResponse response;
    	try {
    		response = mineService.getOutTimeContinue(planId);
    	} catch (Exception e) {
    		e.printStackTrace();
    		log.info("逾期中弹框接口异常");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    	}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "一次性结清列表接口",response = RestResponse.class)
    @RequestMapping(value = "getOneTimePayment",method = RequestMethod.POST)
    public Object getOneTimePayment(){
    	RestResponse response;
    	try {
    		response = mineService.getOneTimePayment();
    	} catch (Exception e) {
    		e.printStackTrace();
    		log.info("一次性结清列表接口报错");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    	}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "一次性结清作废",response = RestResponse.class)
    @RequestMapping(value = "getOneTimePaymentContinueZF",method = RequestMethod.POST)
    public Object getOneTimePaymentContinueZf(@RequestBody @Valid ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO,BindingResult result){
    	RestResponse response;
    	try {
    		response = mineService.getOneTimePaymentContinueZf(applyOnetimePaymentContinueDTO);
    	} catch (Exception e) {
    		e.printStackTrace();
    		log.info("一次性结清作废接口报错");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    	}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "一次性结清续划",response = RestResponse.class)
    @RequestMapping(value = "getOneTimePaymentContinueXh",method = RequestMethod.POST)
    public Object getOneTimePaymentContinueXh(@RequestBody @Valid ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO,BindingResult result){
    	RestResponse response;
    	try {
    		response = mineService.getOneTimePaymentContinueXh(applyOnetimePaymentContinueDTO);
    	} catch (Exception e) {
    		e.printStackTrace();
    		log.info("一次性结清续划接口报错");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    	}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "一次性结清划扣",response = RestResponse.class)
    @RequestMapping(value = "getOneTimePaymentContnueHk",method = RequestMethod.POST)
    public Object getOneTimePaymentContnueHk(){
    	RestResponse response;
    	try {
    		response = mineService.getOneTimePaymentContnueHk();
    	} catch (Exception e) {
    		e.printStackTrace();
    		log.info("一次性结清续划接口报错");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    	}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
   
    @ApiOperation(value = "历史申请记录列表",response = RestResponse.class)
    @RequestMapping(value = "onetimePaymentHistory",method = RequestMethod.POST)
    public Object onetimePaymentHistory(){
    	RestResponse response;
    	try {
    		response = mineService.onetimePaymentHistory();
		} catch (Exception e) {
    		e.printStackTrace();
    		log.info("历史申请记录 列表报错");
    		response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "借款确认查询借款信息",response = LoanConfirmationVO.class)
    @AutoValid
    @RequestMapping(value = "getLoanConfirmation",method = RequestMethod.POST)
    public Object getLoanConfirmation(@RequestBody @Valid LoanConfirmationDTO dto, BindingResult result){
        RestResponse response;
        try {
            response = mineService.getLoanConfirmation(dto);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("借款确认查询借款信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "查询用户协议信息",response = RestResponse.class)
    @RequestMapping(value = "getSign",method = RequestMethod.POST)
    public Object getSign(){
        RestResponse response;
        try {
            response = mineService.getSign();
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取用户协议信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "查询推荐人信息",response = ReferrerInfoVO.class)
    @RequestMapping(value = "getReferrer",method = RequestMethod.POST)
    public Object getReferrer(){
        RestResponse response;
        try {
            response = mineService.getReferrer();
        }catch (Exception e){
            e.printStackTrace();
            log.error("查询推荐人信息异常"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return  new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }
}
