package com.xyb.order.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

/**
 * @author : jiangzhongyan
 * @projectName : finance-api
 * @package : com.xyb.validator
 * @description : 接口字段校验结果处理类
 * @createDate : 2017/12/16 12:43
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Component
public class ValidatorResultHandler {

    /**
     * 获取校验结果
     * @param result
     * @return
     */
    public String getErrorCount(BindingResult result) {
        StringBuffer stringBuffer = new StringBuffer();
        if (result.getFieldErrorCount() > 0) {
            for (FieldError fieldError : result.getFieldErrors()) {
                stringBuffer.append(fieldError.getField() + "=" + fieldError.getDefaultMessage());
            }
        }
        if (result.getGlobalErrorCount() > 0) {
            for (ObjectError objectError : result.getGlobalErrors()) {
                stringBuffer.append(objectError.getCode() + ":" + objectError.getDefaultMessage());
            }
        }
        return stringBuffer.toString();
    }
}
