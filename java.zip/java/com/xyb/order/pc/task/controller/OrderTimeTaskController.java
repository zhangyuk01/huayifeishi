package com.xyb.order.pc.task.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.task.service.OrderTimeTaskService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * 定时任务启动类
 * @author         xieqingyang
 * @date           2018/8/31 下午2:33
*/
@Controller
@RequestMapping("order/orderTimeTask")
public class OrderTimeTaskController {

    @Reference
    private OrderTimeTaskService orderTimeTaskService;

    @ApiOperation(value = "材料补充冻结定时任务主动触发")
    @RequestMapping(value = "openapi/querySignChecks", method = RequestMethod.GET)
    public Object querySignChecks() {
        orderTimeTaskService.materialSupplementFrozen();
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "外访自动冻结定时任务主动触发")
    @RequestMapping(value = "openapi/outBoundFreece", method = RequestMethod.GET)
    public Object outBoundFreece() {
        orderTimeTaskService.outBoundFreece();
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "合同录入自动冻结定时任务主动触发")
    @RequestMapping(value = "openapi/contractFreece", method = RequestMethod.GET)
    public Object contractFreece() {
        orderTimeTaskService.contractFreece();
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "客服业务统计报表数据定时生成定时任务主动触发")
    @RequestMapping(value = "openapi/reportBusinessStatisticsByCusService", method = RequestMethod.GET)
    public Object reportBusinessStatisticsByCusService() {
        orderTimeTaskService.reportBusinessStatisticsByCusService();
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "速贷产品流标处理任务")
    @RequestMapping(value = "openapi/bidRepeal", method = RequestMethod.GET)
    public Object bidRepeal() {
        orderTimeTaskService.bidRepeal();
        RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
