package com.xyb.order.pc.risk.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.util.GetIpAndMacUtil;
import com.xyb.order.common.util.RequestUtils;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.risk.model.RiskSubmitDO;
import com.xyb.order.pc.risk.model.RiskSubmitDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListDO;
import com.xyb.order.pc.risk.model.RiskSubmitListDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDTO;
import com.xyb.order.pc.risk.service.RiskSubmitService;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.ExportFileUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 风险提报
 * @author         xieqingyang
 * @date           2018/4/2 11:48 AM
*/
@Controller
@RequestMapping("/order/riskSubmit")
public class RiskSubmitController {

    private static final Logger log = LoggerFactory.getLogger(RiskSubmitController.class);

    @Reference
    private RiskSubmitService riskSubmitService;
    @Autowired
    private ExportExcelService exportExcelService;

    @ApiOperation(value = "查询风险提报列表信息",response = RiskSubmitListDO.class)
    @RequestMapping(value = "listRiskSubmit/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listConsultation(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody RiskSubmitListDTO riskSubmitListDTO){
        RestResponse response;
        try {
            response = this.riskSubmitService.listRiskSubmitPage(pageNumber,pageSize, riskSubmitListDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("风险提报列表查询接口异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    
    @ApiOperation(value = "风险提报导出",response = RestResponse.class)
    @RequestMapping(value = "outRiskSubmitExport", method = RequestMethod.GET)
    public Object outRiskSubmitExport(HttpServletRequest request, HttpServletResponse response) {
    	RiskSubmitListExportDTO riskSubmitListExportDTO = (RiskSubmitListExportDTO) RequestUtils.getRequestBean(RiskSubmitListExportDTO.class, request);
    	RestResponse rspBody;
    	ResponseEntity responseEntity;
    	List<RiskSubmitListExportDO> list = this.riskSubmitService.outRiskSubmitExport(riskSubmitListExportDTO);
    	try {
    		String[] headers = {"申请编号","客户姓名","手机号码","身份证号","销售团队","销售人员","客服人员","推荐人","申请时间","申请产品",
    				"一级授信产品", "一级授信金额", "一级授信期数", "确认金额", "终极授信金额", "当前状态","提报时间","提报类型"};
    		File file = exportExcelService.exportExcel("风险提报导出.xlsx", headers, list);
			rspBody = new RestResponse(MsgErrCode.SUCCESS);
			rspBody.setData(file);
			ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
			responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
    	} catch (Exception e) {
    		e.printStackTrace();
    		rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    		responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
    	}
    	return responseEntity;
    }

    @ApiOperation(value = "查询风险提报详情",response = RiskSubmitDO.class)
    @RepeatTokenFactory
    @RequestMapping(value = "getRiskSubmitInfo/{mainId}",method = RequestMethod.GET)
    public Object getRiskSubmitInfo(@PathVariable Long mainId){
        RestResponse response;
        try {
            response = this.riskSubmitService.getRiskSubmitInfo(mainId);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询风险提报详情异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "提交风险提报",response = RestResponse.class)
    @AutoValid
    @RepeatTokenValid
    @RequestMapping(value = "insertReconsider",method = RequestMethod.POST)
    public Object insertReconsider(@RequestBody @Valid RiskSubmitDTO riskSubmitDTO, BindingResult result,HttpServletRequest request){
        RestResponse response;
        try {
        	String macAddr = null;
	    	String ipAddr = null;
	    	try {
	    		macAddr = GetIpAndMacUtil.getMacAddress();
			    ipAddr = GetIpAndMacUtil.getIpAddress(request);
			} catch (Exception e) {
				e.printStackTrace();
			}
            response = this.riskSubmitService.insertRiskSubmit(riskSubmitDTO,ipAddr,macAddr);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("提交风险提报异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
