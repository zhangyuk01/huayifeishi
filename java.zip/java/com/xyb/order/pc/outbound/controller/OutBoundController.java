package com.xyb.order.pc.outbound.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.outbound.model.OutBoundDeleteDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSaveDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitCreditAndPropertySurveyDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitCreditDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitPropertySurveyDTO;
import com.xyb.order.pc.outbound.model.OutBoundQueryDTO;
import com.xyb.order.pc.outbound.service.OutBoundService;
import com.xyb.order.validator.ValidatorResultHandler;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.outbound.controller
 * @description : 外访controller层
 * @createDate : 2018/5/15 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/order/outbound")
public class OutBoundController{
	
	@Reference
	private OutBoundService outBoundService;
	
    @Autowired
    private ValidatorResultHandler handler;
	/**
     * 外访列表
     */
	@AutoValid
	@ApiOperation(value = "实地征信与产调列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryOutBounds(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid OutBoundQueryDTO outBoundQueryDTO, BindingResult result) {
        RestResponse restResponse = outBoundService.listOutBound(pageNumber,pageSize,outBoundQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 外访 调查详情
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "外访 调查详情",response = RestResponse.class)
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public Object updateOutBound(@RequestBody @Valid OutBoundDetailDTO outBoundDetailDTO, BindingResult result) {
        RestResponse restResponse = outBoundService.updateOutBound(outBoundDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }

	/**
	 * 外访 查询详情
	 */
	@AutoValid
	@ApiOperation(value = "外访 调查详情",response = RestResponse.class)
    @RequestMapping(value = "getOutBoundDetail", method = RequestMethod.POST)
    public Object getOutBoundDetail(@RequestBody @Valid OutBoundDetailDTO outBoundDetailDTO, BindingResult result) {
        RestResponse restResponse = outBoundService.getOutBoundDetail(outBoundDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 外访 调查暂存
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "外访 调查暂存",response = RestResponse.class)
    @RequestMapping(value = "save", method = RequestMethod.POST)
    public Object saveOutBounds(@RequestBody @Valid OutBoundDetailSaveDTO outBoundDetailSaveDTO, BindingResult result) {
        RestResponse restResponse = outBoundService.saveOutBound(outBoundDetailSaveDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }

	/**
	 * 实地征信提交
	 */
	@RepeatTokenValid
	@ApiOperation(value = "实地征信提交",response = RestResponse.class)
    @RequestMapping(value = "submitCredit", method = RequestMethod.POST)
    public Object submitCreditOutBounds(@RequestBody @Valid OutBoundDetailSubmitCreditDTO outBoundDetailSubmitCreditDTO, BindingResult result) {
		RestResponse restResponse = null;
		if (result.hasErrors()) {
	        String errorStr = handler.getErrorCount(result);
	        restResponse = new RestResponse(MsgErrCode.FAIL);
	        restResponse.setDescription(errorStr);
	    }else{
	        restResponse = outBoundService.submitCreditOutBounds(outBoundDetailSubmitCreditDTO);
	    } 
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }	
	/**
	 * 产调提交
	 */
	@RepeatTokenValid
	@ApiOperation(value = "产调提交",response = RestResponse.class)
    @RequestMapping(value = "submitPropertySurvey", method = RequestMethod.POST)
    public Object submitPropertySurveyOutBounds(@RequestBody @Valid OutBoundDetailSubmitPropertySurveyDTO outBoundDetailSubmitPropertySurveyDTO, BindingResult result) {
		RestResponse restResponse = null;
		if (result.hasErrors()) {
	        String errorStr = handler.getErrorCount(result);
	        restResponse = new RestResponse(MsgErrCode.FAIL);
	        restResponse.setDescription(errorStr);
	    }else{
	        restResponse = outBoundService.submitPropertySurveyOutBounds(outBoundDetailSubmitPropertySurveyDTO);
	    } 
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
	 * 实地征信与产调提交
	 */
	@RepeatTokenValid
	@ApiOperation(value = "实地征信与产调提交",response = RestResponse.class)
    @RequestMapping(value = "submitCreditAndPropertySurvey", method = RequestMethod.POST)
    public Object submitCreditAndPropertySurveyBounds(@RequestBody @Valid OutBoundDetailSubmitCreditAndPropertySurveyDTO outBoundDetailSubmitCreditAndPropertySurveyDTO, BindingResult result) {
		RestResponse restResponse = null;
		if (result.hasErrors()) {
	        String errorStr = handler.getErrorCount(result);
	        restResponse = new RestResponse(MsgErrCode.FAIL);
	        restResponse.setDescription(errorStr);
	    }else{
	        restResponse = outBoundService.submitCreditAndPropertySurveyOutBounds(outBoundDetailSubmitCreditAndPropertySurveyDTO);
	    } 
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
	 * 外访实地征信删除
	 */
	@AutoValid
	@ApiOperation(value = "外访实地征信删除",response = RestResponse.class)
    @RequestMapping(value = "deleteOutbound", method = RequestMethod.POST)
    public Object deleteOutbound(@RequestBody @Valid OutBoundDeleteDTO outBoundDeleteDTO, BindingResult result) {
        RestResponse restResponse = outBoundService.deleteOutbound(outBoundDeleteDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
}
