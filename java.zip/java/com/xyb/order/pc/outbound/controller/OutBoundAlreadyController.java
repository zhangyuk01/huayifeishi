package com.xyb.order.pc.outbound.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.RequestUtils;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyListExportVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyQueryDTO;
import com.xyb.order.pc.outbound.service.OutBoundAlreadyService;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.ExportFileUtil;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.outbound.controller
 * @description : 外访已办controller层
 * @createDate : 2018/5/17 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/order/outbound/already")
public class OutBoundAlreadyController {
	
	@Reference
	private OutBoundAlreadyService outBoundAlreadyService;
    @Autowired
    private ExportExcelService exportExcelService;
	
	/**
     * 外访已办列表
     */
	@AutoValid
	@ApiOperation(value = "外访已办列表(外访人员/客服经理/城市经理)",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryOutBoundAlreadys(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO, BindingResult result) {
        RestResponse restResponse = outBoundAlreadyService.queryOutBoundAlreadys(pageNumber,pageSize,outBoundAlreadyQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
     * 外访已办导出
     */
	@AutoValid
	@ApiOperation(value = "外访已办导出(外访人员/客服经理/城市经理)",response = RestResponse.class)
    @RequestMapping(value = "listExport", method = RequestMethod.GET)
    public Object outBoundAlreadysExport(HttpServletRequest request, HttpServletResponse response) {
        OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO = (OutBoundAlreadyQueryDTO) RequestUtils.getRequestBean(OutBoundAlreadyQueryDTO.class, request);
        ResponseEntity responseEntity;
        RestResponse rspBody = null;
        try {
        	List<OutBoundAlreadyListExportVO> list = outBoundAlreadyService.outBoundAlreadysExport(outBoundAlreadyQueryDTO);
            String[] headers = {"申请编号", "进件机构", "客户姓名", "手机号码", "销售团队", "团队经理", "销售人员", "推荐人","申请产品"
                    , "一级授信产品", "外访类型", "外访返回时间", "实地日期", "产调日期", "征信负责人", "合同生效日期", "合同状态"
                    };
            //创建,导出excel
            File file = exportExcelService.exportExcel("外访已办.xlsx", headers, list);
            rspBody = new RestResponse(MsgErrCode.SUCCESS);
            rspBody.setData(file);
            ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
            responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
        }
        return responseEntity;
    }
}
