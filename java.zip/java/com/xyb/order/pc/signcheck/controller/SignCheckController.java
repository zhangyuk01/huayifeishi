package com.xyb.order.pc.signcheck.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.signcheck.model.SignCheckDetailDTO;
import com.xyb.order.pc.signcheck.model.SignCheckQueryDTO;
import com.xyb.order.pc.signcheck.service.SignCheckService;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.signcheck.controller
 * @description : 签约前核验controller层
 * @createDate : 2018/5/18 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("order/signcheck/")
public class SignCheckController {
	
	@Reference
	private SignCheckService signCheckService;

	/**
     * 签约前核验列表
     */
	@AutoValid
	@ApiOperation(value = "签约前核验列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object querySignChecks(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid SignCheckQueryDTO signCheckQueryDTO, BindingResult result) {
        RestResponse restResponse = signCheckService.querySignChecks(pageNumber,pageSize,signCheckQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 签约前核验详情页
	 */
	@AutoValid
	@ApiOperation(value = "签约前核验详情信息",response = RestResponse.class)
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public Object updateSignCheck(@RequestBody @Valid SignCheckDetailDTO signCheckDetailDTO, BindingResult result) {
        RestResponse restResponse = signCheckService.updateSignCheck(signCheckDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 签约前核验提交
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "签约前核验提交",response = RestResponse.class)
    @RequestMapping(value = "submit", method = RequestMethod.POST)
    public Object submitSignCheck(@RequestBody @Valid SignCheckDetailDTO signCheckDetailDTO, BindingResult result) {
        RestResponse restResponse = signCheckService.submitSignCheck(signCheckDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
}
