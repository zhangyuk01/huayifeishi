package com.xyb.order.pc.deposit.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;
import com.xyb.order.pc.deposit.model.BankChangeVO;
import com.xyb.order.pc.deposit.model.DepositChangeDO;
import com.xyb.order.pc.deposit.model.DepositChangeDTO;
import com.xyb.order.pc.deposit.service.DepositService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 用户账户变更操作
 * @author         xieqingyang
 * @date           2018/7/20 下午7:02
*/
@Controller
@RequestMapping("/order/deposit")
public class DepositController {

    private static final Logger log = LoggerFactory.getLogger(DepositController.class);

    @Reference
    private DepositService depositService;

    @ApiOperation(value = "资料变更审核列表",response = BankChangeVO.class)
    @RequestMapping(value = "depositChangePage/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object depositChangePage(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody DepositChangeDTO depositChangeDTO) {
        RestResponse response;
        try {
            response = depositService.depositChangeNoPage(pageNumber, pageSize, depositChangeDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("资料变更审核列表异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "资料变更审核操作",response = RestResponse.class)
    @RequestMapping(value = "depositChangeOperation", method = RequestMethod.POST)
    public Object depositChangeOperation(@RequestBody @Valid DepositChangeDO depositChangeDO, BindingResult result) {
        RestResponse response;
        try {
            response = depositService.depositChangeOperationNo(depositChangeDO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("资料变更审核操作异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "签约协议完成后确认提交接口",response = RestResponse.class)
    @RequestMapping(value = "submit/{id}", method = RequestMethod.GET)
    public Object submit(@PathVariable("id") Long id) {
        RestResponse response;
        try {
            response = depositService.submit(id);
        }catch (Exception e){
            e.printStackTrace();
            log.error("签约协议完成后确认提交接口异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }



    @AutoValid
    @ApiOperation(value = "获取当前用户待绑卡渠道列表",response = RestResponse.class)
    @RequestMapping(value = "getUserNotBindChannel", method = RequestMethod.POST)
    public Object getUserNotBindChannel(@RequestBody @Valid ThirdPayBindDTO thirdPayBindDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositService.getUserNotBindChannel(thirdPayBindDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取当前用户待绑卡渠道列表接口异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "协议支付-预绑卡",response = RestResponse.class)
    @RequestMapping(value = "preBindCardEntrance", method = RequestMethod.POST)
    public Object preBindCardEntrance(@RequestBody @Valid ThirdPayBindPreDTO thirdPayBindPreDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositService.preBindCardEntrance(thirdPayBindPreDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("协议支付-预绑卡接口异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "协议支付-预绑卡--重发短信",response = RestResponse.class)
    @RequestMapping(value = "resendMessage", method = RequestMethod.POST)
    public Object resendMessage(@RequestBody @Valid ThirdPayBindPreResendDTO thirdPayBindPreResendDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositService.resendMessage(thirdPayBindPreResendDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("协议支付--预绑卡--重发短信接口异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "协议支付--确认绑卡",response = RestResponse.class)
    @RequestMapping(value = "confirmBianCardEntrance", method = RequestMethod.POST)
    public Object confirmBianCardEntrance(@RequestBody @Valid ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO, BindingResult result) {
        RestResponse response;
        try {
            response = depositService.confirmBianCardEntrance(thirdPayBindConfirmBianCardEntranceDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("协议支付--确认绑卡接口异常："+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<>(response, response.getHttpcode());
    }
}
