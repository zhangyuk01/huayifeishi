package com.xyb.order.pc.apply.already.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.RequestUtils;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyListExportVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyQueryDTO;
import com.xyb.order.pc.apply.already.service.ApplyAlreadyService;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyListExportVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyQueryDTO;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.ExportFileUtil;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.apply.already.controller
 * @description : 签约前核验controller层
 * @createDate : 2018/5/18 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("order/apply/already")
public class ApplyAlreadyController {
	
	@Reference
	private ApplyAlreadyService applyAlreadyService;
    @Autowired
    private ExportExcelService exportExcelService;
	/**
     * 申请已办
     */
	@AutoValid
	@ApiOperation(value = "申请已办（客服专员/团队经理/客服经理/城市经理）列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryApplyAlreadys(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid ApplyAlreadyQueryDTO applyAlreadyQueryDTO, BindingResult result) {
        RestResponse restResponse = applyAlreadyService.queryApplyAlreadys(pageNumber,pageSize,applyAlreadyQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
     * 申请已办导出
     */
	@AutoValid
	@ApiOperation(value = "申请已办导出(客服专员/团队经理/客服经理/城市经理)",response = RestResponse.class)
    @RequestMapping(value = "listExport", method = RequestMethod.GET)
    public Object outBoundAlreadysExport(HttpServletRequest request, HttpServletResponse response) {
		ApplyAlreadyQueryDTO applyAlreadyQueryDTO = (ApplyAlreadyQueryDTO) RequestUtils.getRequestBean(ApplyAlreadyQueryDTO.class, request);
        RestResponse rspBody;
        ResponseEntity responseEntity;
        try {
            String[] headers = {"申请编号", "客户姓名", "手机号码", "身份证号", "销售团队", "销售人员", "客服人员","推荐人"
                    , "申请产品", "是否循环贷", "是否签约前核验", "当前状态", "进件时间", "审批时间", "一级授信产品", 
                    "一级授信金额","确认金额", "一级授信期数",  "费率等级","是否拒贷","拒贷原因","合同生效日期","终极授信金额","月还金额","还款日","是否已结清","复议次数","第一次复议日期","第二次复议日期","进件机构"};
        	if(applyAlreadyQueryDTO.getType() != null && applyAlreadyQueryDTO.getType().equals("D")){
        		/**城市经理添加进件机构导出*/
        		headers = new String[]{"申请编号", "客户姓名", "手机号码", "身份证号", "销售团队", "销售人员", "客服人员","推荐人"
                        , "申请产品", "是否循环贷", "是否签约前核验", "当前状态", "进件时间", "审批时间", "一级授信产品", 
                         "一级授信金额", "确认金额","一级授信期数", "费率等级","是否拒贷","拒贷原因","合同生效日期","终极授信金额","月还金额","还款日","是否已结清","复议次数","第一次复议日期","第二次复议日期","进件机构"};
        	}
            List<ApplyAlreadyListExportVO> list = applyAlreadyService.applyAlreadyExport(applyAlreadyQueryDTO);
            File file = exportExcelService.exportExcel("申请已办.xlsx", headers, list);
            rspBody = new RestResponse(MsgErrCode.SUCCESS);
            rspBody.setData(file);
            ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
            responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
        }
        return responseEntity;
    }
	
	/**
	 * 申请已办-复议记录信息
	 * @param applyId
	 * @return
	 */
	@ApiOperation(value = "申请已办-复议记录信息",response = RestResponse.class)
    @RequestMapping(value = "applyAlreadyRreconsiderInfo/{applyId}", method = RequestMethod.GET)
    public Object applyAlreadyRreconsiderInfo(@PathVariable Long applyId) {
        RestResponse restResponse = applyAlreadyService.applyAlreadyRreconsiderInfo(applyId);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }

}
