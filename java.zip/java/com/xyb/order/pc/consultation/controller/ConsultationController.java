package com.xyb.order.pc.consultation.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.wordnik.swagger.annotations.ApiOperation;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.consultation.model.ConsultationDO;
import com.xyb.order.pc.consultation.model.ConsultationDTO;
import com.xyb.order.pc.consultation.model.ConsultationInFoDO;
import com.xyb.order.pc.consultation.model.ServiceUpdateDTO;
import com.xyb.order.pc.consultation.service.ConsultationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * 咨询管理功能
 * @author         xieqingyang
 * @date           2018/3/22 11:39 AM
*/
@Controller
@RequestMapping("/order/consultation")
public class ConsultationController {

    private static final Logger log = LoggerFactory.getLogger(ConsultationController.class);

    @Reference
    private ConsultationService consultationService;

    @ApiOperation(value = "查询咨询列表信息",response = ConsultationDO.class)
    @RequestMapping(value = "listConsultation/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listConsultation(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody ConsultationDTO consultationDTO){
        RestResponse response;
        try {
            response = this.consultationService.listConsultationPage(pageNumber,pageSize, consultationDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询咨询列表信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "查询咨询详细信息",response = ConsultationInFoDO.class,notes = "咨询列表点击申请编号查询咨询详细信息")
    @RequestMapping(value = "getConsultationInFo/{applyNum}/{applyId}",method = RequestMethod.GET)
    public Object getConsultationInFo(@PathVariable String applyNum,@PathVariable Long applyId){
        RestResponse response;
        try {
            response = this.consultationService.getConsultationInFo(applyNum,applyId);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询咨询详细信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "咨询自动分拣开关",response = RestResponse.class)
    @RequestMapping(value = "sortingSwitch/{state}",method = RequestMethod.GET)
    public Object sortingSwitch(@PathVariable String state){
        RestResponse response;
        try {
            response = this.consultationService.sortingSwitch(state);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("咨询自动分拣开关异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "咨询重新分配客服",response = RestResponse.class)
    @RequestMapping(value = "updateConsultService",method = RequestMethod.POST)
    public Object updateConsultService(@RequestBody @Valid ServiceUpdateDTO serviceUpdateDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.consultationService.updateConsultService(serviceUpdateDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("咨询重新分配客服异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "查询当前营业部的自动分件状态")
    @RequestMapping(value = "getSwitchState",method = RequestMethod.GET)
    public Object getSwitchState(){
        RestResponse response;
        try {
            response = this.consultationService.getSwitchState();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询当前营业部的自动分件状态异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
