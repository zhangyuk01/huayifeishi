package com.xyb.order.pc.team.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.team.model.ChangeSaleTeamDTO;
import com.xyb.order.pc.team.model.SaleTeamChangeDO;
import com.xyb.order.pc.team.model.SaleTeamChangeDTO;
import com.xyb.order.pc.team.service.SaleTeamChangeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 销售团队变更
 * @author         xieqingyang
 * @date           2018/4/10 11:53 AM
*/
@Controller
@RequestMapping("/order/saleTeamChange")
public class SaleTeamChangeController {

    private static final Logger log = LoggerFactory.getLogger(SaleTeamChangeController.class);

    @Reference
    private SaleTeamChangeService saleTeamChangeService;

    @ApiOperation(value = "查询团队变更列表",response = SaleTeamChangeDO.class)
    @RequestMapping(value = "listSaleUserPage/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listSaleUserPage(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody SaleTeamChangeDTO saleTeamChangeDTO){
        RestResponse response;
        try {
            response = this.saleTeamChangeService.listSaleUserPage(pageNumber,pageSize, saleTeamChangeDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询团队变更列表异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @AutoValid
    @ApiOperation(value = "变更销售团队",response = RestResponse.class)
    @RequestMapping(value = "changeSaleTeam",method = RequestMethod.POST)
    public Object changeSaleTeam(@RequestBody @Valid ChangeSaleTeamDTO changeSaleTeamDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.saleTeamChangeService.changeSaleTeam(changeSaleTeamDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("变更销售团队异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
