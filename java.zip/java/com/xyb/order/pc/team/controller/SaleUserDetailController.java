package com.xyb.order.pc.team.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.DateTimeUtil;
import com.beiming.kun.utils.RequestUtils;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.team.model.SaleUserDetailDO;
import com.xyb.order.pc.team.model.SaleUserDetailDTO;
import com.xyb.order.pc.team.model.SaleUserDetailExportNoValidDO;
import com.xyb.order.pc.team.model.SaleUserDetailExportValidDO;
import com.xyb.order.pc.team.service.SaleUserDetailService;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.ExportFileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * 团队管理
 * @author         xieqingyang
 * @date           2018/4/8 11:55 AM
*/
@Controller
@RequestMapping("/order/saleUserDetail")
public class SaleUserDetailController {

    private static final Logger log = LoggerFactory.getLogger(SaleUserDetailController.class);

    @Reference
    private SaleUserDetailService managementService;
    @Autowired
    private ExportExcelService exportExcelService;

    @ApiOperation(value = "查询销售人员明细表列表信息",response = SaleUserDetailDO.class)
    @RequestMapping(value = "listSaleUserDetail/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listSaleUserDetailPage(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody SaleUserDetailDTO saleUserDetailDTO){
        RestResponse response;
        try {
            response = this.managementService.listSaleUserDetailPage(pageNumber,pageSize, saleUserDetailDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询销售人员明细表列表信息异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "导出销售人员明细表列表",response = SaleUserDetailDO.class)
    @RequestMapping(value = "listSaleUserDetailExport",method = RequestMethod.GET)
    public Object listSaleUserDetailExport(HttpServletRequest request, HttpServletResponse response){
        String loginId = request.getParameter("loginId");
        String orgTeamId = request.getParameter("orgTeamId");
        String isValid = request.getParameter("isValid");
        SaleUserDetailDTO saleUserDetailDTO = new SaleUserDetailDTO();
        saleUserDetailDTO.setIsValid(isValid);
        saleUserDetailDTO.setOrgTeamId(orgTeamId);
        saleUserDetailDTO.setLoginId(loginId);
        ResponseEntity responseEntity;
        RestResponse rspBody;
        File file;
        try {
            Map<String,Object> map = managementService.listSaleUserDetailExport(saleUserDetailDTO);
            String[] headers = (String[]) map.get("headers");
            List<SaleUserDetailExportValidDO> saleUserDetailExportValidDOS;
            List<SaleUserDetailExportNoValidDO> saleUserDetailExportNoValidDOS;
            if (SysDictEnum.IS_VALID.getCode().toString().equals(saleUserDetailDTO.getIsValid())){
                saleUserDetailExportValidDOS = (List<SaleUserDetailExportValidDO>)map.get("info");
                file = exportExcelService.exportExcel("销售人员明细.xlsx", headers,saleUserDetailExportValidDOS);
            }else {
                saleUserDetailExportNoValidDOS = (List<SaleUserDetailExportNoValidDO>)map.get("info");
                file = exportExcelService.exportExcel("销售人员明细.xlsx", headers, saleUserDetailExportNoValidDOS);
            }
            rspBody = new RestResponse(MsgErrCode.SUCCESS);
            rspBody.setData(file);
            ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
            responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
        }
        return responseEntity;
    }
}
