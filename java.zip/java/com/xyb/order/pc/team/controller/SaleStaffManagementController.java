package com.xyb.order.pc.team.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.team.model.*;
import com.xyb.order.pc.team.service.SaleStaffManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 销售人员管理
 * @author         xieqingyang
 * @date           2018/4/10 11:49 AM
*/
@Controller
@RequestMapping("/order/saleStaffManagement")
public class SaleStaffManagementController {

    private static final Logger log = LoggerFactory.getLogger(SaleStaffManagementController.class);

    @Reference
    private SaleStaffManagementService saleStaffManagementService;

    @ApiOperation(value = "查询销售人员管理列表",response = SaleStaffManagementDO.class)
    @RequestMapping(value = "listSaleStaffManagement/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listSaleStaffManagement(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody SaleStaffManagementDTO saleStaffManagementDTO){
        RestResponse response;
        try {
            response = this.saleStaffManagementService.listSaleStaffManagementPage(pageNumber,pageSize, saleStaffManagementDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询销售人员管理列表异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    @RepeatTokenFactory("update_sale_user")
    @ApiOperation(value = "修改销售人员详细信息",response = UpdateSaleUserDO.class)
    @RequestMapping(value = "querySaleUserInFo/{saleNum}",method = RequestMethod.GET)
    public Object querySaleUserInFo(@PathVariable Long saleNum){
        RestResponse response;
        try {
            response = this.saleStaffManagementService.querySaleUserInFo(saleNum);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("修改销售人员详细信息异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "修改销售人员信息",response = RestResponse.class)
    @AutoValid
    @RepeatTokenValid
    @RequestMapping(value = "updateSaleUserInFo",method = RequestMethod.POST)
    public Object updateSaleUserInFo(@RequestBody @Valid UpdateSaleUserDTO updateSaleUserDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.saleStaffManagementService.updateSaleUserInFo(updateSaleUserDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("修改销售人员信息异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
    @RepeatTokenFactory("insert_sale_user")
    @ApiOperation(value = "添加销售人员信息之前需要调用的接口",response = InsertSaleUserDO.class)
    @RequestMapping(value = "beforeInsertSaleUserInFo",method = RequestMethod.POST)
    public Object beforeInsertSaleUserInFo(){
        RestResponse response;
        try {
            response = this.saleStaffManagementService.beforeInsertSaleUserInFo();
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("添加销售人员信息之前需要调用的接口异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @AutoValid
    @ApiOperation(value = "添加销售人员信息",response = RestResponse.class)
    @RepeatTokenValid
    @RequestMapping(value = "insertSaleUserInFo",method = RequestMethod.POST)
    public Object insertSaleUserInFo(@RequestBody @Valid InsertSaleUserDTO insertSaleUserDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.saleStaffManagementService.insertSaleUserInFo(insertSaleUserDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("添加销售人员信息异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
