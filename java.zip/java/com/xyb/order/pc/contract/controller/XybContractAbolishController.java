package com.xyb.order.pc.contract.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.util.GetIpAndMacUtil;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractAbolishQueryDTO;
import com.xyb.order.pc.contract.service.XybContractAbolishService;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.contract.controller
 * @description : 合同作废controller层
 * @createDate : 2018/5/3 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/order/contract/abolish")
public class XybContractAbolishController {
    private static final Logger logger = LoggerFactory.getLogger(XybContractAbolishController.class);

	@Reference
	private XybContractAbolishService xybContractAbolishService;
	/**
     * 合同废除列表
     */
	@AutoValid
	@ApiOperation(value = "合同废除列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryContracts(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid XybContractAbolishQueryDTO xybContractAbolishQueryDTO, BindingResult result) {
        RestResponse restResponse = xybContractAbolishService.listAbolishContract(pageNumber,pageSize,xybContractAbolishQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
	 * 合同废除
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "合同废除",response = RestResponse.class)
    @RequestMapping(value = "abolish", method = RequestMethod.POST)
    public Object abolishContract(@RequestBody @Valid XybContractAbolishDTO xybContractAbolishDTO, BindingResult result,HttpServletRequest request) {
        RestResponse restResponse = null;
    	String macAddr = null;
    	String ipAddr = null;
    	try {
    		macAddr = GetIpAndMacUtil.getMacAddress();
		    ipAddr = GetIpAndMacUtil.getIpAddress(request);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("推标获取本机mac或客户端ip地址失败", e);
		}
    	restResponse = xybContractAbolishService.abolishContract(xybContractAbolishDTO,ipAddr,macAddr);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
}
