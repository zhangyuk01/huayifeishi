package com.xyb.order.pc.contract.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.util.GetIpAndMacUtil;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;
import com.xyb.order.pc.contract.service.XybContractAuditService;
import com.xyb.order.validator.ValidatorResultHandler;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.contract.controller
 * @description : 进件合同审核controller层
 * @createDate : 2018/4/19 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/order/contract/audit/")
public class XybContractAuditController {
    private static final Logger logger = LoggerFactory.getLogger(XybContractAuditController.class);

	
	@Reference
    private XybContractAuditService xybContractAuditService;
    @Autowired
    private ValidatorResultHandler handler;

	/**
     * 合同审核列表
     */
	@AutoValid
	@ApiOperation(value = "合同审核列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryContracts(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid XybContractAuditQueryDTO xybContractAuditQueryDTO, BindingResult result,HttpServletRequest request) {
        RestResponse restResponse = xybContractAuditService.listContractAudit(pageNumber,pageSize,xybContractAuditQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同审核详情页
	 */
	@AutoValid
	@ApiOperation(value = "合同审核详情信息",response = RestResponse.class)
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public Object updateContract(@RequestBody @Valid XybContractAuditDetailDTO xybContractAuditDetailDTO, BindingResult result) {
        RestResponse restResponse = xybContractAuditService.updateContractAudit(xybContractAuditDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同审核暂存
	 */
	@AutoValid
	@ApiOperation(value = "合同审核暂存",response = RestResponse.class)
    @RequestMapping(value = "save", method = RequestMethod.POST)
    public Object saveContract(@RequestBody @Valid XybContractAuditDetailSaveDTO xybContractAuditDetailSaveDTO, BindingResult result) {
        RestResponse restResponse = xybContractAuditService.saveContractAudit(xybContractAuditDetailSaveDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同审核提交
	 */
	@RepeatTokenValid
	@ApiOperation(value = "合同审核提交",response = RestResponse.class)
    @RequestMapping(value = "sumbit", method = RequestMethod.POST)
    public Object submitContract(@RequestBody @Valid XybContractAuditDetailSubmitDTO xybContractAuditDetailSubmitDTO, BindingResult result,HttpServletRequest request) {
		RestResponse restResponse = null;
		if (result.hasErrors()) {
	        String errorStr = handler.getErrorCount(result);
	        restResponse = new RestResponse(MsgErrCode.FAIL);
	        restResponse.setDescription(errorStr);
	    }else{
	    	String macAddr = null;
	    	String ipAddr = null;
	    	try {
	    		macAddr = GetIpAndMacUtil.getMacAddress();
			    ipAddr = GetIpAndMacUtil.getIpAddress(request);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("推标获取本机mac或客户端ip地址失败", e);
			}
	        restResponse = xybContractAuditService.submitContractAudit(xybContractAuditDetailSubmitDTO,macAddr,ipAddr);
	    }
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }	

}
