package com.xyb.order.pc.contract.controller;


import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.currency.model.ResponseResult;
import com.xyb.order.pc.contract.model.ApplyRevokeDTO;
import com.xyb.order.pc.contract.service.ApplyRevokeService;
import com.xyb.order.validator.ValidatorResultHandler;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.contract.controller
 * @description : 合同作废深圳通知controller层
 * @createDate : 2018/5/11 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/applyRevoke/")
public class ApplyRevokeController {
    @Autowired
    private ValidatorResultHandler handler;
	
	/**
	 * 日志
	 */
	private final static Logger log = Logger.getLogger(ApplyRevokeController.class);
	
	@Reference
	private ApplyRevokeService applyRevokeService;
    
	/**
     * 借款撤销深圳通知接口
     */
	@ApiOperation(value = "借款撤销深圳通知接口",response = RestResponse.class)
    @RequestMapping(value = "openapi/applyRevoke", method = RequestMethod.POST)
    @ResponseBody
    public Object applyRevoke(@RequestBody @Valid ApplyRevokeDTO applyRevokeDTO, BindingResult result ){
        ResponseResult restResponse = new ResponseResult();
        if (result.hasErrors()) {
            String errorStr = handler.getErrorCount(result);
            restResponse.setCode(SysConstants.INTERFACE_FAIL);
            restResponse.setMessage(errorStr);
        } else {
            restResponse = applyRevokeService.receiveApplyRevokeNotice(applyRevokeDTO);
        }
        return new ResponseEntity<>(restResponse, HttpStatus.OK);
    }

}
