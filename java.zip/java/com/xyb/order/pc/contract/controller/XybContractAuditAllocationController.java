package com.xyb.order.pc.contract.controller;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;
import com.xyb.order.pc.contract.service.XybContractAuditAllocationService;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.contract.controller
 * @description : 合同审核重新分配controller层
 * @createDate : 2018/5/3 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("/order/contract/audit/allocation")
public class XybContractAuditAllocationController {

	@Reference
	private XybContractAuditAllocationService xybContractAuditAllocationService;
	/**
     * 合同审核重新分配列表
     */
	@AutoValid
	@ApiOperation(value = "合同审核重新分配列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryContracts(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid XybContractAuditQueryDTO xybContractAuditQueryDTO, BindingResult result) {
        RestResponse restResponse = xybContractAuditAllocationService.listContractAudit(pageNumber,pageSize,xybContractAuditQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同审核重新分配
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "合同审核重新分配",response = RestResponse.class)
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public Object updateContract(@RequestBody @Valid XybContractAllocationDTO xybContractAuditDetailDTO, BindingResult result) {
        RestResponse restResponse = xybContractAuditAllocationService.allocationContract(xybContractAuditDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
}
