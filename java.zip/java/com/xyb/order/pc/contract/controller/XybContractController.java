package com.xyb.order.pc.contract.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.auth.oos.AuthService;
import com.xyb.order.common.util.GetIpAndMacUtil;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;
import com.xyb.order.pc.contract.service.XybContractService;
import com.xyb.order.validator.ValidatorResultHandler;

/**
 * @author : houlvshuang
 * @projectName : order
 * @package : com.xyb.order.pc.contract.controller
 * @description : 进件合同controller层
 * @createDate : 2018/3/28 16:15
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Controller
@RequestMapping("order/contract/")
public class XybContractController {
    private static final Logger logger = LoggerFactory.getLogger(XybContractController.class);

	@Reference
    private XybContractService xybcontractService;
    @Autowired
    private ValidatorResultHandler handler;
    @Reference
    private AuthService authService;

	/**
     * 合同录入
     */
	@AutoValid
	@ApiOperation(value = "合同录入列表",response = RestResponse.class)
    @RequestMapping(value = "query/{pageNumber}/{pageSize}", method = RequestMethod.POST)
    public Object queryContracts(@PathVariable Integer pageNumber, @PathVariable Integer pageSize,@RequestBody @Valid XybContractQueryDTO xybContractQueryDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.listContract(pageNumber,pageSize,xybContractQueryDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同详情页
	 */
	@AutoValid
	@ApiOperation(value = "合同录入详情信息",response = RestResponse.class)
    @RequestMapping(value = "update", method = RequestMethod.POST)
    public Object updateContract(@RequestBody @Valid XybContractDetailDTO xybContractDetailDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.updateContract(xybContractDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同录入列表点操作存管相关校验
	 */
	@AutoValid
	@ApiOperation(value = "合同录入列表点操作存管相关校验",response = RestResponse.class)
    @RequestMapping(value = "updateCheck", method = RequestMethod.POST)
    public Object updateCheck(@RequestBody @Valid XybContractDetailDTO xybContractDetailDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.updateCheck(xybContractDetailDTO);
        return new ResponseEntity<RestResponse>(restResponse, HttpStatus.OK);
    }
	/**
	 * 合同暂存
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "合同暂存",response = RestResponse.class)
    @RequestMapping(value = "save", method = RequestMethod.POST)
    public Object saveContract(@RequestBody @Valid XybContractDetailSaveDTO xybContractDetailSaveDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.saveContract(xybContractDetailSaveDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同提交
	 */
	@RepeatTokenValid
	@ApiOperation(value = "合同提交",response = RestResponse.class)
    @RequestMapping(value = "sumbit", method = RequestMethod.POST)
    public Object submitContract(@RequestBody @Valid XybContractDetailSubmitDTO xybContractDetailSubmitDTO, BindingResult result,HttpServletRequest request) {
		RestResponse restResponse = null;
		if (result.hasErrors()) {
	        String errorStr = handler.getErrorCount(result);
	        restResponse = new RestResponse(MsgErrCode.FAIL);
	        restResponse.setDescription(errorStr);
	    }else{
	    	String macAddr = null;
	    	String ipAddr = null;
	    	try {
	    		macAddr = GetIpAndMacUtil.getMacAddress();
			    ipAddr = GetIpAndMacUtil.getIpAddress(request);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("推标获取本机mac或客户端ip地址失败", e);
			}
	        restResponse = xybcontractService.submitContract(xybContractDetailSubmitDTO,macAddr,ipAddr);
	    }
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 合同作废
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "合同作废",response = RestResponse.class)
    @RequestMapping(value = "abolish", method = RequestMethod.POST)
    public Object abolishContract(@RequestBody @Valid XybContractAbolishDTO xybContractAbolishDTO , BindingResult result) {
        RestResponse restResponse = xybcontractService.abolishContract(xybContractAbolishDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 获取当前用户待绑卡渠道列表
	 */
	@AutoValid
	@ApiOperation(value = "获取当前用户待绑卡渠道列表",response = RestResponse.class)
    @RequestMapping(value = "getUserNotBindChannel", method = RequestMethod.POST)
    public Object getUserNotBindChannel(@RequestBody @Valid ThirdPayBindDTO thirdPayBindDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.getUserNotBindChannel(thirdPayBindDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 协议支付-预绑卡
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "协议支付-预绑卡",response = RestResponse.class)
    @RequestMapping(value = "preBindCardEntrance", method = RequestMethod.POST)
    public Object preBindCardEntrance(@RequestBody @Valid ThirdPayBindPreDTO thirdPayBindPreDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.preBindCardEntrance(thirdPayBindPreDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 协议支付--预绑卡--重发短信
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "协议支付-预绑卡--重发短信",response = RestResponse.class)
    @RequestMapping(value = "resendMessage", method = RequestMethod.POST)
    public Object resendMessage(@RequestBody @Valid ThirdPayBindPreResendDTO thirdPayBindPreResendDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.resendMessage(thirdPayBindPreResendDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 协协议支付--确认绑卡
	 */
	@RepeatTokenValid
	@AutoValid
	@ApiOperation(value = "协议支付--确认绑卡",response = RestResponse.class)
    @RequestMapping(value = "confirmBianCardEntrance", method = RequestMethod.POST)
    public Object confirmBianCardEntrance(@RequestBody @Valid ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO, BindingResult result) {
        RestResponse restResponse = xybcontractService.confirmBianCardEntrance(thirdPayBindConfirmBianCardEntranceDTO);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	
	/**
	 * 申请已办-合同信息
	 */
	@AutoValid
	@ApiOperation(value = "申请已办-合同信息",response = RestResponse.class)
    @RequestMapping(value = "applyAlreadyContractInfo/{applyId}", method = RequestMethod.GET)
    public Object applyAlreadyContractInfo(@PathVariable Long applyId) {
        RestResponse restResponse = xybcontractService.applyAlreadyContractInfo(applyId);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
    }
	/**
	 * 查询还款计划
	 */
	@ApiOperation(value = "查询还款计划",response = RestResponse.class)
    @RequestMapping(value = "getRepaymentPlans/{applyId}", method = RequestMethod.GET)
	public Object getRepaymentPlans(@PathVariable Long applyId){
        RestResponse restResponse = xybcontractService.getRepaymentPlans(applyId);
        return new ResponseEntity<RestResponse>(restResponse, restResponse.getHttpcode());
	}
}
