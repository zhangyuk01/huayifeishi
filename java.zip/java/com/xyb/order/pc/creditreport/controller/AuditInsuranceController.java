package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditInsuranceAllDTO;
import com.xyb.order.pc.creditreport.model.AuditInsuranceDO;
import com.xyb.order.pc.creditreport.service.AuditInsuranceService;

/**
 * @ClassName AuditInsuranceController
 * @author ZhangYu
 * @date 2018年5月4号
 */

@Controller
@RequestMapping("/order/audit/insurance")
public class AuditInsuranceController {

	private static final Logger log = LoggerFactory.getLogger(AuditInsuranceController.class);

	@Reference
	private AuditInsuranceService auditInsuranceService;
	
	@ApiOperation(value = "保单证明页签",response = AuditInsuranceDO.class,notes = "保单证明页签查询")
	@RequestMapping(value = "auditInsuranceInfoList/{applyId}",method = RequestMethod.GET)
	public Object auditInsuranceInfoList(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditInsuranceService.queryAuditInsuranceListByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("保单证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "保单证明页签暂存",response = RestResponse.class,notes = "保单证明页签暂存")
	@RequestMapping(value = "auditInsuranceTempSave",method = RequestMethod.POST)
	public Object auditInsuranceTempSave(@RequestBody AuditInsuranceAllDTO auditInsuranceAllDTO){
		RestResponse response;
		try {
			response = this.auditInsuranceService.auditInsuranceTempSave(auditInsuranceAllDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("保单证明页签暂存异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "保单证明页签删除",response = RestResponse.class,notes = "保单证明页签删除")
	@RequestMapping(value = "auditInsuranceDel/{id}",method = RequestMethod.GET)
	public Object auditInsuranceDel(@PathVariable Long id){
		RestResponse response;
		try {
			response = this.auditInsuranceService.auditInsuranceDelById(id);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("保单证明页签删除异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	} 

}
