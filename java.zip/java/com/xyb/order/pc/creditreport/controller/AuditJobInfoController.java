package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditJobDO;
import com.xyb.order.pc.creditreport.model.AuditJobDTO;
import com.xyb.order.pc.creditreport.service.AuditJobInfoService;

/**
 * @ClassName AuditJobInfoController
 * @author ZhangYu
 * @date 2018年5月7号
 */
@Controller
@RequestMapping("/order/audit/job")
public class AuditJobInfoController {

	private static final Logger log = LoggerFactory.getLogger(AuditJobInfoController.class);
	
	@Reference
	private AuditJobInfoService auditJobInfoService;
	
	@ApiOperation(value = "工作证明页签",response = AuditJobDO.class,notes = "工作证明页签查询")
	@RequestMapping(value = "auditJobInfo/{applyId}",method = RequestMethod.GET)
	public Object auditJobInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJobInfoService.queryAuditJobInfo(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("工作证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "工作证明页签暂存",response =RestResponse.class,notes = "工作证明页签暂存")
	@RequestMapping(value = "updateAuditJobInfo",method = RequestMethod.POST)
	public Object updateAuditJobInfo(@RequestBody AuditJobDTO auditJobDTO){
		RestResponse response;
		try {
			response = this.auditJobInfoService.updateOrAddAuditJobInfo(auditJobDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("工作证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

}
