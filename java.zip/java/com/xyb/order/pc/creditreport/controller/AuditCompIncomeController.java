package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditAllCompIncomeDTO;
import com.xyb.order.pc.creditreport.model.AuditCompIncomeDO;
import com.xyb.order.pc.creditreport.service.AuditCompIncomeService;

/**
 * @ClassName AuditCompIncomeController
 * @author ZhangYu
 * @date 2018年4月23号
 */
@Controller
@RequestMapping("/order/audit/compincome")
public class AuditCompIncomeController {
	
	private static final Logger log = LoggerFactory.getLogger(AuditCompIncomeController.class);
	@Reference
	private AuditCompIncomeService auditCompIncomeService;
	
	@ApiOperation(value = "企业收入证明页签",response = AuditCompIncomeDO.class,notes = "企业收入证明页签查询")
	@RequestMapping(value = "auditCompIncomeListInfo/{applyId}",method = RequestMethod.GET)
	public Object auditCompIncomeListInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditCompIncomeService.queryInfoByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("企业收入证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "企业收入证明页签暂存",response = RestResponse.class)
	@RequestMapping(value = "updateAuditCompIncomeInfo",method = RequestMethod.POST)
	public Object updateAuditCompIncomeInfo(@RequestBody AuditAllCompIncomeDTO auditAllCompIncomeDTO){
		RestResponse response;
		try {
			response = this.auditCompIncomeService.updateOrAddInfoByApplyId(auditAllCompIncomeDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("企业收入证明页签暂存异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	
	@ApiOperation(value = "企业收入证明删除银行流水",response = RestResponse.class)
	@RequestMapping(value = "deleteAuditCompIncomeInfo/{id}",method = RequestMethod.GET)
	public Object deleteAuditPersonIncomeInfo(@PathVariable Long id){
		RestResponse response;
		try {
			response = this.auditCompIncomeService.updateAlreadyDelFlagById(id);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("企业收入证明删除银行流水异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
}
