package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditPhoneDO;
import com.xyb.order.pc.creditreport.model.AuditPhoneDTO;
import com.xyb.order.pc.creditreport.service.AuditPhoneDetailService;

/**
 * @ClassName AuditPhoneDetailController
 * @author ZhangYu
 * @date 2018年4月28号
 */

@Controller
@RequestMapping("/order/audit/phone")
public class AuditPhoneDetailController {
	private static final Logger log = LoggerFactory.getLogger(AuditPhoneDetailController.class);

	@Reference
	private AuditPhoneDetailService auditPhoneDetailService;
	
	@ApiOperation(value = "通话详单页签",response = AuditPhoneDO.class,notes = "通话详单页签查询")
	@RequestMapping(value = "auditPhoneInfoList/{applyId}",method = RequestMethod.GET)
	public Object auditPhoneInfoList(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditPhoneDetailService.queryPhoneDetailInfoByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("通话详单页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "通话详单暂存",response = RestResponse.class,notes = "通话详单暂存")
	@RequestMapping(value = "auditPhoneInfoSave",method = RequestMethod.POST)
	public Object auditPhoneInfoSave(@RequestBody AuditPhoneDTO auditPhoneDTO){
		RestResponse response;
		try {
			response = this.auditPhoneDetailService.auditPhoneInfoSave(auditPhoneDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("通话详单暂存异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
}
