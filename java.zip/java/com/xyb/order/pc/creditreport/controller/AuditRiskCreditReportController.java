package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDO;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDTO;
import com.xyb.order.pc.creditreport.service.AuditRiskCreditReportService;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @ClassName AuditJuxinliCreditReport
 * @author ZhangYu
 * @date 2018年5月16号
 */
@Controller
@RequestMapping("/order/audit/creditreport")
public class AuditRiskCreditReportController {

	private static final Logger log = LoggerFactory.getLogger(AuditRiskCreditReportController.class);

	@Reference
	private AuditRiskCreditReportService auditJuxinliCreditReportService;
	
	@ApiOperation(value = "运营商报告",response = RestResponse.class,notes = "运营商报告")
	@RequestMapping(value = "juxinliYuCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object juxinliYuCreditReportInfo(@PathVariable Long applyId){
        RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getYYSReport(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("运营商报告异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "简版人行征信报告",response = RestResponse.class,notes = "简版人行征信报告")
	@RequestMapping(value = "juxinliRehangCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object juxinliRehangCreditReportInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getSuanhuaCreditReportQuery(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("简版人行征信报告异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "获取简版人行征信报告不用验证授权可直接查询",response = RestResponse.class,notes = "简版人行征信报告")
	@RequestMapping(value = "openapi/juxinliRehangCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object juxinliRehangCreditReportInfoNoAuth(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getSuanhuaCreditReportQuery(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("简版人行征信报告异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "社保",response = RestResponse.class,notes = "社保")
	@RequestMapping(value = "jpoCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object jpoCreditReportInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getShebaoReport(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("社保异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "公积金",response = RestResponse.class,notes = "公积金")
	@RequestMapping(value = "cpfCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object cpfCreditReportInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getGjjReport(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("公积金异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "保单",response = RestResponse.class,notes = "保单")
	@RequestMapping(value = "bdCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object bdCreditReportInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getBDReport(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("保单异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
	   return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@ApiOperation(value = "获取三方通话记录",response = RestResponse.class,notes = "获取三方通话记录")
	@RequestMapping(value = "phoneCreditReportInfo/{applyId}",method = RequestMethod.GET)
	public Object phoneCreditReportInfo(@PathVariable Long applyId,@RequestParam("phone") String phone){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getPhoneCreditReportInfo(applyId, phone);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取三方通话记录异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "手填运营商报告次数统计暂存",response = RestResponse.class,notes = "手填运营商报告次数统计查询暂存")
	@RequestMapping(value = "rhCreditReportCountNumSave",method = RequestMethod.POST)
	public Object rhCreditReportCountNumSave(@RequestBody ApplyPersonTationQueryDTO applyPersonTationQueryDTO){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.rhCreditReportCountNumTempSave(applyPersonTationQueryDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取三方通话记录异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	
	@ApiOperation(value = "获取手填运营商报告次数统计",response = ApplyPersonTationQueryDO.class,notes = "获取手填运营商报告次数统计")
	@RequestMapping(value = "getRhCreditReportCountNum/{applyId}",method = RequestMethod.GET)
	public Object getRhCreditReportCountNum(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditJuxinliCreditReportService.getRhCreditReportCountNum(applyId); 
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取三方通话记录异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
}
