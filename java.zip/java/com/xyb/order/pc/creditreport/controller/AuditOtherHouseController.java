package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDO;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDTO;
import com.xyb.order.pc.creditreport.service.AuditOtherHouseService;

/**
 * @ClassName AuditOtherHouseController
 * @author ZhangYu
 * @date 2018年4月25号
 */

@Controller
@RequestMapping("/order/audit/otherhouse")
public class AuditOtherHouseController {

	private static final Logger log = LoggerFactory.getLogger(AuditOtherHouseController.class);

	@Reference
	private AuditOtherHouseService auditOtherHouseService;
	

	@ApiOperation(value = "房产证明页签",response = AuditOtherHouseDO.class,notes = "房产证明页签查询")
	@RequestMapping(value = "auditOtherHouseInfo/{applyId}",method = RequestMethod.GET)
	public Object auditOtherHouseInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditOtherHouseService.queryInfoByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("房产证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
	@RepeatTokenValid
	@ApiOperation(value = "房产证明页签暂存",response = RestResponse.class)
	@RequestMapping(value = "updateAuditOtherHouseInfo",method = RequestMethod.POST)
	public Object updateAuditOtherHouseInfo(@RequestBody AuditOtherHouseDTO auditOtherHouseDTO){
		RestResponse response;
		try {
			response = this.auditOtherHouseService.updateOrAddInfoById(auditOtherHouseDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("房产证明页签暂存异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

}
