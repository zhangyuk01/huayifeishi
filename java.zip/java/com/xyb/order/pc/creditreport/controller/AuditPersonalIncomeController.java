package com.xyb.order.pc.creditreport.controller;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditAllPersonalIncomeDTO;
import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDO;
import com.xyb.order.pc.creditreport.service.AuditPersonalIncomeService;

/**
 * @ClassName AuditPersonalIncomeController
 * @author ZhangYu
 * @date 2018年4月23号
 */

@Controller
@RequestMapping("/order/audit/personalincome")
public class AuditPersonalIncomeController {

	private static final Logger log = LoggerFactory.getLogger(AuditPersonalIncomeController.class);

	@Reference
	private AuditPersonalIncomeService auditPersonalIncomeService;

	@ApiOperation(value = "个人收入证明页签",response = AuditPersonalIncomeDO.class,notes = "个人收入证明页签查询")
	@RequestMapping(value = "auditPersonIncomeListInfo/{applyId}",method = RequestMethod.GET)
	public Object auditPersonIncomeListInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditPersonalIncomeService.queryInfoByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("个人收入证明页签异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid
	@ApiOperation(value = "个人收入证明页签暂存",response = RestResponse.class)
	@RequestMapping(value = "updateAuditPersonIncomeInfo",method = RequestMethod.POST)
	public Object updateAuditPersonIncomeInfo(@RequestBody AuditAllPersonalIncomeDTO auditAllPersonalIncomeDTO){
		RestResponse response;
		try {
			response = this.auditPersonalIncomeService.updateOrAddInfoByApplyId(auditAllPersonalIncomeDTO);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("个人收入证明页签暂存异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@ApiOperation(value = "个人收入证明银行流水删除",response = RestResponse.class)
	@RequestMapping(value = "deleteAuditPersonIncomeInfo/{id}",method = RequestMethod.GET)
	public Object deleteAuditPersonIncomeInfo(@PathVariable Long id){
		RestResponse response;
		try {
			response = this.auditPersonalIncomeService.updateDelFlagById(id);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("个人收入证明银行流水删除异常:"+e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	

}
