package com.xyb.order.pc.creditreport.controller;

import javax.validation.Valid;

import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.creditreport.model.AuditVerifyDO;
import com.xyb.order.pc.creditreport.model.AuditVerifyDTO;
import com.xyb.order.pc.creditreport.service.AuditVerifyService;

/**
 * @ClassName AuditVerifyController
 * @author ZhangYu
 * @date 2018年5月7号
 */
@Controller
@RequestMapping("/order/audit/verify")
public class AuditVerifyController {

	private static final Logger log = LoggerFactory.getLogger(AuditVerifyController.class);

	@Reference
	private AuditVerifyService auditVerifyService;
	
	@ApiOperation(value = "申请核查页签",response = AuditVerifyDO.class,notes = "申请核查页面查询")
	@RequestMapping(value = "auditPhoneInfo/{applyId}",method = RequestMethod.GET)
	public Object auditVerifyInfo(@PathVariable Long applyId){
		RestResponse response;
		try {
			response = this.auditVerifyService.queryVerifyInfoByApplyId(applyId);
		} catch (Exception e) {
			e.printStackTrace();
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("申请核查页签异常:"+e);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}

	@RepeatTokenValid	
	@ApiOperation(value = "申请核查页签暂存",response = RestResponse.class,notes = "申请核查页签暂存")
	@AutoValid
	@RequestMapping(value = "auditVerifyInfoTempSave",method = RequestMethod.POST)
	public Object auditVerifyInfoTempSave(@RequestBody @Valid AuditVerifyDTO auditVerifyDTO,BindingResult result){
		RestResponse response;
		try {
			response = this.auditVerifyService.updateOrAddVerifyInfo(auditVerifyDTO);
		} catch (Exception e) {
			e.printStackTrace();
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("申请核查页签暂存异常:"+e);
		}
		return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	}
	
}
