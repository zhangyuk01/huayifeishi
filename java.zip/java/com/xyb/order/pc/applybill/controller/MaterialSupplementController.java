package com.xyb.order.pc.applybill.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.applybill.model.MaterialSupplementListDO;
import com.xyb.order.pc.applybill.model.MaterialSupplementListDTO;
import com.xyb.order.pc.applybill.model.MaterialSupplementVO;
import com.xyb.order.pc.applybill.service.ApplyBillInfoService;
import com.xyb.order.pc.applybill.service.MaterialSupplementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * 材料补充
 * @author         xieqingyang
 * @date           2018/4/25 11:45 AM
*/
@Controller
@RequestMapping("/order/materialsupplement")
public class MaterialSupplementController {

    private static final Logger log = LoggerFactory.getLogger(MaterialSupplementController.class);

    @Reference
    private MaterialSupplementService materialSupplementService;
    @Reference
    private ApplyBillInfoService applyBillInfoService;

    @ApiOperation(value = "查询材料补充列表",response = MaterialSupplementListDO.class)
    @RequestMapping(value = "listMaterialSupplementPage/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object listMaterialSupplementPage(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody MaterialSupplementListDTO materialSupplementListDTO){
        RestResponse response;
        try {
            response = this.materialSupplementService.listMaterialSupplementPage(pageNumber,pageSize, materialSupplementListDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询材料补充列表异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenFactory
    @ApiOperation(value = "查询材料补充详细信息",response = MaterialSupplementVO.class)
    @RequestMapping(value = "getMaterialSupplementInFo/{mainId}",method = RequestMethod.GET)
    public Object getMaterialSupplementInFo(@PathVariable Long mainId){
        RestResponse response;
        try {
            response = this.materialSupplementService.getMaterialSupplementInFo(mainId);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询材料补充详细信息异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenValid
    @ApiOperation(value = "材料补充提交",response = RestResponse.class)
    @RequestMapping(value = "onSubmint/{applyId}",method = RequestMethod.GET)
    public Object onSubmint(@PathVariable Long applyId, @RequestParam(value = "projectCode",required = false) Long projectCode){
        RestResponse response;
        try {
            response = this.applyBillInfoService.onSubmint(applyId,projectCode);
        }catch (Exception e){
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("材料补充异常:"+e);
        }
        return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
    }
}
