package com.xyb.order.pc.applybill.controller;

import javax.validation.Valid;

import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoVO;
import com.xyb.order.pc.applybill.model.ApplyBillinfoAllSaveCheckJobDTO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllTempSaveDTO;
import com.xyb.order.pc.applybill.service.ApplyBillInfoService;

/**
 * @ClassName ApplyBillInfoController
 * @author ZhangYu
 * @date 2018年3月26号
 */

@Controller
@RequestMapping("/order/applybill")
public class ApplyBillInfoController {

	private static final Logger log = LoggerFactory.getLogger(ApplyBillInfoController.class);			 

	@Reference
	private ApplyBillInfoService applyBillInfoService;
	
	 @ApiOperation(value = "查询申请单列表信息",response = ApplyBillInfoQueryDTO.class)
	 @RequestMapping(value = "queryApplyBillInfoList/{pageNumber}/{pageSize}",method = RequestMethod.POST)
	 public Object queryApplyBillInfoList(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody(required=false) ApplyBillInfoQueryDTO applyBillInfoQueryDTO){
		 RestResponse response; 
	 	 try{
	 		 response = this.applyBillInfoService.applyBillInfoQueryPage(pageNumber, pageSize, applyBillInfoQueryDTO); 
		 }catch(Exception e){
            e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询申请单列表信息报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }
	 
	 @ApiOperation(value = "申请表详情页面信息",response = ApplyBillInfoVO.class,notes = "申请列表点击操作查询申请单详细信息")
	 @RequestMapping(value = "updateDetailBillInfoData/{mainId}",method = RequestMethod.GET)
	 @RepeatTokenFactory
	 public Object updateDetailBillInfoData(@PathVariable Long mainId){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.updateDetailBillInfoData(mainId);
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("申请表详情页面信息报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 } 

	 @RepeatTokenValid
	 @ApiOperation(value = "申请单列表暂存",response = ApplyBillInfoAllTempSaveDTO.class)
	 @RequestMapping(value = "tempSaveBillInfoList",method = RequestMethod.POST)
	 public Object tempSaveBillInfoData(@RequestBody ApplyBillInfoAllTempSaveDTO applyBillInfoAllTempSaveDTO){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.addOrUpdateAll(applyBillInfoAllTempSaveDTO);
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("查询申请单列表信息报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }

	 @RepeatTokenValid
	 @ApiOperation(value = "申请单列表保存不校验工作信息",response = ApplyBillInfoAllSaveDTO.class)
	 @AutoValid
	 @RequestMapping(value = "saveBillInfoList",method = RequestMethod.POST)
	 public Object saveBillInfoData(@RequestBody @Valid ApplyBillInfoAllSaveDTO applyBillInfoAllSaveDTO,BindingResult result){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.addOrUpdateAll(applyBillInfoAllSaveDTO);
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("申请单列表保存不校验工作信息报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }

	 @RepeatTokenValid
	 @ApiOperation(value = "申请单列表保存校验工作信息",response = ApplyBillinfoAllSaveCheckJobDTO.class)
	 @AutoValid
	 @RequestMapping(value = "saveBillInfoCheckJobList",method = RequestMethod.POST)
	 public Object saveBillInfoDataCheckJob(@RequestBody @Valid ApplyBillinfoAllSaveCheckJobDTO applyBillinfoAllSaveCheckJobDTO,BindingResult result){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.addOrUpdateAll(applyBillinfoAllSaveCheckJobDTO);
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("申请单列表保存校验工作信息报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	 }
	 
	 @ApiOperation(value = "客户放弃原因",response = RestResponse.class)
	 @RequestMapping(value = "queryClientAbandonReason",method = RequestMethod.GET)
	 public Object queryClientAbandonReason(){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.queryClientAbandonReason();
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("客户放弃原因报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }
	 
	 @RepeatTokenValid
	 @ApiOperation(value = "确认客户放弃",response = RestResponse.class)
	 @AutoValid
	 @RequestMapping(value = "confirmClientAbandon",method = RequestMethod.POST)
	 public Object confirmClientAbandon(@RequestBody @Valid ApplyClientAbandonDTO applyClientAbandonDTO,BindingResult result){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.confirmClientAbandon(applyClientAbandonDTO);
		 } catch (Exception e) {
			 e.printStackTrace();
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			 log.error("确认客户放弃报错:"+e);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }

	 @RepeatTokenValid
	 @ApiOperation(value = "联系人删除",response = RestResponse.class)
	 @RequestMapping(value = "deleteLinkManInfo/{id}",method = {RequestMethod.GET,RequestMethod.POST})
	 public Object deleteLinkManInfo(@PathVariable Long id){
		 RestResponse response;
		 try {
			 response = this.applyBillInfoService.updateLinkManDelFlagById(id);
		 } catch (Exception e) {
			 e.printStackTrace();
			 log.error("个人收入证明银行流水删除异常:"+e);
			 response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		 }
		 return new ResponseEntity<RestResponse>(response, response.getHttpcode());
	 }

	@ApiOperation(value = "提交审核（大纲）",response = RestResponse.class)
	@AutoValid
	@RepeatTokenValid
	@RequestMapping(value = "onSubmintOutline/{applyId}/{mainId}",method = RequestMethod.GET)
	public Object onSubmintOutline(@PathVariable Long applyId, @PathVariable Long mainId, @RequestParam(value = "projectCode",required = false) Long projectCode){
		RestResponse response;
		try {
			response = this.applyBillInfoService.onSubmintOutline(applyId,mainId,projectCode);
		} catch (Exception e) {
			e.printStackTrace();
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			log.error("提交审核（大纲）异常:"+e);
		}
		return new ResponseEntity<RestResponse>(response, HttpStatus.OK);
	}
}
