package com.xyb.order.pc.applybill.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.AutoValid;
import com.beiming.kun.framework.annotation.RepeatTokenFactory;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.applybill.model.InsertReconsiderationDTO;
import com.xyb.order.pc.applybill.model.ReconsiderationInfoDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDTO;
import com.xyb.order.pc.applybill.service.ReconsiderationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 复议申请
 * @author         xieqingyang
 * @date           2018/4/18 11:47 AM
*/
@Controller
@RequestMapping("/order/reconsideration")
public class ReconsiderationController {

    private static final Logger log = LoggerFactory.getLogger(ReconsiderationController.class);

    @Reference
    private ReconsiderationService reconsiderationService;

    @ApiOperation(value = "查询复议申请列表",response = ReconsiderationListDO.class)
    @RequestMapping(value = "queryReconsiderationListPage/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object queryReconsiderationListPage(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody ReconsiderationListDTO reconsiderationListDTO){
        RestResponse response;
        try {
            response = this.reconsiderationService.queryReconsiderationListPage(pageNumber,pageSize, reconsiderationListDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询复议申请列表报错:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @RepeatTokenFactory("insert_reconsideration")
    @ApiOperation(value = "查询复议申请详细信息",response = ReconsiderationInfoDO.class)
    @RequestMapping(value = "queryReconsiderationInfo/{mainId}",method = RequestMethod.GET)
    public Object queryReconsiderationInfo(@PathVariable Long mainId){
        RestResponse response;
        try {
            response = this.reconsiderationService.queryReconsiderationInfo(mainId);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("查询复议申请详细信息报错:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }

    @ApiOperation(value = "提交复议操作",response = RestResponse.class)
    @AutoValid
    @RepeatTokenValid
    @RequestMapping(value = "insertReconsider",method = RequestMethod.POST)
    public Object insertReconsider(@RequestBody @Valid InsertReconsiderationDTO insertReconsiderationDTO, BindingResult result){
        RestResponse response;
        try {
            response = this.reconsiderationService.insertReconsider(insertReconsiderationDTO);
        } catch (Exception e) {
            e.printStackTrace();
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            log.error("提交复议操作报错:"+e);
        }
        return new ResponseEntity<RestResponse>(response, response.getHttpcode());
    }
}
