package com.xyb.order.pc.reportform.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.RequestUtils;
import com.xyb.order.pc.reportform.model.*;
import com.xyb.order.pc.reportform.service.ReportFormService;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.ExportFileUtil;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 报表管理
 * @author         xieqingyang
 * @date           2018/5/2 下午3:09
*/
@Controller
@RequestMapping("/order/reportForm")
public class ReportFormController {

    private static final Logger log = LoggerFactory.getLogger(ReportFormController.class);

    @Reference
    private ReportFormService formService;
    @Autowired
    private ExportExcelService exportExcelService;

    @ApiOperation(value = "区域综合查询",response = ComprehensiveQueryDO.class)
    @RequestMapping(value = "comprehensiveQuery/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object comprehensiveQuery(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody ComprehensiveQueryDTO comprehensiveQueryDTO){
        RestResponse response;
        try {
            response = formService.comprehensiveQuery(pageNumber,pageSize,comprehensiveQueryDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("区域综合查询异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "区域综合查询导出",response = RestResponse.class)
    @RequestMapping(value = "outComprehensiveExport", method = RequestMethod.GET)
    public Object outComprehensiveExport(HttpServletRequest request, HttpServletResponse response) {
    	ComprehensiveQueryExportDTO comprehensiveQueryExportDTO = (ComprehensiveQueryExportDTO) RequestUtils.getRequestBean(ComprehensiveQueryExportDTO.class, request);
    	RestResponse rspBody;
    	ResponseEntity responseEntity;
    	try {
    		String[] headers = {"进件机构","销售团队","销售人员","推荐人","进件日期","客服人员","申请编号","客户姓名","身份证号","合同编号","申请产品","申请金额","申请期数",
    				"一级授信产品", "一级授信金额","一级授信期数","确认金额","费率等级","终极授信金额", "服务费","月还金额","是否循环贷","流程节点"};
    		List<ComprehensiveQueryExportDO> list = formService.outComprehensiveQueryExport(comprehensiveQueryExportDTO);
    		File file = exportExcelService.exportExcel("区域综合查询.xlsx", headers, list);
    		rspBody = new RestResponse(MsgErrCode.SUCCESS);
    		rspBody.setData(file);
    		ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
    		responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
    	} catch (Exception e) {
    		e.printStackTrace();
    		rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    		responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
    	}
    	return responseEntity;
    }

    @ApiOperation(value = "综合查询",response = ComprehensiveQueryDO.class)
    @RequestMapping(value = "comprehensiveAllQuery/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object comprehensiveAllQuery(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody ComprehensiveAllQueryDTO comprehensiveAllQueryDTO){
        RestResponse response;
        try {
        	 response = formService.comprehensiveAllQuery(pageNumber, pageSize, comprehensiveAllQueryDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("综合查询异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "综合查询导出",response = RestResponse.class)
    @RequestMapping(value = "outComprehensiveAllExport", method = RequestMethod.GET)
    public Object outComprehensiveAllExport(HttpServletRequest request, HttpServletResponse response) {
    	ComprehensiveAllQueryExportDTO comprehensiveAllQueryExportDTO = (ComprehensiveAllQueryExportDTO) RequestUtils.getRequestBean(ComprehensiveAllQueryExportDTO.class, request);
    	RestResponse rspBody;
    	ResponseEntity responseEntity;
    	try {
    		String[] headers = {"申请编号","进件机构","进件时间","客户姓名","身份证号","申请产品","申请期数","销售团队","销售人员","客服经理","客服人员","推荐人",
    				"审批时间","一级授信产品", "一级授信金额", "一级授信期数","确认金额", "费率等级", "终极授信金额", "月还金额", "合同生效时间", "复议次数", "是否循环贷", "是否签约前核验","是否结清",
    				"专案码",  "主拒贷码","流程节点"};
    		List<ComprehensiveAllQueryExportDO> list = formService.outComprehensiveAllQueryExport(comprehensiveAllQueryExportDTO);
    		File file = exportExcelService.exportExcel("综合查询.xlsx", headers, list);
			rspBody = new RestResponse(MsgErrCode.SUCCESS);
			rspBody.setData(file);
			ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
			responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
    	} catch (Exception e) {
    		e.printStackTrace();
    		rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
    		responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
    	}
    	return responseEntity;
    }

    @ApiOperation(value = "全量进程表",response = FullScaleProcessTableDO.class)
    @RequestMapping(value = "fullScaleProcessTable/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object fullScaleProcessTable(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody FullScaleProcessTableDTO fullScaleProcessTableDTO){
        RestResponse response;
        try {
            response = formService.fullScaleProcessTable(pageNumber,pageSize,fullScaleProcessTableDTO);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("全量进程表异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

	@ApiOperation(value = "全量进程表导出",response = RestResponse.class)
    @RequestMapping(value = "outFullScaleProcessTableExport", method = RequestMethod.GET)
    public Object outFullScaleProcessTableExport(HttpServletRequest request, HttpServletResponse response) {
		FullScaleProcessTableExportDTO fullScaleProcessTableExportDTO = (FullScaleProcessTableExportDTO) RequestUtils.getRequestBean(FullScaleProcessTableExportDTO.class, request);
		RestResponse rspBody;
		ResponseEntity responseEntity;
		try {
			String[] headers = {"大区","小区","进件机构","营业部类型","申请编号", "客户姓名", "身份证号"
					, "合同编号", "申请产品", "申请金额", "申请期数", "一级授信产品", "一级授信金额", "一级授信期数","确认金额","终极授信金额", "服务费",  "月还金额",
					"是否循环贷","单位性质","职务","销售团队","销售人员","推荐人","进件时间","初审开始时间","终审开始时间","审核时间","合同生效时间","主拒贷码","专案码",
					"流程节点","是否结清","合同废除原因","合同废除日期","合同废除备注"};
			List<FullScaleProcessTableExportDO> list = formService.outFullScaleProcessTable(fullScaleProcessTableExportDTO);
			File file = exportExcelService.exportExcel("全量进程表.xlsx", headers, list);
			rspBody = new RestResponse(MsgErrCode.SUCCESS);
			rspBody.setData(file);
			ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
			responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
		}
		return responseEntity;
	}

	@ApiOperation(value = "客服人员统计列表",response = CustomerServiceStatisticsVO.class)
    @RequestMapping(value = "customerServiceStatistics/{pageNumber}/{pageSize}",method = RequestMethod.POST)
    public Object customerServiceStatistics(@PathVariable Integer pageNumber, @PathVariable Integer pageSize, @RequestBody CustomerServiceStatisticsDTO customerServiceStatisticsDTO){
        RestResponse response;
        try {
            response = formService.customerServiceStatistics(pageNumber,pageSize,customerServiceStatisticsDTO);
        }catch (Exception e){
            e.printStackTrace();
            log.error("客服人员统计列表异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

	@ApiOperation(value = "客服人员统计导出",response = RestResponse.class)
    @RequestMapping(value = "customerServiceStatisticsExport",method = RequestMethod.GET)
    public Object customerServiceStatisticsExport(HttpServletRequest request, HttpServletResponse response){
        CustomerServiceStatisticsDTO customerServiceStatisticsDTO = (CustomerServiceStatisticsDTO)RequestUtils.getRequestBean(CustomerServiceStatisticsDTO.class, request);
        RestResponse rspBody;
        ResponseEntity responseEntity;
        try {
            String[] headers = {"客服人员","已分配咨询数","已提交申请数","待签订合同数","未通过审核数", "初审待补充材料数", "复议待补充材料数", "待实地征信数", "待产调数", "待实地征信与产调数"};
            List<CustomerServiceStatisticsVO> list = formService.customerServiceStatisticsExport(customerServiceStatisticsDTO);
            File file = exportExcelService.exportExcel("客服人员统计表.xlsx", headers, list);
            rspBody = new RestResponse(MsgErrCode.SUCCESS);
            rspBody.setData(file);
            ExportFileUtil exportFileUtil = new ExportFileUtil((File) rspBody.getData(), request).invoke();
            responseEntity = new ResponseEntity<>(exportFileUtil.getFileByte(), exportFileUtil.getHeaders(), HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("客服人员统计导出异常:"+e);
            rspBody = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            responseEntity = new ResponseEntity<>(rspBody, rspBody.getHttpcode());
        }
        return responseEntity;
    }
}
