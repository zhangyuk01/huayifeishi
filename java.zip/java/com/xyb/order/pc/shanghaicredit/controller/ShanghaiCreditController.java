package com.xyb.order.pc.shanghaicredit.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.framework.annotation.RepeatTokenValid;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.wordnik.swagger.annotations.ApiOperation;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditInformationVO;
import com.xyb.order.pc.shanghaicredit.service.ShanghaiCreditService;
import com.xyb.service.FastFileStorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import javax.servlet.http.HttpServletRequest;

/**
 * 上海资信相关功能
 * @author         xieqingyang
 * @date           2018/9/18 下午3:34
*/
@Controller
@RequestMapping("order/shanghaiCredit")
public class ShanghaiCreditController {

    private static final Logger log = LoggerFactory.getLogger(ShanghaiCreditController.class);

    @Reference
    private ShanghaiCreditService shanghaiCreditService;
    @Autowired
    private FastFileStorageService fastFileStorageService;

    @RepeatTokenValid
    @ApiOperation(value = "自动生成excel上传到上海资信")
    @RequestMapping(value = "automaticUpload",method = RequestMethod.GET)
    public Object automaticUpload(){
        RestResponse response;
        try {
            response = shanghaiCreditService.automaticUpload();
        }catch (Exception e){
            e.printStackTrace();
            log.error("自动生成excel上传到上海资信异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "手动上传excel到上海资信")
    @RequestMapping(value = "manuallyUpload",method = {RequestMethod.POST,RequestMethod.GET})
    public Object manuallyUpload(HttpServletRequest request){
        RestResponse response;
        String filePath = null;
        String fileName;
        try {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
            MultipartFile file = multipartHttpServletRequest.getFile("file");
            fileName = file.getOriginalFilename();
            String fileNameDe = fileName.substring(fileName.lastIndexOf(".")+1);
            if ("xls".equalsIgnoreCase(fileNameDe) || "xlsx".equalsIgnoreCase(fileNameDe)){
                // -- 保存文件
                ResultFileInfo uploadFile = fastFileStorageService.uploadFile(file, null);
                if (uploadFile == null){
                    response = new RestResponse(MsgErrCode.FAIL);
                }else {
                    filePath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");
                    // -- 进行文件处理
                    response = shanghaiCreditService.manuallyUpload(filePath,fileName);
                }
            }else {
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription("文件格式不正确!");
            }
        }catch (Exception e){
            if (StringUtils.isNotNullAndEmpty(filePath)) {
                fastFileStorageService.deleteFile(filePath);
            }
            e.printStackTrace();
            log.error("手动上传excel到上海资信异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "查询上海资信上传信息",response = ShanghaiCreditInformationVO.class)
    @RequestMapping(value = "readyUpload",method = RequestMethod.GET)
    public Object shzxReadyUpload(){
        RestResponse response;
        try {
            response = shanghaiCreditService.readyUpload();
        }catch (Exception e){
            e.printStackTrace();
            log.error("查询上海资信上传信息异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }

    @ApiOperation(value = "查询文件上传状态")
    @RequestMapping(value = "queryFileState/{id}",method = RequestMethod.GET)
    public Object queryFileState(@PathVariable("id") Long id){
        RestResponse response;
        try {
            response = shanghaiCreditService.queryFileState(id);
        }catch (Exception e){
            e.printStackTrace();
            log.error("查询文件上传状态异常:"+e);
            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new ResponseEntity<RestResponse>(response,response.getHttpcode());
    }
}
