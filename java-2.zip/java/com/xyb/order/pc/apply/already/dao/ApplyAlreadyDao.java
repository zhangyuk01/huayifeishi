package com.xyb.order.pc.apply.already.dao;

import java.util.List;

import com.xyb.order.pc.apply.already.model.ApplyAlreadyListExportVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyListVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyQueryDTO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderAuditOneInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderAuditTwoInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderOneInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderTwoInfoVO;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.apply.already.dao
 * @description : 合同dao
 * @createDate : 2018/03/28 13:52
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyAlreadyDao {

    List<ApplyAlreadyListVO> listApplyAlreadyPage(ApplyAlreadyQueryDTO applyAlreadyQueryDTO);
    
    List<ApplyAlreadyListExportVO> listApplyAlreadyExport(ApplyAlreadyQueryDTO applyAlreadyQueryDTO);
    
    ApplyAlreadyReconsiderOneInfoVO  getApplyAlreadyReconsiderOneInfoVO(Long applyId);
    
    ApplyAlreadyReconsiderTwoInfoVO  getApplyAlreadyReconsiderTwoInfoVO(Long applyId);
    
    ApplyAlreadyReconsiderAuditOneInfoVO getApplyAlreadyReconsiderAuditOneInfoVO(Long applyId);
    
    ApplyAlreadyReconsiderAuditTwoInfoVO getApplyAlreadyReconsiderAuditTwoInfoVO(Long applyId);

}
