package com.xyb.order.pc.apply.already.service.impl;

import java.util.List;
import com.xyb.order.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.pc.apply.already.dao.ApplyAlreadyDao;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyListExportVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyListVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyQueryDTO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderAuditOneInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderAuditTwoInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderOneInfoVO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyReconsiderTwoInfoVO;
import com.xyb.order.pc.apply.already.service.ApplyAlreadyService;
import com.xyb.order.pc.outbound.service.impl.OutBoundAlreadyServiceImpl;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.SessionUtil;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.apply.already.service.impl
 * @description : 合同审核重新分配实现
 * @createDate : 2018/5/3 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.apply.already.service.ApplyAlreadyService")
public class ApplyAlreadyServiceImpl implements ApplyAlreadyService {
	private static final Logger logger = LoggerFactory.getLogger(OutBoundAlreadyServiceImpl.class);
	
	@Autowired
	private ApplyAlreadyDao applyAlreadyDao;
    @Autowired
    private ExportExcelService exportExcelService;
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse queryApplyAlreadys(Integer pageNumber, Integer pageSize,
			ApplyAlreadyQueryDTO applyAlreadyQueryDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 
			 applyAlreadyQueryDTO.getPage().setPageNumber(pageNumber);
			 applyAlreadyQueryDTO.getPage().setPageSize(pageSize);
			 /**type：A 赋值机构码和客服人员(默认查询当前机构下的当前客服人员)   B:赋值机构Id(默认查询当前团队组下)   C:如果查询机构orgId不为空,赋值机构Id（默认查询当前营业部下）  D:赋值机构Id(默认查询所有营业部下)*/
			 if("A".equals(applyAlreadyQueryDTO.getType())){
				 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
				 applyAlreadyQueryDTO.setLoginId(loginUser.getId());
			 }else if("B".equals(applyAlreadyQueryDTO.getType())){
				 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
			 }else if("C".equals(applyAlreadyQueryDTO.getType())){
				 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
			 }else if("D".equals(applyAlreadyQueryDTO.getType())){
				 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
			 }
		     /**处理状态集合 0:状态集 */
		     if(StringUtils.isNotNullAndEmpty(applyAlreadyQueryDTO.getState())){
			    applyAlreadyQueryDTO.setList(NodeStateConstant.getNodeStateList(Integer.parseInt(applyAlreadyQueryDTO.getState())));
		     }
		     
		     List<ApplyAlreadyListVO> list = applyAlreadyDao.listApplyAlreadyPage(applyAlreadyQueryDTO);
			 // -- 进行状态显示处理
			 String stateName;
			 for (ApplyAlreadyListVO vo:list) {
				 stateName = NodeStateConstant.getNodeStateNameOfApplyAlready(vo.getStateCode());
				 if (StringUtils.isNotNullAndEmpty(stateName)){
					 vo.setStateName(stateName);
				 }
			 }
		     applyAlreadyQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,applyAlreadyQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("申请已办查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<ApplyAlreadyListExportVO> applyAlreadyExport(
			ApplyAlreadyQueryDTO applyAlreadyQueryDTO) throws Exception{
        
		User loginUser = SessionUtil.getLoginUser(User.class);


		/**type：A 赋值机构码和客服人员(默认查询当前机构下的当前客服人员)   B:赋值机构Id(默认查询当前团队组下)   C:如果查询机构orgId不为空,赋值机构Id（默认查询当前营业部下）  D:赋值机构Id(默认查询所有营业部下)*/
		 if("A".equals(applyAlreadyQueryDTO.getType())){
			 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
			 applyAlreadyQueryDTO.setLoginId(loginUser.getId());
		 }else if("B".equals(applyAlreadyQueryDTO.getType())){
			 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
		 }else if("C".equals(applyAlreadyQueryDTO.getType())){
			 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
		 }else if("D".equals(applyAlreadyQueryDTO.getType())){
			 applyAlreadyQueryDTO.setDataId(loginUser.getDataOrgId());
		 }
	    /**处理状态集合 0:状态集 */
	    if(StringUtils.isNotNullAndEmpty(applyAlreadyQueryDTO.getState())){
		    applyAlreadyQueryDTO.setList(NodeStateConstant.getNodeStateList(Integer.parseInt(applyAlreadyQueryDTO.getState())));
	    }
	    //获取导出数据
	    List<ApplyAlreadyListExportVO> list = applyAlreadyDao.listApplyAlreadyExport(applyAlreadyQueryDTO);
		// -- 进行状态显示处理
		String stateName;
		for (ApplyAlreadyListExportVO vo:list) {
			stateName = NodeStateConstant.getNodeStateNameOfApplyAlready(vo.getStateCode());
			if (StringUtils.isNotNullAndEmpty(stateName)){
				vo.setStateName(stateName);
			}
			/**导出不显示此字段*/
			vo.setStateCode(null);
			if (com.beiming.kun.utils.StringUtils.isNotNullAndEmpty(vo.getRefuseReason())){
				vo.setRefuseReason(vo.getRefuseReason().replace("<","小于").replace("=","等于").replace(">","大于").replace(" ",""));
			}
		}
        return list;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse applyAlreadyRreconsiderInfo(Long applyId) {
		RestResponse response = null;
		try {
			ApplyAlreadyReconsiderInfoVO applyAlreadyReconsiderInfoVO = new ApplyAlreadyReconsiderInfoVO();
			/**查询第一次复议申请信息*/
			ApplyAlreadyReconsiderOneInfoVO applyAlreadyReconsiderOneInfoVO = applyAlreadyDao.getApplyAlreadyReconsiderOneInfoVO(applyId);
			/**查询第二次复议申请信息*/
			ApplyAlreadyReconsiderTwoInfoVO applyAlreadyReconsiderTwoInfoVO = applyAlreadyDao.getApplyAlreadyReconsiderTwoInfoVO(applyId);
			/**查询第一次复议审核信息*/
			ApplyAlreadyReconsiderAuditOneInfoVO applyAlreadyReconsiderAuditOneInfoVO = applyAlreadyDao.getApplyAlreadyReconsiderAuditOneInfoVO(applyId);
			/**查询第二次复议审核信息*/
			ApplyAlreadyReconsiderAuditTwoInfoVO applyAlreadyReconsiderAuditTwoInfoVO = applyAlreadyDao.getApplyAlreadyReconsiderAuditTwoInfoVO(applyId);
			
			applyAlreadyReconsiderInfoVO.setApplyAlreadyReconsiderOneInfoVO(applyAlreadyReconsiderOneInfoVO);
			applyAlreadyReconsiderInfoVO.setApplyAlreadyReconsiderTwoInfoVO(applyAlreadyReconsiderTwoInfoVO);
			applyAlreadyReconsiderInfoVO.setApplyAlreadyReconsiderAuditOneInfoVO(applyAlreadyReconsiderAuditOneInfoVO);
			applyAlreadyReconsiderInfoVO.setApplyAlreadyReconsiderAuditTwoInfoVO(applyAlreadyReconsiderAuditTwoInfoVO);
		    response = new RestResponse(MsgErrCode.SUCCESS,applyAlreadyReconsiderInfoVO);
		} catch (Exception e) {
			 logger.error("申请已办复议信息查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

}
