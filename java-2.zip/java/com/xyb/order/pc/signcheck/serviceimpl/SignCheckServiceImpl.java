package com.xyb.order.pc.signcheck.serviceimpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.material.service.FileDataInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.FileNameConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.outbound.service.impl.OutBoundServiceImpl;
import com.xyb.order.pc.signcheck.dao.SignCheckDao;
import com.xyb.order.pc.signcheck.model.SignCheckDetailAuditListVO;
import com.xyb.order.pc.signcheck.model.SignCheckDetailDTO;
import com.xyb.order.pc.signcheck.model.SignCheckDetailVO;
import com.xyb.order.pc.signcheck.model.SignCheckListVO;
import com.xyb.order.pc.signcheck.model.SignCheckQueryDTO;
import com.xyb.order.pc.signcheck.service.SignCheckService;
import com.xyb.util.SessionUtil;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 签约前核验实现
 * @createDate : 2018/05/17 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.signcheck.service.SignCheckService")
public class SignCheckServiceImpl implements SignCheckService {
	private static final Logger logger = LoggerFactory.getLogger(OutBoundServiceImpl.class);
	@Autowired
	private SignCheckDao signCheckDao;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private FileDataInfoService fileService;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse querySignChecks(Integer pageNumber, Integer pageSize, SignCheckQueryDTO signCheckQueryDTO) {
		 RestResponse response;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 signCheckQueryDTO.getPage().setPageNumber(pageNumber);
			 signCheckQueryDTO.getPage().setPageSize(pageSize);
			 signCheckQueryDTO.setOrgId(loginUser.getDataOrgId());
			 signCheckQueryDTO.setState(NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION);
			 signCheckQueryDTO.setUserId(loginUser.getId());
		     List<SignCheckListVO> list = signCheckDao.listSignCheckPage(signCheckQueryDTO);
		     signCheckQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,signCheckQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("签约前列表查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"签约前列表查询失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateSignCheck(SignCheckDetailDTO signCheckDetailDTO) {
		RestResponse response = null;
		try {
			 /**查询签约前核验详情*/
			 SignCheckDetailVO signCheckDetailVO = signCheckDao.getSignCheckDetailVO(signCheckDetailDTO);
			 /**查询签约前核验审核历史数据*/
			 List<SignCheckDetailAuditListVO> list = signCheckDao.listSignCheckDetailAuditListVO(signCheckDetailDTO);
			 if(signCheckDetailVO != null){
				 signCheckDetailVO.setList(list);
			 }
			 
			 StringBuffer signCheckTypeName = new StringBuffer();
			 /**处理签约前核验类型描述*/
			 if(signCheckDetailVO.getSignCheckType() != null ){
				 if(signCheckDetailVO.getSignCheckType().contains(",")){
					 String[] signCheckTypes = signCheckDetailVO.getSignCheckType().split(",");
					 for (int i = 0; i < signCheckTypes.length; i++) {
						if(Long.valueOf(signCheckTypes[i]).equals(SysDictEnum.SIGN_CHECK_TYPE_DKJQ.getCode())){
							signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_DKJQ.getName()).append(",");
						}
						if(Long.valueOf(signCheckTypes[i]).equals(SysDictEnum.SIGN_CHECK_TYPE_YXHT.getCode())){
							signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_YXHT.getName()).append(",");
						}
						if(Long.valueOf(signCheckTypes[i]).equals(SysDictEnum.SIGN_CHECK_TYPE_GZZM.getCode())){
							signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_GZZM.getName()).append(",");
						}
					 }
				 }else{
					 Long signCheckType = Long.valueOf(signCheckDetailVO.getSignCheckType());
					 if(signCheckType.equals(SysDictEnum.SIGN_CHECK_TYPE_DKJQ.getCode())){
						 signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_DKJQ.getName());
					 }
					 if(signCheckType.equals(SysDictEnum.SIGN_CHECK_TYPE_YXHT.getCode())){
						 signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_YXHT.getName());
					 }
					 if(signCheckType.equals(SysDictEnum.SIGN_CHECK_TYPE_GZZM.getCode())){
						 signCheckTypeName.append(SysDictEnum.SIGN_CHECK_TYPE_GZZM.getName());
					 }
				 }
			 }
			 signCheckDetailVO.setSignCheckTypeName(signCheckTypeName != null ? signCheckTypeName.toString() : null);
		     response = new RestResponse(MsgErrCode.SUCCESS,signCheckDetailVO);
		} catch (Exception e) {
			 logger.error("签约前核验详情查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"签约前核验详情查询失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitSignCheck(SignCheckDetailDTO signCheckDetailDTO) {
		RestResponse response = null;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();
			
			/**1.查询mainInfo*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", signCheckDetailDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			/**2.修改流程状态*/
			MainLogDTO mainLogDTO = new MainLogDTO();
			mainLogDTO.setBusinessState(NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT);
			mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			mainLogDTO.setModifyUser(userId);
			currencyDao.addMainLog(mainLogDTO);
			
			/**3.对比是否需要修改,是：修改mainInfo表,添加表修改日志*/
			String oldData = JsonUtil.object2json(applyBillMainInfoDO);
			
			applyBillMainInfoDO.setState(NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT);
			applyBillMainInfoDO.setModifyTime(new Date());
			applyBillMainInfoDO.setModifyUser(userId);
			applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

			String newData = JsonUtil.object2json(applyBillMainInfoDO);
			boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			if(flag){
				currencyDao.updateMainInFo(applyBillMainInfoDO);
			}
			/**4.更新图片信息为不可删除*/
			fileService.updateFileState(applyBillMainInfoDO.getApplyId(), userId, FileNameConstant.SIGNCHECK_IMAGES_TYPE);
			
			response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			 logger.error("签约前核验提交失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"签约前核验提交失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

}
