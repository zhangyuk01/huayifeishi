package com.xyb.order.pc.signcheck.dao;

import java.util.List;

import com.xyb.order.pc.signcheck.model.SignCheckDetailAuditListVO;
import com.xyb.order.pc.signcheck.model.SignCheckDetailDTO;
import com.xyb.order.pc.signcheck.model.SignCheckDetailVO;
import com.xyb.order.pc.signcheck.model.SignCheckListVO;
import com.xyb.order.pc.signcheck.model.SignCheckQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 签约前核验 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface SignCheckDao {
	
	List<SignCheckListVO> listSignCheckPage(SignCheckQueryDTO signCheckQueryDTO);
	
	SignCheckDetailVO getSignCheckDetailVO(SignCheckDetailDTO signCheckDetailDTO);
	
	List<SignCheckDetailAuditListVO> listSignCheckDetailAuditListVO(SignCheckDetailDTO signCheckDetailDTO);
}
