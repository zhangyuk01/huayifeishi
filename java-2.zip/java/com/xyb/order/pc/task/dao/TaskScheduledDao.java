package com.xyb.order.pc.task.dao;

import com.xyb.order.pc.reportform.model.ReportBusinessStatisticsByCusServiceDO;

import java.util.List;
import java.util.Map;


/**
 * 定时任务使用查询
 * @author         xieqingyang
 * @date           2018/8/30 下午5:55
*/
public interface TaskScheduledDao {


    /**
     * 查询需要补充材料冻结的申请单
     * @author      xieqingyang
     * @date        2018/8/30 下午5:54
     * @version     1.0
     * @param timeLag 天数
     * @return 主表ID
     */
    List<Long> queryMaterialSupplement(Long timeLag);

    /**
     * 根据产品、区域、营业部、客服人员四个维度查询所有可组合的有效数据
     * @author      xieqingyang
     * @date        2018/8/30 下午5:53
     * @version     1.0
     * @param paraMap 查询参数
     * @return 返回客服人员ID
     */
    List<ReportBusinessStatisticsByCusServiceDO> queryValidMailInfo(Map<String,Object> paraMap);

    /**
     * 查询客服业务数据数据
     * @author      xieqingyang
     * @date        2018/8/31 下午12:23
     * @version     1.0
     * @param paraMap 查询条件
     * @return 完整数据
     */
    ReportBusinessStatisticsByCusServiceDO queryReportBusinessStatisticsByCusServiceDO(Map<String,Object> paraMap);

    /**
     * 批量添加客服业务数据数据
     * @author      xieqingyang
     * @date        2018/8/31 下午2:18
     * @version     1.0
     * @param list 待插入数据
     */
    void addReportBusinessStatisticsByCusService(List<ReportBusinessStatisticsByCusServiceDO> list);
}
