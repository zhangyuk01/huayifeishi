package com.xyb.order.pc.task.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.dao.SystemDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.model.ParameterDO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.msg.ParameterConfigEnum;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.reportform.model.ReportBusinessStatisticsByCusServiceDO;
import com.xyb.order.pc.task.dao.TaskScheduledDao;
import com.xyb.order.pc.task.model.ParameterConfigDO;
import com.xyb.order.pc.task.service.OrderTimeTaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.*;

/**
 * 定时任务实现类
 * @author         xieqingyang
 * @date           2018/11/8 1:39 PM
*/
@Service(interfaceName = "com.xyb.order.pc.task.service.OrderTimeTaskService")
public class OrderTimeTaskServiceImpl implements OrderTimeTaskService {

    private static final Logger logger = LoggerFactory.getLogger(OrderTimeTaskServiceImpl.class);

    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private TaskScheduledDao taskScheduledDao;
    @Autowired
    private XybContractDao dao;
    @Autowired
    private TableModifyLogService tableModifyService;
    @Autowired
    private SystemDao systemDao;
    @Autowired
    private ApplyBillInfoDao applyBillInfoDao;

    /**
     * 材料补充冻结
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void materialSupplementFrozen() {
        logger.info("材料补充冻结时任务开始");
        try {
            ParameterConfigDO parameterConfigDO = currencyDao.getParameter(ParameterConfigEnum.PARAMETER_CONFIG_NATERIAL_DATE.getParameterCode());
            if (parameterConfigDO != null && parameterConfigDO.getParameterValue() != null) {
                List<Long> mainIds = taskScheduledDao.queryMaterialSupplement(Long.valueOf(parameterConfigDO.getParameterValue()));
                if (mainIds != null && mainIds.size() > 0) {
                    Map<String, Object> paraMap = new HashMap<>(7);
                    paraMap.put("mainId", mainIds);
                    paraMap.put("state", NodeStateConstant.CONTRACT_FREEZE);
                    paraMap.put("modifyUser", CurrencyConstant.SYSTEM_USER);
                    paraMap.put("modifyUserName", "系统");
                    paraMap.put("businessStateName", "合同冻结");
                    paraMap.put("previous", NodeStateConstant.MATERIAL_SUPPLEMENT);
                    paraMap.put("businessState", NodeStateConstant.CONTRACT_FREEZE);
                    currencyDao.updateMainInfo(paraMap);
                    currencyDao.insertMainLogList(paraMap);
                }
            } else {
                logger.info("异常-----------------------未设置材料补充冻结时间");
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.error("材料补充冻结时任务异常:"+e);
        }finally {
            logger.info("材料补充冻结时任务结束");
        }
    }

    /**
     * 外访自动冻结
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void outBoundFreece() {
        logger.info("外访自动冻结定时任务开始");
        try {
            ParameterDO parameterDate = systemDao.getParameter(ParameterConfigEnum.PARAMETER_CONFIG_WFZDDJSJ.getParameterCode());
            Map<String, Object> map = new HashMap<>(2);
            map.put("state", NodeStateConstant.OUTSIDE_VISIT);
            map.put("dayNum", Integer.valueOf(parameterDate.getParameterValue()));
            /**查询出所有符合条件的数据,进行冻结*/
            List<Long> applyIds = dao.listApplyIds(map);
            for (int i = 0; i < applyIds.size(); i++) {
                /**更新流程状态为作废*/
                Map<String, Object> mainInfoMap = new HashMap<>(2);
                mainInfoMap.put("applyId", applyIds.get(i));
                ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainInfoMap);

                MainLogDTO mainLogDTO = new MainLogDTO();
                mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_FREEZE);
                mainLogDTO.setMainId(applyBillMainInfoDO.getId());
                mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
                currencyDao.addMainLog(mainLogDTO);

                String oldData = JsonUtil.object2json(applyBillMainInfoDO);

                applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_FREEZE);
                applyBillMainInfoDO.setPrevious(NodeStateConstant.OUTSIDE_VISIT);
                applyBillMainInfoDO.setModifyTime(new Date());
                applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
                applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

                String newData = JsonUtil.object2json(applyBillMainInfoDO);
                boolean flag = tableModifyService.insertApplyCommonModifyLog(CurrencyConstant.SYSTEM_USER, applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO, oldData, newData);
                if (flag) {
                    currencyDao.updateMainInFo(applyBillMainInfoDO);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("外访自动冻结失败", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }finally {
            logger.info("外访自动冻结定时任务结束");
        }
    }

    /**
     * 合同录入自动冻结
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void contractFreece() {
        logger.info("合同录入自动冻结定时任务开始");
        try {
            ParameterDO parameterDate = systemDao.getParameter(ParameterConfigEnum.PARAMETER_CONFIG_HTLRZDDJSJ.getParameterCode());
            Map<String, Object> map = new HashMap<>(2);
            map.put("state", NodeStateConstant.CONTRACT_ENTRY);
            map.put("dayNum", Integer.valueOf(parameterDate.getParameterValue()));
            /**查询出所有符合条件的数据,进行冻结*/
            List<Long> applyIds = dao.listApplyIds(map);
            for (int i = 0; i < applyIds.size(); i++) {
                /**更新流程状态为作废*/
                Map<String, Object> mainInfoMap = new HashMap<>(2);
                mainInfoMap.put("applyId", applyIds.get(i));
                ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainInfoMap);

                MainLogDTO mainLogDTO = new MainLogDTO();
                mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_FREEZE);
                mainLogDTO.setMainId(applyBillMainInfoDO.getId());
                mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
                currencyDao.addMainLog(mainLogDTO);

                String oldData = JsonUtil.object2json(applyBillMainInfoDO);

                applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_FREEZE);
                applyBillMainInfoDO.setPrevious(NodeStateConstant.CONTRACT_ENTRY);
                applyBillMainInfoDO.setModifyTime(new Date());
                applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
                applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

                String newData = JsonUtil.object2json(applyBillMainInfoDO);
                boolean flag = tableModifyService.insertApplyCommonModifyLog(CurrencyConstant.SYSTEM_USER, applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO, oldData, newData);
                if (flag) {
                    currencyDao.updateMainInFo(applyBillMainInfoDO);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("合同录入自动冻结失败", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }finally {
            logger.info("合同录入自动冻结定时任务结束");
        }
    }

    @Override
    public void reportBusinessStatisticsByCusService() {
        logger.info("客服业务统计报表数据定时生成开始");
        try {
            /**已分配咨询数节点 105-客服录入中-107-系统审核中-109-申请作废-111-材料补充-119-冻结-121-外访中-131-签约前核验-141-合同录入中-142-合同审核-143-募标中-144-合同生效-145-客户签约-149-合同作废-195-系统审核拒贷-196-风险提报拒贷-197-合同审核拒贷-201-初审待分件-202-初审已分件-203-终审待分件-204-终审已分件-210-初审中-220-审核中-230-终审中-240-签约前核验审核中-250-复议审核中-260-系统审核-297-系统审核拒贷-298-签约前核验拒贷-299-终审拒贷*/
            List<Integer> numberConsultationsAllocated = Arrays.asList(NodeStateConstant.CUSTOMER_SERVICE_ENTRY,NodeStateConstant.PENDING_SYSTEM_AUDIT,NodeStateConstant.APPLY_FOR_INVALIDATION,NodeStateConstant.MATERIAL_SUPPLEMENT,NodeStateConstant.CONTRACT_FREEZE,NodeStateConstant.OUTSIDE_VISIT,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION,NodeStateConstant.CONTRACT_ENTRY,NodeStateConstant.CONTRACT_REVIEW,NodeStateConstant.IN_THE_BID,NodeStateConstant.THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT,NodeStateConstant.CLIENT_CONTRACT,NodeStateConstant.CONTRACT_INVALIDATION,NodeStateConstant.SYSTEM_AUDITS_APPLY,NodeStateConstant.RIS_REPORTING_AND_REFUSING_TO_LEND,NodeStateConstant.CONTRACT_REVIEW_TO_LEND,NodeStateConstant.FIRST_TRIAL_TO_BE_DIVIDED,NodeStateConstant.FIRST_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FINAL_ADJUDICATION,NodeStateConstant.FINAL_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FIRST_TRIAL,NodeStateConstant.AUDIT,NodeStateConstant.IN_THE_FINAL_TRIAL,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT,NodeStateConstant.REVIEW_AND_REVIEW,NodeStateConstant.SYSTEM_AUDIT,NodeStateConstant.SYSTEM_AUDITS_AUDIT,NodeStateConstant.BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT,NodeStateConstant.FINAL_LEND);
            /**已提交申请数节点 109-申请作废-111-材料补充-119-冻结-121-外访中-131-签约前核验-141-合同录入中-142-合同审核-143-募标中-144-合同生效-145-客户签约-149-合同作废-195-系统审核拒贷-196-风险提报拒贷-197-合同审核拒贷-201-初审待分件-202-初审已分件-203-终审待分件-204-终审已分件-210-初审中-220-审核中-230-终审中-240-签约前核验审核中-250-复议审核中-260-系统审核-297-系统审核拒贷-298-签约前核验拒贷-299-终审拒贷*/
            List<Integer> numberApplicationsSubmitted = Arrays.asList(NodeStateConstant.APPLY_FOR_INVALIDATION,NodeStateConstant.MATERIAL_SUPPLEMENT,NodeStateConstant.CONTRACT_FREEZE,NodeStateConstant.OUTSIDE_VISIT,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION,NodeStateConstant.CONTRACT_ENTRY,NodeStateConstant.CONTRACT_REVIEW,NodeStateConstant.IN_THE_BID,NodeStateConstant.THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT,NodeStateConstant.CLIENT_CONTRACT,NodeStateConstant.CONTRACT_INVALIDATION,NodeStateConstant.SYSTEM_AUDITS_APPLY,NodeStateConstant.RIS_REPORTING_AND_REFUSING_TO_LEND,NodeStateConstant.CONTRACT_REVIEW_TO_LEND,NodeStateConstant.FIRST_TRIAL_TO_BE_DIVIDED,NodeStateConstant.FIRST_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FINAL_ADJUDICATION,NodeStateConstant.FINAL_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FIRST_TRIAL,NodeStateConstant.AUDIT,NodeStateConstant.IN_THE_FINAL_TRIAL,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT,NodeStateConstant.REVIEW_AND_REVIEW,NodeStateConstant.SYSTEM_AUDIT,NodeStateConstant.SYSTEM_AUDITS_AUDIT,NodeStateConstant.BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT,NodeStateConstant.FINAL_LEND);
            /**待签订合同节点 141-合同录入中-142-合同审核-143-募标中*/
            List<Integer> contractSigned = Arrays.asList(NodeStateConstant.CONTRACT_ENTRY,NodeStateConstant.CONTRACT_REVIEW,NodeStateConstant.IN_THE_BID);
            /**未通过审核数节点 298-签约前核验拒贷-299-终审拒贷-197-合同审核拒贷*/
            List<Integer> numberAuditsFailed = Arrays.asList(NodeStateConstant.BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT,NodeStateConstant.FINAL_LEND,NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
            /**待补充资料数节点 111-材料补充*/
            List<Integer> materialSupplement = Collections.singletonList(NodeStateConstant.MATERIAL_SUPPLEMENT);
            /**外访节点 121-外访中*/
            List<Integer> outsideVisit = Collections.singletonList(NodeStateConstant.OUTSIDE_VISIT);
            /**定义最后数据*/
            List<ReportBusinessStatisticsByCusServiceDO> list = new ArrayList<>();
            /**根据产品、区域、营业部、客服人员四个维度查询所有可组合的有效数据*/
            Map<String,Object> paraMap = new HashMap<>(20);
            paraMap.put("postCode",SysDictEnum.SERVICE_POST_CODE.getCode());
            paraMap.put("state",SysDictEnum.IS_VALID.getCode());
            paraMap.put("switchState",SysDictEnum.OPEN_SWITCH.getCode());
            paraMap.put("numberConsultationsAllocated",numberConsultationsAllocated);
            paraMap.put("numberApplicationsSubmitted",numberApplicationsSubmitted);
            paraMap.put("contractSigned",contractSigned);
            paraMap.put("numberAuditsFailed",numberAuditsFailed);
            paraMap.put("materialSupplement",materialSupplement);
            paraMap.put("outsideVisit",outsideVisit);
            List<ReportBusinessStatisticsByCusServiceDO> mainInfos = taskScheduledDao.queryValidMailInfo(paraMap);
            if (mainInfos != null && mainInfos.size() > 0){
                Date nowDate = new Date();
                for (ReportBusinessStatisticsByCusServiceDO serviceDO:mainInfos){
                    paraMap.put("productId",serviceDO.getProductId());
                    paraMap.put("areaId",serviceDO.getAreaId());
                    paraMap.put("storeId",serviceDO.getStoreId());
                    paraMap.put("cusServiceId",serviceDO.getCusServiceId());
                    ReportBusinessStatisticsByCusServiceDO statisticsByCusServiceDO = taskScheduledDao.queryReportBusinessStatisticsByCusServiceDO(paraMap);
                    statisticsByCusServiceDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
                    statisticsByCusServiceDO.setCusServiceId(serviceDO.getCusServiceId());
                    statisticsByCusServiceDO.setAreaId(serviceDO.getAreaId());
                    statisticsByCusServiceDO.setStoreId(serviceDO.getStoreId());
                    statisticsByCusServiceDO.setProductId(serviceDO.getProductId());
                    statisticsByCusServiceDO.setReportDate(nowDate);
                    statisticsByCusServiceDO.setCreateTime(nowDate);
                    list.add(statisticsByCusServiceDO);
                }
                if (list.size() > 0){
                    taskScheduledDao.addReportBusinessStatisticsByCusService(list);
                }
            }else {
                logger.info("客服业务统计报表数据定时-未查询到有效的数据");
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.error("客服业务统计报表数据定时异常:"+e);
        }finally {
            logger.info("客服业务统计报表数据定时生成结束");
        }
    }
    
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void bidRepeal() {
		
	}
}
