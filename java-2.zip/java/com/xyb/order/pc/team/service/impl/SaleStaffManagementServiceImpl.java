package com.xyb.order.pc.team.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.DesUtil;
import com.xyb.auth.user.model.User;
import com.xyb.auth.user.service.UserService;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.model.TableModifyLogDTO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.message.service.MessageService;
import com.xyb.order.common.util.IdcardValidator;
import com.xyb.order.common.util.ShareCodeUtil;
import com.xyb.order.pc.team.dao.SaleStaffManagementDao;
import com.xyb.order.pc.team.model.*;
import com.xyb.order.pc.team.service.SaleStaffManagementService;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 销售人员管理实现
 * @author         xieqingyang
 * @date           2018/4/10 11:51 AM
*/
@Service(interfaceName = "com.xyb.order.pc.team.service.SaleStaffManagementService")
public class SaleStaffManagementServiceImpl implements SaleStaffManagementService{

    private static final Logger logger = LoggerFactory.getLogger(SaleStaffManagementServiceImpl.class);

    @Autowired
    private SaleStaffManagementDao saleStaffManagementDao;
    @Autowired
    private MessageService validMessageService;
    @Autowired
    private TableModifyLogService tableModifyService;
    @Reference
    private UserService userService;

    @Override
    public RestResponse listSaleStaffManagementPage(Integer pageNumber, Integer pageSize, SaleStaffManagementDTO saleStaffManagementDTO)throws Exception {
        saleStaffManagementDTO.getPage().setPageSize(pageSize);
        saleStaffManagementDTO.getPage().setPageNumber(pageNumber);
        User user = SessionUtil.getLoginUser(User.class);
        saleStaffManagementDTO.setOrgId(user.getOrgId());
        List<SaleStaffManagementDO> saleStaffManagementDOS = saleStaffManagementDao.listSaleUserDetailPage(saleStaffManagementDTO);
        saleStaffManagementDTO.getPage().setContents(saleStaffManagementDOS);
        return new RestResponse(MsgErrCode.SUCCESS, saleStaffManagementDTO.getPage());
    }

    @Override
    public RestResponse querySaleUserInFo(Long id)throws Exception {
        UpdateSaleUserDO userDO = saleStaffManagementDao.querySaleUserInFo(id);
        if (userDO != null){
            return new RestResponse(MsgErrCode.SUCCESS, userDO);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateSaleUserInFo(UpdateSaleUserDTO updateSaleUserDTO)throws Exception {
        if (SysDictEnum.NO_VALID.getCode().equals(updateSaleUserDTO.getIsValid())){
            User user = new User();
            user.setId(updateSaleUserDTO.getId());
            user.setState(SysDictEnum.NO_VALID.getCode());
            user.setLeaveDate(updateSaleUserDTO.getLeaveDate());
            try {
                return userService.update(user);
            }catch (Exception e){
                e.printStackTrace();
                logger.info("修改销售人员信息异常");
                return new RestResponse(MsgErrCode.FAIL);
            }
        }
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("state",SysDictEnum.IS_VALID.getCode());
        paraMap.put("phone",updateSaleUserDTO.getPhone());
        paraMap.put("id",updateSaleUserDTO.getId());
        int count = saleStaffManagementDao.getValidSaleCount(paraMap);
        if (count > 0){
            return new RestResponse(NativeMsgErrCode.PHONE_REGISTERED);
        }
        UpdateSaleUserDTO saleUser = saleStaffManagementDao.getSaleUserComparison(updateSaleUserDTO.getId());
        if (!saleUser.getPhone().equals(updateSaleUserDTO.getPhone())) {
            // -- 验证短信验证码
            RestResponse response = validMessageService.validateMessageCode(updateSaleUserDTO.getPhone(), updateSaleUserDTO.getMessageCode(), null, CurrencyConstant.Y, user.getId());
            if (response.getResult() != 0) {
                return response;
            }
        }
        // -- 修改
        User user1 = new User();
        user1.setIdcard(updateSaleUserDTO.getIdCard());
        user1.setMobile(updateSaleUserDTO.getPhone());
        user1.setName(updateSaleUserDTO.getName());
        user1.setState(updateSaleUserDTO.getIsValid());
        user1.setId(updateSaleUserDTO.getId());
        if (updateSaleUserDTO.getLeaveDate() != null){
            user1.setLeaveDate(updateSaleUserDTO.getLeaveDate());
        }
        UpdateSaleUserDTO updateSaleUserDTOComparison = saleStaffManagementDao.getSaleUserComparison(updateSaleUserDTO.getId());
        TableModifyLogDTO modifyLogDTO = new TableModifyLogDTO();
        modifyLogDTO.setTableName(TableConstant.T_USER);
        modifyLogDTO.setTableKey(updateSaleUserDTO.getId());
        modifyLogDTO.setModifyNewValue(JsonUtil.object2json(updateSaleUserDTO));
        modifyLogDTO.setModifyOldValue(JsonUtil.object2json(updateSaleUserDTOComparison));
        modifyLogDTO.setCreateUser(user.getId());
        modifyLogDTO.setNoNeed(new String[]{"id","messageCode","isValid","createUserId"});
        tableModifyService.insertTableModirfyLog(modifyLogDTO);
        try {
            return userService.update(user1);
        }catch (Exception e){
            e.printStackTrace();
            logger.info("修改销售人员信息异常");
            return new RestResponse(MsgErrCode.FAIL);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse insertSaleUserInFo(InsertSaleUserDTO insertSaleUserDTO) throws Exception{
        if(!new IdcardValidator().isValidate18Idcard(insertSaleUserDTO.getIdCard())){
            return new RestResponse(NativeMsgErrCode.ILLEGALITY_IDCARD);
        }
        User user = SessionUtil.getLoginUser(User.class);
        // -- 验证短信验证码
        RestResponse response = validMessageService.validateMessageCode(insertSaleUserDTO.getPhone(),insertSaleUserDTO.getMessageCode(),null,CurrencyConstant.Y,user.getId());
        if (response.getResult() != 0){
            return response;
        }
        // -- 验证是否能够注册
        String result = verification(SysDictEnum.IS_VALID.getCode(),insertSaleUserDTO.getPhone(),insertSaleUserDTO.getIdCard(),null);
        if ("1".equals(result)){
            response = new RestResponse(NativeMsgErrCode.PHONE_REGISTERED);
        }else if ("2".equals(result)){
            response = new RestResponse(NativeMsgErrCode.IDCARD_REGISTERED);
        }else {
            User user1 = new User();
            user1.setLoginId(getSaleNum());
            user1.setName(insertSaleUserDTO.getName());
            user1.setOrgId(insertSaleUserDTO.getOrgTeamId());
            user1.setMobile(insertSaleUserDTO.getPhone());
            user1.setIdcard(insertSaleUserDTO.getIdCard());
            user1.setPassword(CurrencyConstant.SALE_USER_PASSWORD);
            user1.setEntryDate(insertSaleUserDTO.getEntryDate());
            user1.setRecommendCode(getRecommondCode());
            user1.setPosts(String.valueOf(56));
            try {
                response = userService.save(user1);
            } catch (Exception e) {
                e.printStackTrace();
                logger.info("添加销售人员信息异常");
                response = new RestResponse(MsgErrCode.FAIL);
            }
        }
        return response;
    }

    @Override
    public RestResponse beforeInsertSaleUserInFo()throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("userId",user.getId());
        InsertSaleUserDO insertSaleUserDO = saleStaffManagementDao.beforeInsertSaleUserInFo(paraMap);
        if (insertSaleUserDO != null){
            return new RestResponse(MsgErrCode.SUCCESS, insertSaleUserDO);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    /**
     * 创建时间（年月日）+营业部缩写+销售团队编号后2位
     */
    private String getSaleNum(){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyMMddHHssmm");
        String saleNum = simpleDateFormat.format(new Date());
        return saleNum;
    }

    /**
     * 判断销售人员是否能够修改或注册
     * @param state
     * @param phone
     * @param idCard
     * @param id
     * @return 1:手机号重复 2：身份证重复 0：可操作
     */
    private String verification(Long state, String phone, String idCard, Long id){
        Map<String,Object> paraMap = new HashMap<>(10);
        int count;
        if (state != null){
            paraMap.put("state",state);
        }
        if (StringUtils.isNotNullAndEmpty(phone)){
            paraMap.put("phone",phone);
        }
        if (id != null){
            paraMap.put("id",id);
        }
        count = saleStaffManagementDao.getValidSaleCount(paraMap);
        if (count > 0){
            return  "1";
        }
        paraMap.remove("phone");
        if (StringUtils.isNotNullAndEmpty(idCard)){
            paraMap.put("idCard",idCard);
        }
        count = saleStaffManagementDao.getValidSaleCount(paraMap);
        if (count > 0){
            return  "2";
        }
        return "0";
    }

    /**
    * 获得客户经理推荐码
    * @author     xieqingyang
    * @return     boolean
    * @exception
    * @date        2018/5/11 下午2:38
    */
    private String getRecommondCode(){
        boolean boo = true;
        String recommondCode;
        List<String> saleCodes;
        if (RedisUtil.exists(RedisConstant.SALE_CODE)){
            saleCodes = RedisUtil.get(RedisConstant.SALE_CODE,List.class);
        }else {
            saleCodes = saleStaffManagementDao.querySaleCodes();
        }
        do {
            recommondCode = ShareCodeUtil.generateRandomStr(6);
            if (saleCodes.contains(recommondCode)){
                continue;
            }else {
                saleCodes.add(recommondCode);
                boo = false;
            }
        }while (boo);
        RedisUtil.setex(RedisConstant.SALE_CODE,saleCodes);
        return recommondCode;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(DesUtil.decrypt("dYLFiyrDu+E="));
    }

}
