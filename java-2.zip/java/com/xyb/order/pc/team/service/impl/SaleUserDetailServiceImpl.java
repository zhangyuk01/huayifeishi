package com.xyb.order.pc.team.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.team.dao.SaleUserDetailDao;
import com.xyb.order.pc.team.model.SaleUserDetailDO;
import com.xyb.order.pc.team.model.SaleUserDetailDTO;
import com.xyb.order.pc.team.model.SaleUserDetailExportNoValidDO;
import com.xyb.order.pc.team.model.SaleUserDetailExportValidDO;
import com.xyb.order.pc.team.service.SaleUserDetailService;
import com.xyb.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 销售人员明细接口实现
 * @author         xieqingyang
 * @date           2018/4/8 1:37 PM
*/
@Service(interfaceName = "com.xyb.order.pc.team.service.SaleUserDetailService")
public class SaleUserDetailServiceImpl implements SaleUserDetailService {

    @Autowired
    private SaleUserDetailDao managementDao;

    @Override
    public RestResponse listSaleUserDetailPage(Integer pageNumber, Integer pageSize, SaleUserDetailDTO userDetailDTO) throws Exception{
        userDetailDTO.getPage().setPageNumber(pageNumber);
        userDetailDTO.getPage().setPageSize(pageSize);
        User user = SessionUtil.getLoginUser(User.class);
        userDetailDTO.setOrgId(user.getOrgId());
        List<SaleUserDetailDO> userDetailDTOS = managementDao.listSaleUserDetailPage(userDetailDTO);
        userDetailDTO.getPage().setContents(userDetailDTOS);
        return new RestResponse(MsgErrCode.SUCCESS, userDetailDTO.getPage());
    }

    @Override
    public Map<String,Object> listSaleUserDetailExport(SaleUserDetailDTO userDetailDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        userDetailDTO.setOrgId(user.getOrgId());
        Map<String,Object> returnMap = new HashMap<>(5);
        String[] headers;
        if (SysDictEnum.IS_VALID.getCode().toString().equals(userDetailDTO.getIsValid())){
            List<SaleUserDetailExportValidDO> saleUserDetailExportValidDOS = managementDao.listSaleUserDetailExportValid(userDetailDTO);
            headers = new String[]{"城市", "进件机构", "销售团队", "团队经理", "销售人员", "员工编号", "创建日期", "是否有效", "入职日期"};
            returnMap.put("info",saleUserDetailExportValidDOS);
            returnMap.put("headers",headers);
        }else {
            List<SaleUserDetailExportNoValidDO> saleUserDetailExportNoValidDOS = managementDao.listSaleUserDetailExportNoValid(userDetailDTO);
            headers = new String[]{"城市","进件机构","销售团队","团队经理","销售人员","员工编号", "创建日期","是否有效","入职日期","置为无效日期","离职日期"};
            returnMap.put("info",saleUserDetailExportNoValidDOS);
            returnMap.put("headers",headers);
        }
        return returnMap;
    }
}
