package com.xyb.order.pc.team.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.dao.TableModifyLogDao;
import com.xyb.order.common.currency.model.TableModifyLogDTO;
import com.xyb.order.pc.team.dao.SaleTeamChangeDao;
import com.xyb.order.pc.team.model.ChangeSaleTeamDTO;
import com.xyb.order.pc.team.model.ChangeSaleTeamSubsidiaryDTO;
import com.xyb.order.pc.team.model.SaleTeamChangeDO;
import com.xyb.order.pc.team.model.SaleTeamChangeDTO;
import com.xyb.order.pc.team.service.SaleTeamChangeService;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.SysDictEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;

/**
 * 销售团队变更接口实现
 * @author         xieqingyang
 * @date           2018/4/10 11:55 AM
*/
@Service(interfaceName = "com.xyb.order.pc.team.service.SaleTeamChangeService")
public class SaleTeamChangeServiceImpl implements SaleTeamChangeService{

    @Autowired
    private SaleTeamChangeDao saleTeamChangeDao;
    @Autowired
    private TableModifyLogDao tableModifyLogDao;

    @Override
    public RestResponse listSaleUserPage(Integer pageNumber, Integer pageSize, SaleTeamChangeDTO saleTeamChangeDTO)throws Exception{
        saleTeamChangeDTO.getPage().setPageNumber(pageNumber);
        saleTeamChangeDTO.getPage().setPageSize(pageSize);
        saleTeamChangeDTO.setIsValid(SysDictEnum.IS_VALID.getCode());
        User user = SessionUtil.getLoginUser(User.class);
        saleTeamChangeDTO.setOrgId(user.getOrgId());
        List<SaleTeamChangeDO> saleTeamChangeDOS = saleTeamChangeDao.listSaleUserPage(saleTeamChangeDTO);
        saleTeamChangeDTO.getPage().setContents(saleTeamChangeDOS);
        return new RestResponse(MsgErrCode.SUCCESS, saleTeamChangeDTO.getPage());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse changeSaleTeam(ChangeSaleTeamDTO changeSaleTeamDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        List<ChangeSaleTeamSubsidiaryDTO> saleUserId = changeSaleTeamDTO.getList();
        List<TableModifyLogDTO> modifyLogDTOS = new ArrayList<>();
        ChangeSaleTeamSubsidiaryDTO changeSaleTeamSubsidiaryDTO;
        for (int i = 0;i<saleUserId.size();i++){
            changeSaleTeamSubsidiaryDTO = saleUserId.get(i);
            if (!changeSaleTeamSubsidiaryDTO.getOrgTeamIdOld().equals(changeSaleTeamDTO.getOrgTeamId())){
                TableModifyLogDTO modifyLogDTO = new TableModifyLogDTO();
                modifyLogDTO.setCreateUser(user.getId());
                modifyLogDTO.setTableField("org_id");
                modifyLogDTO.setTableKey(changeSaleTeamSubsidiaryDTO.getId());
                modifyLogDTO.setTableName(TableConstant.T_USER);
                modifyLogDTO.setModifyNewValue(changeSaleTeamDTO.getOrgTeamId()+"");
                modifyLogDTO.setModifyOldValue(changeSaleTeamSubsidiaryDTO.getOrgTeamIdOld()+"");
                modifyLogDTOS.add(modifyLogDTO);
            }else {
                saleUserId.remove(i);
                i--;
            }
        }
        changeSaleTeamDTO.setIsValid(SysDictEnum.IS_VALID.getCode());
        changeSaleTeamDTO.setModifyUser(user.getId());
        if (saleUserId.size() > 0) {
            changeSaleTeamDTO.setList(saleUserId);
            saleTeamChangeDao.changeSaleTeam(changeSaleTeamDTO);
            tableModifyLogDao.insertTableModirfyLog(modifyLogDTOS);
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }
}
