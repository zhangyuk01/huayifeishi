package com.xyb.order.pc.team.dao;

import com.xyb.order.pc.team.model.SaleUserDetailDO;
import com.xyb.order.pc.team.model.SaleUserDetailDTO;
import com.xyb.order.pc.team.model.SaleUserDetailExportNoValidDO;
import com.xyb.order.pc.team.model.SaleUserDetailExportValidDO;

import java.util.List;

/**
 * Created by xieqingyang on 2018/4/8.
 */
public interface SaleUserDetailDao {

    /**
    * 销售人员明细分页
    * @author      xieqingyang
    * @param userDetailDTO
    * @return
    * @exception
    * @date        2018/5/18 上午9:31
    */
    List<SaleUserDetailDO> listSaleUserDetailPage(SaleUserDetailDTO userDetailDTO);

    /**
     * 导出销售人员明细(有效)
     * @author      xieqingyang
     * @param userDetailDTO
     * @return
     * @exception
     * @date        2018/5/18 上午9:31
     */
    List<SaleUserDetailExportValidDO> listSaleUserDetailExportValid(SaleUserDetailDTO userDetailDTO);


    /**
     * 导出销售人员明细（无效）
     * @author      xieqingyang
     * @param userDetailDTO
     * @return
     * @exception
     * @date        2018/5/18 上午9:31
     */
    List<SaleUserDetailExportNoValidDO> listSaleUserDetailExportNoValid(SaleUserDetailDTO userDetailDTO);
}
