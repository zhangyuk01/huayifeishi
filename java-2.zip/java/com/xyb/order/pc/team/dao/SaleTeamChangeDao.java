package com.xyb.order.pc.team.dao;

import com.xyb.order.pc.team.model.ChangeSaleTeamDTO;
import com.xyb.order.pc.team.model.SaleTeamChangeDO;
import com.xyb.order.pc.team.model.SaleTeamChangeDTO;

import java.util.List;
import java.util.Map;

/**
 * Created by xieqingyang on 2018/4/10.
 */
public interface SaleTeamChangeDao {

    List<SaleTeamChangeDO> listSaleUserPage(SaleTeamChangeDTO teamChangeDTO);

    int changeSaleTeam(ChangeSaleTeamDTO changeSaleTeamDTO);
}
