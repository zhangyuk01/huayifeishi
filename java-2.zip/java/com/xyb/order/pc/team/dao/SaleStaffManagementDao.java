package com.xyb.order.pc.team.dao;

import com.xyb.order.pc.team.model.*;

import java.util.List;
import java.util.Map;

/**
 * Created by xieqingyang on 2018/4/10.
 */
public interface SaleStaffManagementDao {

    List<SaleStaffManagementDO> listSaleUserDetailPage(SaleStaffManagementDTO saleStaffManagementDTO);

    UpdateSaleUserDO querySaleUserInFo(Long id);

    int updateSaleUserInFo(UpdateSaleUserDTO updateSaleUserDTO);

    UpdateSaleUserDTO getSaleUserComparison(Long id);

    int insertSaleUserInFo(InsertSaleUserDTO insertSaleUserDTO);

    InsertSaleUserDO beforeInsertSaleUserInFo(Map<String,Object> paraMap);

    int getValidSaleCount(Map<String,Object> paraMap);

    List<String> querySaleCodes();
}
