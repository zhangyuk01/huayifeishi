package com.xyb.order.pc.reportform.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.reportform.dao.ReportFormDao;
import com.xyb.order.pc.reportform.model.*;
import com.xyb.order.pc.reportform.service.ReportFormService;
import com.xyb.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

/**
 * 报表管理
 * @author         xieqingyang
 * @date           2018/10/18 11:47 AM
*/
@Service(interfaceName = "com.xyb.order.pc.reportform.service.ReportFormService")
public class ReportFormServiceImpl implements ReportFormService{

    @Autowired
    private ReportFormDao formDao;

    @Override
    public RestResponse comprehensiveQuery(Integer pageNumber,Integer pageSize,ComprehensiveQueryDTO comprehensiveQueryDTO)throws Exception {
        comprehensiveQueryDTO.getPage().setPageSize(pageSize);
        comprehensiveQueryDTO.getPage().setPageNumber(pageNumber);
        User user = SessionUtil.getLoginUser(User.class);
        comprehensiveQueryDTO.setOrgId(user.getOrgId());
        List<ComprehensiveQueryDO> queryDOS = formDao.comprehensiveQueryPage(comprehensiveQueryDTO);
        // -- 进行状态显示处理
        String stateName;
        for (ComprehensiveQueryDO comprehensiveQueryDO:queryDOS) {
        	stateName = NodeStateConstant.getNodeStateNameOfReport(comprehensiveQueryDO.getStateCode());
        	if (StringUtils.isNotNullAndEmpty(stateName)){
        		comprehensiveQueryDO.setState(stateName);
        	}
        }
        comprehensiveQueryDTO.getPage().setContents(queryDOS);
        return new RestResponse(MsgErrCode.SUCCESS,comprehensiveQueryDTO.getPage());
    }

	@Override
	public List<ComprehensiveQueryExportDO> outComprehensiveQueryExport(ComprehensiveQueryExportDTO comprehensiveQueryExportDTO)throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		comprehensiveQueryExportDTO.setOrgId(user.getOrgId());
		List<ComprehensiveQueryExportDO> queryDOS = formDao.outComprehensiveQueryExport(comprehensiveQueryExportDTO);
		 // -- 进行状态显示处理
        String stateName;
        for (ComprehensiveQueryExportDO comprehensiveQueryExportDO:queryDOS) {
        	stateName = NodeStateConstant.getNodeStateNameOfReport(comprehensiveQueryExportDO.getState());
        	if (StringUtils.isNotNullAndEmpty(stateName)){
        		comprehensiveQueryExportDO.setStateCode(stateName);
        	}
        	comprehensiveQueryExportDO.setState(null);
        }
		return queryDOS;
	}

    @Override
	public RestResponse comprehensiveAllQuery(Integer pageNumber, Integer pageSize,
			ComprehensiveAllQueryDTO comprehensiveAllQueryDTO) throws Exception {
    	comprehensiveAllQueryDTO.getPage().setPageSize(pageSize);
    	comprehensiveAllQueryDTO.getPage().setPageNumber(pageNumber);
    	User user = SessionUtil.getLoginUser(User.class);
    	comprehensiveAllQueryDTO.setOrgId(user.getDataOrgId());
    	List<ComprehensiveAllQueryDO> comprehensiveAllQueryPage = formDao.comprehensiveAllQueryPage(comprehensiveAllQueryDTO);
    	 // -- 进行状态显示处理
        String stateName;
        for (ComprehensiveAllQueryDO comprehensiveAllQueryDO:comprehensiveAllQueryPage) {
            stateName = NodeStateConstant.getNodeStateNameOfAllQueryReport(comprehensiveAllQueryDO.getState());
            if (StringUtils.isNotNullAndEmpty(stateName)){
            	comprehensiveAllQueryDO.setStateCode(stateName);
            }
        }
    	comprehensiveAllQueryDTO.getPage().setContents(comprehensiveAllQueryPage);
		return new RestResponse(MsgErrCode.SUCCESS,comprehensiveAllQueryDTO.getPage());
	}
    
    @Override
	public List<ComprehensiveAllQueryExportDO> outComprehensiveAllQueryExport(ComprehensiveAllQueryExportDTO comprehensiveAllQueryExportDTO) throws Exception {
    	User user = SessionUtil.getLoginUser(User.class);
    	comprehensiveAllQueryExportDTO.setOrgId(user.getDataOrgId());
    	List<ComprehensiveAllQueryExportDO> outComprehensiveAllQueryExport = formDao.outComprehensiveAllQueryExport(comprehensiveAllQueryExportDTO);
    	 // -- 进行状态显示处理
        String stateName;
        for (ComprehensiveAllQueryExportDO comprehensiveAllQueryExportDO:outComprehensiveAllQueryExport) {
            stateName = NodeStateConstant.getNodeStateNameOfAllQueryReport(comprehensiveAllQueryExportDO.getState());
            if (StringUtils.isNotNullAndEmpty(stateName)){
            	comprehensiveAllQueryExportDO.setStateCode(stateName);
            }
            comprehensiveAllQueryExportDO.setState(null);
        }
    	return outComprehensiveAllQueryExport;
	}

    @Override
    public RestResponse fullScaleProcessTable(Integer pageNumber, Integer pageSize, FullScaleProcessTableDTO fullScaleProcessTableDTO)throws Exception {
        fullScaleProcessTableDTO.getPage().setPageNumber(pageNumber);
        fullScaleProcessTableDTO.getPage().setPageSize(pageSize);
        List<FullScaleProcessTableDO> fullScaleProcessTableDOS = formDao.fullScaleProcessTablePage(fullScaleProcessTableDTO);
        // -- 进行状态显示处理
        String stateName;
        for (FullScaleProcessTableDO fullScaleProcessTableDO:fullScaleProcessTableDOS) {
            stateName = NodeStateConstant.getNodeStateNameOfReport(fullScaleProcessTableDO.getStateCode());
            if (StringUtils.isNotNullAndEmpty(stateName)){
                fullScaleProcessTableDO.setState(stateName);
            }
        }
        fullScaleProcessTableDTO.getPage().setContents(fullScaleProcessTableDOS);
        return new RestResponse(MsgErrCode.SUCCESS,fullScaleProcessTableDTO.getPage());
    }

	@Override
	public  List<FullScaleProcessTableExportDO> outFullScaleProcessTable(FullScaleProcessTableExportDTO fullScaleProcessTableExportDTO)
			throws Exception {
		List<FullScaleProcessTableExportDO> outFullScaleProcessTableExport = formDao.outFullScaleProcessTableExport(fullScaleProcessTableExportDTO);
		// -- 进行状态显示处理
		String stateName;
		for (FullScaleProcessTableExportDO fullScaleProcessTableExportDO:outFullScaleProcessTableExport) {
			stateName = NodeStateConstant.getNodeStateNameOfReport(fullScaleProcessTableExportDO.getState());
			if (StringUtils.isNotNullAndEmpty(stateName)){
				fullScaleProcessTableExportDO.setStateCode(stateName);
			}
			fullScaleProcessTableExportDO.setState(null);
		}
		return outFullScaleProcessTableExport;
	}

    @Override
    public RestResponse customerServiceStatistics(Integer pageNumber, Integer pageSize, CustomerServiceStatisticsDTO customerServiceStatisticsDTO) throws Exception {
        customerServiceStatisticsDTO.getPage().setPageSize(pageSize);
        customerServiceStatisticsDTO.getPage().setPageNumber(pageNumber);
        User user = SessionUtil.getLoginUser(User.class);
        customerServiceStatisticsDTO.setOrgId(user.getOrgId());
        List<CustomerServiceStatisticsVO> vos = formDao.customerServiceStatisticsPage(customerServiceStatisticsDTO);
        customerServiceStatisticsDTO.getPage().setContents(vos);
        return new RestResponse(MsgErrCode.SUCCESS, customerServiceStatisticsDTO.getPage());
    }

    @Override
    public List<CustomerServiceStatisticsVO> customerServiceStatisticsExport(CustomerServiceStatisticsDTO customerServiceStatisticsDTO) throws Exception {
        return formDao.customerServiceStatisticsExport(customerServiceStatisticsDTO);
    }

}
