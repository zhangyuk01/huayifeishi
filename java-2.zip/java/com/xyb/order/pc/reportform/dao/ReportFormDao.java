package com.xyb.order.pc.reportform.dao;

import com.xyb.order.pc.reportform.model.*;

import java.util.List;

/**
 * Created by xieqingyang on 2018/5/2.
 */
public interface ReportFormDao {

    List<ComprehensiveQueryDO> comprehensiveQueryPage(ComprehensiveQueryDTO comprehensiveQueryDTO);

    List<ComprehensiveQueryExportDO> outComprehensiveQueryExport(ComprehensiveQueryExportDTO comprehensiveQueryExportDTO);

    List<ComprehensiveAllQueryDO> comprehensiveAllQueryPage(ComprehensiveAllQueryDTO comprehensiveAllQueryDTO);
    
    List<ComprehensiveAllQueryExportDO> outComprehensiveAllQueryExport(ComprehensiveAllQueryExportDTO comprehensiveAllQueryExportDTO);

    List<FullScaleProcessTableDO> fullScaleProcessTablePage(FullScaleProcessTableDTO fullScaleProcessTableDTO);

    List<FullScaleProcessTableExportDO> outFullScaleProcessTableExport(FullScaleProcessTableExportDTO fullScaleProcessTableExportDTO);

    /**
     * 客服人员统计列表
     * @author      xieqingyang
     * @date        2018/8/31 下午4:08
     * @version     1.0
     * @param customerServiceStatisticsDTO 查询条件
     * @return 返回列表数据
     */
    List<CustomerServiceStatisticsVO> customerServiceStatisticsPage(CustomerServiceStatisticsDTO customerServiceStatisticsDTO);

    /**
     * 客服人员统计导出
     * @author      xieqingyang
     * @date        2018/8/31 下午4:08
     * @version     1.0
     * @param customerServiceStatisticsDTO 查询条件
     * @return 返回导出数据
     */
    List<CustomerServiceStatisticsVO> customerServiceStatisticsExport(CustomerServiceStatisticsDTO customerServiceStatisticsDTO);
}
