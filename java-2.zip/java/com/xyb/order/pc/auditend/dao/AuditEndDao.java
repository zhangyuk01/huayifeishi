/**
 * 
 */
package com.xyb.order.pc.auditend.dao;

import com.xyb.order.pc.auditend.model.AuditEndApplyInfoDO;
import com.xyb.order.pc.auditend.model.AuditEndApplyMainInfoDO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.auditend.dao
 * @description : TODO
 * @createDate : 2018年12月25日 下午4:00:11
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface AuditEndDao {

    /**
     * 更新申请表
     *
     * @param auditEndApplyInfoDO
     */
    void updateApplyInfo(AuditEndApplyInfoDO auditEndApplyInfoDO);

    /**
     * 更新主表
     *
     * @param auditEndApplyMainInfoDO
     */
    void updateApplyMainInfo(AuditEndApplyMainInfoDO auditEndApplyMainInfoDO);

}
