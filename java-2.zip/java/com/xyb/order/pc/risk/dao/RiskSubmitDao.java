package com.xyb.order.pc.risk.dao;

import com.xyb.order.pc.risk.model.RiskSubmitDO;
import com.xyb.order.pc.risk.model.RiskSubmitDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListDO;
import com.xyb.order.pc.risk.model.RiskSubmitListDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDTO;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 风险提报相关功能
 * @author         xieqingyang
 * @date           2018/10/16 2:42 PM
*/
public interface RiskSubmitDao {

    /**
     * 查询风险提报列表数据
     * @author      xieqingyang
     * @date        2018/10/16 2:41 PM
     * @version     1.0
     * @param riskSubmitListDTO 查询条件
     * @return 返回列表数据
     */
    List<RiskSubmitListDO> listRiskSubmitPage(RiskSubmitListDTO riskSubmitListDTO);

    /**
     * 风险提报导出功能
     * @author      xieqingyang
     * @date        2018/10/16 2:42 PM
     * @version     1.0
     * @param riskSubmitListExportDTO 数据筛选条件
     * @return 返回导出数据
     */
    List<RiskSubmitListExportDO> outRiskSubmitExport(RiskSubmitListExportDTO riskSubmitListExportDTO);

    /**
     * 查询风险提报详情
     * @author      xieqingyang
     * @date        2018/10/16 2:43 PM
     * @version     1.0
     * @param mainId 主表ID
     * @return 返回详情数据
     */
    RiskSubmitDO getRiskSubmitInfo(Long mainId);

    /**
     * 新增风险提报
     * @author      xieqingyang
     * @date        2018/10/16 2:43 PM
     * @version     1.0
     * @param riskSubmitDTO 添加数据
     * @return 返回执行结果
     */
    int insertRiskSubmit(RiskSubmitDTO riskSubmitDTO);

    /**
     * 修改风险提报
     * @author      xieqingyang
     * @date        2018/10/16 2:43 PM
     * @version     1.0
     * @param paraMap 筛选条件
     * @return 返回执行结果
     */
    int updateRiskSubmitMain(Map<String,Object> paraMap);

    /**
     * 获取风险提报类型
     * @author      xieqingyang
     * @date        2018/10/16 2:44 PM
     * @version     1.0
     * @param riskType 类型
     * @return 返回文字描述
     */
    String getRiskType(@Param("riskType") String[] riskType);
}
