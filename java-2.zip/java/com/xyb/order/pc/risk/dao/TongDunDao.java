/**
 * 
 */
package com.xyb.order.pc.risk.dao;

import com.xyb.order.pc.risk.model.tongdun.TongDunDTO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.risk.dao
 * @description : TODO
 * @createDate : 2019年1月3日 下午2:04:49
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface TongDunDao {
	
	TongDunDTO getTongDunData(Long applyId) ;
}
