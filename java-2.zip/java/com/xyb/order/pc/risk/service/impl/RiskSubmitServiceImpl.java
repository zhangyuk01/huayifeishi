package com.xyb.order.pc.risk.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.service.XybContractAbolishService;
import com.xyb.order.pc.risk.dao.RiskSubmitDao;
import com.xyb.order.pc.risk.model.RiskSubmitDO;
import com.xyb.order.pc.risk.model.RiskSubmitDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListDO;
import com.xyb.order.pc.risk.model.RiskSubmitListDTO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDO;
import com.xyb.order.pc.risk.model.RiskSubmitListExportDTO;
import com.xyb.order.pc.risk.service.RiskSubmitService;
import com.xyb.risks.process.foreign.service.FraudService;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 风险提报功能
 * @author         xieqingyang
 * @date           2018/10/12 2:54 PM
*/
@Service(interfaceName = "com.xyb.order.pc.risk.service.RiskSubmitService")
public class RiskSubmitServiceImpl implements RiskSubmitService{

    private static final Logger log = LoggerFactory.getLogger(RiskSubmitServiceImpl.class);

    @Autowired
    private RiskSubmitDao riskSubmitDao;
    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private OtherPlatformRelevantService otherPlatformRelevantService;
    @Reference
    private FraudService fraudService;
    @Autowired
    private ApplyBillInfoDao applyBillInfoDao;
    @Autowired
    private XybContractAbolishService xybContractAbolishService;

    @Override
    public RestResponse listRiskSubmitPage(Integer pageNumber, Integer pageSize, RiskSubmitListDTO riskSubmitListDTO)throws Exception  {
        riskSubmitListDTO.getPage().setPageNumber(pageNumber);
        riskSubmitListDTO.getPage().setPageSize(pageSize);
        User user = SessionUtil.getLoginUser(User.class);
        riskSubmitListDTO.setOrgId(user.getDataOrgId());
        riskSubmitListDTO.setList(NodeStateConstant.RISK_SUBMIT_LIST);
        List<RiskSubmitListDO> riskSubmitListDOS = riskSubmitDao.listRiskSubmitPage(riskSubmitListDTO);
        riskSubmitListDTO.getPage().setContents(riskSubmitListDOS);
        return new RestResponse(MsgErrCode.SUCCESS, riskSubmitListDTO.getPage());
    }
    
    @Override
	public List<RiskSubmitListExportDO> outRiskSubmitExport(RiskSubmitListExportDTO riskSubmitListExportDTO) {
        User user = SessionUtil.getLoginUser(User.class);
        riskSubmitListExportDTO.setOrgId(user.getDataOrgId());
        riskSubmitListExportDTO.setList(NodeStateConstant.RISK_SUBMIT_LIST);
		return riskSubmitDao.outRiskSubmitExport(riskSubmitListExportDTO);
	}

    @Override
    public RestResponse getRiskSubmitInfo(Long mainId)throws Exception {
        RiskSubmitDO riskSubmitDO = riskSubmitDao.getRiskSubmitInfo(mainId);
        if (riskSubmitDO != null){
            User user = SessionUtil.getLoginUser(User.class);
            riskSubmitDO.setSubmitUser(user.getName());
            return new RestResponse(MsgErrCode.SUCCESS, riskSubmitDO);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse insertRiskSubmit(RiskSubmitDTO riskSubmitDTO,String ipAddr,String macAddr)throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        riskSubmitDTO.setSubmPerson(user.getId());
        /**修改主表并添加主表修改日志**/
        MainLogDTO mainLogDTO = new MainLogDTO();
        mainLogDTO.setModifyUser(user.getId());
        mainLogDTO.setModifyUserName(user.getName());
        mainLogDTO.setBusinessState(NodeStateConstant.RIS_REPORTING_AND_REFUSING_TO_LEND);
        mainLogDTO.setBusinessStateName("风险提报拒贷");
        mainLogDTO.setMainId(riskSubmitDTO.getMainId());
        ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
        applyBillMainInfoDO.setState(NodeStateConstant.RIS_REPORTING_AND_REFUSING_TO_LEND);
        //applyBillMainInfoDO.setSubmitApplyToAuditTime(new Date());
        applyBillMainInfoDO.setModifyUser(user.getId());
        applyBillMainInfoDO.setId(riskSubmitDTO.getMainId());
        applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
        applyBillMainInfoDO.setRefuseCode(riskSubmitDTO.getSubmReson());
        applyBillMainInfoDO.setRefuseValue(riskSubmitDTO.getSubmResonName());
        applyBillMainInfoDO.setIsRiskHand(SysDictEnum.IS_RISK_SUBMIT.getCode());
        this.riskSubmitDao.insertRiskSubmit(riskSubmitDTO);
        this.currencyDao.addMainLog(mainLogDTO);
        this.currencyDao.updateMainInFo(applyBillMainInfoDO);
        try {
            // -- 其他平台上线后替换
            // -— 接口依赖  推送给风控系统
            fraudService.blackListSubmitForOther(otherPlatformRelevantService.getFxtbJson(riskSubmitDTO.getMainId(),riskSubmitDTO.getRiskDesc(),user.getId(),user.getName()));
            Map<String,Object> paraMap = new HashMap<>(1);
            paraMap.put("applyId",riskSubmitDTO.getApplyId());
            ApplyBillMainInfoDO mainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paraMap);
            if (mainInfoDO == null){
                return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
            }
            // -- 如果是募标中状态 调用深圳撤标
            if (NodeStateConstant.IN_THE_BID.equals(mainInfoDO.getState())){
                XybContractAbolishDTO xybContractAbolishDTO = new XybContractAbolishDTO();
                xybContractAbolishDTO.setApplyId(riskSubmitDTO.getApplyId());
                RestResponse response = xybContractAbolishService.abolishContract(xybContractAbolishDTO,ipAddr,macAddr);
                // -- 处理失败   使事务回滚
                if (response.getResult() != 0){
                    log.error("调用撤标接口异常");
                    throw new Exception("调用撤标接口异常:"+response.toString());
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("调用风控风险提报接口异常:"+e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

	
}
