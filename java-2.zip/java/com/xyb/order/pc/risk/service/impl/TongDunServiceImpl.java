/**
 * 
 */
package com.xyb.order.pc.risk.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.xyb.loan.finance.common.model.ApplyMainInfoDO;
import com.xyb.order.common.constant.TongDunDictConstant;
import com.xyb.order.pc.applybill.dao.ApplyLinkmanInfoDao;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDO;
import com.xyb.order.pc.risk.dao.TongDunDao;
import com.xyb.order.pc.risk.model.tongdun.TongDunDTO;
import com.xyb.order.pc.risk.service.TongDunService;
import com.xyb.util.DateUtils;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.risk.service.impl
 * @description : TODO
 * @createDate : 2019年1月3日 下午2:11:07
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.risk.service.TongDunService")
public class TongDunServiceImpl implements TongDunService {

    private static final Logger log = LoggerFactory.getLogger(TongDunServiceImpl.class);

    @Autowired
    private TongDunDao tongDunDao;
    @Autowired
    private ApplyLinkmanInfoDao applyLinkmanInfoDao;
    
	@Override
	public TongDunDTO getTongDunData(Long applyId) throws Exception{
		TongDunDTO tongDunDTO = tongDunDao.getTongDunData(applyId);
		if(tongDunDTO != null){
			/**一.系统数据转换为同盾指定的类型数据*/
			/**1.学历转换*/
			tongDunDTO.setDiploma(getDiploma(Long.valueOf(tongDunDTO.getDiploma())));
			/**2.婚姻转换*/
			tongDunDTO.setMarriage(getMarriage(Long.valueOf(tongDunDTO.getMarriage())));
			/**3.职业转换*/
			if(null != tongDunDTO.getCareer()){
				tongDunDTO.setCareer(getCareer(Long.valueOf(tongDunDTO.getCareer())));
			}else{
				tongDunDTO.setCareer("失业");
			}
			/**4.工作时间转换*/
			int year = DateUtils.getYearRange(DateUtils.getDate(tongDunDTO.getWork_time()), new Date());
			tongDunDTO.setWork_time(getYearNum(year));
			/**5.公司行业转换*/
			tongDunDTO.setCompany_industry(getCompanyIndustry(Long.valueOf(tongDunDTO.getCompany_industry())));
			/**6.公司性质转换*/
			tongDunDTO.setCompany_type(getCompanyType(Long.valueOf(tongDunDTO.getCompany_type())));
			/**7.联系人封装*/
			Map<String, Object> map = new HashMap<String, Object>(2);
			map.put("applyId", applyId);
			List<ApplyLinkmanInfoDO> applyMainInfoDOs = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(map);
			for(int i = 1;i <= applyMainInfoDOs.size();i++){
				ApplyLinkmanInfoDO applyLinkmanInfoDO = applyMainInfoDOs.get(i-1);
				switch (i) {
				case 1:
					if(applyLinkmanInfoDO.getRelation() != null){
						tongDunDTO.setContact1_relation(getRelationType(applyLinkmanInfoDO.getRelation()));
					}
					tongDunDTO.setContact1_name(applyLinkmanInfoDO.getName());
					tongDunDTO.setContact1_id_number(applyLinkmanInfoDO.getIdcard());
					tongDunDTO.setContact1_mobile(applyLinkmanInfoDO.getPhone());
					tongDunDTO.setContact1_addr(applyLinkmanInfoDO.getAllAddress());
					tongDunDTO.setContact1_com_name(applyLinkmanInfoDO.getCompName());
					tongDunDTO.setContact1_com_addr(applyLinkmanInfoDO.getAllAddress());
					break;
				case 2:
					if(applyLinkmanInfoDO.getRelation() != null){
						tongDunDTO.setContact2_relation(getRelationType(applyLinkmanInfoDO.getRelation()));
					}
					tongDunDTO.setContact2_name(applyLinkmanInfoDO.getName());
					tongDunDTO.setContact2_id_number(applyLinkmanInfoDO.getIdcard());
					tongDunDTO.setContact2_mobile(applyLinkmanInfoDO.getPhone());
					tongDunDTO.setContact2_addr(applyLinkmanInfoDO.getAllAddress());
					tongDunDTO.setContact2_com_name(applyLinkmanInfoDO.getCompName());
					tongDunDTO.setContact2_com_addr(applyLinkmanInfoDO.getAllAddress());
					break;
				case 3:
					if(applyLinkmanInfoDO.getRelation() != null){
						tongDunDTO.setContact3_relation(getRelationType(applyLinkmanInfoDO.getRelation()));
					}
					tongDunDTO.setContact3_name(applyLinkmanInfoDO.getName());
					tongDunDTO.setContact3_id_number(applyLinkmanInfoDO.getIdcard());
					tongDunDTO.setContact3_mobile(applyLinkmanInfoDO.getPhone());
					tongDunDTO.setContact3_addr(applyLinkmanInfoDO.getAllAddress());
					tongDunDTO.setContact3_com_name(applyLinkmanInfoDO.getCompName());
					tongDunDTO.setContact3_com_addr(applyLinkmanInfoDO.getAllAddress());
					break;
				case 4:
					if(applyLinkmanInfoDO.getRelation() != null){
						tongDunDTO.setContact4_relation(getRelationType(applyLinkmanInfoDO.getRelation()));
					}
					tongDunDTO.setContact4_name(applyLinkmanInfoDO.getName());
					tongDunDTO.setContact4_id_number(applyLinkmanInfoDO.getIdcard());
					tongDunDTO.setContact4_mobile(applyLinkmanInfoDO.getPhone());
					tongDunDTO.setContact4_addr(applyLinkmanInfoDO.getAllAddress());
					tongDunDTO.setContact4_com_name(applyLinkmanInfoDO.getCompName());
					tongDunDTO.setContact4_com_addr(applyLinkmanInfoDO.getAllAddress());
					break;
				case 5:
					if(applyLinkmanInfoDO.getRelation() != null){
						tongDunDTO.setContact5_relation(getRelationType(applyLinkmanInfoDO.getRelation()));
					}
					tongDunDTO.setContact5_name(applyLinkmanInfoDO.getName());
					tongDunDTO.setContact5_id_number(applyLinkmanInfoDO.getIdcard());
					tongDunDTO.setContact5_mobile(applyLinkmanInfoDO.getPhone());
					tongDunDTO.setContact5_addr(applyLinkmanInfoDO.getAllAddress());
					tongDunDTO.setContact5_com_name(applyLinkmanInfoDO.getCompName());
					tongDunDTO.setContact5_com_addr(applyLinkmanInfoDO.getAllAddress());
					break;
				}
			}
		}
		return tongDunDTO;
	}
	/**
	 * 学历转换
	 * @param code
	 * @return
	 */
	private String getDiploma(Long code){
		String value = null;
		switch (code.intValue()) {
			case  1598:
				value = TongDunDictConstant.PRE_HIGH_SCHOOL;
				break;
			case  1597:
				value = TongDunDictConstant.HIGH_SCHOOL;
				break;
			case  1596:
				value = TongDunDictConstant.JUNIOR_COLLEGE;
				break;
			case  1595:
				value = TongDunDictConstant.UNDER_GRADUATE;
				break;
			default:
				value = TongDunDictConstant.POST_GRADUATE;
				break;
		}
		return value;
	}
	
	/**
	 * 婚姻转换
	 * @param code
	 * @return
	 */
	private String getMarriage(Long code){
		String value = null;
		switch (code.intValue()) {
			case  2169:
				value = TongDunDictConstant.WIDOWED;
				break;
			case  2239:
				value = TongDunDictConstant.MARRIED;
				break;
			case  2240:
				value = TongDunDictConstant.DIVORCED;
				break;
			default:
				value = TongDunDictConstant.SPINSTERHOOD;
				break;
		}
		return value;
	}
	
	/**
	 * 职业转换
	 * @param code
	 * @return
	 */
	private String getCareer(Long code){
		String value = null;
		switch (code.intValue()) {
			case  1394:
				value = "政府官员、公务员";
				break;
			default:
				value = "一般工人";
				break;
		}
		return value;
	}
	
	/**
	 * 工作时间转换
	 * @param code
	 * @return
	 */
	private String getYearNum(Integer num){
		String value = null;
		switch (num) {
			case  1:
				value = "1年";
				break;
			case  2:
				value = "2年";
				break;
			case  3:
				value = "3-4年";
				break;
			case  4:
				value = "3-4年";
				break;
			case  5:
				value = "5-7年";
				break;
			case  6:
				value = "5-7年";
				break;
			case  7:
				value = "5-7年";
				break;
			case  8:
				value = "8-9年";
				break;
			case  9:
				value = "8-9年";
				break;
			default:
				value = "10年以上";
				break;
		}
		return value;
	}
	
	/**
	 * 公司行业转换
	 * @param code
	 * @return
	 */
	private String getCompanyIndustry(Long code){
		String value = null;
		switch (code.intValue()) {
			case  3110:
				value = "农、林、牧、渔业";
				break;
			case  3111:
				value = "采掘业";
				break;
			case  3112:
				value = "制造业";
				break;
			case  3113:
				value = "电力、仓储和邮政业";
				break;
			case  3115:
				value = "批发和零售业";
				break;
			case  3117:
				value = "住宿和餐饮业";
				break;
			case  3118:
				value = "信息传输、计算机服务和软件业";
				break;
			case  3119:
				value = "金融业";
				break;
			case  3120:
				value = "房地产业";
				break;
			case  3121:
				value = "租赁和商务服务业";
				break;
			case  3122:
				value = "科学研究、技术服务业和地质勘察业";
				break;
			case  3123:
				value = "水利、环境和公共设施管理业";
				break;
			case  3124:
				value = "居民服务和其他服务业；";
				break;
			case  3125:
				value = "教育";
				break;
			case  3126:
				value = "卫生和社会工作";
				break;
			case  3127:
				value = "国际组织";
				break;
			case  3128:
				value = "公共管理和社会组织";
				break;
			case  3129:
				value = "文化、体育和娱乐业";
				break;
		}
		return value;
	}
	
	/**
	 * 公司性质转换
	 * @param code
	 * @return
	 */
	private String getCompanyType(Long code){
		String value = null;
		switch (code.intValue()) {
			case  1493:
				value = "机关事业";
				break;
			case  1766:
				value = "国有股份";
				break;
			case  1991:
				value = "私营";
				break;
			default:
				value = "其他";
				break;
		}
		return value;
	}
	
	/**
	 * 联系人关系转换
	 * @param code
	 * @return
	 */
	private String getRelationType(Long code){
		String value = null;
		switch (code.intValue()) {
			case  3092:
				value = "配偶";
				break;
			case  2009:
				value = "子女";
				break;
			case  2003:
				value = "其他亲属";
				break;
			case  2005:
				value = "朋友";
				break;
			case  2004:
				value = "同事";
				break;
			default:
				value = "其他";
				break;
		}
		return value;
	}
	
}
