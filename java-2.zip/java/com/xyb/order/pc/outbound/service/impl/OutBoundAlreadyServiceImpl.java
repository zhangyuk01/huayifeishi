package com.xyb.order.pc.outbound.service.impl;

import java.util.List;

import com.beiming.kun.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.pc.outbound.dao.OutBoundAlreadyDao;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyListExportVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyListVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyQueryDTO;
import com.xyb.order.pc.outbound.service.OutBoundAlreadyService;
import com.xyb.poi.ExportExcelService;
import com.xyb.util.SessionUtil;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 外访已办实现
 * @createDate : 2018/05/17 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.outbound.service.OutBoundAlreadyService")
public class OutBoundAlreadyServiceImpl implements OutBoundAlreadyService {
	private static final Logger logger = LoggerFactory.getLogger(OutBoundAlreadyServiceImpl.class);
	
	@Autowired
	private OutBoundAlreadyDao outBoundAlreadyDao;
	@SuppressWarnings("unchecked")
    @Autowired
    private ExportExcelService exportExcelService;
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse queryOutBoundAlreadys(Integer pageNumber, Integer pageSize,OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO) {
		RestResponse response;
		try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 
			 /**type：A 赋值机构码和外访人员  B赋值机构Id  C如果机构Id为空,赋值机构Id*/
			 if("A".equals(outBoundAlreadyQueryDTO.getType())){
				 outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
				 if(!StringUtils.isNotNullAndEmpty(outBoundAlreadyQueryDTO.getVisitUid())){
					 outBoundAlreadyQueryDTO.setVisitUid(loginUser.getId().toString());
				 }
			 }else if("B".equals(outBoundAlreadyQueryDTO.getType())){
				 outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
			 }else if("C".equals(outBoundAlreadyQueryDTO.getType())){
				 if(outBoundAlreadyQueryDTO.getOrgId() == null){
					 outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
				 }
			 }
			 outBoundAlreadyQueryDTO.getPage().setPageNumber(pageNumber);
			 outBoundAlreadyQueryDTO.getPage().setPageSize(pageSize);
			 /**合同状态转换*/
			 if(StringUtils.isNotNullAndEmpty(outBoundAlreadyQueryDTO.getContractState())){
				 outBoundAlreadyQueryDTO.setList(NodeStateConstant.getNodeStateList(Integer.valueOf(outBoundAlreadyQueryDTO.getContractState())));
			 }
		     List<OutBoundAlreadyListVO> list = outBoundAlreadyDao.listOutBoundPage(outBoundAlreadyQueryDTO);
			// -- 进行状态显示处理
			String stateName;
			for (OutBoundAlreadyListVO vo:list) {
				stateName = NodeStateConstant.getNodeStateNameOfContractState(vo.getStateCode());
				if (StringUtils.isNotNullAndEmpty(stateName)){
					vo.setContractState(stateName);
				}
			}
		     outBoundAlreadyQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,outBoundAlreadyQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("外访列表查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<OutBoundAlreadyListExportVO> outBoundAlreadysExport(OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO) throws Exception{
        //获取登录用户信息
		User loginUser = SessionUtil.getLoginUser(User.class);
		 
		/**type：A 赋值机构码和外访人员  B赋值机构Id  C如果机构Id为空,赋值机构Id*/
		if("A".equals(outBoundAlreadyQueryDTO.getType())){
			outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
			if(!StringUtils.isNotNullAndEmpty(outBoundAlreadyQueryDTO.getVisitUid())){
				outBoundAlreadyQueryDTO.setVisitUid(loginUser.getId().toString());
			}
		}else if("B".equals(outBoundAlreadyQueryDTO.getType())){
			outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
		}else if("C".equals(outBoundAlreadyQueryDTO.getType())){
			if(outBoundAlreadyQueryDTO.getOrgId() == null){
				 outBoundAlreadyQueryDTO.setOrgId(loginUser.getDataOrgId().toString());
			}
		}

		/**合同状态转换*/
		if(StringUtils.isNotNullAndEmpty(outBoundAlreadyQueryDTO.getContractState())){
			outBoundAlreadyQueryDTO.setList(NodeStateConstant.getNodeStateList(Integer.valueOf(outBoundAlreadyQueryDTO.getContractState())));
		}
	    //获取导出数据
	    List<OutBoundAlreadyListExportVO> list = outBoundAlreadyDao.listOutBoundExport(outBoundAlreadyQueryDTO);
		// -- 进行状态显示处理
		String stateName;
		for (OutBoundAlreadyListExportVO vo:list) {
			stateName = NodeStateConstant.getNodeStateNameOfContractState(vo.getStateCode());
			if (StringUtils.isNotNullAndEmpty(stateName)){
				vo.setContractState(stateName);
			}
			/**导出不显示此字段*/
			vo.setStateCode(null);
		}
        return list;
	}

}
