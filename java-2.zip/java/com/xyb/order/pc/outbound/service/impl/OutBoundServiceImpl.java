package com.xyb.order.pc.outbound.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.utils.DateTimeUtil;
import com.xyb.credit.common.model.DepotTimeDO;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.credit.constant.DictionariesConstant;
import com.xyb.credit.creditreport.model.AuditSingleRecordDO;
import com.xyb.credit.creditreport.service.CreditReportService;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.material.service.FileDataInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.FileNameConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.service.AuditCheckItemService;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.outbound.dao.ApplyVisitCreditFamilyInfoDao;
import com.xyb.order.pc.outbound.dao.ApplyVisitCreditJobInfoDao;
import com.xyb.order.pc.outbound.dao.ApplyVisitCreditManagementInfoDao;
import com.xyb.order.pc.outbound.dao.ApplyVisitMainInfoDao;
import com.xyb.order.pc.outbound.dao.ApplyVisitPropertySurveyDao;
import com.xyb.order.pc.outbound.dao.OutBoundDao;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditFamilyInfoDO;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditFamilyInfoDTO;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditJobInfoDO;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditJobInfoDTO;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditManagermentInfoDO;
import com.xyb.order.pc.outbound.model.ApplyVisitCreditManagermentInfoDTO;
import com.xyb.order.pc.outbound.model.ApplyVisitMainInfoDO;
import com.xyb.order.pc.outbound.model.ApplyVisitPropertySurveyDO;
import com.xyb.order.pc.outbound.model.ApplyVisitPropertySurveyDTO;
import com.xyb.order.pc.outbound.model.OutBoundDeleteDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailCustInfoDO;
import com.xyb.order.pc.outbound.model.OutBoundDetailDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSaveDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitCreditAndPropertySurveyDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitCreditDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailSubmitPropertySurveyDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailVO;
import com.xyb.order.pc.outbound.model.OutBoundListVO;
import com.xyb.order.pc.outbound.model.OutBoundQueryDTO;
import com.xyb.order.pc.outbound.service.OutBoundService;
import com.xyb.util.SessionUtil;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 外访实现
 * @createDate : 2018/05/17 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.outbound.service.OutBoundService")
public class OutBoundServiceImpl implements OutBoundService {

	private static final Logger logger = LoggerFactory.getLogger(OutBoundServiceImpl.class);

	@Autowired
	private OutBoundDao outBoundDao;
	@Autowired
	private ApplyVisitCreditFamilyInfoDao applyVisitCreditFamilyInfoDao;
	@Autowired
	private ApplyVisitCreditJobInfoDao applyVisitCreditJobInfoDao;
	@Autowired
	private ApplyVisitCreditManagementInfoDao applyVisitCreditManagementInfoDao;
	@Autowired
	private ApplyVisitMainInfoDao applyVisitMainInfoDao;
	@Autowired
	private ApplyVisitPropertySurveyDao applyVisitPropertySurveyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Reference
	private CreditCommonService commonService;
	@Autowired
	private FileDataInfoService fileService;
	@Autowired
	private AuditCheckItemService auditCheckItemService;
	@Reference
	private CreditReportService creditReportService;
	/**信审系统审批项值*/
	private Integer item = 15;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listOutBound(Integer pageNumber, Integer pageSize,OutBoundQueryDTO outBoundQueryDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 
			 outBoundQueryDTO.getPage().setPageNumber(pageNumber);
			 outBoundQueryDTO.getPage().setPageSize(pageSize);
			 outBoundQueryDTO.setOrgId(loginUser.getDataOrgId());
		     List<OutBoundListVO> list = outBoundDao.listOutBoundPage(outBoundQueryDTO);
		     for (OutBoundListVO outBoundListVO:list){
		     	outBoundListVO.setLoginId(loginUser.getId());
			 }
		     outBoundQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,outBoundQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("外访列表查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"外访列表查询失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateOutBound(OutBoundDetailDTO outBoundDetailDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();
			 
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", outBoundDetailDTO.getApplyId());
			 ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 
			 map.put("state", applyMaInfo.getPrevious());
			 OutBoundDetailVO outBoundDetailVO = outBoundDao.getOutBoundInfoByApplyId(map);
			 if (outBoundDetailVO == null){
				 outBoundDetailVO = new OutBoundDetailVO();
			 }
			 /**查询外访用户基本信息*/
			 OutBoundDetailCustInfoDO outBoundDetailCustInfoDO = outBoundDao.getInfoByApplyId(outBoundDetailDTO.getApplyId());
			 if (outBoundDetailVO.getEndSubmitTime()!= null) {
				 outBoundDetailCustInfoDO.setEndSubmitTime(outBoundDetailVO.getEndSubmitTime());
			 }
			 if (outBoundDetailVO.getEndRemark()!= null) {
				 outBoundDetailCustInfoDO.setEndRemark(outBoundDetailVO.getEndRemark());
			 }
			 if (outBoundDetailCustInfoDO != null) {
				 outBoundDetailVO.setOutBoundDetailCustInfoDO(outBoundDetailCustInfoDO);
			 }
			 
			 ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailDTO.getApplyId());
			 /**更新外访操作人员*/
			 String oldData = JsonUtil.object2json(applyVisitMainInfoDO);
			 applyVisitMainInfoDO.setVisitUid(userId);
			 applyVisitMainInfoDO.setModifyUser(userId);
			 applyVisitMainInfoDO.setModifyTime(new Date());
			 String newData = JsonUtil.object2json(applyVisitMainInfoDO);
			 /**1.对比是否需要修改,是：修改contract表,添加表修改日志*/
			 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitMainInfoDO.getId(),TableConstant.T_APPLY_VISIT_MAIN_INFO,oldData,newData);
			 if(flag){
				 applyVisitMainInfoDao.updateApplyVisitMainInfoDO(applyVisitMainInfoDO);
			 }
			 /**获取外访实地征信工作信息*/
			 ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDao.getByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditJobInfoDO == null ){
				 applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDao.getCompInfoByApplyId(applyVisitMainInfoDO.getApplyId());
			 }
			 /**获取外访实地征信家庭信息*/
			 List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDOs = applyVisitCreditFamilyInfoDao.listByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditFamilyInfoDOs == null || applyVisitCreditFamilyInfoDOs.size() == 0){
				 applyVisitCreditFamilyInfoDOs = new ArrayList<>();
				 ApplyVisitCreditFamilyInfoDO  applyVisitCreditFamilyInfoDO = applyVisitCreditFamilyInfoDao.getFamilyInfoByApplyId(applyVisitMainInfoDO.getApplyId());
				 if(applyVisitCreditFamilyInfoDO != null){
					 applyVisitCreditFamilyInfoDOs.add(applyVisitCreditFamilyInfoDO);
				 }
			 }

			 /**获取外访实地征信经营信息*/
			 List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs = applyVisitCreditManagementInfoDao.listByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditManagermentInfoDOs == null || applyVisitCreditManagermentInfoDOs.size() == 0){
				 applyVisitCreditManagermentInfoDOs = new ArrayList<>();
				 ApplyVisitCreditManagermentInfoDO applyVisitCreditManagermentInfoDO = applyVisitCreditManagementInfoDao.getManagerInfoByApplyId(applyVisitMainInfoDO.getApplyId());
				 if(applyVisitCreditManagermentInfoDO != null){
					 applyVisitCreditManagermentInfoDOs.add(applyVisitCreditManagermentInfoDO);
				 }
			 }
			 /**获取外访产调信息*/
			 ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO = applyVisitPropertySurveyDao.getByApplyId(outBoundDetailDTO.getApplyId());
			 
			 /**封装返回数据*/
			 if (applyVisitCreditJobInfoDO != null) {
				 outBoundDetailVO.setApplyVisitCreditJobInfoDO(applyVisitCreditJobInfoDO);
			 }
			 if(applyVisitCreditFamilyInfoDOs != null && applyVisitCreditFamilyInfoDOs.size() > 0){
				 outBoundDetailVO.setApplyVisitCreditFamilyInfoDO(applyVisitCreditFamilyInfoDOs);
			 }
			 if(applyVisitCreditManagermentInfoDOs != null && applyVisitCreditManagermentInfoDOs.size() > 0){
				 outBoundDetailVO.setApplyVisitCreditManagermentInfoDOs(applyVisitCreditManagermentInfoDOs);
			 }
			 outBoundDetailVO.setApplyVisitPropertySurveyDO(applyVisitPropertySurveyDO);
			 
		     response = new RestResponse(MsgErrCode.SUCCESS,outBoundDetailVO);
		} catch (Exception e) {
			 logger.error("外访详情查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"外访详情查询失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse saveOutBound(OutBoundDetailSaveDTO outBoundDetailSaveDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();

			 ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailSaveDTO.getApplyId());
			 
			 /**添加或更新外访实地征信工作信息*/
			 ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO = outBoundDetailSaveDTO.getApplyVisitCreditJobInfoDO();
			 if(applyVisitCreditJobInfoDO != null){
				 if(applyVisitCreditJobInfoDO.getId() != null && applyVisitCreditJobInfoDO.getId() > 0){
					 ApplyVisitCreditJobInfoDO  applyVisitCreditJobInfoDOOld = applyVisitCreditJobInfoDao.getByVisitMainId(applyVisitMainInfoDO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditJobInfoDO.getId(),TableConstant.T_APPLY_VISIT_CREDIT_JOB_INFO,JsonUtil.bean2json(applyVisitCreditJobInfoDOOld),JsonUtil.bean2json(applyVisitCreditJobInfoDO));
					 if(flag){
						 applyVisitCreditJobInfoDao.updateApplyVisitCreditJobInfoDO(applyVisitCreditJobInfoDO);
					 }
				 }else{
					 applyVisitCreditJobInfoDO.setCreateTime(new Date());
					 applyVisitCreditJobInfoDO.setCreateUser(userId);
					 applyVisitCreditJobInfoDO.setModifyTime(new Date());
					 applyVisitCreditJobInfoDO.setModifyUser(userId);
					 applyVisitCreditJobInfoDO.setVisitMainId(applyVisitMainInfoDO.getId());
					 applyVisitCreditJobInfoDao.insert(applyVisitCreditJobInfoDO);
				 }
			 }
			 /**添加或更新外访实地征信家庭信息*/
			 List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDOs = outBoundDetailSaveDTO.getApplyVisitCreditFamilyInfoDOs();
			 if(applyVisitCreditFamilyInfoDOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditFamilyInfoDOs.size(); i++) {
					if(applyVisitCreditFamilyInfoDOs.get(i).getId() != null && applyVisitCreditFamilyInfoDOs.get(i).getId() > 0){
						 ApplyVisitCreditFamilyInfoDO  applyVisitCreditFamilyInfoDOOld = applyVisitCreditFamilyInfoDao.getById(applyVisitCreditFamilyInfoDOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditFamilyInfoDOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_FAMILY_INFO,JsonUtil.bean2json(applyVisitCreditFamilyInfoDOOld),JsonUtil.bean2json(applyVisitCreditFamilyInfoDOs.get(i)));
						 if(flag){
							 applyVisitCreditFamilyInfoDao.updateApplyVisitCreditFamilyInfoDO(applyVisitCreditFamilyInfoDOs.get(i));
						 }
					}else{
						 applyVisitCreditFamilyInfoDOs.get(i).setCreateTime(new Date());
						 applyVisitCreditFamilyInfoDOs.get(i).setCreateUser(userId);
						 applyVisitCreditFamilyInfoDOs.get(i).setModifyTime(new Date());
						 applyVisitCreditFamilyInfoDOs.get(i).setModifyUser(userId);
						 applyVisitCreditFamilyInfoDOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						 applyVisitCreditFamilyInfoDao.insert(applyVisitCreditFamilyInfoDOs.get(i));
					}
				 }
			 }
			 /**添加或更新外访实地征信经营信息*/
			 List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs = outBoundDetailSaveDTO.getApplyVisitCreditManagermentInfoDOs();
			 if(applyVisitCreditManagermentInfoDOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditManagermentInfoDOs.size(); i++) {
					if(applyVisitCreditManagermentInfoDOs.get(i).getId() != null && applyVisitCreditManagermentInfoDOs.get(i).getId() > 0){
						ApplyVisitCreditManagermentInfoDO  applyVisitCreditManagermentInfoDOOld = applyVisitCreditManagementInfoDao.getById(applyVisitCreditManagermentInfoDOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditManagermentInfoDOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_MANAGEMENT_INFO,JsonUtil.bean2json(applyVisitCreditManagermentInfoDOOld),JsonUtil.bean2json(applyVisitCreditManagermentInfoDOs.get(i)));
						 if(flag){
								applyVisitCreditManagementInfoDao.updateApplyVisitCreditManagermentInfoDO(applyVisitCreditManagermentInfoDOs.get(i));
						 }
					}else{
						applyVisitCreditManagermentInfoDOs.get(i).setCreateTime(new Date());
						applyVisitCreditManagermentInfoDOs.get(i).setCreateUser(userId);
						applyVisitCreditManagermentInfoDOs.get(i).setModifyTime(new Date());
						applyVisitCreditManagermentInfoDOs.get(i).setModifyUser(userId);
						applyVisitCreditManagermentInfoDOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						applyVisitCreditManagementInfoDao.insert(applyVisitCreditManagermentInfoDOs.get(i));
					}
				 }
			 }
			 /**添加或更新外访产调信息*/
			 ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO = outBoundDetailSaveDTO.getApplyVisitPropertySurveyDO();	
			 if(applyVisitPropertySurveyDO != null){
				 if(applyVisitPropertySurveyDO.getId() != null && applyVisitPropertySurveyDO.getId() > 0){
					 ApplyVisitPropertySurveyDO  applyVisitPropertySurveyDOOld = applyVisitPropertySurveyDao.getById(applyVisitPropertySurveyDO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitPropertySurveyDO.getId(),TableConstant.T_APPLY_VISIT_PROPERTY_SURVEY,JsonUtil.bean2json(applyVisitPropertySurveyDOOld),JsonUtil.bean2json(applyVisitPropertySurveyDO));
					 if(flag){
						 applyVisitPropertySurveyDao.updateApplyVisitPropertySurveyDO(applyVisitPropertySurveyDO);
					 }
				 }else{
					 applyVisitPropertySurveyDO.setApplyId(applyVisitMainInfoDO.getApplyId());
					 applyVisitPropertySurveyDO.setCreateTime(new Date());
					 applyVisitPropertySurveyDO.setCreateUser(userId);
					 applyVisitPropertySurveyDO.setModifyTime(new Date());
					 applyVisitPropertySurveyDO.setModifyUser(userId);
					 applyVisitPropertySurveyDao.insert(applyVisitPropertySurveyDO);
				 }
			 }
			 /**更新外访主表信息*/
			String oldMainInfoData = JsonUtil.bean2json(applyVisitMainInfoDO);
			applyVisitMainInfoDO.setVisitDate(outBoundDetailSaveDTO.getVisitDate());
			applyVisitMainInfoDO.setCustomerIntegratedDescription(outBoundDetailSaveDTO.getCustomerIntegratedDescription());
			boolean flagA = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitMainInfoDO.getId(),TableConstant.T_APPLY_VISIT_MAIN_INFO,oldMainInfoData,JsonUtil.bean2json(applyVisitMainInfoDO));
			if(flagA){
				applyVisitMainInfoDao.updateApplyVisitMainInfoDO(applyVisitMainInfoDO);
			}
		     response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("外访暂存失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"暂存失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitCreditOutBounds(OutBoundDetailSubmitCreditDTO outBoundDetailSubmitCreditDTO) {
		RestResponse response = null;
		try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();

			 
			ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailSubmitCreditDTO.getApplyId());

			/**1.添加或修改表数据*/
			 /**添加或更新外访实地征信工作信息*/
			 ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO = outBoundDetailSubmitCreditDTO.getApplyVisitCreditJobInfoDTO();
			 if(applyVisitCreditJobInfoDTO != null){
				 if(applyVisitCreditJobInfoDTO.getId() != null && applyVisitCreditJobInfoDTO.getId() > 0){
					 ApplyVisitCreditJobInfoDO  applyVisitCreditJobInfoDOOld = applyVisitCreditJobInfoDao.getByVisitMainId(applyVisitMainInfoDO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditJobInfoDTO.getId(),TableConstant.T_APPLY_VISIT_CREDIT_JOB_INFO,JsonUtil.bean2json(applyVisitCreditJobInfoDOOld),JsonUtil.bean2json(applyVisitCreditJobInfoDTO));
					 if(flag){
						 applyVisitCreditJobInfoDao.updateApplyVisitCreditJobInfoDO(applyVisitCreditJobInfoDTO);
					 }
				 }else{
					 applyVisitCreditJobInfoDTO.setVisitMainId(applyVisitMainInfoDO.getId());
					 applyVisitCreditJobInfoDao.insert(applyVisitCreditJobInfoDTO);
				 }
			 }
			 /**添加或更新外访实地征信家庭信息*/
			 List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs = outBoundDetailSubmitCreditDTO.getApplyVisitCreditFamilyInfoDTOs();
			 if(applyVisitCreditFamilyInfoDTOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditFamilyInfoDTOs.size(); i++) {
					if(applyVisitCreditFamilyInfoDTOs.get(i).getId() != null && applyVisitCreditFamilyInfoDTOs.get(i).getId() > 0){
						 ApplyVisitCreditFamilyInfoDO  applyVisitCreditFamilyInfoDOOld = applyVisitCreditFamilyInfoDao.getById(applyVisitCreditFamilyInfoDTOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditFamilyInfoDTOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_FAMILY_INFO,JsonUtil.bean2json(applyVisitCreditFamilyInfoDOOld),JsonUtil.bean2json(applyVisitCreditFamilyInfoDTOs.get(i)));
						 if(flag){
							 applyVisitCreditFamilyInfoDao.updateApplyVisitCreditFamilyInfoDO(applyVisitCreditFamilyInfoDTOs.get(i));
						 }
					}else{
						 applyVisitCreditFamilyInfoDTOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						 applyVisitCreditFamilyInfoDao.insert(applyVisitCreditFamilyInfoDTOs.get(i));
					}
				 }
			 }
			 /**添加或更新外访实地征信经营信息*/
			 List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs = outBoundDetailSubmitCreditDTO.getApplyVisitCreditManagermentInfoDTOs();
			 if(applyVisitCreditManagermentInfoDTOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditManagermentInfoDTOs.size(); i++) {
					if(applyVisitCreditManagermentInfoDTOs.get(i).getId() != null && applyVisitCreditManagermentInfoDTOs.get(i).getId() > 0){
						ApplyVisitCreditManagermentInfoDO  applyVisitCreditManagermentInfoDOOld = applyVisitCreditManagementInfoDao.getById(applyVisitCreditManagermentInfoDTOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditManagermentInfoDTOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_MANAGEMENT_INFO,JsonUtil.bean2json(applyVisitCreditManagermentInfoDOOld),JsonUtil.bean2json(applyVisitCreditManagermentInfoDTOs.get(i)));
						 if(flag){
								applyVisitCreditManagementInfoDao.updateApplyVisitCreditManagermentInfoDO(applyVisitCreditManagermentInfoDTOs.get(i));
						 }
					}else{
						applyVisitCreditManagermentInfoDTOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						applyVisitCreditManagementInfoDao.insert(applyVisitCreditManagermentInfoDTOs.get(i));
					}
				 }
			 }
			 /**更新外访主表信息*/
			String oldMainInfoData = JsonUtil.object2json(applyVisitMainInfoDO);
			applyVisitMainInfoDO.setVisitUid(userId);
			applyVisitMainInfoDO.setVisitState(SysDictEnum.OUT_BOUND_TYPEFOUR.getCode());
			applyVisitMainInfoDO.setVisitDate(outBoundDetailSubmitCreditDTO.getVisitDate());
			applyVisitMainInfoDO.setCustomerIntegratedDescription(outBoundDetailSubmitCreditDTO.getCustomerIntegratedDescription());
			boolean flagA = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitMainInfoDO.getId(),TableConstant.T_APPLY_VISIT_MAIN_INFO,oldMainInfoData,JsonUtil.bean2json(applyVisitMainInfoDO));
			if(flagA){
				applyVisitMainInfoDao.updateApplyVisitMainInfoDO(applyVisitMainInfoDO);
			}
			/**2.更改流程状态为终审中*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", applyVisitMainInfoDO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			Integer provious = applyBillMainInfoDO.getPrevious();
			
			MainLogDTO mainLogDTO = new MainLogDTO();
			mainLogDTO.setBusinessState(applyBillMainInfoDO.getPrevious());
			mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			mainLogDTO.setModifyUser(userId);
			currencyDao.addMainLog(mainLogDTO);
						
			String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
						
			applyBillMainInfoDO.setState(applyBillMainInfoDO.getPrevious());
			applyBillMainInfoDO.setPrevious(NodeStateConstant.OUTSIDE_VISIT);
			applyBillMainInfoDO.setModifyTime(new Date());
			applyBillMainInfoDO.setModifyUser(userId);
			applyBillMainInfoDO.setVisitSubmitAuditTime(new Date());

			String newData = JsonUtil.object2json(applyBillMainInfoDO);
			boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			if(flag){
				/**更新审批时效*/
				updateDepotTime(applyBillMainInfoDO.getApplyId(),provious,userId);
				currencyDao.updateMainInFo(applyBillMainInfoDO);
			}
			 /**3.更新图片信息为不可删除*/
			 fileService.updateFileState(applyBillMainInfoDO.getApplyId(), userId, FileNameConstant.OUTBOUND_IMAGES_TYPE);
			 /**4.更新审核项表信息*/
			 AuditSingleRecordDO auditSingleRecordDO = new AuditSingleRecordDO();
			 auditSingleRecordDO.setApplyId(applyBillMainInfoDO.getApplyId());
			 auditSingleRecordDO.setItem(item);
			 creditReportService.deleteAuditSingleRecord(auditSingleRecordDO);
			 auditCheckItemService.insertCheckItem(applyBillMainInfoDO.getApplyId(), AuditCheckItemConstant.FIELD_LETTER);
			 
		     response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("外访提交失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"提交失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitPropertySurveyOutBounds(OutBoundDetailSubmitPropertySurveyDTO outBoundDetailSubmitPropertySurveyDTO) {
		RestResponse response = null;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();
			
			ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailSubmitPropertySurveyDTO.getApplyId());
			/**1.添加或更新外访产调信息*/
			 ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO = outBoundDetailSubmitPropertySurveyDTO.getApplyVisitPropertySurveyDTO();	
			 if(applyVisitPropertySurveyDTO != null){
				 if(applyVisitPropertySurveyDTO.getId() != null && applyVisitPropertySurveyDTO.getId() > 0){
					 ApplyVisitPropertySurveyDO  applyVisitPropertySurveyDOOld = applyVisitPropertySurveyDao.getById(applyVisitPropertySurveyDTO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitPropertySurveyDTO.getId(),TableConstant.T_APPLY_VISIT_PROPERTY_SURVEY,JsonUtil.bean2json(applyVisitPropertySurveyDOOld),JsonUtil.bean2json(applyVisitPropertySurveyDTO));
					 if(flag){
						 applyVisitPropertySurveyDao.updateApplyVisitPropertySurveyDO(applyVisitPropertySurveyDTO);
					 }
				 }else{
					 applyVisitPropertySurveyDTO.setApplyId(applyVisitMainInfoDO.getApplyId());
					 applyVisitPropertySurveyDao.insert(applyVisitPropertySurveyDTO);
				 }
			 }
			 /**更新外访主表信息*/
			 String oldMainInfoData = JsonUtil.object2json(applyVisitMainInfoDO);
			 applyVisitMainInfoDO.setVisitUid(userId);
			 applyVisitMainInfoDO.setVisitState(SysDictEnum.OUT_BOUND_TYPEFOUR.getCode());
			 applyVisitMainInfoDO.setVisitIndustryDate(applyVisitPropertySurveyDTO.getPropertySurveyDate());
			 applyVisitMainInfoDO.setIndustryDescription(applyVisitPropertySurveyDTO.getRemark());
			 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitMainInfoDO.getId(),TableConstant.T_APPLY_VISIT_MAIN_INFO,oldMainInfoData,JsonUtil.bean2json(applyVisitMainInfoDO));
			 if(flag){
					applyVisitMainInfoDao.updateApplyVisitMainInfoDO(applyVisitMainInfoDO);
			 }
			 /**2.更改流程状态为终审中*/
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", applyVisitMainInfoDO.getApplyId());
			 ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 Integer provious = applyBillMainInfoDO.getPrevious();
			 
			 MainLogDTO mainLogDTO = new MainLogDTO();
			 mainLogDTO.setBusinessState(applyBillMainInfoDO.getPrevious());
			 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			 mainLogDTO.setModifyUser(userId);
			 currencyDao.addMainLog(mainLogDTO);
							
			 String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
							
			 applyBillMainInfoDO.setState(applyBillMainInfoDO.getPrevious());
			 applyBillMainInfoDO.setPrevious(NodeStateConstant.OUTSIDE_VISIT);
			 applyBillMainInfoDO.setModifyTime(new Date());
			 applyBillMainInfoDO.setModifyUser(userId);
			 applyBillMainInfoDO.setVisitSubmitAuditTime(new Date());

			 String newData = JsonUtil.object2json(applyBillMainInfoDO);
			 boolean flagA = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			 if(flagA){
				 /**更新审批时效*/
				 updateDepotTime(applyBillMainInfoDO.getApplyId(),provious,userId);
				 currencyDao.updateMainInFo(applyBillMainInfoDO);
			 }
			 /**3.更新图片信息为不可删除*/
			 fileService.updateFileState(applyBillMainInfoDO.getApplyId(), userId, FileNameConstant.OUTBOUND_IMAGES_TYPE);
			 /**4.更新审核项表信息*/
			 AuditSingleRecordDO auditSingleRecordDO = new AuditSingleRecordDO();
			 auditSingleRecordDO.setApplyId(applyBillMainInfoDO.getApplyId());
			 auditSingleRecordDO.setItem(item);
			 creditReportService.deleteAuditSingleRecord(auditSingleRecordDO);
			 auditCheckItemService.insertCheckItem(applyBillMainInfoDO.getApplyId(), AuditCheckItemConstant.INDUSTRY);
			 
		     response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("外访提交失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"提交失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitCreditAndPropertySurveyOutBounds(OutBoundDetailSubmitCreditAndPropertySurveyDTO outBoundDetailSubmitCreditAndPropertySurveyDTO) {
		RestResponse response = null;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();
			
			
			ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailSubmitCreditAndPropertySurveyDTO.getApplyId());

			/**1.添加或修改表数据*/
			 /**添加或更新外访实地征信工作信息*/
			 ApplyVisitCreditJobInfoDTO applyVisitCreditJobInfoDTO = outBoundDetailSubmitCreditAndPropertySurveyDTO.getApplyVisitCreditJobInfoDTO();
			 if(applyVisitCreditJobInfoDTO != null){
				 if(applyVisitCreditJobInfoDTO.getId() != null && applyVisitCreditJobInfoDTO.getId() > 0){
					 ApplyVisitCreditJobInfoDO  applyVisitCreditJobInfoDOOld = applyVisitCreditJobInfoDao.getByVisitMainId(applyVisitMainInfoDO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditJobInfoDTO.getId(),TableConstant.T_APPLY_VISIT_CREDIT_JOB_INFO,JsonUtil.bean2json(applyVisitCreditJobInfoDOOld),JsonUtil.bean2json(applyVisitCreditJobInfoDTO));
					 if(flag){
						 applyVisitCreditJobInfoDao.updateApplyVisitCreditJobInfoDO(applyVisitCreditJobInfoDTO);
					 }
				 }else{
					 applyVisitCreditJobInfoDTO.setVisitMainId(applyVisitMainInfoDO.getId());
					 applyVisitCreditJobInfoDao.insert(applyVisitCreditJobInfoDTO);
				 }
			 }
			 /**添加或更新外访实地征信家庭信息*/
			 List<ApplyVisitCreditFamilyInfoDTO> applyVisitCreditFamilyInfoDTOs = outBoundDetailSubmitCreditAndPropertySurveyDTO.getApplyVisitCreditFamilyInfoDTOs();
			 if(applyVisitCreditFamilyInfoDTOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditFamilyInfoDTOs.size(); i++) {
					if(applyVisitCreditFamilyInfoDTOs.get(i).getId() != null && applyVisitCreditFamilyInfoDTOs.get(i).getId() > 0){
						 ApplyVisitCreditFamilyInfoDO  applyVisitCreditFamilyInfoDOOld = applyVisitCreditFamilyInfoDao.getById(applyVisitCreditFamilyInfoDTOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditFamilyInfoDTOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_FAMILY_INFO,JsonUtil.bean2json(applyVisitCreditFamilyInfoDOOld),JsonUtil.bean2json(applyVisitCreditFamilyInfoDTOs.get(i)));
						 if(flag){
							 applyVisitCreditFamilyInfoDao.updateApplyVisitCreditFamilyInfoDO(applyVisitCreditFamilyInfoDTOs.get(i));
						 }
					}else{
						 applyVisitCreditFamilyInfoDTOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						 applyVisitCreditFamilyInfoDao.insert(applyVisitCreditFamilyInfoDTOs.get(i));
					}
				 }
			 }
			 /**添加或更新外访实地征信经营信息*/
			 List<ApplyVisitCreditManagermentInfoDTO> applyVisitCreditManagermentInfoDTOs = outBoundDetailSubmitCreditAndPropertySurveyDTO.getApplyVisitCreditManagermentInfoDTOs();
			 if(applyVisitCreditManagermentInfoDTOs != null){
				 /**每条进行判断添加或更新*/
				 for (int i = 0; i < applyVisitCreditManagermentInfoDTOs.size(); i++) {
					if(applyVisitCreditManagermentInfoDTOs.get(i).getId() != null && applyVisitCreditManagermentInfoDTOs.get(i).getId() > 0){
						ApplyVisitCreditManagermentInfoDO  applyVisitCreditManagermentInfoDOOld = applyVisitCreditManagementInfoDao.getById(applyVisitCreditManagermentInfoDTOs.get(i).getId());
						 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
						 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitCreditManagermentInfoDTOs.get(i).getId(),TableConstant.T_APPLY_VISIT_CREDIT_MANAGEMENT_INFO,JsonUtil.bean2json(applyVisitCreditManagermentInfoDOOld),JsonUtil.bean2json(applyVisitCreditManagermentInfoDTOs.get(i)));
						 if(flag){
								applyVisitCreditManagementInfoDao.updateApplyVisitCreditManagermentInfoDO(applyVisitCreditManagermentInfoDTOs.get(i));
						 }
					}else{
						applyVisitCreditManagermentInfoDTOs.get(i).setVisitMainId(applyVisitMainInfoDO.getId());
						applyVisitCreditManagementInfoDao.insert(applyVisitCreditManagermentInfoDTOs.get(i));
					}
				 }
			 }
			 /**添加或更新外访产调信息*/
			 ApplyVisitPropertySurveyDTO applyVisitPropertySurveyDTO = outBoundDetailSubmitCreditAndPropertySurveyDTO.getApplyVisitPropertySurveyDTO();	
			 if(applyVisitPropertySurveyDTO != null){
				 if(applyVisitPropertySurveyDTO.getId() != null && applyVisitPropertySurveyDTO.getId() > 0){
					 ApplyVisitPropertySurveyDO  applyVisitPropertySurveyDOOld = applyVisitPropertySurveyDao.getById(applyVisitPropertySurveyDTO.getId());
					 /**1.对比是否需要修改,是：修改表,添加表修改日志*/
					 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitPropertySurveyDTO.getId(),TableConstant.T_APPLY_VISIT_PROPERTY_SURVEY,JsonUtil.bean2json(applyVisitPropertySurveyDOOld),JsonUtil.bean2json(applyVisitPropertySurveyDTO));
					 if(flag){
						 applyVisitPropertySurveyDao.updateApplyVisitPropertySurveyDO(applyVisitPropertySurveyDTO);
					 }
				 }else{
					 applyVisitPropertySurveyDTO.setApplyId(applyVisitMainInfoDO.getApplyId());
					 applyVisitPropertySurveyDao.insert(applyVisitPropertySurveyDTO);
				 }
			 }
			 /**更新外访主表信息*/
			 String oldMainInfoData = JsonUtil.object2json(applyVisitMainInfoDO);
			 applyVisitMainInfoDO.setVisitUid(userId);
			 applyVisitMainInfoDO.setVisitState(SysDictEnum.OUT_BOUND_TYPEFOUR.getCode());
			 applyVisitMainInfoDO.setVisitDate(outBoundDetailSubmitCreditAndPropertySurveyDTO.getVisitDate());
			 applyVisitMainInfoDO.setCustomerIntegratedDescription(outBoundDetailSubmitCreditAndPropertySurveyDTO.getCustomerIntegratedDescription());
			 
			 applyVisitMainInfoDO.setVisitIndustryDate(applyVisitPropertySurveyDTO.getPropertySurveyDate());
			 applyVisitMainInfoDO.setIndustryDescription(applyVisitPropertySurveyDTO.getRemark());
			 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyVisitMainInfoDO.getId(),TableConstant.T_APPLY_VISIT_MAIN_INFO,oldMainInfoData,JsonUtil.bean2json(applyVisitMainInfoDO));
			 if(flag){
					applyVisitMainInfoDao.updateApplyVisitMainInfoDO(applyVisitMainInfoDO);
			 }
			 /**2.更改流程状态为终审中*/
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", applyVisitMainInfoDO.getApplyId());
			 ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 Integer provious = applyBillMainInfoDO.getPrevious();
			 
			 MainLogDTO mainLogDTO = new MainLogDTO();
			 mainLogDTO.setBusinessState(applyBillMainInfoDO.getPrevious());
			 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			 mainLogDTO.setModifyUser(userId);
			 currencyDao.addMainLog(mainLogDTO);
							
			 String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
							
			 applyBillMainInfoDO.setState(applyBillMainInfoDO.getPrevious());
			 applyBillMainInfoDO.setPrevious(NodeStateConstant.OUTSIDE_VISIT);
			 applyBillMainInfoDO.setModifyTime(new Date());
			 applyBillMainInfoDO.setModifyUser(userId);
			 applyBillMainInfoDO.setVisitSubmitAuditTime(new Date());

			 String newData = JsonUtil.object2json(applyBillMainInfoDO);
			 boolean flagA = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			 if(flagA){
				 /**更新审批时效*/
				 updateDepotTime(applyBillMainInfoDO.getApplyId(),provious,userId);
				 currencyDao.updateMainInFo(applyBillMainInfoDO);
			 }
			 /**3.更新图片信息为不可删除*/
			 fileService.updateFileState(applyBillMainInfoDO.getApplyId(), userId, FileNameConstant.OUTBOUND_IMAGES_TYPE);
			 
			 /**4.更新审核项表信息*/
			 AuditSingleRecordDO auditSingleRecordDO = new AuditSingleRecordDO();
			 auditSingleRecordDO.setApplyId(applyBillMainInfoDO.getApplyId());
			 auditSingleRecordDO.setItem(item);
			 creditReportService.deleteAuditSingleRecord(auditSingleRecordDO);
			 auditCheckItemService.insertCheckItem(applyBillMainInfoDO.getApplyId(), AuditCheckItemConstant.FIELD_LETTER_AND_INDUSTRY);
		     response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("外访提交失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"提交失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse deleteOutbound(OutBoundDeleteDTO outBoundDeleteDTO) {
		RestResponse response = null;
		try {
			 /**A：外访家庭信息删除，B：外访经营信息删除*/
			 outBoundDao.updateApplyVisitCreditFamilyOrManagermentInfo(outBoundDeleteDTO);
		     response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("外访刪除失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"刪除失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}
	
	private void updateDepotTime(Long applyId,Integer previous,Long userId){
		DepotTimeDO timeDO = new DepotTimeDO();
		Date startTime = DateTimeUtil.getNow();
		timeDO.setBeginTimeOne(startTime);
		timeDO.setBeginTimeTwo(startTime);
		timeDO.setBeginTimeThree(startTime);
		timeDO.setCreateUser(userId);
		timeDO.setApplyId(applyId);
		if(NodeStateConstant.AUDIT.equals(previous)){
			/**上一节点高级审核更新初审审批时效*/
			timeDO.setAuditType(DictionariesConstant.AUDIT_STATE_2669);
		}else if(NodeStateConstant.IN_THE_FINAL_TRIAL.equals(previous)){
			/**上一节点终审更新终审审批时效*/
			timeDO.setAuditType(DictionariesConstant.AUDIT_STATE_2670);
		}
		commonService.updateDepotTime(timeDO);
	}

	@Override
	public RestResponse getOutBoundDetail(OutBoundDetailDTO outBoundDetailDTO) {
		 RestResponse response ;
		 try {
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", outBoundDetailDTO.getApplyId());
			 ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 
			 map.put("state", applyMaInfo.getPrevious());
			 OutBoundDetailVO outBoundDetailVO = outBoundDao.getOutBoundInfoByApplyId(map);
			 if (outBoundDetailVO == null){
				 outBoundDetailVO = new OutBoundDetailVO();
			 }
			 /**查询外访用户基本信息*/
			 OutBoundDetailCustInfoDO outBoundDetailCustInfoDO = outBoundDao.getInfoByApplyId(outBoundDetailDTO.getApplyId());
			 if (outBoundDetailVO.getEndSubmitTime()!= null) {
				 outBoundDetailCustInfoDO.setEndSubmitTime(outBoundDetailVO.getEndSubmitTime());
			 }
			 if (outBoundDetailVO.getEndRemark()!= null) {
				 outBoundDetailCustInfoDO.setEndRemark(outBoundDetailVO.getEndRemark());
			 }

			 if(outBoundDetailCustInfoDO != null){
				 outBoundDetailVO.setOutBoundDetailCustInfoDO(outBoundDetailCustInfoDO);
			 }
			 
			 ApplyVisitMainInfoDO applyVisitMainInfoDO = applyVisitMainInfoDao.getByApplyId(outBoundDetailDTO.getApplyId());

			 /**获取外访实地征信工作信息*/
			 ApplyVisitCreditJobInfoDO applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDao.getByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditJobInfoDO == null ){
				 applyVisitCreditJobInfoDO = applyVisitCreditJobInfoDao.getCompInfoByApplyId(applyVisitMainInfoDO.getApplyId());
			 }
			 /**获取外访实地征信家庭信息*/
			 List<ApplyVisitCreditFamilyInfoDO> applyVisitCreditFamilyInfoDOs = applyVisitCreditFamilyInfoDao.listByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditFamilyInfoDOs == null || applyVisitCreditFamilyInfoDOs.size() == 0){
				 applyVisitCreditFamilyInfoDOs = new ArrayList<>();
				 ApplyVisitCreditFamilyInfoDO  applyVisitCreditFamilyInfoDO = applyVisitCreditFamilyInfoDao.getFamilyInfoByApplyId(applyVisitMainInfoDO.getApplyId());
				 if(applyVisitCreditFamilyInfoDO != null){
					 applyVisitCreditFamilyInfoDOs.add(applyVisitCreditFamilyInfoDO);
				 }
			 }

			 /**获取外访实地征信经营信息*/
			 List<ApplyVisitCreditManagermentInfoDO> applyVisitCreditManagermentInfoDOs = applyVisitCreditManagementInfoDao.listByVisitMainId(applyVisitMainInfoDO.getId());
			 if(applyVisitCreditManagermentInfoDOs == null || applyVisitCreditManagermentInfoDOs.size() == 0){
				 applyVisitCreditManagermentInfoDOs = new ArrayList<>();
				 ApplyVisitCreditManagermentInfoDO applyVisitCreditManagermentInfoDO = applyVisitCreditManagementInfoDao.getManagerInfoByApplyId(applyVisitMainInfoDO.getApplyId());
				 if(applyVisitCreditManagermentInfoDO != null){
					 applyVisitCreditManagermentInfoDOs.add(applyVisitCreditManagermentInfoDO);
				 }
			 }
			 /**获取外访产调信息*/
			 ApplyVisitPropertySurveyDO applyVisitPropertySurveyDO = applyVisitPropertySurveyDao.getByApplyId(outBoundDetailDTO.getApplyId());
			 
			 /**封装返回数据*/
			 if (applyVisitCreditJobInfoDO != null) {
				 outBoundDetailVO.setApplyVisitCreditJobInfoDO(applyVisitCreditJobInfoDO);
			 }
			 if(applyVisitCreditFamilyInfoDOs != null && applyVisitCreditFamilyInfoDOs.size() > 0){
				 outBoundDetailVO.setApplyVisitCreditFamilyInfoDO(applyVisitCreditFamilyInfoDOs);
			 }
			 if(applyVisitCreditManagermentInfoDOs != null && applyVisitCreditManagermentInfoDOs.size() > 0){
				 outBoundDetailVO.setApplyVisitCreditManagermentInfoDOs(applyVisitCreditManagermentInfoDOs);
			 }
			 outBoundDetailVO.setApplyVisitPropertySurveyDO(applyVisitPropertySurveyDO);
			 
		     response = new RestResponse(MsgErrCode.SUCCESS,outBoundDetailVO);
		} catch (Exception e) {
			 logger.error("外访详情查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"详情查询失败");
		}
		return response;
	}

}
