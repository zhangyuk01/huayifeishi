package com.xyb.order.pc.outbound.dao;

import com.xyb.order.pc.outbound.model.ApplyVisitPropertySurveyDO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访产调表 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyVisitPropertySurveyDao {
	
	void insert(Object object);
	
	ApplyVisitPropertySurveyDO getById(long id);
	
    ApplyVisitPropertySurveyDO getByApplyId(long applyId);
    
    void updateApplyVisitPropertySurveyDO(Object object);
}
