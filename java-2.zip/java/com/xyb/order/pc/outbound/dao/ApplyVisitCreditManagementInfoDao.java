package com.xyb.order.pc.outbound.dao;

import java.util.List;

import com.xyb.order.pc.outbound.model.ApplyVisitCreditManagermentInfoDO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访经营信息 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyVisitCreditManagementInfoDao {
	
    int insert(Object object);
    
    ApplyVisitCreditManagermentInfoDO getById(long id);
    
    ApplyVisitCreditManagermentInfoDO getManagerInfoByApplyId(long applyId);
    
    List<ApplyVisitCreditManagermentInfoDO> listByVisitMainId(long visitMainId);
    
    void updateApplyVisitCreditManagermentInfoDO(Object object);
}
