package com.xyb.order.pc.outbound.dao;

import com.xyb.order.pc.outbound.model.ApplyVisitCreditJobInfoDO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访工作信息 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyVisitCreditJobInfoDao {
	
    int insert(Object object);
    
    ApplyVisitCreditJobInfoDO getCompInfoByApplyId(long applyId);
    
    ApplyVisitCreditJobInfoDO getByVisitMainId(long visitMainId);
    
    void updateApplyVisitCreditJobInfoDO(Object object);

}
