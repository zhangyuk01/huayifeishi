package com.xyb.order.pc.outbound.dao;

import java.util.List;

import com.xyb.order.pc.outbound.model.ApplyVisitCreditFamilyInfoDO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访家庭信息 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyVisitCreditFamilyInfoDao {
	
    int insert(Object object);
    
    ApplyVisitCreditFamilyInfoDO getById(long id);
    
    ApplyVisitCreditFamilyInfoDO getFamilyInfoByApplyId(long applyId);
    
    List<ApplyVisitCreditFamilyInfoDO>  listByVisitMainId(long visitMainId);
    
    void updateApplyVisitCreditFamilyInfoDO(Object object);
}
