package com.xyb.order.pc.outbound.dao;

import java.util.List;

import com.xyb.order.pc.outbound.model.OutBoundAlreadyListExportVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyListVO;
import com.xyb.order.pc.outbound.model.OutBoundAlreadyQueryDTO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访已办 dao
 * @createDate : 2018/5/17 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface OutBoundAlreadyDao {
	
	List<OutBoundAlreadyListVO> listOutBoundPage(OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO);
	
	List<OutBoundAlreadyListExportVO> listOutBoundExport(OutBoundAlreadyQueryDTO outBoundAlreadyQueryDTO);
}
