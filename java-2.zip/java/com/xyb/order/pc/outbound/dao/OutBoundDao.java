package com.xyb.order.pc.outbound.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.pc.outbound.model.OutBoundDeleteDTO;
import com.xyb.order.pc.outbound.model.OutBoundDetailCustInfoDO;
import com.xyb.order.pc.outbound.model.OutBoundDetailVO;
import com.xyb.order.pc.outbound.model.OutBoundListVO;
import com.xyb.order.pc.outbound.model.OutBoundQueryDTO;
/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface OutBoundDao {
	
	List<OutBoundListVO> listOutBoundPage(OutBoundQueryDTO outBoundQueryDTO);
	
	OutBoundDetailCustInfoDO getInfoByApplyId(Long applyId);
	
	OutBoundDetailVO getOutBoundInfoByApplyId(Map<String, Object> map);
	
	void updateApplyVisitCreditFamilyOrManagermentInfo(OutBoundDeleteDTO outBoundDeleteDTO);
	
}
