package com.xyb.order.pc.outbound.dao;

import com.xyb.order.pc.outbound.model.ApplyVisitMainInfoDO;

/**
 * @author : houlvshuang
 * @projectName : order-api
 * @package : com.xyb.order.pc.outbound.dao
 * @description : 外访主表 dao
 * @createDate : 2018/5/15 11:30
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface ApplyVisitMainInfoDao {
	
    ApplyVisitMainInfoDO getByApplyId(long applyId);
    
	void updateApplyVisitMainInfoDO(ApplyVisitMainInfoDO applyVisitMainInfoDO);

}
