package com.xyb.order.pc.shanghaicredit.dao;

import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditFileInfoDO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditInFoVO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditInformationVO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditUploadInfoDO;

import java.util.List;
import java.util.Map;

/**
 * 上海资信所需sql
 * @author         xieqingyang
 * @date           2018/9/18 下午3:31
*/
public interface ShanghaiCreditDao {
    /*--------------------------------------数据相关接口--------------------------------------*/

    /**
     * 查询上海资信推送数据
     * @author      xieqingyang
     * @date        2018/9/20 上午10:37
     * @version     1.0
     * @param paraMap 传入参数
     * @return 返回查询数据
     */
    List<ShanghaiCreditInFoVO> queryShanghaiCreditInFo(Map<String,Object> paraMap);

    /**
     * 查询标识符是否使用
     * @param paraMap 查询参数
     * @return 返回使用次数
     */
    int querySgincount(Map<String,Object> paraMap);

    /**
     * 查询页面展示数据
     * @author      xieqingyang
     * @date        2018/9/25 下午3:58
     * @version     1.0
     * @return 页面展示数据
     */
    ShanghaiCreditInformationVO getShanghaiCreditInformationVO();

    /*--------------------------------------日志相关接口--------------------------------------*/
    /**
     * 查询上传文件信息
     * @author      xieqingyang
     * @date        2018/9/18 下午5:38
     * @version     1.0
     * @param paraMap 查询条件
     * @return 返回上传文件信息列表
     */
    List<ShanghaiCreditUploadInfoDO> queryShanghaiCreditUploadInfo(Map<String,Object> paraMap);

    /**
     * 插入上传文件信息
     * @author      xieqingyang
     * @date        2018/9/18 下午5:46
     * @version     1.0
     * @param shanghaiCreditUploadInfoDO 待插入数据
     * @return 返回执行结果
     */
    int insertShanghaiCreditUploadInfo(ShanghaiCreditUploadInfoDO shanghaiCreditUploadInfoDO);

    /**
     * 查询上传结果信息
     * @author      xieqingyang
     * @date        2018/9/18 下午5:48
     * @version     1.0
     * @param shanghaiCreditFileInfoDO 查询条件
     * @return 返回查询信息
     */
    ShanghaiCreditFileInfoDO getShanghaiCreditFileInfo(ShanghaiCreditFileInfoDO shanghaiCreditFileInfoDO);

    /**
     * 插入上传结果信息
     * @author      xieqingyang
     * @date        2018/9/18 下午5:49
     * @version     1.0
     * @param shanghaiCreditFileInfoDO 待插入数据
     * @return 返回执行结果
     */
    int insertShanghaiCreditFileInfo(ShanghaiCreditFileInfoDO shanghaiCreditFileInfoDO);

    /**
     * 修改上传结果信息
     * @author      xieqingyang
     * @date        2018/9/18 下午5:52
     * @version     1.0
     * @param shanghaiCreditFileInfoDO 待修改信息
     * @return 返回执行结果
     */
    int updateShanghaiCreditFileInfo(ShanghaiCreditFileInfoDO shanghaiCreditFileInfoDO);
}
