package com.xyb.order.pc.shanghaicredit.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.StringUtils;
import com.xyb.auth.user.model.User;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.DateUtils;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.pc.shanghaicredit.dao.ShanghaiCreditDao;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditFileInfoDO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditInFoVO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditInformationVO;
import com.xyb.order.pc.shanghaicredit.model.ShanghaiCreditUploadInfoDO;
import com.xyb.order.pc.shanghaicredit.service.ShanghaiCreditService;
import com.xyb.order.pc.shanghaicredit.util.MySecureProtocolSocketFactory;
import com.xyb.service.FastFileStorageService;
import com.xyb.util.SessionUtil;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 上海资信相关功能
 * @author         xieqingyang
 * @date           2018/9/18 下午3:31
*/
@Service(interfaceName = "com.xyb.order.pc.shanghaicredit.service.ShanghaiCreditService")
public class ShanghaiCreditServiceImpl implements ShanghaiCreditService {

    private static final Logger log = LoggerFactory.getLogger(ShanghaiCreditServiceImpl.class);

    @Autowired
    private ShanghaiCreditDao shanghaiCreditDao;
    @Autowired
    private FastFileStorageService fastFileStorageService;

    /**上海资信临时文件存储位置*/
    @Value("${shzx.file}")
    private String shzxFilePath;

    /**上海资信vpn地址*/
    @Value("${shzx.login.url}")
    private String shzxLoginUrl;

    /**上海资信登录地址*/
    @Value("${shzx.index.url}")
    private String shzxIndexUrl;

    /**上海资信vpn登录名*/
    @Value("${shzx.login.user}")
    private String shzxLoginUser;

    /**上海资信vpn登录密码*/
    @Value("${shzx.login.password}")
    private String shzxLoginPassword;

    /**上海资信vpn登录密码*/
    @Value("${shzx.queryCredit.orgcode}")
    private String shzxQueryCreditOrgcode;

    /**上海资信查询接口操作密码*/
    @Value("${shzx.queryCredit.secret}")
    private String shzxQueryCreditSecret;

    /**上海资信查询接口地址*/
    @Value("${shzx.queryCredit.url}")
    private String shzxQueryCreditUrl;

    /**上海资信文件上传接口操作密码*/
    @Value("${shzx.msgSubmit.secret}")
    private String shzxMsgSubmitSecret;

    /**上海资信文件上传接口地址*/
    @Value("${shzx.msgSubmit.url}")
    private String shzxMsgSubmitUrl;

    /**上海资信文件上传接口地址*/
    @Value("${shzx.ready.url}")
    private String shzxReadyUrl;

    @Override
    public RestResponse automaticUpload()throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //上月1号
        Calendar now = Calendar.getInstance();
        now.add(Calendar.MONTH, -1);
        now.set(Calendar.DAY_OF_MONTH, 1);
        String datePreStr = sdf.format(now.getTime());
        //上月末
        Calendar now1 = Calendar.getInstance();
        now1.set(Calendar.DAY_OF_MONTH, 0);
        String dateNowStr = sdf.format(now1.getTime());

        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("beginDate",datePreStr);
        paraMap.put("endDate",dateNowStr);
        // -- 获取上传到上海资信的数据
        List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS = shanghaiCreditDao.queryShanghaiCreditInFo(paraMap);

        // -- 创建excel对象
        HSSFWorkbook excelDoc = new HSSFWorkbook();
        // 身份信息
        String[] personalHead = { "P2P机构代码", "姓名", "证件类型", "证件号码", "性别", "出生日期", "婚姻状况", "最高学历", "最高学位", "住宅电话", "手机号码", "单位电话", "电子邮箱", "通讯地址", "通讯地址邮政编码", "户籍地址", "配偶姓名", "配偶证件类型", "配偶证件号码", "配偶工作单位", "配偶联系电话", "第一联系人姓名", "第一联系人关系", "第一关系人联系电话", "第二联系人姓名", "第二联系人关系", "第二关系人联系电话" };
        Object[][] personalValues = getExcelPersonalValues(shanghaiCreditInFoVOS);
        excelDoc = this.addSheet("身份信息", excelDoc, personalHead, personalValues);

        // 职业信息
        String[] jobHead = { "P2P机构代码", "姓名", "证件类型", "证件号码", "职业", "单位名称", "单位所属行业", "单位地址", "单位地址邮政编码", "本单位工作起始年份", "职务", "职称", "年收入" };
        Object[][] jobValues = this.getExcelJobValues(shanghaiCreditInFoVOS);
        excelDoc = this.addSheet("职业信息", excelDoc, jobHead, jobValues);


        // 居住信息
        String[] liveHead = { "P2P机构代码", "姓名", "证件类型", "证件号码", "居住地址", "居住地址邮政编码", "居住状况" };
        Object[][] liveValues = this.getExcelLiveValues(shanghaiCreditInFoVOS);
        excelDoc = this.addSheet("居住信息", excelDoc, liveHead, liveValues);

        // 贷款申请信息
        String[] loanApplyHead = { "P2P机构代码", "贷款申请号", "姓名", "证件类型", "证件号码", "贷款申请类型", "贷款申请金额", "贷款申请月数", "贷款申请时间", "贷款申请状态" };
        excelDoc = this.addSheet("贷款申请", excelDoc, loanApplyHead, new Object[0][0]);

        // 贷款业务信息
        String[] loanBusinessHead = { "P2P机构代码", "贷款类型", "贷款合同号码", "业务号", "发生地点", "开户日期", "到期日期", "币种", "授信额度", "共享授信额度", "最大负债额", "担保方式", "还款频率", "还款月数", "剩余还款月数", "协定还款期数", "协定期还款额", "结算/应还款日期", "最近一次实际还款日期", "本月应还款金额", "本月实际还款金额", "余额", "当前逾期期数", "当前逾期总额", "逾期31-60天未归还贷款本金", "逾期61-90天未归还贷款本金", "逾期91-180天未归还贷款本金", "逾期180天以上未归还贷款本金", "累计逾期期数", "最高逾期期数", "五级分类状态", "账户状态", "24月（账户）还款状态", "账户拥有者信息提示", "姓名", "证件类型", "证件号码" };
        Object[][] loanBusinessValues = this.getExcelLoanBusinessValues(shanghaiCreditInFoVOS);
        excelDoc = this.addSheet("贷款业务信息", excelDoc, loanBusinessHead, loanBusinessValues);

        // 贷款合同信息
        String[] loanContractHead = { "P2P机构代码", "贷款合同号码", "贷款合同生效日期", "贷款合同终止日期", "币种", "贷款合同金额", "合同有效状态" };
//        Object[][] loanContractValues = this.getExcelLoanContractValues(shanghaiCreditInFoVOS);
//        excelDoc = this.addSheet("贷款合同信息", excelDoc, loanContractHead, loanContractValues);
        excelDoc = this.addSheet("贷款合同信息", excelDoc, loanContractHead, new Object[0][0]);

        // 担保信息
        String[] guaranteeHead = { "P2P机构代码", "业务号", "担保人姓名", "担保人证件类型", "担保人证件号码", "担保金额", "担保状态" };
        excelDoc = this.addSheet("担保信息", excelDoc, guaranteeHead, new Object[0][0]);
        // 投资人信息
        String[] investorHead = { "P2P机构代码", "业务号", "投资人姓名", "投资人证件类型", "投资人证件号码", "投资人投资金额" };
        excelDoc = this.addSheet("投资人信息", excelDoc, investorHead, new Object[0][0]);
        // 特殊交易信息
        String[] specialHead = { "P2P机构代码", "姓名", "证件类型", "证件号码", "业务号", "特殊交易类型", "发生日期", "变更月数", "发生金额", "明细信息" };
        excelDoc = this.addSheet("特殊交易信息", excelDoc, specialHead, new Object[0][0]);
        //本地生成excel文档 以及 zip文件
        Map<String, Object> map = createExcelZip(excelDoc,shzxFilePath);
        String zipPath = (String) map.get("zipPath");
        String fileName = (String) map.get("fileName");
        String signCode = (String)map.get("signCode");
        String xlsPath = (String)map.get("xlsPath");
        // -- 上传文件到上海资信
        return callUploadInterface(null,zipPath,fileName,signCode,user.getId(),xlsPath);
    }

    @Override
    public RestResponse manuallyUpload(String filePath,String fileName) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        // -- 根据网络文件地址创建URL
        URL url = new URL(filePath);
        // 获取此路径的连接
        URLConnection conn = url.openConnection();
        // -- 构造读取流
        InputStream is = conn.getInputStream();
        // -- 创建临时文件路径
        File rootPathFile = new File(shzxFilePath);
        if (!rootPathFile.exists()) {
            // -- 不存在该路径则自动生成
            rootPathFile.mkdirs();
        }
        // -- 获取文件唯一标识码
        String signCode = fileName.substring(fileName.length()-4,fileName.length()-1);
        String xlsPath = shzxFilePath + "/" + fileName;
        // -- 手动选择的excel保存到本地
        saveFileFromInputStream(is,shzxFilePath,fileName);
        // -- 去除后缀的文件名称
        String fileNameDe = fileName.substring(0,fileName.lastIndexOf("."));
        String zipPath = shzxFilePath + "/" + fileNameDe + ".zip";
        // -- 生成zip 加密文件
        addFilesWithAESEncryption(xlsPath, zipPath);
        // -- 删除本地文件
        File file = new File(shzxFilePath + "/" + fileName);
        file.delete();
        return callUploadInterface(filePath,zipPath,fileNameDe,signCode,user.getId(),null);
    }

    @Override
    public RestResponse readyUpload() throws Exception {
        ShanghaiCreditInformationVO informationVO = shanghaiCreditDao.getShanghaiCreditInformationVO();
        if (informationVO == null){
            informationVO = new ShanghaiCreditInformationVO();
        }else {
            if (informationVO.getUploadDate() != null) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                informationVO.setUploadTime(simpleDateFormat.format(informationVO.getUploadDate()));
            }
            if (StringUtils.isNotNullAndEmpty(informationVO.getFileName())) {
                informationVO.setFileName(informationVO.getFileName() + ".xls");
                if (StringUtils.isNotNullAndEmpty(informationVO.getFilePath())) {
                    informationVO.setFilePath(informationVO.getFilePath() + "?filename=" + informationVO.getFileName());
                }
            }
            if (informationVO.getState() != null) {
                switch (informationVO.getState()) {
                    case "1":
                        informationVO.setState("等待加载");
                        break;
                    case "2":
                        informationVO.setState("正在加载");
                        break;
                    case "3":
                        informationVO.setState("加载完成");
                        break;
                    default:
                        informationVO.setState("");
                }
            } else {
                if (informationVO.getErrors() != null) {
                    informationVO.setState(informationVO.getErrors());
                }
            }
            if (StringUtils.isNotNullAndEmpty(informationVO.getFeedbackFile()) && !"/download/?url=null".equals(informationVO.getFeedbackFile())) {
                informationVO.setFeedbackInfo("下载");
            } else {
                informationVO.setFeedbackInfo("暂无");
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS,informationVO);
    }

    @Override
    public RestResponse queryFileState(Long id) throws Exception {
        if (id == null){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",id);
        List<ShanghaiCreditUploadInfoDO> infoDOS = shanghaiCreditDao.queryShanghaiCreditUploadInfo(paraMap);
        if (infoDOS == null || infoDOS.size() <= 0){
            return new RestResponse(NativeMsgErrCode.ERROR);
        }else {
            return callQueryFileInterface(id,infoDOS.get(0).getFileName(),user.getId());
        }
    }

    /**
     * 调用上海资信查询状态接口
     * @author      xieqingyang
     * @date        2018/9/25 下午4:41
     * @version     1.0
     * @param uploadId 上传模版ID
     * @param fileName 文件名称
     * @param loginId 登录人
     * @return 查询结果
     * @throws Exception 所有异常
     */
    private RestResponse callQueryFileInterface(Long uploadId,String fileName,Long loginId) throws Exception {
        PostMethod fileQueryMethod;
        int submitReturnCode;
        JSONObject json;
        HttpClient httpClient = this.readyCallInterface();
        fileQueryMethod = new PostMethod(shzxMsgSubmitUrl);
        int callTime = 0;
        do {
            fileQueryMethod.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            String queryMsgFileRequest = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.datasubmit.p2p.sino.com/\">"
                    + "<soapenv:Header/>"
                    + "<soapenv:Body>"
                    + "<web:queryMessageFile>"
                    + "<orgcode>" + shzxQueryCreditOrgcode + "</orgcode>"
                    + "<secret>" + shzxQueryCreditSecret + "</secret>"
                    + "<filename>" + fileName + ".zip" + "</filename>" // 文件名
                    + "</web:queryMessageFile>" + "</soapenv:Body>"
                    + "</soapenv:Envelope>";
            fileQueryMethod.setRequestBody(queryMsgFileRequest);
            submitReturnCode = httpClient.executeMethod(fileQueryMethod);
            String result5 = fileQueryMethod.getResponseBodyAsString();
            String results = result5.replaceAll("&gt;", ">").replaceAll("&lt;", "<").replaceAll("&quot;", "\"");
            json = this.convertJson(results);
            callTime ++;
            log.info("filename:" + fileName + ",json:" + json.toString() + "++++++++++++");
        } while (submitReturnCode == 302 && callTime <= 2);
        // -- 查询历史上传文件信息
        ShanghaiCreditFileInfoDO query = new ShanghaiCreditFileInfoDO();
        query.setUploadId(uploadId);
        ShanghaiCreditFileInfoDO shanghaiCreditFileInfoDO = shanghaiCreditDao.getShanghaiCreditFileInfo(query);
        if (shanghaiCreditFileInfoDO == null){
            shanghaiCreditFileInfoDO = new ShanghaiCreditFileInfoDO();
        }
        shanghaiCreditFileInfoDO.setUploadId(uploadId);
        shanghaiCreditFileInfoDO.setCreateUser(loginId);
        shanghaiCreditFileInfoDO.setModifyUser(loginId);
        // -- 解析返回结果
        if (!json.getBoolean("success")){
            RestResponse response = new RestResponse(MsgErrCode.FAIL);
            response.setDescription(json.getString("errors"));
            return response;
        }
        if (json.containsKey("errors")){
            shanghaiCreditFileInfoDO.setErrorInfo(json.getString("errors"));
        }
        String state = "";
        if (json.containsKey("state")){
            state = json.getString("state");
            shanghaiCreditFileInfoDO.setState(state);
        }
        if (json.containsKey("failcount")){
            shanghaiCreditFileInfoDO.setFailCount(json.getInt("failcount"));
        }
        if (json.containsKey("totalcount")){
            shanghaiCreditFileInfoDO.setTotalCount(json.getInt("totalcount"));
        }
        if (json.containsKey("feedbackfilepath")){
            String feedbackfilepath = json.getString("feedbackfilepath");
            if (StringUtils.isNotNullAndEmpty(feedbackfilepath)){
                feedbackfilepath.replaceAll("\\\\", "\\/");
            }
            shanghaiCreditFileInfoDO.setFeedbackFilepath(feedbackfilepath);
        }
        // -- 如果有加载完成 且有错误数据 调用下载报文反馈文件
        if("3".equals(state) && json.getInt("totalcount") > 0 && json.getInt("failcount") > 0){
            try {
                shanghaiCreditFileInfoDO = callDownloadFile(shanghaiCreditFileInfoDO);
            }catch (Exception e){
                log.error("获取上海资信反馈文件接口异常:"+e);
            }
        }
        if(shanghaiCreditFileInfoDO.getId() != null){
            shanghaiCreditDao.updateShanghaiCreditFileInfo(shanghaiCreditFileInfoDO);
        }else{
            shanghaiCreditDao.insertShanghaiCreditFileInfo(shanghaiCreditFileInfoDO);
        }
        return new RestResponse(MsgErrCode.SUCCESS);

    }

    /**
     * 下载反馈文件
     * @author      xieqingyang
     * @date        2018/9/25 下午5:09
     * @version     1.0
     * @param shanghaiCreditFileInfoDO 文件信息
     * @return 返回文件信息
     * @throws Exception 所有异常
     */
    private ShanghaiCreditFileInfoDO callDownloadFile(ShanghaiCreditFileInfoDO shanghaiCreditFileInfoDO) throws Exception {
        GetMethod fileQueryMethod;
        int submitReturnCode;
        int callTime = 0;
        do {
            HttpClient httpClient = this.readyCallInterface();
            String url = shzxReadyUrl + shanghaiCreditFileInfoDO.getFeedbackFilepath();
            fileQueryMethod = new GetMethod(URLEncoder.encode(url,"UTF-8"));
            fileQueryMethod.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            submitReturnCode = httpClient.executeMethod(fileQueryMethod);
            InputStream ins = fileQueryMethod.getResponseBodyAsStream();
            // -- 文件名
            String uid = UUID.randomUUID().toString();
            ResultFileInfo uploadFile = fastFileStorageService.uploadFile(ins,uid,null);
            shanghaiCreditFileInfoDO.setFeedbackFilepath(CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ",""));
            callTime ++;
        } while (submitReturnCode == 302 && callTime <= 2);
        return shanghaiCreditFileInfoDO;
    }

    /**
     * 保存文件
     * @author      xieqingyang
     * @date        2018/9/25 下午2:31
     * @version     1.0
     * @param stream 文件流
     * @param path 路径
     * @param filename 文件名称
     * @throws IOException ioe异常
     */
    private void saveFileFromInputStream(InputStream stream, String path, String filename) throws IOException {
        FileOutputStream fs = new FileOutputStream(path + "/" + filename);
        byte[] buffer = new byte[1024 * 1024];
        int byteread = 0;
        while ((byteread = stream.read(buffer)) != -1) {
            fs.write(buffer, 0, byteread);
            fs.flush();
        }
        fs.close();
        stream.close();
    }

    /**
     * 上传文件到上海资信 并且存储文件到fasdfs
     * @author      xieqingyang
     * @date        2018/9/25 上午10:32
     * @version     1.0
     * @param localFilePath 本地文件路径
     * @param fileName 文件名称
     * @param signCode 标识
     * @param loginId 登录人
     * @return 返回上海资信返回数据
     * @throws Exception 所有异常
     */
    private RestResponse callUploadInterface(String filePath,String localFilePath, String fileName,String signCode,Long loginId,String xlsPath) throws Exception {
        PostMethod fileUploadMethod;
        int submitReturnCode;
        JSONObject json;
        HttpClient httpClient = this.readyCallInterface();
        fileUploadMethod = new PostMethod(shzxMsgSubmitUrl);
        // 注意！！！，此处的文件是用zippassword压缩后的zip文件
        File file = new File(localFilePath);
        ResultFileInfo uploadFile;
        if (StringUtils.isNullOrEmpty(filePath)) {
            File xlsFile = new File(xlsPath);
            uploadFile = fastFileStorageService.uploadFile(xlsFile, null);
            filePath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");
            xlsFile.delete();
        }
        do {
            fileUploadMethod.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            String uploadRequest = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.datasubmit.p2p.sino.com/\">"
                    + "<soapenv:Header/>"
                    + "<soapenv:Body>"
                    + "<web:uploadMessageFile>"
                    + "<orgcode>" + shzxQueryCreditOrgcode + "</orgcode>"
                    + "<secret>" + shzxQueryCreditSecret + "</secret>"
                    + "<filename>" + fileName + ".zip" + "</filename>" // 文件名
                    + "<filebuff>" + Base64.encodeBase64String(FileUtils.readFileToByteArray(file)) + "</filebuff>"
                    + "</web:uploadMessageFile>"
                    + "</soapenv:Body>"
                    + "</soapenv:Envelope>";
            fileUploadMethod.setRequestBody(uploadRequest);
            submitReturnCode = httpClient.executeMethod(fileUploadMethod);
            String result = fileUploadMethod.getResponseBodyAsString();
            result = result.replaceAll("&gt;", ">").replaceAll("&lt;", "<").replaceAll("&quot;", "\"");
            json = this.convertJson(result);
            log.info("filename:" + fileName + ",json:" + json.toString() + "++++++++++++");
        } while (submitReturnCode == 302);
        file.delete();
        ShanghaiCreditUploadInfoDO shzxUploadInfo = new ShanghaiCreditUploadInfoDO();
        if (json.containsKey("errors")){
            shzxUploadInfo.setErrors(json.getString("errors"));
        }
        if (json.containsKey("success")) {
            shzxUploadInfo.setIsSucuess(json.getString("success"));
        }
        //保存上传接口调用信息
        shzxUploadInfo.setSignCode(signCode);
        shzxUploadInfo.setFileName(fileName);
        shzxUploadInfo.setReturnCode(String.valueOf(submitReturnCode));
        shzxUploadInfo.setCreateUser(loginId);
        shzxUploadInfo.setFilePath(filePath);
        shanghaiCreditDao.insertShanghaiCreditUploadInfo(shzxUploadInfo);
        if (json.getBoolean("success")){
            return new RestResponse(MsgErrCode.SUCCESS);
        }else {
            RestResponse response = new RestResponse(MsgErrCode.FAIL);
            response.setDescription(json.getString("errors"));
            return response;
        }
    }

    /**
     * 上海资信返回数据转换成json格式
     * @author      xieqingyang
     * @date        2018/9/25 上午11:07
     * @version     1.0
     * @param results 返回结果
     * @return json数据
     * @throws Exception 所有异常
     */
    private JSONObject convertJson(String results) throws Exception{
        int start = results.indexOf('[');
        int end = results.indexOf(']');
        String content = results.substring(start + 1, end);
        return JSONObject.fromObject(content);
    }

    /**
     * 本地生成excel以及zip加密文件
     * @author      xieqingyang
     * @date        2018/9/21 下午4:27
     * @version     1.0
     * @param workBook 表格
     * @param rootPath 临时文件存储位置
     * @return 返回文件信息
     * @throws Exception 所有异常
     */
    private Map<String,Object> createExcelZip(HSSFWorkbook workBook,String rootPath) throws Exception {
        // 获取当前时间 yyyyMMdd
        Calendar now = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        //上传时间
        String dateNowStr = sdf.format(now.getTime());
        //生成3位随机字符串
        String signCode = this.getRandomStr(dateNowStr);
        // 上传文件名
        String fileName = shzxQueryCreditOrgcode + dateNowStr + signCode + "1";
        // excel 目标文件名
        String xlsPath = rootPath + "/" + fileName + ".xls";
        // 删除重复的目标excel文件
        File pathDel = new File(xlsPath);
        pathDel.createNewFile();
        // 生成目标excel文件
        FileOutputStream fileout = new FileOutputStream(xlsPath);
        workBook.write(fileout);
        fileout.flush();
        fileout.close();
        // 目标zip文件名
        String zipPath = rootPath + "/" + fileName + ".zip";
        // 生成zip 加密文件
        addFilesWithAESEncryption(xlsPath, zipPath);
        Map<String, Object> map = new HashMap<String, Object>(4);
        map.put("zipPath", zipPath);
        map.put("fileName", fileName);
        map.put("signCode", signCode);
        map.put("xlsPath",xlsPath);
        return map;
    }

    /**
     * 生成zip文件
     * @param filePath 文件存放位置
     * @param zipFilePath zip文件存放位置
     * @throws Exception 所有异常
     */
    private void addFilesWithAESEncryption(String filePath,String zipFilePath)throws Exception{
        //目标zip文件
        ZipFile zipFile = new ZipFile(zipFilePath);

        //需压缩文件
        ArrayList<File> filesToAdd = new ArrayList<File>();
        filesToAdd.add(new File(filePath));

        ZipParameters parameters = new ZipParameters();
        parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);

        parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
        parameters.setEncryptFiles(true);

        parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);

        //加密密码
        parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
        parameters.setPassword(shzxMsgSubmitSecret);

        zipFile.addFiles(filesToAdd, parameters);
    }

    /**
     * 获取随机三位字符串
     * @author      xieqingyang
     * @date        2018/9/21 下午4:28
     * @version     1.0
     * @param date 传入数据
     * @return 返回标识符
     * @throws Exception 所有异常
     */
     private String getRandomStr(String date) throws Exception{
        char[] chr = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        StringBuffer buffer;
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("dateStr", date);
        do {
            Random random = new Random();
            buffer = new StringBuffer();
            for (int i = 0; i < 3; i++) {
                buffer.append(chr[random.nextInt(chr.length)]);
            }
            paraMap.put("signCode", buffer.toString());
        } while (shanghaiCreditDao.querySgincount(paraMap) > 0);

        return buffer.toString();
    }

    /**
     * 返回execl需要的身份信息
     * @author      xieqingyang
     * @date        2018/9/20 下午6:31
     * @version     1.0
     * @param shanghaiCreditInFoVOS 数据信息
     * @return 返回所需信息
     * @throws Exception 所有异常
     */
    private Object[][] getExcelPersonalValues(List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS)throws Exception{
        Object[][] personalValues = new Object[shanghaiCreditInFoVOS.size()][27];
        for (int i = 0; i < shanghaiCreditInFoVOS.size(); i++) {
            ShanghaiCreditInFoVO shanghaiCreditInFoVO = shanghaiCreditInFoVOS.get(i);
            Object[] values = new Object[27];
            values[0] = shzxQueryCreditOrgcode;
            values[1] = shanghaiCreditInFoVO.getClientName();
            values[2] = shanghaiCreditInFoVO.getCardType();
            values[3] = shanghaiCreditInFoVO.getIdCard();
            values[4] = IdCardUtil.getSexShzx(shanghaiCreditInFoVO.getIdCard());
            values[5] = shanghaiCreditInFoVO.getIdCard().substring(6, 14);
            values[6] = shanghaiCreditInFoVO.getMarriage();
            values[7] = shanghaiCreditInFoVO.getEducation();
            values[8] = shanghaiCreditInFoVO.getDegree();
            values[9] = shanghaiCreditInFoVO.getHomePhone() == null ? "" : hideStr(shanghaiCreditInFoVO.getHomePhone());
            values[10] = shanghaiCreditInFoVO.getPhone() == null ? "" : hideStr(shanghaiCreditInFoVO.getPhone());
            values[11] = shanghaiCreditInFoVO.getCompPhone() == null ? "" : hideStr(shanghaiCreditInFoVO.getCompPhone());
            values[12] = subStr(shanghaiCreditInFoVO.getEmail(), 30);
            values[13] = checkAddressLength(shanghaiCreditInFoVO.getNowAllAddress(), shanghaiCreditInFoVO.getNowAddress());
            values[14] = shanghaiCreditInFoVO.getNowPostalcode();
            values[15] = checkAddressLength(shanghaiCreditInFoVO.getHomeAllAddress(), shanghaiCreditInFoVO.getHomeAddress());
            //不是未婚
            if(!"10".equals(shanghaiCreditInFoVO.getMarriage())){
                values[16] = shanghaiCreditInFoVO.getSpouseName() == null ? "" : shanghaiCreditInFoVO.getSpouseName();
                values[17] = shanghaiCreditInFoVO.getSpouseCardType() == null ? "" : shanghaiCreditInFoVO.getSpouseCardType();
                values[18] = shanghaiCreditInFoVO.getSpouseIdcard() == null ? "" : shanghaiCreditInFoVO.getSpouseIdcard();
                values[19] = shanghaiCreditInFoVO.getSpouseCompName() == null ? "" : shanghaiCreditInFoVO.getSpouseCompName();
                values[20] = shanghaiCreditInFoVO.getSpousePhone() == null ? "" : hideStr(shanghaiCreditInFoVO.getSpousePhone());
            }
            values[21] = shanghaiCreditInFoVO.getFirstLinkmanName() == null? "" : shanghaiCreditInFoVO.getFirstLinkmanName();
            values[22] = shanghaiCreditInFoVO.getFirstLinkmanRelation() == null ? "" : shanghaiCreditInFoVO.getFirstLinkmanRelation();
            values[23] = StringUtils.isNullOrEmpty(shanghaiCreditInFoVO.getFirstLinkmanPhone())? "*" : hideStr(shanghaiCreditInFoVO.getFirstLinkmanPhone());
            values[24] = shanghaiCreditInFoVO.getSecondLinkmanName() == null ? "" : shanghaiCreditInFoVO.getSecondLinkmanName();
            values[25] = shanghaiCreditInFoVO.getSecondLinkmanRelation() == null ? "" : shanghaiCreditInFoVO.getSecondLinkmanRelation();
            values[26] = StringUtils.isNullOrEmpty(shanghaiCreditInFoVO.getSecondLinkmanPhone()) ? "*" : hideStr(shanghaiCreditInFoVO.getSecondLinkmanPhone());
            personalValues[i] = values;
        }
        return personalValues;
    }

    /**
     * 返回excel需要的职业信息
     * @author      xieqingyang
     * @date        2018/9/21 下午2:28
     * @version     1.0
     * @param shanghaiCreditInFoVOS 数据信息
     * @return 返回所需信息
     * @throws Exception 所有异常
     */
    private Object[][] getExcelJobValues(List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS)throws Exception{
        Object[][] jobValues = new Object[shanghaiCreditInFoVOS.size()][13];
        for (int i = 0; i < shanghaiCreditInFoVOS.size(); i++) {
            ShanghaiCreditInFoVO shanghaiCreditInFoVO = shanghaiCreditInFoVOS.get(i);
            Object[] values = new Object[13];
            values[0] = shzxQueryCreditOrgcode;
            values[1] = shanghaiCreditInFoVO.getClientName();
            values[2] = shanghaiCreditInFoVO.getCardType();
            values[3] = shanghaiCreditInFoVO.getIdCard();
            values[4] = shanghaiCreditInFoVO.getOccupation();
            values[5] = checkAddressLength(shanghaiCreditInFoVO.getCompName(), shanghaiCreditInFoVO.getCompName());
            values[6] = shanghaiCreditInFoVO.getCompIndustry();
            values[7] = checkAddressLength(shanghaiCreditInFoVO.getCompAllAddress(), shanghaiCreditInFoVO.getCompAddress());
            values[8] = shanghaiCreditInFoVO.getCompPostalcode();
            values[9] = shanghaiCreditInFoVO.getJoinYear() == null ? "" : shanghaiCreditInFoVO.getJoinYear();
            values[10] = shanghaiCreditInFoVO.getDuty() == null ? "" : shanghaiCreditInFoVO.getDuty();
            values[11] = shanghaiCreditInFoVO.getJobTitle() == null ? "" : shanghaiCreditInFoVO.getJobTitle();
            values[12] = shanghaiCreditInFoVO.getYearlyIncome().substring(0,shanghaiCreditInFoVO.getYearlyIncome().lastIndexOf("."));
            jobValues[i] = values;
        }
        return jobValues;
    }

    /**
     * 返回excel需要的居住信息
     * @author      xieqingyang
     * @date        2018/9/21 下午2:34
     * @version     1.0
     * @param shanghaiCreditInFoVOS 数据信息
     * @return 返回所需信息
     * @throws Exception 所有异常
     */
    private Object[][] getExcelLiveValues(List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS) throws Exception {
        Object[][] liveValues = new Object[shanghaiCreditInFoVOS.size()][7];
        for (int i = 0; i < shanghaiCreditInFoVOS.size(); i++) {
            ShanghaiCreditInFoVO shanghaiCreditInFoVO = shanghaiCreditInFoVOS.get(i);
            Object[] values = new Object[7];
            values[0] = shzxQueryCreditOrgcode;
            values[1] = shanghaiCreditInFoVO.getClientName();
            values[2] = shanghaiCreditInFoVO.getCardType();
            values[3] = shanghaiCreditInFoVO.getIdCard();
            values[4] = this.checkAddressLength(shanghaiCreditInFoVO.getNowAllAddress(), shanghaiCreditInFoVO.getNowAddress());
            values[5] = shanghaiCreditInFoVO.getNowPostalcode();
            values[6] = shanghaiCreditInFoVO.getLiveStatus() == null ? "" : shanghaiCreditInFoVO.getLiveStatus();
            liveValues[i] = values;
        }
        return liveValues;
    }

    /**
     * 返回excel需要的贷款业务信息
     * @author      xieqingyang
     * @date        2018/9/21 下午2:58
     * @version     1.0
     * @param shanghaiCreditInFoVOS 数据信息
     * @return 返回所需信息
     * @throws Exception 所有异常
     */
    private Object[][] getExcelLoanBusinessValues(List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS) throws Exception {
        Object[][] loanBusinessValues = new Object[shanghaiCreditInFoVOS.size()][37];
        for (int i = 0; i < shanghaiCreditInFoVOS.size(); i++) {
            ShanghaiCreditInFoVO shanghaiCreditInFoVO = shanghaiCreditInFoVOS.get(i);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
            //结算应还款日期
            Date returnDate = getRealReturnDate(shanghaiCreditInFoVO.getFinishDate(),shanghaiCreditInFoVO.getAccountStatus(),shanghaiCreditInFoVO.getAcountOpenDate());
            //计算24月还款状态
//            String calcateRepaymentState = calcateRepaymentState(shanghaiCreditInFoVO.getAccountStatus(), shanghaiCreditInFoVO.getAgreementReturnLimit(), shanghaiCreditInFoVO.getAgreementReturnDate(), returnDate, shanghaiCreditInFoVO.getRepDateNew(), shanghaiCreditInFoVO.getAcountOpenDate());
            String calcateRepaymentState = "3".equals(shanghaiCreditInFoVO.getAccountStatus())?"///////////////////////C":"///////////////////////*";
            Object[] values = new Object[37];
            values[0] = shzxQueryCreditOrgcode;
            values[1] = shanghaiCreditInFoVO.getLoanType();
//            values[2] = shanghaiCreditInFoVO.getContractNum();
            values[2] = "";
            values[3] = shanghaiCreditInFoVO.getBusinessNum();
            values[4] = shanghaiCreditInFoVO.getDealPlace() == null ? "110000" : shanghaiCreditInFoVO.getDealPlace();
            values[5] = shanghaiCreditInFoVO.getAcountOpenDate() == null ? "" : simpleDateFormat.format(shanghaiCreditInFoVO.getAcountOpenDate());
            values[6] = shanghaiCreditInFoVO.getExpireDate() == null ? "" : simpleDateFormat.format(shanghaiCreditInFoVO.getExpireDate());
            values[7] = shanghaiCreditInFoVO.getCurrency() == null ? "" : shanghaiCreditInFoVO.getCurrency();
            values[8] = shanghaiCreditInFoVO.getCreditAmount().substring(0,shanghaiCreditInFoVO.getCreditAmount().lastIndexOf("."));
            values[9] = shanghaiCreditInFoVO.getCreditShareAmount().substring(0,shanghaiCreditInFoVO.getCreditShareAmount().lastIndexOf("."));
            values[10] = shanghaiCreditInFoVO.getLiabilityMaxAmount().substring(0,shanghaiCreditInFoVO.getLiabilityMaxAmount().lastIndexOf("."));
            values[11] = shanghaiCreditInFoVO.getGuaranteeWay();
            values[12] = shanghaiCreditInFoVO.getRepaymentFrequency();
            values[13] = shanghaiCreditInFoVO.getReturnMonth();
            values[14] = shanghaiCreditInFoVO.getRemainingMonth() == null ? shanghaiCreditInFoVO.getReturnMonth() : shanghaiCreditInFoVO.getRemainingMonth();
            values[15] = shanghaiCreditInFoVO.getReturnMonth() == null ? "" : shanghaiCreditInFoVO.getReturnMonth();
            values[16] = shanghaiCreditInFoVO.getAgreementReturnAmount();
            values[17] = simpleDateFormat.format(returnDate);
            // 最近一次还款日期 如果没有 填写开户日期
            values[18] = simpleDateFormat.format(shanghaiCreditInFoVO.getFinishDate() == null ? shanghaiCreditInFoVO.getAcountOpenDate() : shanghaiCreditInFoVO.getFinishDate());
            values[19] = "3".equals(shanghaiCreditInFoVO.getAccountStatus())?shanghaiCreditInFoVO.getAgreementReturnAmount().substring(0,shanghaiCreditInFoVO.getAgreementReturnAmount().lastIndexOf(".")):"0";
//            values[20] = shanghaiCreditInFoVO.getReturnCurrentPracticalAmount().substring(0,shanghaiCreditInFoVO.getReturnCurrentPracticalAmount().indexOf("."));
            values[20] = "3".equals(shanghaiCreditInFoVO.getAccountStatus())?shanghaiCreditInFoVO.getCreditAmount().substring(0,shanghaiCreditInFoVO.getCreditAmount().lastIndexOf(".")):shanghaiCreditInFoVO.getReturnCurrentPracticalAmount().substring(0,shanghaiCreditInFoVO.getReturnCurrentPracticalAmount().indexOf("."));
            //结清状态下 余额为0
            values[21] = shanghaiCreditInFoVO.getAccountStatus().equals("3")?0:shanghaiCreditInFoVO.getRemainAmount();
            values[22] = shanghaiCreditInFoVO.getOverdueCurrentLimit();
            values[23] = shanghaiCreditInFoVO.getOverdueCurrentAmount();
            values[24] = shanghaiCreditInFoVO.getOverdueCapital3160();
            values[25] = shanghaiCreditInFoVO.getOverdueCapital6190();
            values[26] = shanghaiCreditInFoVO.getOverdueCapital91100();
            values[27] = shanghaiCreditInFoVO.getOverdueCapital180();
            values[28] = shanghaiCreditInFoVO.getOverdueSumLimit();
            values[29] = shanghaiCreditInFoVO.getOverdueMaxLimit();
            values[30] = shanghaiCreditInFoVO.getTypeStatus() == null ? "" : shanghaiCreditInFoVO.getTypeStatus();
            values[31] = shanghaiCreditInFoVO.getAccountStatus() == null ? "" : shanghaiCreditInFoVO.getAccountStatus();
            values[32] = calcateRepaymentState;
            values[33] = shanghaiCreditInFoVO.getAccountPrompt() == null ? "" : shanghaiCreditInFoVO.getAccountPrompt();
            values[34] = shanghaiCreditInFoVO.getClientName();
            values[35] = shanghaiCreditInFoVO.getCardType();
            values[36] = shanghaiCreditInFoVO.getIdCard();
            loanBusinessValues[i] = values;
        }
        return loanBusinessValues;
    }

    /**
     * 返回excel需要的贷款合同信息
     * @author      xieqingyang
     * @date        2018/9/21 下午2:54
     * @version     1.0
     * @param shanghaiCreditInFoVOS 数据信息
     * @return 返回所需信息
     * @throws Exception 所有异常
     */
    private Object[][] getExcelLoanContractValues(List<ShanghaiCreditInFoVO> shanghaiCreditInFoVOS) throws Exception {
        // 贷款合同信息
        Object[][] loanContractValues = new Object[shanghaiCreditInFoVOS.size()][7];
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        for (int i = 0; i < shanghaiCreditInFoVOS.size(); i++) {
            ShanghaiCreditInFoVO shanghaiCreditInFoVO = shanghaiCreditInFoVOS.get(i);
            Object[] values = new Object[7];
            values[0] = shzxQueryCreditOrgcode;
            values[1] = shanghaiCreditInFoVO.getContractNum();
            values[2] = shanghaiCreditInFoVO.getAcountOpenDate() == null ? "" : simpleDateFormat.format(shanghaiCreditInFoVO.getAcountOpenDate());
            values[3] = shanghaiCreditInFoVO.getExpireDate() == null ? "" : simpleDateFormat.format(shanghaiCreditInFoVO.getExpireDate());
            values[4] = shanghaiCreditInFoVO.getCurrency();
            values[5] = shanghaiCreditInFoVO.getCreditAmount().substring(0,shanghaiCreditInFoVO.getCreditAmount().indexOf("."));
            values[6] = shanghaiCreditInFoVO.getContractStatus() == null ? "" : shanghaiCreditInFoVO.getContractStatus();
            loanContractValues[i] = values;
        }
        return loanContractValues;
    }

    /**
     * 当月应还金额
     * @author      xieqingyang
     * @date        2018/9/21 下午2:54
     * @param calulate 24月还款状态
     * @param monthReturn 本月应还金额
     * @return 返回金额
     * @throws Exception 所有异常
     */
    private BigDecimal getMonthReturn(String calulate,BigDecimal monthReturn) throws Exception{
        String lastState = calulate.substring(calulate.length()-1,calulate.length());
        // -- 本月未开户或者无需还款 ,金额需为0
        if(lastState.equals("*") || lastState.equals("/")){
            return BigDecimal.ZERO;
        }else{
            return monthReturn;
        }
    }

    /**
     * 计算结算/应还日期
     * @author      xieqingyang
     * @date        2018/9/21 下午3:41
     * @version     1.0
     * @param finishDate 结算日期
     * @param state 账户状态
     * @return 结算/应还日期
     */
    private Date getRealReturnDate(Date finishDate,String state,Date openDate){
        if("3".equals(state)){
            return finishDate;
            // -- 结清状态
        }else{
            return openDate;
        }
    }

    /**
     * 计算24月还款状态
     * @param accountStatus 账户状态
     * @param agreementReturnLimit 期限
     * @param agreementReturnDate 最后一次应还款日期
     * @param returnDate 实际最近还款日期
     * @param repDateNew 还款日
     * @param acountOpenDate 开户日期
     * @return 返回24月还款状态
     * @throws Exception 所有异常
     */
    private String calcateRepaymentState(String accountStatus, String agreementReturnLimit, Date agreementReturnDate, Date returnDate, String repDateNew, Date acountOpenDate) throws Exception {
        String s1 = "";
        String s3 = "";
        String fs = "";
        String lastRepayDateStr = DateUtils.formatDateYMD(agreementReturnDate);
        String lateActualDateStr = DateUtils.formatDateYMD(returnDate);
        // 最近还款日默认为开户日期
        if (returnDate == null) {
            lateActualDateStr = DateUtils.formatDateYMD(acountOpenDate);
        }
        // -- 总期数
        int repayNum = Integer.parseInt(agreementReturnLimit);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date date1 = sdf.parse(lateActualDateStr);
        Date date2 = sdf.parse(lastRepayDateStr);
        // -- 剩余未还期数
        int monthNum = this.getDiffNum(date1, date2);
        int nu = repayNum - monthNum>24?24:repayNum-monthNum;
        if(nu == 0){
            nu = nu + 1;
        }
        // 1：未结清
        if ("1".equals(accountStatus) || "2".equals(accountStatus)) {
            for (int m = 1; m <= nu; m++) {
                if (!"30".equals(repDateNew) && m == 1) {
                    s1 += "*";
                }else {
                    s1 += "N";
                }
            }

        } else {
            // 2：结清
            for (int k = 1; k <= nu; k++) {
                if(k==nu){
                    // 提前结清、最后一位结清
                    s1 += "C";
                }else{
                    s1 += "N";
                }
            }
        }
        int len = 24 - (s1.length());
        for (int j = 1; j <= len; j++) {
            s3 += "/";
        }
        fs += s3 + s1;
        return fs;
    }

    private Integer getDiffNum(Date startMonth, Date endMonth) throws Exception {
        Integer monthNum = 0;
        Integer yearNumber = 0;
        Calendar startCalendar = Calendar.getInstance();
        Calendar endCalendar = Calendar.getInstance();
        startCalendar.setTime(startMonth);
        endCalendar.setTime(endMonth);
        yearNumber = endCalendar.get(endCalendar.YEAR) - startCalendar.get(endCalendar.YEAR);
        monthNum = endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
        return yearNumber * 12 + monthNum;
    }

    /**
     * check 全地址字符长度
     * @author      xieqingyang
     * @date        2018/9/21 下午2:16
     * @version     1.0
     * @param allAddress 全地址
     * @param address 地址
     * @return 处理之后的地址
     * @throws Exception 所有异常
     */
    private String checkAddressLength(String allAddress, String address) throws Exception {
        if (StringUtils.isNotNullAndEmpty(allAddress) && this.getCharLength(allAddress) > 60) {
            if (StringUtils.isNotNullAndEmpty(address) && this.getCharLength(address) > 60) {
                return subStr(address, 60);
            } else {
                return StringUtils.isNotNullAndEmpty(address)?address:"";
            }
        } else {
            return StringUtils.isNotNullAndEmpty(allAddress)?allAddress:"";
        }
    }

    /**
     * 得到一个字符串的长度,显示的长度,一个汉字或日韩文长度为2,英文字符长度为1
     * @author      xieqingyang
     * @date        2018/9/21 下午2:17
     * @version     1.0
     * @param s 需要得到长度的字符串
     * @return 得到的字符串长度
     */
    private int getCharLength(String s){
        s = s.replaceAll("[^\\x00-\\xff]", "**");
        return s.length();
    }

    /**
     * 按字节 截取字符串
     * @author      xieqingyang
     * @date        2018/9/21 下午2:17
     * @version     1.0
     * @param str 待截取字符串
     * @param subSLength 截取长度
     * @return 截取之后的数据
     * @throws UnsupportedEncodingException 异常信息
     */
    private String subStr(String str, int subSLength) throws UnsupportedEncodingException {
        if (str == null) {
            return "";
        }else {
            // 截取字节数
            int tempSubLength = subSLength;
            // 截取的子串
            String subStr = str.substring(0, str.length() < subSLength ? str.length() : subSLength);
            int subStrByetsL = subStr.getBytes("GBK").length;
            // int subStrByetsL = subStr.getBytes().length;//截取子串的字节长度
            // 说明截取的字符串中包含有汉字
            while (subStrByetsL > tempSubLength) {
                int subSLengthTemp = --subSLength;
                subStr = str.substring(0, subSLengthTemp > str.length() ? str.length() : subSLengthTemp);
                subStrByetsL = subStr.getBytes("GBK").length;
                // subStrByetsL = subStr.getBytes().length;
            }
            return subStr;
        }
    }

    /**
     * 手机号隐藏后四位
     * @author      xieqingyang
     * @date        2018/9/21 下午2:11
     * @version     1.0
     * @param phone 手机号
     * @return 处理之后的手机号
     */
    private String hideStr(String phone){
        if (StringUtils.isNullOrEmpty(phone) || phone.length() < 7) {
            return "";
        } else {
            if(phone.length()>11){
                phone = phone.substring(0,11);
            }
            StringBuffer sb = new StringBuffer(phone);
            return sb.replace(sb.length() - 4, sb.length(), "****").toString();
        }
    }

    /**
     * 为excel添加sheet
     * @author      xieqingyang
     * @date        2018/9/20 下午6:17
     * @version     1.0
     * @param title sheet标题
     * @param workbook excel对象
     * @param head 标题
     * @param values 单元格的值
     * @return excel
     */
    private HSSFWorkbook addSheet(String title, HSSFWorkbook workbook, String[] head, Object[][] values){
        // sheet名称
        HSSFSheet sheet = workbook.createSheet(title);
        HSSFCellStyle dataStyle = null;

        dataStyle = workbook.createCellStyle();

        HSSFFont dataFont = workbook.createFont();
        dataFont.setFontHeightInPoints((short) 10);
        dataFont.setFontName("宋体");
        dataFont.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
        dataStyle.setFont(dataFont);
        dataStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        dataStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
        dataStyle.setWrapText(true);
        dataStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        dataStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        dataStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
        dataStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
        sheet.setDisplayGridlines(false);
        // sheet默认单元格宽度
        sheet.setDefaultColumnWidth((short) 30);
        // 创建标题行
        HSSFRow row0 = sheet.createRow(0);
        for (int i = 0; i < head.length; i++) {
            // 创建标题行对应的列
            HSSFCell cell0 = row0.createCell(i);
            cell0.setCellStyle(dataStyle);
            // 设置标题内容
            cell0.setCellValue(new HSSFRichTextString(head[i]));
        }
        // 创建具体内容行 列
        for (int i = 0; i < values.length; i++) {
            HSSFRow row = sheet.createRow(i + 1);
            for (int j = 0; j < values[i].length; j++) {
                HSSFCell cell0 = row.createCell(j);
                cell0.setCellStyle(dataStyle);
                setCellValue(cell0, values[i][j]);
            }
        }
        return workbook;
    }


    /**
     * 设置单元格的值
     * @author      xieqingyang
     * @date        2018/9/20 下午6:16
     * @version     1.0
     * @param cell 单元格
     * @param data 数据
     */
    private void setCellValue(HSSFCell cell, Object data){
        if (data instanceof Integer) {
            cell.setCellValue((Integer) data);
        } else if (data instanceof Long) {
            cell.setCellValue((Long) data);
        } else if (data instanceof Timestamp) {
            cell.setCellValue((Timestamp) data);
        } else if (data instanceof java.util.Date) {
            // 时间 转换yyyyMMdd
            cell.setCellValue(DateUtils.toString((Date) data,"yyyyMMdd"));
        } else if (data instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal)data).setScale(0,BigDecimal.ROUND_HALF_UP).intValue());
        } else {
            cell.setCellValue(new HSSFRichTextString((String) data));
        }
    }

    /**
     * 模拟登录
     * @author      xieqingyang
     * @date        2018/9/25 上午10:33
     * @version     1.0
     * @return 返回连接
     * @throws Exception 所有异常
     */
    private HttpClient readyCallInterface() throws Exception {

        HttpClient httpClient = new HttpClient();
        HttpClientParams httparams = new HttpClientParams();
        // 请求超时时间
        httparams.setSoTimeout(60000);
        httpClient.setParams(httparams);
        // 连接超时时间
        httpClient.setConnectionTimeout(60000);
        httpClient.getHostConfiguration().setHost("vpn.shanghai-cis.com.cn", 80);

        ProtocolSocketFactory fcty = new MySecureProtocolSocketFactory();
        Protocol.registerProtocol("https", new Protocol("https", fcty, 443));

        PostMethod login = new PostMethod(shzxLoginUrl);
        login.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        int loginReturnCode = httpClient.executeMethod(login);
        log.info("上海资信接口模拟login,returnCode:" + loginReturnCode);

        // STEP2:
        PostMethod index = new PostMethod(shzxIndexUrl);
        index.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        index.addRequestHeader("Refer", shzxLoginUrl);
        index.addRequestHeader("Accept", "image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
        NameValuePair tgroup = new NameValuePair("tgroup", "");
        NameValuePair next = new NameValuePair("next", "");
        NameValuePair tgcookieset = new NameValuePair("tgcookieset", "");
        NameValuePair Login = new NameValuePair("Login", "登录");
        // -- 登录用户名
        NameValuePair Email = new NameValuePair("username", shzxLoginUser);
        // -- 登录密码
        NameValuePair password = new NameValuePair("password", shzxLoginPassword);
        NameValuePair[] data = { tgroup, next, tgcookieset, Login, Email, password };
        index.setRequestBody(data);
        int indexReturnCode = httpClient.executeMethod(index);
        if (indexReturnCode == 200) {
            log.info("上海资信接口模拟index成功,returnCode:" + indexReturnCode);
        } else {
            log.info("上海资信接口模拟index失败,returnCode:" + indexReturnCode);
        }
        return httpClient;
    }
}
