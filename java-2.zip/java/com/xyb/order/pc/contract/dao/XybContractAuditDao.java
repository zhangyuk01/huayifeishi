package com.xyb.order.pc.contract.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.pc.contract.contracttb.model.ContractTbItem;
import com.xyb.order.pc.contract.contracttb.model.ContractTbItemDetail;
import com.xyb.order.pc.contract.contracttb.model.XybContractTbDO;
import com.xyb.order.pc.contract.model.XybContractAuditDO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailVO;
import com.xyb.order.pc.contract.model.XybContractAuditListVO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;
import com.xyb.order.pc.contract.model.XybContractAuditRecordDO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.dao
 * @description : 合同审核dao
 * @createDate : 2018/4/18 13:52
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractAuditDao {
	/**
	 * 获取合同审核信息
	 * @param map
	 * @return
	 */
	XybContractAuditDO getXybContractAuditDO(Map<String, Object> map);
	/**
	 * 获取合同审核list
	 * @param xybContractAuditQueryDTO
	 * @return
	 */
	List<XybContractAuditListVO> listContractAuditPage(XybContractAuditQueryDTO xybContractAuditQueryDTO);
	/**
	 * 获取合同审核详情
	 * @param xybContractAuditDetailDTO
	 * @return
	 */
    XybContractAuditDetailVO getXybContractAuditDetailVO(XybContractAuditDetailDTO xybContractAuditDetailDTO);
    /**
     * 合同合同审核记录信息
     * @param applyId
     * @return
     */
    List<XybContractAuditRecordDO> listContractAuditRecordDO(Long applyId);
    
    void updateContractAuditNotNull(Object object);
    /**
     * 添加合同审核
     * @param object
     */
    void insertContractAudit(Object object);
    /**
     * 获取合同推标信息
     * @param applyId
     * @return
     */
    XybContractTbDO getXybContractTbDO(Long applyId);
    /**
     * 获取房产信息
     * @param applyId
     * @return
     */
    int getAuditOtherHouseCount(Long applyId);
    /**
     * 添加合同审核记录
     * @param xybContractAuditRecordDO
     */
    void insertXybContractAuditRecord(XybContractAuditRecordDO xybContractAuditRecordDO);
    /**
     * 查询图片信息
     * @param applyId
     * @return
     */
    List<Map<String,Object>> getPicsByApplyId(long applyId);
    /**
     * 查询披露图片信息
     * @param applyId
     * @return
     */
    List<Map<String,Object>> getAnnouncePicsByApplyId(long applyId);
    
	/**
	 * 查询推标主item项信息
	 * @param applyId
	 * @return
	 */
	ContractTbItem getContractTbItem(Long applyId);
	
	/**
	 * 查询推标detail数据
	 * @param applyId
	 * @return
	 */
	ContractTbItemDetail getContractTbItemDetail(Long applyId);
}
