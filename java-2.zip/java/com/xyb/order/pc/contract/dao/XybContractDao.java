package com.xyb.order.pc.contract.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.common.bank.model.XybContractUpdateDTO;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyContractInfoVO;
import com.xyb.order.pc.contract.model.XybContractAbolishListVO;
import com.xyb.order.pc.contract.model.XybContractAbolishQueryDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractDetailVO;
import com.xyb.order.pc.contract.model.XybContractListVO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;
import com.xyb.order.pc.contract.model.repaymentplan.XybContractRepaymentPlanDO;
import com.xyb.order.pc.contract.model.repaymentplan.XybContractRepaymentPlanVO;
import com.xyb.order.pc.product.model.ProductDO;
import com.xyb.order.pc.product.model.ProductExtDO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.dao
 * @description : 合同dao
 * @createDate : 2018/03/28 13:52
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface XybContractDao {
	
	/**
	 * 获取合同信息
	 * @param applyId
	 * @return
	 */
	XybContractDO getXybContractDO(Long applyId);
	
    /**
     * 获取合同列表
     * @param xybContractQueryDTO
     * @return
     */
    List<XybContractListVO> listContractPage(XybContractQueryDTO xybContractQueryDTO);
    
    /**
     * 获取合同详情信息
     * @param xybContractDetailDTO
     * @return
     */
    XybContractDetailVO getXybContractDetailVO(XybContractDetailDTO xybContractDetailDTO);
    /**
     * 获取合同审核信息
     * @param applyId
     * @return
     */
    XybContractAuditDO getContractAuditDO(Long applyId);
    /**
     * 添加合同
     * @param bean
     */
	void insertContract(XybContractDO bean);	
	/**
	 * 更新合同
	 * @param object
	 */
	void updateContractNotNull(Object object);
	/**
	 * 获取合同废除列表
	 * @param xybContractAbolishQueryDTO
	 * @return
	 */
    List<XybContractAbolishListVO> listContractAbolishPage(XybContractAbolishQueryDTO xybContractAbolishQueryDTO);
    /**
     * 获取合同人员id
     * @param map
     * @return
     */
	List<Map<Long, Long>> getContractUserId(Map<String, Object> map);
	/**
	 * 查询外访待冻结或合同待冻结的申请单id
	 * @param map
	 * @return
	 */
	List<Long> listApplyIds(Map<String, Object> map);
	
	
	/**
	 * 批量刪除还款计划
	 * @param applyId
	 */
	void deleteRepaymentPlan(Long applyId);
	
	/**
	 * 批量添加还款计划
	 * @param list
	 */
	void addPlans(List<XybContractRepaymentPlanDO> list);
	
	/**
	 * 获取申请已办合同信息
	 * @param applyId
	 * @return
	 */
	ApplyAlreadyContractInfoVO getApplyAlreadyContractInfoVO(Long applyId);
	
	/**
	 * 获取机构名字
	 * @param orgId
	 * @return
	 */
	String getOrgName(Long orgId);

	/**
	 * @description 修改用户合同表的银行卡信息
	 * @author      xieqingyang
	 * @CreatedDate 2018/7/23 上午11:48
	 * @Version     1.0
	 * @param xybContractUpdateDTO 用户银行卡信息
	 * @return 返回执行结果
	 */
	int updateContractBankInfo(XybContractUpdateDTO xybContractUpdateDTO);
	/**
	 * 获取产品信息
	 * @param productId
	 * @return
	 */
	ProductDO getProduct(Long productId);
	/**
	 * 获取产品拓展表信息
	 * @param productId
	 * @return
	 */
	List<ProductExtDO> getProductExtList(Long productId);

	
	List<String> getRecommendedWordValuesByIds(List<String> list);
	/**
	 * 获取还款计划
	 * @param applyId
	 * @return
	 */
	List<XybContractRepaymentPlanVO> listRepaymentPlans(Long applyId);
	/**
	 * 根据clientId获取存管账户Id
	 * @param clientId
	 * @return
	 */
	Long getAcctId(Long clientId);
	
}
