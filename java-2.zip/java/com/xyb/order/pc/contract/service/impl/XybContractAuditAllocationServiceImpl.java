package com.xyb.order.pc.contract.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.pc.contract.dao.XybContractAuditDao;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailVO;
import com.xyb.order.pc.contract.model.XybContractAuditListVO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.service.XybContractAuditAllocationService;
import com.xyb.order.pc.ownuse.service.contract.XybContractAllocationOwnService;
import com.xyb.util.SessionUtil;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 合同审核重新分配实现
 * @createDate : 2018/5/3 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.XybContractAuditAllocationService")
public class XybContractAuditAllocationServiceImpl implements XybContractAuditAllocationService{
	private static final Logger logger = LoggerFactory.getLogger(XybContractServiceImpl.class);
	@Autowired
	private XybContractAuditDao xybContractAuditDao;
	@Autowired
	private XybContractDao xybContractDao;	
	@Autowired
	private XybContractAllocationOwnService xybContractAllocationOwnService;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listContractAudit(Integer pageNumber, Integer pageSize, XybContractAuditQueryDTO xybContractAuditQueryDTO) {
		 RestResponse response;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);

	         
			 xybContractAuditQueryDTO.getPage().setPageNumber(pageNumber);
			 xybContractAuditQueryDTO.getPage().setPageSize(pageSize);
			 xybContractAuditQueryDTO.setOrgId(loginUser.getDataOrgId());
		     List<XybContractAuditListVO> list = xybContractAuditDao.listContractAuditPage(xybContractAuditQueryDTO);
		     xybContractAuditQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,xybContractAuditQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("合同审核重新分配列表查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateContractAudit(XybContractAuditDetailDTO xybContractAuditDetailDTO) {

		RestResponse response = null;
		try {
			/**1.查询申请相关信息*/
			XybContractAuditDetailVO xybContractAuditDetailVO = xybContractAuditDao.getXybContractAuditDetailVO(xybContractAuditDetailDTO);
			if(xybContractAuditDetailVO == null){
				xybContractAuditDetailVO = new XybContractAuditDetailVO();
			}
			
			/**2.查询合同相关信息*/
			XybContractDO xybContractDO = xybContractDao.getXybContractDO(xybContractAuditDetailDTO.getApplyId());
			
			/**3.查询图片类型集合*/
						
	        	    
			xybContractAuditDetailVO.setXybContractDO(xybContractDO);
			
	  		response = new RestResponse(MsgErrCode.SUCCESS,xybContractAuditDetailVO);
		} catch (Exception e) {
			logger.error("合同审核详情查询失败",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse allocationContract(XybContractAllocationDTO xybContractAllocationDTO) {
		RestResponse response = null;
		try {
			xybContractAllocationOwnService.contractAllocation(xybContractAllocationDTO);
	  		response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("合同重新分配异常,分配类型:",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	}
}
