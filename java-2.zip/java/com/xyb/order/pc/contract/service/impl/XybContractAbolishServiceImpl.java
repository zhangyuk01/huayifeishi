package com.xyb.order.pc.contract.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractAbolishListVO;
import com.xyb.order.pc.contract.model.XybContractAbolishQueryDTO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.service.XybContractAbolishService;
import com.xyb.order.pc.ownuse.service.contract.ApplyRevokeOwnService;
import com.xyb.order.pc.ownuse.service.contract.XybContractOwnuseService;
import com.xyb.util.SessionUtil;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 合同作废实现
 * @createDate : 2018/5/3 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.XybContractAbolishService")
public class XybContractAbolishServiceImpl implements XybContractAbolishService{
	private static final Logger logger = LoggerFactory.getLogger(XybContractServiceImpl.class);

	@Autowired
	private XybContractDao dao;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private XybContractOwnuseService xybContractOwnuseService;
	@Autowired
	private ApplyRevokeOwnService applyRevokeOwnService;

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listAbolishContract(Integer pageNumber, Integer pageSize,XybContractAbolishQueryDTO xybContractAbolishQueryDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);

			 xybContractAbolishQueryDTO.getPage().setPageNumber(pageNumber);
			 xybContractAbolishQueryDTO.getPage().setPageSize(pageSize);
			 xybContractAbolishQueryDTO.setOrgId(loginUser.getDataOrgId());
		     List<XybContractAbolishListVO> list = dao.listContractAbolishPage(xybContractAbolishQueryDTO);
		     xybContractAbolishQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,xybContractAbolishQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("合同重新分配列表查询失",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}
	
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse abolishContract(XybContractAbolishDTO xybContractAbolishDTO,String ipAddr,String macAddr) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();
			 /**合同废除 */
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", xybContractAbolishDTO.getApplyId());
			 ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 if(NodeStateConstant.CONTRACT_REVIEW.equals(applyBillMainInfoDO.getState())){
				 /**合同审核进行合同废除*/
				 /**1.更新流程状态为合同作废*/
				 MainLogDTO mainLogDTO = new MainLogDTO();
				 mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_INVALIDATION);
				 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
				 mainLogDTO.setModifyUser(userId);
				 currencyDao.addMainLog(mainLogDTO);
							
				 String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
				
				 applyBillMainInfoDO.setPrevious(NodeStateConstant.CONTRACT_REVIEW);
				 applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_INVALIDATION);
				 applyBillMainInfoDO.setModifyTime(new Date());
				 applyBillMainInfoDO.setModifyUser(userId);
				 applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

				 String newData = JsonUtil.object2json(applyBillMainInfoDO);
				 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
				 if(flag){
					currencyDao.updateMainInFo(applyBillMainInfoDO);
				 }
				 /**2.2.2更新合同表合同状态*/
				 XybContractDO xybContractDO = dao.getXybContractDO(applyBillMainInfoDO.getApplyId());
				 String oldContractData = JsonUtil.object2json(xybContractDO);
				 xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTZF.getCode());
				 xybContractDO.setContractAbolitionTime(new Date());
				 xybContractDO.setContractAbolition(xybContractAbolishDTO.getContractAbolition());
				 StringBuffer contractAbolitionName = new StringBuffer();
				 String[] reasons= xybContractAbolishDTO.getContractAbolition().substring(1,xybContractAbolishDTO.getContractAbolition().length()-1).split(",");
				 for (int i = 0; i < reasons.length; i++) {
					 if(i == reasons.length-1){
						 contractAbolitionName.append(SysDictEnum.getContractAbolishName(Long.valueOf(reasons[i])));
					 }else {
						 contractAbolitionName.append(SysDictEnum.getContractAbolishName(Long.valueOf(reasons[i]))).append(",");
					 }
				 }
				 xybContractDO.setContractAbolition(xybContractAbolishDTO.getContractAbolition().substring(1,xybContractAbolishDTO.getContractAbolition().length()-1));
				 xybContractDO.setContractAbolitionName(contractAbolitionName.toString());
				 xybContractDO.setRemarks(xybContractAbolishDTO.getRemarks());
				 xybContractDO.setModifyName(loginUser.getName());
				 xybContractDO.setModifyTime(new Date());
				 xybContractDO.setModifyUser(userId);
				 xybContractOwnuseService.updateContractNotNull(userId,oldContractData,xybContractDO);
			     response = new RestResponse(MsgErrCode.SUCCESS);
			 }else if(NodeStateConstant.IN_THE_BID.equals(applyBillMainInfoDO.getState())){
				 /**资金募集中进行合同废除*/
				 response = applyRevokeOwnService.repealing(xybContractAbolishDTO.getApplyId(),ipAddr,macAddr);
			 }else {
				 logger.error("合同废除失败,状态异常："+applyBillMainInfoDO.getState());
				 response = new RestResponse(MsgErrCode.FAIL);
			 }
		} catch (Exception e) {
			 logger.error("合同废除失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

}
