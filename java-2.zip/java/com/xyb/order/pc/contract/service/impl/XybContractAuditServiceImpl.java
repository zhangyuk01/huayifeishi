package com.xyb.order.pc.contract.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


import com.xyb.order.common.currency.service.TableModifyLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.base.util.JsonUtils;
import com.xyb.loan.finance.loan.service.LoanService;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyClientInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyJobInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.applybill.model.ApplyClientInfoDO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoOfJinBoAndCpfDO;
import com.xyb.order.pc.contract.contracttb.model.ContractResultDTO;
import com.xyb.order.pc.contract.contracttb.model.ContractTbBodyDTO;
import com.xyb.order.pc.contract.contracttb.model.ContractTbDTO;
import com.xyb.order.pc.contract.contracttb.model.ContractTbItem;
import com.xyb.order.pc.contract.contracttb.model.ContractTbItemDetail;
import com.xyb.order.pc.contract.contracttb.model.ContractTbItemDetailBaoDan;
import com.xyb.order.pc.contract.contracttb.model.ContractTbItemList;
import com.xyb.order.pc.contract.contracttb.model.XybContractTbDO;
import com.xyb.order.pc.contract.dao.XybContractAuditDao;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.InterfaceLogDO;
import com.xyb.order.pc.contract.model.XybContractAuditDO;
import com.xyb.order.pc.contract.model.XybContractAuditDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailVO;
import com.xyb.order.pc.contract.model.XybContractAuditListVO;
import com.xyb.order.pc.contract.model.XybContractAuditQueryDTO;
import com.xyb.order.pc.contract.model.XybContractAuditRecordDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.service.XybContractAuditService;
import com.xyb.order.pc.finance.FinanceBatchDetailsDO;
import com.xyb.order.pc.finance.FinancePaymentDO;
import com.xyb.order.pc.finance.dao.FinanceBatchDetailsDao;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.dao.SystemDao;
import com.xyb.order.common.currency.model.AuditCodeInfo;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.pc.ownuse.service.contract.XybContractOwnuseService;
import com.xyb.order.pc.ownuse.service.finance.FinanceOwnService;
import com.xyb.order.pc.ownuse.service.interfacelog.InterfaceLogOwnService;
import com.xyb.order.pc.product.model.ProductDO;
import com.xyb.risks.process.Rong360.model.GjjReport;
import com.xyb.risks.process.Rong360.model.ShebaoReport;
import com.xyb.risks.process.Rong360.service.Rong360Service;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.risks.process.juxinli.model.JuXinLiInterfaceData;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanSDReportDetail;
import com.xyb.risks.process.juxinli.service.JuXinLiBaoDanService;
import com.xyb.risks.process.mq.HandleInterface;
import com.xyb.risks.process.suanhua.model.SuanHuaReport;
import com.xyb.risks.process.suanhua.model.SuanhuaReportRiskCreditLoanNeeds;
import com.xyb.risks.process.suanhua.model.SuanhuaReportRiskDebts;
import com.xyb.risks.process.suanhua.model.SuanhuaReportRiskOverdues;
import com.xyb.risks.process.suanhua.service.SuanhuaService;
import com.xyb.util.SessionUtil;

import net.sf.json.JSONObject;

import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.common.constant.InterfaceLogConstants;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.ProductConstant;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.DateUtils;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.PosMainStart;
import com.xyb.order.common.util.SignMatchesUtil;
import com.xyb.order.common.util.StringUtils;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 合同审核实现
 * @createDate : 2018/4/18 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.XybContractAuditService")
public class XybContractAuditServiceImpl implements XybContractAuditService {
	
    private static final Logger logger = LoggerFactory.getLogger(XybContractAuditServiceImpl.class);

    /**
     * properties属性信息
     */
    @Value("${http.secret.key}")
    /**接口签名密钥(深圳)*/
    private String secretKey; 
    /**
     * properties属性信息
     */
    @Value("${sys.id}")
    /**接口签名密钥(深圳)*/
    private String sysId;
    
    @Value("${suanhua.report.url}")
    /**算话报告查询地址*/
    private String suanhuaReportUrl;
    
    @Value("${get.tb.state.info.url}")
    /**查询标的在深圳的实时状态接口地址*/
    private String getTbStateInfoUrl;
    /**
     * properties属性信息
     * 合同推标接口地址
     */
    @Value("${contract.tb.interface.url}")
    private String contractTbInterfaceUrl; 
    /**
     * properties属性信息
     * 代偿账户ID
     */
    @Value("${warranty.acctId}")
    private String warrantyAcctId; 
    @Autowired
    private XybContractAuditDao xybContractAuditDao;
    @Autowired
    private XybContractOwnuseService xybContractOwnuseService;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private InterfaceLogOwnService interfaceLogOwnService;
	@Autowired
	private FinanceOwnService financeOwnService;
	@Autowired
	private FinanceBatchDetailsDao financeBatchDetailsDao;
	@Reference
	private ForeignService foreignService;
	@Autowired
	private XybContractDao dao;
	@Reference
	private SuanhuaService suanhuaService;
	@Reference
	private Rong360Service rong360Service;
	@Autowired
	private ApplyJobInfoDao applyJobInfoDao;
	@Autowired
	private ApplyClientInfoDao applyClientInfoDao;
	@Autowired
	private ClinetUserModifyService clinetUserModifyService;
	@Reference
	private JuXinLiBaoDanService juXinLiBaoDanService;
	@Autowired
	private SystemDao systemDao;
	@Reference
	private LoanService loanService;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listContractAudit(Integer pageNumber, Integer pageSize, XybContractAuditQueryDTO xybContractAuditQueryDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 
			 xybContractAuditQueryDTO.getPage().setPageNumber(pageNumber);
			 xybContractAuditQueryDTO.getPage().setPageSize(pageSize);
			 xybContractAuditQueryDTO.setOrgId(loginUser.getDataOrgId());
			 xybContractAuditQueryDTO.setUserId(loginUser.getId());
		     List<XybContractAuditListVO> list = xybContractAuditDao.listContractAuditPage(xybContractAuditQueryDTO);
		     xybContractAuditQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,xybContractAuditQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("合同审核列表查询失败",e);
		     response = new RestResponse(MsgErrCode.FAIL,"合同审核列表查询失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateContractAudit(XybContractAuditDetailDTO xybContractAuditDetailDTO) {

		RestResponse response = null;
		try {
			/**1.查询申请相关信息*/
			XybContractAuditDetailVO xybContractAuditDetailVO = xybContractAuditDao.getXybContractAuditDetailVO(xybContractAuditDetailDTO);
			if(xybContractAuditDetailVO == null){
				xybContractAuditDetailVO = new XybContractAuditDetailVO();
			}
			
			/**2.查询合同相关信息*/
			XybContractDO xybContractDO = dao.getXybContractDO(xybContractAuditDetailDTO.getApplyId());
			
			/**3.查询图片类型集合*/
			
			/**4.查询合同审核信息*/
			XybContractAuditDO xybContractAuditDO = dao.getContractAuditDO(xybContractAuditDetailDTO.getApplyId());
			if(xybContractAuditDO != null && xybContractAuditDO.getIsTempSave().equals(SysDictEnum.YES.getCode())){
				xybContractAuditDetailVO.setXybContractAuditDO(xybContractAuditDO);
			}
			
			/**5.查询合同审核记录信息*/
			List<XybContractAuditRecordDO> xybContractAuditRecordDOs = xybContractAuditDao.listContractAuditRecordDO(xybContractAuditDetailDTO.getApplyId());
			xybContractAuditDetailVO.setXybContractAuditRecordDOs(xybContractAuditRecordDOs);
	        	    
			xybContractAuditDetailVO.setXybContractDO(xybContractDO);
			
	  		response = new RestResponse(MsgErrCode.SUCCESS,xybContractAuditDetailVO);
		} catch (Exception e) {
			logger.error("合同审核详情查询失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"合同审核详情查询失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse saveContractAudit(XybContractAuditDetailSaveDTO xybContractAuditDetailSaveDTO) {
		RestResponse response = null;
		try {
			 /**1.处理合同审核信息*/
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();

			 XybContractAuditDO xybContractAuditDONew = xybContractAuditDetailSaveDTO.getXybContractAuditDO();
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", xybContractAuditDONew.getApplyId());
			 XybContractAuditDO xybContractAuditDOOld = xybContractAuditDao.getXybContractAuditDO(map);
			 StringBuffer contractBackReasonName = new StringBuffer();
			 /**处理合同退回原因*/
			 if(StringUtils.isNotNullAndEmpty(xybContractAuditDONew.getBackReason())){
				if(xybContractAuditDONew.getBackReason().contains(",")){
					String[] reasons= xybContractAuditDONew.getBackReason().substring(1,xybContractAuditDONew.getBackReason().length()-1).split(",");
					for (int i = 0; i < reasons.length; i++) {
						if(i == reasons.length - 1){
							contractBackReasonName.append(SysDictEnum.getContractBackName(Long.valueOf(reasons[i])));
						}else {
							contractBackReasonName.append(SysDictEnum.getContractBackName(Long.valueOf(reasons[i]))).append(",");
						}
					}
				}else{
					contractBackReasonName.append(SysDictEnum.getContractBackName(Long.valueOf(xybContractAuditDONew.getBackReason().substring(1,xybContractAuditDONew.getBackReason().length()-1))));

				}
			 }
			 /**1.1不存在,进行insert,反之,update*/
			 if(xybContractAuditDOOld == null){
				 xybContractAuditDONew.setIsTempSave(SysDictEnum.YES.getCode());
				 xybContractAuditDONew.setCreateUser(userId);
				 xybContractAuditDONew.setCreateName(loginUser.getName());
				 xybContractAuditDONew.setModifyName(loginUser.getName());
				 xybContractAuditDONew.setModifyUser(userId);
				 if(xybContractAuditDONew.getContractAuditResult().equals(SysDictEnum.CONTRACT_AUDIT_TH.getCode())){
					 if(StringUtils.isNotNullAndEmpty(xybContractAuditDONew.getBackReason())){
						 xybContractAuditDONew.setBackReason(xybContractAuditDONew.getBackReason().substring(1,xybContractAuditDONew.getBackReason().length()-1));
					 }
				 }
				 xybContractAuditDONew.setBackReasonName(contractBackReasonName != null ? contractBackReasonName.toString() : null);
				 this.insertContractAudit(xybContractAuditDONew);
			 }else{
				 String oldData = JsonUtil.object2json(xybContractAuditDOOld);
				 xybContractAuditDOOld.setContractAuditRemark(xybContractAuditDONew.getContractAuditRemark());
				 if(xybContractAuditDONew.getContractAuditResult().equals(SysDictEnum.CONTRACT_AUDIT_TH.getCode())){
					 if(StringUtils.isNotNullAndEmpty(xybContractAuditDONew.getBackReason())){
						 xybContractAuditDOOld.setBackReason(xybContractAuditDONew.getBackReason().substring(1,xybContractAuditDONew.getBackReason().length()-1));
					 }
				 }
				 xybContractAuditDOOld.setRefuseReason(xybContractAuditDONew.getRefuseReason());
				 xybContractAuditDOOld.setContractAuditResult(xybContractAuditDONew.getContractAuditResult());
				 xybContractAuditDOOld.setModifyName(loginUser.getName());
				 xybContractAuditDOOld.setModifyUser(userId);
				 xybContractAuditDOOld.setBackReasonName(contractBackReasonName != null ? contractBackReasonName.toString() : null);
				 xybContractAuditDOOld.setIsTempSave(SysDictEnum.YES.getCode());
				 this.updateContractAudit(userId,oldData,xybContractAuditDOOld);
			 }
			 response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			 logger.error("合同审核暂存失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"合同审核暂存失败失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	public void updateContractAudit(Long userId,String oldData,XybContractAuditDO xybContractAuditDONew){
		/**1.对比是否需要修改,是：修改contract表,添加表修改日志*/
		boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,xybContractAuditDONew.getId(),TableConstant.T_XYB_CONTRACT_AUDIT, oldData,JsonUtil.object2json(xybContractAuditDONew));
		if(flag){
			xybContractAuditDao.updateContractAuditNotNull(xybContractAuditDONew);
		}
	}
	
	private void insertContractAudit(XybContractAuditDO xybContractAuditDO){
		xybContractAuditDao.insertContractAudit(xybContractAuditDO);
	}

	private void insertContractAudit(XybContractAuditDTO xybContractAuditDTO){
		xybContractAuditDao.insertContractAudit(xybContractAuditDTO);
	}
	@SuppressWarnings("unused")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitContractAudit(XybContractAuditDetailSubmitDTO xybContractAuditDetailSubmitDTO,String macAddr,String ipAddr) {
		RestResponse response = null;
		try {
			 /**1.处理合同审核信息*/
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();
			 
			 XybContractDO xybContractDO = dao.getXybContractDO(xybContractAuditDetailSubmitDTO.getXybContractAuditDTO().getApplyId());
			 String oldContractData = JsonUtil.object2json(xybContractDO);
			 XybContractAuditDTO xybContractAuditDTONew = xybContractAuditDetailSubmitDTO.getXybContractAuditDTO();
			 /**获取合同审核信息*/
			 Map<String, Object> map = new HashMap<>(2);
			 map.put("applyId", xybContractAuditDTONew.getApplyId());
			 XybContractAuditDO xybContractAuditDOOld = xybContractAuditDao.getXybContractAuditDO(map);
			 String oldData = null;
			 if(xybContractAuditDOOld != null){
				 oldData = JsonUtil.object2json(xybContractAuditDOOld);
			 }
			 /**获取主表信息*/
			 ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			 String oldMainInfoData = JsonUtil.object2json(applyBillMainInfoDO);
			 StringBuffer contractBackReasonName = new StringBuffer();
			 /**2.根据不同的审核结果处理对应的业务逻辑*/
			 if(xybContractAuditDTONew.getContractAuditResult().equals(SysDictEnum.CONTRACT_AUDIT_TH.getCode())){
				 /**2.1 合同退回*/
				 /**2.1.1  合同退回,更新流程状态*/
				 /**置为未暂存,合同退回提交之后再次进入合同审核,审核记录显示为空*/
				 xybContractAuditDTONew.setIsTempSave(SysDictEnum.NO.getCode());
				 
				 MainLogDTO mainLogDTO = new MainLogDTO();
				 mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_ENTRY);
				 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
				 mainLogDTO.setModifyUser(userId);
				 currencyDao.addMainLog(mainLogDTO);
					
				 applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_ENTRY);
				 applyBillMainInfoDO.setModifyTime(new Date());
				 applyBillMainInfoDO.setModifyUser(userId);
				 applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

				 String newData = JsonUtil.object2json(applyBillMainInfoDO);
				 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldMainInfoData,newData);
				 if(flag){
					 currencyDao.updateMainInFo(applyBillMainInfoDO);
				 }
				 /**处理合同退回原因*/
				String[] reasons= xybContractAuditDTONew.getBackReason().substring(1,xybContractAuditDTONew.getBackReason().length()-1).split(",");
				for (int i = 0; i < reasons.length; i++) {
					if(i == reasons.length - 1){
						contractBackReasonName.append(SysDictEnum.getContractBackName(Long.valueOf(reasons[i])));
					}else {
						contractBackReasonName.append(SysDictEnum.getContractBackName(Long.valueOf(reasons[i]))).append(",");
					}
				 }
				 xybContractAuditDTONew.setBackReason(xybContractAuditDTONew.getBackReason());
				 xybContractAuditDTONew.setBackReasonName(contractBackReasonName != null ? contractBackReasonName.toString() : null);

			     /**2.1.2更新合同表合同狀太*/
				 xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTDXG.getCode());
				 xybContractDO.setModifyName(loginUser.getName());
				 xybContractDO.setModifyTime(new Date());
				 xybContractDO.setModifyUser(userId);
				 xybContractOwnuseService.updateContractNotNull(userId,oldContractData,xybContractDO);
				 
			 }else if(xybContractAuditDTONew.getContractAuditResult().equals(SysDictEnum.CONTRACT_AUDIT_JD.getCode())){
				 /**2.2 合同拒贷*/
				 /**2.2.1  合同拒贷,更新流程状态*/
				 /**置为已暂存*/
				 xybContractAuditDTONew.setIsTempSave(SysDictEnum.YES.getCode());
				 
				 MainLogDTO mainLogDTO = new MainLogDTO();
				 mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
				 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
				 mainLogDTO.setModifyUser(userId);
				 currencyDao.addMainLog(mainLogDTO);
					
				 applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
				 applyBillMainInfoDO.setRefuseCode(xybContractAuditDTONew.getRefuseReason());
				 applyBillMainInfoDO.setRefuseValue(xybContractAuditDTONew.getRefuseReasonValue());
				 applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
				 applyBillMainInfoDO.setPrevious(NodeStateConstant.CONTRACT_REVIEW);
				 applyBillMainInfoDO.setModifyTime(new Date());
				 applyBillMainInfoDO.setModifyUser(userId);
				 applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

				 String newData = JsonUtil.object2json(applyBillMainInfoDO);
				 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldMainInfoData,newData);
				 if(flag){
					 currencyDao.updateMainInFo(applyBillMainInfoDO);
				 }
			     /**2.2.2更新合同表合同狀太*/
				 xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTJD.getCode());
				 xybContractDO.setModifyName(loginUser.getName());
				 xybContractDO.setModifyTime(new Date());
				 xybContractDO.setModifyUser(userId);
				 xybContractOwnuseService.updateContractNotNull(userId,oldContractData,xybContractDO);
				 
				 /**2.2.3更新applybillInfo 拒贷信息*/
				 Map<String, Object> applyBillMap = new HashMap<>(5);
				 applyBillMap.put("id", applyBillMainInfoDO.getApplyId());
				 applyBillMap.put("isRefuse", SysDictEnum.YES.getCode());
				 applyBillMap.put("refuseNode", SysDictEnum.JD_NODE_HTSHJD.getCode());
				 applyBillMap.put("refuseCode", String.valueOf(xybContractAuditDTONew.getRefuseReason()));
				 applyBillInfoDao.updateApplyInfoOnlyNeed(applyBillMap);
				 
				 /**2.2.4重置用户可进件时长*/
				 AuditCodeInfo auditCodeInfo = systemDao.getAuditCodeInfo(xybContractAuditDTONew.getRefuseReason());
				 clinetUserModifyService.updateClientAllowableEntryTime(applyBillMainInfoDO.getClientId(), auditCodeInfo.getRefuseNotorerDays());
			 }else if(xybContractAuditDTONew.getContractAuditResult().equals(SysDictEnum.CONTRACT_AUDIT_TG.getCode())){
				 String resultCode = "";
				 /**置为已暂存*/
				 xybContractAuditDTONew.setIsTempSave(SysDictEnum.YES.getCode());
				 /**2.3合同审核通过,推标到深圳*/
				 /**2.3.1获取基本数据*/
				 XybContractTbDO xybContractTbDO = xybContractAuditDao.getXybContractTbDO(xybContractDO.getApplyId());
				 ApplyClientInfoDO applyClientInfoDO = applyClientInfoDao.queryClientInfoByMainId(applyBillMainInfoDO.getId());
				 ApplyJobInfoOfJinBoAndCpfDO applyJobInfoOfJinBoAndCpfDO = applyJobInfoDao.queryJobInfoOfJinBoAndCpfByMainId(applyBillMainInfoDO.getId());
				 /**2.3.2封装推标数据*/
				 ContractTbDTO contractTbDTO = this.geContractTbDTO(xybContractDO, applyClientInfoDO, applyJobInfoOfJinBoAndCpfDO,applyBillMainInfoDO,macAddr,ipAddr);
				 /**2.4向深圳推标*/
				 /**2.4.1参数转换*/
			      /**根据日志记录判断是否已成功推过深圳,若已成功推过,直接按成功处理业务(业务场景：推送深圳成功,返回后系统处理业务数据失败,单子在列表中还可以再次推送的情况),反之正常逻辑*/
				 Map<String, Object> interfaceMap = new HashMap<>();
				 interfaceMap.put("applyId", applyBillMainInfoDO.getApplyId());
				 interfaceMap.put("interfaceName", InterfaceLogConstants.INTERFACE_CONTRACT_TB);
				 List<InterfaceLogDO> logs = interfaceLogOwnService.queryInterfaceLogs(interfaceMap);
				 /**是否已推送成功过*/
				 boolean isSendSuccess = false;
				 for (int i = 0; i < logs.size(); i++) {
					/**解析成指定model*/
					ContractResultDTO contractResultDTO = JsonUtils.fromJSON(logs.get(i).getResponse(), ContractResultDTO.class);
					if(contractResultDTO != null){
					    if(contractResultDTO.getCode().equals(SysConstants.INTERFACE_SUCCESS)){
					    	/**获取推标历史日志记录最新的返回code码*/
					    	String oldResultCode = contractResultDTO.getBody().getItems().get(0).getCode();
					    	if(SysConstants.INTERFACE_SUCCESS.equals(oldResultCode)){
								/**返回码等于业务处理成功,已推送状态置为true*/
								isSendSuccess = true;
								break;
					    	}
					    }
					}
				 }
				 /**未推送成功过,调用推送接口*/
				 String result = null;
				 JSONObject resultJson = null;
				 ContractResultDTO contractResultDTO = null;
				 if(!isSendSuccess){
			    	/**2.4.2调用推标接口*/
			    	try {
					      /**进行指定字段加签*/
						String sign = SignMatchesUtil.signEncode(contractTbDTO, secretKey);
						logger.info("申请单号："+xybContractTbDO.getApplyId()+",加签后结果:"+sign);
						contractTbDTO.setSign(sign);
						String dataJson = JsonUtils.toJSON(contractTbDTO);
					    result = this.sendPost(applyBillMainInfoDO, dataJson);
					    contractResultDTO = JsonUtils.fromJSON(result, ContractResultDTO.class);
					    if(contractResultDTO != null){
					    	/**对返回结果进行验签通过后再进行后续处理*/
					    	Boolean rspSign = SignMatchesUtil.matches(contractResultDTO, secretKey, contractResultDTO.getSign());
					    	if(rspSign){
						    	if(SysConstants.INTERFACE_SUCCESS.equals(contractResultDTO.getCode())){
						    		resultCode = contractResultDTO.getBody().getItems().get(0).getCode();
						    	}else{
								    resultCode = contractResultDTO.getCode();
						    	}
					    	}else{
								logger.info("推标结果返回进行验签失败");
								response = new RestResponse(MsgErrCode.FAIL,"验签失败");
								TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
						    	return response;
					    	}
					    }
					} catch (Exception e) {
						logger.error("调用深圳推标接口处理失败",e);
				    	response = new RestResponse(MsgErrCode.FAIL);
						TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				    	return response;
					}
				 }
			    /**未推送成功过且返回接口状态码为成功 或 已推送成功过 都按成功处理业务,反之按失败处理*/
			    if((!isSendSuccess && resultCode.equals(SysConstants.INTERFACE_SUCCESS)) || (isSendSuccess)){
			    	/**2.5返回成功,处理业务*/
			    	/**深圳线上*/
			    	xybContractAuditDTONew.setIsLine(SysDictEnum.YES.getCode());
			    	
					/**2.5.1生成合同待交易表数据*/
			    	FinancePaymentDO financePaymentDO = financeOwnService.setPaymentByOut(loginUser.getId(), xybContractDO,applyBillMainInfoDO);
			    	resultCode = SysConstants.INTERFACE_SUCCESS;

			    	/**2.5.2生成批次明细数据*/
		            FinanceBatchDetailsDO financeBatchDetailsDO = new FinanceBatchDetailsDO();
		            /** 合同待支付表ID*/
		            financeBatchDetailsDO.setRepaymentId(financePaymentDO.getId()); 
		            /** 合同ID*/
		            financeBatchDetailsDO.setContractId(financePaymentDO.getContractId());
		            /** 银行类别*/
		            financeBatchDetailsDO.setBankType(financePaymentDO.getBankType());
		            /** 账户名*/
		            financeBatchDetailsDO.setBankAccount(financePaymentDO.getBankAccount());
		            /** 银行账号*/
		            financeBatchDetailsDO.setRefundCardNum(financePaymentDO.getRefundCardNum());
		            /** 金额*/
		            financeBatchDetailsDO.setAmount(financePaymentDO.getTotalAmount());
		            /** 状态*/
		            financeBatchDetailsDO.setState(SysDictEnum.PAY_MENT_DETAILS_DCL.getCode());
		            /** 创建时间*/
		            financeBatchDetailsDO.setCreateTime(new Date());
		            /** 创建人*/
		            financeBatchDetailsDO.setCreateUser(loginUser.getId());
		            financeBatchDetailsDO.setClientIdcard(xybContractDO.getClientIdcard());
		            financeBatchDetailsDO.setMp(xybContractDO.getMp());
		            financeBatchDetailsDO.setOrgId(xybContractDO.getStoreOrgId());

			        /**批量插入批次明细*/
			        financeBatchDetailsDao.addFinanceBatchDetails(financeBatchDetailsDO);
			        
			        /**更新合同信息,若产品为优信借且更新合同违约金比例,罚息比例*/
			        if(applyBillMainInfoDO.getAgreeProductId().equals(ProductConstant.YOU_XIN_JIE_ID)){
			        	ProductDO product = dao.getProduct(applyBillMainInfoDO.getAgreeProductId());
			        	xybContractDO.setBreachProportion(product.getBreach_proportion());
			        	xybContractDO.setFineProportion(product.getFine_proportion());
			        }
			        xybContractDO.setTbState(SysDictEnum.TB_STATE_TBCG.getCode());
			        xybContractDO.setModifyUser(loginUser.getId());
			        xybContractDO.setModifyTime(new Date());
			        xybContractDO.setPushTime(new Date());
				    xybContractOwnuseService.updateContractNotNull(userId,oldContractData,xybContractDO);
			        /**更新流程状态为深圳资金募集中*/
					 
					MainLogDTO mainLogDTO = new MainLogDTO();
					mainLogDTO.setBusinessState(NodeStateConstant.IN_THE_BID);
					mainLogDTO.setMainId(applyBillMainInfoDO.getId());
					mainLogDTO.setModifyUser(userId);
				    currencyDao.addMainLog(mainLogDTO);
						
					applyBillMainInfoDO.setState(NodeStateConstant.IN_THE_BID);
					applyBillMainInfoDO.setModifyTime(new Date());
					applyBillMainInfoDO.setModifyUser(userId);

					String newData = JsonUtil.object2json(applyBillMainInfoDO);
					boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldMainInfoData,newData);
					if(flag){
						currencyDao.updateMainInFo(applyBillMainInfoDO);
					}
			    }else{
			    	response = new RestResponse(MsgErrCode.FAIL);
			    	if(contractResultDTO != null && SysConstants.INTERFACE_SUCCESS.equals(contractResultDTO.getCode())){
			    		response.setDescription(contractResultDTO.getBody().getItems().get(0).getMessage());
			    	}
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			    	return response;
				}
			}
			/**3 处理合同审核信息,不存在,进行insert,反之,update*/
			if(xybContractAuditDOOld == null){
				xybContractAuditDTONew.setContractId(xybContractDO.getId());
				xybContractAuditDTONew.setApplyId(applyBillMainInfoDO.getApplyId());
				xybContractAuditDTONew.setCreateUser(userId);
				xybContractAuditDTONew.setModifyUser(userId);
				this.insertContractAudit(xybContractAuditDTONew);
			}else{
				xybContractAuditDOOld.setIsTempSave(xybContractAuditDTONew.getIsTempSave());
				xybContractAuditDOOld.setContractAuditRemark(xybContractAuditDTONew.getContractAuditRemark());
				xybContractAuditDOOld.setBackReason(xybContractAuditDTONew.getBackReason());
				xybContractAuditDOOld.setBackReasonName(xybContractAuditDTONew.getBackReasonName());
				xybContractAuditDOOld.setRefuseReason(xybContractAuditDTONew.getRefuseReason());
				xybContractAuditDOOld.setContractAuditResult(xybContractAuditDTONew.getContractAuditResult());
				xybContractAuditDOOld.setModifyName(loginUser.getName());
				xybContractAuditDOOld.setModifyUser(userId);
				xybContractAuditDOOld.setModifyTime(new Date());
				this.updateContractAudit(userId,oldData,xybContractAuditDOOld);
			}
			 /**4处理合同审核记录相关信息*/
			 XybContractAuditRecordDO xybContractAuditRecordDO = new XybContractAuditRecordDO();
			 xybContractAuditRecordDO.setApplyId(applyBillMainInfoDO.getApplyId());
			 xybContractAuditRecordDO.setContractId(xybContractDO.getId());
		     xybContractAuditRecordDO.setContractAuditId(xybContractAuditDOOld == null ? xybContractAuditDTONew.getId() : xybContractAuditDOOld.getId());
			 xybContractAuditRecordDO.setDisposeResult(SysDictEnum.getContractAuditName(xybContractAuditDTONew.getContractAuditResult()));
			 xybContractAuditRecordDO.setRecordInfo(xybContractAuditDTONew.getContractAuditRemark());
			 xybContractAuditRecordDO.setRecordName(loginUser.getName());
			 xybContractAuditRecordDO.setCreateUser(userId);
			 xybContractAuditRecordDO.setModifyUser(userId);
			 xybContractAuditRecordDO.setBackReason(xybContractAuditDTONew.getBackReason());
			 xybContractAuditRecordDO.setBackReasonName(xybContractAuditDTONew.getBackReasonName());
			 xybContractAuditRecordDO.setRefuseReason(xybContractAuditDTONew.getRefuseReason());
			 xybContractAuditDao.insertXybContractAuditRecord(xybContractAuditRecordDO);
			 response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			 logger.error("合同审核提交失败",e);
			 response = new RestResponse(MsgErrCode.FAIL,"合同审核提交失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	/**
	 * 封装推标数据
	 * @param xybContractDO
	 * @param applyClientInfoDO
	 * @param applyJobInfoOfJinBoAndCpfDO
	 * @param applyBillMainInfoDO
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	private  ContractTbDTO geContractTbDTO(XybContractDO xybContractDO,ApplyClientInfoDO applyClientInfoDO,ApplyJobInfoOfJinBoAndCpfDO applyJobInfoOfJinBoAndCpfDO,ApplyBillMainInfoDO applyBillMainInfoDO,String macAddr,String ipAddr) throws Exception{
		 /**调用风控服务获取信用评分*/
		 Integer score = (Integer) this.foreignService.getScoreOfShenzhenpingfen(String.valueOf(xybContractDO.getApplyId())).get("score");
		 /**调用风控服务获取算话信息*/
		 SuanHuaReport suanHuaReport = this.suanhuaService.suanhuaCreditReportQuery(String.valueOf(xybContractDO.getApplyId()));
		 /**调用风控服务获取社保信息*/
		 ShebaoReport shebaoReport = this.foreignService.shebaoReportOfOrder(String.valueOf(xybContractDO.getApplyId()), "gd");
		 /**调用风控服务获取公积金信息*/
		 GjjReport gjjReport = this.foreignService.gjjReportOfOrder(String.valueOf(xybContractDO.getApplyId()), "gd");
		 /**调用风控服务获取聚信立保单信息*/
		 HandleInterface handleInterface = new HandleInterface();
		 handleInterface.setApplyId(String.valueOf(xybContractDO.getApplyId()));
		 handleInterface.setSysId("gd");
		 List<JuXinLiBaoDanSDReportDetail> juXinLiBaoDanAppInDatas = this.juXinLiBaoDanService.getJuXinLiBaoDanSDReport(handleInterface);
		 /**调用风控服务获取聚信立运营商信息*/
		 JuXinLiInterfaceData juXinLiInterfaceData = this.foreignService.getJuXinLiDataForGD(String.valueOf(xybContractDO.getApplyId()));
		 /**一:封装图片信息*/
		 /**添加附件集合数据*/
		 /**1.信用报告图片集合(算话报告)*/
		 List<ContractTbItemList> creditReportList = new LinkedList<>();
		 ContractTbItemList reportItem = new ContractTbItemList();
		 reportItem.setApplyId(String.valueOf(xybContractDO.getApplyId()));
		 reportItem.setUrl(suanhuaReportUrl + String.valueOf(xybContractDO.getApplyId()));
		 creditReportList.add(reportItem);
		 /**2.工作证明图片集合*/
		 List<ContractTbItemList> workList = new LinkedList<>();
		 /**3.收入(居住)证明图片集合*/
		 List<ContractTbItemList> incomeList = new LinkedList<>();
		 /**4.身份证图片集合*/
		 List<ContractTbItemList> idCardList = new LinkedList<>();
		 ContractTbItemList idCardFront = new ContractTbItemList();
		 idCardFront.setApplyId(String.valueOf(xybContractDO.getApplyId()));
		 idCardFront.setUrl(applyClientInfoDO.getIdcardFrontSide());
		 ContractTbItemList idCardBack = new ContractTbItemList();
		 idCardBack.setApplyId(String.valueOf(xybContractDO.getApplyId()));
		 idCardBack.setUrl(applyClientInfoDO.getIdcardBackSide());
		 idCardList.add(idCardFront);
		 idCardList.add(idCardBack);
		 /**5.自我推荐图片集合*/
		 List<ContractTbItemList> selfRecommendURLList = new LinkedList<>();
		 List<Map<String,Object>> xybDataInfoList = xybContractAuditDao.getPicsByApplyId(xybContractDO.getApplyId());
		 if(null!=xybDataInfoList && xybDataInfoList.size()>0){
		    for(Map<String,Object> model:xybDataInfoList){
		    	    ContractTbItemList contractTbItemList = new ContractTbItemList();
		    		String fileCode = (String) model.get("fileCode");
		    		String picurl = (String) model.get("picPath");
	    			contractTbItemList.setApplyId(String.valueOf(xybContractDO.getApplyId()));
	    			contractTbItemList.setUrl(picurl);
	    			/**设置附件类型码  0:信用报告,1:工作证明,2:收入证明,3:居住证明,5:借款人身份证*/
	    			if(fileCode.equals(SysDictEnum.IMAGE_TYPE_GZZM.getName())){
	    				/**工作证明*/
	    				workList.add(contractTbItemList);
		    		}else if(fileCode.equals(SysDictEnum.IMAGE_TYPE_GRSRZM.getName()) || fileCode.equals(SysDictEnum.IMAGE_TYPE_QYSRZM.getName())){
		    			/**收入证明,居住证明*/
		    			incomeList.add(contractTbItemList);
		    		}else if(fileCode.equals(SysDictEnum.IMAGE_TYPE_ZWTJ.getName())){
		    			/**自我推荐图片*/
		    			selfRecommendURLList.add(contractTbItemList);
		    		}
		    }
		 }
		 /**5.披露信息图片集合*/
		 List<ContractTbItemList> announceURLList = new ArrayList<>();
		 List<Map<String,Object>> announcePics = xybContractAuditDao.getAnnouncePicsByApplyId(xybContractDO.getApplyId());
		 if(null!=announcePics && announcePics.size()>0){
			    for(Map<String,Object> model:announcePics){
			    	    ContractTbItemList contractTbItemList = new ContractTbItemList();
			    		String fileCode = (String) model.get("fileCode");
			    		String picurl = (String) model.get("picPath");
		    			contractTbItemList.setApplyId(String.valueOf(xybContractDO.getApplyId()));
		    			contractTbItemList.setUrl(picurl);
		    			announceURLList.add(contractTbItemList);
			    }
		 }
		 /**二：查询推标item主数据*/
		 ContractTbItem contractTbItem = xybContractAuditDao.getContractTbItem(xybContractDO.getApplyId());
		 contractTbItem.setScore(score);
		 contractTbItem.setWarrantyAcctId(Long.parseLong(warrantyAcctId));
		 
		 /**三：查询推标detail详情数据*/
		 ContractTbItemDetail contractTbItemDetail = xybContractAuditDao.getContractTbItemDetail(xybContractDO.getApplyId());
		 contractTbItemDetail.setXybScore(score.toString());
		   /**处理详情数据:
		    * 1.月利率%*/
		 contractTbItemDetail.setInterestRate(contractTbItem.getRate().multiply(new BigDecimal(100)).setScale(5, BigDecimal.ROUND_HALF_UP));
		 /**年利率*/
		 contractTbItem.setRate(contractTbItem.getRate().multiply(new BigDecimal(12)).setScale(5, BigDecimal.ROUND_HALF_UP));
		   /**2.算话征信相关字段*/
			/** 有无其他信用贷款 */
		 String otherLoan = "N";
		 if ((suanHuaReport != null) && (suanHuaReport.getGeneral() != null)) {
			 if((suanHuaReport.getGeneral().getMortgageTotal() > 0 || suanHuaReport.getGeneral().getOtherloanTotal() > 0)){
				 otherLoan = "Y";
			 }
			 /**是否有信用卡*/
			 contractTbItemDetail.setCreditCard(suanHuaReport.getGeneral().getCreditTotal() != null && suanHuaReport.getGeneral().getCreditTotal() > 0 ? "Y":"N");
			 /**未销户信用卡数量*/
			 contractTbItemDetail.setCreditNum(suanHuaReport.getGeneral().getCreditActive());
		 }
		 contractTbItemDetail.setOtherLoan(otherLoan);
		 if(suanHuaReport != null ){
			 if(suanHuaReport.getDebts() != null){
				 SuanhuaReportRiskDebts suanhuaReportRiskDebts = suanHuaReport.getDebts();
				 /**信用卡额度*/
				 contractTbItemDetail.setCreditLimit(suanhuaReportRiskDebts.getCreditLimitTotal());
				 /**征信报告代偿银行贷款笔数(未结清贷款总笔数)*/
				 contractTbItemDetail.setReportWaitLoanNum(suanhuaReportRiskDebts.getLoanBalanceCounts());
				 /**征信报告代偿银行贷款总金额(贷款余额)*/
				 contractTbItemDetail.setReportWaitLoanAmt(suanhuaReportRiskDebts.getLoanBalances());
				 /**信用卡已使用额度*/
				 Double creditlimitUsed = suanhuaReportRiskDebts.getCreditLimitUsed() != null ? Double.valueOf(suanhuaReportRiskDebts.getCreditLimitUsed()) : 0.0;
				 /**贷款余额*/
				 Double loanBalances = suanhuaReportRiskDebts.getLoanBalances() != null ? Double.valueOf(suanhuaReportRiskDebts.getLoanBalances()) : 0.0;
				 /**负债金额=信用卡已使用额度+贷款余额*/
				 contractTbItemDetail.setCurrLiabilities(creditlimitUsed + loanBalances);
				 /**信用卡额度使用率*/
				 contractTbItemDetail.setCreditLimitUseRate(suanhuaReportRiskDebts.getCreditLimitUseRate());
				 /**月还贷款总额*/
				 contractTbItemDetail.setLoanBalancesMonth(suanhuaReportRiskDebts.getLoanBalancesMonth());
				 /**月还房贷金额*/
				 contractTbItemDetail.setLoanBalancesMortgageMonth(suanhuaReportRiskDebts.getLoanBalancesMortgageMonth());
				 /**月还车贷金额*/
				 contractTbItemDetail.setLoanBalancesCarMonth(suanhuaReportRiskDebts.getLoanBalancesCarMonth());
				 /**月还其它贷款总余额*/
				 contractTbItemDetail.setLoanBalancesOtherMonth(suanhuaReportRiskDebts.getLoanBalancesOtherMonth());
			 }
			 if(suanHuaReport.getOverdues() != null){
				 SuanhuaReportRiskOverdues suanhuaReportRiskOverdues = suanHuaReport.getOverdues();
				 /** 征信报告严重逾期次数 */
				 contractTbItemDetail.setSeriousOverdueNum(suanhuaReportRiskOverdues.getCountsM60D90());
				 /**征信报告逾期次数*/
				 contractTbItemDetail.setReportOverdueNum(suanhuaReportRiskOverdues.getCountsM60());
				 /** 逾期金额=信用卡当前逾期总金额+贷款当前逾期总金额 */
				 BigDecimal reportOverdueAmt = BigDecimal.ZERO;
				 /** 信用卡当前逾期总金额 */
				 BigDecimal creditAmts = BigDecimal.ZERO;
				 if (suanhuaReportRiskOverdues.getCreditAmts() != null) {
					creditAmts = new BigDecimal(suanhuaReportRiskOverdues.getCreditAmts());
				 }
				 /** 贷款当前逾期总金额 */
				 BigDecimal loanAmts = BigDecimal.ZERO;
				 if (suanhuaReportRiskOverdues.getLoanAmts() != null) {
					loanAmts = new BigDecimal(suanhuaReportRiskOverdues.getLoanAmts());
				 }
				 reportOverdueAmt = creditAmts.add(loanAmts).setScale(2, BigDecimal.ROUND_HALF_UP);
				 contractTbItemDetail.setReportOverdueAmt(reportOverdueAmt);
				 contractTbItemDetail.setCreditOverAmts(creditAmts);
				 /**信用卡60个月内逾期超过90天的次数(月数)*/
				 contractTbItemDetail.setCreditCountsM60D90(suanhuaReportRiskOverdues.getCreditCountsM60D90());
				 /**贷款60个月内逾期超过90天的次数(月数)*/
				 contractTbItemDetail.setLoanCountsM60D90(suanhuaReportRiskOverdues.getLoanCountsM60D90());
			 }
			 if(suanHuaReport.getCreditLoanNeeds() != null){
				 SuanhuaReportRiskCreditLoanNeeds suanhuaReportRiskCreditLoanNeeds = suanHuaReport.getCreditLoanNeeds();
				 contractTbItemDetail.setSelfQueriesM3(suanhuaReportRiskCreditLoanNeeds.getSelfQueriesM3());
				 contractTbItemDetail.setLoanQueriesM3(suanhuaReportRiskCreditLoanNeeds.getLoanQueriesM3());
			 }
		 }
		 contractTbItemDetail.setCreditReportURLList(creditReportList);
		 contractTbItemDetail.setWorkProveURLList(workList.size() > 0 ? workList : null);
		 contractTbItemDetail.setIncomeProveURLList(incomeList.size() > 0 ? incomeList : null);
		 contractTbItemDetail.setLiveProveURLList(incomeList.size() > 0 ? incomeList : null);
		 contractTbItemDetail.setIdcardURLList(idCardList);
		 contractTbItemDetail.setAnnounceURLList(announceURLList.size() > 0 ? announceURLList : null);
		 contractTbItemDetail.setSelfRecommendURLList(selfRecommendURLList.size() > 0 ? selfRecommendURLList : null);
		 contractTbItemDetail.setCreditRisk("暂无");
		 contractTbItemDetail.setPolicyRisk("暂无");
		 contractTbItemDetail.setMarketRisk("暂无");
		 String yearIncome = contractTbItemDetail.getYearIncome().contains(".") ? contractTbItemDetail.getYearIncome().substring(0,contractTbItemDetail.getYearIncome().indexOf(".")) : contractTbItemDetail.getYearIncome();
		 contractTbItemDetail.setIncomeLevel(new BigDecimal(contractTbItemDetail.getYearIncome()).multiply(new BigDecimal(10000)).divide(new BigDecimal(12),0, BigDecimal.ROUND_HALF_UP).toString());
		 contractTbItemDetail.setYearIncome(new BigDecimal(contractTbItemDetail.getYearIncome()).multiply(new BigDecimal(10000)).setScale(2, BigDecimal.ROUND_HALF_UP).toString());
		   /**公积金数据*/
		 if(gjjReport != null && gjjReport.getGjjBaseInfo() != null){
			 contractTbItemDetail.setFundStatus("正常缴纳");
			 contractTbItemDetail.setFundCity(gjjReport.getGjjBaseInfo().getFund_city());
			 contractTbItemDetail.setFundBaseMoney(gjjReport.getGjjBaseInfo().getFund_base_money());
			 contractTbItemDetail.setFundMonthMoney(gjjReport.getGjjBaseInfo().getFund_month_money());
			 contractTbItemDetail.setGjjComName(StringUtils.isNotNullAndEmpty(gjjReport.getGjjBaseInfo().getCom_name()) ? StringUtils.getCompName(gjjReport.getGjjBaseInfo().getCom_name()) : null);
			 /**公积金当前公司缴存时长*/
			 Integer paySize =  gjjReport.getGjjPayList().stream().filter(payList -> payList.getCom_name().equals(gjjReport.getGjjBaseInfo().getCom_name())).collect(Collectors.toList()).size();
			 contractTbItemDetail.setCpfDuration(paySize != null ? String.valueOf(paySize) : null);
		 }else if(applyJobInfoOfJinBoAndCpfDO.getJinpoRecord() != null && (applyJobInfoOfJinBoAndCpfDO.getJinpoRecord().equals(SysDictEnum.SHEBAO_TYPE_ONE.getCode()) || applyJobInfoOfJinBoAndCpfDO.getJinpo().equals(SysDictEnum.SHEBAO_TYPE_TWO.getCode()))){
			 contractTbItemDetail.setFundStatus("正常缴纳");
			 contractTbItemDetail.setFundBaseMoney(applyJobInfoOfJinBoAndCpfDO.getCpfBase() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getCpfBase()) : null);
			 contractTbItemDetail.setFundMonthMoney(applyJobInfoOfJinBoAndCpfDO.getCpfMonth() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getCpfMonth()) : null);
			 contractTbItemDetail.setGjjComName(StringUtils.isNotNullAndEmpty(applyJobInfoOfJinBoAndCpfDO.getCpfCompany())  ? StringUtils.getCompName(applyJobInfoOfJinBoAndCpfDO.getCpfCompany()) : null);
			 contractTbItemDetail.setCpfDuration(applyJobInfoOfJinBoAndCpfDO.getCpfDuration() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getCpfDuration()) : null);
		 }else {
			 contractTbItemDetail.setFundStatus("暂无");
		 }
		   /**社保数据*/
		 if(shebaoReport != null && shebaoReport.getShebaoBaseInfo() != null){
			 contractTbItemDetail.setInsureStatus("正常缴纳");
			 contractTbItemDetail.setInsureCity(shebaoReport.getShebaoBaseInfo().getInsure_city());
			 contractTbItemDetail.setBaseRmb(shebaoReport.getShebaoPayList() != null && shebaoReport.getShebaoPayList().size() > 0 ? shebaoReport.getShebaoPayList().get(0).getBase_rmb() : "0");
			 contractTbItemDetail.setInsureMonthMoney(shebaoReport.getShebaoBaseInfo().getInsure_month_money());
			 contractTbItemDetail.setInsureComName(StringUtils.isNotNullAndEmpty(shebaoReport.getShebaoBaseInfo().getCom_name()) ? StringUtils.getCompName(shebaoReport.getShebaoBaseInfo().getCom_name()) : null);
			 contractTbItemDetail.setJinpoDuration(applyJobInfoOfJinBoAndCpfDO.getJinpoDuration() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getJinpoDuration()) : null);
		 }else if(applyJobInfoOfJinBoAndCpfDO.getCpfRecord() != null && (applyJobInfoOfJinBoAndCpfDO.getCpfRecord().equals(SysDictEnum.GJJ_TYPE_ONE.getCode()) || applyJobInfoOfJinBoAndCpfDO.getCpfRecord().equals(SysDictEnum.GJJ_TYPE_TWO.getCode()))){
			 contractTbItemDetail.setInsureStatus("正常缴纳");
			 contractTbItemDetail.setBaseRmb(applyJobInfoOfJinBoAndCpfDO.getJinpoBase() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getJinpoBase()) : null);
			 contractTbItemDetail.setInsureMonthMoney(applyJobInfoOfJinBoAndCpfDO.getJinpoMonth() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getJinpoMonth()) : null);
			 contractTbItemDetail.setInsureComName(StringUtils.isNotNullAndEmpty(applyJobInfoOfJinBoAndCpfDO.getJinpoCompany()) ? StringUtils.getCompName(applyJobInfoOfJinBoAndCpfDO.getJinpoCompany()) : null);
			 contractTbItemDetail.setJinpoDuration(applyJobInfoOfJinBoAndCpfDO.getJinpoDuration() != null ? String.valueOf(applyJobInfoOfJinBoAndCpfDO.getJinpoDuration()) : null);
		 }else {
			 contractTbItemDetail.setInsureStatus("暂无");
		 }
		 /**封装保单信息*/
		 List<ContractTbItemDetailBaoDan> baoDans = null;
		 for (int i = 0; i < juXinLiBaoDanAppInDatas.size(); i++) {
			baoDans = new ArrayList<>();
			JuXinLiBaoDanSDReportDetail juXinLiBaoDanSDReportDetail = juXinLiBaoDanAppInDatas.get(i);
			ContractTbItemDetailBaoDan contractTbItemDetailBaoDan = new ContractTbItemDetailBaoDan();
			contractTbItemDetailBaoDan.setCompany(juXinLiBaoDanSDReportDetail.getCompany());
			contractTbItemDetailBaoDan.setPaymentPolicyStartDate(DateUtils.formatTime(juXinLiBaoDanSDReportDetail.getPaymentPolicyStartDate()));
			contractTbItemDetailBaoDan.setPaymentType(juXinLiBaoDanSDReportDetail.getPaymentFrequency());
			contractTbItemDetailBaoDan.setPaymentYearSum(juXinLiBaoDanSDReportDetail.getPaymentYear() != null ? String.valueOf(juXinLiBaoDanSDReportDetail.getPaymentYear()) : "0");
			baoDans.add(contractTbItemDetailBaoDan);
		 }
		 contractTbItemDetail.setBaoDanList(baoDans);
		 /**封装聚信立运营商信息*/
		 contractTbItemDetail.setPhoneUsedTime(juXinLiInterfaceData.getPhoneUsedTime());
		 contractTbItemDetail.setAvgAmountM6(juXinLiInterfaceData.getAvgAmountM6());
		 String friendAndAddress = null;
		 if(juXinLiInterfaceData.getFriendAndAddress() != null){
			 if(juXinLiInterfaceData.getFriendAndAddress().contains("非居住地")){
				 friendAndAddress = "不一致";
			 }else if (juXinLiInterfaceData.getFriendAndAddress().contains("居住地") && !juXinLiInterfaceData.getFriendAndAddress().contains("非居住地")){
				 friendAndAddress = "一致";
			 }else {
				friendAndAddress = "未知";
			}
		 }
		 contractTbItemDetail.setFriendAndAddress(friendAndAddress);
		 contractTbItemDetail.setCourtBlack(juXinLiInterfaceData.getCourtBlack());
		 contractTbItemDetail.setCourtContactCourt(juXinLiInterfaceData.getCourtContactCourt());
		 contractTbItemDetail.setFinancialBlack(juXinLiInterfaceData.getFinancialBlack());
		 contractTbItemDetail.setPhoneGrayScore(juXinLiInterfaceData.getPhoneGrayScore());
		 contractTbItemDetail.setContactsClass1BlacklistCnt(juXinLiInterfaceData.getContactsClass1BlacklistCnt());
		 /**封装风险相关数据*/
		 contractTbItemDetail.setRiskBid("Y");
		 contractTbItemDetail.setRiskLevel(applyBillMainInfoDO.getServiceProportionType());
		 /**封装推荐语和银行4要素数据*/
		 contractTbItemDetail.setDcRecommendText(xybContractDO.getDcRecommendText());
//		 contractTbItemDetail.setBankType(xybContractDO.getBankType());
//		 contractTbItemDetail.setBankAccount(xybContractDO.getBankAccount());
//		 contractTbItemDetail.setBankCardNum(xybContractDO.getRefundCardNum());
//		 contractTbItemDetail.setBankMp(xybContractDO.getMp());
		 contractTbItem.setDetail(JsonUtils.toJSON(contractTbItemDetail));
		 /**添加contractTbDTO数据*/
		 ContractTbDTO contractTbDTO = new ContractTbDTO();
		 ContractTbBodyDTO contractTbBodyDTO = new ContractTbBodyDTO();
		 /**获取ip和mac地址*/
		 contractTbBodyDTO.setClient(SysConstants.BORROWER);
		 contractTbBodyDTO.setCustom(SysConstants.WEB);
		 contractTbBodyDTO.setClient_ip(ipAddr);
		 contractTbBodyDTO.setClient_service(macAddr);
		 contractTbBodyDTO.setSysId(Long.parseLong(sysId));
		 List<ContractTbItem> items = new ArrayList<>();
		 items.add(contractTbItem);
		 contractTbBodyDTO.setItems(items);
		 contractTbDTO.setBody(contractTbBodyDTO);
		 
		 return contractTbDTO;
	}
	/**
	 * 调用深圳推标接口,日志独立事物,事物传播类型：Propagation.REQUIRES_NEW
	 * @param applyBillMainInfoDO
	 * @param dataJson
	 * @return
	 * @throws Exception
	 */
	private String sendPost(ApplyBillMainInfoDO applyBillMainInfoDO,String dataJson) throws Exception{
	    logger.info("调用深圳推标接口开始,申请id:"+applyBillMainInfoDO.getApplyId()+",请求参数："+dataJson);
	    String result = PosMainStart.sendPost(contractTbInterfaceUrl, dataJson);
	    logger.info("调用深圳推标接口结束,申请id:"+applyBillMainInfoDO.getApplyId()+",返回参数："+result);
	    /**保存接口日志*/
	    /**日志存储*/
        InterfaceLogDO interfaceLogDO = new InterfaceLogDO();
        interfaceLogDO.setApply_id(applyBillMainInfoDO.getApplyId());
        interfaceLogDO.setInterface_name(InterfaceLogConstants.INTERFACE_CONTRACT_TB);
        interfaceLogDO.setInvocation(InterfaceLogConstants.INVOK_TYPE_0);
        interfaceLogDO.setRequest(dataJson);
        interfaceLogDO.setResponse(result);
        interfaceLogDO.setState(SysDictEnum.YES.getCode());
	    interfaceLogOwnService.addInterfaceLog(interfaceLogDO);
	    return result;
	}
	
}
