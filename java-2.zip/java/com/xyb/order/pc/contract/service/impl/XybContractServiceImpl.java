package com.xyb.order.pc.contract.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.ChangeBankApplyDO;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.material.service.FileDataInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.google.gson.Gson;
import com.xyb.auth.user.model.User;
import com.xyb.bindcard.service.BindCardEntranceService;
import com.xyb.common.model.dto.AgreementBindInDTO;
import com.xyb.common.model.dto.AgreementPayOutDTO;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.common.util.TimestampIDUtil;
import com.xyb.order.pc.apply.already.model.ApplyAlreadyContractInfoVO;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractAbolishDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDO;
import com.xyb.order.pc.contract.model.XybContractAuditDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.model.XybContractDTO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSaveDTO;
import com.xyb.order.pc.contract.model.XybContractDetailSubmitDTO;
import com.xyb.order.pc.contract.model.XybContractDetailVO;
import com.xyb.order.pc.contract.model.XybContractListVO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;
import com.xyb.order.pc.contract.model.repaymentplan.XybContractRepaymentPlanVO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;
import com.xyb.order.pc.contract.service.XybContractAuditService;
import com.xyb.order.pc.contract.service.XybContractService;
import com.xyb.order.pc.ownuse.service.contract.XybContractAllocationOwnService;
import com.xyb.order.pc.ownuse.service.contract.XybContractOwnuseService;
import com.xyb.order.pc.product.model.ProductDO;
import com.xyb.util.SessionUtil;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 合同实现
 * @createDate : 2018/03/28 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.XybContractService")
public class XybContractServiceImpl implements XybContractService {
	private static final Logger logger = LoggerFactory.getLogger(XybContractServiceImpl.class);

	/**是否是正式环境*/
	@Value("${is.formal}")
	private String isFormal;

	@Autowired
	private XybContractDao dao;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private XybContractOwnuseService xybContractOwnuseService;
	@Autowired
	private XybContractAllocationOwnService xybContractAllocationOwnService;
	@Reference
	private BindCardEntranceService bindCardEntranceService;
	@Autowired
	private ClinetUserDao clinetUserDao;
	@Autowired
	private FileDataInfoService fileService;
	@Autowired
	private AuthorizationDao authorizationDao;
	@Autowired
	private BankDao bankDao;
	@Autowired
	private XybContractAuditService xybContractAuditService;
	static Gson gson = new Gson();
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listContract(Integer pageNumber, Integer pageSize,XybContractQueryDTO xybContractQueryDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 xybContractQueryDTO.getPage().setPageNumber(pageNumber);
			 xybContractQueryDTO.getPage().setPageSize(pageSize);
			 xybContractQueryDTO.setOrgId(loginUser.getDataOrgId());
		     List<XybContractListVO> list = dao.listContractPage(xybContractQueryDTO);
		     for (XybContractListVO xybContractListVO:list){
		     	xybContractListVO.setLoginId(loginUser.getId());
			 }
		     xybContractQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,xybContractQueryDTO.getPage());
		} catch (Exception e) {
			logger.error("合同列表查询失败" , e);
			response = new RestResponse(MsgErrCode.FAIL,"合同列表查询失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateCheck(XybContractDetailDTO xybContractDetailDTO)  {
		RestResponse response;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();

			/**1.获取合同信息*/
			XybContractDO xybContractDO = dao.getXybContractDO(xybContractDetailDTO.getApplyId());
			String oldData = JsonUtil.object2json(xybContractDO);
			
			/**2.查询主表数据*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", xybContractDetailDTO.getApplyId());
			ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			
			/**4.判断存管账户是否已开户*/
			ClientBankInfoNoDO bankPara = new ClientBankInfoNoDO();
			bankPara.setClientId(applyMaInfo.getClientId());
			bankPara.setIsDefault(SysDictEnum.YES.getCode());
			bankPara.setState(SysDictEnum.YES.getCode());
			List<ClientBankInfoNoDO> bankInfoNoDOS = bankDao.queryClientBankInFoNo(bankPara);
			if (bankInfoNoDOS != null && bankInfoNoDOS.size() > 0){
				// -- 查询用户申请信息
				ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
				changeBankApplyDO.setClientId(applyMaInfo.getClientId());
				changeBankApplyDO.setBankInfoId(bankInfoNoDOS.get(0).getId());
				List<ChangeBankApplyDO> applyDOList = bankDao.queryChangeBankApply(changeBankApplyDO);
				if (applyDOList != null && applyDOList.size() > 0){
					for (ChangeBankApplyDO ct:applyDOList){
						if (SysDictEnum.BANK_CARD_STATUS_3102.getCode().equals(ct.getState()) || SysDictEnum.BANK_CARD_STATUS_3103.getCode().equals(ct.getState())){
							response = new RestResponse(MsgErrCode.FAIL);
							response.setDescription("用户申请换卡中！");
							return response;
						}
					}
				}
			}else {
				/**未绑定银行卡*/
				response = new RestResponse(MsgErrCode.FAIL);
				response.setDescription("请在APP上完成银行卡绑定!");
				return response;
			}
			/**查询存管银行信息并且绑定到合同表*/
			xybContractDO.setBankType(Long.valueOf(bankInfoNoDOS.get(0).getBankId()));
			xybContractDO.setBankAccountOpen(bankInfoNoDOS.get(0).getBankcardBankname());
			xybContractDO.setRefundCardNum(bankInfoNoDOS.get(0).getBankNum());
			xybContractDO.setMp(bankInfoNoDOS.get(0).getPhone());
			xybContractDO.setBankAccount(bankInfoNoDOS.get(0).getBankRealName());
			
			/**5.更新合同表信息*/
			this.updateContractNotNull(userId,oldData,xybContractDO);
			response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("合同详情校验方法失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"合同详情校验方法失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	}


//	@SuppressWarnings("null")
//	@Override
//	@Transactional(rollbackFor = Exception.class)
//	public RestResponse updateCheck(XybContractDetailDTO xybContractDetailDTO)  {
//		RestResponse response;
//		try {
//			User loginUser = SessionUtil.getLoginUser(User.class);
//			Long userId = loginUser.getId();
//
//			/**1.获取合同信息 ,判断redis 缓存中是否存在,已存在读取缓存，反之查询数据库*/
//			XybContractDO xybContractDO = new XybContractDO();
//			String key = SysConstants.CONTRACT + xybContractDetailDTO.getApplyId();
//			String cacheData = RedisUtil.get(key);
//			if(StringUtils.isNotNullAndEmpty(cacheData)){
//				xybContractDO = RedisUtil.get(key,XybContractDO.class);
//			}else {
//				xybContractDO = dao.getXybContractDO(xybContractDetailDTO.getApplyId());
//			}
//
//			/**2.查询主表数据*/
//			Map<String, Object> map = new HashMap<>(2);
//			map.put("applyId", xybContractDetailDTO.getApplyId());
//			ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
//
//			Map<String, Object> depositMap = new HashMap<>(2);
//			depositMap.put("openPlatform", xybContractDO.getLoanChannel());
//			depositMap.put("clientId", applyMaInfo.getClientId());
//			DepositAccountStatementInFoDO depositAccountStatementInFoDO = authorizationDao.getDepositAccountStatementInFoByOpenPlatform(depositMap);
//			if(depositAccountStatementInFoDO != null){
//				/**已开通存管账户,判断当前是否有存管正在操作而未完成的*/
//				DepositAccountStatementChangeDO depositAccountStatementChangeDO = new DepositAccountStatementChangeDO();
//				depositAccountStatementChangeDO.setDepositId(depositAccountStatementInFoDO.getId());
//				depositAccountStatementChangeDO.setClientId(depositAccountStatementInFoDO.getClientId());
//				List<DepositAccountStatementChangeDO> depositAccountStatementChangeDOs = authorizationDao.getDepositAccountStatementChange(depositAccountStatementChangeDO);
//				if(depositAccountStatementChangeDOs != null && depositAccountStatementChangeDOs.size() > 0){
//					/**当前有未完成的操作,不可进入详情页*/
//					String typeDec = "";
//					if(depositAccountStatementChangeDOs.get(0).getType().equals(SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_ONE.getCode())){
//						typeDec = SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_ONE.getName();
//					}else if(depositAccountStatementChangeDOs.get(0).getType().equals(SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_TWO.getCode())){
//						typeDec = SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_TWO.getName();
//					}else if(depositAccountStatementChangeDOs.get(0).getType().equals(SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_THREE.getCode())){
//						typeDec = SysDictEnum.DEPOSIT_ACCOUNT_STATEMENT_TYPE_THREE.getName();
//					}
//					response = new RestResponse(MsgErrCode.FAIL);
//					response.setDescription("请先处理完存管当前任务：" + typeDec + "!");
//				}else{
//					/**查询存管银行信息并且绑定到合同表*/
//					ClientBankInFoDO clientBankInFoDO = authorizationDao.getClientBankInFoByDepositId(depositAccountStatementInFoDO.getId());
//
//					xybContractDO.setBankType(Long.valueOf(clientBankInFoDO.getBankId()));
//					xybContractDO.setBankAccountOpen(clientBankInFoDO.getBankcardBankname());
//					xybContractDO.setRefundCardNum(clientBankInFoDO.getBankNum());
//					xybContractDO.setMp(clientBankInFoDO.getPhone());
//					xybContractDO.setBankAccount(clientBankInFoDO.getBankRealName());
//					/**5.更新合同表信息*/
//					this.updateContractNotNull(userId,xybContractDO);
//					response = new RestResponse(MsgErrCode.SUCCESS);
//				}
//			}else{
//				/**未开通存管账户*/
//				response = new RestResponse(MsgErrCode.FAIL);
//				response.setDescription("请先开通存管账户!");
//			}
//		} catch (Exception e) {
//			logger.error("合同详情校验方法失败",e);
//			response = new RestResponse(MsgErrCode.FAIL,"合同详情校验方法失败");
//			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//		}
//  		return response;
//	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateContract(XybContractDetailDTO xybContractDetailDTO)  {
		RestResponse response;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();

			/**1.获取合同信息 */
			XybContractDO xybContractDO = dao.getXybContractDO(xybContractDetailDTO.getApplyId());
			
			/**2.查询合同相关信息且更新主表数据*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", xybContractDetailDTO.getApplyId());
			ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			
			/**3.查询申请相关信息*/
			XybContractDetailVO xybContractDetailVO = dao.getXybContractDetailVO(xybContractDetailDTO);
			if(xybContractDetailVO == null){
				xybContractDetailVO = new XybContractDetailVO();
			}
			
			/**4.查询合同审核信息*/
			XybContractAuditDO xybContractAuditDO = dao.getContractAuditDO(xybContractDetailDTO.getApplyId());
			xybContractDetailVO.setXybContractAuditDO(xybContractAuditDO);
	        
			xybContractDetailVO.setXybContractDO(xybContractDO);
			
	  		/**5.更新main表合同专员,和最后修改人,最后修改日期*/

			String oldData = JsonUtil.object2json(applyMaInfo);
			
			applyMaInfo.setModifyTime(new Date());
			applyMaInfo.setModifyUser(userId);
			applyMaInfo.setContractUid(userId);
			applyMaInfo.setContractNum(xybContractDO.getContractNum());
			applyMaInfo.setContractId(xybContractDO.getId());
			
			String newData = JsonUtil.object2json(applyMaInfo);
			boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyMaInfo.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			if(flag){
				currencyDao.updateMainInFo(applyMaInfo);
			}
			/**6.生成还款计划*/
			BigDecimal serviceAmount = applyBillInfoDao.getServiceAmount(applyMaInfo.getApplyId());
			xybContractOwnuseService.repaymentPlan(applyMaInfo, serviceAmount);

	  		response = new RestResponse(MsgErrCode.SUCCESS,xybContractDetailVO);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("合同详情查询失败" , e);
			response = new RestResponse(MsgErrCode.FAIL,"合同详情查询失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	}
	
	public void updateContractNotNull(Long userId,String oldData,XybContractDO xybContractDO){
		/**1.对比是否需要修改,是：修改contract表,添加表修改日志*/
		boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,xybContractDO.getId(),TableConstant.T_XYB_CONTRACT,oldData,JsonUtil.object2json(xybContractDO));
		if(flag){
			dao.updateContractNotNull(xybContractDO);
		}
	}
	
	public void updateContractNotNullOfXybContractDTO(Long userId,String oldData,XybContractDTO xybContractDO){
		/**1.对比是否需要修改,是：修改contract表,添加表修改日志*/
		boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,xybContractDO.getId(),TableConstant.T_XYB_CONTRACT,oldData,JsonUtil.object2json(xybContractDO));
		if(flag){
			dao.updateContractNotNull(xybContractDO);
		}
	}
	private void insertContract(XybContractDO bean){
		dao.insertContract(bean);
	}
	/**
	 * 生成合同编号方法，合同编号声称规则：4位机构码(机构码前四位)+6位时间(yymmdd)+4位随机码
	 * 
	 * @param orgId
	 * @throws Exception
	 */
	private String getContractNum(Long orgId){
		String contractNum = "";
		String dateNum = "0";

		contractNum = orgId.toString().substring(4, 8);

		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		dateNum = sdf.format(new Date());
		contractNum = contractNum + String.valueOf(dateNum);
		Random random = new Random();
		for (int i = 0; i < 4; i++) {
			int a = random.nextInt(10);
			contractNum = contractNum + String.valueOf(a);
		}
		return contractNum;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse saveContract(XybContractDetailSaveDTO xybContractDetailSaveDTO) {
		 RestResponse response = null;
		 try {
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();
		     
			 XybContractDO xybContractDO = xybContractDetailSaveDTO.getXybContractDO();
			 String oldData = JsonUtil.object2json(xybContractDO);
			 xybContractDO.setModifyUser(userId);
			 xybContractDO.setModifyTime(new Date());
			 xybContractDO.setModifyName(loginUser.getName());
			 xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTDFH.getCode());
			 this.updateContractNotNull(userId,oldData,xybContractDO);
			 response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			 logger.error("合同暂存失败" , e);
			 response = new RestResponse(MsgErrCode.FAIL,"合同暂存失败");
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse submitContract(XybContractDetailSubmitDTO xybContractDetailSubmitDTO,String macAddr,String ipAddr) {
		RestResponse response = null;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();
			
			/**1.获取合同和查询主表信息*/
			XybContractDTO xybContractDTO = xybContractDetailSubmitDTO.getXybContractDTO();
			String contractOldData = JsonUtil.object2json(xybContractDTO);
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", xybContractDetailSubmitDTO.getXybContractDTO().getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			// -- 上线打开
			/**2.判断用户是否未完成签约协议*/
			if (CurrencyConstant.Y.equals(isFormal)) {
				Map<String, Object> paraMap = new HashMap<>(3);
				paraMap.put("agreementType", SysDictEnum.LOAN_SERVICE_URL.getCode());
				paraMap.put("applyId", xybContractDetailSubmitDTO.getXybContractDTO().getApplyId());
				paraMap.put("isValid", SysDictEnum.IS_VALID.getCode());
				int count = authorizationDao.getAgreementInFoCount(paraMap);
				if (count == 0) {
					response = new RestResponse(MsgErrCode.FAIL);
					response.setDescription("提交失败,请先在APP上完成协议签署！");
					return response;
				}
			}
			/**3.查询是否已经授权全部划扣渠道*/
			/**3.1获取客户信息*/
			Map<String, Object> clientMap = new HashMap<>(2);
			clientMap.put("id", applyBillMainInfoDO.getClientId());
			ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(clientMap);

			AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
			agreementBindInDTO.setBankType(String.valueOf(xybContractDTO.getBankType()));
			agreementBindInDTO.setCardNumber(xybContractDTO.getRefundCardNum());
			agreementBindInDTO.setName(xybContractDTO.getBankAccount());
			agreementBindInDTO.setPhoneNumber(xybContractDTO.getMp());
			agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
			agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
			agreementBindInDTO.setIdcardNumber(xybContractDTO.getClientIdcard());
			logger.info("获取渠道银行类型列表接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
			Map<String, Object> resultMap = bindCardEntranceService.getUserNotBindChannel(agreementBindInDTO);
			logger.info("获取渠道银行类型列表接口返回结果:"+JsonUtils.toJSON(resultMap));
			if(resultMap != null ){
				@SuppressWarnings("rawtypes")
				List resultList = (List) resultMap.get("channelList");
				if(resultMap.get("code").equals(SysConstants.CODEONE) && (resultList == null || (resultList != null && resultList.size() == 0))){
					/**code为S channelList为null说明该用户已签约完所有渠道,可以提交*/
				}else if (resultMap.get("code").equals(SysConstants.CODETWO) && (resultList == null || (resultList != null && resultList.size() == 0))){
					/**code为F channelList为null说明所选银行无支持的渠道,提交失败*/
					response = new RestResponse(MsgErrCode.FAIL);
					response.setDescription("提交失败,当前银行无支持的划扣渠道!");
					return response;
				}else {
					/**当前有未完成的划扣渠道,提交失败*/
					response = new RestResponse(MsgErrCode.FAIL);
					response.setDescription("提交失败,请先完成所有划扣渠道的签约！");
					return response;
				}
			}
			/**4.产品为优信借直接推送深圳,反之原流程*/
			if(applyBillMainInfoDO.getAgreeProductId().equals(ProductConstant.YOU_XIN_JIE_ID)){
				/**封装审核通过信息*/
				XybContractAuditDTO xybContractAuditDTO = new XybContractAuditDTO();
				xybContractAuditDTO.setApplyId(applyBillMainInfoDO.getApplyId());
				xybContractAuditDTO.setContractAuditResult(SysDictEnum.CONTRACT_AUDIT_TG.getCode());
				XybContractAuditDetailSubmitDTO xybContractAuditDetailSubmitDTO = new XybContractAuditDetailSubmitDTO();
				xybContractAuditDetailSubmitDTO.setXybContractAuditDTO(xybContractAuditDTO);
				/**调用推标接口*/
				response = xybContractAuditService.submitContractAudit(xybContractAuditDetailSubmitDTO, macAddr, ipAddr);
			}else{
				/**4.更新合同信息*/
				/**4.1 查询批贷产品信息,更新合同违约金比例,罚息比例*/
				ProductDO product = dao.getProduct(applyBillMainInfoDO.getAgreeProductId());
				xybContractDTO.setBreachProportion(product.getBreach_proportion());
				xybContractDTO.setFineProportion(product.getFine_proportion());
				xybContractDTO.setModifyUser(userId);
				xybContractDTO.setModifyTime(new Date());
				xybContractDTO.setModifyName(loginUser.getName());
				xybContractDTO.setContractState(SysDictEnum.CONTRACT_STATE_HTDFH.getCode());
				this.updateContractNotNullOfXybContractDTO(userId,contractOldData,xybContractDTO);

				/**5.修改流程状态*/
				MainLogDTO mainLogDTO = new MainLogDTO();
				mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_REVIEW);
				mainLogDTO.setMainId(applyBillMainInfoDO.getId());
				mainLogDTO.setModifyUser(userId);
				currencyDao.addMainLog(mainLogDTO);
				
				/**6.对比是否需要修改,是：修改mainInfo表,添加表修改日志*/
				String oldData = JsonUtil.object2json(applyBillMainInfoDO);
				
				applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_REVIEW);
				applyBillMainInfoDO.setModifyTime(new Date());
				applyBillMainInfoDO.setModifyUser(userId);
				applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

				String newData = JsonUtil.object2json(applyBillMainInfoDO);
				boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
				if(flag){
					currencyDao.updateMainInFo(applyBillMainInfoDO);
				}
				
				/**7.分配合同审核人员*/
				xybContractAllocationOwnService.contractAuditAutoAllocation(applyBillMainInfoDO,userId);
				
				/**8.更新图片信息为不可删除*/
				fileService.updateFileState(applyBillMainInfoDO.getApplyId(), userId, FileNameConstant.CONTRACT_IMAGES_TYPE);
				
				response = new RestResponse(MsgErrCode.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("合同提交失败" , e);
			response = new RestResponse(MsgErrCode.FAIL,"合同提交失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse abolishContract(XybContractAbolishDTO xybContractAbolishDTO) {
		RestResponse response = null;
		try {
			User loginUser = SessionUtil.getLoginUser(User.class);
			Long userId = loginUser.getId();
			/**1.查询main_info*/
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", xybContractAbolishDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			
			/**2.分配合同审核人员*/
			xybContractAllocationOwnService.contractAuditAutoAllocation(applyBillMainInfoDO,userId);
			
			/**更新流程状态为合同作废*/
				 
		    MainLogDTO mainLogDTO = new MainLogDTO();
			mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_INVALIDATION);
			mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			mainLogDTO.setModifyUser(userId);
			currencyDao.addMainLog(mainLogDTO);
					
			String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
					
			applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_INVALIDATION);
			applyBillMainInfoDO.setPrevious(NodeStateConstant.CONTRACT_ENTRY);
			applyBillMainInfoDO.setModifyTime(new Date());
			applyBillMainInfoDO.setModifyUser(userId);
			applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

			String newData = JsonUtil.object2json(applyBillMainInfoDO);
			boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			if(flag){
				currencyDao.updateMainInFo(applyBillMainInfoDO);
			}
			/**2.2.2更新合同表合同状态*/
			XybContractDO xybContractDO = dao.getXybContractDO(applyBillMainInfoDO.getApplyId());
			String oldContractOld = JsonUtil.object2json(xybContractDO);
			xybContractDO.setApplyId(xybContractAbolishDTO.getApplyId());
			xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTZF.getCode());
			xybContractDO.setContractAbolitionTime(new Date());
			/**处理合同退回中文描述*/
			StringBuffer contractAbolitionName = new StringBuffer();
			String[] reasons = null;
			
			if(StringUtils.isNotNullAndEmpty(xybContractAbolishDTO.getContractAbolition())){
				if(xybContractAbolishDTO.getContractAbolition().contains(",")){
					reasons = xybContractAbolishDTO.getContractAbolition().substring(1,xybContractAbolishDTO.getContractAbolition().length()-1).split(",");
					for (int i = 0; i < reasons.length; i++) {
						if(i == reasons.length - 1){
							contractAbolitionName.append(SysDictEnum.getContractAbolishName(Long.valueOf(reasons[i])));
						}else {
							contractAbolitionName.append(SysDictEnum.getContractAbolishName(Long.valueOf(reasons[i]))).append(",");
						}
					}
				}else{
					contractAbolitionName.append(SysDictEnum.getContractAbolishName(Long.valueOf(xybContractAbolishDTO.getContractAbolition().substring(1,xybContractAbolishDTO.getContractAbolition().length()-1))));
				}
			}
			
			xybContractDO.setContractAbolition(xybContractAbolishDTO.getContractAbolition().substring(1,xybContractAbolishDTO.getContractAbolition().length()-1));
			xybContractDO.setContractAbolitionName(contractAbolitionName.toString());
			xybContractDO.setRemarks(xybContractAbolishDTO.getRemarks());
			xybContractDO.setModifyName(loginUser.getName());
			xybContractDO.setModifyTime(new Date());
			xybContractDO.setModifyUser(userId);
			xybContractOwnuseService.updateContractNotNull(userId,oldContractOld,xybContractDO);
			response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("-----合同废除失败---",e);
			response = new RestResponse(MsgErrCode.FAIL,"合同废除失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;		 
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse getUserNotBindChannel(ThirdPayBindDTO thirdPayBindDTO) {
		RestResponse response = null;
		try {
			/**获取客户id*/
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", thirdPayBindDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**获取合同信息*/
			XybContractDO  xybContractDO = dao.getXybContractDO(thirdPayBindDTO.getApplyId());
			/**获取客户信息*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("id", applyBillMainInfoDO.getClientId());
			ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(map);
			
			AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
			agreementBindInDTO.setBankType(String.valueOf(xybContractDO.getBankType()));
			agreementBindInDTO.setCardNumber(xybContractDO.getRefundCardNum());
			agreementBindInDTO.setName(xybContractDO.getBankAccount());
			agreementBindInDTO.setPhoneNumber(xybContractDO.getMp());
			agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
			agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
			agreementBindInDTO.setIdcardNumber(xybContractDO.getClientIdcard());
			logger.info("获取渠道银行类型列表接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
			Map<String, Object> resultMap = bindCardEntranceService.getUserNotBindChannel(agreementBindInDTO);
			logger.info("获取渠道银行类型列表接口返回结果:"+JsonUtils.toJSON(resultMap));
			if(resultMap != null ){
				@SuppressWarnings("rawtypes")
				List resultList = (List) resultMap.get("channelList");
				if(SysConstants.CODEONE.equals(resultMap.get("code")) && (resultList == null || (resultList != null && resultList.size() == 0))){
					/**code为S channelList为null说明该用户已签约完所有渠道*/
					response = new RestResponse(MsgErrCode.SUCCESS,resultMap);
				}else if (SysConstants.CODETWO.equals(resultMap.get("code")) && (resultList == null || (resultList != null && resultList.size() == 0))){
					/**code为F channelList为null说明所选银行无支持的渠道*/
					response = new RestResponse(MsgErrCode.FAIL);
					response.setDescription("失败,当前银行无支持的划扣渠道!");
				}else {
					response = new RestResponse(MsgErrCode.SUCCESS,resultMap.get("channelList"));
				}
			}
		} catch (Exception e) {
			logger.error("协议支付-获取当前用户待绑卡渠道列表失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"协议支付-获取当前用户待绑卡渠道列表失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;	
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse preBindCardEntrance(ThirdPayBindPreDTO thirdPayBindPreDTO) {
		RestResponse response = null;
		try {
			/**获取客户id*/
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", thirdPayBindPreDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**获取合同信息*/
			XybContractDO  xybContractDO = dao.getXybContractDO(thirdPayBindPreDTO.getApplyId());
			/**获取客户信息*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("id", applyBillMainInfoDO.getClientId());
			ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(map);
			
			AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
			agreementBindInDTO.setBankType(String.valueOf(xybContractDO.getBankType()));
			agreementBindInDTO.setCardNumber(xybContractDO.getRefundCardNum());
			agreementBindInDTO.setName(xybContractDO.getBankAccount());
			agreementBindInDTO.setPhoneNumber(xybContractDO.getMp());
			agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
			agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
			agreementBindInDTO.setIdcardNumber(xybContractDO.getClientIdcard());
			agreementBindInDTO.setChannelId(thirdPayBindPreDTO.getChannelId());
			agreementBindInDTO.setOrderNo(TimestampIDUtil.createID());
			logger.info("协议支付-预绑卡接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
			AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.preBindCardEntrance(agreementBindInDTO);
			logger.info("协议支付-预绑卡接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
			if(SysConstants.CODEONE.equals(agreementPayOutDTO.getCode())){
				response = new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
			}else if(SysConstants.CODETWO.equals(agreementPayOutDTO.getCode())){
				response = new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
			}

		} catch (Exception e) {
			logger.error("协议支付-预绑卡失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"协议支付-预绑卡失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse resendMessage(ThirdPayBindPreResendDTO thirdPayBindPreResendDTO) {
		RestResponse response = null;
		try {
			/**获取客户id*/
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", thirdPayBindPreResendDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**获取合同信息*/
			XybContractDO  xybContractDO = dao.getXybContractDO(thirdPayBindPreResendDTO.getApplyId());
			/**获取客户信息*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("id", applyBillMainInfoDO.getClientId());
			ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(map);
			
			AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
			agreementBindInDTO.setBankType(String.valueOf(xybContractDO.getBankType()));
			agreementBindInDTO.setCardNumber(xybContractDO.getRefundCardNum());
			agreementBindInDTO.setName(xybContractDO.getBankAccount());
			agreementBindInDTO.setPhoneNumber(xybContractDO.getMp());
			agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
			agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
			agreementBindInDTO.setIdcardNumber(xybContractDO.getClientIdcard());
			agreementBindInDTO.setChannelId(thirdPayBindPreResendDTO.getChannelId());
			agreementBindInDTO.setOrderNo(thirdPayBindPreResendDTO.getOrder());
			logger.info("协议支付-预绑卡重发短信接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
			AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.resendMessage(agreementBindInDTO);
			logger.info("协议支付-预绑卡重发短信接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
			if(SysConstants.CODEONE.equals(agreementPayOutDTO.getCode())){
				response = new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
			}else if(SysConstants.CODETWO.equals(agreementPayOutDTO.getCode())){
				response = new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
			}

		} catch (Exception e) {
			logger.error("协议支付--预绑卡--重发短信失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"协议支付--预绑卡--重发短信失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse confirmBianCardEntrance(
			ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO) {
		RestResponse response = null;
		try {
			/**获取客户id*/
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", thirdPayBindConfirmBianCardEntranceDTO.getApplyId());
			ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**获取合同信息*/
			XybContractDO  xybContractDO = dao.getXybContractDO(thirdPayBindConfirmBianCardEntranceDTO.getApplyId());
			/**获取客户信息*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("id", applyBillMainInfoDO.getClientId());
			ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(map);
			
			AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
			agreementBindInDTO.setBankType(String.valueOf(xybContractDO.getBankType()));
			agreementBindInDTO.setCardNumber(xybContractDO.getRefundCardNum());
			agreementBindInDTO.setName(xybContractDO.getBankAccount());
			agreementBindInDTO.setPhoneNumber(xybContractDO.getMp());
			agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
			agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
			agreementBindInDTO.setIdcardNumber(xybContractDO.getClientIdcard());
			agreementBindInDTO.setChannelId(thirdPayBindConfirmBianCardEntranceDTO.getChannelId());
			agreementBindInDTO.setOrderNo(thirdPayBindConfirmBianCardEntranceDTO.getOrder());
			agreementBindInDTO.setValidateCode(thirdPayBindConfirmBianCardEntranceDTO.getValidateCode());
			logger.info("协议支付确认绑卡接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
			AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.confirmBianCardEntrance(agreementBindInDTO);
			logger.info("协议支付确认绑卡接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
			if(agreementPayOutDTO != null){
				if(SysConstants.CODEONE.equals(agreementPayOutDTO.getCode())){
					/**成功*/
					response = new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
				}else if(SysConstants.CODETWO.equals(agreementPayOutDTO.getCode())){
					/**失败*/
					response = new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
				}
			}
		} catch (Exception e) {
			logger.error("协议支付确认绑卡失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"协议支付确认绑卡失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public XybContractDO addContract(Long applyId,Long channelId,Long userId,String[] recommendedWordIdS) throws Exception{
		XybContractDO xybContractDO;

		/**1.获取主表信息*/
		Map<String, Object> map = new HashMap<>(2);
		map.put("applyId", applyId);
		ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
		/**2.获取合同信息*/
		xybContractDO = dao.getXybContractDO(applyId);
		
		String oldData = JsonUtil.object2json(xybContractDO);
		/**3.初始化合同*/
		if(xybContractDO == null){
			xybContractDO = new XybContractDO();
			xybContractDO.setApplyId(applyId);
			String contractNum = this.getContractNum(applyMaInfo.getStoreOrgId());
			xybContractDO.setContractNum(contractNum);
			xybContractDO.setCreateUser(userId);
			xybContractDO.setModifyUser(userId);
			xybContractDO.setStoreOrgId(applyMaInfo.getStoreOrgId());
		}
		if(channelId != null){
			xybContractDO.setLoanChannel(channelId);
		}
        /**4.合同不存在,生成合同,反之,更新*/
  		if (xybContractDO != null) {
  			/**关键字处理为中文*/
  			if(recommendedWordIdS != null){
  				List<String> list = dao.getRecommendedWordValuesByIds(Arrays.asList(recommendedWordIdS));
  				String recommendedWordValues = list.stream().collect(Collectors.joining(","));
  				xybContractDO.setClientLabelIds(Arrays.asList(recommendedWordIdS).stream().collect(Collectors.joining(",")));
  				xybContractDO.setClientLabel(recommendedWordValues);
  			}
  			/**添加初始数据*/
			xybContractDO.setStoreOrgId(applyMaInfo.getStoreOrgId());
			xybContractDO.setProductId(applyMaInfo.getAgreeProductId());
			xybContractDO.setProductName(applyMaInfo.getAgreeProductName());
			xybContractDO.setProductProportion(applyMaInfo.getProductProportion());
			xybContractDO.setServiceProportion(applyMaInfo.getServiceProportion());
			xybContractDO.setCustName(applyMaInfo.getClientRealName());
			xybContractDO.setCustId(applyMaInfo.getClientId());
			xybContractDO.setIsLoop(applyMaInfo.getIsLoop());
			xybContractDO.setMonthRepaymentMoney(applyMaInfo.getMonthRepaymentMoney());
			xybContractDO.setProductLimit(applyMaInfo.getAgreeProductLimit());
			xybContractDO.setClientIdcard(applyMaInfo.getClientIdcard());
			xybContractDO.setStoreOrgName(dao.getOrgName(applyMaInfo.getStoreOrgId()));
			xybContractDO.setType(SysDictEnum.CONTRACT_TYPE_ORIGINAL.getCode());
			if (xybContractDO.getId() == null) {
				if (StringUtils.isNullOrEmpty(xybContractDO.getContractNum())) {
					String contractNum = this.getContractNum(applyMaInfo.getStoreOrgId());
					xybContractDO.setContractNum(contractNum);
				}
				this.insertContract(xybContractDO);
			} else {
				if (StringUtils.isNullOrEmpty(xybContractDO.getContractNum())) {
					String contractNum = this.getContractNum(applyMaInfo.getStoreOrgId());
					xybContractDO.setContractNum(contractNum);
				}
				this.updateContractNotNull(userId,oldData,xybContractDO);
			}
		}
	
		return xybContractDO;
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse applyAlreadyContractInfo(Long applyId) {
		RestResponse response = null;
		try {
			/**查询申请已办合同信息*/
			ApplyAlreadyContractInfoVO applyAlreadyContractInfoVO = dao.getApplyAlreadyContractInfoVO(applyId);
			response = new RestResponse(MsgErrCode.SUCCESS,applyAlreadyContractInfoVO);
		} catch (Exception e) {
			logger.error("申请已办合同信息查询失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"申请已办合同信息查询失败");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	public RestResponse getRepaymentPlans(Long applyId) {
		RestResponse response = null;
		try {
			List<XybContractRepaymentPlanVO> repaymentPlans = dao.listRepaymentPlans(applyId);
			response = new RestResponse(MsgErrCode.SUCCESS,repaymentPlans);
		} catch (Exception e) {
			logger.error("还款计划查询失败",e);
			response = new RestResponse(MsgErrCode.FAIL,"还款计划查询失败");
		}
		return response;
	}
}
