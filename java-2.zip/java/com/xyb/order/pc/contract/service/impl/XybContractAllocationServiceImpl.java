package com.xyb.order.pc.contract.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;
import com.xyb.order.pc.contract.model.XybContractAuditDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.model.XybContractDetailDTO;
import com.xyb.order.pc.contract.model.XybContractDetailVO;
import com.xyb.order.pc.contract.model.XybContractListVO;
import com.xyb.order.pc.contract.model.XybContractQueryDTO;
import com.xyb.order.pc.contract.service.XybContractAllocationService;
import com.xyb.order.pc.ownuse.service.contract.XybContractAllocationOwnService;
import com.xyb.util.SessionUtil;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.contract.service.impl
 * @description : 合同重新分配实现
 * @createDate : 2018/5/3 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.XybContractAllocationService")
public class XybContractAllocationServiceImpl implements XybContractAllocationService{
	private static final Logger logger = LoggerFactory.getLogger(XybContractServiceImpl.class);

	@Autowired
	private XybContractDao dao;
	@Autowired
	private XybContractAllocationOwnService xybContractAllocationOwnService;
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse listContract(Integer pageNumber, Integer pageSize,XybContractQueryDTO xybContractQueryDTO) {
		 RestResponse response = null;
		 try {
			  User loginUser = SessionUtil.getLoginUser(User.class);
	         
			 xybContractQueryDTO.getPage().setPageNumber(pageNumber);
			 xybContractQueryDTO.getPage().setPageSize(pageSize);
			 xybContractQueryDTO.setOrgId(loginUser.getDataOrgId());
		     List<XybContractListVO> list = dao.listContractPage(xybContractQueryDTO);
		     xybContractQueryDTO.getPage().setContents(list);
		     response = new RestResponse(MsgErrCode.SUCCESS,xybContractQueryDTO.getPage());
		} catch (Exception e) {
			 logger.error("合同重新分配列表查询失败",e);
			 response = new RestResponse(MsgErrCode.FAIL);
			 TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}


	@SuppressWarnings("null")
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateContract(XybContractDetailDTO xybContractDetailDTO)  {
		RestResponse response = null;
		try {
			/**1.查询申请相关信息*/
			XybContractDetailVO xybContractDetailVO = dao.getXybContractDetailVO(xybContractDetailDTO);
			if(xybContractDetailVO == null){
				xybContractDetailVO = new XybContractDetailVO();
			}
			
			/**2.查询合同相关信息*/
			XybContractDO xybContractDO = dao.getXybContractDO(xybContractDetailDTO.getApplyId());
			
			
			/**3.查询合同审核相关信息*/
			XybContractAuditDO xybContractAuditDO = dao.getContractAuditDO(xybContractDetailDTO.getApplyId());
			xybContractDetailVO.setXybContractAuditDO(xybContractAuditDO);
			
			xybContractDetailVO.setXybContractDO(xybContractDO);
			
	  		response = new RestResponse(MsgErrCode.SUCCESS,xybContractDetailVO);
		} catch (Exception e) {
			logger.error("合同详情查询失败",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	}


	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse allocationContract(XybContractAllocationDTO xybContractAllocationDTO) {
		RestResponse response = null;
		try {
			xybContractAllocationOwnService.contractAllocation(xybContractAllocationDTO);
	  		response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (Exception e) {
			logger.error("合同重新分配异常,分配类型:",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
  		return response;
	}
}
