package com.xyb.order.pc.contract.service.impl;



import java.util.HashMap;
import java.util.Map;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.utils.DateTimeUtil;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.order.common.constant.InterfaceLogConstants;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.currency.model.ResponseResult;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.SignMatchesUtil;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.ApplyRevokeDTO;
import com.xyb.order.pc.contract.model.ApplyRevokeDetailDTO;
import com.xyb.order.pc.contract.model.InterfaceLogDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.service.ApplyRevokeService;
import com.xyb.order.pc.finance.dao.FinancePaymentDao;
import com.xyb.order.pc.ownuse.service.contract.ApplyRevokeOwnService;
import com.xyb.order.pc.ownuse.service.interfacelog.InterfaceLogOwnService;


/**
 * @description 借款撤销通知处理
 * @author houlvshuang
 * @time 2018年05月13日下午4:52:52
 * @modificationHistory <记录修改历史记录 who where what>
 */
@Service(interfaceName = "com.xyb.order.pc.contract.service.ApplyRevokeService")
public class ApplyRevokeServiceImpl implements ApplyRevokeService{

	private final static Logger log = Logger.getLogger(ApplyRevokeServiceImpl.class);
	

    /**接口签名秘钥*/
    @Value("${http.secret.key}")
    private String secretKey;
    /**借款撤销申请地址*/
    @Value("${apply.revoke.url}")
    private String applyRevokeUrl;
	
	@Autowired
	private XybContractDao xybcontractDao;
	@Autowired
	private FinancePaymentDao financePaymentDao;
	@Autowired
	private InterfaceLogOwnService interfaceLogOwnService;
	@Autowired
	private ApplyRevokeOwnService applyRevokeOwnService;
    
	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseResult receiveApplyRevokeNotice(ApplyRevokeDTO applyRevokeDTO) {
		String jsonStr = JsonUtils.toJSON(applyRevokeDTO);
		String sign = applyRevokeDTO.getSign();
		ApplyRevokeDetailDTO applyRevokeDetail = applyRevokeDTO.getBody();
		String errorMsg;
        log.info("借款撤销通知回调接口开始------- 时间: "+ DateTimeUtil.getDateTime() + "返回参数为: " + JsonUtils.toJSON(applyRevokeDTO));
        ResponseResult responseResult = new ResponseResult();
//        boolean isOk = false; //是否作废成功
//        try {
//            // 接口调用校验
//           boolean matcheFlag = SignMatchesUtil.matches(applyRevokeDetail, secretKey, sign);
//            if (matcheFlag) 
//            {
//        		// 系统ID
//            	long sysId = applyRevokeDetail.getSysId();
//            	// 借款申请ID
//            	String applyId = applyRevokeDetail.getApplyId();
//            	// 收购时间，data类型
//            	String revokeCode = applyRevokeDetail.getRevokeCode();
//            	XybContractDO xybContract = xybcontractDao.getXybContractDO(Long.valueOf(applyId));
//            	//判断是否放款
//            	Map<String, Object> map  = new HashMap<>(3);
//            	map.put("in_out_flag", SysDictEnum.IN_OUT_FLAG_DF.getCode());
//            	map.put("state", SysDictEnum.PAY_MENT_DETAILS_CLCG.getCode());
//            	map.put("contractId", xybContract.getId());
//				Integer isPayment = financePaymentDao.queryCountByContractIdOfFancePayment(map);
//				if(isPayment == 0)
//				{
//					isOk = applyRevokeOwnService.saveData(Long.valueOf(applyId));
//		           	if (isOk) 
//	            	{
//	            		responseResult.setCode(SysConstants.INTERFACE_SUCCESS);
//	    	            responseResult.setMessage("撤销成功");
//					}else
//					{
//						responseResult.setCode(SysConstants.INTERFACE_FAIL);
//	    	            responseResult.setMessage("撤销失败");
//					}
//				}else 
//				{
//					responseResult.setCode(SysConstants.INTERFACE_FAIL);
//		            responseResult.setMessage("当前合同已放款，不允许撤销");
//				}
//            }else 
//            {
//            	responseResult.setCode(SysConstants.INTERFACE_FAIL);
//	            responseResult.setMessage("验签失败");
//			}
//		} catch (Exception e) 
//        {
//            responseResult.setCode(SysConstants.INTERFACE_FAIL);
//            responseResult.setMessage("系统异常");
//            errorMsg = e.getMessage();
//            log.error("借款撤销通知接口异常------- 时间: " + DateTimeUtil.getDateTime() + "------- 参数: " + errorMsg);
//            log.error(e.getMessage());
//		}finally 
//        {
//            // 创建接口调用记录
//            InterfaceLogDO interfaceLog = new InterfaceLogDO();
//            interfaceLog.setApply_id(Long.valueOf(applyRevokeDetail.getApplyId()));
//            interfaceLog.setInterface_name(InterfaceLogConstants.INTERFACE_APPLY_REVOKE_NOTICE_INFO);
//            interfaceLog.setInvocation(InterfaceLogConstants.INVOK_TYPE_1);
//            interfaceLog.setRequest(jsonStr);
//            interfaceLog.setResponse(JsonUtils.toJSON(responseResult));
//    	    interfaceLogOwnService.addInterfaceLog(interfaceLog);
//		}
//        log.info("***GAME***OVER*******借款撤销通知回调接口结束************GAME***OVER*******");
		return responseResult;
	}
 



}
