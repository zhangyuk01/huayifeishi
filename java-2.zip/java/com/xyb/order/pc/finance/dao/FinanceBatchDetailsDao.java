package com.xyb.order.pc.finance.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.pc.finance.FinanceBatchDetailsDO;

/**
 * @description 批次明细持久层
 * @author houlvshuang
 * @time 2018年5月15日下午4:05:32
 * @modificationHistory <记录修改历史记录 who where what>
 */
public interface FinanceBatchDetailsDao {

	/**
	 * 新增批次明细(单个)
	 */
    int addFinanceBatchDetails(FinanceBatchDetailsDO fbd);

	/**
	 * 根据待交易ID查询批次明细（待处理和处理中）
	 * @param repaymentId 待交易明细ID
	 */
	public List<FinanceBatchDetailsDO> getFinanceBatchDetailsById(Map<String, Object> paraMap);
	
	/**
	 * 更新交易明细表
	 * @param repaymentId
	 */
	void updateFinanceBatchDetailsFail(Long repaymentId);
}
