package com.xyb.order.pc.finance.dao;

import java.util.Map;

import com.xyb.order.pc.finance.FinancePaymentDO;

/**
 * @description 待交易明细DAO
 * @author houlvshuang
 * @time 2018年5月10日下午4:05:32
 * @modificationHistory <记录修改历史记录 who where what>
 */
public interface FinancePaymentDao {

    /**
     * 新增待交易明细（单个）
     */
    int addFinancePayment(FinancePaymentDO financePayment);
    
    /**
     * 查询当前合同放款的数量
     */
    int queryCountByContractIdOfFancePayment(Map<String, Object> map);
    
    /**
     * 修改待交易明细
     */
    int updateOnlyChanged(FinancePaymentDO financePaymentDO);
	/**
	 * 查询待交易明细（放款专用）
	 * @param contractId 合同ID
	 */
	FinancePaymentDO getFinancePaymentForPayment(long contractId);
  
}
