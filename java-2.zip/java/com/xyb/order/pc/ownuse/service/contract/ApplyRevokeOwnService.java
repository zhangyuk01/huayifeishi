package com.xyb.order.pc.ownuse.service.contract;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.base.util.JsonUtils;
import com.xyb.order.common.constant.InterfaceLogConstants;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.PosMainStart;
import com.xyb.order.common.util.SignMatchesUtil;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.ApplyRevokeDTO;
import com.xyb.order.pc.contract.model.ApplyRevokeDetailDTO;
import com.xyb.order.pc.contract.model.ApplyRevokeResultDTO;
import com.xyb.order.pc.contract.model.InterfaceLogDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.finance.FinancePaymentDO;
import com.xyb.order.pc.finance.dao.FinanceBatchDetailsDao;
import com.xyb.order.pc.finance.dao.FinancePaymentDao;
import com.xyb.order.pc.ownuse.service.interfacelog.InterfaceLogOwnService;
import com.xyb.util.SessionUtil;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract
 * @description : 合同作废自用service
 * @createDate : 2018/5/3 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class ApplyRevokeOwnService {
	private static final Logger logger = LoggerFactory.getLogger(ApplyRevokeOwnService.class);
    /**接口签名秘钥*/
    @Value("${http.secret.key}")
    private String secretKey;
    /**借款撤销申请地址*/
    @Value("${apply.revoke.url}")
    private String applyRevokeUrl;
    /**系統Id*/
    @Value("${sys.id}")
    private String sysId; 
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private XybContractDao dao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private XybContractOwnuseService xybContractOwnuseService;
	@Autowired
	private FinancePaymentDao financePaymentDao;
	@Autowired
	private FinanceBatchDetailsDao financeBatchDetailsDao;
	@Autowired
	private InterfaceLogOwnService interfaceLogOwnService;
	/**
	 * 借款撤销调用深圳接口
	 * @param applyId
	 * @param ipAddr
	 * @param macAddr
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	public RestResponse repealing(Long applyId,String ipAddr,String macAddr) {
		RestResponse response = null;
		try{
			Map<String, Object> parameterMap = new HashMap<>(2);
			parameterMap.put("applyId", applyId);
			ApplyBillMainInfoDO mainInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(parameterMap);
			Long acctId = dao.getAcctId(mainInfo.getClientId());
			/**合同为待审核状态*/
			if(mainInfo.getState().equals(NodeStateConstant.IN_THE_BID)){	
				/**查询是否已放款*/
				Map<String, Object> map = new HashMap<>(2);
				map.put("in_out_flag", SysDictEnum.IN_OUT_FLAG_DF.getCode());
				map.put("contractId", mainInfo.getContractId());
				Integer isPayment = financePaymentDao.queryCountByContractIdOfFancePayment(map);
				if(isPayment == 0){
					/**进行参数数据封装*/
					ApplyRevokeDTO applyRevokeDTO = new ApplyRevokeDTO();
					ApplyRevokeDetailDTO body = new ApplyRevokeDetailDTO();
					body.setSysId(Long.valueOf(sysId));
					body.setApplyId(applyId);
					body.setAcctId(acctId);
					/**封装ip和mac地址*/
					body.setClient(SysConstants.BORROWER);
					body.setCustom(SysConstants.WEB);
					body.setClient_ip(ipAddr);
					body.setClient_service(macAddr);
					applyRevokeDTO.setBody(body);
					String sign = SignMatchesUtil.signEncode(applyRevokeDTO, secretKey);
					applyRevokeDTO.setSign(sign);
					String requestData = JsonUtils.toJSON(applyRevokeDTO);
					/**根据日志记录判断是否已成功调用深圳撤标接口,若已成功过,直接按成功处理业务(业务场景：调用深圳撤标接口成功,返回后系统处理业务数据失败,单子在列表中还可以再次请求撤标的情况),反之正常逻辑*/
					Map<String, Object> interfaceMap = new HashMap<>();
					interfaceMap.put("applyId", applyId);
					interfaceMap.put("interfaceName", InterfaceLogConstants.INTERFACE_APPLY_REVOKE);
					List<InterfaceLogDO> logs = interfaceLogOwnService.queryInterfaceLogs(interfaceMap);
					/**是否已推送成功过*/
					boolean isSendSuccess = false;
					ApplyRevokeResultDTO resultDTO = null;
					for (int i = 0; i < logs.size(); i++) {
						/**解析成指定model*/
						resultDTO = JsonUtils.fromJSON(logs.get(i).getResponse(), ApplyRevokeResultDTO.class);
						if(resultDTO != null){
						    if(resultDTO.getCode().equals(SysConstants.INTERFACE_SUCCESS)){
								/**已经成功推送过,推送状态置为true*/
								isSendSuccess = true;
								break;
						    }
						}
					}
					if(!isSendSuccess){
						/**未推送成功过,开始调用深圳标的撤销接口*/
						String result = sendPost(applyId, requestData);
					    resultDTO = JsonUtils.fromJSON(result, ApplyRevokeResultDTO.class);
					}
					/**对返回结果进行验签后处理*/
					Boolean resultSign = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
					resultSign = true;
					if(resultSign){
						/**验签通过,处理业务,返回成功*/
						this.saveData(applyId);
						response = new RestResponse(MsgErrCode.SUCCESS);
					}else{
						/**验签失败*/
						response = new RestResponse(MsgErrCode.FAIL);
						response.setDescription("验签失败");
					}
				}else{
					response = new RestResponse(MsgErrCode.FAIL);
					response.setDescription("借款撤销失败，合同已放款！");
				}
			}else{ 
				response = new RestResponse(MsgErrCode.FAIL);
				response.setDescription("作废失败,当前状态不正确");
			}
		}catch (Exception e) {
			logger.error("借款撤销申请异常",e);
			response = new RestResponse(MsgErrCode.FAIL);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}	
		return response;
	}
	
    /**
     * 借款撤销修改流程
     */
	 @Transactional(rollbackFor = Exception.class)
	 public boolean saveData(Long applyId) throws Exception
	 {
		 /**合同废除 */
		 Map<String, Object> map = new HashMap<>(2);
		 map.put("applyId", applyId);
		 ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
		 if(NodeStateConstant.IN_THE_BID.equals(applyBillMainInfoDO.getState())){
			 /**合同审核进行合同废除*/
			 User loginUser = SessionUtil.getLoginUser(User.class);
			 Long userId = loginUser.getId();
				
			 /**更新流程状态为合同作废*/
					 
			 MainLogDTO mainLogDTO = new MainLogDTO();
			 mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_INVALIDATION);
			 mainLogDTO.setMainId(applyBillMainInfoDO.getId());
			 mainLogDTO.setModifyUser(userId);
			 currencyDao.addMainLog(mainLogDTO);
						
			 String oldData =  JsonUtil.object2json(applyBillMainInfoDO);
			 
			 applyBillMainInfoDO.setPrevious(NodeStateConstant.IN_THE_BID);			
			 applyBillMainInfoDO.setState(NodeStateConstant.CONTRACT_INVALIDATION);
			 applyBillMainInfoDO.setModifyTime(new Date());
			 applyBillMainInfoDO.setModifyUser(userId);

			 String newData = JsonUtil.object2json(applyBillMainInfoDO);
			 boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			 if(flag){
				currencyDao.updateMainInFo(applyBillMainInfoDO);
			 }
			 /**更新合同表合同状态*/
			 XybContractDO xybContractDO = dao.getXybContractDO(applyId);
			 String oldContractData = JsonUtil.object2json(xybContractDO);
			 xybContractDO.setContractState(SysDictEnum.CONTRACT_STATE_HTZF.getCode());
			 xybContractDO.setContractAbolitionTime(new Date());
			 xybContractDO.setContractAbolition(SysDictEnum.CONTRACT_STATE_HTZF_REASON_HTMJSB.getCode().toString());
			 xybContractDO.setContractAbolitionName(SysDictEnum.CONTRACT_STATE_HTZF_REASON_HTMJSB.getName());
			 xybContractDO.setRemarks(SysDictEnum.CONTRACT_STATE_HTZF_REASON_HTMJSB.getName());
			 xybContractDO.setModifyName(loginUser.getName());
			 xybContractDO.setModifyTime(new Date());
			 xybContractDO.setModifyUser(userId);
			 xybContractOwnuseService.updateContractNotNull(userId,oldContractData,xybContractDO);
			 
			 FinancePaymentDO financePaymentDO = financePaymentDao.getFinancePaymentForPayment(xybContractDO.getId());
       
			 /**更新待交易表state状态为处理失败*/
			 financePaymentDO.setState(SysDictEnum.PAY_MENT_DETAILS_CLSB.getCode());
			 financePaymentDao.updateOnlyChanged(financePaymentDO);
			 
			 /**更新批次明细表state状态为处理失败*/

			 financeBatchDetailsDao.updateFinanceBatchDetailsFail(financePaymentDO.getId());
		}
		return true;
	 }

	 /**
	  * 调用深圳借款撤销接口,日志独立事物,事物传播类型：Propagation.REQUIRES_NEW
	  * @param applyId
	  * @param dataJson
	  * @return
	  * @throws Exception
	  */
	private String sendPost(Long applyId,String dataJson) throws Exception{
		    logger.info("调用深圳借款撤销接口开始,申请id:" + applyId + ",请求参数：" + dataJson);
		    String result = PosMainStart.sendPost(applyRevokeUrl, dataJson);
		    logger.info("调用深圳借款撤销接口结束,申请id:" + applyId + ",返回参数：" + result);
		    /**保存接口日志*/
		    /**日志存储*/
	        InterfaceLogDO interfaceLogDO = new InterfaceLogDO();
	        interfaceLogDO.setApply_id(applyId);
	        interfaceLogDO.setInterface_name(InterfaceLogConstants.INTERFACE_APPLY_REVOKE);
	        interfaceLogDO.setInvocation(InterfaceLogConstants.INVOK_TYPE_0);
	        interfaceLogDO.setRequest(dataJson);
	        interfaceLogDO.setResponse(result);
	        interfaceLogDO.setState(SysDictEnum.YES.getCode());
		    interfaceLogOwnService.addInterfaceLog(interfaceLogDO);
		    return result;
	 }
}	 
