package com.xyb.order.pc.ownuse.service.contract;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.credit.common.model.MessageParamerDTO;
import com.xyb.credit.common.model.MessageTemplateDTO;
import com.xyb.credit.common.model.MessageTemplateVO;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.message.model.SendMessageCurrencyDTO;
import com.xyb.order.common.msg.SysDictEnum;

import org.apache.commons.collections.map.HashedMap;
import org.exolab.castor.dsml.Producer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.utils.DateTimeUtil;
import com.google.gson.Gson;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.auditend.dao.AuditEndDao;
import com.xyb.order.pc.auditend.model.AuditEndApplyInfoDO;
import com.xyb.order.pc.auditend.model.AuditEndApplyMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.contract.model.repaymentplan.XybContractRepaymentPlanDO;
import com.xyb.order.pc.contract.service.XybContractService;
import com.xyb.order.pc.ownuse.service.contract.reapymentplan.FeeRateOwnService;
import com.xyb.order.pc.product.model.ProductExtDO;
import com.xyb.order.common.util.JsonUtil;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract
 * @description : 合同自用service
 * @createDate : 2018/5/10 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class XybContractOwnuseService {
	private static final Logger logger = LoggerFactory.getLogger(XybContractOwnuseService.class);
	@Autowired
	private XybContractDao dao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private FeeRateOwnService feeRateOwnService;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private AuditEndDao auditEndDao;
	@Autowired
	private XybContractService xybContractService;
	@Autowired
	private CurrencyDao currencyDao;
	@Reference
	private CreditCommonService creditCommonService;
	@Autowired
	private XybContractDao xybContractDao;
	
	static Gson gson = new Gson();

	public void updateContractNotNull(Long userId,String oldData,XybContractDO xybContractDONew){
		/**1.对比是否需要修改,是：修改contract表,添加表修改日志*/
		boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,xybContractDONew.getId(),TableConstant.T_XYB_CONTRACT,oldData,JsonUtil.object2json(xybContractDONew));
		if(flag){
			dao.updateContractNotNull(xybContractDONew);
		}
	}

	@SuppressWarnings("unused")
	private void insertContract(XybContractDO bean){
		dao.insertContract(bean);
	}
	
	/**
	 * 生成还款计划
	 */
	@Transactional(rollbackFor = Exception.class)
	public List<XybContractRepaymentPlanDO> repaymentPlan(ApplyBillMainInfoDO applyBillMainInfoDO,BigDecimal serviceAmount){
		logger.info("----生成还款计划开始,合同id："+applyBillMainInfoDO.getContractId());
		long beginTime = System.currentTimeMillis();
		List<XybContractRepaymentPlanDO> list = new ArrayList<>();
		try {
			/**新还款计划生成方法*/
			list = feeRateOwnService.getRepaymentPlans(applyBillMainInfoDO,serviceAmount);
			/**删除原还款计划*/
			dao.deleteRepaymentPlan(applyBillMainInfoDO.getApplyId());
			/**批量添加还款计划*/
			dao.addPlans(list);
			
		} catch (Exception e) {
			logger.error("生成还款计划失败",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		long endTime = System.currentTimeMillis();
		logger.info("----生成还款计划开始结束,处理时长："+String.valueOf(endTime - beginTime));
		return list;
	} 
	/**
	 * 速贷产品批贷逻辑
	 * @param applyId
	 */
	@Transactional(rollbackFor = Exception.class)
	public void agreeLoan(Long applyId){
		try {
			/**1.更新申请表和主表信息*/
			/**1.1查询主表当前数据*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", applyId);
			ApplyBillMainInfoDO applyMainInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(map);
			/**1.2查询产品拓展表数据*/
			List<ProductExtDO> productExtDOs = xybContractDao.getProductExtList(applyMainInfo.getExpectProductId());
	        /**1.2计算服务费*/
	        BigDecimal serviceAmount = this.calculateServiceAmount(applyMainInfo.getExpectMoney(), applyMainInfo.getExpectTerm(), productExtDOs.get(0).getServiceProportion());
	        /**1.3更新申请表*/
	        AuditEndApplyInfoDO auditEndApplyInfoDO = new AuditEndApplyInfoDO();
	        auditEndApplyInfoDO.setId(applyId);
	        auditEndApplyInfoDO.setRefuse(SysDictEnum.NO.getCode());
	        auditEndApplyInfoDO.setOperationUser(CurrencyConstant.SYSTEM_USER);
	        auditEndApplyInfoDO.setAgreeProductExtId(productExtDOs.get(0).getProductExtId());
	        auditEndApplyInfoDO.setAgreeProductId(applyMainInfo.getExpectProductId());
	        auditEndApplyInfoDO.setAmount(applyMainInfo.getExpectMoney());
	        auditEndApplyInfoDO.setServiceAmount(serviceAmount);
	        auditEndDao.updateApplyInfo(auditEndApplyInfoDO);
	        /**1.4更新主表*/
	        AuditEndApplyMainInfoDO auditEndApplyMainInfoDO = new AuditEndApplyMainInfoDO();
	        auditEndApplyMainInfoDO.setId(applyMainInfo.getId());
	        auditEndApplyMainInfoDO.setRefuse(SysDictEnum.NO.getCode());
	        auditEndApplyMainInfoDO.setEndauditOverTime(DateTimeUtil.getNow());
	        auditEndApplyMainInfoDO.setAgreeAmount(applyMainInfo.getExpectMoney());
	        auditEndApplyMainInfoDO.setServiceAmount(serviceAmount);
	        auditEndApplyMainInfoDO.setLoanMoney(applyMainInfo.getExpectMoney());
	        auditEndApplyMainInfoDO.setContractMoney(applyMainInfo.getExpectMoney());
	        auditEndApplyMainInfoDO.setAgreeProductId(applyMainInfo.getExpectProductId());
	        auditEndApplyMainInfoDO.setAgreeProductName(applyMainInfo.getExpectProductName());
	        auditEndApplyMainInfoDO.setAgreeProductLimit(applyMainInfo.getExpectTerm());
	        auditEndApplyMainInfoDO.setProductProportion(productExtDOs.get(0).getProductProportion());
	        auditEndApplyMainInfoDO.setServiceProportion(productExtDOs.get(0).getServiceProportion());
	        	/**当前默认A*/
	        auditEndApplyMainInfoDO.setServiceProportionType("A");
	        auditEndApplyMainInfoDO.setLoanChannelId(SysDictEnum.LOAN_CHANNEL_XYB.getCode());
	        auditEndApplyMainInfoDO.setOperationUser(CurrencyConstant.SYSTEM_USER);
	        auditEndDao.updateApplyMainInfo(auditEndApplyMainInfoDO);
			/**2.初始化合同信息*/
            xybContractService.addContract(applyId, SysDictEnum.LOAN_CHANNEL_XYB.getCode(), CurrencyConstant.SYSTEM_USER, null);
			/**3.流程跳转*/
			MainLogDTO mainLogDTO = new MainLogDTO();
			mainLogDTO.setBusinessState(NodeStateConstant.CONTRACT_ENTRY);
			mainLogDTO.setMainId(applyMainInfo.getId());
			mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
			currencyDao.addMainLog(mainLogDTO);
			/**4.发送短信*/
			creditCommonService.sendMessage(applyMainInfo.getId());
		} catch (Exception e) {
			logger.error("速贷产品批贷后业务逻辑处理失败",e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
	}
	
    /**
     * 计算服务费
     *
     * @param auditAmount
     * @param serviceProportion
     * @return
     */
    @SuppressWarnings("unused")
	private BigDecimal calculateServiceAmount(BigDecimal auditAmount, Integer productLimit, BigDecimal serviceProportion) {
        BigDecimal serviceAmount = auditAmount.multiply(serviceProportion).multiply(new BigDecimal(productLimit));
        return new BigDecimal(serviceAmount.setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
    }
 
}
