package com.xyb.order.pc.ownuse.service.finance;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.finance.FinancePaymentDO;
import com.xyb.order.pc.finance.dao.FinancePaymentDao;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract
 * @description : finance自用service
 * @createDate : 2018/5/10 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class FinanceOwnService {

	@Autowired
	private FinancePaymentDao financePaymentDao;
	@Transactional(rollbackFor=Exception.class)
	public FinancePaymentDO setPaymentByOut(Long loginId, XybContractDO xybContractDO,ApplyBillMainInfoDO applyBillMainInfoDO) {
        FinancePaymentDO fpm = new FinancePaymentDO();
        // 代付
        // 设定拆分金额20W
		BigDecimal single = BigDecimal.valueOf(20000000);
        // DecimalFormat df = new DecimalFormat("######0.00");
		

        BigDecimal amount = applyBillMainInfoDO.getAgreeAmount();
        BigDecimal amountLong = (amount.multiply(new BigDecimal(100)));
        BigDecimal a = amountLong.divideToIntegralValue(single);
        BigDecimal b = amountLong.divideAndRemainder(single)[1];
        if (!b.equals(0)) {
            a = a.add(new BigDecimal(1)).setScale(0);
        }
        
        for (int i = 0; i < Integer.valueOf(a.toString()); i++) {
            BigDecimal splitAmount = new BigDecimal(200000.00);
            if (i == Long.valueOf(a.subtract(new BigDecimal(1)).toString()) && !b.equals(BigDecimal.ZERO)) {
                splitAmount = b.divide(new BigDecimal(100));
            }
            fpm.setContractId(xybContractDO.getId()); // 合同ID
            fpm.setCusId(applyBillMainInfoDO.getClientId()); // 客户ID
            fpm.setInOutFlag(SysDictEnum.IN_OUT_FLAG_DF.getCode()); // 代付
            fpm.setAccountType(SysConstants.PERSONAGE);// 个人账户
            fpm.setTotalAmount(splitAmount); // 交易金额
            fpm.setBankType(xybContractDO.getBankType().intValue()); // 银行大类
            fpm.setRefundCardNum(xybContractDO.getRefundCardNum());
            fpm.setBankAccount(xybContractDO.getBankAccount());
            fpm.setState(SysDictEnum.PAY_MENT_DETAILS_DCL.getCode());// 状态：待放款
            fpm.setCreateTime(new Timestamp(System.currentTimeMillis()));
            fpm.setCreateUser(loginId);
            fpm.setClientIdcard(xybContractDO.getClientIdcard());
            fpm.setMp(xybContractDO.getMp());
            fpm.setOrgId(xybContractDO.getStoreOrgId());
            financePaymentDao.addFinancePayment(fpm);
        }
        return fpm;
	}
}
