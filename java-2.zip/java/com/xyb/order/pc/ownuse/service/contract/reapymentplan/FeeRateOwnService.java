package com.xyb.order.pc.ownuse.service.contract.reapymentplan;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.xyb.credit.util.RefundAdpaterLineStrategy;
import com.xyb.credit.util.RefundUnit;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.model.newrepaymentplan.DEBXRefundStrategy;
import com.xyb.order.pc.contract.model.repaymentplan.FeeRateQueryBeanDTO;
import com.xyb.order.pc.contract.model.repaymentplan.XybContractRepaymentPlanDO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract.reapymentplan;
 * @description : 还款计划自用service
 * @createDate : 2018/6/1 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class FeeRateOwnService {
	private static final Logger logger = LoggerFactory.getLogger(FeeRateOwnService.class);

	/**
	 * 费率计算服务方法
	 * @param queryBean
	 * @return
	 */
	public List<XybContractRepaymentPlanDO> feeRateCalculation(FeeRateQueryBeanDTO queryBean,ApplyBillMainInfoDO applyBillMainInfoDO){
		
		List<XybContractRepaymentPlanDO> list = new ArrayList<XybContractRepaymentPlanDO>();
		BigDecimal actualSum = queryBean.getActualSum();//实际金额
		BigDecimal borrowRate = queryBean.getProductProportion();//借款利率
		BigDecimal serviceRate = queryBean.getServiceProportion();//服务费率

		int n = queryBean.getProductLimit();//期次
		if(n > 0){

			//还款计划统一精度按深圳计算方法计算初始化
			RefundAdpaterLineStrategy rsl = RefundAdpaterLineStrategy.getInstance();
			List<RefundUnit> rusa = rsl.getActualSumRefund(n,actualSum, borrowRate);
			List<RefundUnit> russ = rsl.getServiceRefund(n, actualSum,borrowRate, serviceRate);
			List<RefundUnit> loaners = rsl.getLoanerRefund(n, actualSum,borrowRate, serviceRate);
			logger.info("深圳计算还款计划公式"+loaners);
			//南粤还款计算按深圳精度计算

			for(int i=0 ; i < n ; i++){
				XybContractRepaymentPlanDO  plan = new XybContractRepaymentPlanDO();
				/**初始化数据*/
				plan.setApplyId(applyBillMainInfoDO.getApplyId());
				plan.setContractId(applyBillMainInfoDO.getContractId());
				plan.setTotalPeriod(applyBillMainInfoDO.getAgreeProductLimit());
				plan.setState(SysDictEnum.CONTRACT_REPAYMENT_PLAN_DHK.getCode());
				plan.setAccountType(SysDictEnum.CONTRACT_REPAYMENT_PLAN_ACCOUNT_TYPE_GR.getCode());
				plan.setCreateTime(new Date());
				plan.setCreateUser(applyBillMainInfoDO.getContractUid());
				plan.setModifyTime(new Date());
				plan.setModifyUser(applyBillMainInfoDO.getContractUid());
				
				plan.setProductLimit(i+1);
				
				//修改月还金额为深圳计算方式
				BigDecimal monthReturn = loaners.get(i).getTotalRefund();

				//按深圳的方法重新计算还款方式
				plan.setCapitalContract(loaners.get(i).getPrincipal());
				plan.setInterest(rusa.get(i).getInterest());
				plan.setServiceInterest(russ.get(i).getInterest());
				plan.setChannelMonthReturn(monthReturn); 
				plan.setCapital(rusa.get(i).getPrincipal());
				plan.setAccountService(russ.get(i).getPrincipal());
				
				plan.setMonthReturn(monthReturn);//月还金额
				//2017/2/27  一次性还款金额=当期本息+未到期本金之和*（1+1%）

				plan.setReturnAll(loaners.get(i).getOncePay());
				list.add(plan);
			}
		
		}
		
		return list;
		
	}

	/**
	 * 按深圳提供包生成还款计划
	 * @param applyBillMainInfoDO
	 * @return
	 */
	public List<XybContractRepaymentPlanDO> getRepaymentPlans(ApplyBillMainInfoDO applyBillMainInfoDO,BigDecimal serviceAmount){
		List<XybContractRepaymentPlanDO> list = new ArrayList<XybContractRepaymentPlanDO>();
		/**借款利率*/
		BigDecimal monthRate = applyBillMainInfoDO.getProductProportion();
		/**期次*/
		int n = applyBillMainInfoDO.getAgreeProductLimit();
		/**调用深圳提供的包生成还款数据整合到当前系统中*/
		/**借款年化利率*/
		BigDecimal yearRate = monthRate.multiply(new BigDecimal(12)).setScale(5);
		List<com.xyb.order.pc.contract.model.newrepaymentplan.RefundUnit> refundPlans = new DEBXRefundStrategy().bulidRefundUnits(yearRate, new BigDecimal("0.00"), n, 0,applyBillMainInfoDO.getContractMoney(),new Date());
		BigDecimal contractAmount = applyBillMainInfoDO.getContractMoney();
		for (int i = 0; i < refundPlans.size(); i++) {
			com.xyb.order.pc.contract.model.newrepaymentplan.RefundUnit unit = refundPlans.get(i);
			XybContractRepaymentPlanDO  plan = new XybContractRepaymentPlanDO();
			/**初始化数据*/
			plan.setApplyId(applyBillMainInfoDO.getApplyId());
			plan.setContractId(applyBillMainInfoDO.getContractId());
			plan.setTotalPeriod(applyBillMainInfoDO.getAgreeProductLimit());
			plan.setState(SysDictEnum.CONTRACT_REPAYMENT_PLAN_DHK.getCode());
			plan.setAccountType(SysDictEnum.CONTRACT_REPAYMENT_PLAN_ACCOUNT_TYPE_GR.getCode());
			plan.setCreateTime(new Date());
			plan.setCreateUser(applyBillMainInfoDO.getContractUid());
			plan.setModifyTime(new Date());
			plan.setModifyUser(applyBillMainInfoDO.getContractUid());
			plan.setProductLimit(i+1);
			
			/**当期剩余应还本金*/
			contractAmount = contractAmount.subtract(refundPlans.get(i).getPrincipal());
			plan.setCapital(unit.getPrincipal());
			plan.setInterest(unit.getInterest());
			plan.setMonthReturn(unit.getPrincipal().add(unit.getInterest()));
			plan.setChannelMonthReturn(unit.getPrincipal().add(unit.getInterest()));
			/**当期一次性结清金额=当期本金+当期利息+当期剩余应还本金*/
			plan.setReturnAll(unit.getPrincipal().add(unit.getInterest()).add(contractAmount));
			plan.setAccountService(serviceAmount.divide(new BigDecimal(n), 2, BigDecimal.ROUND_CEILING));
			list.add(plan);
		}
		return list;
	}

}
