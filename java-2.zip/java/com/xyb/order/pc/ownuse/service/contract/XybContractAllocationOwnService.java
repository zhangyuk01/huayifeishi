package com.xyb.order.pc.ownuse.service.contract;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractAllocationDTO;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract
 * @description : 合同分配自用service
 * @createDate : 2018/5/10 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class XybContractAllocationOwnService{
	
	@Autowired
	private XybContractDao xybContractDao;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	
	/**
	 * 合同/合同审核 重新分配方法
	 * 
	 */
	@Transactional(rollbackFor=Exception.class)
	public void contractAllocation(XybContractAllocationDTO xybContractAllocationDTO) throws Exception{
		if("A".equals(xybContractAllocationDTO.getType())){
			/**批量合同重新分配*/
			Map<String, Object> map = new HashMap<>();
			map.put("applyIds", xybContractAllocationDTO.getApplyIds());
			map.put("contractUid", xybContractAllocationDTO.getUserId());
			map.put("type", xybContractAllocationDTO.getType());
			map.put("modifyUser", SysDictEnum.SYS_ADMIN_CODE.getCode());
			currencyDao.updateContractUidOrContractReviewId(map);
		}else if("B".equals(xybContractAllocationDTO.getType())){
			/**合同审核重新分配*/
			/**按applyIds循环单子进行重新分配*/
			Map<String, Object> map = new HashMap<>();
			map.put("applyIds", xybContractAllocationDTO.getApplyIds());
			map.put("contractReviewUid", xybContractAllocationDTO.getUserId());
			map.put("type", xybContractAllocationDTO.getType());
			map.put("modifyUser", SysDictEnum.SYS_ADMIN_CODE.getCode());
			currencyDao.updateContractUidOrContractReviewId(map);
		}
	}
	/**
	 * 合同审核自动分配
	 */
	@Transactional(rollbackFor = Exception.class)
	public void contractAuditAutoAllocation(ApplyBillMainInfoDO applyBillMainInfoDO,Long userId) throws Exception{
		User user = SessionUtil.getLoginUser(User.class);
		/**合同审核重新分配*/
		Map<String, Object> map = new HashMap<>(2);
		map.put("postCode", SysDictEnum.CONTRACT_AUDIT_POST_CODE.getCode());
		/**查询所有合同审核人员和处理中单子数量信息*/
		List<Map<Long, Long>>  list = xybContractDao.getContractUserId(map);
		if(list.size() > 0){
			
			/**1.对比是否需要修改,是：修改mainInfo表合同专员,添加表修改日志*/
			String oldData = JsonUtil.object2json(applyBillMainInfoDO);
			applyBillMainInfoDO.setContractReviewUid(list.get(0).get("contractUid"));
			applyBillMainInfoDO.setModifyTime(new Date());
			applyBillMainInfoDO.setModifyUser(SysDictEnum.SYS_ADMIN_CODE.getCode());
			applyBillMainInfoDO.setContractAuditAdoptTime(new Date());

			String newData = JsonUtil.object2json(applyBillMainInfoDO);
			System.out.println("tableModifyService="+tableModifyService);
			System.out.println("user="+user);
			System.out.println("applyBillMainInfoDO="+applyBillMainInfoDO);
			boolean flag = tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
			if(flag){
				currencyDao.updateMainInFo(applyBillMainInfoDO);
			}
//			/**查询所有合同审核待分配的数据*/
//			List<Long> applyIds = applyBillInfoDao.listContractAuditApplyIds();
//			for (int i = 0; i < applyIds.size(); i++) {
//				/**1.每次获取排序后获取第一个审核人员信息进行自动分件*/
//				Map.Entry<Long, Integer> reviewInfo = list.get(0);
//				/**2.查询mainId*/
//				Map<String, Object> mainMap = new HashMap<>(2);
//				mainMap.put("applyId", applyIds.get(i));
//				ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
//				
//				/**3.对比是否需要修改,是：修改mainInfo表合同专员,添加表修改日志*/
//				String oldData = JsonUtil.object2json(applyBillMainInfoDO);
//				
//				applyBillMainInfoDO.setContractReviewId(reviewInfo.getKey());
//				applyBillMainInfoDO.setModifyTime(new Date());
//				applyBillMainInfoDO.setModifyUser(SysDictEnum.SYS_ADMIN_CODE.getCode());
//				applyBillMainInfoDO.setContractAuditAdoptTime(new Date());
//
//				String newData = JsonUtil.object2json(applyBillMainInfoDO);
//				boolean flag = tableModifyService.insertApplyCommonModifyLog(applyBillMainInfoDO.getId(),TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
//				if(flag){
//					currencyDao.updateMainInFo(applyBillMainInfoDO);
//				}
//				/**4.给当前审核人员已分配单子数量+1 后重新排序*/
//				reviewInfo.setValue(reviewInfo.getValue() + 1);
//				list.set(0, reviewInfo);
//				list.sort(Comparator.comparing(o2 -> o2.getValue()));
//			}
		}
	}
	
}
