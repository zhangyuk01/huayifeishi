package com.xyb.order.pc.ownuse.service.interfacelog;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.xyb.order.common.interfacelog.dao.InterfacelogDao;
import com.xyb.order.pc.contract.model.InterfaceLogDO;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.pc.ownuse.service.contract
 * @description : 接口日志自用service
 * @createDate : 2018/5/10 17:31
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service
public class InterfaceLogOwnService {
	
	@Autowired
	private InterfacelogDao interfacelogDao;
	
	public  List<InterfaceLogDO> queryInterfaceLogs(Map<String, Object> map){
		return interfacelogDao.queryInterfaceLogs(map);
	}
	
	/**
     * 添加接口日志数据,日志独立事物,事物传播类型：Propagation.REQUIRES_NEW
     *
     * @param interfaceLogDO
     */
	@Transactional(rollbackFor = Exception.class , propagation=Propagation.REQUIRES_NEW)
    public  void addInterfaceLog(InterfaceLogDO interfaceLogDO){
    	interfacelogDao.addInterfaceLog(interfaceLogDO);
    }

}
