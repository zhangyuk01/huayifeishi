package com.xyb.order.pc.creditreport.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDO;
import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDTO;

/**
 * @ClassName AuditPersonalIncomeDao
 * @author ZhangYu
 * @date 2018年4月23号
 */

public interface AuditPersonalIncomeDao {

	public List<AuditPersonalIncomeDO> queryInfoByApplyId(Map<String, Object> paramMap);

    public AuditPersonalIncomeDO queryInfoById(Long id);
    
    public void addPersonalIncome(@Param("auditPersonalIncomeDTOs") List<AuditPersonalIncomeDTO> auditPersonalIncomeDTOs);
    
    public void uppdatePersonalIncome(@Param("auditPersonalIncomeDTOs") List<AuditPersonalIncomeDTO> auditPersonalIncomeDTOs);
    
    public void updateDelFlagById(Map<String, Object> paramMap);

}
