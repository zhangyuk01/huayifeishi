package com.xyb.order.pc.creditreport.dao;

import com.xyb.order.pc.creditreport.model.AuditOtherHouseDO;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDTO;

/**
 * @ClassName AuditOtherHouseDao
 * @author ZhangYu
 * @date 2018年4月25号
 */

public interface AuditOtherHouseDao {

	AuditOtherHouseDO queryInfoByApplyId(Long applyId);
	
	AuditOtherHouseDO queryInfoById(Long id);
	
	void updateInfoById(AuditOtherHouseDTO auditOtherHouseDTO);
	
	void addInfo(AuditOtherHouseDTO auditOtherHouseDTO);

}
