package com.xyb.order.pc.creditreport.dao;

import com.xyb.order.pc.creditreport.model.AuditVerifyDO;
import com.xyb.order.pc.creditreport.model.AuditVerifyDTO;

/**
 * @ClassName AuditVerifyDao
 * @author ZhangYu
 * @date 2018年5月7号
 */
public interface AuditVerifyDao {
	
	AuditVerifyDO queryVerifyInfoByApplyId(Long applyId);
	
	AuditVerifyDO queryVerifyInfoById(Long id);
	
	void addVerifyInfo(AuditVerifyDTO auditVerifyDTO);
	
	void updateVerifyInfo(AuditVerifyDTO auditVerifyDTO);

}
