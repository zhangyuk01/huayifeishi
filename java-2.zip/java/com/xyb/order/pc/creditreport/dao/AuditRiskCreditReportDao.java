package com.xyb.order.pc.creditreport.dao;

import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDO;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDTO;

/**
 * @ClassName AuditRiskCreditReportDao
 * @author ZhangYu
 * @date 2018年5月31号
 */
public interface AuditRiskCreditReportDao {

	/**
	 * 查询运营商报告查询次数 
	 * @param applyId
	 * @return
	 */
	ApplyPersonTationQueryDO queryPersonTationQueryDo(Long applyId);
	
	/**
	 * 运营商报告查询次数暂存 
	 * @param applyPersonTationQueryDTO
	 */
	void personTationInfoTempSave(ApplyPersonTationQueryDTO applyPersonTationQueryDTO);

	/**
	 * 运营商报告查询次数新增 
	 * @param applyPersonTationQueryDTO
	 */
	void personTationInfoAdd(ApplyPersonTationQueryDTO applyPersonTationQueryDTO);

}
