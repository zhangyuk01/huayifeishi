package com.xyb.order.pc.creditreport.dao;

import com.xyb.order.pc.creditreport.model.AuditOtherMaterialDO;
import com.xyb.order.pc.creditreport.model.AuditOtherMaterialDTO;
import com.xyb.order.pc.creditreport.model.AuditPersonDO;
import com.xyb.order.pc.creditreport.model.AuditPrivateDO;
import com.xyb.order.pc.creditreport.model.AuditPrivateDTO;

/**
 * @ClassName AuditOtherDao
 * @author ZhangYu
 * @date 2018年4月25号
 */
public interface AuditOtherDao {

	AuditPersonDO queryPersonInfoByApplyId(Long applyId);

	AuditPrivateDO queryPrivateInfoByApplyId(Long applyId);

	AuditPrivateDO queryPrivateInfoById(Long id);

	void updateLegalPersonById(AuditPrivateDTO auditPrivateDTO);

	AuditOtherMaterialDO queryOtherMaterialInfoByApplyId(Long applyId);

	void updateOtherMaterialByApplyId(AuditOtherMaterialDTO auditOtherMaterialDTO);
	
}
