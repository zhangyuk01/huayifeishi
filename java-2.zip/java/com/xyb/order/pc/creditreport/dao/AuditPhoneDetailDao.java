package com.xyb.order.pc.creditreport.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.pc.creditreport.model.AuditDetailPhoneDO;
import com.xyb.order.pc.creditreport.model.AuditDetailPhoneDTO;
import com.xyb.order.pc.creditreport.model.AuditPhoneLinkManInfoDO;
import com.xyb.order.pc.creditreport.model.AuditPhoneLinkManInfoDTO;

/**
 * @ClassName AuditPhoneDetailDao
 * @author ZhangYu
 * @date 2018年4月28号
 */

public interface AuditPhoneDetailDao {

	/**
	 * 根据申请单ID查询通话详单信息 
	 * @param applyId
	 * @return
	 */
	public List<AuditPhoneLinkManInfoDO> queryPhoneLinkManInfoByApplyId(Long applyId);

	/**
	 * 根据ID查询通话联系人信息
	 * @param id
	 * @return
	 */
	public AuditPhoneLinkManInfoDO queryPhoneLinkManInfoById(Long id);
	

	/**
	 * 新增通话联系人信息 
	 * @param auditPhoneLinkManInfoDTOs
	 */
	public void addPhoneLinkManInfo(@Param("auditAddPhoneLinkManInfoDTOs") List<AuditPhoneLinkManInfoDTO> auditPhoneLinkManInfoDTOs);

	/**
	 * 修改通话联系人信息 
	 * @param auditPhoneLinkManInfoDTOs
	 */
	public void updatePhoneLinkManInfo(@Param("auditUpdatePhoneLinkManInfoDTOs") List<AuditPhoneLinkManInfoDTO> auditPhoneLinkManInfoDTOs);
	
	/**
	 * 根据 申请单ID查询通话联系人信息
	 * @param applyId
	 * @return
	 */
	public AuditDetailPhoneDO queryPhoneSpecifiInfoByApplyId(Long applyId);

	/**
	 * 根据ID查询通话详情信息 
	 * @param id
	 * @return
	 */
	public AuditDetailPhoneDO queryPhoneSpecifiInfoById(Long id);
	
	/**
	 * 新增通话详单信息 
	 */
	public void addPhoneSpecifiInfo(AuditDetailPhoneDTO auditDetailPhoneDTO);

	/**
	 * 修改通话详单信息 
	 */
	public void updatePhoneSpecifiInfo(AuditDetailPhoneDTO auditDetailPhoneDTO);
	
	

}
