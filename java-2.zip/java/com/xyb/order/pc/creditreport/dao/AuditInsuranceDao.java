package com.xyb.order.pc.creditreport.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.pc.creditreport.model.AuditInsuranceDO;
import com.xyb.order.pc.creditreport.model.AuditInsuranceDTO;

/**
 * @ClassName AuditInsuranceDao
 * @author ZhangYu
 * @date 2018年5月4号
 */
public interface AuditInsuranceDao {

	List<AuditInsuranceDO> queryAuditInsuranceListByApplyId(Long applyId);
	
	AuditInsuranceDO queryAuditInsuranceById(Long id);
	
	void addAuditInsuranceList(@Param("auditInsuranceDTOs") List<AuditInsuranceDTO> auditInsuranceDTOs);
	
	void updateAuditInsuranceList(@Param("auditInsuranceDTOs") List<AuditInsuranceDTO> auditInsuranceDTOs);
	
    void updateAuditDelFlag(Map<String, Object> paramMap);

}
