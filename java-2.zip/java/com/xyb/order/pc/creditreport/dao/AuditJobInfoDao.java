package com.xyb.order.pc.creditreport.dao;

import java.util.Map;

import com.xyb.order.pc.creditreport.model.AuditJobDO;
import com.xyb.order.pc.creditreport.model.AuditJobDTO;

/**
 * @ClassName AuditJobInfoDao
 * @author ZhangYu
 * @date 2018年5月7号
 */
public interface AuditJobInfoDao {

	/**
	 * 根据申请单ID查询工作证明信息 
	 * @param applyId
	 * @return
	 */
   AuditJobDO queryAuditJobInfoByApplyId(Long applyId);	
  
   /**
    * 根据ID查询工作证明信息 
    * @param id
    * @return
    */
   AuditJobDO queryAuditJobInfoById(Long id);
  
   /**
    * 更新工作证明页签信息 
    * @param auditJobDTO
    */
   void updateAuditJobInfo(AuditJobDTO auditJobDTO);
  
   /**
    * 添加工作证明页签信息 
    * @param auditJobDTO
    */
   void addAuditJobInfo(AuditJobDTO auditJobDTO);
   
   /**
    * 修改 个人信息月收入
    * @param paramMap
    */
   void updateAuditPersonMonthMoney(Map<String, Object> paramMap);
  
   /**
    * 根据申请单ID查询申请产品ID 
    * @return
    */
   Long getExpectProductIdByApplyId(Long applyId);
 
   /**
    * 更新社保记录状态
    */
   void updateJinPoRecord(Long applyId);
   
   /**
    * 更新公积金记录状态 
    */
   void updateCpfRecord(Long applyId);

}
