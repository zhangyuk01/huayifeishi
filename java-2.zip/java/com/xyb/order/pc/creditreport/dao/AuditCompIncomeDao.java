package com.xyb.order.pc.creditreport.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.pc.creditreport.model.AuditCompIncomeDO;
import com.xyb.order.pc.creditreport.model.AuditCompIncomeDTO;
/**
 * @ClassName AuditCompIncomeDao
 * @author ZhangYu
 * @date 2018年4月25号
 */
public interface AuditCompIncomeDao {
	
	public List<AuditCompIncomeDO> queryInfoByApplyId(Map<String, Object> paramMap);
	
	public AuditCompIncomeDO queryById(Long id);
	
	public void addCompIncome(@Param("auditCompIncomeDTOs") List<AuditCompIncomeDTO> auditCompIncomeDTOs);

	public void uppdateCompIncome(@Param("auditCompIncomeDTOs") List<AuditCompIncomeDTO> auditCompIncomeDTOs);
	
	public void updateAlreadyDelFlagById(Map<String, Object> paramMap);

}
