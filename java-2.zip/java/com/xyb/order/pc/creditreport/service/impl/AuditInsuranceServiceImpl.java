package com.xyb.order.pc.creditreport.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditInsuranceDao;
import com.xyb.order.pc.creditreport.model.AuditInSuranceAllDO;
import com.xyb.order.pc.creditreport.model.AuditInsuranceAllDTO;
import com.xyb.order.pc.creditreport.model.AuditInsuranceDO;
import com.xyb.order.pc.creditreport.model.AuditInsuranceDTO;
import com.xyb.order.pc.creditreport.service.AuditInsuranceService;
import com.xyb.util.SessionUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;

/**
 * @ClassName AuditInsuranceServiceImpl
 * @author ZhangYu
 * @date 2018年5月4号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditInsuranceService")
public class AuditInsuranceServiceImpl implements AuditInsuranceService{
	@Autowired
	private AuditInsuranceDao auditInsuranceDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;

	@Override
	public RestResponse queryAuditInsuranceListByApplyId(Long applyId)throws Exception {
		List<AuditInsuranceDO> auditInsuranceDOs = this.auditInsuranceDao.queryAuditInsuranceListByApplyId(applyId);
		AuditInSuranceAllDO auditInSuranceAllDO = new AuditInSuranceAllDO();
		auditInSuranceAllDO.setSystemDate(new Date());
		auditInSuranceAllDO.setAuditInsuranceDOs(auditInsuranceDOs);
		if (auditInsuranceDOs != null && auditInsuranceDOs.size() > 0) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.BAODAN_REPORT);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditInSuranceAllDO);
	}

	@Override
	public RestResponse auditInsuranceTempSave(AuditInsuranceAllDTO auditInsuranceAllDTO)throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		List<AuditInsuranceDTO> auditInsuranceDTOs = auditInsuranceAllDTO.getAuditInsuranceDTOs();
		List<AuditInsuranceDTO> addList = new ArrayList<>();
		List<AuditInsuranceDTO> uppdateList = new ArrayList<>();
		if ( auditInsuranceDTOs != null && auditInsuranceDTOs.size() > 0) {
			for (AuditInsuranceDTO auditInsuranceDTO : auditInsuranceDTOs) {
				if (auditInsuranceDTO.getId() != null) {
					AuditInsuranceDO auditInsuranceDO = this.auditInsuranceDao.queryAuditInsuranceById(auditInsuranceDTO.getId());
					boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditInsuranceDO.getId(), TableConstant.T_APPLY_INSURANCE_INFO,
							JsonUtil.object2json(auditInsuranceDO), JsonUtil.object2json(auditInsuranceDTO));
					if (flag) {
						auditInsuranceDTO.setModifyUser(userId);
						uppdateList.add(auditInsuranceDTO);
					}
				}else{
					auditInsuranceDTO.setApplyId(auditInsuranceAllDTO.getApplyId());
					auditInsuranceDTO.setCreateUser(userId);
					auditInsuranceDTO.setModifyUser(userId);
					addList.add(auditInsuranceDTO);
				}
			}
			if (addList.size() > 0) {
				this.auditInsuranceDao.addAuditInsuranceList(addList);
			}
			if (uppdateList.size() > 0) {
				this.auditInsuranceDao.updateAuditInsuranceList(uppdateList);
			}
			otherPlatformRelevantService.insertCheckItem(auditInsuranceAllDTO.getApplyId(), AuditCheckItemConstant.BAODAN_REPORT);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse auditInsuranceDelById(Long id)throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("id", id);
		paramMap.put("delFlag", SysDictEnum.YES.getCode());
		this.auditInsuranceDao.updateAuditDelFlag(paramMap);
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	

}
