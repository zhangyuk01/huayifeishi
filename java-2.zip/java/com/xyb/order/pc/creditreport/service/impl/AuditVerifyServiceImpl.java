package com.xyb.order.pc.creditreport.service.impl;
/**
 * @ClassName AuditVerifyServiceImpl
 * @author ZhangYu
 * @date 2018年5月7号
 */

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.creditreport.dao.AuditVerifyDao;
import com.xyb.order.pc.creditreport.model.AuditVerifyDO;
import com.xyb.order.pc.creditreport.model.AuditVerifyDTO;
import com.xyb.order.pc.creditreport.service.AuditVerifyService;
import com.xyb.util.SessionUtil;

@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditVerifyService")
public class AuditVerifyServiceImpl implements AuditVerifyService{
	
	@Autowired
	private AuditVerifyDao auditVerifyDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;

	@Override
	public RestResponse queryVerifyInfoByApplyId(Long applyId) throws Exception{
		AuditVerifyDO auditVerifyDO = this.auditVerifyDao.queryVerifyInfoByApplyId(applyId);
		if (auditVerifyDO != null) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.APPLY_CHECK);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditVerifyDO);
	}

	@Override
	public RestResponse updateOrAddVerifyInfo(AuditVerifyDTO auditVerifyDTO) throws Exception{
		if (auditVerifyDTO != null) {
			User user = SessionUtil.getLoginUser(User.class);
			Long userId = user.getId();
			if (auditVerifyDTO.getId() != null) {
				AuditVerifyDO auditVerifyDO = this.auditVerifyDao.queryVerifyInfoById(auditVerifyDTO.getId());
				boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditVerifyDO.getId(), TableConstant.T_APPLY_VERIFY,
						JsonUtil.object2json(auditVerifyDO), JsonUtil.object2json(auditVerifyDTO));
				if (flag) {
					this.auditVerifyDao.updateVerifyInfo(auditVerifyDTO);
				}
			}else{
				auditVerifyDTO.setCreateUser(userId);
				this.auditVerifyDao.addVerifyInfo(auditVerifyDTO);
			}
			otherPlatformRelevantService.insertCheckItem(auditVerifyDTO.getApplyId(), AuditCheckItemConstant.APPLY_CHECK);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
