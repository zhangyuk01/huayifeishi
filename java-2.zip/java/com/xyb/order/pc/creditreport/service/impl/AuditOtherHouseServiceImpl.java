package com.xyb.order.pc.creditreport.service.impl;

import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.util.SessionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditOtherHouseDao;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDO;
import com.xyb.order.pc.creditreport.model.AuditOtherHouseDTO;
import com.xyb.order.pc.creditreport.service.AuditOtherHouseService;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.JsonUtil;

/**
 * @ClassName AuditOtherHouseServiceImpl
 * @author ZhangYu
 * @date 2018年4月23号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditOtherHouseService")
public class AuditOtherHouseServiceImpl implements AuditOtherHouseService{

	@Autowired
	private AuditOtherHouseDao auditOtherHouseDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	@Reference
	private ForeignService foreignService;
	
	private static final Logger log = LoggerFactory.getLogger(AuditOtherHouseServiceImpl.class);

	@Override
	public RestResponse queryInfoByApplyId(Long applyId)throws Exception {
		AuditOtherHouseDO auditOtherHouseDO = this.auditOtherHouseDao.queryInfoByApplyId(applyId);
		if (auditOtherHouseDO != null) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.HOUSE_PROPERTY);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditOtherHouseDO);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateOrAddInfoById(AuditOtherHouseDTO auditOtherHouseDTO) throws Exception{
		User user = SessionUtil.getLoginUser(User.class);
		if (auditOtherHouseDTO != null) {
			if (auditOtherHouseDTO.getId() != null) {
				AuditOtherHouseDO auditOtherHouseDO = this.auditOtherHouseDao.queryInfoById(auditOtherHouseDTO.getId());
				boolean flag = this.tableModifyService.insertApplyCommonModifyLog(user.getId(),auditOtherHouseDO.getId(), TableConstant.T_AUDIT_OTHER_HOUSE,
						JsonUtil.object2json(auditOtherHouseDO), JsonUtil.object2json(auditOtherHouseDTO));
				if (flag) {
					this.auditOtherHouseDao.updateInfoById(auditOtherHouseDTO);
				}
			}else{
				this.auditOtherHouseDao.addInfo(auditOtherHouseDTO);
			}
			otherPlatformRelevantService.insertCheckItem(auditOtherHouseDTO.getApplyId(), AuditCheckItemConstant.HOUSE_PROPERTY);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
