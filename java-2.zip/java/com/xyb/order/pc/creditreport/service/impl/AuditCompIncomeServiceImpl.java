package com.xyb.order.pc.creditreport.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditCompIncomeDao;
import com.xyb.order.pc.creditreport.model.AuditAllCompIncomeDTO;
import com.xyb.order.pc.creditreport.model.AuditCompIncomeDO;
import com.xyb.order.pc.creditreport.model.AuditCompIncomeDTO;
import com.xyb.order.pc.creditreport.service.AuditCompIncomeService;
import com.xyb.util.SessionUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;

/**
 * @ClassName AuditPersonalIncomeServiceImpl
 * @author ZhangYu
 * @date 2018年4月23号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditCompIncomeService")
public class AuditCompIncomeServiceImpl implements AuditCompIncomeService{

	@Autowired
	private AuditCompIncomeDao auditCompIncomeDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;

	@Override
	public RestResponse queryInfoByApplyId(Long applyId)throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("applyId", applyId);
		paramMap.put("alreadyDelFlag", SysDictEnum.NO.getCode());
		List<AuditCompIncomeDO> auditCompIncomeDOs = this.auditCompIncomeDao.queryInfoByApplyId(paramMap);
		if (auditCompIncomeDOs != null && auditCompIncomeDOs.size() > 0) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.ENTERPRISE_INCOME);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditCompIncomeDOs);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateOrAddInfoByApplyId(AuditAllCompIncomeDTO auditAllCompIncomeDTO)throws Exception {
		if (auditAllCompIncomeDTO != null) {
			Long applyId = auditAllCompIncomeDTO.getApplyId();
			List<AuditCompIncomeDTO> addList = new ArrayList<>();
			List<AuditCompIncomeDTO> updateList = new ArrayList<>();
			List<AuditCompIncomeDTO> auditCompIncomeDTOs = auditAllCompIncomeDTO.getAuditCompIncomeDTOs();
			User user = SessionUtil.getLoginUser(User.class);
			Long userId = user.getId();
			if (auditCompIncomeDTOs != null && auditCompIncomeDTOs.size() > 0) {
				for (AuditCompIncomeDTO auditCompIncomeDTO : auditCompIncomeDTOs) {
					if (auditCompIncomeDTO.getId() != null) {
						AuditCompIncomeDO auditCompIncomeDO = this.auditCompIncomeDao.queryById(auditCompIncomeDTO.getId());
						boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditCompIncomeDO.getId(), TableConstant.T_AUDIT_COMP_INCOME,
								JsonUtil.object2json(auditCompIncomeDO), JsonUtil.object2json(auditCompIncomeDTO));
						if (flag) {
							auditCompIncomeDTO.setModifyUser(userId);
							updateList.add(auditCompIncomeDTO);
						}
					}else{
						auditCompIncomeDTO.setApplyId(applyId);
						auditCompIncomeDTO.setCreateUser(userId);
						auditCompIncomeDTO.setModifyUser(userId);
						addList.add(auditCompIncomeDTO);
					}
				}
			}
			if (addList.size() > 0) {
				this.auditCompIncomeDao.addCompIncome(addList);
			}
			if (updateList.size() > 0) {
				this.auditCompIncomeDao.uppdateCompIncome(updateList);
			}
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.ENTERPRISE_INCOME);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse updateAlreadyDelFlagById(Long id) throws Exception{
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("id",id);
		paramMap.put("alreadyDelFlag", SysDictEnum.YES.getCode());
		this.auditCompIncomeDao.updateAlreadyDelFlagById(paramMap);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
