package com.xyb.order.pc.creditreport.service.impl;


import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.creditreport.dao.AuditJobInfoDao;
import com.xyb.order.pc.creditreport.model.AuditJobDO;
import com.xyb.order.pc.creditreport.model.AuditJobDTO;
import com.xyb.order.pc.creditreport.service.AuditJobInfoService;
import com.xyb.risks.process.Rong360.service.Rong360Service;
import com.xyb.util.SessionUtil;
/**
 * @ClassName AuditJobInfoServiceImpl
 * @author ZhangYu
 * @date 2018年5月7号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditJobInfoService")
public class AuditJobInfoServiceImpl implements AuditJobInfoService{

	@Autowired
	private AuditJobInfoDao auditJobInfoDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private AuthorizationDao authorizationDao;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	@Reference
	private Rong360Service rong360Service;

	
	private static final Logger log = LoggerFactory.getLogger(AuditJobInfoServiceImpl.class);

	@Override
	public RestResponse queryAuditJobInfo(Long applyId)throws Exception {
		AuditJobDO auditJobDO = this.auditJobInfoDao.queryAuditJobInfoByApplyId(applyId);
		if (auditJobDO != null) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.WORK);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditJobDO);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateOrAddAuditJobInfo(AuditJobDTO auditJobDTO)throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		Long userId = user.getId();
		/**新增或者更新工作证明信息**/
		if (auditJobDTO.getId() != null) {
			AuditJobDO auditJobDO = this.auditJobInfoDao.queryAuditJobInfoById(auditJobDTO.getId());
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditJobDO.getId(), TableConstant.T_APPLY_JOB_INFO,
					JsonUtil.object2json(auditJobDO), JsonUtil.object2json(auditJobDTO));
			if (flag) {
				auditJobDTO.setModifyUser(userId);
				this.auditJobInfoDao.updateAuditJobInfo(auditJobDTO);
			}
		}else{
			auditJobDTO.setApplyId(auditJobDTO.getApplyId());
			auditJobDTO.setCusId(auditJobDTO.getCusId());
			this.auditJobInfoDao.addAuditJobInfo(auditJobDTO);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
