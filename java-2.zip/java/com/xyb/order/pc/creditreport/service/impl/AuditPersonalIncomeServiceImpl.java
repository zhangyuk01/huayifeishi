package com.xyb.order.pc.creditreport.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditPersonalIncomeDao;
import com.xyb.order.pc.creditreport.model.AuditAllPersonalIncomeDTO;
import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDO;
import com.xyb.order.pc.creditreport.model.AuditPersonalIncomeDTO;
import com.xyb.order.pc.creditreport.service.AuditPersonalIncomeService;
import com.xyb.util.SessionUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;

/**
 * @ClassName AuditPersonalIncomeServiceImpl
 * @author ZhangYu
 * @date 2018年4月23号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditPersonalIncomeService")
public class AuditPersonalIncomeServiceImpl implements AuditPersonalIncomeService{

	@Autowired
	private AuditPersonalIncomeDao auditPersonalIncomeDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;

	@Override
	public RestResponse queryInfoByApplyId(Long applyId)throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("applyId", applyId);
		paramMap.put("alreadyDelFlag",SysDictEnum.NO.getCode());
		List<AuditPersonalIncomeDO> auditPersonalIncomeDOs = this.auditPersonalIncomeDao.queryInfoByApplyId(paramMap);
		if (auditPersonalIncomeDOs != null && auditPersonalIncomeDOs.size() >0) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.PERSONAL_INCOME);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditPersonalIncomeDOs);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateOrAddInfoByApplyId(AuditAllPersonalIncomeDTO auditAllPersonalIncomeDTO)throws Exception {
		if (auditAllPersonalIncomeDTO != null) {
			Long applyId = auditAllPersonalIncomeDTO.getApplyId();
			List<AuditPersonalIncomeDTO> addList = new ArrayList<>();
			List<AuditPersonalIncomeDTO> uppdateList = new ArrayList<>();
			User user = SessionUtil.getLoginUser(User.class);
			Long userId = user.getId();
			List<AuditPersonalIncomeDTO> auditPersonalIncomeDTOs = auditAllPersonalIncomeDTO.getAuditPersonalIncomeDTOs();
			if (auditPersonalIncomeDTOs != null && auditPersonalIncomeDTOs.size() > 0) {
				for (AuditPersonalIncomeDTO auditPersonalIncomeDTO : auditPersonalIncomeDTOs) {
					if (auditPersonalIncomeDTO.getId() != null) {
						AuditPersonalIncomeDO auditPersonalIncomeDO = this.auditPersonalIncomeDao.queryInfoById(auditPersonalIncomeDTO.getId());
						boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditPersonalIncomeDO.getId(), TableConstant.T_AUDIT_PERSONAL_INCOME,
								JsonUtil.object2json(auditPersonalIncomeDO), JsonUtil.object2json(auditPersonalIncomeDTO));
						if (flag) {
							auditPersonalIncomeDTO.setModifyUser(userId);
							uppdateList.add(auditPersonalIncomeDTO);
						}
					}else{
						auditPersonalIncomeDTO.setApplyId(applyId);
						auditPersonalIncomeDTO.setCreateUser(userId);
						auditPersonalIncomeDTO.setModifyUser(userId);
						addList.add(auditPersonalIncomeDTO);
					}
				}
			}
			if (addList.size() > 0) {
				this.auditPersonalIncomeDao.addPersonalIncome(addList);
			}
			if (uppdateList.size() > 0) {
				this.auditPersonalIncomeDao.uppdatePersonalIncome(uppdateList);
			}
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.PERSONAL_INCOME);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse updateDelFlagById(Long id) throws Exception{
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("id",id);
		paramMap.put("alreadyDelFlag", SysDictEnum.YES.getCode());
		this.auditPersonalIncomeDao.updateDelFlagById(paramMap);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public AuditPersonalIncomeDO queryInfoById(Long id)throws Exception {
		return this.auditPersonalIncomeDao.queryInfoById(id);
	}
	
}
