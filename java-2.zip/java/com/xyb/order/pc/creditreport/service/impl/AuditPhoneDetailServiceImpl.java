package com.xyb.order.pc.creditreport.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditPhoneDetailDao;
import com.xyb.order.pc.creditreport.model.AuditDetailPhoneDO;
import com.xyb.order.pc.creditreport.model.AuditDetailPhoneDTO;
import com.xyb.order.pc.creditreport.model.AuditPhoneLinkManInfoDO;
import com.xyb.order.pc.creditreport.model.AuditPhoneLinkManInfoDTO;
import com.xyb.order.pc.creditreport.model.AuditPhoneDO;
import com.xyb.order.pc.creditreport.model.AuditPhoneDTO;
import com.xyb.order.pc.creditreport.service.AuditPhoneDetailService;
import com.xyb.util.SessionUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.JsonUtil;

/**
 * @ClassName AuditPhoneDetailServiceImpl
 * @author ZhangYu
 * @date 2018年4月23号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditPhoneDetailService")
public class AuditPhoneDetailServiceImpl implements AuditPhoneDetailService{

	@Autowired
	private AuditPhoneDetailDao auditPhoneDetailDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;


	@Override
	public RestResponse queryPhoneDetailInfoByApplyId(Long applyId)throws Exception {
		AuditDetailPhoneDO auditDetailPhoneDO = this.auditPhoneDetailDao.queryPhoneSpecifiInfoByApplyId(applyId);
		if (auditDetailPhoneDO == null) {
			auditDetailPhoneDO = new AuditDetailPhoneDO();
		}
		List<AuditPhoneLinkManInfoDO> auditLinkManInfos = this.auditPhoneDetailDao.queryPhoneLinkManInfoByApplyId(applyId);
		AuditPhoneDO auditPhoneDO = new AuditPhoneDO();
		//获取当前日历信息
		Calendar ca = Calendar.getInstance();  
		int currentMonth=ca.get(Calendar.MONTH)+1;  
		int currentDay=ca.get(Calendar.DATE);  
		int showMonth = 0;
		if (currentDay <= 15) {
			//未超过15号获取前三个月通话详情
			showMonth = currentMonth -1;//6
		}else{
			//超过15号获取本月及以上两个月通话详情
			showMonth = currentMonth;//7
		}
		auditDetailPhoneDO.setMonth1(showMonth);
		auditDetailPhoneDO.setMonth2(showMonth-1);
		auditDetailPhoneDO.setMonth3(showMonth-2);
		auditPhoneDO.setAuditDetailPhone(auditDetailPhoneDO);
		//联系人信息
		if (auditLinkManInfos.size() > 0) {
			for (AuditPhoneLinkManInfoDO auditLinkManInfo : auditLinkManInfos) {
				if (auditLinkManInfo.getMonth1() != null) {
					Integer month1 = auditLinkManInfo.getMonth1();
					if (month1 == showMonth) {
						continue;
					}else if(month1 == showMonth-1){
						auditLinkManInfo.setMonth3(auditLinkManInfo.getMonth2());
						auditLinkManInfo.setMonth3Qty(auditLinkManInfo.getMonth2Qty());
						auditLinkManInfo.setMonth2(auditLinkManInfo.getMonth1());
						auditLinkManInfo.setMonth2Qty(auditLinkManInfo.getMonth1Qty());
						auditLinkManInfo.setMonth1(showMonth);
						continue;
					}else if(month1 == showMonth -2){
						auditLinkManInfo.setMonth3(auditLinkManInfo.getMonth1());
						auditLinkManInfo.setMonth3Qty(auditLinkManInfo.getMonth1Qty());
						auditLinkManInfo.setMonth2(showMonth-1);
						auditLinkManInfo.setMonth1(showMonth);
						continue;
					}else{
						auditLinkManInfo.setMonth3(showMonth-2);
						auditLinkManInfo.setMonth2(showMonth-1);
						auditLinkManInfo.setMonth1(showMonth);
						continue;
					}
				}else{
					auditLinkManInfo.setMonth3(showMonth-2);
					auditLinkManInfo.setMonth2(showMonth-1);
					auditLinkManInfo.setMonth1(showMonth);
				}
			}
			auditPhoneDO.setAuditLinkManInfos(auditLinkManInfos);
			otherPlatformRelevantService.insertCheckItem(applyId,AuditCheckItemConstant.CALL_DETAILS);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditPhoneDO);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse auditPhoneInfoSave(AuditPhoneDTO auditPhoneDTO)throws Exception {
		List<AuditPhoneLinkManInfoDTO> updatePhoneLinkManInfoDTOs = new ArrayList<>();//更新联系人LIST
		List<AuditPhoneLinkManInfoDTO> addPhoneLinkManInfoDTOs = new ArrayList<>(); //新增联系人LIST
		User user = SessionUtil.getLoginUser(User.class);
		Long userId = user.getId();
		AuditDetailPhoneDTO auditDetailPhoneDTO = auditPhoneDTO.getAuditDetailPhoneDTO();
		if (auditDetailPhoneDTO != null) {
			if (auditDetailPhoneDTO.getId() != null) {
				AuditDetailPhoneDO auditDetailPhoneDO = this.auditPhoneDetailDao.queryPhoneSpecifiInfoById(auditDetailPhoneDTO.getId());
				boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditDetailPhoneDO.getId(), TableConstant.T_APPLY_PHONE_SPECIFICATIONS,
						JsonUtil.object2json(auditDetailPhoneDO), JsonUtil.object2json(auditDetailPhoneDTO));
				if (flag) {
					auditDetailPhoneDTO.setModifyUser(userId);
					this.auditPhoneDetailDao.updatePhoneSpecifiInfo(auditDetailPhoneDTO);
			    }
			}else{
				auditDetailPhoneDTO.setCreateUser(userId);
				auditDetailPhoneDTO.setModifyUser(userId);
				this.auditPhoneDetailDao.addPhoneSpecifiInfo(auditDetailPhoneDTO);
			}
		}
		List<AuditPhoneLinkManInfoDTO> auditPhoneLinkManInfoDTOs = auditPhoneDTO.getAuditPhoneLinkManInfoDTOs();
		if (auditPhoneLinkManInfoDTOs != null && auditPhoneLinkManInfoDTOs.size() > 0) {
			for (AuditPhoneLinkManInfoDTO auditPhoneLinkManInfoDTO: auditPhoneLinkManInfoDTOs) {
				if (auditPhoneLinkManInfoDTO.getId() != null) {
					AuditPhoneLinkManInfoDO auditPhoneLinkManInfoDO = this.auditPhoneDetailDao.queryPhoneLinkManInfoById(auditPhoneLinkManInfoDTO.getId());
					boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,auditPhoneLinkManInfoDO.getId(), TableConstant.T_APPLY_SPECIFICATIONS_DETAIL,
							JsonUtil.object2json(auditPhoneLinkManInfoDO), JsonUtil.object2json(auditPhoneLinkManInfoDTO));
					if (flag) {
						auditPhoneLinkManInfoDTO.setModifyUser(userId);
						updatePhoneLinkManInfoDTOs.add(auditPhoneLinkManInfoDTO);
					}
				}else{
					auditPhoneLinkManInfoDTO.setCreateUser(userId);
					auditPhoneLinkManInfoDTO.setModifyUser(userId);
					auditPhoneLinkManInfoDTO.setApplyPhoneId(auditDetailPhoneDTO.getId());
					addPhoneLinkManInfoDTOs.add(auditPhoneLinkManInfoDTO);
				}
			}
		}
		if (addPhoneLinkManInfoDTOs.size() > 0) {
			this.auditPhoneDetailDao.addPhoneLinkManInfo(addPhoneLinkManInfoDTOs);
		}
		if (updatePhoneLinkManInfoDTOs.size() > 0) {
			this.auditPhoneDetailDao.updatePhoneLinkManInfo(updatePhoneLinkManInfoDTOs);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}
}
