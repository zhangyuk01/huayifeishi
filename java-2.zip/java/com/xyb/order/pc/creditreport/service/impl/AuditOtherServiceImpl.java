package com.xyb.order.pc.creditreport.service.impl;

import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.util.SessionUtil;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.creditreport.dao.AuditOtherDao;
import com.xyb.order.pc.creditreport.model.AuditOtherMaterialDO;
import com.xyb.order.pc.creditreport.model.AuditOtherMaterialDTO;
import com.xyb.order.pc.creditreport.model.AuditPersonDO;
import com.xyb.order.pc.creditreport.model.AuditPrivateDO;
import com.xyb.order.pc.creditreport.model.AuditPrivateDTO;
import com.xyb.order.pc.creditreport.service.AuditOtherService;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.StringUtils;

/**
 * @ClassName AuditOtherService
 * @author ZhangYu
 * @date 2018年4月25号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditOtherService")
public class AuditOtherServiceImpl implements AuditOtherService{
	
	@Autowired
	private AuditOtherDao auditOtherDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;

	@Override
	public RestResponse queryPersonInfoByApplyId(Long applyId) throws Exception{
		AuditPersonDO auditPersonDO = this.auditOtherDao.queryPersonInfoByApplyId(applyId);
		if (auditPersonDO != null) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.IDENTITY);
		}
		return new RestResponse(MsgErrCode.SUCCESS, auditPersonDO);
	}

	@Override
	public RestResponse queryPrivateInfoByApplyId(Long applyId) throws Exception{
		AuditPrivateDO auditPrivateDO = this.auditOtherDao.queryPrivateInfoByApplyId(applyId);
		if (auditPrivateDO != null) {
			String enterpriseName = auditPrivateDO.getEnterpriseName();
			Long enteType = auditPrivateDO.getEnteType();
			String legalPerson = auditPrivateDO.getLegalPerson();
			Date regDate = auditPrivateDO.getRegDate();
			Double stockRatio = auditPrivateDO.getStockRatio();
			if (StringUtils.isNotNullAndEmpty(enterpriseName) && enteType != null && 
					StringUtils.isNotNullAndEmpty(legalPerson) && regDate != null && stockRatio !=null) {
				otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.MANAGEMENT);
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS,auditPrivateDO);
	}

	@Override
	public RestResponse updateLegalPersonById(AuditPrivateDTO auditPrivateDTO) throws Exception{
		User user = SessionUtil.getLoginUser(User.class);
		if (auditPrivateDTO != null) {
			AuditPrivateDO auditPrivateDO = this.auditOtherDao.queryPrivateInfoById(auditPrivateDTO.getId());
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(user.getId(),auditPrivateDO.getId(), TableConstant.T_APPLY_PRIVATE_INFO,
					JsonUtil.object2json(auditPrivateDO), JsonUtil.object2json(auditPrivateDTO));
			if (flag) {
				this.auditOtherDao.updateLegalPersonById(auditPrivateDTO);
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse queryOtherMaterialInfoByApplyId(Long applyId)throws Exception {
		AuditOtherMaterialDO auditOtherMaterialDO = this.auditOtherDao.queryOtherMaterialInfoByApplyId(applyId);
		if (auditOtherMaterialDO != null) {
			if (StringUtils.isNotNullAndEmpty(auditOtherMaterialDO.getOtherMaterialRemark())) {
				otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.OTHER);
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS,auditOtherMaterialDO);
	}

	@Override
	public RestResponse updateOtherMaterialInfoTempSave(AuditOtherMaterialDTO auditOtherMaterialDTO) throws Exception{
		if (auditOtherMaterialDTO != null) {
			this.auditOtherDao.updateOtherMaterialByApplyId(auditOtherMaterialDTO);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
