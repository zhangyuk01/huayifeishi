package com.xyb.order.pc.creditreport.service.impl;

import java.util.List;

import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.AuditCheckItemConstant;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.creditreport.dao.AuditRiskCreditReportDao;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDO;
import com.xyb.order.pc.creditreport.model.ApplyPersonTationQueryDTO;
import com.xyb.order.pc.creditreport.service.AuditRiskCreditReportService;
import com.xyb.risks.process.Rong360.model.GjjReport;
import com.xyb.risks.process.Rong360.model.ShebaoReport;
import com.xyb.risks.process.Rong360.service.Rong360Service;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.risks.process.juxinli.juxinliforother.JuXinLiApplicationCheckForOther;
import com.xyb.risks.process.juxinli.juxinliforother.JuXinLiApplicationCheckInData;
import com.xyb.risks.process.juxinli.juxinliforother.JuXinLiReportForOther;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanReport;
import com.xyb.risks.process.juxinli.service.JuXinLiBaoDanService;
import com.xyb.risks.process.juxinli.service.JuxinliService;
import com.xyb.risks.process.mq.HandleInterface;
import com.xyb.risks.process.suanhua.model.SuanHuaReport;
import com.xyb.risks.process.suanhua.service.SuanhuaService;
import com.xyb.util.SessionUtil;

/**
 * @ClassName AuditRiskCreditReportServiceImpl
 * @author ZhangYu
 * @date 2018年5月16号
 */
@Service(interfaceName = "com.xyb.order.pc.creditreport.service.AuditRiskCreditReportService")
public class AuditRiskCreditReportServiceImpl implements AuditRiskCreditReportService{

	@Reference
	private SuanhuaService suanhuaService;
	@Reference
	private Rong360Service rong360Service;
	@Reference
	private JuxinliService juXinLiService;
	@Reference
	private JuXinLiBaoDanService juXinLiBaoDanService;
	@Autowired
	private AuditRiskCreditReportDao auditRiskCreditReportDao;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	@Reference
	private ForeignService foreignService;

	@Override
	public RestResponse getSuanhuaCreditReportQuery(Long applyId)throws Exception {
		RestResponse response;
		try {
			SuanHuaReport suanHuaReport = this.foreignService.getSuanhuaReportOfOrder(String.valueOf(applyId));
			response = new RestResponse(MsgErrCode.SUCCESS, suanHuaReport);
		} catch (Exception e) {
			 e.printStackTrace();
	         throw new RuntimeException("---调取风控简版人行征信报告错误----");
		}
		return  response;
	}

	@Override
	public RestResponse getShebaoReport(Long applyId)throws Exception {
		RestResponse response;
		try {
			ShebaoReport shebaoReport = this.foreignService.shebaoReportOfOrder(String.valueOf(applyId), "gd");
			response = new RestResponse(MsgErrCode.SUCCESS, shebaoReport);
		} catch (Exception e) {
			 e.printStackTrace();
	         throw new RuntimeException("---调取风控社保报告错误----");
		}
		return  response;
	}

	@Override
	public RestResponse getGjjReport(Long applyId)throws Exception {
		RestResponse response;
		try {
			GjjReport gjjReport = this.foreignService.gjjReportOfOrder(String.valueOf(applyId), "gd");
			response = new RestResponse(MsgErrCode.SUCCESS, gjjReport);
		} catch (Exception e) {
			 e.printStackTrace();
	         throw new RuntimeException("---调取风控公积金报告错误----");
		}
		return response;
	}

	@Override
	public RestResponse getYYSReport(Long applyId)throws Exception {
		RestResponse response;
		try {
			HandleInterface handleInterface = new HandleInterface(); 
			handleInterface.setApplyId(String.valueOf(applyId));
			handleInterface.setSysId("gd");
			JuXinLiReportForOther juXinLiReportForXSGD = this.juXinLiService.getJuXinLiReportForXSGD(handleInterface);
			if (juXinLiReportForXSGD != null) {
				juXinLiReportForXSGD.setJuXinLiApplicationCheckForOtherList(juXinLiReportForXSGD.getJuXinLiApplicationCheckForOtherList().subList(0, 10));
			}
			response = new RestResponse(MsgErrCode.SUCCESS, juXinLiReportForXSGD);
		} catch (Exception e) {
			 e.printStackTrace();
	         throw new RuntimeException("---调取运营商报告错误----");
		}
		return response;
	}

	@Override
	public RestResponse getBDReport(Long applyId) throws Exception {
		RestResponse response;
		try {
			HandleInterface handleInterface = new HandleInterface();

			handleInterface.setApplyId(String.valueOf(applyId));
			handleInterface.setSysId("gd");
			JuXinLiBaoDanReport juXinLiBaoDanReport = this.juXinLiBaoDanService.getJxlbdReportForOther(handleInterface);
			response = new RestResponse(MsgErrCode.SUCCESS, juXinLiBaoDanReport);
		} catch (Exception e) {
			 e.printStackTrace();
	         throw new RuntimeException("---调取保单证明报错----");
		}
		return response;
	}

	@Override
	public RestResponse getPhoneCreditReportInfo(Long applyId, String phone) throws Exception {
		RestResponse response;
		try {
			JuXinLiApplicationCheckInData juXinLiApplicationCheckInData = new JuXinLiApplicationCheckInData();
			juXinLiApplicationCheckInData.setApplyId(String.valueOf(applyId));
			juXinLiApplicationCheckInData.setSysId("gd");
			if (StringUtils.isNotNullAndEmpty(phone)) {
				juXinLiApplicationCheckInData.setPhone(phone);
			}
			List<JuXinLiApplicationCheckForOther> juXinLiApplicationCheckForGD = this.juXinLiService.getJuXinLiApplicationCheckForGD(juXinLiApplicationCheckInData);
			response = new RestResponse(MsgErrCode.SUCCESS, juXinLiApplicationCheckForGD);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调取三方电话信息报错----");
		}
		return response;
	}

	@Override
	public RestResponse rhCreditReportCountNumTempSave(ApplyPersonTationQueryDTO applyPersonTationQueryDTO)
			throws Exception {
		Long applyId = applyPersonTationQueryDTO.getApplyId();
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		ApplyPersonTationQueryDO queryPersonTationQueryDo = this.auditRiskCreditReportDao.queryPersonTationQueryDo(applyId);
		if (queryPersonTationQueryDo == null || queryPersonTationQueryDo.getId() == null) {
			applyPersonTationQueryDTO.setCreateUser(userId);
			this.auditRiskCreditReportDao.personTationInfoAdd(applyPersonTationQueryDTO);
		}else{
			applyPersonTationQueryDTO.setModifyUser(userId);
			this.auditRiskCreditReportDao.personTationInfoTempSave(applyPersonTationQueryDTO);
		}
		otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.HUMAN_REPORT);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse getRhCreditReportCountNum(Long applyId) throws Exception {
		ApplyPersonTationQueryDO queryPersonTationQueryDO = this.auditRiskCreditReportDao.queryPersonTationQueryDo(applyId);
		return new RestResponse(MsgErrCode.SUCCESS, queryPersonTationQueryDO==null?new ApplyPersonTationQueryDO():queryPersonTationQueryDO);
	}
}
