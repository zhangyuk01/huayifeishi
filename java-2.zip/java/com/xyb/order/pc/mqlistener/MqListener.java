package com.xyb.order.pc.mqlistener;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.risks.common.model.mqresponse.RiskResponseInfo;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.beiming.kun.utils.StringUtils;
import com.fr.third.v2.org.apache.poi.hssf.usermodel.HSSFWorkbook;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Cell;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Row;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Sheet;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Workbook;
import com.fr.third.v2.org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.google.common.base.Joiner;
import com.xyb.credit.common.model.CheatInterfaceLogDO;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import com.xyb.credit.depend.service.DependService;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.PhoneBookBO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatchDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDTO;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.MqConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.message.dao.MessageDao;
import com.xyb.order.common.message.model.AppNoticeDetailsDO;
import com.xyb.order.common.message.model.AppNoticeTemplateAddDTO;
import com.xyb.order.common.message.model.AppNoticeTemplateDO;
import com.xyb.order.common.message.model.UserDTO;
import com.xyb.order.common.message.service.UMengSendUtil;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.risks.common.model.mqresponse.ErrorCircumstances;
import com.xyb.risks.common.model.mqresponse.MainResponseInfo;

/**
 * mq队列监听
 * @author         xieqingyang
 * @date           2018/5/17 下午5:04
*/
@Component
public class MqListener {

	private static final Logger log = LoggerFactory.getLogger(MqListener.class);

	@Value("${youmeng.bapp.key}")
	private String youmengBappKey;
	@Value("${youmeng.bapp.master.secret}")
	private String youmengBappMasterSecret;
	@Value("${youmeng.capp.key}")
	private String youmengCappKey;
	@Value("${youmeng.capp.master.secret}")
	private String youmengCappMasterSecret;

	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	@Autowired
	private CurrencyDao currencyDao;
	@Reference
	private DependService dependService;
	@Resource(name = "jmsQueueTemplate")
	private JmsTemplate jmsQueueTemplate;
	@Autowired
	private MessageDao messageDao;
	@Autowired
	private UMengSendUtil uMengSendUtil;
	@Autowired
	private ClinetUserModifyService clinetUserModifyService;

	/* ————————————————————————————————————————————————————————————风控——————————————————————————————————————————————————————————————————————————————————*/
	/**
	 * 风控推送结果监听
	 * @author      xieqingyang
	 * @date        2018/10/12 5:32 PM
	 * @version     1.0
	 * @param message 消息队列消息内容
	 */
	@JmsListener(containerFactory = MqConstant.JMS_LISTENER_CONTAINER_FACTORY_ID, destination = MqConstant.SYSTEM_AUDIT_PUSH_DESTINATION)
	public void systemAuditingMonitoring(ActiveMQTextMessage message) {
		try {
			MainResponseInfo mainResponseInfo = JsonUtils.fromJSON(message.getText(), MainResponseInfo.class);
			Long applyMainId = Long.valueOf(mainResponseInfo.getApplyMainId());
			Long applyId = Long.valueOf(mainResponseInfo.getApplyId());
			Long cusId = Long.valueOf(mainResponseInfo.getCusId());
			int submitNode = Integer.valueOf(mainResponseInfo.getSubmitNode());
			Map<String, Object> map = new HashMap<>(2);
			map.put("messageId", message.getJMSMessageID());
			map.put("orderId", applyId);
			// 防重复消费
			if (!otherPlatformRelevantService.getAndInsertMessageConsumeLog(map)) {
				// 添加接口日志
				CheatInterfaceLogDO cheatInterfaceLogDO = new CheatInterfaceLogDO();
				cheatInterfaceLogDO.setApplyMainId(applyMainId);
				cheatInterfaceLogDO.setInterfaceFlag("2");
				cheatInterfaceLogDO.setRequestJson(message.getText());
				cheatInterfaceLogDO.setSubmitNode(String.valueOf(submitNode));
				cheatInterfaceLogDO.setSubmitUser(CurrencyConstant.SYSTEM_USER);
				cheatInterfaceLogDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
				otherPlatformRelevantService.addCheatInterfaceLog(cheatInterfaceLogDO);
				log.info("添加消费日志");
				log.info("开始流程处理");
				log.info("接收数据:"+ message.getText());
				if (mainResponseInfo.getSubmitNode().equals(String.valueOf(NodeStateConstant.CLIENT_APPLY))) {
					log.info("客服申请节点不处理");
					return;
				}
				if (mainResponseInfo.getErrorCircumstances() != null) {
					ErrorCircumstances error = mainResponseInfo.getErrorCircumstances();
					String flowState = error.getFlowState();
					if ("1".equals(flowState)) {
						// -- 添加系统审核是否通过结果
						ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
						applyBillMainInfoDO.setId(applyMainId);
						applyBillMainInfoDO.setIsSysAuditPass(SysDictEnum.YES.getCode());
						currencyDao.updateMainInFo(applyBillMainInfoDO);
						dependService.creditInitialize(applyMainId);
					} else if ("4".equals(flowState) || "5".equals(flowState)) {
						// -- 获取报告异常 返回原节点
						if (NodeStateConstant.PENDING_SYSTEM_AUDIT.equals(submitNode)) {
							submitNode = NodeStateConstant.CUSTOMER_SERVICE_ENTRY;
						}
						updateAndInsertLog(applyMainId, submitNode);
					} else {
						log.info("调用风控系统系统审核重新提交");
						SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(applyMainId,
								submitNode);
						systemAuditParamDTO.setSubmitUser("系统账户");
						systemAuditParamDTO.setSynOrAsy("asynchronous");
						/** 调用风控系统系统审核重新提交 */
						jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION,
								JsonUtils.toJSON(systemAuditParamDTO));
						// -- 添加系统审核是否通过结果
						ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
						applyBillMainInfoDO.setId(applyMainId);
						applyBillMainInfoDO.setIsSysAuditPass(0L);
						currencyDao.updateMainInFo(applyBillMainInfoDO);
					}
				}
				// -- 其他平台上线后替换
				else {
					String repellentCode = null;
					String repellentMessage = null;
					Integer repellentNumberofdays = null;
					String whetherGoodClient = null;
					RiskResponseInfo riskResponseInfo = mainResponseInfo.getRiskResponseInfo();
					if (riskResponseInfo != null){
						repellentCode = riskResponseInfo.getRepellentCode();
						repellentMessage = riskResponseInfo.getRepellentMessage();
						repellentNumberofdays = riskResponseInfo.getRepellentNumberofdays();
						whetherGoodClient = riskResponseInfo.getWhetherGoodClient();
					}
					// -- 批贷
					if (StringUtils.isNullOrEmpty(repellentCode)) {
						if (CurrencyConstant.Y.equals(whetherGoodClient)) {
							// -- 用户等级为现在最高3级
							updateMain(SysDictEnum.CLIENT_GRADE_THREE.getCode(), applyMainId,
									SysDictEnum.YES.getCode());
						} else {
							// -- 用户等级为2级
							updateMain(SysDictEnum.CLIENT_GRADE_TWO.getCode(), applyMainId, SysDictEnum.YES.getCode());
						}
						log.info("提交信审");
						dependService.creditInitialize(applyMainId);
						// -- 拒贷
					} else {
						updateMain(SysDictEnum.CLIENT_GRADE_ONE.getCode(), applyMainId, 0L);
						updateAndInsertLog(repellentCode, repellentMessage, applyMainId);
						clinetUserModifyService.updateClientAllowableEntryTime(cusId, repellentNumberofdays);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("解析系统审核风控结果异常:" + e);
		}
	}

	/**
	 * 添加用户优质等级
	 * 
	 * @param clientGrade
	 */
	private void updateMain(Long clientGrade, Long mainId, Long isSysAuditPass) {
		/** 修改主表 **/
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setClientGrade(clientGrade);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		applyBillMainInfoDO.setIsSysAuditPass(isSysAuditPass);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}

	/**
	 * 修改并添加表日志 refuseCode 拒贷码 refuseValue 拒贷原因
	 */
	private void updateAndInsertLog(String refuseCode, String refuseValue, Long mainId) {
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		mainLogDTO.setModifyUserName("系统账户");
		mainLogDTO.setBusinessState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
		mainLogDTO.setBusinessStateName("系统审核拒贷");
		mainLogDTO.setMainId(mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		if (StringUtils.isNotNullAndEmpty(refuseCode)) {
			applyBillMainInfoDO.setRefuseCode(refuseCode);
			applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
		}
		if (StringUtils.isNotNullAndEmpty(refuseValue)) {
			applyBillMainInfoDO.setRefuseValue(refuseValue);
			applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
		}
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}

	/**
	 * 修改并添加表日志
	 */
	private void updateAndInsertLog(Long mainId, Integer state) {
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		mainLogDTO.setModifyUserName("系统账户");
		mainLogDTO.setBusinessState(state);
		mainLogDTO.setBusinessStateName(NodeStateConstant.MATERIAL_SUPPLEMENT.equals(state) ? "材料补充" : "客服录入中");
		mainLogDTO.setMainId(mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(state);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		applyBillMainInfoDO.setIsSysAuditPass(SysDictEnum.NO.getCode());
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}

	/* ————————————————————————————————————————————————————————————推送消息——————————————————————————————————————————————————————————————————————————————————*/
	/**
	 * app推送消息队列监听
	 * @author      xieqingyang
	 * @date        2018/10/12 5:32 PM
	 * @version     1.0
	 * @param message 推送消息监听
	 */
	@JmsListener(containerFactory = MqConstant.JMS_LISTENER_CONTAINER_FACTORY_ID, destination = MqConstant.MESSAGE_QUEUE)
	public void messageQueue(ActiveMQTextMessage message) {
		try {
			AppNoticeTemplateAddDTO addDTO = JsonUtils.fromJSON(message.getText(), AppNoticeTemplateAddDTO.class);
			String appkey;
			String appMasterSecret;
			List<UserDTO> userDTOs;
			// -- 判断app版本类型
			if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(addDTO.getAppType())) {
				appkey = youmengCappKey;
				appMasterSecret = youmengCappMasterSecret;

			} else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(addDTO.getAppType())) {
				appkey = youmengBappKey;
				appMasterSecret = youmengBappMasterSecret;
			} else {
				log.info("推送消息-app版本填写错误");
				return;
			}
			AppNoticeTemplateDO appNoticeTemplateDO = new AppNoticeTemplateDO();
			appNoticeTemplateDO.setState(SysDictEnum.IS_VALID.getCode());
			appNoticeTemplateDO.setType(addDTO.getType());
			appNoticeTemplateDO.setTitle(addDTO.getTitle());
			appNoticeTemplateDO.setContent(addDTO.getContent());
			appNoticeTemplateDO.setUrl(addDTO.getUrl());
			appNoticeTemplateDO.setAppType(addDTO.getAppType());
			appNoticeTemplateDO.setReleaseTime(addDTO.getReleaseTime());
			appNoticeTemplateDO.setIsTiming(addDTO.getIsTiming());
			appNoticeTemplateDO.setMessageFileName(addDTO.getMessageFileName());
			appNoticeTemplateDO.setMessageFilePath(addDTO.getMessageFilePath());
			appNoticeTemplateDO.setCreateUser(addDTO.getCreateUser());
			appNoticeTemplateDO.setModifyUser(addDTO.getModifyUser());
			// -- 公告
			if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(addDTO.getType())) {
				String iosResult = uMengSendUtil.sendIOSBroadcast(appkey, appMasterSecret, addDTO.getTitle(),
						addDTO.getContent(), addDTO.getUrl(),
						SysDictEnum.YES.getCode().equals(addDTO.getIsTiming()) ? addDTO.getReleaseTime() : null);
				String andResult = uMengSendUtil.sendAndroidBroadcast(appkey, appMasterSecret, addDTO.getTitle(),
						addDTO.getContent(), addDTO.getUrl(),
						SysDictEnum.YES.getCode().equals(addDTO.getIsTiming()) ? addDTO.getReleaseTime() : null);
				appNoticeTemplateDO.setIosTaskId(uMengSendUtil.parseResult(iosResult));
				appNoticeTemplateDO.setAndroidTaskId(uMengSendUtil.parseResult(andResult));
				messageDao.insertAppNoticeTemplate(appNoticeTemplateDO);
				// -- 通知
			} else if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(addDTO.getType())) {
				userDTOs = getUserInFos(addDTO.getMessageFilePath(), addDTO.getMessageFileName(), addDTO.getAppType());
				messageDao.insertAppNoticeTemplate(appNoticeTemplateDO);
				if (userDTOs != null) {
					send(userDTOs, appkey, appMasterSecret, addDTO.getTitle(), addDTO.getContent(), addDTO.getUrl());
					List<AppNoticeDetailsDO> dos = new ArrayList<>();
					for (UserDTO userDTO : userDTOs) {
						AppNoticeDetailsDO appNoticeDetailsDO = new AppNoticeDetailsDO();
						appNoticeDetailsDO.setMainId(appNoticeTemplateDO.getId());
						appNoticeDetailsDO.setUserId(userDTO.getId());
						appNoticeDetailsDO.setName(userDTO.getName());
						appNoticeDetailsDO.setPhone(userDTO.getPhone());
						appNoticeDetailsDO.setDeviceToken(userDTO.getDeviceToken());
						appNoticeDetailsDO.setState(SysDictEnum.NO.getCode());
						appNoticeDetailsDO.setTitle(appNoticeTemplateDO.getTitle());
						appNoticeDetailsDO.setContent(appNoticeTemplateDO.getContent());
						appNoticeDetailsDO.setUrl(appNoticeTemplateDO.getUrl());
						appNoticeDetailsDO.setCreateUser(appNoticeTemplateDO.getCreateUser());
						appNoticeDetailsDO.setModifyUser(appNoticeTemplateDO.getModifyUser());
						dos.add(appNoticeDetailsDO);
						delRedis(appNoticeTemplateDO, userDTO);
					}
					messageDao.insertAppNoticeDetails(dos);
				}
			} else {
				log.info("推送消息-通知类型填写错误");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("推送消息监听队列异常:" + e);
		}
	}

	/**
	 * 删除缓存数据
	 * @author xieqingyang
	 * @date 2018/6/28 下午5:51
	 * @param appNoticeTemplateDO 消息模版数据
	 * @param userDTO 用户数据
	 */
	private void delRedis(AppNoticeTemplateDO appNoticeTemplateDO, UserDTO userDTO) {
		if (appNoticeTemplateDO != null) {
			// -- 公告
			if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appNoticeTemplateDO.getType())) {
				// -- c端
				if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())) {
					RedisUtil.delPre(RedisConstant.C_MESSAGE);
					RedisUtil.del(RedisConstant.C_LAST_MESSAGE);
				} else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateDO.getAppType())) {
					RedisUtil.delPre(RedisConstant.B_MESSAGE);
					RedisUtil.del(RedisConstant.B_LAST_MESSAGE);
				}
			} else if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateDO.getType())) {
				if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())) {
					RedisUtil.delPre(RedisConstant.C_MESSAGE_USER + userDTO.getId());
					RedisUtil.delPre(RedisConstant.C_LAST_MESSAGE_USER + userDTO.getId());
				} else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateDO.getAppType())) {
					RedisUtil.delPre(RedisConstant.B_MESSAGE_USER + userDTO.getId());
					RedisUtil.delPre(RedisConstant.B_LAST_MESSAGE_USER + userDTO.getId());
				}
			}
		}
	}

	/**
	 * 解析附件内容 提取所有手机号
	 * @author xieqingyang
	 * @date 2018/9/4 下午5:10
	 * @version 1.0
	 * @param filePath 文件路径
	 * @param fileName 文件名称
	 * @param appType app类型
	 * @return 返回所有用户信息
	 * @throws Exception 所有异常
	 */
	private List<UserDTO> getUserInFos(String filePath, String fileName, Long appType) throws Exception {
		// -- 根据网络文件地址创建URL
		URL url = new URL(filePath);
		// 获取此路径的连接
		URLConnection conn = url.openConnection();
		// -- 构造读取流
		InputStream is = conn.getInputStream();
		Workbook wb = null;
		// -- 判断文件类型是否符合标准
		if (fileName.endsWith(".xls")) {
			wb = new HSSFWorkbook(is);
		} else if (fileName.endsWith(".xlsx")) {
			wb = new XSSFWorkbook(is);
		}
		// -- 手机号集合
		List<String> phones = new ArrayList<>();
		// 创建工作表sheet
		Sheet sheet = wb.getSheetAt(0);
		int rows = sheet.getPhysicalNumberOfRows();
		// 获取表头的单元格个数
		int cells = 1;
		// 从第X行开始获取手机号
		for (int i = 2; i < rows; i++) {
			// 创建对象
			Row row = sheet.getRow(i);
			int index = 0;
			while (index < cells) {
				Cell cell = row.getCell(index);
				if (null == cell) {
					cell = row.createCell(index);
				}
				cell.setCellType(Cell.CELL_TYPE_STRING);
				String value = (null == cell.getStringCellValue() ? ""
						: cell.getStringCellValue().trim().replace(" ", ""));
				if (com.xyb.order.common.util.StringUtils.isNotNullAndEmpty(value)) {
					phones.add(value);
				}
				index++;
			}
		}
		List<UserDTO> list = null;
		if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appType)) {
			list = messageDao.getClientUserList(phones);
		} else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appType)) {
			list = messageDao.getUserList(phones);
		}
		return list;
	}

	/**
	 * 发送友盟通知
	 * @author xieqingyang
	 * @date 2018/9/4 下午5:34
	 * @version 1.0
	 * @param userDTOS 用户信息集合
	 */
	private void send(List<UserDTO> userDTOS, String appkey, String appMasterSecret, String title, String content,
			String url) {
		// -- 分离ios和android设备
		List<String> ios = new ArrayList<>();
		List<String> android = new ArrayList<>();
		for (UserDTO userDTO : userDTOS) {
			if (StringUtils.isNotNullAndEmpty(userDTO.getDeviceToken())) {
				if (userDTO.getDeviceToken().length() == 44) {
					android.add(userDTO.getDeviceToken());
				} else {
					ios.add(userDTO.getDeviceToken());
				}
			}
		}
		// -- 友盟接口推送列播 上限500条一个组合 本系统400个为一个组合
		// -- 发送ios
		if (ios.size() > 0) {
			int count = ios.size() / 400 + (ios.size() % 400 > 0 ? 1 : 0);
			for (int i = 0; i < count; i++) {
				String devices = Joiner.on(",").join(ios.subList(i * 400, (i + 1) * 400));
				uMengSendUtil.sendIOSUnicast(appkey, appMasterSecret, devices, title, content, url);
			}
		}
		// -- 发送android
		if (android.size() > 0) {
			int count = android.size() / 400 + (android.size() % 400 > 0 ? 1 : 0);
			for (int i = 0; i < count; i++) {
				String devices = Joiner.on(",").join(android.subList(i * 400, (i + 1) * 400));
				uMengSendUtil.sendAndroidUnicast(appkey, appMasterSecret, devices, title, content, url);
			}
		}
	}

	/*————————————————————————————————————————————————————————————保存通讯录—————————————————————————————————————————————————————————————————————————————————*/
	/**
	 * 保存通讯录队列监听
	 * @author      xieqingyang
	 * @date        2018/10/12 5:34 PM
	 * @version     1.0
	 * @param message 消息队列消息内容
	 */
	@JmsListener(containerFactory = MqConstant.JMS_LISTENER_CONTAINER_FACTORY_ID, destination = MqConstant.KEEP_PHONE_BOOKS)
	public void addPhoneBooks(ActiveMQTextMessage message) {
		PhoneBookBO bo = null;
		try {
			bo = JsonUtils.fromJSON(message.getText(), PhoneBookBO.class);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("保存通讯录监听队列异常:" + e);
			return;
		}
		if (null == bo.getBatchNum()) {
			log.error("保存通讯录失败，批次号不存在");
			return;
		}
		Long batchNum = bo.getBatchNum();
		// 获取批次
		PhoneBookBatchDTO phoneBookBatchDTO = applyPersonDao.getPhoneBookAddressBatchById(batchNum);
		if (null == phoneBookBatchDTO) {
			log.error("保存通讯录失败，批次不存在");
			return;
		}
		// 更新条数
		Long userId = bo.getUserId();
		List<PhoneBookDTO> beans = bo.getBeans();
		Date date = new Date();
		for (PhoneBookDTO bean : beans) {
			PhoneBookDO phoneBookDO = new PhoneBookDO();
			String phone = bean.getPhone();
			try {
				// 处理数据
				phone = StringUtils.isNotNullAndEmpty(phone) ? phone.trim().replace(" ", "") : phone;
				bean.setPhone(phone);
				bean.setAddress(replaceEmoji(bean.getAddress()));
				bean.setCompany(replaceEmoji(bean.getCompany()));
				bean.setEmail(replaceEmoji(bean.getEmail()));
				bean.setNickname(replaceEmoji(bean.getNickname()));
				bean.setName(replaceEmoji(bean.getName()));
				bean.setPhoneGroup(replaceEmoji(bean.getPhoneGroup()));
				bean.setRemark(replaceEmoji(bean.getRemark()));
				BeanUtils.copyProperties(bean, phoneBookDO);
				phoneBookDO.setClientId(userId);
				phoneBookDO.setModifyTime(date);
				phoneBookDO.setCreateTime(date);
				phoneBookDO.setModifyUser(userId);
				phoneBookDO.setCreateUser(userId);
				phoneBookDO.setMobilePhoneBatchId(batchNum);
				// 保存数据
				applyPersonDao.addPhoneBookInfo(phoneBookDO);

			} catch (Exception e) {
				phoneBookDO = new PhoneBookDO();
				phoneBookDO.setClientId(userId);
				phoneBookDO.setModifyTime(date);
				phoneBookDO.setCreateTime(date);
				phoneBookDO.setModifyUser(userId);
				phoneBookDO.setCreateUser(userId);
				phoneBookDO.setMobilePhoneBatchId(batchNum);
				phoneBookDO.setPhone(StringUtils.isNotNullAndEmpty(phone) ? phone.trim().replace(" ", "") : phone);
				applyPersonDao.addPhoneBookInfo(phoneBookDO);
				e.printStackTrace();
				log.error("保存通讯录异常：" + bean.toString() + "\n" + e);
			}
		}
		// 统计批次数量
		int num = applyPersonDao.CountPhoneBookNumByBatchNum(batchNum);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", batchNum);
		params.put("actualQty", num);
		try {
			this.applyPersonDao.updatePhoneAddressBatchById(params);
		} catch (Exception e) {
			log.error("更新应收条数失败" + e);
		}

	}

	private String replaceEmoji(String source) {
		return source = StringUtils.isNotNullAndEmpty(source)
				? source.replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "") : source;
	}
}