package com.xyb.order.pc.deposit.dao;

import com.xyb.order.pc.deposit.model.BankChangeVO;
import com.xyb.order.pc.deposit.model.DepositChangeDO;
import com.xyb.order.pc.deposit.model.DepositChangeDTO;
import com.xyb.order.pc.deposit.model.DepositChangeVO;

import java.util.List;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.dao
 * @description : 存管服务
 * @createDate : 2018/06/29 15:26
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface DepositDao {

    /**
     * 资料变更审核列表
     *
     * @param depositChangeDTO
     * @return
     */
    List<DepositChangeVO> depositChangePage(DepositChangeDTO depositChangeDTO);

    /**
     * 资料变更审核操作
     *
     * @param depositChangeDO
     */
    void updateDepositChange(DepositChangeDO depositChangeDO);

    /**
     * @description 资料变更审核列表非存管
     * @author      xieqingyang
     * @CreatedDate 2018/7/20 下午9:47
     * @Version     1.0
     * @param depositChangeDTO 传入页面查询参数
     * @return 返回列表数据
     */
    List<BankChangeVO> bankChangePage(DepositChangeDTO depositChangeDTO);
}
