package com.xyb.order.pc.deposit.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.bindcard.service.BindCardEntranceService;
import com.xyb.common.model.dto.AgreementBindInDTO;
import com.xyb.common.model.dto.AgreementPayOutDTO;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.*;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.message.service.MessageService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.TimestampIDUtil;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindConfirmBianCardEntranceDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreDTO;
import com.xyb.order.pc.contract.model.thridPay.ThirdPayBindPreResendDTO;
import com.xyb.order.pc.deposit.dao.DepositDao;
import com.xyb.order.pc.deposit.model.BankChangeVO;
import com.xyb.order.pc.deposit.model.DepositChangeDO;
import com.xyb.order.pc.deposit.model.DepositChangeDTO;
import com.xyb.order.pc.deposit.model.DepositChangeVO;
import com.xyb.order.pc.deposit.service.DepositService;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : jiangzhongyan
 * @projectName : order-model
 * @package : com.xyb.order.pc.deposit.service.impl
 * @description : 存管服务
 * @createDate : 2018/06/29 15:24
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.pc.deposit.service.DepositService")
public class DepositServiceImpl implements DepositService {

    private static final Logger log = LoggerFactory.getLogger(DepositServiceImpl.class);

    private static final Long DCIT_3077 = 3077L;
    private static final Long DCIT_3079 = 3079L;
    private static final String DCIT_STR = "换卡";

    @Autowired
    private DepositDao depositDao;
    @Autowired
    private MessageService messageService;
    @Autowired
    private BankDao bankDao;
    @Autowired
    private ClinetUserDao clinetUserDao;
    @Reference
    private BindCardEntranceService bindCardEntranceService;
    @Autowired
    private XybContractDao xybContractDao;

    /**
     * 资料变更审核列表
     *
     * @param pageNumber
     * @param pageSize
     * @param depositChangeDTO
     * @return
     */
    @Override
    public RestResponse depositChangePage(Integer pageNumber, Integer pageSize, DepositChangeDTO depositChangeDTO) {
        User user = SessionUtil.getLoginUser(User.class);
        depositChangeDTO.setOrgId(user.getOrgId());
        depositChangeDTO.getPage().setPageSize(pageSize);
        depositChangeDTO.getPage().setPageNumber(pageNumber);
        List<DepositChangeVO> contents = depositDao.depositChangePage(depositChangeDTO);
        depositChangeDTO.getPage().setContents(contents);
        return new RestResponse(MsgErrCode.SUCCESS, depositChangeDTO.getPage());
    }

    /**
     * 资料变更审核操作
     *
     * @param depositChangeDO
     * @return
     */
    @Override
    public RestResponse depositChangeOperation(DepositChangeDO depositChangeDO) {
        User user = SessionUtil.getLoginUser(User.class);
        depositChangeDO.setOperationUser(user.getId());
        // 通知模板id
        Long templateId = null;
        Map<String, Object> map = null;
        depositDao.updateDepositChange(depositChangeDO);

        if (DCIT_STR.equals(depositChangeDO.getDepositChangeTypeStr())) {
            templateId = 3L;
        } else {
            if (DCIT_3077.equals(depositChangeDO.getState())) {
                templateId = 1L;
            } else if (DCIT_3079.equals(depositChangeDO.getState())) {
                templateId = 2L;
            }
            map = new HashMap<>(1);
            map.put("[variable]", depositChangeDO.getDepositChangeTypeStr());
        }
        // c端通知
        messageService.sendMessage(templateId, depositChangeDO.getPhone(), map, user.getId());
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    public RestResponse depositChangeNoPage(Integer pageNumber, Integer pageSize, DepositChangeDTO depositChangeDTO)throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        depositChangeDTO.setOrgId(user.getOrgId());
        depositChangeDTO.getPage().setPageSize(pageSize);
        depositChangeDTO.getPage().setPageNumber(pageNumber);
        List<BankChangeVO> list = depositDao.bankChangePage(depositChangeDTO);
        depositChangeDTO.getPage().setContents(list);
        return new RestResponse(MsgErrCode.SUCCESS, depositChangeDTO.getPage());
    }

    @Override
    public RestResponse depositChangeOperationNo(DepositChangeDO depositChangeDO)throws Exception{
        if(!SysDictEnum.BANK_CARD_STATUS_3103.getCode().equals(depositChangeDO.getState()) && !SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(depositChangeDO.getState())){
            return new RestResponse(NativeMsgErrCode.DEVICE_TYPE_ERROR);
        }
        User user = SessionUtil.getLoginUser(User.class);
        // -- 修改申请状态
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(depositChangeDO.getId());
        changeBankApplyDO.setState(depositChangeDO.getState());
        changeBankApplyDO.setModifyUser(user.getId());
        bankDao.updateChangeBankApply(changeBankApplyDO);
        // c端通知 拒绝通知
        if (SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(depositChangeDO.getState())){
            // -- 删除银行卡缓存
            // -- 查询银行卡变更申请申请
            ChangeBankApplyDO ct = new ChangeBankApplyDO();
            ct.setId(depositChangeDO.getId());
            List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(ct);
            // -- 查询用户信息
            Map<String,Object> paraMap = new HashMap<>(1);
            paraMap.put("id",list.get(0).getClientId());
            ApplyClientInfoDO clientUserDO = clinetUserDao.getApplyClientInfo(paraMap);
            RedisUtil.del(RedisConstant.ORDER_USER_BANK_STATE + clientUserDO.getPhone());
            messageService.sendMessage(5L, depositChangeDO.getPhone(), null, user.getId());
        }else {
            messageService.sendMessage(4L, depositChangeDO.getPhone(), null, user.getId());
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse submit(Long id) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        if (id == null){
            return new RestResponse(NativeMsgErrCode.DEVICE_TYPE_ERROR);
        }
        // -- 查询用户账户修改申请表信息
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(id);
        List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(changeBankApplyDO);
        if (list == null || list.size() == 0 || SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(list.get(0).getState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 查询银行卡相关信息
        XybBankCodeDO paraBank = new XybBankCodeDO();
        paraBank.setBankType(list.get(0).getBankId());
        XybBankCodeDO xybBankCodeDO = bankDao.getBankIconByBankID(paraBank);
        if (xybBankCodeDO == null){
            return new RestResponse(NativeMsgErrCode.REFUSE);
        }
        // -- 查询用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",list.get(0).getClientId());
        // -- 查询用户信息
        ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        // -- 验证用户是否签约完成所有划扣协议
        try {
            AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
            agreementBindInDTO.setBankType(String.valueOf(list.get(0).getBankId()));
            agreementBindInDTO.setCardNumber(list.get(0).getBankNum());
            agreementBindInDTO.setName(applyClientInfoDO.getName());
            agreementBindInDTO.setPhoneNumber(list.get(0).getPhone());
            agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
            agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
            agreementBindInDTO.setIdcardNumber(applyClientInfoDO.getIdcard());
            Map<String, Object> resultMap = bindCardEntranceService.getUserNotBindChannel(agreementBindInDTO);
            if(resultMap != null ){
                if(resultMap.get("code").equals(SysConstants.CODEONE)){
                    List resultList = (List) resultMap.get("channelList");
                    if (resultList != null && resultList.size() > 0){
                        return new RestResponse(NativeMsgErrCode.EXISTENCE_UNAUTHORIZED_CHANNELS);
                    }
                }else{
                    return new RestResponse(NativeMsgErrCode.REFUSE);
                }
            }else {
                log.info("划扣路由接口返回null");
                return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("调用划扣路由接口异常："+e);
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        // -- 查询用户银行卡信息
        ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
        paraClient.setId(list.get(0).getBankInfoId());
        List<ClientBankInfoNoDO> noDOList = bankDao.queryClientBankInFoNo(paraClient);
        if (noDOList == null || noDOList.size() == 0){
            return new RestResponse(NativeMsgErrCode.NO_EXISTENCE);
        }
        // -- 修改银行卡信息
        ClientBankInfoNoDO ct = noDOList.get(0);
        ct.setModifyUser(user.getId());
        ct.setBankRealName(applyClientInfoDO.getName());
        ct.setBankIdcard(applyClientInfoDO.getIdcard());
        ct.setBankNum(list.get(0).getBankNum());
        ct.setBankName(xybBankCodeDO.getBankDes());
        ct.setBankcardBankname(xybBankCodeDO.getBankDes());
        ct.setPhone(list.get(0).getPhone());
        ct.setBankId(list.get(0).getBankId());
        ct.setState(SysDictEnum.YES.getCode());
        // -- 添加银行卡修改日志
        ClientBankLogDO clientBankLogDO = new ClientBankLogDO();
        clientBankLogDO.setClientId(applyClientInfoDO.getId());
        clientBankLogDO.setBusinessType(SysDictEnum.BANK_CARD_BUSINESS_TYPE_3106.getCode());
        JSONObject afterContent = new JSONObject();
        afterContent.put("idcard",applyClientInfoDO.getIdcard());
        afterContent.put("name",applyClientInfoDO.getName());
        afterContent.put("bankcard",list.get(0).getBankNum());
        afterContent.put("phone",list.get(0).getPhone());
        clientBankLogDO.setAfterContent(afterContent.toString());
        JSONObject beforeContent = new JSONObject();
        beforeContent.put("idcard",noDOList.get(0).getBankIdcard());
        beforeContent.put("name",noDOList.get(0).getBankRealName());
        beforeContent.put("bankcard",noDOList.get(0).getBankNum());
        beforeContent.put("phone",noDOList.get(0).getPhone());
        clientBankLogDO.setBeforeContent(beforeContent.toString());
        clientBankLogDO.setCreateUser(user.getId());
        // -- 修改用户账户申请信息
        changeBankApplyDO.setState(SysDictEnum.BANK_CARD_STATUS_3104.getCode());
        changeBankApplyDO.setModifyUser(user.getId());
        // -- 变更合同表中的银行卡信息
        XybContractUpdateDTO xybContractDO = new XybContractUpdateDTO();
        xybContractDO.setClientId(applyClientInfoDO.getId());
        xybContractDO.setBankType(list.get(0).getBankId());
        xybContractDO.setBankAccount(applyClientInfoDO.getName());
        xybContractDO.setBankAccountOpen(xybBankCodeDO.getBankDes());
        xybContractDO.setRefundCardNum(list.get(0).getBankNum());
        xybContractDO.setMp(list.get(0).getPhone());
        xybContractDO.setCustName(applyClientInfoDO.getName());
        bankDao.updateClientBankInFoNo(ct);
        bankDao.addClinetBankLog(clientBankLogDO);
        bankDao.updateChangeBankApply(changeBankApplyDO);
        // -- 更换用户合同的银行卡信息
        xybContractDao.updateContractBankInfo(xybContractDO);
        // -- c端通知 成功通知
        messageService.sendMessage(6L, applyClientInfoDO.getPhone(), null, user.getId());
        RedisUtil.del(RedisConstant.ORDER_USER_BANK_STATE + applyClientInfoDO.getPhone());
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    public RestResponse getUserNotBindChannel(ThirdPayBindDTO thirdPayBindDTO)throws Exception{
        RestResponse response;
        // -- 查询用户账户修改申请表信息
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(thirdPayBindDTO.getApplyId());
        List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(changeBankApplyDO);
        if (list == null || list.size() == 0 || SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(list.get(0).getState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 查询用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",list.get(0).getClientId());
        ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
        agreementBindInDTO.setBankType(String.valueOf(list.get(0).getBankId()));
        agreementBindInDTO.setCardNumber(list.get(0).getBankNum());
        agreementBindInDTO.setName(applyClientInfoDO.getName());
        agreementBindInDTO.setPhoneNumber(list.get(0).getPhone());
        agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
        agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
        agreementBindInDTO.setIdcardNumber(applyClientInfoDO.getIdcard());
        log.info("获取渠道银行类型列表接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
        Map<String, Object> resultMap = bindCardEntranceService.getUserNotBindChannel(agreementBindInDTO);
        log.info("获取渠道银行类型列表接口返回结果:"+JsonUtils.toJSON(resultMap));
        if(resultMap != null ){
            if(resultMap.get("code").equals(SysConstants.CODEONE)){
                List resultList = (List) resultMap.get("channelList");
                if (resultList == null || resultList.size() == 0){
                    /**code为S channelList为null说明该用户已签约完所有渠道*/
                    response = new RestResponse(MsgErrCode.FAIL,resultMap);
                    response.setDescription("已签约完所有渠道");
                    return response;
                }else {
                    return new RestResponse(MsgErrCode.SUCCESS,resultMap.get("channelList"));
                }
            }else{
                /**code为F channelList为null说明所选银行无支持的渠道*/
                response = new RestResponse(MsgErrCode.FAIL,resultMap);
                response.setDescription("用户当前绑定银卡行无可支持划扣渠道，请更换银行卡！");
                return response;
            }
        }else {
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }

    @Override
    public RestResponse preBindCardEntrance(ThirdPayBindPreDTO thirdPayBindPreDTO)throws Exception{
        // -- 查询用户账户修改申请表信息
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(thirdPayBindPreDTO.getApplyId());
        List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(changeBankApplyDO);
        if (list == null || list.size() == 0 || SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(list.get(0).getState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 查询用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",list.get(0).getClientId());
        ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
        agreementBindInDTO.setBankType(String.valueOf(list.get(0).getBankId()));
        agreementBindInDTO.setCardNumber(list.get(0).getBankNum());
        agreementBindInDTO.setName(applyClientInfoDO.getName());
        agreementBindInDTO.setPhoneNumber(list.get(0).getPhone());
        agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
        agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
        agreementBindInDTO.setIdcardNumber(applyClientInfoDO.getIdcard());
        agreementBindInDTO.setChannelId(thirdPayBindPreDTO.getChannelId());
        agreementBindInDTO.setOrderNo(TimestampIDUtil.createID());
        log.info("协议支付-预绑卡接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
        AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.preBindCardEntrance(agreementBindInDTO);
        log.info("协议支付-预绑卡接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
        if(SysConstants.CODEONE.equals(agreementPayOutDTO.getCode())){
            return new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
        }else if(SysConstants.CODETWO.equals(agreementPayOutDTO.getCode())){
            return new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
        }else {
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }

    @Override
    public RestResponse resendMessage(ThirdPayBindPreResendDTO thirdPayBindPreResendDTO)throws Exception{
        // -- 查询用户账户修改申请表信息
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(thirdPayBindPreResendDTO.getApplyId());
        List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(changeBankApplyDO);
        if (list == null || list.size() == 0 || SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(list.get(0).getState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 查询用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",list.get(0).getClientId());
        ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
        agreementBindInDTO.setBankType(String.valueOf(list.get(0).getBankId()));
        agreementBindInDTO.setCardNumber(list.get(0).getBankNum());
        agreementBindInDTO.setName(applyClientInfoDO.getName());
        agreementBindInDTO.setPhoneNumber(list.get(0).getPhone());
        agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
        agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
        agreementBindInDTO.setIdcardNumber(applyClientInfoDO.getIdcard());
        agreementBindInDTO.setChannelId(thirdPayBindPreResendDTO.getChannelId());
        agreementBindInDTO.setOrderNo(thirdPayBindPreResendDTO.getOrder());
        log.info("协议支付-预绑卡重发短信接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
        AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.resendMessage(agreementBindInDTO);
        log.info("协议支付-预绑卡重发短信接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
        if(agreementPayOutDTO.getCode().equals(SysConstants.CODEONE)){
            return new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
        }else if(agreementPayOutDTO.getCode().equals(SysConstants.CODETWO)){
            return new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
        }else {
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }

    @Override
    public RestResponse confirmBianCardEntrance(ThirdPayBindConfirmBianCardEntranceDTO thirdPayBindConfirmBianCardEntranceDTO)throws Exception{
        // -- 查询用户账户修改申请表信息
        ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
        changeBankApplyDO.setId(thirdPayBindConfirmBianCardEntranceDTO.getApplyId());
        List<ChangeBankApplyDO> list = bankDao.queryChangeBankApply(changeBankApplyDO);
        if (list == null || list.size() == 0 || SysDictEnum.BANK_CARD_STATUS_3104.getCode().equals(list.get(0).getState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 查询用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",list.get(0).getClientId());
        ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        AgreementBindInDTO agreementBindInDTO = new AgreementBindInDTO();
        agreementBindInDTO.setBankType(String.valueOf(list.get(0).getBankId()));
        agreementBindInDTO.setCardNumber(list.get(0).getBankNum());
        agreementBindInDTO.setName(applyClientInfoDO.getName());
        agreementBindInDTO.setPhoneNumber(list.get(0).getPhone());
        agreementBindInDTO.setUserType(String.valueOf(SysDictEnum.CAPITAL_TRANSFER_THREE.getCode()));
        agreementBindInDTO.setUserId(String.valueOf(applyClientInfoDO.getId()));
        agreementBindInDTO.setIdcardNumber(applyClientInfoDO.getIdcard());
        agreementBindInDTO.setChannelId(thirdPayBindConfirmBianCardEntranceDTO.getChannelId());
        agreementBindInDTO.setOrderNo(thirdPayBindConfirmBianCardEntranceDTO.getOrder());
        agreementBindInDTO.setValidateCode(thirdPayBindConfirmBianCardEntranceDTO.getValidateCode());
        log.info("协议支付确认绑卡接口请求参数:"+JsonUtils.toJSON(agreementBindInDTO));
        AgreementPayOutDTO agreementPayOutDTO = bindCardEntranceService.confirmBianCardEntrance(agreementBindInDTO);
        log.info("协议支付确认绑卡接口返回结果:"+JsonUtils.toJSON(agreementPayOutDTO));
        if(agreementPayOutDTO != null){
            if(agreementPayOutDTO.getCode().equals(SysConstants.CODEONE)){
                /**成功*/
                return new RestResponse(MsgErrCode.SUCCESS,agreementPayOutDTO);
            }else if(agreementPayOutDTO.getCode().equals(SysConstants.CODETWO) && agreementPayOutDTO.isRefreshFlag()){
                /**失败*/
                return new RestResponse(MsgErrCode.FAIL,agreementPayOutDTO);
            }else {
                return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            }
        }else {
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }
}
