package com.xyb.order.pc.applybill.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import com.alibaba.dubbo.config.annotation.Reference;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.credit.common.model.CheatInterfaceLogDO;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.material.dao.FileDataInfoDao;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.creditreport.dao.*;
import com.xyb.order.pc.creditreport.model.*;
import com.xyb.risks.common.model.mqresponse.*;
import com.xyb.risks.process.Rong360.model.GjjReport;
import com.xyb.risks.process.Rong360.model.Rong360GjjBaseInfoModel;
import com.xyb.risks.process.Rong360.model.Rong360GjjPayModel;
import com.xyb.risks.process.Rong360.model.Rong360ManualReport;
import com.xyb.risks.process.Rong360.model.Rong360ShebaoBaseInfoModel;
import com.xyb.risks.process.Rong360.model.Rong360ShebaoPayModel;
import com.xyb.risks.process.Rong360.model.ShebaoReport;
import com.xyb.risks.process.Rong360.service.Rong360Service;
import com.xyb.risks.process.foreign.model.OrderSuanhuaInfo;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.risks.process.juxinli.juxinliforother.JuXinLiApplicationCheckForOther;
import com.xyb.risks.process.juxinli.juxinliforother.JuXinLiApplicationCheckInData;
import com.xyb.risks.process.juxinli.model.JuXinLiSDReport;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanReport;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanSDReport;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanSDReportDetail;
import com.xyb.risks.process.juxinli.service.JuXinLiBaoDanService;
import com.xyb.risks.process.juxinli.service.JuxinliService;
import com.xyb.risks.process.mq.HandleInterface;
import com.xyb.risks.process.process.service.ProcessService;
import com.xyb.risks.process.suanhua.model.SuanhuaManualReport;
import com.xyb.risks.process.suanhua.service.SuanhuaService;
import com.xyb.util.SessionUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyClientInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyJobInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyLinkmanInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyPersonInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyPrivateInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoAllTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoDO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoVO;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.applybill.model.ApplyBillinfoAllSaveCheckJobDTO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDTO;
import com.xyb.order.pc.applybill.model.ApplyClientInfoDO;
import com.xyb.order.pc.applybill.model.ApplyClientInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyClientInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDO;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDTO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoCheckDTO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoDO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDO;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyOtherdataRemarkDTO;
import com.xyb.order.pc.applybill.model.ApplyPersonInfoDO;
import com.xyb.order.pc.applybill.model.ApplyPersonInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyPersonInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyPrivateInfoDO;
import com.xyb.order.pc.applybill.model.ApplyPrivateInfoDTO;
import com.xyb.order.pc.applybill.model.ApplyPrivateInfoTempSaveDTO;
import com.xyb.order.pc.applybill.service.ApplyBillInfoService;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.dao.ApplyCommonProvinceDao;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.ApplyNumberUtil;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.ObjectUtils;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import javax.annotation.Resource;

@Service(interfaceName = "com.xyb.order.pc.applybill.service.ApplyBillInfoService")
public class ApplyBillInfoServiceImpl implements ApplyBillInfoService{

	private static final Logger log = LoggerFactory.getLogger(ApplyBillInfoServiceImpl.class);

	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Autowired
	private ApplyClientInfoDao applyClientInfoDao;
	@Autowired
	private ApplyPersonInfoDao applyPersonInfoDao; 
	@Autowired
	private ApplyPrivateInfoDao applyPrivateInfoDao; 
	@Autowired
	private  ApplyLinkmanInfoDao applyLinkmanInfoDao;
	@Autowired
	private ApplyJobInfoDao applyJobInfoDao;
	@Autowired
	private TableModifyLogService tableModifyService;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	@Autowired
	private FileDataInfoService fileService;
	@Reference
	private ProcessService processService;
	@Resource(name = "jmsQueueTemplate")
	private JmsTemplate jmsQueueTemplate;
	@Reference
	private Rong360Service rong360Service;
	@Reference
	private SuanhuaService suanhuaService;
	@Autowired
	private AuditRiskCreditReportDao auditRiskCreditReportDao;
	@Autowired
	private AuditOtherHouseDao auditOtherHouseDao;
	@Autowired
	private AuditJobInfoDao auditJobInfoDao;
	@Autowired
	private AuthorizationDao authorizationDao;
	@Reference
	private ForeignService foreignService;
	@Autowired
	private AuditInsuranceDao auditInsuranceDao;
	@Reference
	private CreditCommonService commonService;
	@Reference
	private JuxinliService juXinLiService;
	@Reference
	private JuXinLiBaoDanService juXinLiBaoDanService;
	@Autowired
	private FileDataInfoDao fileDataInfoDao;
	@Autowired
	private AuditPhoneDetailDao auditPhoneDetailDao;
	@Autowired
	private HomeDao homeDao;
	@Autowired
	private ApplyCommonProvinceDao applyCommonProvinceDao;
	@Autowired
	private ClinetUserModifyService clinetUserModifyService;

	/**
	 * 申请单列表 
	 */
	@Override
	public RestResponse applyBillInfoQueryPage(Integer pageNumber, Integer pageSize,ApplyBillInfoQueryDTO applyBillInfoQueryDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		applyBillInfoQueryDTO.setLoginId(loginUser.getId());
		applyBillInfoQueryDTO.setClientAbandon(SysDictEnum.NO.getCode());
		applyBillInfoQueryDTO.getPage().setPageNumber(pageNumber);
		applyBillInfoQueryDTO.getPage().setPageSize(pageSize);
		List<ApplyBillInfoQueryDO> applyBillInfoQueryDOs = this.applyBillInfoDao.applyBillInfoQueryPage(applyBillInfoQueryDTO);
		applyBillInfoQueryDTO.getPage().setContents(applyBillInfoQueryDOs);
		return new RestResponse(MsgErrCode.SUCCESS,applyBillInfoQueryDTO.getPage());
	}

	/**
	 * 修改申请单详情页面
	 */
	@Override
	public RestResponse updateDetailBillInfoData(Long mainId) throws Exception {
		ApplyBillInfoVO applyBillInfoVO = new ApplyBillInfoVO();
		/**申请单信息**/
		ApplyBillInfoDO applyBillInfoDO = this.applyBillInfoDao.queryBillInfoByMainId(mainId);
		/**客户信息**/
		ApplyClientInfoDO applyClientInfoDO = this.applyClientInfoDao.queryClientInfoByMainId(mainId);
		/**个人信息**/
		ApplyPersonInfoDO personInfoDO = this.applyPersonInfoDao.queryPersonInfoByMainId(mainId);
		/**家庭子女信息**/
		Map<String, Object> queryChildMap = new HashMap<>(5);
		queryChildMap.put("applyId", applyBillInfoDO.getId());
		queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
		List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao.queryFamilyChildrenList(queryChildMap);
		/**工作信息**/
		ApplyJobInfoDO jobInfoDO = this.applyJobInfoDao.queryJobInfoByMainId(mainId);
		/**私营信息**/
		ApplyPrivateInfoDO privateInfoDO = this.applyPrivateInfoDao.queryPrivateInfoByMainId(mainId);
		/**家庭联系人信息**/
		Map<String,Object> paraMap = new HashMap<>(5);
		paraMap.put("mainId", mainId);
		paraMap.put("type", SysDictEnum.FAMILY_PERSON_LINK.getCode());
		List<ApplyLinkmanInfoDO> homeLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
		/**工作联系人信息**/
		paraMap.put("type", SysDictEnum.WORK_PERSON_LINK.getCode());
		List<ApplyLinkmanInfoDO> workLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
		/**紧急联系人信息**/
		paraMap.put("type", SysDictEnum.QUICK_PERSON_LINK.getCode());
		List<ApplyLinkmanInfoDO> urgentLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
		applyBillInfoVO.setApplyBillInfoDo(applyBillInfoDO);
		applyBillInfoVO.setApplyClientInfoDO(applyClientInfoDO);
		applyBillInfoVO.setApplyPersonInfoDo(personInfoDO);
		applyBillInfoVO.setApplyJobInfoDO(jobInfoDO);
		applyBillInfoVO.setApplyPrivateInfoDo(privateInfoDO);
		applyBillInfoVO.setHomeLinkList(homeLinkList);
		applyBillInfoVO.setWorkLinkList(workLinkList);
		applyBillInfoVO.setUrgentLinkList(urgentLinkList);
		applyBillInfoVO.setFamilyChildrenList(applyFamilyChildrenDOs);
		return new RestResponse(MsgErrCode.SUCCESS, applyBillInfoVO);
	}

	/**
	 * 暂存申请单信息
	 * @author ZhangYu
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdateAll(ApplyBillInfoAllTempSaveDTO applyBillInfoAllTempSaveDTO) throws Exception {
		Map<String, Object> applyBillInfoMap = null;
		Map<String, Object> applyClientMap = null;
		Map<String, Object> applyPersonMap = null;
		Map<String, Object> applyPrivateMap = null;
		Map<String, Object> applyjobInfoMap = null;
		ApplyBillInfoTempSaveDTO applyBillInfoTempSaveDTO = applyBillInfoAllTempSaveDTO.getApplyBillInfoTempSaveDTO();//申请单信息
		ApplyClientInfoTempSaveDTO applyClientInfoTempSaveDTO = applyBillInfoAllTempSaveDTO.getApplyClientInfoTempSaveDTO();//客户信息
		ApplyPersonInfoTempSaveDTO applyPersonInfoTempSaveDTO = applyBillInfoAllTempSaveDTO.getApplyPersonInfoTempSaveDTO();//个人信息
		ApplyJobInfoTempSaveDTO applyJobInfoTempSaveDTO = applyBillInfoAllTempSaveDTO.getApplyJobInfoTempSaveDTO();//工作信息
		ApplyPrivateInfoTempSaveDTO applyPrivateInfoTempSaveDTO = applyBillInfoAllTempSaveDTO.getApplyPrivateInfoTempSaveDTO();//私营信息
		List<ApplyLinkmanInfoTempSaveDTO> homeLinkManInfos = applyBillInfoAllTempSaveDTO.getHomeLinkManInfoTempSaveDTO(); //家庭联系人信息
		List<ApplyLinkmanInfoTempSaveDTO> workLinkManInfos = applyBillInfoAllTempSaveDTO.getWorkLinkManInfoTempSaveDTO(); //工作联系人信息
		List<ApplyLinkmanInfoTempSaveDTO> urgetLinkManInfos = applyBillInfoAllTempSaveDTO.getUrgentLinkManInfoTempSaveDTO();//紧急联系人信息
		List<ApplyFamilyChildrenDTO> familyChildrenList = applyBillInfoAllTempSaveDTO.getFamilyChildrenList();
		if (familyChildrenList == null){
			familyChildrenList = new ArrayList<>();
		}
		Long mainId = applyBillInfoTempSaveDTO.getMainId();//主表ID
		User user = SessionUtil.getLoginUser(User.class);
		Long userId = user.getId();
		/**暂存客户信息**/
		if (applyClientInfoTempSaveDTO.getId() != null) {
			ApplyClientInfoDO applyClientInfoDO = this.applyClientInfoDao.queryClientInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyClientInfoDO.getId(),TableConstant.T_APPLY_CLIENT_INFO,
					JsonUtil.object2json(applyClientInfoDO), JsonUtil.object2json(applyClientInfoTempSaveDTO));
			if (flag) {
				applyClientInfoTempSaveDTO.setModifyUser(userId); 
				applyClientMap = ObjectUtils.describe(applyClientInfoTempSaveDTO);
				this.applyClientInfoDao.updateOnlyChanged(applyClientMap);
			}
		}else{
			applyClientInfoTempSaveDTO.setCreateUser(userId);
			applyClientMap = ObjectUtils.describe(applyClientInfoTempSaveDTO);
			this.applyClientInfoDao.add(applyClientMap);
			/**返回主键值**/
			applyClientInfoTempSaveDTO.setId(Long.valueOf(String.valueOf(applyClientMap.get("id"))));
		}
		/**暂存申请单信息**/
		applyBillInfoTempSaveDTO.setIsTempSave(SysDictEnum.YES.getCode());
		if (applyBillInfoTempSaveDTO.getId() != null) {
			ApplyBillInfoDO applyBillInfoDO = this.applyBillInfoDao.queryBillInfoByMainId(mainId);
			
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyBillInfoTempSaveDTO.getId(), TableConstant.T_APPLY_BILL_INFO,
					JsonUtil.object2json(applyBillInfoDO), JsonUtil.object2json(applyBillInfoTempSaveDTO));
			if (flag) {
				applyBillInfoMap = ObjectUtils.describe(applyBillInfoTempSaveDTO);
				this.applyBillInfoDao.updateApplyBillInfoById(applyBillInfoMap);
			}
		}else{
			applyBillInfoTempSaveDTO.setMainId(mainId);
			applyBillInfoTempSaveDTO.setCusId(applyClientInfoTempSaveDTO.getId());
			String applyNum = ApplyNumberUtil.getsApplyNumber();
			applyBillInfoTempSaveDTO.setApplyNum(applyNum);
			applyBillInfoMap = ObjectUtils.describe(applyBillInfoTempSaveDTO);
			this.applyBillInfoDao.add(applyBillInfoMap);
			/**返回主键值**/
			applyBillInfoTempSaveDTO.setId(Long.valueOf(String.valueOf(applyBillInfoMap.get("id"))));
		}
		/**暂存主表信息**/
		updateMainInfoTempSave(userId,mainId, applyBillInfoTempSaveDTO);
		/**暂存个人信息**/
		String homeTownProvinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyPersonInfoTempSaveDTO.getHomeTownProvince());
		String homeTownCityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyPersonInfoTempSaveDTO.getHomeTownCity());
		String homeTownAreaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyPersonInfoTempSaveDTO.getHomeTownArea());
		String homeAllAdress = (homeTownProvinceLabel == null ?"":homeTownProvinceLabel)+
				(homeTownCityLabel == null?"":homeTownCityLabel)+( homeTownAreaLabel==null?"":homeTownAreaLabel)+
				(applyPersonInfoTempSaveDTO.getHomeTown()==null?"":applyPersonInfoTempSaveDTO.getHomeTown());
		String nowAddressProvinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyPersonInfoTempSaveDTO.getNowAddressProvince());
		String cityLabelByCityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyPersonInfoTempSaveDTO.getNowAddressCity());
		String areaLabelByAreaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyPersonInfoTempSaveDTO.getNowAddressArea());
		String nowAllAdress = (nowAddressProvinceLabel == null?"":nowAddressProvinceLabel) +
				(cityLabelByCityLabel==null?"":cityLabelByCityLabel)+(areaLabelByAreaLabel==null?"":areaLabelByAreaLabel)+
				(applyPersonInfoTempSaveDTO.getNowAddress()==null?"":applyPersonInfoTempSaveDTO.getNowAddress());
		String allTell = (applyPersonInfoTempSaveDTO.getTellArea()==null?"":(applyPersonInfoTempSaveDTO.getTellArea()+"-"))+(applyPersonInfoTempSaveDTO.getTell()==null?"":applyPersonInfoTempSaveDTO.getTell()); 
		applyPersonInfoTempSaveDTO.setCusId(applyClientInfoTempSaveDTO.getId());
		applyPersonInfoTempSaveDTO.setHomeTownAllAddress(homeAllAdress);
		applyPersonInfoTempSaveDTO.setNowAllAddress(nowAllAdress);
		applyPersonInfoTempSaveDTO.setAllTell(allTell);
		/**年收入*/
		Double yearIncome = (applyJobInfoTempSaveDTO.getSalary()+(applyJobInfoTempSaveDTO.getOtherIncome()== null?0:applyJobInfoTempSaveDTO.getOtherIncome()))*12/10000;
		applyPersonInfoTempSaveDTO.setYearIncome(String.valueOf(yearIncome));
		if (applyPersonInfoTempSaveDTO.getId() != null) {
			ApplyPersonInfoDO applyPersonInfoDO = this.applyPersonInfoDao.queryPersonInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyPersonInfoDO.getId(), TableConstant.T_APPLY_PERSONAL_INFO,
					JsonUtil.object2json(applyPersonInfoDO),JsonUtil.object2json(applyPersonInfoTempSaveDTO));
			if (flag) {
				applyPersonInfoTempSaveDTO.setModifyUser(userId);
				applyPersonMap = ObjectUtils.describe(applyPersonInfoTempSaveDTO);
				this.applyPersonInfoDao.update(applyPersonMap);
			}
		}else{
			applyPersonInfoTempSaveDTO.setApplyId(applyBillInfoTempSaveDTO.getId());
			applyPersonInfoTempSaveDTO.setCusId(applyClientInfoTempSaveDTO.getId());
			applyPersonInfoTempSaveDTO.setCreateUser(userId);
			applyPersonMap = ObjectUtils.describe(applyPersonInfoTempSaveDTO);
			this.applyPersonInfoDao.add(applyPersonMap);
		}
		/**暂存家庭子女信息**/
		Map<String, Object> queryChildMap = new HashMap<>();
		queryChildMap.put("applyId", applyBillInfoTempSaveDTO.getId());
		queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
		List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao.queryFamilyChildrenList(queryChildMap);
		List<ApplyFamilyChildrenDTO> addFamilyList = new ArrayList<>();
		List<ApplyFamilyChildrenDTO> updateFamilyList = new ArrayList<>();

		Map<String,Object> familyChildrenListMap = new HashMap<>();
		for (int i = 0;i<familyChildrenList.size();i++){
			familyChildrenListMap.put(String.valueOf(familyChildrenList.get(i).getId()),familyChildrenList.get(i).getAge());
		}
		Map<String,Object> applyFamilyChildrenDOsMap = new HashMap<>();
		for (ApplyFamilyChildrenDO familyChildrenDO:applyFamilyChildrenDOs){
			applyFamilyChildrenDOsMap.put(String.valueOf(familyChildrenDO.getId()),familyChildrenDO.getAge());
		}
		for (ApplyFamilyChildrenDTO childrenDO:familyChildrenList){
			if (StringUtils.isNullOrEmpty(childrenDO.getId())){
				childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
				addFamilyList.add(childrenDO);
			}else {
				if (applyFamilyChildrenDOsMap.containsKey(String.valueOf(childrenDO.getId()))){
					childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
					updateFamilyList.add(childrenDO);
				}
			}
		}
		for (int i = 0;i<applyFamilyChildrenDOs.size();i++){
			if (familyChildrenListMap.containsKey(String.valueOf(applyFamilyChildrenDOs.get(i).getId()))){
				applyFamilyChildrenDOs.remove(i);
				i--;
			}
		}
		for (ApplyFamilyChildrenDO familyChildrenDO:applyFamilyChildrenDOs){
			ApplyFamilyChildrenDTO applyFamilyChildrenDTO = new ApplyFamilyChildrenDTO();
			applyFamilyChildrenDTO.setDelFlag(SysDictEnum.NO_VALID.getCode());
			applyFamilyChildrenDTO.setAge(familyChildrenDO.getAge());
			applyFamilyChildrenDTO.setApplyId(familyChildrenDO.getApplyId());
			applyFamilyChildrenDTO.setId(String.valueOf(familyChildrenDO.getId()));
			updateFamilyList.add(applyFamilyChildrenDTO);
		}

		if (addFamilyList.size() > 0) {
			this.applyPersonInfoDao.addFamilyChildrenList(addFamilyList);
		}
		if (updateFamilyList.size() > 0) {
			this.applyPersonInfoDao.updateFamilyChildrenList(updateFamilyList);
		}

		/**暂存工作信息**/
		if (applyJobInfoTempSaveDTO.getId() != null) {
			ApplyJobInfoDO applyJobInfoDO = this.applyJobInfoDao.queryJobInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyJobInfoDO.getId(),TableConstant.T_APPLY_JOB_INFO,
					JsonUtil.object2json(applyJobInfoDO),JsonUtil.object2json(applyJobInfoTempSaveDTO));
			if (flag) {
				applyJobInfoTempSaveDTO.setModifyUser(userId);
				applyjobInfoMap = ObjectUtils.describe(applyJobInfoTempSaveDTO);
				this.applyJobInfoDao.update(applyjobInfoMap);
			}
		}else{
			applyJobInfoTempSaveDTO.setCreateUser(userId);
			applyJobInfoTempSaveDTO.setApplyId(applyBillInfoTempSaveDTO.getId());
			applyJobInfoTempSaveDTO.setCusId(applyClientInfoTempSaveDTO.getId());
			applyjobInfoMap = ObjectUtils.describe(applyJobInfoTempSaveDTO);
			this.applyJobInfoDao.add(applyjobInfoMap);
		}
		/**暂存私营信息**/
		if (applyPrivateInfoTempSaveDTO.getId() != null) {
			ApplyPrivateInfoDO applyPrivateInfoDO = this.applyPrivateInfoDao.queryPrivateInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyPrivateInfoDO.getId(), TableConstant.T_APPLY_PRIVATE_INFO,
					JsonUtil.object2json(applyPrivateInfoDO), JsonUtil.object2json(applyPrivateInfoTempSaveDTO));
			if (flag) {
				applyPrivateInfoTempSaveDTO.setModifyUser(userId);
				applyPrivateMap = ObjectUtils.describe(applyPrivateInfoTempSaveDTO);
				this.applyPrivateInfoDao.update(applyPrivateMap);
			}
		}else{
			if (StringUtils.isNotNullAndEmpty(applyPrivateInfoTempSaveDTO.getEnterpriseName()) || (applyPrivateInfoTempSaveDTO.getRegDate()!=null)
					|| (applyPrivateInfoTempSaveDTO.getEnteType() != null) || StringUtils.isNotNullAndEmpty(applyPrivateInfoTempSaveDTO.getTel())  
					|| (applyPrivateInfoTempSaveDTO.getPalace() != null) || (applyPrivateInfoTempSaveDTO.getStockRatio() != null) || (applyPrivateInfoTempSaveDTO.getStaffAmount() != null)){ 				
				applyPrivateInfoTempSaveDTO.setCreateUser(userId);
				applyPrivateInfoTempSaveDTO.setApplyId(applyBillInfoTempSaveDTO.getId());
				applyPrivateInfoTempSaveDTO.setCusId(applyClientInfoTempSaveDTO.getId());
				applyPrivateMap = ObjectUtils.describe(applyPrivateInfoTempSaveDTO);
				this.applyPrivateInfoDao.add(applyPrivateMap);
			}
		}
		/**暂存联系人信息**/
		Map<String, List<ApplyLinkmanInfoTempSaveDTO>> linkManInfoListMap = getLinkManInfoListTemp(homeLinkManInfos, workLinkManInfos, urgetLinkManInfos, userId, 
				applyBillInfoTempSaveDTO.getId(), applyClientInfoTempSaveDTO.getId());
		List<ApplyLinkmanInfoTempSaveDTO> addLinkManInfos = linkManInfoListMap.get("add");
		List<ApplyLinkmanInfoTempSaveDTO> updateLinkManInfos = linkManInfoListMap.get("update");
		if (addLinkManInfos.size() > 0) {
			this.applyLinkmanInfoDao.addLinkManInfos(addLinkManInfos);
		}
		if (updateLinkManInfos.size() > 0) {
			this.applyLinkmanInfoDao.updateLinkManInfos(updateLinkManInfos);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 * 不校验工作信息下一步 
	 * @author ZhangYu
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdateAll(ApplyBillInfoAllSaveDTO applyBillInfoAllSaveDTO) throws Exception{
		Map<String, Object> applyJobInfoMap = null;
		ApplyBillInfoDTO applyBillInfoDTO = applyBillInfoAllSaveDTO.getApplyBillInfoDTO();//申请单信息
		ApplyClientInfoDTO applyClientInfoDTO = applyBillInfoAllSaveDTO.getApplyClientInfoDTO();//客户信息
		ApplyPersonInfoDTO applyPersonInfoDTO = applyBillInfoAllSaveDTO.getApplyPersonInfoDTO();//个人信息
		ApplyJobInfoDTO applyJobInfoDTO = applyBillInfoAllSaveDTO.getApplyJobInfoDTO();//工作信息
		ApplyPrivateInfoDTO applyPrivateInfoDTO = applyBillInfoAllSaveDTO.getApplyPrivateInfoDTO();//私人信息
		List<ApplyLinkmanInfoDTO> homeLinkManInfoDTO = applyBillInfoAllSaveDTO.getHomeLinkManInfoDTO();
		List<ApplyLinkmanInfoDTO> workLinkManInfoDTO = applyBillInfoAllSaveDTO.getWorkLinkManInfoDTO();
		List<ApplyLinkmanInfoDTO> urgentLinkManInfoDTO = applyBillInfoAllSaveDTO.getUrgentLinkManInfoDTO();
		List<ApplyFamilyChildrenDTO> familyChildrenList = applyBillInfoAllSaveDTO.getFamilyChildrenList();
		/**如果共同居住者是其他,其他信息文本框为必输**/
		String liveJoin = applyPersonInfoDTO.getLiveJoin();
		String[] liveJoinArr = liveJoin.split(",");
		boolean checkLiveJoinFlag = false;
		for (String lj: liveJoinArr) {
			if (SysDictEnum.LIVE_JOIN.getCode().equals(Long.valueOf(lj))) {
				checkLiveJoinFlag = true;
			}
		}
		if (checkLiveJoinFlag) {
			if (applyPersonInfoDTO.getLiveJoinOther() == null || "".equals(applyPersonInfoDTO.getLiveJoinOther())) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_LIVE_JOIN_OTHER);
			}
		}
		User user = SessionUtil.getLoginUser(User.class);
		Long userId = user.getId();
		Double yearIncomeDu = (applyJobInfoDTO.getSalary()+(applyJobInfoDTO.getOtherIncome()==null?0:applyJobInfoDTO.getOtherIncome()))*12/10000;
    	String yearIncome = String.valueOf(yearIncomeDu);
		/**通用保存(修改),除了工作信息之外的申请单信息**/
		Map<String, Long> commonMap = commonSaveOrUpdate(applyBillInfoDTO,applyClientInfoDTO,applyPersonInfoDTO,
				applyPrivateInfoDTO,homeLinkManInfoDTO,workLinkManInfoDTO,urgentLinkManInfoDTO,userId,familyChildrenList,yearIncome);

		Long applyId = commonMap.get("applyId");
		Long cusId = commonMap.get("cusId");
		Long mainId = commonMap.get("mainId");
		/**保存(修改)工作信息**/
		if (applyJobInfoDTO.getId() != null) {
			ApplyJobInfoDO applyJobInfoDO = this.applyJobInfoDao.queryJobInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyJobInfoDO.getId(),TableConstant.T_APPLY_JOB_INFO,
					JsonUtil.object2json(applyJobInfoDO),JsonUtil.object2json(applyJobInfoDTO));
			if (flag) {
				applyJobInfoDTO.setModifyUser(userId);
				applyJobInfoMap = ObjectUtils.describe(applyJobInfoDTO);
				this.applyJobInfoDao.update(applyJobInfoMap);
			}
		}else{
			applyJobInfoDTO.setCreateUser(userId);
			applyJobInfoDTO.setApplyId(applyId);
			applyJobInfoDTO.setCusId(cusId);
			applyJobInfoMap = ObjectUtils.describe(applyJobInfoDTO);
			this.applyJobInfoDao.add(applyJobInfoMap);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 *  校验工作信息下一步
	 *  @author ZhangYu
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdateAll(ApplyBillinfoAllSaveCheckJobDTO applyBillinfoAllSaveCheckJobDTO) throws Exception{
		Map<String, Object> applyJobInfoMap = null;
		ApplyBillInfoDTO applyBillInfoDTO = applyBillinfoAllSaveCheckJobDTO.getApplyBillInfoDTO();//申请单信息
		ApplyClientInfoDTO applyClientInfoDTO = applyBillinfoAllSaveCheckJobDTO.getApplyClientInfoDTO();//客户信息
		ApplyPersonInfoDTO applyPersonInfoDTO = applyBillinfoAllSaveCheckJobDTO.getApplyPersonInfoDTO();//个人信息
		ApplyJobInfoCheckDTO applyJobInfoCheckDTO = applyBillinfoAllSaveCheckJobDTO.getApplyJobInfoCheckDTO();//工作信息
		ApplyPrivateInfoDTO applyPrivateInfoDTO = applyBillinfoAllSaveCheckJobDTO.getApplyPrivateInfoDTO();//私人信息
		List<ApplyLinkmanInfoDTO> homeLinkManInfoDTO = applyBillinfoAllSaveCheckJobDTO.getHomeLinkManInfoDTO();
		List<ApplyLinkmanInfoDTO> workLinkManInfoDTO = applyBillinfoAllSaveCheckJobDTO.getWorkLinkManInfoDTO();
		List<ApplyLinkmanInfoDTO> urgentLinkManInfoDTO = applyBillinfoAllSaveCheckJobDTO.getUrgentLinkManInfoDTO();
		List<ApplyFamilyChildrenDTO> familyChildrenList = applyBillinfoAllSaveCheckJobDTO.getFamilyChildrenList();
		User user = SessionUtil.getLoginUser(User.class);
		Long userId = user.getId();
		/**下一步之前校验图片信息是否完整**/
		RestResponse checkImageInfo = checkImageInfo(applyBillinfoAllSaveCheckJobDTO);
		if (checkImageInfo.getResult() != 0) {
			return checkImageInfo;
		}
		/** 申请产品如果是公务贷，公积金贷，社保贷 薪资发放日为必填项*/
		Long expectProductId = applyBillInfoDTO.getExpectProductId();
		if (expectProductId == 91 || expectProductId == 92 || expectProductId == 93 || expectProductId == 95 || expectProductId == 451 ){
			if (applyJobInfoCheckDTO.getSalaryDelivery() == null || "".equals(applyJobInfoCheckDTO.getSalaryDelivery())) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_SALARY_DAY);
			}
		}
		/**如果共同居住者是其他,其他信息文本框为必输**/
		String liveJoin = applyPersonInfoDTO.getLiveJoin();
		boolean checkLiveJoinFlag=false;
		if (liveJoin.contains(",")) {
			String[] liveJoinArr = liveJoin.split(",");
			checkLiveJoinFlag = false;
			for (String lj: liveJoinArr) {
				if (SysDictEnum.LIVE_JOIN.getCode().equals(Long.valueOf(lj))) {
					checkLiveJoinFlag = true;
				}
			}
		}else if(SysDictEnum.LIVE_JOIN.getCode().equals(Long.valueOf(liveJoin))){
			checkLiveJoinFlag = true;
		}
		if (checkLiveJoinFlag) {
			if (applyPersonInfoDTO.getLiveJoinOther() == null || "".equals(applyPersonInfoDTO.getLiveJoinOther())) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_LIVE_JOIN_OTHER);
			}
		}
		/**校验申请额度是否在可申请额度之内*/
		List<ProductExhibitionDO> exhibitionDOS = homeDao.queryProductExhibition(expectProductId);
    	BigDecimal endMaxAmount = exhibitionDOS.get(0).getMaxAmount();
    	BigDecimal endMinAmount = exhibitionDOS.get(0).getMinAmount();
    	int compareMinNum = applyBillInfoDTO.getExpectMoney().compareTo(endMinAmount);
    	int compareMaxNum = applyBillInfoDTO.getExpectMoney().compareTo(endMaxAmount);
    	if (compareMinNum == -1 ) {
    		return new RestResponse(1,"该产品最低申请金额为"+"【"+endMinAmount+"】元");
		}
    	if (compareMaxNum == 1) {
    		return new RestResponse(1,"该产品最高申请金额为"+"【"+endMaxAmount+"】元");
		}
    	/**年收入**/
    	Double yearIncomeDu = (applyJobInfoCheckDTO.getSalary()+(applyJobInfoCheckDTO.getOtherIncome()==null?0:applyJobInfoCheckDTO.getOtherIncome()))*12/10000;
    	String yearIncome = String.valueOf(yearIncomeDu);
		/**通用保存(修改),除了工作信息之外的申请单信息**/
		Map<String, Long> commonMap = commonSaveOrUpdate(applyBillInfoDTO,applyClientInfoDTO,applyPersonInfoDTO,
				applyPrivateInfoDTO,homeLinkManInfoDTO,workLinkManInfoDTO,urgentLinkManInfoDTO,userId,familyChildrenList,yearIncome);

		Long applyId = commonMap.get("applyId");
		Long cusId = commonMap.get("cusId");
		Long mainId = commonMap.get("mainId");
		/**保存(修改)工作信息**/
		if (applyJobInfoCheckDTO.getId() != null) {
			ApplyJobInfoDO applyJobInfoDO = this.applyJobInfoDao.queryJobInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyJobInfoDO.getId(),TableConstant.T_APPLY_JOB_INFO,
					JsonUtil.object2json(applyJobInfoDO),JsonUtil.object2json(applyJobInfoCheckDTO));
			if (flag) {
				applyJobInfoCheckDTO.setModifyUser(userId);
				applyJobInfoMap = ObjectUtils.describe(applyJobInfoCheckDTO);
				this.applyJobInfoDao.update(applyJobInfoMap);
			}
		}else{
			applyJobInfoCheckDTO.setCreateUser(userId);
			applyJobInfoCheckDTO.setApplyId(applyId);
			applyJobInfoCheckDTO.setCusId(cusId);
			applyJobInfoMap = ObjectUtils.describe(applyJobInfoCheckDTO);
			this.applyJobInfoDao.add(applyJobInfoMap);
		}
		/**插入申请单过审页面**/
		otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.APPLY);
		/**插入结清证明图片**/
		String key = RedisConstant.IMAGE_APPLY + String.valueOf(applyId) +"_I0_*";
		Set<String> keys = RedisUtil.keys(key);
		if (keys.size()>0) {
			otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.SETTLE);
		}else{
			Map<String, Object>paraMap=new HashMap<String, Object>();
			paraMap.put("fileClassificationId",9);
			paraMap.put("applyId", applyId);
			int fileIsExit = this.fileDataInfoDao.fileIsExit(paraMap);
			if (fileIsExit > 0) {
				otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.SETTLE);
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 *  下一步通用保存信息(除工作信息外)
	 * @author ZhangYu
	 * @return
	 * @throws Exception 
	 */
	private Map<String, Long> commonSaveOrUpdate(ApplyBillInfoDTO applyBillInfoDTO,
			ApplyClientInfoDTO applyClientInfoDTO,ApplyPersonInfoDTO applyPersonInfoDTO,
			ApplyPrivateInfoDTO applyPrivateInfoDTO,List<ApplyLinkmanInfoDTO> homeLinkManInfos,
			List<ApplyLinkmanInfoDTO> workLinkManInfos,List<ApplyLinkmanInfoDTO> urgetLinkManInfos,
			Long userId,List<ApplyFamilyChildrenDTO> familyChildrenList,String yearIncome){
		Map<String, Object> applyBillInfoMap = null;
		Map<String, Object> applyClientMap = null;
		Map<String, Object> applyPersonMap = null;
		Map<String, Object> applyPrivateMap = null;
		Map<String,Long> map = new HashMap<>();

		Long applyId = applyBillInfoDTO.getId();
		Long mainId = applyBillInfoDTO.getMainId();
		Long cusId = applyClientInfoDTO.getId();
		/**保存客户信息**/
		if (applyClientInfoDTO.getId() != null) {
			ApplyClientInfoDO applyClientInfoDO = this.applyClientInfoDao.queryClientInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyClientInfoDO.getId(),TableConstant.T_APPLY_CLIENT_INFO,
					JsonUtil.object2json(applyClientInfoDO), JsonUtil.object2json(applyClientInfoDTO));
			if (flag) {
				applyClientInfoDTO.setModifyUser(userId);
				applyClientMap = ObjectUtils.describe(applyClientInfoDTO);
				this.applyClientInfoDao.updateOnlyChanged(applyClientMap);
			}
		}else{
			applyClientInfoDTO.setCreateUser(userId);
			applyClientMap = ObjectUtils.describe(applyClientInfoDTO);
			this.applyClientInfoDao.add(applyClientMap);
		}
		/**保存申请单信息**/
		if (applyBillInfoDTO.getId() != null) {
			ApplyBillInfoDO applyBillInfoDO = this.applyBillInfoDao.queryBillInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyBillInfoDTO.getId(), TableConstant.T_APPLY_BILL_INFO,
					JsonUtil.object2json(applyBillInfoDO), JsonUtil.object2json(applyBillInfoDTO));
			if (flag) {
				applyBillInfoMap = ObjectUtils.describe(applyBillInfoDTO);
				this.applyBillInfoDao.updateApplyBillInfoById(applyBillInfoMap);
			}
		}else{
			applyBillInfoDTO.setMainId(mainId);
			applyBillInfoDTO.setCusId(applyClientInfoDTO.getId());
			String applyNum = ApplyNumberUtil.getsApplyNumber();
			applyBillInfoDTO.setApplyNum(applyNum);
			applyBillInfoMap = ObjectUtils.describe(applyBillInfoDTO);
			this.applyBillInfoDao.add(applyBillInfoMap);
		}
		/**暂存主表信息**/
		updateMainInfoSave(userId,mainId, applyBillInfoDTO);
		/**保存个人信息**/
		String homeTownProvinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyPersonInfoDTO.getHomeTownProvince());
		String homeTownCityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyPersonInfoDTO.getHomeTownCity());
		String homeTownAreaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyPersonInfoDTO.getHomeTownArea());
		String nowProvinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyPersonInfoDTO.getNowAddressProvince());
		String nowCityLabel= this.applyCommonProvinceDao.getCityLabelByCityId(applyPersonInfoDTO.getNowAddressCity());
		String nowAreaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyPersonInfoDTO.getNowAddressArea());
		String homeAllAdress = (homeTownProvinceLabel==null?"":homeTownProvinceLabel)+(homeTownCityLabel==null?"":homeTownCityLabel)+
				(homeTownAreaLabel==null?"":homeTownAreaLabel)+(applyPersonInfoDTO.getHomeTown()==null?"":applyPersonInfoDTO.getHomeTown());
		String nowAllAdress = (nowProvinceLabel==null?"":nowProvinceLabel)+(nowCityLabel==null?"":nowCityLabel)+(nowAreaLabel==null?"":nowAreaLabel)
				+(applyPersonInfoDTO.getNowAddress()==null?"":applyPersonInfoDTO.getNowAddress());
		String allTell = (applyPersonInfoDTO.getTellArea()==null?"":(applyPersonInfoDTO.getTellArea()+"-"))+(applyPersonInfoDTO.getTell()==null?"":applyPersonInfoDTO.getTell()); 
		applyPersonInfoDTO.setCusId(applyClientInfoDTO.getId());
		applyPersonInfoDTO.setHomeTownAllAddress(homeAllAdress);
		applyPersonInfoDTO.setNowAllAddress(nowAllAdress);
		applyPersonInfoDTO.setAllTell(allTell);
		/**年收入*/
		applyPersonInfoDTO.setYearIncome(yearIncome);
		if (applyPersonInfoDTO.getId() != null) {
			ApplyPersonInfoDO applyPersonInfoDO = this.applyPersonInfoDao.queryPersonInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyPersonInfoDO.getId(), TableConstant.T_APPLY_PERSONAL_INFO,
					JsonUtil.object2json(applyPersonInfoDO),JsonUtil.object2json(applyPersonInfoDTO));
			if (flag) {
				applyPersonInfoDTO.setModifyUser(userId);
				applyPersonMap = ObjectUtils.describe(applyPersonInfoDTO);
				this.applyPersonInfoDao.update(applyPersonMap);
			}
		}else{
			applyPersonInfoDTO.setApplyId(applyBillInfoDTO.getId());
			applyPersonInfoDTO.setCusId(applyClientInfoDTO.getId());
			applyPersonInfoDTO.setCreateUser(userId);
			applyPersonMap = ObjectUtils.describe(applyPersonInfoDTO);
			this.applyPersonInfoDao.add(applyPersonMap);
		}
		/**保存家庭子女信息**/
		Map<String, Object> queryChildMap = new HashMap<>();
		queryChildMap.put("applyId", applyBillInfoDTO.getId());
		queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
		List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao.queryFamilyChildrenList(queryChildMap);
		List<ApplyFamilyChildrenDTO> addFamilyList = new ArrayList<>();
		List<ApplyFamilyChildrenDTO> updateFamilyList = new ArrayList<>();

		Map<String,Object> familyChildrenListMap = new HashMap<>();
		for (int i = 0;i<familyChildrenList.size();i++){
			familyChildrenListMap.put(String.valueOf(familyChildrenList.get(i).getId()),familyChildrenList.get(i).getAge());
		}
		Map<String,Object> applyFamilyChildrenDOsMap = new HashMap<>();
		for (ApplyFamilyChildrenDO familyChildrenDO:applyFamilyChildrenDOs){
			applyFamilyChildrenDOsMap.put(String.valueOf(familyChildrenDO.getId()),familyChildrenDO.getAge());
		}
		for (ApplyFamilyChildrenDTO childrenDO:familyChildrenList){
			if (StringUtils.isNullOrEmpty(childrenDO.getId())){
				childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
				addFamilyList.add(childrenDO);
			}else {
				if (applyFamilyChildrenDOsMap.containsKey(String.valueOf(childrenDO.getId()))){
					childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
					updateFamilyList.add(childrenDO);
				}
			}
		}
		for (int i = 0;i<applyFamilyChildrenDOs.size();i++){
			if (familyChildrenListMap.containsKey(String.valueOf(applyFamilyChildrenDOs.get(i).getId()))){
				applyFamilyChildrenDOs.remove(i);
				i--;
			}
		}
		for (ApplyFamilyChildrenDO familyChildrenDO:applyFamilyChildrenDOs){
			ApplyFamilyChildrenDTO applyFamilyChildrenDTO = new ApplyFamilyChildrenDTO();
			applyFamilyChildrenDTO.setDelFlag(SysDictEnum.NO_VALID.getCode());
			applyFamilyChildrenDTO.setAge(familyChildrenDO.getAge());
			applyFamilyChildrenDTO.setApplyId(familyChildrenDO.getApplyId());
			applyFamilyChildrenDTO.setId(String.valueOf(familyChildrenDO.getId()));
			updateFamilyList.add(applyFamilyChildrenDTO);
		}
		if (addFamilyList.size() > 0) {
			this.applyPersonInfoDao.addFamilyChildrenList(addFamilyList);
		}
		if (updateFamilyList.size() > 0) {
			this.applyPersonInfoDao.updateFamilyChildrenList(updateFamilyList);
		}
		/**保存私营信息**/
		if (applyPrivateInfoDTO.getId() != null) {
			ApplyPrivateInfoDO applyPrivateInfoDO = this.applyPrivateInfoDao.queryPrivateInfoByMainId(mainId);
			boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyPrivateInfoDO.getId(), TableConstant.T_APPLY_PRIVATE_INFO,
					JsonUtil.object2json(applyPrivateInfoDO), JsonUtil.object2json(applyPrivateInfoDTO));
			if (flag) {
				applyPrivateInfoDTO.setModifyUser(userId);
				applyPrivateMap = ObjectUtils.describe(applyPrivateInfoDTO);
				this.applyPrivateInfoDao.update(applyPrivateMap);
			}
		}else{
			if (StringUtils.isNotNullAndEmpty(applyPrivateInfoDTO.getEnterpriseName()) || (applyPrivateInfoDTO.getRegDate()!=null)
					|| (applyPrivateInfoDTO.getEnteType() != null) || StringUtils.isNotNullAndEmpty(applyPrivateInfoDTO.getTel())  
					|| (applyPrivateInfoDTO.getPalace() != null) || (applyPrivateInfoDTO.getStockRatio() != null) || (applyPrivateInfoDTO.getStaffAmount() != null)){ 	
				applyPrivateInfoDTO.setCreateUser(userId);
				applyPrivateInfoDTO.setApplyId(applyBillInfoDTO.getId());
				applyPrivateInfoDTO.setCusId(applyClientInfoDTO.getId());
				applyPrivateMap = ObjectUtils.describe(applyPrivateInfoDTO);
				this.applyPrivateInfoDao.add(applyPrivateMap);

			}
		}
		/**保存联系人信息**/
		Map<String, List<ApplyLinkmanInfoDTO>> linkManInfoListNextMap = getLinkManInfoListNext(homeLinkManInfos, workLinkManInfos, urgetLinkManInfos, userId, applyId, cusId);
		List<ApplyLinkmanInfoDTO> addLinkManInfos = linkManInfoListNextMap.get("add");
		List<ApplyLinkmanInfoDTO> updateLinkManInfos = linkManInfoListNextMap.get("update");
		if (addLinkManInfos.size() > 0) {
			this.applyLinkmanInfoDao.addLinkManInfos(addLinkManInfos);
		}
		if (updateLinkManInfos.size() > 0) {
			this.applyLinkmanInfoDao.updateLinkManInfos(updateLinkManInfos);
		}
		/**添加申请单ID和客户ID**/
		map.put("applyId", applyBillInfoDTO.getId());
		map.put("mainId", applyBillInfoDTO.getMainId());
		map.put("cusId", applyClientInfoDTO.getId());
		return map;
	}
	
	/**
	 * 获取新增和修改联系人列表信息(暂存) 
	 * @author ZhangYu
	 * @return
	 */
	private Map<String,List<ApplyLinkmanInfoTempSaveDTO>> getLinkManInfoListTemp(List<ApplyLinkmanInfoTempSaveDTO> homeLinkManInfos,
			List<ApplyLinkmanInfoTempSaveDTO> workLinkManInfos,List<ApplyLinkmanInfoTempSaveDTO> urgetLinkManInfos,
			Long userId,Long applyId,Long cusId){
		Map<String, List<ApplyLinkmanInfoTempSaveDTO>> linkManInfoMap = new HashMap<>();
		List<ApplyLinkmanInfoTempSaveDTO> allLinkManInfos = new ArrayList<>(); //全部联系人信息
		List<ApplyLinkmanInfoTempSaveDTO> updateLinkManInfos = new ArrayList<>();//修改联系人信息集合
		List<ApplyLinkmanInfoTempSaveDTO> addLinkManInfos = new ArrayList<>(); //新增联系人信息集合
		if (homeLinkManInfos.size() > 0 && homeLinkManInfos != null) {
			for (ApplyLinkmanInfoTempSaveDTO applyLinkmanInfoTempSaveDTO : homeLinkManInfos) {
				applyLinkmanInfoTempSaveDTO.setContactType(SysDictEnum.FAMILY_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoTempSaveDTO);
			}
		}
		if (workLinkManInfos.size() > 0 && workLinkManInfos != null) {
			for (ApplyLinkmanInfoTempSaveDTO applyLinkmanInfoTempSaveDTO : workLinkManInfos) {
				applyLinkmanInfoTempSaveDTO.setContactType(SysDictEnum.WORK_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoTempSaveDTO);
			}
		}
		if (urgetLinkManInfos.size() > 0 && urgetLinkManInfos != null) {
			for (ApplyLinkmanInfoTempSaveDTO applyLinkmanInfoTempSaveDTO : urgetLinkManInfos) {
				applyLinkmanInfoTempSaveDTO.setContactType(SysDictEnum.QUICK_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoTempSaveDTO);
			}
		}
		if (allLinkManInfos.size() > 0) {
			for (ApplyLinkmanInfoTempSaveDTO applyLinkmanInfoTempSaveDTO : allLinkManInfos) {
				String provinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyLinkmanInfoTempSaveDTO.getProvince());
				String cityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyLinkmanInfoTempSaveDTO.getCity());
				String areaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyLinkmanInfoTempSaveDTO.getArea());
				String address = "";
				String allAddress = "";
				if (StringUtils.isNullOrEmpty(provinceLabel)) {
					provinceLabel = "";
				}
				if (StringUtils.isNullOrEmpty(cityLabel)) {
					cityLabel = "";
				}
				if (StringUtils.isNullOrEmpty(areaLabel)) {
					areaLabel = "";
				}
				if (StringUtils.isNotNullAndEmpty(applyLinkmanInfoTempSaveDTO.getAddress())) {
					address = applyLinkmanInfoTempSaveDTO.getAddress();
				}
				allAddress = provinceLabel+cityLabel+areaLabel+address;
				if (applyLinkmanInfoTempSaveDTO.getId() != null) {
					ApplyLinkmanInfoDO applyLinkmanInfoDO = this.applyLinkmanInfoDao.queryLinkManById(applyLinkmanInfoTempSaveDTO.getId());
					boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyLinkmanInfoTempSaveDTO.getId(), TableConstant.T_APPLY_LINKMAN_INFO,
							JsonUtil.object2json(applyLinkmanInfoDO), JsonUtil.object2json(applyLinkmanInfoTempSaveDTO));
					if (flag) {
						applyLinkmanInfoTempSaveDTO.setModifyUser(userId);
						applyLinkmanInfoTempSaveDTO.setAllAddress(allAddress);
						updateLinkManInfos.add(applyLinkmanInfoTempSaveDTO);
					}
				}else{
					applyLinkmanInfoTempSaveDTO.setModifyUser(userId);
					applyLinkmanInfoTempSaveDTO.setApplyId(applyId);
					applyLinkmanInfoTempSaveDTO.setCusId(cusId);
					applyLinkmanInfoTempSaveDTO.setAllAddress(allAddress);
					addLinkManInfos.add(applyLinkmanInfoTempSaveDTO);
				}
			}
		}
		
		linkManInfoMap.put("add",addLinkManInfos);
		linkManInfoMap.put("update",updateLinkManInfos);
		return linkManInfoMap;
	}

	/**
	 * 获取新增和修改联系人列表信息(下一步) 
	 * @author ZhangYu
	 * @return
	 */
	private Map<String,List<ApplyLinkmanInfoDTO>> getLinkManInfoListNext(List<ApplyLinkmanInfoDTO> homeLinkManInfos,
			List<ApplyLinkmanInfoDTO> workLinkManInfos,List<ApplyLinkmanInfoDTO> urgetLinkManInfos,
			Long userId,Long applyId,Long cusId){
		Map<String, List<ApplyLinkmanInfoDTO>> linkManInfoMap = new HashMap<>();
		List<ApplyLinkmanInfoDTO> allLinkManInfos = new ArrayList<>(); //全部联系人信息
		List<ApplyLinkmanInfoDTO> updateLinkManInfos = new ArrayList<>();//修改联系人信息集合
		List<ApplyLinkmanInfoDTO> addLinkManInfos = new ArrayList<>(); //新增联系人信息集合
		if (homeLinkManInfos.size() > 0 && homeLinkManInfos != null) {
			for (ApplyLinkmanInfoDTO applyLinkmanInfoDTO: homeLinkManInfos) {
				applyLinkmanInfoDTO.setContactType(SysDictEnum.FAMILY_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoDTO);
			}
		}
		if (workLinkManInfos.size() > 0 && workLinkManInfos != null) {
			for (ApplyLinkmanInfoDTO applyLinkmanInfoDTO: workLinkManInfos) {
				applyLinkmanInfoDTO.setContactType(SysDictEnum.WORK_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoDTO);
			}
		}
		if (urgetLinkManInfos.size() > 0 && urgetLinkManInfos != null) {
			for (ApplyLinkmanInfoDTO applyLinkmanInfoDTO : urgetLinkManInfos) {
				applyLinkmanInfoDTO.setContactType(SysDictEnum.QUICK_PERSON_LINK.getCode());
				allLinkManInfos.add(applyLinkmanInfoDTO);
			}
		}
		if (allLinkManInfos.size() > 0) {
			for (ApplyLinkmanInfoDTO applyLinkmanInfoDTO : allLinkManInfos) {
				String provinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyLinkmanInfoDTO.getProvince());
				String cityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyLinkmanInfoDTO.getCity());
				String areaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyLinkmanInfoDTO.getArea());
				String address = "";
				String allAddress = "";
				if (StringUtils.isNullOrEmpty(provinceLabel)) {
					provinceLabel = "";
				}
				if (StringUtils.isNullOrEmpty(cityLabel)) {
					cityLabel = "";
				}
				if (StringUtils.isNullOrEmpty(areaLabel)) {
					areaLabel = "";
				}
				if (StringUtils.isNotNullAndEmpty(applyLinkmanInfoDTO.getAddress())) {
					address = applyLinkmanInfoDTO.getAddress();
				}
				allAddress = provinceLabel+cityLabel+areaLabel+address;
				if (applyLinkmanInfoDTO.getId() != null) {
					ApplyLinkmanInfoDO applyLinkmanInfoDO = this.applyLinkmanInfoDao.queryLinkManById(applyLinkmanInfoDTO.getId());
					boolean flag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyLinkmanInfoDTO.getId(), TableConstant.T_APPLY_LINKMAN_INFO,
							JsonUtil.object2json(applyLinkmanInfoDO), JsonUtil.object2json(applyLinkmanInfoDTO));
					if (flag) {
						applyLinkmanInfoDTO.setModifyUser(userId);
						applyLinkmanInfoDTO.setAllAddress(allAddress);
						updateLinkManInfos.add(applyLinkmanInfoDTO);
					}
				}else{
					applyLinkmanInfoDTO.setModifyUser(userId);
					applyLinkmanInfoDTO.setApplyId(applyId);
					applyLinkmanInfoDTO.setCusId(cusId);
					applyLinkmanInfoDTO.setAllAddress(allAddress);
					addLinkManInfos.add(applyLinkmanInfoDTO);
				}
			}
		}
		
		linkManInfoMap.put("add",addLinkManInfos);
		linkManInfoMap.put("update",updateLinkManInfos);
		return linkManInfoMap;
	}

	/**
	 * 暂存更新主表信息 
	 * @author ZhangYu
	 * @param mainId
	 * @param applyBillInfoTempSaveDTO
	 */
	private void updateMainInfoTempSave(Long userId,Long mainId,ApplyBillInfoTempSaveDTO applyBillInfoTempSaveDTO){
		Map<String, Object> paramMainMap =new HashMap<>();
		paramMainMap.put("id", mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paramMainMap);
		String oldJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		if (StringUtils.isNotNullAndEmpty(applyBillInfoTempSaveDTO.getProjectCode())) {
			applyBillMainInfoDO.setProjectCode(Long.parseLong(applyBillInfoTempSaveDTO.getProjectCode()));
		}
		if(applyBillInfoTempSaveDTO.getExpectProductId() != null){
			applyBillMainInfoDO.setExpectProductId(applyBillInfoTempSaveDTO.getExpectProductId());
		}
		if (applyBillInfoTempSaveDTO.getExpectProductName() != null) {
			applyBillMainInfoDO.setExpectProductName(applyBillInfoTempSaveDTO.getExpectProductName());
		}
		if (applyBillInfoTempSaveDTO.getExpectProductType() != null) {
			applyBillMainInfoDO.setExpectProductType(applyBillInfoTempSaveDTO.getExpectProductType());
		}
		if (applyBillInfoTempSaveDTO.getExpectMoney() != null) {
			applyBillMainInfoDO.setExpectMoney(applyBillInfoTempSaveDTO.getExpectMoney());
		}
		if (applyBillInfoTempSaveDTO.getStoreOrgId() != null) {
			applyBillMainInfoDO.setStoreOrgId(applyBillInfoTempSaveDTO.getStoreOrgId());
		}
		if (applyBillInfoTempSaveDTO.getTeamOrgId() != null) {
			applyBillMainInfoDO.setTeamOrgId(applyBillInfoTempSaveDTO.getTeamOrgId());
		}
		if (applyBillInfoTempSaveDTO.getTeamManagerId() != null) {
			applyBillMainInfoDO.setTeamManagerId(applyBillInfoTempSaveDTO.getTeamManagerId());
		}
		if (applyBillInfoTempSaveDTO.getTeamManageUname() != null) {
			applyBillMainInfoDO.setTeamManagerUname(applyBillInfoTempSaveDTO.getTeamManageUname());
		}
		if (applyBillInfoTempSaveDTO.getManagerUid() != null) {
			applyBillMainInfoDO.setManagerUid(applyBillInfoTempSaveDTO.getManagerUid());
		}
		if (applyBillInfoTempSaveDTO.getManagerUname() != null) {
			applyBillMainInfoDO.setManagerUname(applyBillInfoTempSaveDTO.getManagerUname());
		}
		if (applyBillInfoTempSaveDTO.getServiceUid() != null) {
			applyBillMainInfoDO.setServiceUid(applyBillInfoTempSaveDTO.getServiceUid());
		}
		if (applyBillInfoTempSaveDTO.getServiceUname() != null) {
			applyBillMainInfoDO.setServiceName(applyBillInfoTempSaveDTO.getServiceUname());
		}
		applyBillMainInfoDO.setExpectTerm(applyBillInfoTempSaveDTO.getExpectTerm());
		String newJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		boolean mainUpdateFlag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO, oldJsonData, newJsonData);
		if (mainUpdateFlag) {
			this.currencyDao.updateMainInFo(applyBillMainInfoDO);
		}
	}

	/**
	 * 下一步更新主表信息
	 * @author ZhangYu
	 * @param mainId
	 * @param applyBillInfoDTO
	 */
	private void updateMainInfoSave(Long userId,Long mainId,ApplyBillInfoDTO applyBillInfoDTO){
		Map<String, Object> paramMainMap =new HashMap<>();
		paramMainMap.put("id", mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paramMainMap);
		String oldJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		if (StringUtils.isNotNullAndEmpty(applyBillInfoDTO.getProjectCode())) {
			applyBillMainInfoDO.setProjectCode(Long.parseLong(applyBillInfoDTO.getProjectCode()));
		}
		if(applyBillInfoDTO.getExpectProductId() != null){
			applyBillMainInfoDO.setExpectProductId(applyBillInfoDTO.getExpectProductId());
		}
		if (applyBillInfoDTO.getExpectProductName() != null) {
			applyBillMainInfoDO.setExpectProductName(applyBillInfoDTO.getExpectProductName());
		}
		if (applyBillInfoDTO.getExpectProductType() != null) {
			applyBillMainInfoDO.setExpectProductType(applyBillInfoDTO.getExpectProductType());
		}
		if (applyBillInfoDTO.getExpectMoney() != null) {
			applyBillMainInfoDO.setExpectMoney(applyBillInfoDTO.getExpectMoney());
		}
		if (applyBillInfoDTO.getStoreOrgId() != null) {
			applyBillMainInfoDO.setStoreOrgId(applyBillInfoDTO.getStoreOrgId());
		}
		if (applyBillInfoDTO.getTeamOrgId() != null) {
			applyBillMainInfoDO.setTeamOrgId(applyBillInfoDTO.getTeamOrgId());
		}
		if (applyBillInfoDTO.getTeamManagerId() != null) {
			applyBillMainInfoDO.setTeamManagerId(applyBillInfoDTO.getTeamManagerId());
		}
		if (applyBillInfoDTO.getTeamManageUname() != null) {
			applyBillMainInfoDO.setTeamManagerUname(applyBillInfoDTO.getTeamManageUname());
		}
		if (applyBillInfoDTO.getManagerUid() != null) {
			applyBillMainInfoDO.setManagerUid(applyBillInfoDTO.getManagerUid());
		}
		if (applyBillInfoDTO.getManagerUname() != null) {
			applyBillMainInfoDO.setManagerUname(applyBillInfoDTO.getManagerUname());
		}
		if (applyBillInfoDTO.getServiceUid() != null) {
			applyBillMainInfoDO.setServiceUid(applyBillInfoDTO.getServiceUid());
		}
		if (applyBillInfoDTO.getServiceUname() != null) {
			applyBillMainInfoDO.setServiceName(applyBillInfoDTO.getServiceUname());
		}
		applyBillMainInfoDO.setExpectTerm(applyBillInfoDTO.getExpectTerm());
		String newJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		boolean mainUpdateFlag = this.tableModifyService.insertApplyCommonModifyLog(userId,applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO, oldJsonData, newJsonData);
		if (mainUpdateFlag) {
			this.currencyDao.updateMainInFo(applyBillMainInfoDO);
		}
	}
	
	/**
	 * 提交更新主表信息 
	 * @author ZhangYu
	 * @param mainId
	 * @param applyBillInfoDTO
	 */
	private void updateMainInfoOnSubmit(Long mainId,ApplyBillInfoDTO applyBillInfoDTO){
		User user = SessionUtil.getLoginUser(User.class);
		Map<String, Object> paramMainMap =new HashMap<>();
		paramMainMap.put("id", mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paramMainMap);
		String oldJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		applyBillMainInfoDO.setExpectProductId(applyBillInfoDTO.getExpectProductId());
		applyBillMainInfoDO.setExpectProductName(applyBillInfoDTO.getExpectProductName());
		applyBillMainInfoDO.setExpectProductType(applyBillInfoDTO.getExpectProductType());
		applyBillMainInfoDO.setExpectMoney(applyBillInfoDTO.getExpectMoney());
		applyBillMainInfoDO.setStoreOrgId(applyBillInfoDTO.getStoreOrgId());
		applyBillMainInfoDO.setTeamOrgId(applyBillInfoDTO.getTeamOrgId());
		applyBillMainInfoDO.setTeamManagerId(applyBillInfoDTO.getTeamManagerId());
		applyBillMainInfoDO.setTeamManagerUname(applyBillInfoDTO.getTeamManageUname());
		applyBillMainInfoDO.setManagerUid(applyBillInfoDTO.getManagerUid());
		applyBillMainInfoDO.setManagerUname(applyBillInfoDTO.getManagerUname());
		applyBillMainInfoDO.setServiceUid(applyBillInfoDTO.getServiceUid());
		applyBillMainInfoDO.setServiceName(applyBillInfoDTO.getServiceUname());
		String newJsonData = JsonUtil.object2json(applyBillMainInfoDO);
		boolean mainUpdateFlag = this.tableModifyService.insertApplyCommonModifyLog(user.getId(),applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO, oldJsonData, newJsonData);
		if (mainUpdateFlag) {
			this.currencyDao.updateMainInFo(applyBillMainInfoDO);
		}
		
	}

	@Override
	public RestResponse queryClientAbandonReason() throws Exception{
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("typeId",SysDictEnum.CLIENT_ABANDON.getParentCode());
		List<ApplyClientAbandonDO> applyClientAbandonDOs = this.applyBillInfoDao.queryClientAbandonReason(paramMap);
		return new RestResponse(MsgErrCode.SUCCESS, applyClientAbandonDOs);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse confirmClientAbandon(ApplyClientAbandonDTO applyClientAbandonDTO) throws Exception{
		User user = SessionUtil.getLoginUser(User.class);
		/**获得单子当前状态*/
		int state = applyBillInfoDao.getMainState(applyClientAbandonDTO.getMainId());
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(user.getId());
		mainLogDTO.setModifyUserName(user.getName());
		mainLogDTO.setBusinessState(NodeStateConstant.APPLY_FOR_INVALIDATION);
		mainLogDTO.setBusinessStateName("申请作废");
		mainLogDTO.setMainId(applyClientAbandonDTO.getMainId());
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(NodeStateConstant.APPLY_FOR_INVALIDATION);
		applyBillMainInfoDO.setModifyUser(user.getId());
		applyBillMainInfoDO.setId(applyClientAbandonDTO.getMainId());
		applyBillMainInfoDO.setAbandonReason(applyClientAbandonDTO.getId());
		applyBillMainInfoDO.setClientAbandon(SysDictEnum.YES.getCode());
		applyBillMainInfoDO.setPrevious(state);
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	
	@Override
	public RestResponse updateLinkManDelFlagById(Long id) throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("id", id);
		paramMap.put("delFlag",SysDictEnum.NO_VALID.getCode());
		this.applyBillInfoDao.updateLinkManDelFlagById(paramMap);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse onSubmintOutline(Long applyId,Long mainId,Long projectCode) throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		/**跑大纲组装参数*/
		if (mainId != null && applyId != null) {
			// -- 修改专案码
			ApplyBillMainInfoDO mainInfoDO = new ApplyBillMainInfoDO();
			mainInfoDO.setProjectCode(projectCode);
			mainInfoDO.setModifyUser(user.getId());
			mainInfoDO.setId(mainId);
			applyBillInfoDao.updateMainInfoProjectCode(mainInfoDO);
			//-- 修改历史备注
			String serviceRemark = applyBillInfoDao.getServiceRemark(applyId);
			if (StringUtils.isNotNullAndEmpty(serviceRemark)) {
				ApplyOtherdataRemarkDTO applyOtherdataRemarkDTO = new ApplyOtherdataRemarkDTO();
				applyOtherdataRemarkDTO.setApplyId(applyId);
				applyOtherdataRemarkDTO.setRemark(serviceRemark);
				applyOtherdataRemarkDTO.setCreateUser(user.getId());
				this.applyBillInfoDao.addHistoryRemark(applyOtherdataRemarkDTO);//修改历史备注
				this.applyBillInfoDao.updateServiceRemark(applyId);//修改申请表中的备注为NULL
			}
			/**根据风控数据校验工作信息是否完整**/
			RestResponse checkAuditJob = checkAuditJob(applyId);
			if (checkAuditJob.getResult() != 0) {
				return checkAuditJob;
			}
			/**根据风控数据校验校验房产证明信息是否完整**/
			RestResponse checkOtherHouse = checkOtherHouse(applyId);
			if (checkOtherHouse.getResult() != 0) {
				return checkOtherHouse;
			}
			/**根据风控数据校验保单第一条数据是否完整**/
			RestResponse checkAuditInsurance = checkAuditInsurance(applyId);
			if (checkAuditInsurance.getResult() != 0) {
				return checkAuditInsurance;
			}
			/**根据风控数据校验通话详单信息是否完整**/
			RestResponse checkAuditPhone = checkAuditPhone(applyId);
			if (checkAuditPhone.getResult() != 0) {
				return checkAuditPhone;
			}
			SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(mainId, NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
			if (systemAuditParamDTO == null) {
				return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			} else {
				try {
					String repellentCode = null;
					String repellentMessage = null;
					Integer repellentNumberofdays = null;
					systemAuditParamDTO.setSubmitUser(user.getName());
					systemAuditParamDTO.setSynOrAsy("synchronous");
					MainResponseInfo mainResponseInfo = processService.runOutlineRules(JsonUtils.toJSON(systemAuditParamDTO));
					Long cusId = Long.valueOf(mainResponseInfo.getCusId());
					if (mainResponseInfo.getErrorCircumstances() != null){
						ErrorCircumstances error = mainResponseInfo.getErrorCircumstances();
						String flowState = error.getFlowState();
						if ("1".equals(flowState)){
							// -- 调用系统审核
							return onSubmintSystemAudit(user,applyId,systemAuditParamDTO);
						}else {
							return new RestResponse(2,"风控系统异常，请联系管理员！");
						}
					}
					// -- 其他平台上线后替换
					else {
						RiskResponseInfo riskResponseInfo = mainResponseInfo.getRiskResponseInfo();
						if (riskResponseInfo != null){
							repellentCode = riskResponseInfo.getRepellentCode();
							repellentMessage = riskResponseInfo.getRepellentMessage();
							repellentNumberofdays = riskResponseInfo.getRepellentNumberofdays();
						}
						if (StringUtils.isNullOrEmpty(repellentCode)){
							// -- 调用系统审核
							return onSubmintSystemAudit(user,applyId,systemAuditParamDTO);
						}
					}

//					else if (mainResponseInfo.getFqzResult() != null && "2".equals(mainResponseInfo.getFqzResult())){
//						repellentCode = "FQ001";
//						repellentMessage = "反欺诈确认欺诈";
//						repellentNumberofdays = 36500;
//					}else {
//						repellentCode = mainResponseInfo.getRepellentCode();
//						repellentMessage = mainResponseInfo.getRepellentMessage();
//						repellentNumberofdays = mainResponseInfo.getRepellentNumberofdays();
//						if (StringUtils.isNullOrEmpty(repellentCode)){
//							// -- 调用系统审核
//							return onSubmintSystemAudit(user,applyId,systemAuditParamDTO);
//						}
//					}
					MainLogDTO mainLogDTO = new MainLogDTO();
					mainLogDTO.setModifyUser(user.getId());
					mainLogDTO.setModifyUserName(user.getName());
					mainLogDTO.setBusinessState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
					mainLogDTO.setBusinessStateName("系统审核拒贷");
					mainLogDTO.setMainId(mainId);
					ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
					applyBillMainInfoDO.setState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
					applyBillMainInfoDO.setModifyUser(user.getId());
					applyBillMainInfoDO.setId(mainId);
					applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
					if (StringUtils.isNotNullAndEmpty(repellentCode)){
						clinetUserModifyService.updateClientAllowableEntryTime(cusId,repellentNumberofdays);
						applyBillMainInfoDO.setRefuseCode(repellentCode);
					}
					if (StringUtils.isNotNullAndEmpty(repellentMessage)){
						applyBillMainInfoDO.setRefuseValue(repellentMessage);
					}
					this.currencyDao.addMainLog(mainLogDTO);
					this.currencyDao.updateMainInFo(applyBillMainInfoDO);
					return new RestResponse(1,repellentMessage);
				}catch (Exception e){
					e.printStackTrace();
					log.info("调用风控接口异常",e);
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
					return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
				}
			}
		}else {
			return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
		}
	}

	/**
	 * 提交审核
	 * @author      xieqingyang
	 * @date 2018/7/12 下午7:21
	 * @version     1.0
	 * @param user 用户信息
	 * @param applyId 申请单ID
	 * @param systemAuditParamDTO 发送风控参数
	 * @return 返回处理结果
	 * @throws Exception 所有异常
	 */
	private RestResponse onSubmintSystemAudit(User user,Long applyId,SystemAuditParamDTO systemAuditParamDTO) throws Exception {
		systemAuditParamDTO.setSubmitUser(user.getName());
		systemAuditParamDTO.setSynOrAsy("asynchronous");
		systemAuditParamDTO.setSubmitNode(String.valueOf(NodeStateConstant.PENDING_SYSTEM_AUDIT));
		/**插入未过审页面*/
		insertCheckItem(applyId);
		/**调用风控系统系统审核日志*/
		CheatInterfaceLogDO cheatInterfaceLogDO = new CheatInterfaceLogDO();
		cheatInterfaceLogDO.setApplyMainId(Long.valueOf(systemAuditParamDTO.getApplyMainId()));
		cheatInterfaceLogDO.setInterfaceFlag("1");
		cheatInterfaceLogDO.setRequestJson(JsonUtils.toJSON(systemAuditParamDTO));
		cheatInterfaceLogDO.setSubmitNode(String.valueOf(NodeStateConstant.CUSTOMER_SERVICE_ENTRY));
		cheatInterfaceLogDO.setSubmitUser(user.getId());
		cheatInterfaceLogDO.setCreateUser(user.getId());
		/**修改主表并添加主表修改日志**/
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(user.getId());
		mainLogDTO.setModifyUserName(user.getName());
		mainLogDTO.setBusinessState(NodeStateConstant.PENDING_SYSTEM_AUDIT);
		mainLogDTO.setBusinessStateName("系统审核中");
		mainLogDTO.setMainId(Long.parseLong(systemAuditParamDTO.getApplyMainId()));
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(NodeStateConstant.PENDING_SYSTEM_AUDIT);
		applyBillMainInfoDO.setSubmitApplyToAuditTime(new Date());
		applyBillMainInfoDO.setModifyUser(user.getId());
		applyBillMainInfoDO.setId(Long.parseLong(systemAuditParamDTO.getApplyMainId()));
		jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION, JsonUtils.toJSON(systemAuditParamDTO));
		otherPlatformRelevantService.addCheatInterfaceLog(cheatInterfaceLogDO);
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
		/**修改图片为不可修改*/
		this.fileService.updateFileState(applyId,user.getId(),new ArrayList<String>(){{add(FileNameConstant.A0);}{add(FileNameConstant.B0);}{add(FileNameConstant.C0);}{add(FileNameConstant.D0);}{add(FileNameConstant.E0);}{add(FileNameConstant.G0);}{add(FileNameConstant.H0);}{add(FileNameConstant.I0);}{add(FileNameConstant.J0);}{add(FileNameConstant.F0);}{add(FileNameConstant.L0);}{add(FileNameConstant.L0);}{add(FileNameConstant.K0);}});
		RestResponse pushFkCreditReport = pushFkCreditReport(applyId);
		if (pushFkCreditReport.getResult() != 0) {
			return pushFkCreditReport;
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse onSubmint(Long applyId,Long projectCode) throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		if (applyId != null) {
			Map<String, Object> paraMap = new HashMap<>();
			paraMap.put("applyId", applyId);
			ApplyBillMainInfoDO mainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paraMap);
			if (mainInfoDO == null) {
				return new RestResponse(1, "系统异常，请联系管理员");
			} else {
				// -- 修改专案码
				ApplyBillMainInfoDO billMainInfoDO = new ApplyBillMainInfoDO();
				billMainInfoDO.setProjectCode(projectCode);
				billMainInfoDO.setModifyUser(user.getId());
				billMainInfoDO.setId(mainInfoDO.getId());
				//-- 修改历史备注
				String serviceRemark = applyBillInfoDao.getServiceRemark(applyId);
				if (StringUtils.isNotNullAndEmpty(serviceRemark)) {
					ApplyOtherdataRemarkDTO applyOtherdataRemarkDTO = new ApplyOtherdataRemarkDTO();
					applyOtherdataRemarkDTO.setApplyId(applyId);
					applyOtherdataRemarkDTO.setRemark(serviceRemark);
					applyOtherdataRemarkDTO.setCreateUser(user.getId());
					this.applyBillInfoDao.addHistoryRemark(applyOtherdataRemarkDTO);//修改历史备注
					this.applyBillInfoDao.updateServiceRemark(applyId);//修改申请表中的备注为NULL
				}
				applyBillInfoDao.updateMainInfoProjectCode(billMainInfoDO);
				/**根据风控数据校验工作信息是否完整**/
				RestResponse checkAuditJob = checkAuditJob(applyId);
				if (checkAuditJob.getResult() != 0) {
					return checkAuditJob;
				}
				/**根据风控数据校验校验房产证明信息是否完整**/
				RestResponse checkOtherHouse = checkOtherHouse(applyId);
				if (checkOtherHouse.getResult() != 0) {
					return checkOtherHouse;
				}
				/**根据风控数据校验保单第一条数据是否完整**/
				RestResponse checkAuditInsurance = checkAuditInsurance(applyId);
				if (checkAuditInsurance.getResult() != 0) {
					return checkAuditInsurance;
				}
				/**根据风控数据校验通话详单信息是否完整**/
				RestResponse checkAuditPhone = checkAuditPhone(applyId);
				if (checkAuditPhone.getResult() != 0) {
					return checkAuditPhone;
				}
				/**推风控三方手填报告数据**/
				RestResponse pushFkCreditReport = pushFkCreditReport(applyId);
				if (pushFkCreditReport.getResult() != 0) {
					return pushFkCreditReport;
				}
				if (NodeStateConstant.MATERIAL_SUPPLEMENT.equals(mainInfoDO.getState())) {
					/**获取调用风控数据*/
					SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(mainInfoDO.getId(), NodeStateConstant.MATERIAL_SUPPLEMENT);
					systemAuditParamDTO.setSubmitUser(user.getName());
					systemAuditParamDTO.setSynOrAsy("asynchronous");
					/**调用风控系统系统审核日志*/
					CheatInterfaceLogDO cheatInterfaceLogDO = new CheatInterfaceLogDO();
					cheatInterfaceLogDO.setApplyMainId(Long.valueOf(systemAuditParamDTO.getApplyMainId()));
					cheatInterfaceLogDO.setInterfaceFlag("1");
					cheatInterfaceLogDO.setRequestJson(JsonUtils.toJSON(systemAuditParamDTO));
					cheatInterfaceLogDO.setSubmitNode(String.valueOf(NodeStateConstant.MATERIAL_SUPPLEMENT));
					cheatInterfaceLogDO.setSubmitUser(user.getId());
					cheatInterfaceLogDO.setCreateUser(user.getId());
					/**修改主表并添加主表修改日志**/
					MainLogDTO mainLogDTO = new MainLogDTO();
					mainLogDTO.setModifyUser(user.getId());
					mainLogDTO.setModifyUserName(user.getName());
					mainLogDTO.setBusinessState(NodeStateConstant.PENDING_SYSTEM_AUDIT);
					mainLogDTO.setBusinessStateName("系统审核中");
					mainLogDTO.setMainId(mainInfoDO.getId());
					ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
					applyBillMainInfoDO.setState(NodeStateConstant.PENDING_SYSTEM_AUDIT);
					applyBillMainInfoDO.setModifyUser(user.getId());
					applyBillMainInfoDO.setId(mainInfoDO.getId());
					jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION, JsonUtils.toJSON(systemAuditParamDTO));
					this.currencyDao.addMainLog(mainLogDTO);
					this.currencyDao.updateMainInFo(applyBillMainInfoDO);
					otherPlatformRelevantService.addCheatInterfaceLog(cheatInterfaceLogDO);
					try {
						/**修改图片为不可修改*/
						this.fileService.updateFileState(applyId,user.getId(),new ArrayList<String>(){{add(FileNameConstant.A0);}{add(FileNameConstant.B0);}{add(FileNameConstant.C0);}{add(FileNameConstant.D0);}{add(FileNameConstant.E0);}{add(FileNameConstant.G0);}{add(FileNameConstant.H0);}{add(FileNameConstant.I0);}{add(FileNameConstant.J0);}{add(FileNameConstant.F0);}{add(FileNameConstant.L0);}{add(FileNameConstant.L0);}{add(FileNameConstant.K0);}});
						/**查询结清证明图片**/
						String imkey = RedisConstant.IMAGE_APPLY + applyId +"_I0_*";
						Set<String> keys = RedisUtil.keys(imkey);
						if (keys.size()>0) {
							otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.SETTLE);
						}else{
							Map<String, Object> imageMap =new HashMap<String, Object>();
							imageMap.put("fileClassificationId",9);
							imageMap.put("applyId", applyId);
							int fileIsExit = this.fileDataInfoDao.fileIsExit(imageMap);
							if (fileIsExit > 0) {
								otherPlatformRelevantService.insertCheckItem(applyId, AuditCheckItemConstant.SETTLE);
							}
						}
						return new RestResponse(MsgErrCode.SUCCESS);
					} catch (Exception e) {
						e.printStackTrace();
						log.info("调用信审更新审核时效接口异常");
						TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
						return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
					}
				} else {
					return new RestResponse(1, "请刷新后重试");
				}
			}
		} else {
			return new RestResponse(1, "申请单ID不能为空");
		}
	}

	/**
	 * 推送三方手填报告信息 
	 * @author ZhangYu
	 * @param applyId
	 * @return
	 */
	private RestResponse pushFkCreditReport(Long applyId){
		/**推风控手填报告*/
		/**推风控运营商报告次数数据*/
		ApplyPersonTationQueryDO queryPersonTationQueryDo = this.auditRiskCreditReportDao.queryPersonTationQueryDo(applyId);
		if(queryPersonTationQueryDo != null){
			if (queryPersonTationQueryDo.getQueryQty() > 0) {
				SuanhuaManualReport suanhuaManualReport = new SuanhuaManualReport();
				AuditOtherHouseDO auditOtherHouseDO = this.auditOtherHouseDao.queryInfoByApplyId(applyId);
				if (auditOtherHouseDO != null) {
					if (auditOtherHouseDO.getMonthRepayAmount() != null) {
						suanhuaManualReport.setLoanBalancesMortgageMonth(auditOtherHouseDO.getMonthRepayAmount());
					}
				}
				suanhuaManualReport.setApplyId(String.valueOf(applyId));
				suanhuaManualReport.setSysId("gd");
				suanhuaManualReport.setSelfQueriesM3(queryPersonTationQueryDo.getQueryQty());
				try {
					this.suanhuaService.SuanhuaManualReportInterface(suanhuaManualReport);
				}catch (Exception e){
					e.printStackTrace();
					log.info("调用风控推送手填报告次数异常");
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
					return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
				}
			}
		}
		/**推风控公积金手填报告&&社保手填报告*/
		AuditJobDO auditJobDO = this.auditJobInfoDao.queryAuditJobInfoByApplyId(applyId);
		if (auditJobDO != null) {
			Rong360ManualReport gjjRong360ManualReport = new Rong360ManualReport();
			gjjRong360ManualReport.setApplyId(String.valueOf(applyId));
			gjjRong360ManualReport.setInsureMonthMoney(auditJobDO.getCpfMonth() == null?null:auditJobDO.getCpfMonth().doubleValue());
			gjjRong360ManualReport.setComName(auditJobDO.getCpfComp());
			gjjRong360ManualReport.setBaseRmb(auditJobDO.getCpfBase() == null?null:auditJobDO.getCpfBase().doubleValue());
			gjjRong360ManualReport.setComNameTime(auditJobDO.getCpfDuration());
			gjjRong360ManualReport.setSysId("gd");
			if (auditJobDO.getCpfLately() != null) {
				gjjRong360ManualReport.setStartDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(auditJobDO.getCpfLately()));
			}
			Rong360ManualReport shebaoRong360ManualReport = new Rong360ManualReport();
			shebaoRong360ManualReport.setApplyId(String.valueOf(applyId));
			shebaoRong360ManualReport.setInsureMonthMoney(auditJobDO.getJinpoMonth() == null?null:auditJobDO.getJinpoMonth().doubleValue());
			shebaoRong360ManualReport.setComName(auditJobDO.getJinpoComp());
			shebaoRong360ManualReport.setBaseRmb(auditJobDO.getJinpoBase() == null?null:auditJobDO.getJinpoBase().doubleValue());
			shebaoRong360ManualReport.setComNameTime(auditJobDO.getJinpoDuration());
			shebaoRong360ManualReport.setSysId("gd");
			if (auditJobDO.getJinpoLately() != null) {
				shebaoRong360ManualReport.setStartDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(auditJobDO.getJinpoLately()));
			}
			try {
				this.rong360Service.rong360GjjManualReportInterface(gjjRong360ManualReport);
				this.rong360Service.rong360ShebaoManualReportInterface(shebaoRong360ManualReport);
			}catch (Exception e){
				e.printStackTrace();
				log.info("调用风控手填报告异常");
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			}
		}
		/**推风控通话详单*/
		AuditDetailPhoneDO auditDetailPhoneDO = this.auditPhoneDetailDao.queryPhoneSpecifiInfoByApplyId(applyId);
		if (auditDetailPhoneDO != null) {
			JuXinLiSDReport juXinLiSDReport = new JuXinLiSDReport();
			juXinLiSDReport.setApplyId(String.valueOf(applyId));
			if (auditDetailPhoneDO.getRealAuth() != null) {
				if (SysDictEnum.REAL_AUTH_NAME_ONE.getCode().equals(auditDetailPhoneDO.getRealAuth())) {
					juXinLiSDReport.setReliability(SysDictEnum.REAL_AUTH_NAME_ONE.getName());
				}
				if (SysDictEnum.REAL_AUTH_NAME_TWO.getCode().equals(auditDetailPhoneDO.getRealAuth())) {
					juXinLiSDReport.setReliability(SysDictEnum.REAL_AUTH_NAME_TWO.getName());
				}
				if (SysDictEnum.REAL_AUTH_NAME_THREE.getCode().equals(auditDetailPhoneDO.getRealAuth())) {
					juXinLiSDReport.setReliability(SysDictEnum.REAL_AUTH_NAME_THREE.getName());
				}
			}
			if (auditDetailPhoneDO.getOpenDate() != null) {
				juXinLiSDReport.setRegTime(auditDetailPhoneDO.getOpenDate());
			}
			this.juXinLiService.addOrUpdateJuXinLiSDReport(juXinLiSDReport);
		}
		/**推风控保单证明**/
		JuXinLiBaoDanSDReport juXinLiBaoDanSDReport = new JuXinLiBaoDanSDReport();
		juXinLiBaoDanSDReport.setApplyId(String.valueOf(applyId));
		juXinLiBaoDanSDReport.setSysId("gd");
		List<AuditInsuranceDO> auditInsuranceDOs = this.auditInsuranceDao.queryAuditInsuranceListByApplyId(applyId);
		List<JuXinLiBaoDanSDReportDetail> juXinLiBaoDanSDReportDetailList = new ArrayList<JuXinLiBaoDanSDReportDetail>();
		if (auditInsuranceDOs != null && auditInsuranceDOs.size() >0 ) {
			for (AuditInsuranceDO auditInsuranceDO : auditInsuranceDOs) {
				JuXinLiBaoDanSDReportDetail juXinLiBaoDanSDReportDetail = new JuXinLiBaoDanSDReportDetail();
				juXinLiBaoDanSDReportDetail.setApplicantName(auditInsuranceDO.getInsureManName());
				juXinLiBaoDanSDReportDetail.setInsurantName(auditInsuranceDO.getPassiveInsureManName());
				juXinLiBaoDanSDReportDetail.setCompany(auditInsuranceDO.getInsuranceName());
				juXinLiBaoDanSDReportDetail.setPaymentPolicyStartDate(auditInsuranceDO.getEffectiveDate());
				juXinLiBaoDanSDReportDetail.setPaymentYear(auditInsuranceDO.getPaymentYearAmount() == null?null:auditInsuranceDO.getPaymentYearAmount().floatValue());
				if (SysDictEnum.PAY_MENT_TYPE_MONTH.getCode().equals(auditInsuranceDO.getPaymentType())) {
					juXinLiBaoDanSDReportDetail.setPaymentFrequency(SysDictEnum.PAY_MENT_TYPE_MONTH.getName());
				}
				if (SysDictEnum.PAY_MENT_TYPE_JIDU.getCode().equals(auditInsuranceDO.getPaymentType())) {
					juXinLiBaoDanSDReportDetail.setPaymentFrequency(SysDictEnum.PAY_MENT_TYPE_JIDU.getName());
				}
				if (SysDictEnum.PAY_MENT_TYPE_BYEAE.getCode().equals(auditInsuranceDO.getPaymentType())) {
					juXinLiBaoDanSDReportDetail.setPaymentFrequency(SysDictEnum.PAY_MENT_TYPE_BYEAE.getName());
				}
				if (SysDictEnum.PAY_MENT_TYPE_YEAR.getCode().equals(auditInsuranceDO.getPaymentType())) {
					juXinLiBaoDanSDReportDetail.setPaymentFrequency(SysDictEnum.PAY_MENT_TYPE_YEAR.getName());
				}
				juXinLiBaoDanSDReportDetailList.add(juXinLiBaoDanSDReportDetail);
			}
			juXinLiBaoDanSDReport.setJuXinLiBaoDanSDReportDetailList(juXinLiBaoDanSDReportDetailList);
			this.juXinLiBaoDanService.addOrUpdateJuXinLiBaoDanSDReport(juXinLiBaoDanSDReport);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 * @description 插入未过审页面
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/28 下午9:06
	 * @Version     1.0
	 * @param applyId 申请单ID
	 */
	private void insertCheckItem(Long applyId){
		int contractCount = applyBillInfoDao.getContractCount(applyId);
		int clearProofCount = applyBillInfoDao.getClearProofCount(applyId);
		if (clearProofCount > 0){
			otherPlatformRelevantService.insertCheckItem(applyId,AuditCheckItemConstant.CONTRACT_LOG_INFO);
		}
		if (contractCount > 0){
			otherPlatformRelevantService.insertCheckItem(applyId,AuditCheckItemConstant.SETTLE);
		}
		/**其他材料上传图片插入其他材料未过审页面*/
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("applyId", applyId);
		paramMap.put("fileClassificationId",10);
		int gsCount = this.fileDataInfoDao.fileIsExit(paramMap);
		paramMap.put("fileClassificationId",13);
		int otherCount = this.fileDataInfoDao.fileIsExit(paramMap);
		if (otherCount > 0 || gsCount > 0) {
			otherPlatformRelevantService.insertCheckItem(applyId,AuditCheckItemConstant.OTHER);
		}
	}

	/**
	 * 校验工作信息是否完整 
	 * @author ZhangYu
	 * @return
	 */
	private RestResponse checkAuditJob(Long applyId){
		AuditJobDO auditJobDO = this.auditJobInfoDao.queryAuditJobInfoByApplyId(applyId);
		if (auditJobDO == null) {
			auditJobDO = new AuditJobDO();
		}
		/***查询荣360社保是否比附**/
		Map<String, Object> paraSbMap = new HashMap<>();
		paraSbMap.put("applyId", applyId);
		paraSbMap.put("authorizationType", SysDictEnum.TIANJI_SOCIAL_SECURITY.getCode());
		AuthorizationProductDO authorizationProductSbDO = this.authorizationDao.queryAuthorizationType(paraSbMap); 
		/**查询荣360公积金是否比附**/
		Map<String, Object> paraGjjMap = new HashMap<>();
		paraGjjMap.put("applyId", applyId);
		paraGjjMap.put("authorizationType", SysDictEnum.TIANJI_ACCUMULATION_FUND.getCode());
		AuthorizationProductDO authorizationProductGjjDO = this.authorizationDao.queryAuthorizationType(paraGjjMap); 
		/**获取荣360社保对象**/
		ShebaoReport shebaoReport = null;
		try {
			shebaoReport = this.foreignService.shebaoReportOfOrder(String.valueOf(applyId), "gd");
		} catch (Exception e) {
			 e.printStackTrace();
			 log.info("获取社保数据报错");
	         throw new RuntimeException("---获取社保数据报错----");
		}
		BigDecimal cpfBase = auditJobDO.getCpfBase();
		BigDecimal cpfMonth = auditJobDO.getCpfMonth();
		Date cpfLately = auditJobDO.getCpfLately();
		Integer cpfDuration = auditJobDO.getCpfDuration();
		BigDecimal jinpoBase = auditJobDO.getJinpoBase();
		BigDecimal jinpoMonth = auditJobDO.getJinpoMonth();
		Date jinpoLately = auditJobDO.getJinpoLately();
		Integer jinpoDuration = auditJobDO.getJinpoDuration();
		String jinpoComp = auditJobDO.getJinpoComp();
		String cpfComp = auditJobDO.getCpfComp();
		/**社保报告比附**/
		if (SysDictEnum.YES.getCode().equals(authorizationProductSbDO.getIsAdditional())) {
			if (shebaoReport == null) {//获取报告为空
				if (jinpoBase == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_BASE);
				}
				if(jinpoMonth == null){
					return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_MONTH);
				}
				if (jinpoLately == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_LATELY);
				}
				if (jinpoDuration == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_DURATION);
				}
				if (StringUtils.isNullOrEmpty(jinpoComp)) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_JINPOCOMPANY);
				}
			}else{//不为空判断其中字段
				List<Rong360ShebaoPayModel> shebaoPayList = shebaoReport.getShebaoPayList();
				Rong360ShebaoBaseInfoModel shebaoBaseInfo = shebaoReport.getShebaoBaseInfo();
				if (shebaoPayList == null && shebaoBaseInfo == null ) {
					if (jinpoBase == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_BASE);
					}
					if(jinpoMonth == null){
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_MONTH);
					}
					if (jinpoLately == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_LATELY);
					}
					if (jinpoDuration == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_DURATION);
					}
					if (StringUtils.isNullOrEmpty(jinpoComp)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPOCOMPANY);
					}
				}
				/**社保报告,缴费基数字段为空 **/
				if (shebaoPayList != null && shebaoPayList.size() >0) {
					Rong360ShebaoPayModel rong360ShebaoPayModel = shebaoPayList.get(0);
					if (StringUtils.isNullOrEmpty(rong360ShebaoPayModel.getBase_rmb()) && jinpoBase == null ){
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_BASE);
					}
				}else{
					if (jinpoBase == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_BASE);
					}
				}
				/**社保报告,社保月申报人民币字段为空**/
				if (shebaoBaseInfo != null) {
					if (StringUtils.isNullOrEmpty(shebaoBaseInfo.getInsure_month_money()) && jinpoMonth == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_MONTH);
					}
				}else{
					if (jinpoMonth == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_JINPO_MONTH);
					}
				}
			}
		}
		/**获取荣360公积金对象**/
		GjjReport gjjReport = null; 
		try {
			gjjReport = this.foreignService.gjjReportOfOrder(String.valueOf(applyId), "gd");
		} catch (Exception e) {
			 e.printStackTrace();
			 log.info("获取公积金数据报错");
	         throw new RuntimeException("---获取公积金数据报错----");
		}
		/**公积金报告必附**/
		if (SysDictEnum.YES.getCode().equals(authorizationProductGjjDO.getIsAdditional())) {
			if (gjjReport == null) {//获取报告为空
				if (cpfBase == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_BASE);
				}
				if (cpfMonth == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_MONTH);
				}
				if (cpfLately == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_LATELY);
				}
				if (cpfDuration == null) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_DURATION);
				}
				if (StringUtils.isNullOrEmpty(cpfComp)) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_CPFCOMPANY);
				}
			}else{//报告不为空判断其中字段
				Rong360GjjBaseInfoModel gjjBaseInfo = gjjReport.getGjjBaseInfo();
				List<Rong360GjjPayModel> gjjPayList = gjjReport.getGjjPayList();
				if (gjjBaseInfo == null && gjjPayList == null) {
					if (cpfBase == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_BASE);
					}
					if (cpfMonth == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_MONTH);
					}
					if (cpfLately == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_LATELY);
					}
					if (cpfDuration == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_DURATION);
					}
					if (StringUtils.isNullOrEmpty(cpfComp)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPFCOMPANY);
					}
				}
				if (gjjPayList != null && gjjPayList.size() > 0) {
					Rong360GjjPayModel rong360GjjPayModel = gjjPayList.get(0);
					/**公积金报告,缴费基数字段为空**/
					if (StringUtils.isNullOrEmpty(rong360GjjPayModel.getBase_rmb()) && 
							StringUtils.isNullOrEmpty(gjjBaseInfo.getFund_base_money()) && cpfBase == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_BASE);
					}
				}else{
					if (cpfBase == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_BASE);
					}
				}
				if (gjjBaseInfo != null) {
					/**公积金报告,公积金月申报人民币字段为空**/
					if (StringUtils.isNullOrEmpty(gjjBaseInfo.getFund_month_money()) && cpfMonth == null ) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_MONTH);
					}
				}else{
					if (cpfMonth == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_CPF_MONTH);
					}
				}
			}
		}
		/**修改社保公积金记录**/
		if (jinpoBase != null) {
			auditJobInfoDao.updateJinPoRecord(applyId);
		}
		if (cpfBase != null) {
			auditJobInfoDao.updateCpfRecord(applyId);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 * 校验房产信息是否完整 
	 * @author ZhangYu
	 * @param applyId
	 * @return
	 */
	private RestResponse checkOtherHouse(Long applyId){
		Long expectProductId = this.applyBillInfoDao.getExpectProductId(applyId);
		if (expectProductId != null) {
			if (expectProductId == 94) {
				AuditOtherHouseDO auditOtherHouseDO = this.auditOtherHouseDao.queryInfoByApplyId(applyId);
				if (auditOtherHouseDO != null) {
					String houseHost = auditOtherHouseDO.getHouseHost();//所有权人
					Long houseShare = auditOtherHouseDO.getHouseShare();//公用情况
					Date purchaseDate = auditOtherHouseDO.getPurchaseDate();//购买时间
					Long houseAddressProvince = auditOtherHouseDO.getHouseAddressProvince();//房屋所在省
					Long houseAddressCity = auditOtherHouseDO.getHouseAddressCity();//房屋所在市
					Long houseAddressArea = auditOtherHouseDO.getHouseAddressArea();//房屋所在区
					String houseAddress = auditOtherHouseDO.getHouseAddress();//房屋所在详细地址
					String houseArea = auditOtherHouseDO.getHouseArea();//建筑面积
					String housePurpose = auditOtherHouseDO.getHousePurpose();//规划用途
					Long mortgageExplain = auditOtherHouseDO.getMortgageExplain();//抵押情况
					String mortgagor = auditOtherHouseDO.getMortgagor();//抵押权人
					Double mortgageAmount = auditOtherHouseDO.getMortgageAmount();//抵押金额
					Double monthRepayAmount = auditOtherHouseDO.getMonthRepayAmount();//月还款金额
					if (StringUtils.isNullOrEmpty(houseHost)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEHOST);
					}
					if (houseShare == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSESHARE);
					}
					if (purchaseDate == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_PURCHASEDATE);
					}
					if (houseAddressProvince == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEADDRESSPROVINCE);
					}
					if (houseAddressCity == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEADDRESSCITY);
					}
					if (houseAddressArea == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEADDRESSAREA);
					}
					if (StringUtils.isNullOrEmpty(houseAddress)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEADDRESS);
					}
					if (StringUtils.isNullOrEmpty(houseArea)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEAREA);
					}
					if (StringUtils.isNullOrEmpty(housePurpose)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_HOUSEPURPOSE);
					}
					if (mortgageExplain == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_MORTGAGEEXPLAIN);
					}else{
						//如果不是无抵押/已解压  抵押权人抵押金额必填
						if (!SysDictEnum.MORTGAGE_EXPLAIN_NO.getCode().equals(mortgageExplain)) {
							if (StringUtils.isNullOrEmpty(mortgagor)) {
								return new RestResponse(NativeMsgErrCode.NO_NULL_MORTGAGOR);
							}
							if (mortgageAmount == null) {
								return new RestResponse(NativeMsgErrCode.NO_NULL_MORTGAGEAMOUNT);
							}
						}
					}
					/**获取简版人行报告**/
	                OrderSuanhuaInfo orderSuanhuaInfo = null;
					try {
						orderSuanhuaInfo = this.foreignService.getOrderSuanhuaInfo(String.valueOf(applyId));
					} catch (Exception e) {
						e.printStackTrace();
						log.info("获取简版人行报告报错");
						throw new RuntimeException("---获取简版人行报告报错----");
					}
					if (orderSuanhuaInfo == null) {
						if (monthRepayAmount == null) {
							return new RestResponse(NativeMsgErrCode.NO_NULL_MONTHREPAYAMOUNT);
						}
					}else{
						Double loanBalancesMortgageMonth = orderSuanhuaInfo.getLoanBalancesMortgageMonth();
						if (loanBalancesMortgageMonth == null && monthRepayAmount == null) {
							return new RestResponse(NativeMsgErrCode.NO_NULL_MONTHREPAYAMOUNT);
						}
					}
				}else{
					return new RestResponse(NativeMsgErrCode.NO_NULL_OTHERHOUSE);
				}
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	
	/**
	 * 校验保单证明信息完整 
	 * @param applyId
	 * @return
	 */
	private RestResponse checkAuditInsurance(Long applyId){
		Map<String, Object> paraGjjMap = new HashMap<>();
		paraGjjMap.put("applyId", applyId);
		paraGjjMap.put("authorizationType", SysDictEnum.JUXINLI_POLICY_REPORT.getCode());
		AuthorizationProductDO authorizationProductDO = this.authorizationDao.queryAuthorizationType(paraGjjMap); 
		/**保单证明比附*/
		if (SysDictEnum.YES.getCode().equals(authorizationProductDO.getIsAdditional())) {
			List<AuditInsuranceDO> auditInsuranceDOs = this.auditInsuranceDao.queryAuditInsuranceListByApplyId(applyId);
			if (auditInsuranceDOs != null && auditInsuranceDOs.size() > 0) {
				AuditInsuranceDO auditInsuranceDO = auditInsuranceDOs.get(0);
				if (auditInsuranceDO != null) {
					String insuranceManName = auditInsuranceDO.getInsureManName(); 
					if (StringUtils.isNullOrEmpty(insuranceManName)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_INSURANCEMANNAME);//投保人姓名不能为空
					}
					String passiveInsureManName = auditInsuranceDO.getPassiveInsureManName();
					if (StringUtils.isNullOrEmpty(passiveInsureManName)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_PASSIVEINSUREMANNAME);//被保人姓名不能为空
					}
					String insuranceName = auditInsuranceDO.getInsuranceName();
					if (StringUtils.isNullOrEmpty(insuranceName)) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_INSURANCENAME);//投保公司名称不能为空
					}
					Date effectiveDate = auditInsuranceDO.getEffectiveDate();
					if (effectiveDate == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_EFFECTIVEDATE);//保险生效日期不能为空
					}
					Long paymentType = auditInsuranceDO.getPaymentType();
					if (paymentType == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_PAYMENTTYPE);//缴费频率不能为空
					}
					BigDecimal paymentYearAmount = auditInsuranceDO.getPaymentYearAmount();
					if (paymentYearAmount == null) {
						return new RestResponse(NativeMsgErrCode.NO_NULL_PAYMENTYEARAMOUNT);//年交保费不能为空
					}
				}
			}else{
				return new RestResponse(NativeMsgErrCode.NO_NULL_INSURANCE);//保单信息不能为空
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	
	/**
	 * 校验通话详单信息完整 
	 * @author ZhangYu      
	 * @param applyId
	 * @return
	 */
	private RestResponse checkAuditPhone(Long applyId){
		Map<String, Object> paraGjjMap = new HashMap<>();
		paraGjjMap.put("applyId", applyId);
		paraGjjMap.put("authorizationType", SysDictEnum.JUXINLI_OPERATOR.getCode());
		AuthorizationProductDO authorizationProductDO = this.authorizationDao.queryAuthorizationType(paraGjjMap); 
		/**查询通话详单信息*/
		AuditDetailPhoneDO auditDetailPhoneDO = this.auditPhoneDetailDao.queryPhoneSpecifiInfoByApplyId(applyId);
        Date openDate = null;
        Long realAuth = null;
		if (auditDetailPhoneDO != null) {
			openDate = auditDetailPhoneDO.getOpenDate();
			realAuth = auditDetailPhoneDO.getRealAuth();
		}
		if (SysDictEnum.YES.getCode().equals(authorizationProductDO.getIsAdditional())) {
			/**获取三方实名认证和开户日期字段**/
			Map<String, Object> map = this.juXinLiService.getReliabilityAndRegTimeForJJ(String.valueOf(applyId));
			String reliability = null;
			String regTime = null ;
			if (map != null && map.containsKey("reliability")){
				reliability = (String)map.get("reliability");
			}
			if (map != null && map.containsKey("reg_time")){
				regTime = (String)map.get("reg_time");
			}
			if (StringUtils.isNullOrEmpty(reliability) && realAuth == null) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_RELIABILITY);//实名认证不能为空
			}
			if (StringUtils.isNullOrEmpty(regTime) && openDate == null) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_REGTIME);//开户日期不能为空
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 *  校验图片信息 
	 * @author ZhangYu
	 * @param applyBillinfoAllSaveCheckJobDTO
	 * @return
	 */
	private RestResponse checkImageInfo(ApplyBillinfoAllSaveCheckJobDTO applyBillinfoAllSaveCheckJobDTO){
		ApplyBillInfoDTO applyBillInfoDTO = applyBillinfoAllSaveCheckJobDTO.getApplyBillInfoDTO();
		Long applyId = applyBillInfoDTO.getId();
		Long expectProductId = applyBillInfoDTO.getExpectProductId();
		/**校验身份证明图片不能为空*/
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("applyId", applyId);
		paramMap.put("fileClassificationId",1);
		com.xyb.order.app.client.cuser.model.ApplyClientInfoDO applyClientFileInfo = this.fileDataInfoDao.getApplyClientFileInfo(applyId); 
		if (applyClientFileInfo != null) {
			if (StringUtils.isNullOrEmpty(applyClientFileInfo.getFrontFileKey()) && StringUtils.isNullOrEmpty(applyClientFileInfo.getBackFileKey()) ) {
				int personCount = this.fileDataInfoDao.fileIsExit(paramMap);
				if (personCount == 0) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_PERSON);
				}
			}
		}else{
			int personCount = this.fileDataInfoDao.fileIsExit(paramMap);
			if (personCount == 0) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_PERSON);
			}
		}
		/**校验自我推荐图片不能为空*/
		paramMap.put("fileClassificationId",44);
		int mineCount = this.fileDataInfoDao.fileIsExit(paramMap);
		if (mineCount == 0) {
			return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_MINE);
		}
		/**如果产品是公务贷*/
		if (expectProductId == 91 || expectProductId == 92 || expectProductId == 451) {
			ShebaoReport shebaoReport = null;
			try {
				shebaoReport = this.foreignService.shebaoReportOfOrder(String.valueOf(applyId), "gd");
			} catch (Exception e) {
				 e.printStackTrace();
				 log.info("获取社保数据报错");
		         throw new RuntimeException("---获取社保数据报错----");
			}
			/**获取荣360公积金对象**/
			GjjReport gjjReport = null; 
			try {
				gjjReport = this.foreignService.gjjReportOfOrder(String.valueOf(applyId), "gd");
			} catch (Exception e) {
				 e.printStackTrace();
				 log.info("获取公积金数据报错");
		         throw new RuntimeException("---获取公积金数据报错----");
			}
			//如果社保和公积金都没有必须上传工作证明图片
			if (shebaoReport == null && gjjReport == null) {
				paramMap.put("fileClassificationId",2);
				int workCount = this.fileDataInfoDao.fileIsExit(paramMap);
				if (workCount == 0) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_WORK);
				}
			}
		}
		/**如果产品是社保贷*/
		if (expectProductId == 95) {
			ShebaoReport shebaoReport = null;
			try {
				shebaoReport = this.foreignService.shebaoReportOfOrder(String.valueOf(applyId), "gd");
			} catch (Exception e) {
				e.printStackTrace();
				log.info("获取社保数据报错");
				throw new RuntimeException("---获取社保数据报错----");
			}
			//如果社保数据为空
			if (shebaoReport == null) {
				paramMap.put("fileClassificationId",2);
				int workCount = this.fileDataInfoDao.fileIsExit(paramMap);
				if (workCount == 0) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_WORK);
				}
			}
		}
		/**如果产品是公积金贷*/
		if (expectProductId == 93) {
			/**获取荣360公积金对象**/
			GjjReport gjjReport = null; 
			try {
				gjjReport = this.foreignService.gjjReportOfOrder(String.valueOf(applyId), "gd");
			} catch (Exception e) {
				 e.printStackTrace();
				 log.info("获取公积金数据报错");
		         throw new RuntimeException("---获取公积金数据报错----");
			}
			//如果公积金数据为空
			if (gjjReport == null) {
				paramMap.put("fileClassificationId",2);
				int workCount = this.fileDataInfoDao.fileIsExit(paramMap);
				if (workCount == 0) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_WORK);
				}
			}
		}
		/**如果产品是宅易贷*/
		if (expectProductId == 94) {
			paramMap.put("fileClassificationId",7);
			int houseCount = this.fileDataInfoDao.fileIsExit(paramMap);
			if (houseCount == 0) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_HOUSE); 
			}
		}
		/**获取通话详单*/
		JuXinLiApplicationCheckInData juXinLiApplicationCheckInData = new JuXinLiApplicationCheckInData();
		juXinLiApplicationCheckInData.setApplyId(String.valueOf(applyId));
		juXinLiApplicationCheckInData.setSysId("gd");
		List<JuXinLiApplicationCheckForOther> juXinLiApplicationCheckForGD = this.juXinLiService.getJuXinLiApplicationCheckForGD(juXinLiApplicationCheckInData);
		//如果三方通话详单为空
		if (juXinLiApplicationCheckForGD == null) {
			paramMap.put("fileClassificationId",8);
			int houseCount = this.fileDataInfoDao.fileIsExit(paramMap);
			if (houseCount == 0) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_PHONE);
			}
		}
		/**如果产品是信保贷*/
		if (expectProductId == 90) {
			HandleInterface handleInterface = new HandleInterface();
			handleInterface.setApplyId(String.valueOf(applyId));
			handleInterface.setSysId("gd");
			JuXinLiBaoDanReport juXinLiBaoDanReport = null;
			try {
				juXinLiBaoDanReport = this.juXinLiBaoDanService.getJxlbdReportForOther(handleInterface);
			} catch (Exception e) {
				e.printStackTrace();
				log.info("获取聚信立保单数据报错");
				throw new RuntimeException("---获取聚信立保单数据报错----");
			}
			if (juXinLiBaoDanReport == null) {
				paramMap.put("fileClassificationId",11);
				int houseCount = this.fileDataInfoDao.fileIsExit(paramMap);
				if (houseCount == 0) {
					return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_BDZM); 
				}
			}
		}
		/**如果产品是退休贷*/
		if (expectProductId == 96) {
			paramMap.put("fileClassificationId",12);
			int houseCount = this.fileDataInfoDao.fileIsExit(paramMap);
			if (houseCount == 0) {
				return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_TXZM); 
			}
		}
		/**所有产品比附,工商网和人法网截图必须上传*/
		paramMap.put("fileClassificationId",10);
		int gfCount = this.fileDataInfoDao.fileIsExit(paramMap);
		if (gfCount == 0) {
			return new RestResponse(NativeMsgErrCode.NO_NULL_IMAGE_GFWTP); 
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	
	
	
	public static void main(String[] args) {
		RedisUtil.setex("a","aaa");
	}
}
