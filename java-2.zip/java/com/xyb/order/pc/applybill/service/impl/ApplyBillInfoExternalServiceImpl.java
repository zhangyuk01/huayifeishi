package com.xyb.order.pc.applybill.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.dao.ApplyCommonProvinceDao;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoExternalDao;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDTO;
import com.xyb.order.pc.applybill.service.ApplyBillInfoExternalService;
import com.xyb.util.SessionUtil;


/**
 * @ClassName ApplyBillInfoExternalServiceImpl
 * @author ZhangYu
 * @date 2018年4月16号
 */

@Service(interfaceName = "com.xyb.order.pc.applybill.service.ApplyBillInfoExternalService")
public class ApplyBillInfoExternalServiceImpl implements ApplyBillInfoExternalService{

	@Autowired
	private ApplyBillInfoExternalDao applyBillInfoExternalDao; 
	@Autowired
	private ApplyCommonProvinceDao applyCommonProvinceDao;

	@Override
	public RestResponse saveApplyLinkManInfo(ApplyLinkmanInfoDTO applyLinkmanInfoDTO) {
		User user = SessionUtil.getLoginUser(User.class);
		applyLinkmanInfoDTO.setModifyUser(user.getId());
		applyLinkmanInfoDTO.setCreateUser(user.getId());
		String provinceLabel = "";
		String cityLabel = "";
		String areaLabel = "";
		String address = "";
		String allAdress = "";
		if (applyLinkmanInfoDTO.getProvince() != null) {
			provinceLabel = this.applyCommonProvinceDao.getProvinceLabelByProvinceId(applyLinkmanInfoDTO.getProvince());
		}
		if (applyLinkmanInfoDTO.getCity() != null) {
			cityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyLinkmanInfoDTO.getCity());
		}
		if (applyLinkmanInfoDTO.getArea() != null) {
			areaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyLinkmanInfoDTO.getArea());
		}
		if (applyLinkmanInfoDTO.getAddress() != null ) {
			address = applyLinkmanInfoDTO.getAddress();
		}
		allAdress = provinceLabel+cityLabel+areaLabel+address;
		applyLinkmanInfoDTO.setAllAddress(allAdress);
		this.applyBillInfoExternalDao.addLinkManInfo(applyLinkmanInfoDTO);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

}
