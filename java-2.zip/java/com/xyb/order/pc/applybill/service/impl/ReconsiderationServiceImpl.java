package com.xyb.order.pc.applybill.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.FileNameConstant;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.applybill.dao.ReconsiderationDao;
import com.xyb.order.pc.applybill.model.InsertReconsiderationDTO;
import com.xyb.order.pc.applybill.model.ReconsiderationInfoDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDTO;
import com.xyb.order.pc.applybill.service.ReconsiderationService;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 复议功能
 * @author         xieqingyang
 * @date           2018/10/17 2:28 PM
*/
@Service(interfaceName = "com.xyb.order.pc.applybill.service.ReconsiderationService")
public class ReconsiderationServiceImpl implements ReconsiderationService {

    @Autowired
    private ReconsiderationDao reconsiderationDao;
    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private FileDataInfoService fileService;

    @Override
    public RestResponse queryReconsiderationListPage(Integer pageNumber, Integer pageSize, ReconsiderationListDTO reconsiderationListDTO) throws Exception{
        reconsiderationListDTO.getPage().setPageSize(pageSize);
        reconsiderationListDTO.getPage().setPageNumber(pageNumber);
        User user = SessionUtil.getLoginUser(User.class);
        reconsiderationListDTO.setOrgId(user.getDataOrgId());
        reconsiderationListDTO.setState(NodeStateConstant.RECONSIDERATION_STATE_LIST);
        List<ReconsiderationListDO> reconsiderationListDOS = reconsiderationDao.queryReconsiderationListPage(reconsiderationListDTO);
        // -- 进行状态显示处理
        String stateName;
        for (ReconsiderationListDO reconsiderationListDO:reconsiderationListDOS) {
            stateName = NodeStateConstant.getNodeStateNameOfReconsideration(reconsiderationListDO.getStateCode());
            if (StringUtils.isNotNullAndEmpty(stateName)){
                reconsiderationListDO.setState(stateName);
            }
        }
        reconsiderationListDTO.getPage().setContents(reconsiderationListDOS);
        return new RestResponse(MsgErrCode.SUCCESS, reconsiderationListDTO.getPage());
    }

    @Override
    public RestResponse queryReconsiderationInfo(Long mainId) throws Exception{
        ReconsiderationInfoDO reconsiderationInfoDO = reconsiderationDao.queryReconsiderationInfo(mainId);
        if (reconsiderationInfoDO != null){
            if (NodeStateConstant.RECONSIDERATION_STATE_LIST.contains(reconsiderationInfoDO.getState()) && reconsiderationInfoDO.getReconsiderationQty() < CurrencyConstant.RECONSIDERATION_QTY){
                return new RestResponse(MsgErrCode.SUCCESS, reconsiderationInfoDO);
            }else {
                return new RestResponse(NativeMsgErrCode.NOT_SATISFIED_RECONSIDERATION);
            }
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse insertReconsider(InsertReconsiderationDTO insertReconsiderationDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        insertReconsiderationDTO.setModifyUser(user.getId());
        int count = reconsiderationDao.insertReconsider(insertReconsiderationDTO);
        if (count > 0){
            /**修改图片为不可修改*/
            fileService.updateFileState(insertReconsiderationDTO.getApplyId(),user.getId(), new ArrayList<String>(){{add(FileNameConstant.FYA1);}});
            updateMainInfo(user.getId(),user.getName(),insertReconsiderationDTO.getState(),insertReconsiderationDTO.getMainId());
            return new RestResponse(MsgErrCode.SUCCESS);
        }else {
            return new RestResponse(NativeMsgErrCode.ERROR);
        }
    }

    private void updateMainInfo(Long userId,String userName,int lastState,Long mainId){
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("mainId",mainId);
        paraMap.put("businessState",NodeStateConstant.REVIEW_AND_REVIEW);
        paraMap.put("businessStateName","复议审核中");
        paraMap.put("modifyUser",userId);
        paraMap.put("modifyUserName",userName);
        reconsiderationDao.updateReconsiderMain(paraMap);
        currencyDao.insertMainLog(paraMap);
    }
}
