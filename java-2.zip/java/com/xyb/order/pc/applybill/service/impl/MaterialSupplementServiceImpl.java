package com.xyb.order.pc.applybill.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.applybill.dao.*;
import com.xyb.order.pc.applybill.model.*;
import com.xyb.order.pc.applybill.service.MaterialSupplementService;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 材料补充接口实现
 * @author         xieqingyang
 * @date           2018/4/25 11:46 AM
*/
@Service(interfaceName = "com.xyb.order.pc.applybill.service.MaterialSupplementService")
public class MaterialSupplementServiceImpl implements MaterialSupplementService {

    private static final Logger log = LoggerFactory.getLogger(MaterialSupplementServiceImpl.class);

    @Autowired
    private MaterialSupplementDao materialSupplementDao;
    @Autowired
    private ApplyBillInfoDao applyBillInfoDao;
    @Autowired
    private ApplyClientInfoDao applyClientInfoDao;
    @Autowired
    private ApplyPersonInfoDao applyPersonInfoDao;
    @Autowired
    private ApplyPrivateInfoDao applyPrivateInfoDao;
    @Autowired
    private ApplyLinkmanInfoDao applyLinkmanInfoDao;
    @Autowired
    private ApplyJobInfoDao applyJobInfoDao;
    @Autowired
    private CurrencyDao currencyDao;
    @Reference
    private CreditCommonService commonService;

    @Override
    public RestResponse listMaterialSupplementPage(Integer pageNumber, Integer pageSize, MaterialSupplementListDTO materialSupplementListDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        materialSupplementListDTO.getPage().setPageNumber(pageNumber);
        materialSupplementListDTO.getPage().setPageSize(pageSize);
        materialSupplementListDTO.setServieUid(user.getId());
        materialSupplementListDTO.setState(NodeStateConstant.MATERIAL_SUPPLEMENT);
        List<MaterialSupplementListDO> materialSupplementListDOS = materialSupplementDao.listMaterialSupplementPage(materialSupplementListDTO);
        materialSupplementListDTO.getPage().setContents(materialSupplementListDOS);
        return new RestResponse(MsgErrCode.SUCCESS,materialSupplementListDTO.getPage());
    }

    @Override
    public RestResponse getMaterialSupplementInFo(Long mainId) throws Exception{
        if (mainId == null){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }else {
            MaterialSupplementVO materialSupplementVO = new MaterialSupplementVO();
            ApplyBillInfoDO applyBillInfoDO = this.applyBillInfoDao.queryBillInfoByMainId(mainId);	//申请单信息
            ApplyClientInfoDO applyClientInfoDO = this.applyClientInfoDao.queryClientInfoByMainId(mainId);//客户信息
            ApplyPersonInfoDO personInfoDO = this.applyPersonInfoDao.queryPersonInfoByMainId(mainId);//个人信息
            ApplyJobInfoDO jobInfoDO = this.applyJobInfoDao.queryJobInfoByMainId(mainId);//工作信息
            ApplyPrivateInfoDO privateInfoDO = this.applyPrivateInfoDao.queryPrivateInfoByMainId(mainId);//私营信息
            //工作联系人信息
            Map<String,Object> paraMap = new HashMap<String,Object>();
            paraMap.put("mainId", mainId);
            paraMap.put("type", SysDictEnum.FAMILY_PERSON_LINK.getCode());
            List<ApplyLinkmanInfoDO> homeLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
            //工作联系人信息
            paraMap.put("type", SysDictEnum.WORK_PERSON_LINK.getCode());
            List<ApplyLinkmanInfoDO> workLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
            //紧急联系人信息
            paraMap.put("type", SysDictEnum.QUICK_PERSON_LINK.getCode());
            List<ApplyLinkmanInfoDO> urgentLinkList = applyLinkmanInfoDao.queryLinkInfoListByMainIdAndType(paraMap);
            //家庭子女信息
            Map<String, Object> queryChildMap = new HashMap<>();
    		queryChildMap.put("applyId", applyBillInfoDO.getId());
    		queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
    		List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao.queryFamilyChildrenList(queryChildMap);
            // -- 需补充材料信息
            MaterialSupplementInfoDO materialSupplementInfoDO = materialSupplementDao.getMaterialSupplemgntInfo(mainId);
            //---查询历史备注
            List<ApplyOtherDataRemarkDO> applyOtherDataRemarkDOs = this.applyBillInfoDao.getHistoryRemarkByApplyId(applyBillInfoDO.getId());
            if (materialSupplementInfoDO != null) {
                // -- 查询补充材料类型
                List<String> materialTypeList = materialSupplementDao.queryMaterialType(materialSupplementInfoDO.getAuditReportId());
                if (materialTypeList != null && materialTypeList.size() > 0) {
                    materialSupplementInfoDO.setMaterialType(materialTypeList);
                }
                if (applyOtherDataRemarkDOs != null && applyOtherDataRemarkDOs.size() > 0) {
                	materialSupplementInfoDO.setApplyOtherDataRemarkDOs(applyOtherDataRemarkDOs);
                }
                materialSupplementVO.setMaterialSupplementInfoDO(materialSupplementInfoDO);
            }else{
            	if (applyOtherDataRemarkDOs != null && applyOtherDataRemarkDOs.size() > 0) {
            		materialSupplementInfoDO  = new MaterialSupplementInfoDO();
            		materialSupplementInfoDO.setApplyOtherDataRemarkDOs(applyOtherDataRemarkDOs);
            		materialSupplementVO.setMaterialSupplementInfoDO(materialSupplementInfoDO);
            	}
            }
            materialSupplementVO.setApplyBillInfoDo(applyBillInfoDO);
            materialSupplementVO.setApplyClientInfoDO(applyClientInfoDO);
            materialSupplementVO.setApplyPersonInfoDo(personInfoDO);
            materialSupplementVO.setApplyJobInfoDO(jobInfoDO);
            if(privateInfoDO != null) {
                materialSupplementVO.setApplyPrivateInfoDo(privateInfoDO);
            }
            materialSupplementVO.setHomeLinkList(homeLinkList);
            materialSupplementVO.setWorkLinkList(workLinkList);
            materialSupplementVO.setUrgentLinkList(urgentLinkList);
            materialSupplementVO.setFamilyChildrenList(applyFamilyChildrenDOs);
            return new RestResponse(MsgErrCode.SUCCESS,materialSupplementVO);
        }
    }
}
