package com.xyb.order.pc.applybill.dao;

import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDTO;

/**
 * @ClassName ApplyBillInfoExternalDao
 * @author ZhangYu
 * @date 2018年7月17号
 */
public interface ApplyBillInfoExternalDao {

	/**
	 * 添加联系信息 
	 * @param applyLinkmanInfoDTO
	 */
	void addLinkManInfo(ApplyLinkmanInfoDTO applyLinkmanInfoDTO);

}
