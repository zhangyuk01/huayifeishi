package com.xyb.order.pc.applybill.dao;

import java.util.Map;

import com.xyb.order.pc.applybill.model.ApplyPrivateInfoDO;

/**
 * @ClassName ApplyPrivateInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
public interface ApplyPrivateInfoDao {
	
	public ApplyPrivateInfoDO queryPrivateInfoByMainId(Long mainId);
	
	void add(Map<String, Object> map);

	void update(Map<String, Object> map);

}
