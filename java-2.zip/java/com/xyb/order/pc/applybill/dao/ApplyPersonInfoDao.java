package com.xyb.order.pc.applybill.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDO;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDTO;
import com.xyb.order.pc.applybill.model.ApplyPersonInfoDO;

/**
 * @ClassName ApplyPersonInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
public interface ApplyPersonInfoDao {

	ApplyPersonInfoDO queryPersonInfoByMainId(Long mainId);
	
	void add(Map<String, Object> map);

	void update(Map<String, Object> map);
	
	List<ApplyFamilyChildrenDO> queryFamilyChildrenList(Map<String,Object> paramMap);
	
	void updateFamilyChildrenList(@Param("familyList") List<ApplyFamilyChildrenDTO> familyList);
	
	void addFamilyChildrenList(@Param("familyList") List<ApplyFamilyChildrenDTO> familyList);

}
