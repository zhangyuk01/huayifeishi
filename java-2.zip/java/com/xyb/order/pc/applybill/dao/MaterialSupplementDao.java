package com.xyb.order.pc.applybill.dao;

import com.xyb.order.pc.applybill.model.MaterialSupplementInfoDO;
import com.xyb.order.pc.applybill.model.MaterialSupplementListDO;
import com.xyb.order.pc.applybill.model.MaterialSupplementListDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by xieqingyang on 2018/4/25.
 */
public interface MaterialSupplementDao {

    List<MaterialSupplementListDO> listMaterialSupplementPage(MaterialSupplementListDTO supplementListDTO);

    String getType(@Param("type") String[] type);

    MaterialSupplementInfoDO getMaterialSupplemgntInfo(Long mainId);

    /**
     * @description 根据报告ID查询补充材料累心
     * @author      xieqingyang
     * @CreatedDate 2018/8/2 下午5:08
     * @Version     1.0
     * @param auditReportId 报告ID
     * @return 返回补充材料类型数据
     */
    List<String> queryMaterialType(Long auditReportId);
}
