package com.xyb.order.pc.applybill.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.xyb.order.pc.applybill.model.ApplyBillInfoDO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoQueryDTO;
import com.xyb.order.pc.applybill.model.ApplyBillInfoTempSaveDTO;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDO;
import com.xyb.order.pc.applybill.model.ApplyClientAbandonDTO;
import com.xyb.order.pc.applybill.model.ApplyOtherDataRemarkDO;
import com.xyb.order.pc.applybill.model.ApplyOtherdataRemarkDTO;

/**
 * @ClassName ApplyBillInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
public interface ApplyBillInfoDao {

	List<ApplyBillInfoQueryDO> applyBillInfoQueryPage(ApplyBillInfoQueryDTO applyBillInfoQueryDTO);
	
	ApplyBillInfoDO queryBillInfoByMainId(Long mainId);
	
	List<ApplyBillInfoDO> queryApplyBillListByCusId(Long cusId);

	void add(Map<String, Object> map);

	void updateApplyBillInfoById(Map<String, Object> queryMap);
	
	void updateMainInfoBbyMainId(ApplyBillInfoTempSaveDTO applyBillInfoTempSaveDTO);
	
	ApplyBillMainInfoDO getMainInfoByApplyNumOrApplyId(Map<String, Object> map);

	List<ApplyClientAbandonDO> queryClientAbandonReason(Map<String, Object> paramMap);

	void updateClientAbandonStatus(ApplyClientAbandonDTO applyClientAbandonDTO);
	
    void updateApplyInfoOnlyNeed(Map<String, Object> map);
    
    List<Long> listContractAuditApplyIds();
    
    void updateLinkManDelFlagById(Map<String, Object> paramMap);
    
    void addHistoryRemark(ApplyOtherdataRemarkDTO applyOtherdataRemarkDTO);
    
    List<ApplyOtherDataRemarkDO> getHistoryRemarkByApplyId(Long applyId);
    
    Long getExpectProductId(Long applyId);
    
    String getServiceRemark(Long applyId);
    
    void updateServiceRemark(Long applyId);


    /**为了结清证明、历史合同信息的查询sql*/
    int getContractCount(Long applyId);
    int getClearProofCount(Long applyId);
    
    BigDecimal getServiceAmount(Long applyId);

    /**
     * @description 修改主表专案码
     * @author      xieqingyang
     * @CreatedDate 2018/7/23 下午4:17
     * @Version     1.0
     * @param applyBillMainInfoDO 修改信息
     * @return 返回执行结果
     */
    int updateMainInfoProjectCode(ApplyBillMainInfoDO applyBillMainInfoDO);

    /**
     * 根据主表主键查询当前节点
     * @author      xieqingyang
     * @date        2018/8/30 下午5:00
     * @version     1.0
     * @param mainId 主表主键ID
     * @return 返回当前状态
     */
    int getMainState(Long mainId);
}
