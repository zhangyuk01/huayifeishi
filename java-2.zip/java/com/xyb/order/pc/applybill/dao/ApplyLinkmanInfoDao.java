package com.xyb.order.pc.applybill.dao;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDO;

/**
 * @ClassName ApplyLinkmanInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
public interface ApplyLinkmanInfoDao {

	public List<ApplyLinkmanInfoDO> queryLinkInfoListByMainIdAndType(Map<String, Object> paraMap);
	
	void add(Map<String, Object> map);

	void update(Map<String, Object> map);
	
	public ApplyLinkmanInfoDO queryLinkManById(Long id);
	
	<T> void addLinkManInfos(@Param("list") List<T> list);
	
	<T> void updateLinkManInfos(@Param("list") List<T> list);
	
	ApplyLinkmanInfoDO getLinkInfoByApplyIdAndPhone1(Map<String, Object> map);
}
