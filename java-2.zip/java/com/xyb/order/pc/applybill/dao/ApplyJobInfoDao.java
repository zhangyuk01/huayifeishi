package com.xyb.order.pc.applybill.dao;

import java.util.Map;

/**
 * @ClassName ApplyJobInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
import com.xyb.order.pc.applybill.model.ApplyJobInfoDO;
import com.xyb.order.pc.applybill.model.ApplyJobInfoOfJinBoAndCpfDO;

public interface ApplyJobInfoDao {

	ApplyJobInfoDO queryJobInfoByMainId(Long mainId);
	
	void add(Map<String, Object> map);

	void update(Map<String, Object> map);
	
	ApplyJobInfoOfJinBoAndCpfDO queryJobInfoOfJinBoAndCpfByMainId(Long mainId);

}
