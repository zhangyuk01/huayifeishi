package com.xyb.order.pc.applybill.dao;

import com.xyb.order.pc.applybill.model.InsertReconsiderationDTO;
import com.xyb.order.pc.applybill.model.ReconsiderationInfoDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDO;
import com.xyb.order.pc.applybill.model.ReconsiderationListDTO;

import java.util.List;
import java.util.Map;

/**
 * 复议功能使用
 * @author         xieqingyang
 * @date           2018/10/17 2:39 PM
*/
public interface ReconsiderationDao {

    List<ReconsiderationListDO> queryReconsiderationListPage(ReconsiderationListDTO reconsiderationListDTO);

    ReconsiderationInfoDO queryReconsiderationInfo(Long mainId);

    int insertReconsider(InsertReconsiderationDTO insertReconsiderationDTO);

    int updateReconsiderMain(Map<String,Object> paraMap);
}
