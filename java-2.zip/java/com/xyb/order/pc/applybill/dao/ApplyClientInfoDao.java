package com.xyb.order.pc.applybill.dao;

import java.util.Map;
import com.xyb.order.pc.applybill.model.ApplyClientInfoDO;

/**
 * @ClassName ApplyClientInfoDao
 * @author ZhangYu
 * @date 2018年3月26号
 */
public interface ApplyClientInfoDao {

	public ApplyClientInfoDO queryClientInfoByMainId(Long mainId);
	
	void add(Map<String, Object> map);

	void updateOnlyChanged(Map<String, Object> map);

}
