package com.xyb.order.pc.consultation.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.pc.consultation.dao.ConsultationDao;
import com.xyb.order.pc.consultation.model.*;
import com.xyb.order.pc.consultation.service.ConsultationService;
import com.xyb.order.common.currency.dao.TableModifyLogDao;
import com.xyb.order.common.currency.model.TableModifyLogDTO;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 咨询管理接口实现
 * @author         xieqingyang
 * @date           2018/3/22 11:42 AM
*/
@Service(interfaceName="com.xyb.order.pc.consultation.service.ConsultationService")
public class ConsultationServiceImpl implements ConsultationService{

    @Autowired
    private ConsultationDao consultationDao;
    @Autowired
    private TableModifyLogDao tableModifyLogDao;
    @Autowired
    private CurrencyDao currencyDao;

    @Override
    public RestResponse listConsultationPage(Integer pageNumber, Integer pageSize, ConsultationDTO consultationDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        consultationDTO.getPage().setPageNumber(pageNumber);
        consultationDTO.getPage().setPageSize(pageSize);
        consultationDTO.setOrgId(user.getDataOrgId());
        consultationDTO.setList(NodeStateConstant.CONSULT_LIST);
        List<ConsultationDO> consultationS = consultationDao.listConsultationPage(consultationDTO);
        consultationDTO.getPage().setContents(consultationS);
        return new RestResponse(MsgErrCode.SUCCESS, consultationDTO.getPage());
    }

    @Override
    public RestResponse getConsultationInFo(String applyNum,Long applyId)throws Exception{
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("applyNum",applyNum);
        paraMap.put("familyCode",SysDictEnum.FAMILY_PERSON_LINK.getCode());
        paraMap.put("workCode",SysDictEnum.WORK_PERSON_LINK.getCode());
        paraMap.put("quickCode",SysDictEnum.QUICK_PERSON_LINK.getCode());
        paraMap.put("applyId",applyId);
        ConsultationInFoDO consultationInFoDO = consultationDao.consultationInFo(paraMap);
        return new RestResponse(MsgErrCode.SUCCESS, consultationInFoDO);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse sortingSwitch(String state)throws Exception {
        if (StringUtils.isNotNullAndEmpty(state) && (CurrencyConstant.Y.equals(state) || CurrencyConstant.N.equals(state))){
            User user = SessionUtil.getLoginUser(User.class);
            Map<String,Object> paraMap = new HashMap<>(4);
            paraMap.put("userId",user.getId());
            paraMap.put("state",(CurrencyConstant.Y.equals(state))? SysDictEnum.OPEN_SWITCH.getCode():SysDictEnum.CLOSE_SWITCH.getCode());
            paraMap.put("orgId",user.getOrgId());
            paraMap.put("configItem",SysDictEnum.CONSULT_SWITCH.getCode());
            Long orgType = consultationDao.getOrgLevel(user.getOrgId());
            if (orgType != null && SysDictEnum.BUSINESS_DEPARTMENT.getCode().equals(orgType)) {
                int switchCount = consultationDao.queryOrgSwitchCount(paraMap);
                if (switchCount <= 0) {
                    consultationDao.insertOrgSortingSwitch(paraMap);
                } else {
                    consultationDao.updateOrgSortingSwitch(paraMap);
                }
                return new RestResponse(MsgErrCode.SUCCESS);
            }else {
                return new RestResponse(NativeMsgErrCode.NO_AUTHORITY);
            }
        }else {
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateConsultService(ServiceUpdateDTO serviceUpdateDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        serviceUpdateDTO.setUserId(user.getId());
        List<ServiceUpdateSubsidiaryDTO> applyInFo = serviceUpdateDTO.getApplyInFo();
        List<TableModifyLogDTO> modifyLogDTOS = new ArrayList<>();
        List<Long> mainIds = new ArrayList<>();
        for (int i = 0;i<applyInFo.size();i++){
            ServiceUpdateSubsidiaryDTO dto = applyInFo.get(i);
            if (dto.getOldServiceUid() == null){
                mainIds.add(applyInFo.get(i).getMainId());
            }else if (!dto.getOldServiceUid().equals(serviceUpdateDTO.getServiceUid())){
                TableModifyLogDTO modifyLogDTO = new TableModifyLogDTO();
                modifyLogDTO.setCreateUser(user.getId());
                modifyLogDTO.setTableField("service_uname");
                modifyLogDTO.setTableKey(dto.getMainId());
                modifyLogDTO.setTableName(TableConstant.T_APPLY_MAIN_INFO);
                modifyLogDTO.setModifyNewValue(serviceUpdateDTO.getServiceName());
                modifyLogDTO.setModifyOldValue(dto.getOldServiceName());
                modifyLogDTOS.add(modifyLogDTO);
                modifyLogDTO = new TableModifyLogDTO();
                modifyLogDTO.setCreateUser(user.getId());
                modifyLogDTO.setTableField("service_uid");
                modifyLogDTO.setTableKey(dto.getMainId());
                modifyLogDTO.setTableName(TableConstant.T_APPLY_MAIN_INFO);
                modifyLogDTO.setModifyNewValue(serviceUpdateDTO.getServiceUid()+"");
                modifyLogDTO.setModifyOldValue(dto.getOldServiceUid()+"");
                modifyLogDTOS.add(modifyLogDTO);
                modifyLogDTO = new TableModifyLogDTO();
                modifyLogDTO.setCreateUser(user.getId());
                modifyLogDTO.setTableField("service_uid");
                modifyLogDTO.setTableKey(dto.getApplyId());
                modifyLogDTO.setTableName(TableConstant.T_APPLY_BILL_INFO);
                modifyLogDTO.setModifyNewValue(serviceUpdateDTO.getServiceUid()+"");
                modifyLogDTO.setModifyOldValue(dto.getOldServiceUid()+"");
                modifyLogDTOS.add(modifyLogDTO);
                mainIds.add(applyInFo.get(i).getMainId());
            }else {
                applyInFo.remove(i);
                i--;
            }
        }
        if (mainIds.size() > 0) {
            Map<String, Object> paraMap = new HashMap<>(7);
            paraMap.put("mainId", mainIds);
            paraMap.put("state", NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
            paraMap.put("modifyUser", user.getId());
            paraMap.put("modifyUserName", user.getName());
            paraMap.put("businessStateName", "客服录入中");
            paraMap.put("previous", NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE);
            paraMap.put("businessState", NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
            currencyDao.updateMainInfo(paraMap);
            currencyDao.insertMainLogList(paraMap);
            Map<String, Object> serviceManager = consultationDao.getServiceManager(serviceUpdateDTO.getServiceUid());
            if (serviceManager != null) {
                if (serviceManager.containsKey("id")) {
                    serviceUpdateDTO.setServiceManagerUid((Long) serviceManager.get("id"));
                }
                if (serviceManager.containsKey("name")) {
                    serviceUpdateDTO.setServiceManagerName((String) serviceManager.get("name"));
                }
            }
            serviceUpdateDTO.setApplyInFo(applyInFo);
            consultationDao.updateConsultService(serviceUpdateDTO);
        }
        if (modifyLogDTOS.size() > 0) {
            tableModifyLogDao.insertTableModirfyLog(modifyLogDTOS);
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    public RestResponse getSwitchState() throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("orgId",user.getOrgId());
        paraMap.put("configItem",SysDictEnum.CONSULT_SWITCH.getCode());
        Long switchOrg = consultationDao.getOrgSwitch(paraMap);
        if (SysDictEnum.CLOSE_SWITCH.getCode().equals(switchOrg)){
            return new RestResponse(MsgErrCode.SUCCESS,CurrencyConstant.N);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS,CurrencyConstant.Y);
        }
    }

}
