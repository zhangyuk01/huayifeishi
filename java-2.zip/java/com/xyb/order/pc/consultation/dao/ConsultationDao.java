package com.xyb.order.pc.consultation.dao;

import com.xyb.order.pc.consultation.model.ConsultationDO;
import com.xyb.order.pc.consultation.model.ConsultationDTO;
import com.xyb.order.pc.consultation.model.ConsultationInFoDO;
import com.xyb.order.pc.consultation.model.ServiceUpdateDTO;

import java.util.List;
import java.util.Map;

/**
 * 咨询管理相关
 * @author         xieqingyang
 * @date           2018/10/16 3:05 PM
*/
public interface ConsultationDao {

    /**
     * 咨询列表数据查询
     * @author      xieqingyang
     * @date        2018/10/16 3:06 PM
     * @version     1.0
     * @param consultationDTO 查询条件
     * @return 返回列表数据
     */
    List<ConsultationDO> listConsultationPage(ConsultationDTO consultationDTO);

    /**
     * 查询咨询详情
     * @author      xieqingyang
     * @date        2018/10/16 3:06 PM
     * @version     1.0
     * @param paraMap 查询条件
     * @return 咨询详情
     */
    ConsultationInFoDO consultationInFo(Map<String,Object> paraMap);

    /**
     * 获取营业部等级
     * @author      xieqingyang
     * @date        2018/10/16 3:07 PM
     * @version     1.0
     * @param orgId 营业部id
     * @return 返回等级
     */
    Long getOrgLevel(Long orgId);

    /**
     * 获取营业部开关配置数量
     * @author      xieqingyang
     * @date        2018/10/16 3:07 PM
     * @version     1.0
     * @param paraMap 查询条件
     * @return 返回数量
     */
    int queryOrgSwitchCount(Map<String,Object> paraMap);

    /**
     * 配置营业部开关
     * @author      xieqingyang
     * @date        2018/10/16 3:07 PM
     * @version     1.0
     * @param paraMap 配置数据
     * @return 返回执行结果
     */
    int insertOrgSortingSwitch(Map<String,Object> paraMap);

    /**
     * 修改营业部开关状态
     * @author      xieqingyang
     * @date        2018/10/16 3:08 PM
     * @version     1.0
     * @param paraMap 查询信息
     * @return 返回执行结果
     */
    int updateOrgSortingSwitch(Map<String,Object> paraMap);

    /**
     * 修改咨询详情 修改服务人员
     * @author      xieqingyang
     * @date        2018/10/16 3:08 PM
     * @version     1.0
     * @param serviceUpdateDTO 待修改信息
     * @return 返回执行结果
     */
    int updateConsultService(ServiceUpdateDTO serviceUpdateDTO);

    /**
     * 获得营业部开关状态
     * @author      xieqingyang
     * @date        2018/10/16 3:05 PM
     * @version     1.0
     * @param paraMap 查询条件
     * @return 返回开关状态
     */
    Long getOrgSwitch(Map<String,Object> paraMap);

    /**
     * 查询营业部下件数最少的客服专员
     * @author      xieqingyang
     * @date 2018/5/24 下午4:51
     * @version     1.0
     * @param orgId 营业部ID
     * @return      客服专员信息
     */
    Map<String,Object> getService(Long orgId);

    /**
     * 根据客服专员ID获取客服经理ID和名称
     * @author      xieqingyang
     * @date 2018/6/15 上午9:57
     * @version     1.0
     * @param serviceUid 客服专员ID
     * @return 返回客服经理ID和名称
     */
    Map<String,Object> getServiceManager(Long serviceUid);
}
