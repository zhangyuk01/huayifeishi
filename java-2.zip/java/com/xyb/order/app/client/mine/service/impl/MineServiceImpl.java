package com.xyb.order.app.client.mine.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.xyb.auth.user.model.User;
import com.xyb.credit.auditend.model.AuditEndOperationVO;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.loan.app.laterpayment.model.AppLatePaymentDTO;
import com.xyb.loan.app.laterpayment.model.AppLatePaymentPlanVO;
import com.xyb.loan.app.laterpayment.model.AppLatePaymentVO;
import com.xyb.loan.app.laterpayment.service.AppLatePaymentService;
import com.xyb.loan.app.onetimepayment.service.AppOnetimePaymentService;
import com.xyb.loan.finance.onetimerepayment.model.dto.AppOnetimePaymentApplicationDTO;
import com.xyb.loan.finance.onetimerepayment.model.dto.OnetimePaymentApplicationDTO;
import com.xyb.loan.finance.onetimerepayment.model.dto.OnetimePaymentContinueDTO;
import com.xyb.loan.finance.onetimerepayment.model.po.OnetimePaymentApplicationDetailDO;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.FddClientApplyInFoDTO;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.app.client.mine.dao.MineDao;
import com.xyb.order.app.client.mine.model.*;
import com.xyb.order.app.client.mine.service.MineService;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.ChangeBankApplyDO;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.AppVersionDO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import com.xyb.util.SessionUtil;

import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;


@Service(interfaceName = "com.xyb.order.app.client.mine.service.MineService")
public class MineServiceImpl implements MineService {

    @Autowired
    private MineDao mineDao;
    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private ClientRedisUtil clientRedisUtil;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private BankDao bankDao;
    @Autowired
    private ApplyPersonDao applyPersonDao;
    @Reference
    private CreditCommonService creditCommonService;
    @Reference
    private AppLatePaymentService appLatePaymentService;
    @Reference 
    private AppOnetimePaymentService appOnetimePaymentService;
    @Autowired
    private HomeDao homeDao;


    @Override
    public RestResponse queryMineInfo()throws Exception{
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        // -- 客户认证相关信息
        ClientAuthenticationDO authenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        if (authenticationDO == null){
            response = new RestResponse(MsgErrCode.SUCCESS);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS, authenticationDO);
        }
        return response;
    }

    @Override
    public RestResponse queryAppVersion(String deviceType)throws Exception{
        RestResponse response;
        // -- 版本信息
        AppVersionDO appVersionDO = new AppVersionDO();
        if (StringUtils.isNullOrEmpty(deviceType)){
            return new RestResponse(NativeMsgErrCode.DEVICE_TYPE_ERROR);
        }else if (CurrencyConstant.IOS.equals(deviceType)){
            if (RedisUtil.exists(RedisConstant.C_APP_VERSION_IOS)){
                appVersionDO = RedisUtil.get(RedisConstant.C_APP_VERSION_IOS,AppVersionDO.class);
            }else {
                appVersionDO.setAppType(SysDictEnum.APP_TYPE_CLIENT.getCode());
                appVersionDO.setDeviceType(SysDictEnum.APP_VERSION_IOS.getCode());
                appVersionDO = currencyDao.getAppVersion(appVersionDO);
                if (appVersionDO != null){
                    RedisUtil.setex(RedisConstant.C_APP_VERSION_IOS,appVersionDO);
                }
            }
        }else if (CurrencyConstant.ANDROID.equals(deviceType)){
            if (RedisUtil.exists(RedisConstant.C_APP_VERSION_ANDROID)){
                appVersionDO = RedisUtil.get(RedisConstant.C_APP_VERSION_ANDROID,AppVersionDO.class);
            }else {
                appVersionDO.setAppType(SysDictEnum.APP_TYPE_CLIENT.getCode());
                appVersionDO.setDeviceType(SysDictEnum.APP_VERSION_ANDROID.getCode());
                appVersionDO = currencyDao.getAppVersion(appVersionDO);
                if (appVersionDO != null){
                    RedisUtil.setex(RedisConstant.C_APP_VERSION_ANDROID,appVersionDO);
                }
            }
        }else {
            return new RestResponse(NativeMsgErrCode.DEVICE_TYPE_ERROR);
        }
        if (appVersionDO != null){
            // -- 页面展示
            VersionInfoVO versionInfoVO = new VersionInfoVO();
            versionInfoVO.setIsShow(SysDictEnum.YES.getCode().equals(appVersionDO.getIsShow())?CurrencyConstant.Y:CurrencyConstant.N);
            versionInfoVO.setNeed(SysDictEnum.YES.getCode().equals(appVersionDO.getNeed())?CurrencyConstant.Y:CurrencyConstant.N);
            versionInfoVO.setRemark(appVersionDO.getRemark());
            versionInfoVO.setUpdateUrl(appVersionDO.getUpdateUrl());
            versionInfoVO.setVersionCode(appVersionDO.getVersionCode() + "");
            versionInfoVO.setVersionName(appVersionDO.getVersionName());
            response = new RestResponse(MsgErrCode.SUCCESS,versionInfoVO);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS);
        }
        return response;
    }

    @Override
    public RestResponse getApplyRecord(ApplyRecordQueryDTO applyRecordQueryDTO) throws Exception {
     	RestResponse response = null;
    	User user = SessionUtil.getLoginUser(User.class);
        String applyRecordType = applyRecordQueryDTO.getApplyRecordType();
        Integer page = applyRecordQueryDTO.getPage();
        /**全部*/
        if ("1".equals(applyRecordType)) {
        	if (page == null){
        		page = 0;
        	}
        	Map<String,Object> paraMap = new HashMap<>(2);
        	paraMap.put("page",page*10);
        	paraMap.put("userId",user.getLoginId());
        	ApplyRecordListVO listVO;
        	//查询借款信息
        	List<ApplyRecordVO> recordVOS = mineDao.queryApplyRecord(paraMap);
        	//修改利率
        	DecimalFormat df = new DecimalFormat("0.00%"); 
        	for (ApplyRecordVO applyRecordVO : recordVOS) {
        		if (applyRecordVO.getServiceProportion() != null) {
		            applyRecordVO.setProductProportion(df.format(applyRecordVO.getServiceProportion()));
				}else{
					if (applyRecordVO.getMaxProductProportion() != null && applyRecordVO.getMaxProductProportion() != null) {
						applyRecordVO.setProductProportion(df.format(applyRecordVO.getMinPorductProportion())+"-"+df.format(applyRecordVO.getMaxProductProportion()));
					}
				}
			}
        	//查询借款数量
        	int count = mineDao.queryApplyRecordCount(paraMap);
        	listVO = ansiayNo(recordVOS,user.getId());
        	if (count-(page + 1) * 10 >= 1){
        		listVO.setIsMore(CurrencyConstant.Y);
        	}else {
        		listVO.setIsMore(CurrencyConstant.N);
        	}
        	response = new RestResponse(MsgErrCode.SUCCESS,listVO);
        }
        /**申请中*/
        if ("2".equals(applyRecordType)) {
        	response = getRecordMidList(user);
        }
        /**还款中*/
        if ("3".equals(applyRecordType)) {
        	response = getRecordReturn(user);
        }
        return response;
    }
    
    /***
     * C端APP借款中列表 
     * @author ZhangYu
     * @param user
     * @return
     */
    private RestResponse getRecordMidList(User user){
    	ApplyRecordProcessDTO applyRecordProcessDTO = new  ApplyRecordProcessDTO();
    	applyRecordProcessDTO.setUserId(user.getLoginId());
    	applyRecordProcessDTO.setList(NodeStateConstant.APPLY_RECORD_PROCESS);
    	// 登录用户所有申请中的申请单信息
    	List<ApplyRecordStateDO> applyRecordStateDOs = mineDao.queryApplyRecordState(applyRecordProcessDTO);

    	List<ApplyRecordProcessDO> applyRecordProcessDOs  = new ArrayList<ApplyRecordProcessDO>();
    	List<ApplyRecordLogStateDO> allRecordLogList = new ArrayList<ApplyRecordLogStateDO>();
    	DecimalFormat df = new DecimalFormat("0.00%"); 
    	if (applyRecordStateDOs != null && applyRecordStateDOs.size() > 0) {
    		//遍历客户下面的所有申请单信息
    		for (ApplyRecordStateDO applyRecordStateDO : applyRecordStateDOs) {
    			//查询对应申请单金额利率
    			if (applyRecordStateDO.getMainId() != null) {
    				ApplyRecordProcessDO applyRecordProcessDO = new ApplyRecordProcessDO();
    				applyRecordProcessDO.setApplyId(applyRecordStateDO.getApplyId());
    				applyRecordProcessDO.setMainId(applyRecordStateDO.getMainId());
    				ApplyRecordProcessAmountDO applyRecordProcessAmountDO = mineDao.queryApplyRecordAmountByMainId(applyRecordStateDO.getMainId());
    				if (applyRecordProcessAmountDO != null) {
    					if (applyRecordProcessAmountDO.getServiceProportion() != null) {
    						applyRecordProcessDO.setProductProportion(df.format(applyRecordProcessAmountDO.getServiceProportion()));
						}else{
							if (applyRecordProcessAmountDO.getMinPorductProportion() != null && applyRecordProcessAmountDO.getMaxProductProportion() != null) {
								applyRecordProcessDO.setProductProportion(df.format(applyRecordProcessAmountDO.getMinPorductProportion())+"-"+df.format(applyRecordProcessAmountDO.getMaxProductProportion()));
							}
						}
    					applyRecordProcessDO.setRecordProcessMoney(applyRecordProcessAmountDO.getRecordProcessMoney());
    					applyRecordProcessDO.setRecoreProcessLimit(applyRecordProcessAmountDO.getRecoreProcessLimit());
    					applyRecordProcessDO.setProductName(applyRecordProcessAmountDO.getProductName());
    				}
    				List<ApplyRecordLogStateDO> applyRecordLogStateDOs = mineDao.queryApplyRecordStateListByMainId(applyRecordStateDO.getMainId());
    				if (applyRecordLogStateDOs != null && applyRecordLogStateDOs.size() > 0) {
    					String currentStateFlag = NodeStateConstant.getNodeFlagOfApplyRecord(applyRecordStateDO.getState());
    					boolean tempFlag = false;
    					for (ApplyRecordLogStateDO applyRecordLogStateDO : applyRecordLogStateDOs) {
    						//遍历每个申请单日志信息
    						String stateName = NodeStateConstant.getNodeStateNameOfApplyRecord(applyRecordLogStateDO.getLogState());
    						if (currentStateFlag.equals(applyRecordLogStateDO.getLogState())) {
    							if ("5".equals(applyRecordLogStateDO.getLogState()) ) {
									// -- 查看用户签约状态
									Map<String,Object> paraMap = new HashMap<>(2);
									paraMap.put("agreementType",SysDictEnum.LOAN_SERVICE_URL.getCode());
									paraMap.put("cusId",applyRecordStateDO.getClientId());
									paraMap.put("isValid",SysDictEnum.IS_VALID.getCode());
									int count = authorizationDao.getAgreementInFoCount(paraMap);
									if (count < 1){
										applyRecordLogStateDO.setButtonName("去签约");
										applyRecordLogStateDO.setIsButton(CurrencyConstant.Y);
									}
								}
								if ("3".equals(applyRecordLogStateDO.getLogState())) {
									applyRecordLogStateDO.setButtonName(stateName);
									applyRecordLogStateDO.setIsButton(CurrencyConstant.Y);
								}
								applyRecordLogStateDO.setLogState(stateName);
								tempFlag = true;
    						}
    						if (tempFlag) {
    							if (StringUtils.isNotNullAndEmpty(stateName)) {
    								applyRecordLogStateDO.setLogState(stateName);
    								allRecordLogList.add(applyRecordLogStateDO);
								}
    						}
    					}
    					applyRecordProcessDO.setApplyRecordLogStateDOs(allRecordLogList);
    					applyRecordProcessDOs.add(applyRecordProcessDO);
    				}
    			}
    		}
    	}
    	return new RestResponse(MsgErrCode.SUCCESS,applyRecordProcessDOs);
    }
   
    /***
     * 还款中 
     * @author ZhangYu
     * @param user
     * @return
     * @throws Exception
     */
    private RestResponse getRecordReturn(User user) throws Exception{
    	RestResponse response;
    	try {
    		String loginId = user.getLoginId();
    		Long contractId = mineDao.getContractIdByLoginId(loginId);
    		if(contractId == null){
    			return new RestResponse(MsgErrCode.SUCCESS);
    		}
    		AppLatePaymentVO appLatePaymentVO = appLatePaymentService.queryPaymentInformation(contractId);
    		if (appLatePaymentVO == null) {
    			return new RestResponse(MsgErrCode.SUCCESS);
			}
    		Long contractStatus = appLatePaymentVO.getContractStatus();
    		if (contractStatus != null && contractStatus == 2761) {
    			return new RestResponse(MsgErrCode.SUCCESS);
			}
    		response = new RestResponse(MsgErrCode.SUCCESS,appLatePaymentVO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后还款中接口报错----");
		}
    	return response;
    }
   
    /**
     * 查询确认借款金额数据 
     * @author ZhangYu
     * @param mainId,applyId
     * @return
     * @throws Exception
     */
    @Override
	public RestResponse getApplyRecordConfirmInfo(Long mainId,Long applyId) throws Exception {
    	RestResponse response;
    	try {
    		BigDecimal expertMoney = mineDao.getExpertMoneyByMainId(mainId);
    		int auditBpmLogs = creditCommonService.getAuditBpmLogs(mainId);
    		AuditEndOperationVO auditEndOperationVO= creditCommonService.getAuditReportLast(auditBpmLogs,applyId);
    		ApplyRecordConfrimDO applyRecordConfrimDO =  new ApplyRecordConfrimDO();
    		if (auditEndOperationVO != null) {
    			if (auditEndOperationVO.getAuditAmount() != null && expertMoney != null) {
    				int compareNum = expertMoney.compareTo(auditEndOperationVO.getAuditAmount());
        			if (compareNum == -1 ) {
        				applyRecordConfrimDO.setAgreeAmount(expertMoney);
        			}else{
        				applyRecordConfrimDO.setAgreeAmount(auditEndOperationVO.getAuditAmount());
        			}
				}else{
					if (expertMoney == null) {
        				applyRecordConfrimDO.setAgreeAmount(auditEndOperationVO.getAuditAmount());
					}
					if (auditEndOperationVO.getAuditAmount() == null) {
        				applyRecordConfrimDO.setAgreeAmount(expertMoney);
					}
				}
    			applyRecordConfrimDO.setAgreeProductLimit(auditEndOperationVO.getAuditProductLimit());
			}else{
				applyRecordConfrimDO.setAgreeAmount(expertMoney);
			}
    		response = new RestResponse(MsgErrCode.SUCCESS, applyRecordConfrimDO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调取信审获取报告结果错误----");
		}
    	return response;
	}
    
    /**
     * 确认还款 
     * @author ZhangYu
     * @param applyReturnLoanDTO
     * @return
     * @throws Exception
     */
    @Override
	public RestResponse getApplyReturnLoan(ApplyReturnLoanDTO applyReturnLoanDTO) throws Exception {
    	RestResponse response;
    	try {
    		BigDecimal shouldAlsoAmount = applyReturnLoanDTO.getShouldAlsoAmount();
    		if (shouldAlsoAmount == null) {
    			return new RestResponse(NativeMsgErrCode.NULL_SHOULD_ALSO_AMOUNT);
			}
    		AppLatePaymentDTO appLatePaymentDTO = new AppLatePaymentDTO();
    		User user = SessionUtil.getLoginUser(User.class);
    		Long contractId = mineDao.getContractIdByLoginId(user.getLoginId());
    		if (contractId != null) {
    			appLatePaymentDTO.setContractId(contractId);
    		}
    		appLatePaymentDTO.setId(applyReturnLoanDTO.getId());
    		appLatePaymentDTO.setShouldAlsoAmount(applyReturnLoanDTO.getShouldAlsoAmount());
    		appLatePaymentDTO.setCurrentPaymentStatus(applyReturnLoanDTO.getCurrentPaymentStatus());
    		if (applyReturnLoanDTO.getCurrendPeriod() != null) {
    			appLatePaymentDTO.setCurrendPeriod(applyReturnLoanDTO.getCurrendPeriod());
			}
    		Map<Object, Object> returnMap = appLatePaymentService.submitAnApplicationForRepayment(appLatePaymentDTO);
    		response = new RestResponse(MsgErrCode.SUCCESS, returnMap);
    		response.setDescription((String)returnMap.get("description"));
    		response.setResult((int)returnMap.get("result"));
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后确认还款接口报错----");
		}
		return response;
	}
   
    /**
     * 逾期中弹框接口 
     * @author ZhangYu
     * @param palnId
     * @return
     * @throws Exception
     */
    @Override
	public RestResponse getOutTimeContinue(Long planId) throws Exception {
    	AppLatePaymentPlanVO appLatePaymentPlanVO = appLatePaymentService.queryPaymentPlanDetails(planId);
		return new RestResponse(MsgErrCode.SUCCESS, appLatePaymentPlanVO);
	}

    /**
     * 一次性结清列表接口 
     * @author ZhangYu
     * @param applyReturnLoanDTO
     * @return
     * @throws Exception
     */
    @Override
	public RestResponse getOneTimePayment() throws Exception {
    	RestResponse response;
    	try {
    		User user = SessionUtil.getLoginUser(User.class);
    		Long contractId = mineDao.getContractIdByLoginId(user.getLoginId());
    		if (contractId == null) {
    			return new RestResponse(MsgErrCode.SUCCESS);
			}
    		Map<String, Object> onetimePaymentApplicationMap = appOnetimePaymentService.onetimePaymentApplication(contractId); 
    		List<OnetimePaymentApplicationDetailDO> oldList = (List<OnetimePaymentApplicationDetailDO>)onetimePaymentApplicationMap.get("calculateList");
    		List<OnetimePaymentApplicationReciveDetailDO> newList = new ArrayList<OnetimePaymentApplicationReciveDetailDO>(); 
    		Integer totalPeriod = (Integer)onetimePaymentApplicationMap.get("totalPeriod");
    		if (oldList != null && oldList.size() > 0) {
    			for (OnetimePaymentApplicationDetailDO onetimePaymentApplicationDetailDO : oldList) {
    				Integer currentPeriod = onetimePaymentApplicationDetailDO.getCurrentPeriod();
    				String periodStr = currentPeriod+"/"+totalPeriod;
    				OnetimePaymentApplicationReciveDetailDO onetimePaymentApplicationReciveDetailDO = new OnetimePaymentApplicationReciveDetailDO();
    				onetimePaymentApplicationReciveDetailDO.setPeriodStr(periodStr);
    				onetimePaymentApplicationReciveDetailDO.setId(onetimePaymentApplicationDetailDO.getId());
    				onetimePaymentApplicationReciveDetailDO.setPaymentApplicationId(onetimePaymentApplicationDetailDO.getPaymentApplicationId());
    				onetimePaymentApplicationReciveDetailDO.setRepaymentPlanId(onetimePaymentApplicationDetailDO.getRepaymentPlanId());
    				onetimePaymentApplicationReciveDetailDO.setShouldPrincipal(onetimePaymentApplicationDetailDO.getShouldPrincipal());
    				onetimePaymentApplicationReciveDetailDO.setShouldInterest(onetimePaymentApplicationDetailDO.getShouldInterest());
    				onetimePaymentApplicationReciveDetailDO.setShouldTotal(onetimePaymentApplicationDetailDO.getShouldTotal());
    				onetimePaymentApplicationReciveDetailDO.setActualPrincipal(onetimePaymentApplicationDetailDO.getActualPrincipal());
    				onetimePaymentApplicationReciveDetailDO.setActualInterest(onetimePaymentApplicationDetailDO.getActualInterest());
    				onetimePaymentApplicationReciveDetailDO.setActualTotal(onetimePaymentApplicationDetailDO.getActualTotal());
    				onetimePaymentApplicationReciveDetailDO.setReductionAmount(onetimePaymentApplicationDetailDO.getReductionAmount());
    				onetimePaymentApplicationReciveDetailDO.setCurrentPeriod(onetimePaymentApplicationDetailDO.getCurrentPeriod());
    				onetimePaymentApplicationReciveDetailDO.setAccountType(onetimePaymentApplicationDetailDO.getAccountType());
    				onetimePaymentApplicationReciveDetailDO.setState(onetimePaymentApplicationDetailDO.getState());
    				onetimePaymentApplicationReciveDetailDO.setRemark(onetimePaymentApplicationDetailDO.getRemark());
    				onetimePaymentApplicationReciveDetailDO.setCreateTime(onetimePaymentApplicationDetailDO.getCreateTime());
    				onetimePaymentApplicationReciveDetailDO.setCreateUser(onetimePaymentApplicationDetailDO.getCreateUser());
    				onetimePaymentApplicationReciveDetailDO.setModifyTime(onetimePaymentApplicationDetailDO.getModifyTime());
    				onetimePaymentApplicationReciveDetailDO.setModifyUser(onetimePaymentApplicationDetailDO.getModifyUser());
    				newList.add(onetimePaymentApplicationReciveDetailDO);
    			}
    			onetimePaymentApplicationMap.put("calculateList",newList);
    		}
    		response = new RestResponse(MsgErrCode.SUCCESS,onetimePaymentApplicationMap);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后一次性结清接口报错----");
		}
		return response;
	}
   
    /**
     * 作废
     * @author ZhangYu
     * @param ApplyOnetimePaymentContinueDTO
     * @return
     */
	@Override
	public RestResponse getOneTimePaymentContinueZf(ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO) {
		Long paymentApplicationId = applyOnetimePaymentContinueDTO.getPaymentApplicationId();
		try {
			OnetimePaymentContinueDTO onetimePaymentContinueDTO = new OnetimePaymentContinueDTO(); 
			onetimePaymentContinueDTO.setPaymentApplicationId(paymentApplicationId);
			appOnetimePaymentService.onetimePaymentCancellation(onetimePaymentContinueDTO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后作废接口报错----");
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}
	
	/**
     * 续划
     * @author ZhangYu
     * @param ApplyOnetimePaymentContinueDTO
     * @return
     */
	@Override
	public RestResponse getOneTimePaymentContinueXh(ApplyOnetimePaymentContinueDTO applyOnetimePaymentContinueDTO) {
		Long paymentApplicationId = applyOnetimePaymentContinueDTO.getPaymentApplicationId();
		try {
			OnetimePaymentContinueDTO onetimePaymentContinueDTO = new OnetimePaymentContinueDTO(); 
			onetimePaymentContinueDTO.setPaymentApplicationId(paymentApplicationId);
			appOnetimePaymentService.onetimePaymentContinueSubmit(onetimePaymentContinueDTO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后续划接口报错----");
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
     * 划扣
     * @author ZhangYu
     * @param ApplyOnetimePaymentApplicationDTO
     * @return
     */
	@Override
	public RestResponse getOneTimePaymentContnueHk() {
		RestResponse response;
		User user = SessionUtil.getLoginUser(User.class);
		Long contractId = mineDao.getContractIdByLoginId(user.getLoginId());
		OnetimePaymentApplicationDTO  onetimePaymentApplicationDTO = new OnetimePaymentApplicationDTO();
		if (contractId == null){
			return new RestResponse(NativeMsgErrCode.HK_FAILD);
		}
		try {
			onetimePaymentApplicationDTO.setContractId(contractId);
			Map<String, Object> resultMap = appOnetimePaymentService.onetimePaymentApplicationApplySubmit(onetimePaymentApplicationDTO);
			response = new RestResponse(MsgErrCode.SUCCESS, resultMap);
			response.setDescription((String)resultMap.get("description"));
    		response.setResult((int)resultMap.get("result"));
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调用贷后划扣接口报错----");
		}
		return response;
	}

	/**
     * 历史申请记录
     * @author ZhangYu
     * @param 
     * @return
     */
	@Override
	public RestResponse onetimePaymentHistory() {
		User user = SessionUtil.getLoginUser(User.class);
		Long contractId = mineDao.getContractIdByLoginId(user.getLoginId());
		if (contractId != null) {
			OnetimePaymentApplicationDTO onetimePaymentApplicationDTO  = new OnetimePaymentApplicationDTO();
			onetimePaymentApplicationDTO.setContractId(contractId);
			List<AppOnetimePaymentApplicationDTO> onetimePaymentHistory = appOnetimePaymentService.onetimePaymentHistory(onetimePaymentApplicationDTO);
			return new RestResponse(MsgErrCode.SUCCESS,onetimePaymentHistory);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

    @Override
	public RestResponse getApplyRecordConfirm(ApplyRecordConfrimDTO applyRecordConfrimDTO) throws Exception {
    	Long applyId = applyRecordConfrimDTO.getApplyId();
    	Long mainId = applyRecordConfrimDTO.getMainId();
    	BigDecimal agreeAmount = applyRecordConfrimDTO.getAgreeAmount();
    	BigDecimal oldAgreeAmount = applyRecordConfrimDTO.getOldAgreeAmount();
    	Long expertProductId = mineDao.getExpertProductIdByMainId(mainId);
    	List<ProductExhibitionDO> exhibitionDOS = homeDao.queryProductExhibition(expertProductId);
    	BigDecimal endMinAmount = exhibitionDOS.get(0).getMinAmount();
    	int compareMinNum = agreeAmount.compareTo(endMinAmount);
    	int compareMaxNum = agreeAmount.compareTo(oldAgreeAmount);
    	if (compareMinNum == -1 ) {//借款金额小于最小金额
    		return new RestResponse(1,"金额不可低于"+"【"+endMinAmount+"】元");
		}
    	if (compareMaxNum == 1) {//借款金额大于最大金额
    		return new RestResponse(1,"金额不可高于"+"【"+oldAgreeAmount+"】元");
		}
    	/**调用信审确认借款接口 */
    	try {
    		creditCommonService.confirmBorrow(mainId,applyId,agreeAmount);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("---调取信审确认借款接口失败----");
		}
    	return new RestResponse(MsgErrCode.SUCCESS);
	}
    
    @Override
    public RestResponse getLoanConfirmation(LoanConfirmationDTO dto) throws Exception {
        LoanConfirmationVO loanConfirmationVO = mineDao.getLoanConfirmation(dto);
        if (loanConfirmationVO != null){
            return new RestResponse(MsgErrCode.SUCCESS,loanConfirmationVO);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    @Override
    public RestResponse getSign() throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Map<String, Object> paraMap = new HashMap<>(2);
        paraMap.put("clientUserId", user.getId());
        paraMap.put("list", Arrays.asList(NodeStateConstant.CONTRACT_ENTRY));
        // -- 查询客户申请单信息
        FddClientApplyInFoDTO fddClientApplyInFoDTO = applyPersonDao.getFddClientApplyInFo(paraMap);
        if (fddClientApplyInFoDTO == null) {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
        String result;
        /**判断是否已拥有有效的银行卡信息*/
        // -- 查询用户银行卡信息
        ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
        paraClient.setClientId(fddClientApplyInFoDTO.getClientId());
        paraClient.setIsDefault(SysDictEnum.YES.getCode());
        paraClient.setState(SysDictEnum.YES.getCode());
        List<ClientBankInfoNoDO> list = bankDao.queryClientBankInFoNo(paraClient);
        if (list == null || list.size() <1){
            return new RestResponse(MsgErrCode.SUCCESS);
        }
        /**判断用户是否未完成签约协议*/
        paraMap = new HashMap<>(3);
        paraMap.put("agreementType", SysDictEnum.LOAN_SERVICE_URL.getCode());
        paraMap.put("applyId", fddClientApplyInFoDTO.getApplyId());
        paraMap.put("isValid", SysDictEnum.IS_VALID.getCode());
        int count = authorizationDao.getAgreementInFoCount(paraMap);
        if (count == 0) {
            result = CurrencyConstant.N;
        } else {
            result = CurrencyConstant.Y;
        }
        if (CurrencyConstant.Y.equals(result)){
            return new RestResponse(MsgErrCode.SUCCESS);
        }else {
            return new RestResponse(MsgErrCode.FAIL);
        }
    }

    /**
     * 查询推荐人
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getReferrer() throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        String key = RedisConstant.ORDER_USER_REFERRER + user.getLoginId();
        ReferrerInfoVO referrer;
        if(RedisUtil.exists(key)){
            referrer = RedisUtil.get(key,ReferrerInfoVO.class);
        }else{
            //通过客户loginId查询推荐人信息
            referrer = mineDao.getReferrer(user.getLoginId());
            RedisUtil.setex(key,referrer);
        }
        return new RestResponse(MsgErrCode.SUCCESS,referrer);
    }

    /**
     * 解析数据非存管
     * @author      xieqingyang
     * @date 2018/7/3 上午11:14
     * @version     1.0
     * @param recordVOS 传入数据
     * @param userId 登录用户ID
     * @return 展示数据
     */
    private ApplyRecordListVO ansiayNo(List<ApplyRecordVO> recordVOS,Long userId)throws Exception{
    	ApplyRecordListVO applyRecordListVO = new ApplyRecordListVO();
    	List<ApplyRecordVO> vos = new ArrayList<>();
        /**待分配客服、客服录入中*/
        List<Integer> list1 = Arrays.asList(NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE,NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
        /**申请作废、冻结*/
        List<Integer> list2 = Arrays.asList(NodeStateConstant.APPLY_FOR_INVALIDATION,NodeStateConstant.CONTRACT_FREEZE);
        /**系统审核中、信审所有分件节点、初审中、审核中、终审中、系统审核、签约前核验审核中、复议审核中、合同审核中、外访中、材料补充、签约前核验、反欺诈审核中*/
        List<Integer> list3 = Arrays.asList(NodeStateConstant.PENDING_SYSTEM_AUDIT,NodeStateConstant.FIRST_TRIAL_TO_BE_DIVIDED,NodeStateConstant.FIRST_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FINAL_ADJUDICATION,NodeStateConstant.FINAL_TRIAL_HAS_BEEN_DIVIDED,NodeStateConstant.FIRST_TRIAL,NodeStateConstant.AUDIT,NodeStateConstant.IN_THE_FINAL_TRIAL,NodeStateConstant.SYSTEM_AUDIT,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION_AUDIT,NodeStateConstant.REVIEW_AND_REVIEW,NodeStateConstant.CONTRACT_REVIEW,NodeStateConstant.MATERIAL_SUPPLEMENT,NodeStateConstant.OUTSIDE_VISIT,NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION,NodeStateConstant.ANTI_FRAUD_AUDIT);
        /**系统拒贷、签约前核验拒贷、合同审核拒贷、风险提报拒贷、预审批不通过、终审拒贷*/
        List<Integer> list4 = Arrays.asList(NodeStateConstant.SYSTEM_AUDITS_AUDIT,NodeStateConstant.SYSTEM_AUDITS_APPLY,NodeStateConstant.BEFORE_SIGNING_TO_CREDIT_VERIFICATION_AUDIT,NodeStateConstant.RIS_REPORTING_AND_REFUSING_TO_LEND,NodeStateConstant.CONTRACT_REVIEW_TO_LEND,NodeStateConstant.THE_PRETRIAL_APPROVAL_IS_NOT_PASSED,NodeStateConstant.FINAL_LEND);
        /**合同录入中、签约前核验*/
        List<Integer> list5 = Arrays.asList(NodeStateConstant.BEFORE_SIGNING_THE_CONTRACT_VERIFICATION,NodeStateConstant.CONTRACT_ENTRY);
        for (ApplyRecordVO vo:recordVOS){
        	if (NodeStateConstant.TO_BE_PRETRIAL.equals(vo.getStateCode())){
        		vo.setState("待授权");
        		vo.setButtonName("补充资料");
        		vo.setIsButton(CurrencyConstant.Y);
        		vo.setButtonType("BCCL");
        	}else if (list1.contains(vo.getStateCode())){
        		vo.setState("待审核");
        	}else if (list2.contains(vo.getStateCode())){
        		vo.setState("已作废");
        	}else if (list3.contains(vo.getStateCode())){
        		vo.setState("审核中");
        	}else if (list4.contains(vo.getStateCode())){
        		vo.setState("未通过");
        	}else if (list5.contains(vo.getStateCode())){
        		vo.setState("签约中");
        		// -- 查询用户绑卡信息
        		ClientBankInfoNoDO clientPara = new ClientBankInfoNoDO();
        		Long clientId = applyPersonDao.getCusIdByClientUserId(userId);
        		clientPara.setClientId(clientId);
        		clientPara.setState(SysDictEnum.YES.getCode());
        		clientPara.setIsDefault(SysDictEnum.YES.getCode());
        		List<ClientBankInfoNoDO> infoNoDOList = bankDao.queryClientBankInFoNo(clientPara);
        		if (infoNoDOList == null || infoNoDOList.size() == 0){
        			vo.setButtonName("去绑卡");
        			vo.setButtonType("QBK");
        			vo.setIsButton(CurrencyConstant.Y);
        		}else {
        			// -- 查询用户换卡申请
        			ChangeBankApplyDO applyPara = new ChangeBankApplyDO();
        			applyPara.setClientId(clientId);
        			applyPara.setBankInfoId(infoNoDOList.get(0).getId());
        			applyPara.setState(SysDictEnum.BANK_CARD_STATUS_3104.getCode());
        			List<ChangeBankApplyDO> applyDOList = bankDao.queryChangeBankApply(applyPara);
        			int i = 0;
        			for (ChangeBankApplyDO ct:applyDOList){
        				if (SysDictEnum.BANK_CARD_STATUS_3102.getCode().equals(ct.getState()) || SysDictEnum.BANK_CARD_STATUS_3103.getCode().equals(ct.getState())){
        					i = i + 1;
        					break;
        				}
        			}
        			if (i == 0){
        				// -- 查看用户签约状态
        				Map<String,Object> paraMap = new HashMap<>(2);
        				paraMap.put("agreementType",SysDictEnum.LOAN_SERVICE_URL.getCode());
        				paraMap.put("cusId",vo.getClientId());
        				paraMap.put("isValid",SysDictEnum.IS_VALID.getCode());
        				int count = authorizationDao.getAgreementInFoCount(paraMap);
        				if (count < 1){
        					vo.setButtonName("去签约");
        					vo.setButtonType("QQYXY");
        					vo.setIsButton(CurrencyConstant.Y);
        				}
        				//处理签约时间，批贷时间+5天
        				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        				if(com.beiming.kun.utils.StringUtils.isNotNullAndEmpty(vo.getSignDate())){
        					Date parse = sdf.parse(vo.getSignDate());
        					vo.setSignDate(sdf.format(new Date(parse.getTime()+(long)6 * 24 * 60 * 60 * 1000)));
        				}
        			}
        		}
        	}else if (NodeStateConstant.IN_THE_BID.equals(vo.getStateCode())){
        		vo.setState("募标中");
        	}else if (NodeStateConstant.THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(vo.getStateCode())){
        		vo.setState("合同生效");
        		vo.setButtonName("查看合同");
        		vo.setIsButton(CurrencyConstant.Y);
        		vo.setButtonType("CKHT");
        	}else if (NodeStateConstant.CONTRACT_INVALIDATION.equals(vo.getStateCode())){
        		if (vo.getContractAbolition().contains(SysDictEnum.CONTRACT_STATE_HTZF_REASON_HTMJSB.getCode().toString())){
        			vo.setState("募标失败");
        		}else{
        			vo.setState("募集终止");
        		}
        	}else if (NodeStateConstant.CONFIRMATION_LOAN_AMOUNT.equals(vo.getStateCode())){
        		vo.setState("借款金额确认中");
			}
        	vos.add(vo);
        }
        applyRecordListVO.setApplyRecordVOS(vos);
        return applyRecordListVO;
    }

}
