package com.xyb.order.app.client.mine.dao;

import com.xyb.order.app.client.mine.model.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
* @description:    我的功能
* @author:         xieqingyang
* @createDate:     2018/5/14 下午3:50
*/
public interface MineDao {

    /**
    * 根据登录ID查询用户认证信息
    * @author      xieqingyang
    * @param loginId
    * @return
    * @exception
    * @date        2018/5/14 下午3:51
    */
    ClientAuthenticationDO getClientAuthenticationInFo(String loginId);

    /**查询capp借款列表*/
    List<ApplyRecordVO> queryApplyRecord(Map<String,Object> paraMap);
    
    /**查询capp借款列表数量*/
    int queryApplyRecordCount(Map<String,Object> paraMap);
    
    /**查询capp借款申请中所有申请中的申请单信息*/
    List<ApplyRecordStateDO> queryApplyRecordState(ApplyRecordProcessDTO applyRecordProcessDTO);
    
    /**查询capp借款申请中状态节点日志信息*/
    List<ApplyRecordLogStateDO> queryApplyRecordStateListByMainId(Long mainId);
   
    /**查询capp借款申请中申请金额利率信息*/ 
    ApplyRecordProcessAmountDO queryApplyRecordAmountByMainId(Long mainId);
    
    /**查询借款确认信息*/
    LoanConfirmationVO getLoanConfirmation(LoanConfirmationDTO dto);

    /** 查询推荐人信息 */
    ReferrerInfoVO getReferrer(String loginId);
  
    /**根据MAINID查询申请产品ID*/
    Long getExpertProductIdByMainId(Long mainId);
    
    /**查询登录用户的合同ID*/
    Long getContractIdByLoginId(String loginId); 
  
    /**根据主表ID查询申请金额*/
    BigDecimal getExpertMoneyByMainId(Long mainId);
}
