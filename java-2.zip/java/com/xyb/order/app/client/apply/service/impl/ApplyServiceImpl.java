package com.xyb.order.app.client.apply.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.apply.dao.ApplyDao;
import com.xyb.order.app.client.apply.model.ApplyClientDO;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.apply.model.ApplyManageDO;
import com.xyb.order.app.client.apply.model.TeamManageDO;
import com.xyb.order.app.client.apply.service.ApplyService;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.ApplyNumberUtil;
import com.xyb.util.SessionUtil;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
/**
 * 
 * @author ZhangYu 
 *
 */
@Service(interfaceName = "com.xyb.order.app.client.apply.service.ApplyService")
public class ApplyServiceImpl implements ApplyService {

    @Autowired
    private ApplyDao applyDao;
    @Autowired
	private HomeDao homeDao;
    @Autowired
	private CurrencyDao currencyDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse insertApplyInfo(ApplyDTO applyDTO) throws Exception {
    	Long expectProductId = applyDTO.getExpectProductId();
    	User loginUser = SessionUtil.getLoginUser(User.class);
    	BigDecimal expectMoney = applyDTO.getExpectMoney();
		List<ProductExhibitionDO> exhibitionDOS = homeDao.queryProductExhibition(expectProductId);
    	BigDecimal endMaxAmount = exhibitionDOS.get(0).getMaxAmount();
    	BigDecimal endMinAmount = exhibitionDOS.get(0).getMinAmount();
    	int compareMinNum = expectMoney.compareTo(endMinAmount);
    	int compareMaxNum = expectMoney.compareTo(endMaxAmount);
    	if (compareMinNum == -1 ) {//借款金额小于最小金额
    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY);
		}
    	if (compareMaxNum == 1) {//借款金额大于最大金额
    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY);
		}
    	Long mainId = this.applyDao.getMainIdByLoginId(loginUser.getId());
    	/**查询客户经理信息**/
    	ApplyManageDO applyManageDO = this.applyDao.getManageIdByLoginId(loginUser.getId());
    	/**团队经理信息**/
        TeamManageDO teamManageDO = null;
    	if (applyManageDO != null) {
    		applyDTO.setManagerId(applyManageDO.getId());
    		applyDTO.setManageName(applyManageDO.getName());
    		applyDTO.setTeamOrgId(applyManageDO.getOrgId());
    		applyDTO.setTeamOrgName(applyManageDO.getOrgName());
    		teamManageDO = this.applyDao.getTeamInfoByManageId(applyManageDO.getId());
		}
    	if (teamManageDO != null) {
    		applyDTO.setTeamManagerId(teamManageDO.getId());
    		applyDTO.setTeamManagerUname(teamManageDO.getName());
		}
    	/**查询客户信息**/
    	ApplyClientDO applyClientDO = this.applyDao.getClientByLoginId(loginUser.getId());
    	if (applyClientDO != null) {
    		applyDTO.setClientId(applyClientDO.getId());
    		applyDTO.setClientIdCard(applyClientDO.getIdcard());
    		applyDTO.setClientRealName(applyClientDO.getName());
			int loopCount = this.applyDao.getLoopContractByCusId(applyClientDO.getId());
			if (loopCount > 0) {
				applyDTO.setIsLoop(SysDictEnum.YES.getCode());
			}else{
				applyDTO.setIsLoop(SysDictEnum.NO.getCode());
			}
		}
    	if (mainId == null) {
			String applyNum = ApplyNumberUtil.getsApplyNumber();
			applyDTO.setApplyNum(applyNum);
			applyDTO.setCreateUser(loginUser.getId());
			applyDTO.setModifyUser(loginUser.getId());
			applyDTO.setState(NodeStateConstant.CLIENT_APPLY);
			/**新增申请t_apply_bill_info表数据**/
			this.applyDao.addBillInfo(applyDTO);
			applyDTO.setApplyId(applyDTO.getId());
			/**新增主表t_apply_main_info表数据**/
			this.applyDao.addMainInfo(applyDTO);
			/**添加主表日志*/
			MainLogDTO mainLogDTO = new MainLogDTO();
			mainLogDTO.setMainId(applyDTO.getId());
			mainLogDTO.setModifyUser(loginUser.getId());
			mainLogDTO.setModifyUserName(loginUser.getName());
			mainLogDTO.setBusinessState(NodeStateConstant.CLIENT_APPLY);
			mainLogDTO.setBusinessStateName("客户申请");
			currencyDao.addMainLog(mainLogDTO);
		}else{
			Long applyId = this.applyDao.getApplyIdByMainId(mainId);
			applyDTO.setMainId(mainId);
			applyDTO.setApplyId(applyId);
			applyDTO.setModifyUser(loginUser.getId());
			applyDTO.setState(NodeStateConstant.CLIENT_APPLY);
			/**更新t_apply_main_info主表信息**/
			this.applyDao.updateMainInfo(applyDTO);
			/**更新t_apply_bill_info申请表信息**/
			this.applyDao.updateBillInfo(applyDTO);
		}
    	return new RestResponse(MsgErrCode.SUCCESS);
    }
   
}
