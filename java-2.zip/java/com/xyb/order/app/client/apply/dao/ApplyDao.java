package com.xyb.order.app.client.apply.dao;

import com.xyb.order.app.client.apply.model.ApplyAmountDO;
import com.xyb.order.app.client.apply.model.ApplyClientDO;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.apply.model.ApplyManageDO;
import com.xyb.order.app.client.apply.model.TeamManageDO;

/**
 * 
 * @author ZhangYu 
 *
 */
public interface ApplyDao {

	/**
	 * 根据产品ID获取该产品借款金额范围 
	 * @param exceptProductId
	 * @return
	 */
	ApplyAmountDO getApplyAmountByProductId(Long exceptProductId);

	/**
	 * 根据登录ID获取主表ID 
	 * @param clientUserId
	 * @return
	 */
	Long getMainIdByLoginId(Long clientUserId);

	/**
	 * 根据主表ID获取申请单ID 
	 * @param mainId
	 * @return
	 */
	Long getApplyIdByMainId(Long mainId);

	/**
	 * 根据登录ID获取客户经理信息 
	 * @param clinetUserID
	 * @return
	 */
	ApplyManageDO getManageIdByLoginId(Long clinetUserID);

	/**
	 * 根据客户经理ID查询销售团队信息 
	 * @param manageId
	 * @return
	 */
	TeamManageDO getTeamInfoByManageId(Long manageId);

	/**
	 * 根据登录ID获取客户信息 
	 * @param clientUserID
	 * @return
	 */
	ApplyClientDO getClientByLoginId(Long clientUserID);

	/**
	 * 添加主表信息 
	 * @param applyDTO
	 */
	void addMainInfo(ApplyDTO applyDTO);

	/**
	 * 添加申请单信息 
	 * @param applyDTO
	 */
	void addBillInfo(ApplyDTO applyDTO);

	/**
	 *更新主表信息 
	 * @param applyDTO
	 */
	void updateMainInfo(ApplyDTO applyDTO);
	
	/**
	 * 更新申请表信息
	 * @param applyDTO
	 */
	void updateBillInfo(ApplyDTO applyDTO);
	
	/**
	 * 是否是循环贷流程 
	 * @param cusId
	 * @return
	 */
	int getLoopContractByCusId(Long cusId);

	/**
	 * 通过applyId修改初始化产品
	 * @param applyDTO
	 */
	void updateProductByApplyId(ApplyDTO applyDTO);

	/**
	 * 通过Mian修改初始化产品
	 * @param applyDTO
	 */
	void updateProductByMainId(ApplyDTO applyDTO);
}
