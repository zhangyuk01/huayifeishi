package com.xyb.order.app.client.cuser.service.impl;

import com.xyb.order.common.message.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.DesUtil;
import com.fr.base.Base64;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.cuser.model.ClientUserDTO;
import com.xyb.order.app.client.cuser.service.RegisterService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.StringUtils;

@Service(interfaceName = "com.xyb.order.app.client.cuser.service.RegisterService")
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	private ClinetUserDao clinetUserDao;
	@Autowired
	private MessageService validMessageService;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse register(ClientUserDTO clientUserDTO) throws Exception {
		RestResponse response;
		// 判断推荐人是否存在
		ClientUserDO user = null;
		String recommendPhone = clientUserDTO.getRecommendPhone();
		String recommendId = clientUserDTO.getRecommendId();
		// 推荐人不能是本人
		if (clientUserDTO.getPhone().equals(recommendPhone)) {
			response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("推荐人不合法！");
			return response;
		}
		if (StringUtils.isNotNullAndEmpty(recommendPhone)) {
			user = clinetUserDao.getClientUserByLoginName(recommendPhone);
			if (null == user) {
				response = new RestResponse(NativeMsgErrCode.NO_VALID_RECOMMEND_CODE);
				response.setDescription("推荐人不存在！");
				return response;
			}
		}
		if (StringUtils.isNotNullAndEmpty(recommendId)) {
			try {
				recommendId = new String(Base64.decode(recommendId));
			} catch (Exception e) {
				response = new RestResponse(NativeMsgErrCode.NO_VALID_RECOMMEND_CODE);
				response.setDescription("推荐人不存在！");
				return response;
			}

			user = clinetUserDao.getClientUserById(Long.valueOf(recommendId));
			if (null == user) {
				response = new RestResponse(NativeMsgErrCode.NO_VALID_RECOMMEND_CODE);
				response.setDescription("推荐人不存在！");
				return response;
			}
		}

		// 获取源推荐人
		Long sorc = null;
		if (null != user) {
			String recommendCode = user.getRecommendCode();
			if (null != user.getSorcRecommend()) {
				sorc = user.getSorcRecommend();
			} else {
				if (null == recommendCode) {
					sorc = user.getId();
				} else {
					// 根据推荐人id获取源推荐人
					ClientUserDO userDo = clinetUserDao.getSorcClientUserByRecommendId(recommendCode);
					if (null != userDo) {
						sorc = userDo.getId();
					}

				}
			}
		}

		// 验证手机号是否已经注册
		int count = clinetUserDao.queryClientUserCount(clientUserDTO.getPhone());
		if (count < 1) {
			response = validMessageService.validateMessageCode(clientUserDTO.getPhone(), clientUserDTO.getMsgCode(),
					CurrencyConstant.MESSAGE_VALID_TIME, null, null);
			if (response.getResult() == 0) {
				ClientUserDO clientUserDO = new ClientUserDO();
				ApplyClientInfoDO applyClientInfoDO = new ApplyClientInfoDO();
				clientUserDO.setLoginName(clientUserDTO.getPhone());
				clientUserDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
				clientUserDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
				if (StringUtils.isNotNullAndEmpty(recommendPhone)) {
					clientUserDO.setRecommendCode(String.valueOf(user.getId()));
					applyClientInfoDO.setReferee(user.getId());
				}
				if (StringUtils.isNotNullAndEmpty(recommendId)) {
					clientUserDO.setRecommendCode(recommendId);
					applyClientInfoDO.setReferee(Long.valueOf(recommendId));
				}
				if (null != sorc) {
					clientUserDO.setSorcRecommend(sorc);
					applyClientInfoDO.setLeader(sorc);
				}
				clientUserDO.setPassword(DesUtil.encrypt(clientUserDTO.getPassword()));
				clinetUserDao.insertClinetUser(clientUserDO);
				applyClientInfoDO.setPhone(clientUserDTO.getPhone());
				applyClientInfoDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
				applyClientInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
				applyClientInfoDO.setClientUserId(clientUserDO.getId());
				clinetUserDao.insertApplyClientInfo(applyClientInfoDO);

				response = new RestResponse(MsgErrCode.SUCCESS);
				return response;
			}
		} else {
			response = new RestResponse(NativeMsgErrCode.PHONE_REGISTERED);
		}
		return response;
	}
}
