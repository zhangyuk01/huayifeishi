package com.xyb.order.app.client.cuser.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.xyb.order.common.message.service.MessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.DesUtil;
import com.beiming.kun.utils.StringUtils;
import com.beiming.kun.utils.UUIDUtil;
import com.xyb.auth.constant.Constant;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.CUpdatePhoneDTO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.fdd.service.FddService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.util.SessionUtil;

@Service(interfaceName = "com.xyb.order.app.client.cuser.service.ClinetUserModifyService")
public class ClinetUserModifyServiceImpl implements ClinetUserModifyService {

	private static final Logger log = LoggerFactory.getLogger(ClinetUserModifyServiceImpl.class);

	@Autowired
	private ClinetUserDao clinetUserDao;
	@Autowired
	private MessageService validMessageService;
	@Autowired
	private FddService fddService;
	@Autowired
	private ClientRedisUtil clientRedisUtil;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse forgetPassword(ClientUserUpdateDTO clientUserUpdateDTO) throws Exception {
		RestResponse response;
		response = validMessageService.validateMessageCode(clientUserUpdateDTO.getPhone(),
				clientUserUpdateDTO.getMsgCode(), CurrencyConstant.MESSAGE_VALID_TIME, null, null);
		if (response.getResult() == 0) {
			ClientUserDO oldclientUserDO = clinetUserDao.getClientUserByLoginName(clientUserUpdateDTO.getPhone());
			if (oldclientUserDO != null) {
				ClientUserDO clientUserDO = new ClientUserDO();
				clientUserDO.setPassword(DesUtil.encrypt(clientUserUpdateDTO.getNewPassword()));
				clientUserDO.setLoginName(clientUserUpdateDTO.getPhone());
				clientUserDO.setModifyUser(oldclientUserDO.getId());
				clinetUserDao.updataClinetUser(clientUserDO);
				response = new RestResponse(MsgErrCode.SUCCESS);
			} else {
				response = new RestResponse(NativeMsgErrCode.ACCOUNTNOTREGISTERED);
			}
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updatePhone(CUpdatePhoneDTO clientUserUpdatePhoneDTO) throws Exception {

		User user = SessionUtil.getLoginUser(User.class);
		RestResponse response;
		String loginId = user.getLoginId();
		String key = RedisConstant.CHECK_USER_ADOPT.concat(loginId);
		if (!RedisUtil.exists(key)) {
			response = new RestResponse(MsgErrCode.USER_VALIDATION_INVALID);
			response.setDescription("验证已失效，请重新进行密码验证");
			return response;
		}
		if (!clientUserUpdatePhoneDTO.getToken().equals(RedisUtil.get(key))) {
			response = new RestResponse(MsgErrCode.USER_VALIDATION_INVALID);
			response.setDescription("请先进行密码验证，再修改手机号");
			return response;
		}
		
		String phone = clientUserUpdatePhoneDTO.getPhone();
		if (loginId.equals(phone)) {
			response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("新手机号不能与旧手机号一致");
			return response;
		}
		response = validMessageService.validateMessageCode(clientUserUpdatePhoneDTO.getPhone(),
				clientUserUpdatePhoneDTO.getMsgCode(), CurrencyConstant.MESSAGE_VALID_TIME, null, null);
		if (response.getResult() == 0) {
			if (!clientUserUpdatePhoneDTO.getPhone().equals(user.getLoginId())) {
				// -- 判断手机号是否除本人以外有人使用
				ClientUserDO ct = clinetUserDao.getClientUserByLoginName(clientUserUpdatePhoneDTO.getPhone());
				if (ct != null) {
					return new RestResponse(NativeMsgErrCode.PHONE_REGISTERED);
				}
				ClientUserDO clientUserDO = new ClientUserDO();
				clientUserDO.setNewLoginName(clientUserUpdatePhoneDTO.getPhone());
				clientUserDO.setModifyUser(user.getId());
				clientUserDO.setLoginName(user.getLoginId());
				ApplyClientInfoDO applyClientInfoDO = new ApplyClientInfoDO();
				applyClientInfoDO.setPhone(clientUserUpdatePhoneDTO.getPhone());
				applyClientInfoDO.setModifyUser(user.getId());
				applyClientInfoDO.setClientUserId(user.getId());
				clinetUserDao.updataClinetUser(clientUserDO);
				clinetUserDao.updateApplyClientInfo(applyClientInfoDO);
				String userId = user.getLoginId();
				user.setLoginId(clientUserUpdatePhoneDTO.getPhone());
				RedisUtil.setex(Constant.USER + clientUserUpdatePhoneDTO.getPhone(), user);
				RedisUtil.setex(Constant.TOKEN + clientUserUpdatePhoneDTO.getPhone(), 10800,
						RedisUtil.get(Constant.TOKEN + userId));
				RedisUtil.del(Constant.USER + userId);
				RedisUtil.del(RedisConstant.ORDER_USER_BANK_STATE +  clientUserUpdatePhoneDTO.getPhone());
				RedisUtil.del(RedisConstant.ORDER_USER_REFERRER +  clientUserUpdatePhoneDTO.getPhone());
				RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO +  clientUserUpdatePhoneDTO.getPhone());
				RedisUtil.del(Constant.TOKEN + userId);
				RedisUtil.del(key);
				RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + user.getLoginId());
				// -- 调用法大大修改用户信息接口
				try {
					// -- 查询用户信息
					ClientAuthenticationDO authenticationDO = clientRedisUtil
							.getClientAuthenticationDO(user.getLoginId());
					if (StringUtils.isNotNullAndEmpty(authenticationDO.getCustomerId())) {
						fddService.invokeInfoChange(authenticationDO.getCustomerId(), null,
								clientUserUpdatePhoneDTO.getPhone(), authenticationDO.getId(), user.getId());
					}
				} catch (Exception e) {
					e.printStackTrace();
					log.error("法大大ca证书签约异常:" + e);
				}
			}
			response = new RestResponse(MsgErrCode.SUCCESS);
		}
		return response;
	}

	@Override
	public RestResponse updatePassword(ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO) throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		RestResponse response;
		String password = DesUtil.encrypt(clientUserUpdatePasswordDTO.getOldPassword());
		if (password.equals(user.getPassword())) {
			if (clientUserUpdatePasswordDTO.getNewPassword().equals(clientUserUpdatePasswordDTO.getOldPassword())) {
				response = new RestResponse(MsgErrCode.FAIL);
				response.setDescription("新密码不能与旧密码一致");
				return response;
			}
			ClientUserDO clientUserDO = new ClientUserDO();
			clientUserDO.setLoginName(user.getLoginId());
			clientUserDO.setModifyUser(user.getId());
			clientUserDO.setPassword(DesUtil.encrypt(clientUserUpdatePasswordDTO.getNewPassword()));
			clinetUserDao.updataClinetUser(clientUserDO);
			RedisUtil.del(Constant.USER + user.getLoginId());
			user.setPassword(password);
			RedisUtil.setex(Constant.USER + user.getLoginId(), user);
			response = new RestResponse(MsgErrCode.SUCCESS);
		} else {
			response = new RestResponse(NativeMsgErrCode.ERROR_PASSWORD);
		}
		return response;
	}

	@Override
	public void updateClientAllowableEntryTime(Long clientId, Integer dayNum) {
		log.info("调用修改客户可进件时长接口，clientId;" + clientId + ";dayNum:" + dayNum + "-----------");
		Map<String, Object> paraMap = new HashMap<>(1);
		paraMap.put("id", clientId);
		ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
		// -- 批贷 去掉进件限制
		ApplyClientInfoDO clientInfoDO = new ApplyClientInfoDO();
		if (dayNum == null) {
			clientInfoDO.setId(clientId);
		} else {
			Calendar ca = Calendar.getInstance();
			ca.add(Calendar.DATE, dayNum);
			Date date = ca.getTime();
			clientInfoDO.setId(clientId);
			clientInfoDO.setAllowableEntryTime(date);
		}
		clinetUserDao.updateApplyClientInFoAllowableEntryTime(clientInfoDO);
		RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + applyClientInfoDO.getPhone());
	}

	@Override
	public RestResponse checkID(String password) throws Exception {
		
		User loginUser = SessionUtil.getLoginUser(User.class);
		String password2 = loginUser.getPassword();
		if (!password2.equals(DesUtil.encrypt(password))) {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("密码不正确");
			return restResponse;
		}
		String uuid = UUIDUtil.getUUID();
		String phone = loginUser.getLoginId();
		RedisUtil.setex(RedisConstant.CHECK_USER_ADOPT.concat(loginUser.getLoginId()), 60 * 60, uuid);
		RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
		Map<String, String> result = new HashMap<String, String>();
		result.put("token", uuid);
		result.put("phone", phone);
		restResponse.setData(result);
		return restResponse;
	}

}
