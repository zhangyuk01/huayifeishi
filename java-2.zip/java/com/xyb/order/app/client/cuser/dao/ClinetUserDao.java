package com.xyb.order.app.client.cuser.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;

public interface ClinetUserDao {

	int insertClinetUser(ClientUserDO clientUserDO);

	int queryClientUserCount(String phone);

	int updataClinetUser(ClientUserDO clientUserDO);

	/**
	 * @description 获取用户信息
	 * @author xieqingyang
	 * @CreatedDate 2018/6/8 上午11:51
	 * @Version 1.0
	 * @param paraMap
	 *            根据不同查询方式传入不同参数
	 * @return 返回用户信息
	 */
	ApplyClientInfoDO getApplyClientInfo(Map<String, Object> paraMap);

	/**
	 * @description 修改用户信息
	 * @author xieqingyang
	 * @CreatedDate 2018/8/3 下午8:27
	 * @Version 1.0
	 * @param applyClientInfoDO
	 *            待修改信息
	 * @return 返回执行结果
	 */
	int updateApplyClientInfo(ApplyClientInfoDO applyClientInfoDO);

	/**
	 * @description 新增用户
	 * @author xieqingyang
	 * @CreatedDate 2018/8/3 下午8:27
	 * @Version 1.0
	 * @param applyClientInfoDO
	 *            新增信息
	 * @return 返回执行结果
	 */
	int insertApplyClientInfo(ApplyClientInfoDO applyClientInfoDO);

	/**
	 * @description 修改用户可进件时长 -- 批贷情况下
	 * @author xieqingyang
	 * @CreatedDate 2018/8/3 下午8:27
	 * @Version 1.0
	 * @param applyClientInfoDO
	 *            待修改数据
	 * @return 返回执行结果
	 */
	int updateApplyClientInFoAllowableEntryTime(ApplyClientInfoDO applyClientInfoDO);

	/**
	 * @description 根据登录手机号查询用户登录信息
	 * @author xieqingyang
	 * @CreatedDate 2018/5/22 下午7:21
	 * @Version 1.0
	 * @param loginName
	 * @return 返回银行卡信息
	 */
	ClientUserDO getClientUserByLoginName(String loginName);

	/**
	 * @description 根据银行编码查询bankType
	 * @author xieqingyang
	 * @CreatedDate 2018/5/22 下午5:31
	 * @Version 1.0
	 * @param bankcode
	 *            新网银行的银行编码
	 * @return 返回bankType
	 */
	Map<String, Object> getBankTypeByCode(String bankcode);

	/**
	 * 根据Id获取用户
	 * 
	 * @param id
	 * @return
	 */
	ClientUserDO getClientUserById(Long id);

	/**
	 * 根据推荐人Id获取源推荐人
	 * 
	 * @param recommendCode
	 * @return
	 */
	ClientUserDO getSorcClientUserByRecommendId(String id);

	/**
	 * 根据applyclienuserId获取clientuser
	 */
	ClientUserDO getClientUserByApplyClientUserId(@Param("id") Long id);
}
