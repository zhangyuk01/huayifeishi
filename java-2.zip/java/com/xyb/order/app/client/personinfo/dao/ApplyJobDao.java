package com.xyb.order.app.client.personinfo.dao;

import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.model.JobInfoDTO;
import com.xyb.order.app.client.personinfo.model.PrivateDO;
import com.xyb.order.app.client.personinfo.model.PrivateDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyJobDTO;

/**
 * @ClassName ApplyJobDao
 * @author ZhangYu
 * @date 2018年5月22号
 */
public interface ApplyJobDao {

	/**
	 * 根据申请单ID查询工作信息
	 * 
	 * @param applyId
	 * @return
	 */
	JobInfoDO getJobInfoByApplyId(Long applyId);

	/**
	 * 根据申请单ID查询私营信息
	 * 
	 * @param applyId
	 * @return
	 */
	PrivateDO getPrivateByApplyId(Long applyId);

	/**
	 * 根据ID跟新工作信息
	 * 
	 * @param id
	 */
	void updateJobInfoById(JobInfoDTO jobInfoDTO);

	/**
	 * 新增工作信息
	 * 
	 * @param jobInfoDTO
	 */
	void addJobInfo(JobInfoDTO jobInfoDTO);

	/**
	 * 根据ID修改私人信息
	 * 
	 * @param privateDTO
	 */
	void updatePrivateInfoById(PrivateDTO privateDTO);

	/**
	 * 新增私人信息
	 * 
	 * @param privateDTO
	 */
	void addPrivateInfo(PrivateDTO privateDTO);

	/**
	 * 更新速贷个人信息
	 * 
	 * @param jobInfo
	 */
	void updateQuickLoanJobInfoById(QuickLoanApplyJobDTO jobInfo);

	/**
	 * 新增速贷个人信息
	 * 
	 * @param jobInfo
	 */
	void addQuickLoanJobInfo(QuickLoanApplyJobDTO jobInfo);

}
