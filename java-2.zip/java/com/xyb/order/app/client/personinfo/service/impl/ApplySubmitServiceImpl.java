/**
 * 
 */
package com.xyb.order.app.client.personinfo.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MessageError;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import com.xyb.order.app.client.apply.dao.ApplyDao;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AuthorizationListVO;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.cuser.model.ApplyLoanOrgDO;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.app.client.personinfo.dao.ApplyJobDao;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.dao.ApplySubmitDao;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;
import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.service.ApplySubmitService;
import com.xyb.order.common.bank.service.BankService;
import com.xyb.order.common.constant.FileNameConstant;
import com.xyb.order.common.constant.MqConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.consultation.dao.ConsultationDao;
import com.xyb.order.pc.contract.dao.XybContractAuditDao;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.util.SessionUtil;

import net.sf.json.JSONObject;

/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.app.client.personinfo.service.impl
 * @description : TODO
 * @createDate : 2018年9月19日 下午4:10:47
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.app.client.personinfo.service.ApplySubmitService")
public class ApplySubmitServiceImpl implements ApplySubmitService {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplySubmitServiceImpl.class);
	
	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private CurrencyDao currencyDao;
    @Autowired
    private HomeDao homeDao;
    @Autowired
    private ApplySubmitDao applySubmitDao;
    @Reference
    private ForeignService foreignservice;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private ConsultationDao consultationDao;
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
    @Resource(name = "jmsQueueTemplate")
    private JmsTemplate jmsQueueTemplate;
	@Autowired
	private FileDataInfoService fileService;
	@Autowired
	private ApplyJobDao applyJobDao;
    @Autowired
    private BankService bankService;
    @Autowired
    private XybContractAuditDao xybContractAuditDao;
    @Autowired
    private ApplyDao applyDao;
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	@Override
	public RestResponse confirmSubmit(ApplySubmitDTO applySubmitDTO){
		 RestResponse response = null;
		 try {
				User user = SessionUtil.getLoginUser(User.class);
		        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
		        if (applyId == null) {
		            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		        }
				/**1.申请金额校验*/
				List<ProductExhibitionDO> exhibitionDOS = homeDao.queryProductExhibition(applySubmitDTO.getExpectProductId());
		    	BigDecimal endMaxAmount = exhibitionDOS.get(0).getMaxAmount();
		    	BigDecimal endMinAmount = exhibitionDOS.get(0).getMinAmount();
		    	/**1.1校验借款金额是否>=当前产品最低借款金额*/
		    	int compareMinNum = applySubmitDTO.getApplyAmount().compareTo(endMinAmount);
		    	if (compareMinNum == -1 ) {
		    		/**借款金额小于产品最低金额*/
		    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY_MIN);
				}
		    	//--需求调整,此处不校验预授权额度字段,以后可能会用到
//		    	/**1.2若预授权金额>当前产品最高金额,则 校验借款金额须<当前产品最高金额*/
//		    	int compareMaxNum = applySubmitDTO.getAccreditAmount().compareTo(endMaxAmount);
//		    	if (compareMaxNum == 1 ) {
//		    		int compareApplyNum = applySubmitDTO.getApplyAmount().compareTo(endMaxAmount);
//		    		if(compareApplyNum == 1){
//			    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY_MAX);
//		    		}
//				}
//		    	/**1.3若预授权金额<当前产品最高金额,则 校验借款金额须<预授权金额*/
//		    	int compareMaxNumTWO = applySubmitDTO.getAccreditAmount().compareTo(endMaxAmount);
//		    	if (compareMaxNumTWO == -1 ) {
//		    		int compareApplyNum = applySubmitDTO.getApplyAmount().compareTo(applySubmitDTO.getAccreditAmount());
//		    		if(compareApplyNum == 1){
//			    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY_ACCREDIT_MAX);
//		    		}
//				}
		    	/**1.2校验借款金额是否<当前产品最高金额*/
	    		int compareApplyNum = applySubmitDTO.getApplyAmount().compareTo(endMaxAmount);
	    		if(compareApplyNum == 1){
		    		return new RestResponse(NativeMsgErrCode.OUT_EXPECT_SALARY_MAX);
	    		}
				/**2.校验当前营业部是否支持当前申请产品*/
		        Map<String,Object> paraMapOne = new HashMap<>(2);
		        paraMapOne.put("orgId",applySubmitDTO.getOrgId());
		        paraMapOne.put("productId",applySubmitDTO.getExpectProductId());
		        int count = homeDao.getProductCountByOrg(paraMapOne);
		        if (count <= 0){
		            return new RestResponse(NativeMsgErrCode.UN_PRODUCTIDS_FOR_ORGID);
		        }
				/**3.修改图片为不可删除*/
				this.fileService.updateFileState(applyId,user.getId(),new ArrayList<String>(){{add(FileNameConstant.M0);}{add(FileNameConstant.A0);}{add(FileNameConstant.B0);}{add(FileNameConstant.C0);}{add(FileNameConstant.D0);}{add(FileNameConstant.E0);}{add(FileNameConstant.G0);}{add(FileNameConstant.H0);}{add(FileNameConstant.I0);}{add(FileNameConstant.J0);}{add(FileNameConstant.F0);}{add(FileNameConstant.L0);}{add(FileNameConstant.L0);}{add(FileNameConstant.K0);}});
				/**4.数据存储,流程跳转*/
		        AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
		        Map<String,Object> paraMap = new HashMap<>();
                paraMap.put("orgId",applySubmitDTO.getOrgId());
                paraMap.put("configItem",SysDictEnum.CONSULT_SWITCH.getCode());
                Long switchOrg = consultationDao.getOrgSwitch(paraMap);
                // -- 流程跳转
                ApplyBillMainInfoDO mainInfoDO = new ApplyBillMainInfoDO();
                mainInfoDO.setExpectMoney(applySubmitDTO.getApplyAmount());
                mainInfoDO.setExpectTerm(applySubmitDTO.getExpectTerm().intValue());
                mainInfoDO.setStoreOrgId(applySubmitDTO.getOrgId());
                if (SysDictEnum.CLOSE_SWITCH.getCode().equals(switchOrg)){
                    mainInfoDO.setId(authorizationListVO.getMainId());
                    mainInfoDO.setState(NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE);
                    paraMap.put("businessState",NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE);
                    paraMap.put("businessStateName","待分配客服");
                }else {
                    mainInfoDO.setId(authorizationListVO.getMainId());
                    mainInfoDO.setState(NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
                    paraMap.put("businessState",NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
                    paraMap.put("businessStateName","客服录入中");
                    Map<String,Object> resultMap = consultationDao.getService(applySubmitDTO.getOrgId());
                    if (resultMap == null || !resultMap.containsKey("id")){
                        return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
                    }else {
                        mainInfoDO.setServiceName((String) resultMap.get("name"));
                        mainInfoDO.setServiceUid((Long) resultMap.get("id"));
                    }
                    Map<String,Object> serviceManager = consultationDao.getServiceManager(mainInfoDO.getServiceUid());
                    if (serviceManager != null){
                        if (serviceManager.containsKey("id")) {
                            mainInfoDO.setServiveManagerUid((Long) serviceManager.get("id"));
                        }
                        if (serviceManager.containsKey("name")) {
                            mainInfoDO.setServiveManagerName((String) serviceManager.get("name"));
                        }
                    }
                }
                /**系统审核组装参数*/
                SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(authorizationListVO.getMainId(), NodeStateConstant.CLIENT_APPLY);
                if (systemAuditParamDTO == null) {
                    return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
                }
                systemAuditParamDTO.setSubmitUser(user.getName());
                systemAuditParamDTO.setSynOrAsy("asynchronous");
                mainInfoDO.setSubmitConsultTime(new Date());
                mainInfoDO.setModifyUser(user.getId());
                paraMap.put("mainId",authorizationListVO.getMainId());
                paraMap.put("modifyUser",user.getId());
                paraMap.put("modifyUserName",user.getName());
                /**更新系统日志*/
                currencyDao.insertMainLog(paraMap);
                /**更新主表信息*/
                currencyDao.updateMainInFo(mainInfoDO);
                /**更新申请表信息*/
                ApplyDTO applyDTO = new ApplyDTO();
                applyDTO.setApplyId(applyId);
                applyDTO.setExpectMoney(applySubmitDTO.getApplyAmount());
                applyDTO.setExpectProductId(applySubmitDTO.getExpectProductId());
                applyDTO.setBorrowDescCode(applySubmitDTO.getBorrowDescCode());
                applyDTO.setStoreOrgId(applySubmitDTO.getOrgId());
                applyDTO.setManagerId(mainInfoDO.getServiveManagerUid());
                applyDTO.setModifyTime(new Date());
                applyDTO.setModifyUser(user.getId());
                applyDao.updateBillInfo(applyDTO);
                jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION, JsonUtils.toJSON(systemAuditParamDTO));
                response = new RestResponse(MsgErrCode.SUCCESS);
            
		} catch (Exception e) {
			logger.error("确认借款提交失败" , e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	public RestResponse applySubmit() {
		 RestResponse response = null;
		 try {
			User user = SessionUtil.getLoginUser(User.class);
			Long loginUserId = user.getId(); 
			/**1.查询applyId是否存在*/
	        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
	        if (applyId == null) {
	            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
	        }
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", applyId);
			ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**2.校验必填项*/
			/**2.1校验基本信息*/
			/**2.1.1校验个人基本信息是否已填写*/
			ApplyPersonBaseInfoDO applyPersonBaseInfo = this.applyPersonDao.getApplyPersonBaseInfo(applyId);
			if(applyPersonBaseInfo == null){
				return new RestResponse(NativeMsgErrCode.UN_PERSON_BASE_INFO);
			}
			/**2.1.2校验联系人信息是否已填写*/
			Map<String, Object> paraMap = new HashMap<String, Object>();
			paraMap.put("applyId", applyId);
			paraMap.put("type", 1734);
			List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
			if (family == null || family.size() < 1) {
				return new RestResponse(NativeMsgErrCode.UN_FAMILY_CONTACT_INFO);
			}
			paraMap.put("type", 2092);
			List<Map<String, Object>> quick = this.applyPersonDao.getLinkManList(paraMap);
			if (quick == null || quick.size() < 2) {
				return new RestResponse(NativeMsgErrCode.UN_EMERGENCY_CONTACT_INFO);
			}
			paraMap.put("type", 1897);
			List<Map<String, Object>> work = this.applyPersonDao.getLinkManList(paraMap);
			if (work == null || work.size() < 1) {
				return new RestResponse(NativeMsgErrCode.UN_WORK_CONTACT_INFO);
			}
			/**2.1.3校验工作信息是否已填写*/
			JobInfoDO jobInfoDO = this.applyJobDao.getJobInfoByApplyId(applyId);
			if(jobInfoDO == null){
				return new RestResponse(NativeMsgErrCode.UN_WORK_INFO);
			}
			/**2.2校验银行卡信息是否已填写*/
			RestResponse bankResult = bankService.getBankCardState();
			JSONObject jsonObject = JSONObject.fromObject(bankResult.getData());
			if(jsonObject.getString("bank").equals("未绑卡")){
				return new RestResponse(NativeMsgErrCode.UN_BANK_CARD_INFO);
			}
			if(jsonObject.getString("bank").equals("申请变更中")){
				return new RestResponse(NativeMsgErrCode.UN_BANK_CARD_CHANGE);
			}
			if(jsonObject.getString("idCard").equals("认证已过期")){
				return new RestResponse(NativeMsgErrCode.ID_CARD_OUT_TIME);
			}
			/**2.3校验自我推荐图片信息是否已填写*/
			Boolean selfRecommedImg = false;
			List<Map<String,Object>> xybDataInfoList = xybContractAuditDao.getPicsByApplyId(applyId);
			if(null!=xybDataInfoList && xybDataInfoList.size()>0){
			    for(Map<String,Object> model:xybDataInfoList){
			    		String fileCode = (String) model.get("fileCode");
		    			if(fileCode.equals(SysDictEnum.IMAGE_TYPE_ZWTJ.getName())){
		    				/**已上传自我推荐图片*/
		    				selfRecommedImg = true;
		    				break;
			    		}
			    }
			 }
			if(!selfRecommedImg){
				return new RestResponse(NativeMsgErrCode.UN_IMG_ZWTJ);
			}
			/**2.4校验必附项信息是否已填写*/
	        AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
	        if (authorizationListVO == null){
	        	logger.info("失败,未查询到主表信息,applyId:"+applyId);
	            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
	        }else {
	            // -- 获取风控报告有效时间
	            Map<String,Integer> maps = null;
	            try {
	                maps = foreignservice.getAuthorizationValidTimeOfOrder();
	            }catch (Exception e){
	                logger.error("获取风控报告有效时间异常:",e);
	            }
	            if (maps == null){
	                maps = new HashMap<>(0);
	            }
	            List<AuthorizationProductDO> doList = authorizationDao.queryAuthorizationProduct(authorizationListVO.getProductId());
	            Map<String,Object> paraMapTwo = new HashMap<>();
	            int count;
	            for (AuthorizationProductDO AuthProductDO:doList){
	            	if(AuthProductDO.getIsAdditional().equals(SysDictEnum.NO.getCode())){
	            		continue;
	            	}
	            	paraMapTwo.put("authorizationType",AuthProductDO.getAuthorizationType());
	            	paraMapTwo.put("applyId",applyId);
	            	paraMapTwo.put("isSuccess",SysDictEnum.YES.getCode());
	                Integer time = maps.get(AuthProductDO.getAuthorizationType().toString());
	                paraMapTwo.put("time",time == null?1:time);
	                count = authorizationDao.getAuthorizationInfoCount(paraMapTwo);
	                if (count > 0){
	                	/**成功,跳出当前,继续循环*/
	                    continue;
	                }else {
	                    //authorizationResultVO.setResult("待授权");
	                	/**根据当前配置的三方必附类型获取对应的messageError*/
	                	MessageError messageError = null;
	                	switch (AuthProductDO.getAuthorizationType().intValue()) {
							case 2873:
								messageError = NativeMsgErrCode.UN_JUXINLI_REPORT;
								break;
							case 2874:
								messageError = NativeMsgErrCode.UN_JUXINLI_BAODAN;
								break;
							case 2875:
								messageError = NativeMsgErrCode.UN_RONG360_SHEBAO;
								break;
							case 2876:
								messageError = NativeMsgErrCode.UN_RONG360_GJJ;
								break;
							case 2877:
								messageError = NativeMsgErrCode.UN_RONG360_JBRH;
								break;
							case 2878:
								messageError = NativeMsgErrCode.UN_SUANHUA_REPORT;
								break;
						}
	                	paraMapTwo.remove("isSuccess");
	                    count = authorizationDao.getAuthorizationInfoCount(paraMapTwo);
	                    if (count > 0){
	                        if (SysDictEnum.EMPOWERMENT_SUCCESS.getCode().equals(AuthProductDO.getForceType())){
	                            /**授权类型为强制授权成功*/
	                        	return new RestResponse(messageError);
	                        }else {
	                        	/**授权类型为非强制授权成功,count>0 则为成功*/
	                        	continue;
	                        }
	                    }else {
	                    	/**未授权成功,返回对应的messageError*/
                        	return new RestResponse(messageError);
	                    }
	                }
	            }
	        }
			/**3.根据工作城市获取营业部信息*/
			/**3.1获取工作城市*/
			Long clientId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
			String jobCity = this.applySubmitDao.getCityName(clientId);
			/**3.2获取营业部*/
			List<ApplyLoanOrgDO> applyLoanOrgDOS = homeDao.queryApplyLoanOrg(jobCity);
			if(applyLoanOrgDOS != null && applyLoanOrgDOS.size() > 0){
				/**3.3获取当前查出来的营业部是否支持当前申请产品*/
				Map<String, Object> map = new HashMap<>(2);
				map.put("productId", applyMaInfo.getExpectProductId());
				map.put("list",applyLoanOrgDOS.stream().map(ApplyLoanOrgDO::getOrgId).collect(Collectors.toList()));
				List<Long> orgIds = homeDao.getOrgIdsByOrgIdsAndProDuctId(map);
				if(orgIds != null && orgIds.size() > 0){
					/**3.4筛选已配置该产品的营业部*/
					applyLoanOrgDOS = applyLoanOrgDOS.stream().filter(list -> orgIds.contains(list.getOrgId())).collect(Collectors.toList());
					return new RestResponse(MsgErrCode.SUCCESS,applyLoanOrgDOS);
				}else{
					return new RestResponse(NativeMsgErrCode.UN_ORGIDS_BY_PRODUCT);
				}
		 	}else{
				return new RestResponse(NativeMsgErrCode.UN_ORGIDS_BY_JOBCITY);
		 	}
		} catch (Exception e) {
			logger.error("提交申请失败" , e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return response;
	}

}
