/**
 * 
 */
package com.xyb.order.app.client.personinfo.dao;
/**
 * @author : houlvshuang
 * @projectName : order-service
 * @package : com.xyb.order.app.client.personinfo.dao
 * @description : TODO
 * @createDate : 2018年9月19日 下午5:44:00
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */

public interface ApplySubmitDao {
	
	String getCityName(Long clientId);
}
