package com.xyb.order.app.client.personinfo.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.app.client.authorization.model.FddClientApplyInFoDTO;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDTO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatcVO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatchDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyPersonInfoDTO;

/**
 * @ClassName ApplyPersonDao
 * @author ZhangYu
 * @date 2018年5月22号
 */
public interface ApplyPersonDao {

	/**
	 * 法大大需要的个人申请信息查询
	 * 
	 * @author xieqingyang
	 * @date 2018/8/1 下午5:45
	 * @version 1.0
	 * @param paraMap
	 *            传入参数
	 * @return 返回查询数据
	 */
	FddClientApplyInFoDTO getFddClientApplyInFo(Map<String, Object> paraMap);

	/**
	 * 根据登录ID查询申请单ID 客户申请中的
	 * 
	 * @param clientUserId
	 * @return
	 */
	Long getApplyIdByClientUserId(Long clientUserId);

	/**
	 * 根据登录ID用户app端校验
	 * 
	 * @param clientUserId
	 * @return
	 */
	Long getApplyIdByClientUserIdToCheck(Long clientUserId);

	/**
	 * 根据登录ID查询申请单ID 待授权的
	 * 
	 * @param clientUserId
	 * @return
	 */
	Long getApplyIdByClientId(Long clientUserId);

	/**
	 * 根据登录ID查询主表ID
	 * 
	 * @param clientUserId
	 * @return
	 */
	Long getMainIdByClientUserId(Long clientUserId);

	/**
	 * 根据登录ID和节点状态查询申请单ID
	 * 
	 * @author xieqingyang
	 * @date 2018/6/9 下午1:02
	 * @version 1.0
	 * @param paraMap
	 *            clientUserId 用户ID list（数组）节点状态
	 * @return 返回申请单ID
	 */
	Long getMainIdByClientUsrIdAndState(Map<String, Object> paraMap);

	/**
	 * 根据登录ID查询客户ID
	 * 
	 * @param clientUserId
	 * @return
	 */
	Long getCusIdByClientUserId(Long clientUserId);

	/**
	 * 获取个人基本基本信息
	 * 
	 * @return
	 */
	ApplyPersonBaseInfoDO getApplyPersonBaseInfo(Long applyId);

	/**
	 * 修改个人基本信息
	 * 
	 * @param applyPersonBaseInfoDTO
	 */
	void updateApplyPersonBaseInfoById(ApplyPersonBaseInfoDTO applyPersonBaseInfoDTO);

	/**
	 * 增加个人基本信息
	 * 
	 * @param applyPersonBaseInfoDTO
	 */
	void addApplyPersonBaseInfo(ApplyPersonBaseInfoDTO applyPersonBaseInfoDTO);

	/**
	 * 获取个人联系基本信息
	 * 
	 * @param applyId
	 * @return
	 */
	PersonBaseRelationInfoDO getPersonBaseRelationInfo(Long applyId);

	/**
	 * 查询联系人信息列表信息
	 * 
	 * @author xieqingyang
	 * @date 2018/5/30 下午6:59
	 * @version 1.0
	 * @param paraMap
	 *            申请单ID和联系人类型
	 * @return 返回app联系人列表信息 包含id、手机号、姓名
	 */
	List<Map<String, Object>> getLinkManList(Map<String, Object> paraMap);

	/**
	 * 根据联系人ID查询联系人信息
	 * 
	 * @param id
	 *            联系人ID
	 * @return
	 */
	LinkManRelationInfoDO getLinkManRelationInfo(Long id);

	/**
	 * 增加个人联系基本信息
	 * 
	 * @param personBaseRelationInfoDTO
	 */
	void addPersonBaseRelationInfo(PersonBaseRelationInfoDTO personBaseRelationInfoDTO);

	/**
	 * 修改个人联系基本信息
	 * 
	 * @param personBaseRelationInfoDTO
	 */
	void updatePersonBaseRelationInfo(PersonBaseRelationInfoDTO personBaseRelationInfoDTO);

	/**
	 * 新增联系人信息
	 * 
	 * @param list
	 */
	void addLinkManInfos(@Param("list") List<LinkManRelationInfoDTO> list);

	/**
	 * 修改联系人信息
	 * 
	 * @param list
	 */
	void updateLinkManInfos(@Param("list") List<LinkManRelationInfoDTO> list);

	/**
	 * 根据申请单ID查询个人信息ID
	 * 
	 * @param applyId
	 * @return
	 */
	Long getPersonIdByApplyId(Long applyId);

	/**
	 * 根据申请单ID查询工作信息ID
	 * 
	 * @param applyId
	 * @return
	 */
	Long getJobIdByApplyId(Long applyId);

	/**
	 * 新增联系人
	 * 
	 * @param bookDo
	 */
	void addPhoneBookInfo(PhoneBookDO bookDo);

	/**
	 * 判断是否要上传电话簿
	 * 
	 * @param params
	 * @param bean
	 * @return
	 */
	PhoneBookBatchDTO getPhoneBookAddressBatch(PhoneBookBatcVO bean);

	/**
	 * 获取联系人
	 * 
	 * @param params
	 * @return
	 */
	PhoneBookDTO getPhoneBookInfo(Map<String, Object> params);

	/**
	 * 将电话簿置为无效
	 */
	void updatePhoneBookByBatchId(@Param("batchId") Long batchId);

	/**
	 * 更新批次/日志表数量
	 */
	void updatePhoneAddressBatchById(Map<String, Object> params);

	/**
	 * 生成批次
	 * 
	 * @param dto
	 */
	void addPhoneBatch(PhoneBookBatchDTO dto);

	PhoneBookBatchDTO getPhoneBookAddressBatchById(@Param("batchId") Long batchId);

	int CountPhoneBookNumByBatchNum(@Param("batchId") Long batchId);

	/**
	 * 更新速贷个人信息
	 * 
	 * @param personInfo
	 */
	void updateQuickApplyPersonBaseInfoById(QuickLoanApplyPersonInfoDTO personInfo);

	/**
	 * 保存速贷个人信息
	 * 
	 * @param personInfo
	 */
	void addQuickApplyPersonBaseInfo(QuickLoanApplyPersonInfoDTO personInfo);

}
