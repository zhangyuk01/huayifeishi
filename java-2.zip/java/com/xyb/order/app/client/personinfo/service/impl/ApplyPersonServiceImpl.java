package com.xyb.order.app.client.personinfo.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.common.redis.RedisUtil;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDTO;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoVO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.LinkManRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDTO;
import com.xyb.order.app.client.personinfo.model.PersonalAddressDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatcVO;
import com.xyb.order.app.client.personinfo.model.PhoneBookBatchDTO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDO;
import com.xyb.order.app.client.personinfo.model.PhoneBookDTO;
import com.xyb.order.app.client.personinfo.service.ApplyPersonService;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.constant.MqConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.ApplyCommonProvinceDao;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.ChineseAddressParser;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.pc.applybill.dao.ApplyLinkmanInfoDao;
import com.xyb.order.pc.applybill.dao.ApplyPersonInfoDao;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDO;
import com.xyb.order.pc.applybill.model.ApplyFamilyChildrenDTO;
import com.xyb.order.pc.applybill.model.ApplyLinkmanInfoDO;
import com.xyb.util.SessionUtil;

/**
 * @ClassName ApplyPersonServiceImpl
 * @author ZhangYu
 * @date 2018年5月22号
 */
@Service(interfaceName = "com.xyb.order.app.client.personinfo.service.ApplyPersonService")
public class ApplyPersonServiceImpl implements ApplyPersonService {

	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private ApplyPersonInfoDao applyPersonInfoDao;
	@Autowired
	private ClientRedisUtil clientRedisUtil;
	@Autowired
	private ApplyCommonProvinceDao applyCommonProvinceDao;
	@Autowired
	private ApplyLinkmanInfoDao applyLinkmanInfoDao;

	@Resource(name = "jmsQueueTemplate")
	private JmsTemplate jmsQueueTemplate;

	@Override
	public RestResponse getApplyPersonBaseInfo() throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		String loginId = loginUser.getLoginId();
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		ApplyPersonBaseInfoDO applyPersonBaseInfo = null;
		ApplyPersonBaseInfoVO applyPersonBaseInfoVO = new ApplyPersonBaseInfoVO();
		ClientAuthenticationDO clientAuthenticationDO = this.clientRedisUtil.getClientAuthenticationDO(loginId);
		String idCard = clientAuthenticationDO.getIdCard();
		int idNOToAge = IdCardUtil.IdNOToAge(idCard);
		if (applyId != null) {
			applyPersonBaseInfo = this.applyPersonDao.getApplyPersonBaseInfo(applyId);
			Map<String, Object> queryChildMap = new HashMap<>();
			queryChildMap.put("applyId", applyId);
			queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
			List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao
					.queryFamilyChildrenList(queryChildMap);
			if (applyFamilyChildrenDOs != null && applyFamilyChildrenDOs.size() > 0) {
				applyPersonBaseInfo.setApplyFamilyChildrenDOs(applyFamilyChildrenDOs);
			}
		}
		applyPersonBaseInfoVO.setApplyAge(idNOToAge);
		applyPersonBaseInfoVO.setApplyPersonBaseInfoDO(applyPersonBaseInfo);
		return new RestResponse(MsgErrCode.SUCCESS, applyPersonBaseInfoVO);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdatePersonBaseInfo(ApplyPersonBaseInfoDTO applyPersonBaseInfoDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		List<ApplyFamilyChildrenDTO> familyChildrenList = applyPersonBaseInfoDTO.getApplyFamilyChildrenDTOs();
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		Long personId = this.applyPersonDao.getPersonIdByApplyId(applyId);
		applyPersonBaseInfoDTO.setId(personId);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil
				.getClientAuthenticationDO(loginUser.getLoginId());
		if (clientAuthenticationDO != null && clientAuthenticationDO.getAddress() != null) {
			PersonalAddressDTO p = ChineseAddressParser.chaifen(clientAuthenticationDO.getAddress());
			applyPersonBaseInfoDTO.setHomeTownProvince(p.getProvince());
			applyPersonBaseInfoDTO.setHomeTownCity(p.getCity());
			applyPersonBaseInfoDTO.setHomeTownArea(p.getArea());
			applyPersonBaseInfoDTO.setHomeTown(p.getAddress());
			applyPersonBaseInfoDTO.setHomeAllAddress(clientAuthenticationDO.getAddress());
			applyPersonBaseInfoDTO.setValidTime(clientAuthenticationDO.getIdCardEndTime());
		}
		/** 居住地址全地址 */
		String provinceLabel = this.applyCommonProvinceDao
				.getProvinceLabelByProvinceId(applyPersonBaseInfoDTO.getNowAddressProvince());
		String cityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(applyPersonBaseInfoDTO.getNowAddressCity());
		String areaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(applyPersonBaseInfoDTO.getNowAddressArea());
		String adress = applyPersonBaseInfoDTO.getNowAddress();
		String allAdress = provinceLabel + cityLabel + areaLabel + adress;
		/** 暂存个人信息 */
		if (applyPersonBaseInfoDTO.getId() != null) {
			applyPersonBaseInfoDTO.setPhone1(loginUser.getLoginId());
			applyPersonBaseInfoDTO.setModifyUser(loginUserId);
			applyPersonBaseInfoDTO.setNowAllAddress(allAdress);
			this.applyPersonDao.updateApplyPersonBaseInfoById(applyPersonBaseInfoDTO);
		} else {
			if (cusId == null) {
				return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
			}
			if (applyId == null) {
				return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
			}
			applyPersonBaseInfoDTO.setApplyId(applyId);
			applyPersonBaseInfoDTO.setCusId(cusId);
			applyPersonBaseInfoDTO.setCreateUser(loginUserId);
			applyPersonBaseInfoDTO.setPhone1(loginUser.getLoginId());
			applyPersonBaseInfoDTO.setNowAllAddress(allAdress);
			this.applyPersonDao.addApplyPersonBaseInfo(applyPersonBaseInfoDTO);
		}
		if (familyChildrenList != null && familyChildrenList.size() > 0) {
			/** 暂存家庭子女信息 **/
			Map<String, Object> queryChildMap = new HashMap<>();
			queryChildMap.put("applyId", applyId);
			queryChildMap.put("delFlag", SysDictEnum.IS_VALID.getCode());
			List<ApplyFamilyChildrenDO> applyFamilyChildrenDOs = this.applyPersonInfoDao
					.queryFamilyChildrenList(queryChildMap);

			List<ApplyFamilyChildrenDTO> addFamilyList = new ArrayList<>();
			List<ApplyFamilyChildrenDTO> updateFamilyList = new ArrayList<>();
			Map<String, Object> familyChildrenListMap = new HashMap<>();

			for (int i = 0; i < familyChildrenList.size(); i++) {
				familyChildrenListMap.put(String.valueOf(familyChildrenList.get(i).getId()),
						familyChildrenList.get(i).getAge());
			}
			Map<String, Object> applyFamilyChildrenDOsMap = new HashMap<>();
			for (ApplyFamilyChildrenDO familyChildrenDO : applyFamilyChildrenDOs) {
				applyFamilyChildrenDOsMap.put(String.valueOf(familyChildrenDO.getId()), familyChildrenDO.getAge());
			}
			for (ApplyFamilyChildrenDTO childrenDO : familyChildrenList) {
				if (StringUtils.isNullOrEmpty(childrenDO.getId())) {
					childrenDO.setApplyId(applyId);
					childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
					addFamilyList.add(childrenDO);
				} else {
					if (applyFamilyChildrenDOsMap.containsKey(String.valueOf(childrenDO.getId()))) {
						childrenDO.setDelFlag(SysDictEnum.IS_VALID.getCode());
						updateFamilyList.add(childrenDO);
					}
				}
			}
			for (int i = 0; i < applyFamilyChildrenDOs.size(); i++) {
				if (familyChildrenListMap.containsKey(String.valueOf(applyFamilyChildrenDOs.get(i).getId()))) {
					applyFamilyChildrenDOs.remove(i);
					i--;
				}
			}
			for (ApplyFamilyChildrenDO familyChildrenDO : applyFamilyChildrenDOs) {
				ApplyFamilyChildrenDTO applyFamilyChildrenDTO = new ApplyFamilyChildrenDTO();
				applyFamilyChildrenDTO.setDelFlag(SysDictEnum.NO_VALID.getCode());
				applyFamilyChildrenDTO.setAge(familyChildrenDO.getAge());
				applyFamilyChildrenDTO.setApplyId(familyChildrenDO.getApplyId());
				applyFamilyChildrenDTO.setId(String.valueOf(familyChildrenDO.getId()));
				updateFamilyList.add(applyFamilyChildrenDTO);
			}

			if (addFamilyList.size() > 0) {
				this.applyPersonInfoDao.addFamilyChildrenList(addFamilyList);
			}
			if (updateFamilyList.size() > 0) {
				this.applyPersonInfoDao.updateFamilyChildrenList(updateFamilyList);
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse getLinkPersonInfo() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(user.getId());
		PersonBaseRelationInfoDO personBaseRelationInfoDO = this.applyPersonDao.getPersonBaseRelationInfo(applyId);
		if (personBaseRelationInfoDO == null) {
			personBaseRelationInfoDO = new PersonBaseRelationInfoDO();
		}
		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("applyId", applyId);
		paraMap.put("type", 1734);
		List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
		paraMap.put("type", 2092);
		List<Map<String, Object>> quick = this.applyPersonDao.getLinkManList(paraMap);
		paraMap.put("type", 1897);
		List<Map<String, Object>> work = this.applyPersonDao.getLinkManList(paraMap);
		personBaseRelationInfoDO.setFamilyCount(family.size());
		personBaseRelationInfoDO.setWorkCount(work.size());
		personBaseRelationInfoDO.setQuickCount(quick.size());
		return new RestResponse(MsgErrCode.SUCCESS, personBaseRelationInfoDO);
	}

	@Override
	public RestResponse getApplyPersonRelationInfo(Long contactType) throws Exception {
		if (contactType == null) {
			return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
		}
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (applyId != null) {
			/** 家庭联系人 **/
			Map<String, Object> paraMap = new HashMap<String, Object>();
			paraMap.put("applyId", applyId);
			paraMap.put("type", contactType);
			List<Map<String, Object>> linkManRelationInfo = this.applyPersonDao.getLinkManList(paraMap);
			if (linkManRelationInfo == null || linkManRelationInfo.size() <= 0) {
				return new RestResponse(MsgErrCode.SUCCESS);
			} else {
				return new RestResponse(MsgErrCode.SUCCESS, linkManRelationInfo);
			}
		} else {
			return new RestResponse(MsgErrCode.FAIL);
		}
	}

	@Override
	public RestResponse getLinkManInfoById(Long id) throws Exception {
		if (id == null) {
			return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
		}
		LinkManRelationInfoDO linkManRelationInfoDO = applyPersonDao.getLinkManRelationInfo(id);
		if (linkManRelationInfoDO == null) {
			return new RestResponse(MsgErrCode.SUCCESS);
		} else {
			return new RestResponse(MsgErrCode.SUCCESS, linkManRelationInfoDO);
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse saveOrUpdateRelationInfo(LinkManRelationInfoDTO linkManRelationInfoDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (cusId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		List<LinkManRelationInfoDTO> addList = new ArrayList<>();
		List<LinkManRelationInfoDTO> updateList = new ArrayList<>();
		if (StringUtils.isNotNullAndEmpty(linkManRelationInfoDTO.getId())) {
			linkManRelationInfoDTO.setModifyUser(loginUserId);
			updateList.add(linkManRelationInfoDTO);
			this.applyPersonDao.updateLinkManInfos(updateList);
		} else {
			/**验证是否已经存在改手机号*/
			Map<String, Object> map = new HashMap<>(2);
			map.put("applyId", applyId);
			map.put("phone1", linkManRelationInfoDTO.getPhone1());
			ApplyLinkmanInfoDO applyLinkmanInfoDO = applyLinkmanInfoDao.getLinkInfoByApplyIdAndPhone1(map);
			if(applyLinkmanInfoDO != null){
				return new RestResponse(NativeMsgErrCode.ALREADY_PHONE1);
			}
			linkManRelationInfoDTO.setApplyId(applyId);
			linkManRelationInfoDTO.setCusId(cusId);
			linkManRelationInfoDTO.setCreateUser(loginUserId);
			linkManRelationInfoDTO.setModifyUser(loginUserId);
			addList.add(linkManRelationInfoDTO);
			this.applyPersonDao.addLinkManInfos(addList);
		}
		// 判断联系人是否在通讯录中
		PhoneBookDTO dto = new PhoneBookDTO();
		dto.setAddress(linkManRelationInfoDTO.getAllAddress());
		dto.setBatchNum(linkManRelationInfoDTO.getBatchNum());
		dto.setPhone(linkManRelationInfoDTO.getPhone1());
		dto.setPhoneType(linkManRelationInfoDTO.getPhoneType());
		dto.setName(linkManRelationInfoDTO.getName());
		queryAndAddPhoneBookInfo(dto);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdatePersonRelationInfo(PersonBaseRelationInfoDTO personBaseRelationInfoDTO)
			throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (cusId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("applyId", applyId);
		paraMap.put("type", 1734);
		List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
		if (family == null || family.size() < 1) {
			return new RestResponse(1, "请完整填写一个家庭联系人信息");
		}
		paraMap.put("type", 2092);
		List<Map<String, Object>> quick = this.applyPersonDao.getLinkManList(paraMap);
		if (quick == null || quick.size() < 2) {
			return new RestResponse(1, "请完整填写两个紧急联系人信息");
		}
		paraMap.put("type", 1897);
		List<Map<String, Object>> work = this.applyPersonDao.getLinkManList(paraMap);
		if (work == null || work.size() < 1) {
			return new RestResponse(1, "请完整填写一个工作联系人信息");
		}
		if (StringUtils.isNotNullAndEmpty(personBaseRelationInfoDTO.getId())) {
			personBaseRelationInfoDTO.setModifyUser(loginUserId);
			this.applyPersonDao.updatePersonBaseRelationInfo(personBaseRelationInfoDTO);
		} else {
			personBaseRelationInfoDTO.setApplyId(applyId);
			personBaseRelationInfoDTO.setCusId(cusId);
			personBaseRelationInfoDTO.setCreateUser(loginUserId);
			this.applyPersonDao.addPersonBaseRelationInfo(personBaseRelationInfoDTO);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 * 保存电话簿
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addPhoneBookInfos(PhoneBookBO phoneBookBO) throws Exception {
		// 加入消息队列
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		phoneBookBO.setUserId(userId);
		jmsQueueTemplate.convertAndSend(MqConstant.KEEP_PHONE_BOOKS, JsonUtils.toJSON(phoneBookBO));
		RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
		// 加入消息队列成功返回成功结果
		Map<String, Object> params = new HashMap<String, Object>();
		// 返回必要的批次编号
		params.put("batchNum", phoneBookBO.getBatchNum());
		response.setData(params);
		response.setDescription("成功");
		return response;
	}

	/**
	 * 查询是否需要上传通讯录
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse getPhoneBookAddressBatch(PhoneBookBatcVO phoneBookBatcVO) throws Exception {
		RestResponse response;
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		String redisKey = RedisConstant.PHONE_ADDRESS_BOOK_CHECK.concat(loginUser.getLoginId());
		// 30分钟内不再上传通讯录
		if (RedisUtil.exists(redisKey)) {
			// 已全部上传
			return new RestResponse(NativeMsgErrCode.ADDRESS_BOOK_UPLOADED);
		}
		if (null == phoneBookBatcVO.getShouldQty() || phoneBookBatcVO.getShouldQty() == 0) {
			// 已全部上传
			return new RestResponse(NativeMsgErrCode.ADDRESS_BOOK_UPLOADED);
		}
		// 保存查询标识
		RedisUtil.setex(redisKey, 30 * 60, loginUser.getLoginId());
		phoneBookBatcVO.setClientId(userId);
		// 查询是否存在批次
		PhoneBookBatchDTO phoneBookBatchDTO = this.applyPersonDao.getPhoneBookAddressBatch(phoneBookBatcVO);
		if (null != phoneBookBatchDTO) {
			Long id = phoneBookBatchDTO.getId();
			// 判断该批次是否已经上传了用户通讯录的全部数据
			if (phoneBookBatcVO.getShouldQty() <= phoneBookBatchDTO.getShouldQty()
					&& phoneBookBatchDTO.getActualQty() >= phoneBookBatchDTO.getShouldQty()) {
				// 已全部上传
				return new RestResponse(NativeMsgErrCode.ADDRESS_BOOK_UPLOADED);
			} else {
				// 未全部上传
				Map<String, Object> params = new HashMap<String, Object>();
				// 根据批次号获取通讯录全部数据
				params.put("mobilePhoneBatchId", id);
				PhoneBookDTO phoneBookInfo = this.applyPersonDao.getPhoneBookInfo(params);
				if (null != phoneBookInfo) {
					// 更新通讯置为无效
					this.applyPersonDao.updatePhoneBookByBatchId(id);
				}
				// 更新批次表数量
				params.clear();
				params.put("id", id);
				params.put("shouldQty", phoneBookBatcVO.getShouldQty());
				params.put("actualQty", "0");
				this.applyPersonDao.updatePhoneAddressBatchById(params);
				// 返回处理结果
				params.clear();
				params.put("batchNum", id);
				response = new RestResponse(MsgErrCode.SUCCESS);
				response.setData(params);
				response.setDescription("通讯录未上传");
				return response;
			}
		} else {
			// 批次不存在，生成新的批次，返回可以上传的标志
			Date date = new Date();
			// 生成批次
			phoneBookBatchDTO = new PhoneBookBatchDTO();
			phoneBookBatchDTO.setShouldQty(phoneBookBatcVO.getShouldQty());
			phoneBookBatchDTO.setActualQty(0);
			phoneBookBatchDTO.setClientId(userId);
			phoneBookBatchDTO.setCreateUser(userId);
			phoneBookBatchDTO.setCreateTime(date);
			phoneBookBatchDTO.setModifyUser(userId);
			phoneBookBatchDTO.setModifyTime(date);
			phoneBookBatchDTO.setPhoneType(phoneBookBatcVO.getPhoneType());
			this.applyPersonDao.addPhoneBatch(phoneBookBatchDTO);
			response = new RestResponse(MsgErrCode.SUCCESS);
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("batchNum", phoneBookBatchDTO.getId());
			response.setData(params);
			response.setDescription("通讯录未上传");
			return response;
		}

	}

	/**
	 * 新增联系人
	 */
	@Override
	public RestResponse queryAndAddPhoneBookInfo(PhoneBookDTO dto) throws Exception {
		RestResponse response;
		Map<String, Object> params = new HashMap<String, Object>();
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		PhoneBookBatchDTO phoneBookBatchDTO = null;
		PhoneBookBatcVO phoneBookBatcVO = new PhoneBookBatcVO();
		// 前台如果传了批次号根据批次号查询批次，否则根据用户的手机型号，clientId查询批次
		Long batchNum = dto.getBatchNum();
		if (null != batchNum) {
			phoneBookBatcVO.setBatchNum(dto.getBatchNum());
			phoneBookBatchDTO = this.applyPersonDao.getPhoneBookAddressBatchById(batchNum);
			if (null == phoneBookBatchDTO) {
				phoneBookBatcVO.setClientId(userId);
				phoneBookBatcVO.setPhoneType(dto.getPhoneType());
				phoneBookBatchDTO = this.applyPersonDao.getPhoneBookAddressBatch(phoneBookBatcVO);
			}
		} else {
			phoneBookBatcVO.setClientId(userId);
			phoneBookBatcVO.setPhoneType(dto.getPhoneType());
			phoneBookBatchDTO = this.applyPersonDao.getPhoneBookAddressBatch(phoneBookBatcVO);
		}
		// 如果批次不存在生成批次
		if (null == phoneBookBatchDTO) {
			Date date = new Date();
			// 生成批次
			phoneBookBatchDTO = new PhoneBookBatchDTO();
			phoneBookBatchDTO.setShouldQty(1);
			phoneBookBatchDTO.setActualQty(0);
			phoneBookBatchDTO.setClientId(userId);
			phoneBookBatchDTO.setCreateUser(userId);
			phoneBookBatchDTO.setCreateTime(date);
			phoneBookBatchDTO.setModifyUser(userId);
			phoneBookBatchDTO.setModifyTime(date);
			phoneBookBatchDTO.setPhoneType(phoneBookBatcVO.getPhoneType());
			this.applyPersonDao.addPhoneBatch(phoneBookBatchDTO);
		}
		batchNum = phoneBookBatchDTO.getId();
		// 判断联系人是否已存在
		params.put("phone", dto.getPhone());
		params.put("clientId", userId);
		params.put("mobilePhoneBatchId", phoneBookBatchDTO.getId());
		PhoneBookDTO phoneBookDTO = this.applyPersonDao.getPhoneBookInfo(params);
		if (null == phoneBookDTO) {
			Date date = new Date();
			PhoneBookDO bean = new PhoneBookDO();
			BeanUtils.copyProperties(dto, bean);
			bean.setClientId(userId);
			bean.setCreateUser(userId);
			bean.setCreateTime(date);
			bean.setModifyUser(userId);
			bean.setModifyTime(date);
			bean.setIsNew(2692L);
			bean.setMobilePhoneBatchId(batchNum);
			this.applyPersonDao.addPhoneBookInfo(bean);
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setDescription("联系人新增成功");
			// 更新上传批次次数
			params.clear();
			params.put("id", batchNum);
			params.put("actualQty", phoneBookBatchDTO.getActualQty() + 1);
			this.applyPersonDao.updatePhoneAddressBatchById(params);
			return response;

		} else {
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setDescription("联系人新增成功");
			return response;
		}
	}

}
