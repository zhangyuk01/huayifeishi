package com.xyb.order.app.client.personinfo.service.impl;

import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.personinfo.dao.ApplyJobDao;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.model.JobInfoDTO;
import com.xyb.order.app.client.personinfo.model.PrivateDO;
import com.xyb.order.app.client.personinfo.model.PrivateDTO;
import com.xyb.order.app.client.personinfo.service.ApplyJobService;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.util.SessionUtil;

/**
 * @ClassName ApplyJobServiceImpl
 * @author ZhangYu
 * @date 2018年5月22号
 */
@Service(interfaceName = "com.xyb.order.app.client.personinfo.service.ApplyJobService")
public class ApplyJobServiceImpl implements ApplyJobService{

	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private ApplyJobDao applyJobDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private ClientRedisUtil clientRedisUtil;

	@Override
	public RestResponse getApplyJobInfo() throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId(); 
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		JobInfoDO jobInfoDO = this.applyJobDao.getJobInfoByApplyId(applyId);
		if (jobInfoDO == null){
			jobInfoDO = new JobInfoDO();
		}
		jobInfoDO.setApplyId(applyId);
		return new RestResponse(MsgErrCode.SUCCESS, jobInfoDO);
	}
	
	@Override
	public RestResponse getPrivateInfo() throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId(); 
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		PrivateDO privateDO = this.applyJobDao.getPrivateByApplyId(applyId);
		if (privateDO == null){
			return new RestResponse(MsgErrCode.SUCCESS);
		}else {
			return new RestResponse(MsgErrCode.SUCCESS, privateDO);
		}
	}
	

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addOrUpdateJobInfo(JobInfoDTO jobInfoDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		Long jobId = this.applyPersonDao.getJobIdByApplyId(applyId);
		jobInfoDTO.setId(jobId);
		if (cusId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		if (jobInfoDTO.getId() != null) {
			jobInfoDTO.setModifyUser(loginUserId);			
			this.applyJobDao.updateJobInfoById(jobInfoDTO);
		}else{
			jobInfoDTO.setCreateUser(loginUserId);
			jobInfoDTO.setModifyUser(loginUserId);
			jobInfoDTO.setApplyId(applyId);
			jobInfoDTO.setCusId(cusId);
			this.applyJobDao.addJobInfo(jobInfoDTO);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse addOrUpdatePrivateInfo(PrivateDTO privateDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId(); 
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (cusId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		if (StringUtils.isNotNullAndEmpty(privateDTO.getId())) {
			privateDTO.setCreateUser(loginUserId);
			privateDTO.setModifyUser(loginUserId);
			this.applyJobDao.updatePrivateInfoById(privateDTO);
		}else{
			privateDTO.setCreateUser(loginUserId);
			privateDTO.setModifyUser(loginUserId);
			privateDTO.setApplyId(applyId);
			privateDTO.setCusId(cusId);
			this.applyJobDao.addPrivateInfo(privateDTO);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

//	@Override
//	public RestResponse onSubmit() throws Exception {
//		User user = SessionUtil.getLoginUser(User.class);
//		// -- 上线打开
//		/**验证是否签约个人信息授权协议*/
//		// -- 客户认证相关信息
//		ClientAuthenticationDO authenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
////		if (!SysDictEnum.HAVE_SUGNED_CONTRACT.getCode().equals(authenticationDO.getAgreementCompleted())){
////			return new RestResponse(NativeMsgErrCode.PLEASE_SIGN_AGREEMENT);
////		}
//		/**------跳转流程节点--------*/
//		/**查询主表ID*/
//		Long mainId = applyPersonDao.getMainIdByClientUserId(user.getId());
//		if (mainId == null) {
//			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
//		}
//		/**修改主表状态**/
//		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
//		applyBillMainInfoDO.setId(mainId);
//		applyBillMainInfoDO.setState(NodeStateConstant.TO_BE_PRETRIAL);
//		applyBillMainInfoDO.setModifyUser(user.getId());
//		/**添加主表修改日志**/
//		MainLogDTO mainLogDTO = new MainLogDTO();
//		mainLogDTO.setMainId(mainId);
//		mainLogDTO.setModifyUser(user.getId());
//		mainLogDTO.setModifyUserName(user.getName());
//		mainLogDTO.setBusinessState(NodeStateConstant.TO_BE_PRETRIAL);
//		mainLogDTO.setBusinessStateName("待授权");
//		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
//		this.currencyDao.addMainLog(mainLogDTO);
//		return new RestResponse(MsgErrCode.SUCCESS);
//	}
}
