package com.xyb.order.app.client.personalcenter.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.app.client.cuser.model.ApplyClientInfoDTO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDO;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDTO;
import com.xyb.order.app.client.personalcenter.model.CommonProblemDTO;
import com.xyb.order.app.client.personalcenter.model.MyBalanceDTO;
import com.xyb.order.app.client.personalcenter.model.MyFriendsDO;
import com.xyb.order.app.client.personalcenter.model.PersonalInfoDTO;
import com.xyb.order.app.client.personalcenter.model.RewardDistributionRuleDO;

/**
 * 
 * @author qiaoJinLong
 * @date 2018年9月13日
 */
public interface PersonalCenterDao {

	/**
	 * 获取个人信息
	 * 
	 * @param id
	 * @return
	 */
	PersonalInfoDTO getPersonalInfoByClientUser(@Param("loginName") String loginName);

	/**
	 * 获取登陆信息
	 * 
	 * @param loginName
	 * @return
	 */
	ClientUserDO getClientUserByLoginName(@Param("loginName") String loginName);

	/**
	 * 添加推荐人
	 * 
	 * @param user
	 */
	void updateClientUserByLoginName(ClientUserDO user);

	/**
	 * 获取我的好友
	 * 
	 * @param id
	 * @return
	 */
	List<MyFriendsDO> getMyFriends(@Param("id") Long id);

	/**
	 * 获取疑难解答列表
	 * 
	 * @param params
	 * @return
	 */
	List<CommonProblemDTO> getProblem(@Param("pageSize") Integer pageSize);

	/**
	 * 根据Id获取疑难解答
	 * 
	 * @param id
	 * @return
	 */
	CommonProblemDTO getProblemById(@Param("id") Long id);

	/**
	 * 根据id更新点击次数
	 * 
	 * @param dto
	 */
	void updateProblemById(CommonProblemDTO dto);

	/**
	 * 根据Id获取登陆信息
	 * 
	 * @param clientUserId
	 * @return
	 */
	ClientUserDO getClientUserById(@Param("id") Long id);

	/**
	 * 获取奖励分配规则
	 * 
	 * @return
	 */
	RewardDistributionRuleDO getRewardDistributionRule();

	/**
	 * 获取客户信息
	 * 
	 * @param id
	 * @return
	 */
	ApplyClientInfoDTO getApplyClientInfoByClientId(@Param("clientUserId") Long clientUserId);

	/**
	 * 更新客户余额
	 * 
	 * @param fristClientInfo
	 */
	void updateApplyClientInfoById(ApplyClientInfoDTO fristClientInfo);

	/**
	 * 插入流水
	 * 
	 * @param fristBalanceDetail
	 */
	void insertClientProfitBalanceDetail(ClientProfitBalanceDetailDO fristBalanceDetail);

	/**
	 * 获取产品期数
	 * 
	 * @param clientUserId
	 * @return
	 */
	int getProductlimit(@Param("clientUserId") Long clientUserId);

	/**
	 * 获取推荐人
	 * 
	 * @param clientUserId
	 * @return
	 */
	ClientUserDO getClientUserByRefereeId(@Param("refereeId") Long refereeId);

	/**
	 * 查询我的余额
	 * 
	 * @param loginId
	 * @return
	 */
	MyBalanceDTO queryBalanceByLongId(@Param("loginId") String loginId);

	/**
	 * 获取我的流水
	 * 
	 * @param dto
	 * @return
	 */
	List<ClientProfitBalanceDetailDO> queryClientProfitBalanceDetailPage(ClientProfitBalanceDetailDTO dto);

	/**
	 * 判断当前用户是否能设置推荐人
	 * 
	 * @param list
	 * @return
	 */
	int countMainByloginName(@Param("loginName") String loginName);

}
