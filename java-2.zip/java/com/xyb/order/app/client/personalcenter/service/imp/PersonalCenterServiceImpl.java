package com.xyb.order.app.client.personalcenter.service.imp;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.beiming.kun.framework.model.Page;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.fr.base.Base64;
import com.xyb.auth.constant.Constant;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDTO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.personalcenter.dao.PersonalCenterDao;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDO;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailDTO;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailPage;
import com.xyb.order.app.client.personalcenter.model.ClientProfitBalanceDetailVO;
import com.xyb.order.app.client.personalcenter.model.CommonProblemDTO;
import com.xyb.order.app.client.personalcenter.model.MyBalanceDTO;
import com.xyb.order.app.client.personalcenter.model.MyFriendsDO;
import com.xyb.order.app.client.personalcenter.model.PersonalInfoDTO;
import com.xyb.order.app.client.personalcenter.model.RewardDistributionDTO;
import com.xyb.order.app.client.personalcenter.model.RewardDistributionRuleDO;
import com.xyb.order.app.client.personalcenter.service.PersonalCenterService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.message.dao.MessageDao;
import com.xyb.order.common.message.model.MessageChannelDO;
import com.xyb.order.common.message.model.MessageCodeDTO;
import com.xyb.order.common.message.model.MessageTemplateDO;
import com.xyb.order.common.message.model.SendMessageLogDTO;
import com.xyb.order.common.message.model.SendMessageVerificationDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.MDClient;
import com.xyb.order.common.util.MessageCountStr;
import com.xyb.order.common.util.PosMainStart;
import com.xyb.order.common.util.RandomUtil;
import com.xyb.util.SessionUtil;

/**
 * 我的/个人中心serviceImpl
 * 
 * @author qiaoJinLong
 * @date 2018年9月13日
 */
@Service(interfaceName = "com.xyb.order.app.client.personalcenter.service.PersonalCenterService")
public class PersonalCenterServiceImpl implements PersonalCenterService {
	private static final Logger log = LoggerFactory.getLogger(PersonalCenterServiceImpl.class);
	@Autowired
	private PersonalCenterDao personalCenterDao;

	@Autowired
	private MessageDao messageDao;

	@Autowired
	private ClinetUserDao clinetUserDao;

	@Value("${make.user.share.url}")
	private String USER_SHARE_URL;

	/**
	 * 个人信息
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse getPersonalInfo() throws Exception {
		RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
		// 获取个人信息
		User loginUser = SessionUtil.getLoginUser(User.class);
		PersonalInfoDTO dto = personalCenterDao.getPersonalInfoByClientUser(loginUser.getLoginId());
		response.setData(dto);
		return response;
	}

	/**
	 * 发送验证码
	 */
	@Override
	public RestResponse SendMessageVerification(SendMessageVerificationDTO messageDTO) throws Exception {
		ClientUserDO userDo = this.personalCenterDao.getClientUserByLoginName(messageDTO.getPhone());
		if (null == userDo) {
			return new RestResponse(NativeMsgErrCode.ACCOUNTNOTREGISTERED);
		}
		if (userDo.getState() == 2687) {
			return new RestResponse(NativeMsgErrCode.NO_OPEN_ACCOUNT);
		}
		int effectiveNum = 0;
		Map<String, Object> paraMap = new HashMap<>();
		paraMap.put("messageTypeId", messageDTO.getMessageTypeId());
		paraMap.put("phone", messageDTO.getPhone());
		paraMap.put("create", getDateString());
		if (CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_102 == messageDTO.getMessageTypeId()
				|| CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_103 == messageDTO.getMessageTypeId()
				|| CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_104 == messageDTO.getMessageTypeId()
				|| CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_105 == messageDTO.getMessageTypeId()) {
			if (messageDTO.getEffectiveNum() == null) {
				effectiveNum = CurrencyConstant.MESSAGE_UP_COUNT;
			}
			int count = messageDao.queryMessageCount(paraMap);
			if (count >= effectiveNum) {
				return new RestResponse(NativeMsgErrCode.EXCEED_UPPER_LIMIT);
			}
		}
		User user = SessionUtil.getLoginUser(User.class);
		paraMap.put("type", CurrencyConstant.MESSAGE_LIST_CURRENCY);
		// -- 查询短信模版
		MessageTemplateDO messageTemplate = messageDao.getMessageTemplateByType(paraMap);
		if (messageTemplate == null) {
			return new RestResponse(NativeMsgErrCode.NO_TEMPLATES_AVAILABLE_FOR_TIME_BEING);
		}
		// -- 保存验证码
		Long userId = CurrencyConstant.SYSTEM_USER;
		String vCode = RandomUtil.getSix();
		String content = messageTemplate.getValue();
		content = content.replace("vCode", vCode);
		MessageCodeDTO messageCodeDTO = new MessageCodeDTO();
		messageCodeDTO.setPhone(messageDTO.getPhone());
		messageCodeDTO.setType(CurrencyConstant.MESSAGE_LIST_CURRENCY);
		messageCodeDTO.setCode(vCode);
		if (user != null && user.getId() != null) {
			userId = user.getId();
			messageCodeDTO.setOperationUser(userId);
		} else {
			messageCodeDTO.setOperationUser(CurrencyConstant.SYSTEM_USER);
		}
		messageCodeDTO.setState(CurrencyConstant.MESSAGE_IS_VALID);
		int messageCodeCount = messageDao.addMessageCode(messageCodeDTO);
		if (messageCodeCount != 1) {
			return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
		}
		paraMap.put("state", CurrencyConstant.CHANNEL_MESSAGE_NO_VALID);
		// -- 查询短信渠道商
		MessageChannelDO messageChannelDO = messageDao.getMessageChannelIsvalid(paraMap);
		if (messageChannelDO == null) {
			return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
		}
		if (messageChannelDO.getId() == CurrencyConstant.MESSAGE_CHANNEL_MD) {
			RedisUtil.setex(RedisConstant.USER_LOGIN_SMS_CODE.concat(messageDTO.getPhone()), 60, vCode);
			return sendMessageMD(messageChannelDO, messageDTO.getPhone(), content, messageTemplate, userId);
		} else {
			return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
		}
	}

	/**
	 * 获得当前时间年月日
	 * 
	 * @return
	 */
	private String getDateString() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		return simpleDateFormat.format(new Date());
	}

	/**
	 * 漫道发送短信
	 * 
	 * @return
	 */
	private RestResponse sendMessageMD(MessageChannelDO messageChannelDO, String phone, String content,
			MessageTemplateDO messageTemplate, long userId) {
		String sn = messageChannelDO.getChannelKey();
		String password = messageChannelDO.getChannelPassword();
		String serviceURL = messageChannelDO.getChannelAddress();
		MDClient mdClient = null;
		try {
			mdClient = new MDClient(sn, password, serviceURL);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String messageText = null;
		try {
			messageText = URLEncoder.encode(content, "utf8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String resultMt = mdClient.mdsmssend(phone, messageText, "", "", "", "");
		// -- 保存短信发送记录
		SendMessageLogDTO sendMessageLog = new SendMessageLogDTO();
		sendMessageLog.setPhone(phone);
		sendMessageLog.setReturnValue(resultMt);
		sendMessageLog.setMessageChannel(String.valueOf(messageChannelDO.getId()));
		sendMessageLog.setMessageTemplateId(messageTemplate.getId());
		sendMessageLog.setMessageTypeId(messageTemplate.getMessageTypeId());
		sendMessageLog.setOperationUser(userId);
		sendMessageLog.setValueCount(String.valueOf(MessageCountStr.countSum(content)));
		int sendMessageLogCount = messageDao.addSendMessageLog(sendMessageLog);
		if (sendMessageLogCount != 1) {
			return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
		}
		// -- 判断短信接口是否调用成功
		boolean flag = mdClient.isNumeric(resultMt);
		if (flag) {
			return new RestResponse(MsgErrCode.SUCCESS);
		} else {
			return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
		}
	}

	/**
	 * 添加推荐人
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse addReferee(String phone) throws Exception {
		RestResponse restResponse = null;
		User loginUser = SessionUtil.getLoginUser(User.class);

		if (StringUtils.isEmpty(phone)) {
			restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("推荐人手机号不能为空！");
			return restResponse;
		}
		// 推荐人不能是本人
		if (loginUser.getLoginId().equals(phone)) {
			restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("推荐人不合法！");
			return restResponse;
		}
		// 获取推荐人
		ClientUserDO user = clinetUserDao.getClientUserByLoginName(phone);
		if (null == user) {
			restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("推荐人不存在！");
			return restResponse;
		}
		// 判断是否互为联系人
		if (!StringUtils.isEmpty(user.getRecommendCode())
				&& loginUser.getId().toString().equals(user.getRecommendCode())) {
			restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("推荐人不合法！");
			return restResponse;
		}
		// 获取源推荐人
		Long sorc = null;
		if (null != user) {
			String recommendCode = user.getRecommendCode();
			if (null != user.getSorcRecommend()) {
				sorc = user.getSorcRecommend();
			} else {
				if (null == recommendCode) {
					sorc = user.getId();
				} else {
					// 根据推荐人id获取源推荐人
					ClientUserDO userDo = clinetUserDao.getSorcClientUserByRecommendId(recommendCode);
					if (null != userDo) {
						sorc = userDo.getId();
					}

				}
			}
		}
		// 保存推荐人
		ClientUserDO clientUser = new ClientUserDO();
		clientUser.setLoginName(loginUser.getLoginId());
		clientUser.setRecommendCode(String.valueOf(user.getId()));
		clientUser.setSorcRecommend(sorc);
		personalCenterDao.updateClientUserByLoginName(clientUser);
		// 更新主表
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("clientUserId", loginUser.getId());
		ApplyClientInfoDO applyClientInfo = clinetUserDao.getApplyClientInfo(params);
		applyClientInfo.setLeader(sorc);
		applyClientInfo.setReferee(user.getId());
		clinetUserDao.updateApplyClientInfo(applyClientInfo);
		// 更新缓存
		loginUser.setRecommendCode(String.valueOf(user.getId()));
		RedisUtil.setex(Constant.USER + loginUser.getLoginId(), loginUser);
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	/**
	 * 获取我的好友与推荐人
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse getMyFriendsAndReferee() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		Long id = user.getId();
		// 获取我的好友
		List<MyFriendsDO> myFriends = personalCenterDao.getMyFriends(id);
		// 存放返回结果
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("friends", myFriends);
		// 获取我的推荐人
		PersonalInfoDTO personalInfoByClientUser = personalCenterDao.getPersonalInfoByClientUser(user.getLoginId());
		if (null != personalInfoByClientUser) {
			Map<String, String> referee = new HashMap<String, String>();
			referee.put("name", personalInfoByClientUser.getRefereeName());
			referee.put("phone", personalInfoByClientUser.getRefereePhone());
			result.put("referee", referee);
		} else {
			result.put("referee", null);

		}
		RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
		response.setData(result);
		return response;
	}

	/**
	 * 获取疑难解答列表
	 */
	@SuppressWarnings("unchecked")
	@Override
	public RestResponse getProblem(Integer num) throws Exception {
		List<CommonProblemDTO> list = null;
		if (num != 0) {
			// redis中获取列表
			String jsonString = RedisUtil.get(RedisConstant.COMMON_PROBLEM_HOME);
			list = (List<CommonProblemDTO>) JSON.parse(jsonString);
			if (null == list || list.size() == 0) {
				list = personalCenterDao.getProblem(num);
				if (null != list && list.size() > 0) {
					RedisUtil.setex(RedisConstant.COMMON_PROBLEM_HOME, 60 * 60 * 12, list);
				}
			}
			if (num != list.size()) {
				list = personalCenterDao.getProblem(num);
				RedisUtil.setex(RedisConstant.COMMON_PROBLEM_HOME, 60 * 60 * 12, list);
			}
		} else {
			list = personalCenterDao.getProblem(num);
		}
		RestResponse response = new RestResponse(MsgErrCode.SUCCESS);
		response.setData(list);
		return response;
	}

	/**
	 * 更新点击数
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateClicks(Long id) throws Exception {
		CommonProblemDTO dto = personalCenterDao.getProblemById(id);
		if (null != dto) {
			Integer clicks = dto.getClicks();
			clicks += 1;
			dto.setClicks(clicks);
			personalCenterDao.updateProblemById(dto);
			return new RestResponse(MsgErrCode.SUCCESS);
		} else {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("数据不存在，更新失败");
			return restResponse;
		}

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateUserRefereeReward(RewardDistributionDTO dto) throws Exception {

		// 获取t_clien_user
		Long applyClientId = dto.getClientId();
		if (null == applyClientId) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("clientId不能为空！");
			return response;
		}
		// 获取applyClientId
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", applyClientId);
		ApplyClientInfoDO applyClientInfo = clinetUserDao.getApplyClientInfo(params);

		if (null == applyClientInfo || applyClientInfo.getClientUserId() == null) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("客户不存在！");
			return response;
		}
		Long clientUserId = applyClientInfo.getClientUserId();
		BigDecimal contractMoney = dto.getContractMoney();
		Long financePaymentId = dto.getFinancePaymentId();
		ClientUserDO clientUser = personalCenterDao.getClientUserById(clientUserId);
		if (null == clientUser) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("客户不存在！");
			return response;
		}
		if (null == clientUser.getRecommendCode()) {
			return new RestResponse(MsgErrCode.SUCCESS);
		}
		// 获取当前客户的信息
		ApplyClientInfoDTO clientInfo = personalCenterDao.getApplyClientInfoByClientId(clientUserId);
		if (null == clientInfo) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("客户信息不存在！");

		}
		// 更新成功借款次数
		Integer loanQty = clientInfo.getLoanQty();
		loanQty += 1;
		clientInfo.setLoanQty(loanQty);
		// clientInfo.setModifyUser(user.getId());
		// 更新当前用户信息
		personalCenterDao.updateApplyClientInfoById(clientInfo);

		// 获取我的推荐人
		ClientUserDO myRefereeUser = personalCenterDao.getClientUserById(Long.valueOf(clientUser.getRecommendCode()));
		if (null != myRefereeUser) {
			ClientUserDO fristRefereeUser = null;
			// 获取二级推荐人，若没有二级推荐人，我的推荐人即一级推荐人
			if (null != myRefereeUser.getRecommendCode()) {
				fristRefereeUser = personalCenterDao.getClientUserById(Long.valueOf(myRefereeUser.getRecommendCode()));
			}
			// 获取分配奖励规则
			RewardDistributionRuleDO rule = personalCenterDao.getRewardDistributionRule();
			if (null != rule) {

				// 总的分配金额
				BigDecimal totalMoney = contractMoney.multiply(new BigDecimal(rule.getTotalRate())).setScale(2,
						BigDecimal.ROUND_DOWN);

				// 总的推荐分配奖励
				BigDecimal recommendTotalMoney = totalMoney.multiply(new BigDecimal(rule.getRecommendRate()))
						.setScale(2, BigDecimal.ROUND_DOWN);

				// 存在一级推荐人
				if (null != fristRefereeUser) {
					// 一级推荐人奖励即我的推荐人
					BigDecimal recommendOneMoney = recommendTotalMoney
							.multiply(new BigDecimal(rule.getOneRecommendRate())).setScale(2, BigDecimal.ROUND_DOWN);
					// 更新余额、流水
					updateUserRefereeReward(financePaymentId, myRefereeUser.getId(), recommendOneMoney, 1);

					// 二级推荐人
					BigDecimal recommendTwoMoney = recommendTotalMoney
							.multiply(new BigDecimal(rule.getTwoRecommendRate())).setScale(2, BigDecimal.ROUND_DOWN);
					// 更新余额、流水
					updateUserRefereeReward(financePaymentId, fristRefereeUser.getId(), recommendTwoMoney, 1);
				}
				// 不存在一级推荐人
				else {
					updateUserRefereeReward(financePaymentId, myRefereeUser.getId(), recommendTotalMoney, 1);
				}
			}

		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse updateUserQualityReward(RewardDistributionDTO dto) throws Exception {

		// 获取t_clien_user
		Long applyClientId = dto.getClientId();
		if (null == applyClientId) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("clientId不能为空！");
			return response;
		}
		// 获取applyClientId
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", applyClientId);
		ApplyClientInfoDO applyClientInfo = clinetUserDao.getApplyClientInfo(params);

		if (null == applyClientInfo || applyClientInfo.getClientUserId() == null) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("客户不存在！");
			return response;
		}
		Long clientUserId = applyClientInfo.getClientUserId();

		BigDecimal contractMoney = dto.getContractMoney();
		Long financePaymentId = dto.getFinancePaymentId();
		ClientUserDO clientUser = personalCenterDao.getClientUserById(clientUserId);
		if (null == clientUser) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("客户不存在！");
			return response;
		}
		if (null == clientUser.getRecommendCode()) {
			return new RestResponse(MsgErrCode.SUCCESS);
		}
		// 获取产品期数
		int limit = personalCenterDao.getProductlimit(clientUserId);

		if (limit < 1) {
			RestResponse response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("产品期数不存在！");
			return response;
		}
		// 获取我的推荐人
		ClientUserDO myRefereeUser = personalCenterDao.getClientUserById(Long.valueOf(clientUser.getRecommendCode()));
		if (null != myRefereeUser) {
			ClientUserDO fristRefereeUser = null;
			// 获取一级推荐人，若没有一级推荐人，我的推荐人即一级推荐人
			if (null != myRefereeUser.getRecommendCode()) {
				fristRefereeUser = personalCenterDao.getClientUserById(Long.valueOf(myRefereeUser.getRecommendCode()));
			}
			// 获取分配奖励规则
			RewardDistributionRuleDO rule = personalCenterDao.getRewardDistributionRule();

			// 总的分配金额
			BigDecimal totalMoney = contractMoney.multiply(new BigDecimal(rule.getTotalRate())).setScale(2,
					BigDecimal.ROUND_DOWN);

			// 总的质保奖励
			BigDecimal qualityTotalMoney = totalMoney.multiply(new BigDecimal(rule.getQualityRate())).setScale(2,
					BigDecimal.ROUND_DOWN);
			// 每一期的质保奖励
			BigDecimal qualityLimitMoney = qualityTotalMoney.divide(new BigDecimal(limit), 2, BigDecimal.ROUND_DOWN)
					.setScale(2, BigDecimal.ROUND_DOWN);

			// 存在一级推荐人
			if (null != fristRefereeUser) {
				// 一级推荐人奖励即我的推荐人
				BigDecimal qualityOneMoney = qualityLimitMoney.multiply(new BigDecimal(rule.getOneQualityRate()))
						.setScale(2, BigDecimal.ROUND_DOWN);
				// 更新余额、流水
				updateUserRefereeReward(financePaymentId, myRefereeUser.getId(), qualityOneMoney, 2);

				// 二级推荐人分配
				BigDecimal qualityTwoMoney = qualityLimitMoney.multiply(new BigDecimal(rule.getTwoQualityRate()))
						.setScale(2, BigDecimal.ROUND_DOWN);
				// 更新余额、流水
				updateUserRefereeReward(financePaymentId, fristRefereeUser.getId(), qualityTwoMoney, 2);
			}
			// 不存在一级推荐人
			else {
				updateUserRefereeReward(financePaymentId, myRefereeUser.getId(), qualityLimitMoney, 2);
			}

		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	private void updateUserRefereeReward(Long financePaymentId, Long clientUserId, BigDecimal recommendMoney,
			int type) {
		// 获取推荐人的客户信息
		ApplyClientInfoDTO clientInfo = personalCenterDao.getApplyClientInfoByClientId(clientUserId);
		double profitBalance = recommendMoney.doubleValue();
		if (null != clientInfo.getProfitBalance() && clientInfo.getProfitBalance() != 0.00) {
			profitBalance = (recommendMoney.add(new BigDecimal(clientInfo.getProfitBalance()))).doubleValue();
		}
		Date date = new Date();
		// 更新总的余额
		if (null != clientInfo) {
			clientInfo.setProfitBalance(profitBalance);
			personalCenterDao.updateApplyClientInfoById(clientInfo);
		}
		// 插入收入流水
		ClientProfitBalanceDetailDO balanceDetail = new ClientProfitBalanceDetailDO();
		balanceDetail.setAmount(recommendMoney.doubleValue());
		balanceDetail.setBalance(profitBalance);
		balanceDetail.setClientId(clientUserId);
		balanceDetail.setCreateTime(date);
		// balanceDetail.setCreateUser(user.getId());
		balanceDetail.setOrderId(financePaymentId);
		balanceDetail.setRemark(type == 1 ? "推荐奖励" : "质保奖励");
		balanceDetail.setIncomeExpenses(2708L);
		balanceDetail.setBusinessType(type == 1 ? 3193L : 3194L);
		personalCenterDao.insertClientProfitBalanceDetail(balanceDetail);
	}

	/**
	 * 查询余额
	 */
	@Override
	public RestResponse queryBalance() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		String loginId = user.getLoginId();
		PersonalInfoDTO persona = personalCenterDao.getPersonalInfoByClientUser(loginId);
		String certificationState = persona.getCertificationState();
		if (null != persona && !"Y".equals(certificationState)) {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("尚未进行身份认证或认证已过期，请先完成认证");
			return restResponse;
		}
		MyBalanceDTO dto = personalCenterDao.queryBalanceByLongId(loginId);
		RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
		restResponse.setData(dto);
		return restResponse;
	}

	@Override
	public RestResponse queryClientProfitBalanceDetail(ClientProfitBalanceDetailDTO dto) throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		String loginId = user.getLoginId();
		// 判断是否进行了身份验证
		PersonalInfoDTO persona = personalCenterDao.getPersonalInfoByClientUser(loginId);
		String certificationState = persona.getCertificationState();
		if (null != persona && !"Y".equals(certificationState)) {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("尚未进行身份认证或认证已过期，请先完成认证");
			return restResponse;
		}
		dto.setLoginId(loginId);
		// 获取详情
		List<ClientProfitBalanceDetailDO> list = personalCenterDao.queryClientProfitBalanceDetailPage(dto);
		Page<ClientProfitBalanceDetailDO> page = dto.getPage();
		ClientProfitBalanceDetailVO vo = new ClientProfitBalanceDetailVO();
		List<Map<String, Object>> resultlist = new ArrayList<>();
		boolean flag = true;
		if (list.size() > 0) {
			// 将数据按月份进行分组
			for (ClientProfitBalanceDetailDO clientProfitBalanceDetailDO : list) {
				String dateFormatCreateTime = clientProfitBalanceDetailDO.getDateFormatCreateTime();
				String month = dateFormatCreateTime.substring(0, 7);
				if (resultlist.size() == 0) {
					Map<String, Object> params = new HashMap<String, Object>();
					List<ClientProfitBalanceDetailDO> beans = new ArrayList<>();
					params.put("month", month);
					beans.add(clientProfitBalanceDetailDO);
					params.put("beans", beans);
					resultlist.add(params);
				} else {
					for (Map<String, Object> map : resultlist) {
						if (month.equals(map.get("month").toString())) {
							@SuppressWarnings("all")
							List<ClientProfitBalanceDetailDO> beans = (List) map.get("beans");
							beans.add(clientProfitBalanceDetailDO);
							flag = false;
							break;
						} else {
							flag = true;
						}
					}
					if (flag) {
						Map<String, Object> params = new HashMap<String, Object>();
						List<ClientProfitBalanceDetailDO> beans = new ArrayList<>();
						params.put("month", month);
						beans.add(clientProfitBalanceDetailDO);
						params.put("beans", beans);
						resultlist.add(params);
					}
				}

			}

		}
		// 获取下一页是否有数据
		// 当前长度小于获取的长度证明没有下一页
		if (page.getPageSize() > list.size()) {
			vo.setIsExist(0);
		} else {
			int pageNumber = page.getPageNumber() + 1;
			Page<ClientProfitBalanceDetailDO> params = new Page<ClientProfitBalanceDetailDO>();
			BeanUtils.copyProperties(page, params);
			params.setPageNumber(pageNumber);
			ClientProfitBalanceDetailDTO paramsDto = new ClientProfitBalanceDetailDTO();
			BeanUtils.copyProperties(dto, paramsDto);
			paramsDto.setPage(params);
			List<ClientProfitBalanceDetailDO> queryClientProfitBalanceDetailPage = personalCenterDao
					.queryClientProfitBalanceDetailPage(paramsDto);
			if (queryClientProfitBalanceDetailPage.size() > 0) {
				vo.setIsExist(1);
			} else {
				vo.setIsExist(0);
			}
		}

		ClientProfitBalanceDetailPage detailPage = new ClientProfitBalanceDetailPage();
		BeanUtils.copyProperties(page, detailPage);
		detailPage.setContents(resultlist);
		BeanUtils.copyProperties(dto, vo);
		vo.setPage(detailPage);
		RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
		restResponse.setData(vo);
		return restResponse;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse getShareUrl() throws Exception {
		// 判断当前用户是否进行了身份认证
		User loginUser = SessionUtil.getLoginUser(User.class);
		String loginName = loginUser.getLoginId();
		PersonalInfoDTO dto = personalCenterDao.getPersonalInfoByClientUser(loginName);
		String certificationState = dto.getCertificationState();
		if (null != dto && !"Y".equals(certificationState)) {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("尚未进行身份认证或认证已过期，请先完成认证");
			return restResponse;
		}
		// 获取用户名称

		// 获取短连接
		ClientUserDO user = personalCenterDao.getClientUserByLoginName(loginName);
		String shortUrl = user.getShortUrl();
		if (StringUtils.isEmpty(shortUrl)) {
			String encode = Base64.encode(String.valueOf(user.getId()).getBytes());
			StringBuffer sb = new StringBuffer();
			sb.append("{").append("\"url\":\"").append(USER_SHARE_URL).append("?name=")
					.append(new String(user.getName().getBytes(), "UTF-8")).append("&code=").append(encode)
					.append("\"}");
			log.info("生成短连接（原链接）【" + sb.toString() + "】");
			// 生成短连接

			String sendPost = PosMainStart.sendPost("http://dwz.cn/admin/create", sb.toString());
			@SuppressWarnings("unchecked")
			Map<String, String> map = JSON.parseObject(sendPost, Map.class);
			log.info("生成短连接（返回数据）【" + sendPost + "】");
			shortUrl = map.get("ShortUrl");
			if (StringUtils.isEmpty(shortUrl)) {
				RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
				restResponse.setDescription("获取分享链接失败");
				return restResponse;

			}
			// 更新数据库
			ClientUserDO params = new ClientUserDO();
			params.setLoginName(loginName);
			params.setShortUrl(shortUrl);
			personalCenterDao.updateClientUserByLoginName(params);

		}

		RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
		restResponse.setData(shortUrl);
		return restResponse;
	}

	@Override
	public RestResponse querywhetherShowSetReferee() throws Exception {
		RestResponse restResponse;
		User loginUser = SessionUtil.getLoginUser(User.class);
		int countMainByIn = personalCenterDao.countMainByloginName(loginUser.getLoginId());
		if (countMainByIn > 0) {
			restResponse = new RestResponse(NativeMsgErrCode.ADDRESS_BOOK_UPLOADED);
			restResponse.setDescription("已提交申请，推荐人不可修改");
		} else {
			restResponse = new RestResponse(MsgErrCode.SUCCESS);
			restResponse.setDescription("可设置推荐人");
		}

		return restResponse;
	}

}
