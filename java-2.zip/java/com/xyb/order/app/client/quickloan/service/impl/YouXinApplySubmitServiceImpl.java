package com.xyb.order.app.client.quickloan.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import net.sf.json.JSONObject;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MessageError;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.beiming.kun.utils.StringUtils;
import com.xyb.auth.user.model.User;
import com.xyb.common.redis.RedisUtil;
import com.xyb.credit.common.model.CheatInterfaceLogDO;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import com.xyb.credit.depend.service.DependService;
import com.xyb.order.app.client.apply.dao.ApplyDao;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AuthorizationListVO;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.cuser.model.ApplyLoanOrgDO;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.personinfo.dao.ApplyJobDao;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.dao.ApplySubmitDao;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;
import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.service.ApplySubmitService;
import com.xyb.order.app.client.personinfo.service.impl.ApplySubmitServiceImpl;
import com.xyb.order.app.client.quickloan.dao.QuickLoanDao;
import com.xyb.order.app.client.quickloan.dao.QuickLoanDetailDao;
import com.xyb.order.app.client.quickloan.dao.QuickLoanRefuseFullClientDao;
import com.xyb.order.app.client.quickloan.dao.QuickLoanRefuseFullDao;
import com.xyb.order.app.client.quickloan.dao.QuickLoanRefuseFullDetailDao;
import com.xyb.order.app.client.quickloan.model.QuickLoanDetailDO;
import com.xyb.order.app.client.quickloan.model.QuickLoanPersonalInformationBean;
import com.xyb.order.app.client.quickloan.model.QuickLoanRedisBean;
import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullClientDO;
import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullDO;
import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullDetailDO;
import com.xyb.order.app.client.quickloan.model.QuickLoanReportParameterBean;
import com.xyb.order.common.bank.service.BankService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.FileNameConstant;
import com.xyb.order.common.constant.LoanRejectionCodeConstant;
import com.xyb.order.common.constant.MqConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.ProductConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.consultation.dao.ConsultationDao;
import com.xyb.order.pc.contract.dao.XybContractAuditDao;
import com.xyb.order.pc.ownuse.service.contract.XybContractOwnuseService;
import com.xyb.risks.common.model.mqresponse.ErrorCircumstances;
import com.xyb.risks.common.model.mqresponse.MainResponseInfo;
import com.xyb.risks.common.model.mqresponse.RiskResponseInfo;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.util.SessionUtil;

/**
 * 
* @className : YouXinApplySubmitServiceImpl.java
* @package : com.xyb.order.app.client.personinfo.service.impl
* @description : 优信借接口实现类
* @author : zhanghao
* @createDate : 2018年12月18日下午2:53:39
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.app.client.personinfo.service.ApplySubmitService")
public class YouXinApplySubmitServiceImpl implements ApplySubmitService {

	private static final Logger logger = LoggerFactory.getLogger(ApplySubmitServiceImpl.class);
	
	@Autowired
	private ApplyPersonDao applyPersonDao;
	
	@Autowired
    private AuthorizationDao authorizationDao;
	
	@Autowired
    private ConsultationDao consultationDao;
	
	@Autowired
	private FileDataInfoService fileService;
	
	@Autowired
	private OtherPlatformRelevantService otherPlatformRelevantService;
	
	@Resource(name = "jmsQueueTemplate")
    private JmsTemplate jmsQueueTemplate;
	
	@Autowired
	private CurrencyDao currencyDao;
	
	@Autowired
    private ApplyDao applyDao;
	
	@Reference
	private DependService dependService;
	
	@Autowired
	private ClinetUserModifyService clinetUserModifyService;
	
	@Autowired
	private QuickLoanDao quickLoanDao;
	
	@Autowired
	private QuickLoanDetailDao quickLoanDetailDao;
	
	@Autowired
	private QuickLoanRefuseFullClientDao quickLoanRefuseFullClientDao;
	
	@Autowired
	private QuickLoanRefuseFullDao quickLoanRefuseFullDao;
	
	@Autowired
	private QuickLoanRefuseFullDetailDao quickLoanRefuseFullDetailDao;
	
	@Autowired
	private ApplyBillInfoDao applyBillInfoDao;
	
	@Autowired
	private ApplyJobDao applyJobDao;
	
	@Autowired
    private BankService bankService;
	
	@Autowired
    private XybContractAuditDao xybContractAuditDao;
	
	@Reference
    private ForeignService foreignservice;
	
	@Autowired
    private ApplySubmitDao applySubmitDao;
	
	@Autowired
    private HomeDao homeDao;
	
	@Autowired
	private XybContractOwnuseService xybContractOwnuseService;
	
	@Override
	public RestResponse confirmSubmit(ApplySubmitDTO applySubmitDTO) {
		RestResponse response = null;
		try {
			User user = SessionUtil.getLoginUser(User.class);
			Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
			if (applyId == null) {
			    return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
			}
			/**1.修改图片为不可删除*/
			this.fileService.updateFileState(applyId,user.getId(),new ArrayList<String>(){{add(FileNameConstant.M0);}{add(FileNameConstant.A0);}{add(FileNameConstant.B0);}{add(FileNameConstant.C0);}{add(FileNameConstant.D0);}{add(FileNameConstant.E0);}{add(FileNameConstant.G0);}{add(FileNameConstant.H0);}{add(FileNameConstant.I0);}{add(FileNameConstant.J0);}{add(FileNameConstant.F0);}{add(FileNameConstant.L0);}{add(FileNameConstant.L0);}{add(FileNameConstant.K0);}});
			/**2.数据存储,流程跳转*/
			AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
			Map<String,Object> paraMap = new HashMap<>();
			// -- 流程跳转
			ApplyBillMainInfoDO mainInfoDO = new ApplyBillMainInfoDO();
			mainInfoDO.setExpectMoney(applySubmitDTO.getApplyAmount());
			mainInfoDO.setExpectTerm(applySubmitDTO.getExpectTerm().intValue());
			mainInfoDO.setStoreOrgId(applySubmitDTO.getOrgId());
			mainInfoDO.setId(authorizationListVO.getMainId());
			mainInfoDO.setState(NodeStateConstant.PENDING_SYSTEM_AUDIT);
			
			/**系统审核组装参数*/
			SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(authorizationListVO.getMainId(), NodeStateConstant.CLIENT_APPLY);
			if (systemAuditParamDTO == null) {
			    return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			}
			systemAuditParamDTO.setSubmitUser(user.getName());
			systemAuditParamDTO.setSynOrAsy("asynchronous");
			mainInfoDO.setSubmitConsultTime(new Date());
			mainInfoDO.setModifyUser(user.getId());
			paraMap.put("mainId",authorizationListVO.getMainId());
			paraMap.put("modifyUser",user.getId());
			paraMap.put("modifyUserName",user.getName());
			/**更新系统日志*/
			currencyDao.insertMainLog(paraMap);
			/**更新主表信息*/
			currencyDao.updateMainInFo(mainInfoDO);
			/**更新申请表信息*/
			ApplyDTO applyDTO = new ApplyDTO();
			applyDTO.setApplyId(applyId);
			applyDTO.setExpectMoney(applySubmitDTO.getApplyAmount());
			applyDTO.setExpectProductId(applySubmitDTO.getExpectProductId());
			applyDTO.setBorrowDescCode(applySubmitDTO.getBorrowDescCode());
			applyDTO.setStoreOrgId(applySubmitDTO.getOrgId());
			applyDTO.setManagerId(mainInfoDO.getServiveManagerUid());
			applyDTO.setModifyTime(new Date());
			applyDTO.setModifyUser(user.getId());
			applyDao.updateBillInfo(applyDTO);
			jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION_YOUXINJIE, JsonUtils.toJSON(systemAuditParamDTO));
			response = new RestResponse(MsgErrCode.SUCCESS);
		} catch (JmsException e) {
			logger.error("确认借款提交失败" , e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return response;
	}

	@Override
	public RestResponse applySubmit() {
		RestResponse response = null;
		 try {
			User user = SessionUtil.getLoginUser(User.class);
			Long loginUserId = user.getId(); 
			/**1.查询applyId是否存在*/
	        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
	        if (applyId == null) {
	            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
	        }
			Map<String, Object> mainMap = new HashMap<>(2);
			mainMap.put("applyId", applyId);
			ApplyBillMainInfoDO applyMaInfo = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(mainMap);
			/**2.校验必填项*/
			/**2.1校验基本信息*/
			/**2.1.1校验个人基本信息是否已填写*/
			ApplyPersonBaseInfoDO applyPersonBaseInfo = this.applyPersonDao.getApplyPersonBaseInfo(applyId);
			if(applyPersonBaseInfo == null){
				return new RestResponse(NativeMsgErrCode.UN_PERSON_BASE_INFO);
			}
			/**2.1.2校验联系人信息是否已填写*/
			Map<String, Object> paraMap = new HashMap<String, Object>();
			paraMap.put("applyId", applyId);
			paraMap.put("type", 1734);
			List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
			if (family == null || family.size() < 1) {
				return new RestResponse(NativeMsgErrCode.UN_FAMILY_CONTACT_INFO);
			}
			paraMap.put("type", 2092);
			List<Map<String, Object>> quick = this.applyPersonDao.getLinkManList(paraMap);
			if (quick == null || quick.size() < 2) {
				return new RestResponse(NativeMsgErrCode.UN_EMERGENCY_CONTACT_INFO);
			}
			paraMap.put("type", 1897);
			List<Map<String, Object>> work = this.applyPersonDao.getLinkManList(paraMap);
			if (work == null || work.size() < 1) {
				return new RestResponse(NativeMsgErrCode.UN_WORK_CONTACT_INFO);
			}
			/**2.1.3校验工作信息是否已填写*/
			JobInfoDO jobInfoDO = this.applyJobDao.getJobInfoByApplyId(applyId);
			if(jobInfoDO == null){
				return new RestResponse(NativeMsgErrCode.UN_WORK_INFO);
			}
			/**2.2校验银行卡信息是否已填写*/
			RestResponse bankResult = bankService.getBankCardState();
			JSONObject jsonObject = JSONObject.fromObject(bankResult.getData());
			if(jsonObject.getString("bank").equals("未绑卡")){
				return new RestResponse(NativeMsgErrCode.UN_BANK_CARD_INFO);
			}
			if(jsonObject.getString("bank").equals("申请变更中")){
				return new RestResponse(NativeMsgErrCode.UN_BANK_CARD_CHANGE);
			}
			if(jsonObject.getString("idCard").equals("认证已过期")){
				return new RestResponse(NativeMsgErrCode.ID_CARD_OUT_TIME);
			}
			/**2.3校验自我推荐图片信息是否已填写*/
			Boolean selfRecommedImg = false;
			List<Map<String,Object>> xybDataInfoList = xybContractAuditDao.getPicsByApplyId(applyId);
			if(null!=xybDataInfoList && xybDataInfoList.size()>0){
			    for(Map<String,Object> model:xybDataInfoList){
			    		String fileCode = (String) model.get("fileCode");
		    			if(fileCode.equals(SysDictEnum.IMAGE_TYPE_ZWTJ.getName())){
		    				/**已上传自我推荐图片*/
		    				selfRecommedImg = true;
		    				break;
			    		}
			    }
			 }
			if(!selfRecommedImg){
				return new RestResponse(NativeMsgErrCode.UN_IMG_ZWTJ);
			}
			/**2.4校验必附项信息是否已填写*/
	        AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
	        if (authorizationListVO == null){
	        	logger.info("失败,未查询到主表信息,applyId:"+applyId);
	            response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
	        }else {
	            // -- 获取风控报告有效时间
	            Map<String,Integer> maps = null;
	            try {
	                maps = foreignservice.getAuthorizationValidTimeOfOrder();
	            }catch (Exception e){
	                logger.error("获取风控报告有效时间异常:",e);
	            }
	            if (maps == null){
	                maps = new HashMap<>(0);
	            }
	            List<AuthorizationProductDO> doList = authorizationDao.queryAuthorizationProduct(authorizationListVO.getProductId());
	            Map<String,Object> paraMapTwo = new HashMap<>();
	            int count;
	            for (AuthorizationProductDO AuthProductDO:doList){
	            	if(AuthProductDO.getIsAdditional().equals(SysDictEnum.NO.getCode())){
	            		/*	算话人行报告特殊处理逻辑
	                		1)风控平台配置“算话征信报告”为非必附；
	                		2)当“基本信息_是否持有信用卡”为“有”时，“算话人行报告”必须进行授权
	                			i.未授权成功：无法提交；
	                			ii.授权成功：其他必填项完成，可提交申请；
	                		当是否持有信用卡选择：否时，不需要授权算话*/
	                	if(SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode().compareTo(AuthProductDO.getAuthorizationType()) == 0){
	                		if (CurrencyConstant.CURRENCY_CONSTANT_2486.equals(applyPersonBaseInfo.getCreditCard())){
	                			if(getCreditInvestigationVerifyResult(applyId)){
	                				continue;
	                			}else{
	                				return new RestResponse(NativeMsgErrCode.UN_SUANHUA_REPORT);
	                			}
		                	}else{
		                		continue;
		                	}
	                	}else{
	                		continue;
	                	}
	            	}
	            	paraMapTwo.put("authorizationType",AuthProductDO.getAuthorizationType());
	            	paraMapTwo.put("applyId",applyId);
	            	paraMapTwo.put("isSuccess",SysDictEnum.YES.getCode());
	                Integer time = maps.get(AuthProductDO.getAuthorizationType().toString());
	                paraMapTwo.put("time",time == null?1:time);
	                count = authorizationDao.getAuthorizationInfoCount(paraMapTwo);
	                if (count > 0){
	                	/**成功,跳出当前,继续循环*/
	                    continue;
	                }else {
	                    //authorizationResultVO.setResult("待授权");
	                	/**根据当前配置的三方必附类型获取对应的messageError*/
	                	MessageError messageError = null;
	                	switch (AuthProductDO.getAuthorizationType().intValue()) {
							case 2873:
								messageError = NativeMsgErrCode.UN_JUXINLI_REPORT;
								break;
							case 2874:
								messageError = NativeMsgErrCode.UN_JUXINLI_BAODAN;
								break;
							case 2875:
								messageError = NativeMsgErrCode.UN_RONG360_SHEBAO;
								break;
							case 2876:
								messageError = NativeMsgErrCode.UN_RONG360_GJJ;
								break;
							case 2877:
								messageError = NativeMsgErrCode.UN_RONG360_JBRH;
								break;
							case 2878:
								messageError = NativeMsgErrCode.UN_SUANHUA_REPORT;
								break;
						}
	                	paraMapTwo.remove("isSuccess");
	                    count = authorizationDao.getAuthorizationInfoCount(paraMapTwo);
	                    if (count > 0){
	                        if (SysDictEnum.EMPOWERMENT_SUCCESS.getCode().equals(AuthProductDO.getForceType())){
	                            /**授权类型为强制授权成功*/
	                        	return new RestResponse(messageError);
	                        }else {
	                        	/**授权类型为非强制授权成功,count>0 则为成功*/
	                        	continue;
	                        }
	                    }else {
	                    	/**未授权成功,返回对应的messageError*/
                       	return new RestResponse(messageError);
	                    }
	                }
	            }
	        }
			/**3.根据工作城市获取营业部信息*/
			/**3.1获取工作城市*/
			Long clientId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
			String jobCity = this.applySubmitDao.getCityName(clientId);
			/**3.2获取营业部*/
			List<ApplyLoanOrgDO> applyLoanOrgDOS = homeDao.queryApplyLoanOrg(jobCity);
			if(applyLoanOrgDOS != null && applyLoanOrgDOS.size() > 0){
				/**3.3获取当前查出来的营业部是否支持当前申请产品*/
				Map<String, Object> map = new HashMap<>(2);
				map.put("productId", applyMaInfo.getExpectProductId());
				map.put("list",applyLoanOrgDOS.stream().map(ApplyLoanOrgDO::getOrgId).collect(Collectors.toList()));
				List<Long> orgIds = homeDao.getOrgIdsByOrgIdsAndProDuctId(map);
				if(orgIds != null && orgIds.size() > 0){
					/**3.4筛选已配置该产品的营业部*/
					applyLoanOrgDOS = applyLoanOrgDOS.stream().filter(list -> orgIds.contains(list.getOrgId())).collect(Collectors.toList());
					return new RestResponse(MsgErrCode.SUCCESS,applyLoanOrgDOS);
				}else{
					return new RestResponse(NativeMsgErrCode.UN_ORGIDS_BY_PRODUCT);
				}
		 	}else{
				return new RestResponse(NativeMsgErrCode.UN_ORGIDS_BY_JOBCITY);
		 	}
		} catch (Exception e) {
			logger.error("提交申请失败" , e);
			response = new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
		return response;
	}
	
	/**
	 * 
     * method_name: systemAuditingMonitoring
     * param: @param message
     * describe: 优信借产品获知风控系统推送结果后进行业务处理
     * creat_user: zhanghao
     * creat_date: 2018年12月20日下午4:02:37
     *
	 */
	@JmsListener(containerFactory = MqConstant.JMS_LISTENER_CONTAINER_FACTORY_ID, destination = MqConstant.SYSTEM_AUDIT_PUSH_YOUXIN_DESTINATION)
	public void systemAuditingMonitoring(ActiveMQTextMessage message) {
		try {
			MainResponseInfo mainResponseInfo = JsonUtils.fromJSON(message.getText(), MainResponseInfo.class);
			Long applyMainId = Long.valueOf(mainResponseInfo.getApplyMainId());
			Long applyId = Long.valueOf(mainResponseInfo.getApplyId());
			Long cusId = Long.valueOf(mainResponseInfo.getCusId());
			int submitNode = Integer.valueOf(mainResponseInfo.getSubmitNode());
			Map<String, Object> map = new HashMap<>(2);
			map.put("messageId", message.getJMSMessageID());
			map.put("orderId", applyId);
			// 防重复消费
			if (!otherPlatformRelevantService.getAndInsertMessageConsumeLog(map)) {
				// 添加接口日志
				CheatInterfaceLogDO cheatInterfaceLogDO = new CheatInterfaceLogDO();
				cheatInterfaceLogDO.setApplyMainId(applyMainId);
				cheatInterfaceLogDO.setInterfaceFlag("2");
				cheatInterfaceLogDO.setRequestJson(message.getText());
				cheatInterfaceLogDO.setSubmitNode(String.valueOf(submitNode));
				cheatInterfaceLogDO.setSubmitUser(CurrencyConstant.SYSTEM_USER);
				cheatInterfaceLogDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
				otherPlatformRelevantService.addCheatInterfaceLog(cheatInterfaceLogDO);
				logger.info("添加消费日志");
				logger.info("开始流程处理");
				logger.info("接收数据:"+ message.getText());
				if (mainResponseInfo.getErrorCircumstances() != null) {
					ErrorCircumstances error = mainResponseInfo.getErrorCircumstances();
					String flowState = error.getFlowState();
					if (SysConstants.FLOW_STATE_01.equals(flowState)) {
						// -- 风控强制通过
						approvedLoanOperation(applyMainId, LoanRejectionCodeConstant.FULL_REJECTION_CODE, LoanRejectionCodeConstant.FULL_REJECTION_MSG);
					}else if (SysConstants.FLOW_STATE_04.equals(flowState) || SysConstants.FLOW_STATE_05.equals(flowState)) {
						// -- 获取报告异常 返回原节点
						if (NodeStateConstant.PENDING_SYSTEM_AUDIT.equals(submitNode)) {
							submitNode = NodeStateConstant.CLIENT_APPLY;
						}
						updateAndInsertLog(applyMainId, submitNode);
					}else {
						logger.info("调用风控系统系统审核重新提交");
						SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(applyMainId, submitNode);
						systemAuditParamDTO.setSubmitUser("系统账户");
						systemAuditParamDTO.setSynOrAsy("asynchronous");
						/** 调用风控系统系统审核重新提交 */
						jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION_YOUXINJIE, JsonUtils.toJSON(systemAuditParamDTO));
						// -- 添加系统审核是否通过结果
						ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
						applyBillMainInfoDO.setId(applyMainId);
						applyBillMainInfoDO.setIsSysAuditPass(0L);
						currencyDao.updateMainInFo(applyBillMainInfoDO);
					}
				}else {
					String repellentCode = null;
					String repellentMessage = null;
					Integer repellentNumberofdays = null;
					RiskResponseInfo riskResponseInfo = mainResponseInfo.getRiskResponseInfo();
					if (riskResponseInfo != null){
						repellentCode = riskResponseInfo.getRepellentCode();
						repellentMessage = riskResponseInfo.getRepellentMessage();
						repellentNumberofdays = riskResponseInfo.getRepellentNumberofdays();
					}
					// -- 批贷
					if (StringUtils.isNullOrEmpty(repellentCode)) {
						approvedLoanOperation(applyMainId, LoanRejectionCodeConstant.FULL_REJECTION_CODE, LoanRejectionCodeConstant.FULL_REJECTION_MSG);
						// -- 系统拒贷
					} else {
						updateAndInsertLog(repellentCode, repellentMessage, applyMainId);
						clinetUserModifyService.updateClientAllowableEntryTime(cusId, repellentNumberofdays);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("解析系统审核风控结果异常:" + e);
		}
		
	}

	/**
	 * 
	 * method_name: approvedLoanOperation
	 * param: @param applyMainId
	 * param: @param repellentCode
	 * param: @param repellentMessage
	 * describe: 批准贷款操作
	 * creat_user: zhanghao
	 * creat_date: 2018年12月25日下午2:59:38
	 *
	 */
	@Transactional
	private void approvedLoanOperation(Long applyMainId, String repellentCode, String repellentMessage) {
		//TODO 进件判断当日已批贷额度，并根据满额规则是否开启进行判定：
		//先从redis取出当日批贷数据集 ，如果没有数据，则从数据库初始化如redis中
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String format = sdf.format(new Date());
		QuickLoanRedisBean quickLoanRedisBean = RedisUtil.getObject((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), QuickLoanRedisBean.class);
		QuickLoanPersonalInformationBean qlpib = quickLoanDao.queryQuickLoanRedisBean(applyMainId);
		//基本信息qlpib不能为空，不然证明此时的mainId不对应本库数据或数据存在问题
		if(qlpib != null){
			if(quickLoanRedisBean == null){
				quickLoanRedisBean = new QuickLoanRedisBean();
				quickLoanRedisBean.setDayLimit(qlpib.getDayLimit());
				quickLoanRedisBean.setApplyMoney(new BigDecimal(0.00));
				quickLoanRedisBean.setIsFull(qlpib.getExpectMoney().compareTo(qlpib.getDayLimit())<=0?false:true);
				quickLoanRedisBean.setRuleSwitch(qlpib.getRuleSwitch());
				RedisUtil.set((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), 172800, quickLoanRedisBean);
			}
			if((qlpib.getExpectMoney().add(quickLoanRedisBean.getApplyMoney())).compareTo(quickLoanRedisBean.getDayLimit()) >= 0){
				//TODO 如果产品关闭 直接进行批贷 否则 进行满额拒贷操作
				if(ProductConstant.CLOSE.compareTo(quickLoanRedisBean.getRuleSwitch()) == 0) {
					//批贷操作
					quickLoanRedisBean.setApplyMoney((qlpib.getExpectMoney().add(quickLoanRedisBean.getApplyMoney())));
					quickLoanRedisBean.setRuleSwitch(qlpib.getRuleSwitch());
					RedisUtil.set((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), 172800, quickLoanRedisBean);
					quickLoanApplyReportOperation(applyMainId);
					xybContractOwnuseService.agreeLoan(applyMainId);
				}else {
					//TODO 满额拒贷操作
					//维护redis数据
					quickLoanRedisBean.setIsFull(true);
					quickLoanRedisBean.setRuleSwitch(qlpib.getRuleSwitch());
					RedisUtil.set((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), 172800, quickLoanRedisBean);
					updateAndInsertLog(repellentCode, repellentMessage, applyMainId);
					quickLoanDeniedLoansOperation(applyMainId);
				}
			}else {
				//TODO 批贷操作
				quickLoanRedisBean.setApplyMoney((qlpib.getExpectMoney().add(quickLoanRedisBean.getApplyMoney())));
				quickLoanRedisBean.setRuleSwitch(qlpib.getRuleSwitch());
				RedisUtil.set((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), 172800, quickLoanRedisBean);
				quickLoanApplyReportOperation(applyMainId);
				xybContractOwnuseService.agreeLoan(applyMainId);
			}
		}else{
			//TODO 异常处理
			new RuntimeException("QuickLoanPersonalInformationBean对象为空");
		}
	}
	
	/**
	 * 添加用户优质等级
	 * 
	 * @param clientGrade
	 */
	@Transactional
	private void updateMain(Long clientGrade, Long mainId, Long isSysAuditPass) {
		/** 修改主表 **/
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setClientGrade(clientGrade);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		applyBillMainInfoDO.setIsSysAuditPass(isSysAuditPass);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}
	
	/**
	 * 修改并添加表日志
	 */
	@Transactional
	private void updateAndInsertLog(Long mainId, Integer state) {
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		mainLogDTO.setModifyUserName("系统账户");
		mainLogDTO.setBusinessState(state);
		mainLogDTO.setBusinessStateName("客户申请");
		mainLogDTO.setMainId(mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(state);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		applyBillMainInfoDO.setIsSysAuditPass(SysDictEnum.NO.getCode());
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}
	
	/**
	 * 修改并添加表日志 refuseCode 拒贷码 refuseValue 拒贷原因
	 */
	@Transactional
	private void updateAndInsertLog(String refuseCode, String refuseValue, Long mainId) {
		MainLogDTO mainLogDTO = new MainLogDTO();
		mainLogDTO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		mainLogDTO.setModifyUserName("系统账户");
		mainLogDTO.setBusinessState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
		mainLogDTO.setBusinessStateName("系统审核拒贷");
		mainLogDTO.setMainId(mainId);
		ApplyBillMainInfoDO applyBillMainInfoDO = new ApplyBillMainInfoDO();
		applyBillMainInfoDO.setState(NodeStateConstant.SYSTEM_AUDITS_APPLY);
		applyBillMainInfoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
		applyBillMainInfoDO.setId(mainId);
		if (StringUtils.isNotNullAndEmpty(refuseCode)) {
			applyBillMainInfoDO.setRefuseCode(refuseCode);
			applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
		}
		if (StringUtils.isNotNullAndEmpty(refuseValue)) {
			applyBillMainInfoDO.setRefuseValue(refuseValue);
			applyBillMainInfoDO.setIsResuse(SysDictEnum.YES.getCode());
		}
		this.currencyDao.addMainLog(mainLogDTO);
		this.currencyDao.updateMainInFo(applyBillMainInfoDO);
	}
	
	/**
	 * 
	     * method_name: quickLoanReportOperation
	     * param: 
	     * describe: 速贷进件报表操作
	     * creat_user: zhanghao
	     * creat_date: 2018年12月21日下午4:20:39
	     *
	 */
	@Transactional
	public void quickLoanApplyReportOperation(Long applyMainId){
		Map<String, Object> queryMap = new HashMap<String, Object>(1);
		//查询所需维护参数
		QuickLoanReportParameterBean qlrpb = quickLoanDao.queryQuickLoanReportParameterBean(applyMainId);
		//维护申请通过记录表
		QuickLoanDetailDO quickLoanDetailDO = new QuickLoanDetailDO();
		quickLoanDetailDO.setClientId(qlrpb.getClientId());
		quickLoanDetailDO.setClientName(qlrpb.getClientName());
		quickLoanDetailDO.setOrgId(qlrpb.getOrgId());
		quickLoanDetailDO.setProductId(qlrpb.getProductId());
		quickLoanDetailDO.setBusinessType(qlrpb.getBusinessType());
		quickLoanDetailDO.setBusinessMoney(qlrpb.getBusinessMoney());
		quickLoanDetailDO.setCreateTime(new Date());
		quickLoanDetailDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
		quickLoanDetailDao.insert(quickLoanDetailDO);
		queryMap.put("productId", qlrpb.getProductId());
		List<QuickLoanRefuseFullClientDO> quickLoanRefuseFullClientDOs = quickLoanRefuseFullClientDao.selectAll(queryMap);
		updateRefuseFullClient(qlrpb, quickLoanRefuseFullClientDOs, 0, 1);
	}
	
	/**
	 * 
	     * method_name: quickLoanDeniedLoansOperation
	     * param: 
	     * describe: 速贷进件满额拒贷报表操作
	     * creat_user: zhanghao
	     * creat_date: 2018年12月21日下午4:30:03
	     *
	 */
	@Transactional
	public void quickLoanDeniedLoansOperation(Long applyMainId){
		Map<String, Object> queryMap = new HashMap<String, Object>(1);
		//查询所需维护参数
		QuickLoanReportParameterBean qlrpb = quickLoanDao.queryQuickLoanReportParameterBean(applyMainId);
		//维护满额拒贷记录表
		QuickLoanRefuseFullDetailDO quickLoanRefuseFullDetailDO = new QuickLoanRefuseFullDetailDO();
		quickLoanRefuseFullDetailDO.setClientId(qlrpb.getClientId());
		quickLoanRefuseFullDetailDO.setClientName(qlrpb.getClientName());
		quickLoanRefuseFullDetailDO.setClientIdcard(qlrpb.getClientIdcard());
		quickLoanRefuseFullDetailDO.setClientPhone(qlrpb.getClientPhone());
		quickLoanRefuseFullDetailDO.setApplyDate(new Date());
		quickLoanRefuseFullDetailDO.setOrgId(qlrpb.getOrgId());
		quickLoanRefuseFullDetailDO.setProductId(qlrpb.getProductId());
		quickLoanRefuseFullDetailDO.setApplyAmount(qlrpb.getBusinessMoney());
		quickLoanRefuseFullDetailDO.setCreateTime(new Date());
		quickLoanRefuseFullDetailDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
		quickLoanRefuseFullDetailDao.insert(quickLoanRefuseFullDetailDO);
		
		queryMap.put("clientId", qlrpb.getClientId());
		queryMap.put("productId", qlrpb.getProductId());
		List<QuickLoanRefuseFullClientDO> quickLoanRefuseFullClientDOs = quickLoanRefuseFullClientDao.selectAll(queryMap);
		QuickLoanRefuseFullClientDO quickLoanRefuseFullClientDO = updateRefuseFullClient(qlrpb, quickLoanRefuseFullClientDOs, 1, 1);
		
		List<QuickLoanRefuseFullDO> quickLoanRefuseFullDOs = quickLoanRefuseFullDao.selectAll(queryMap);
		updateRefuseFull(qlrpb, quickLoanRefuseFullClientDO, quickLoanRefuseFullDOs);
	}

	/**
	 * 
	     * method_name: updateRefuseFull
	     * param: @param qlrpb
	     * param: @param quickLoanRefuseFullClientDO
	     * param: @param quickLoanRefuseFullDOs
	     * describe: 修改客户拒贷统计总表
	     * creat_user: zhanghao
	     * creat_date: 2018年12月24日上午10:44:01
	     *
	 */
	@Transactional
	private void updateRefuseFull(QuickLoanReportParameterBean qlrpb, QuickLoanRefuseFullClientDO quickLoanRefuseFullClientDO, List<QuickLoanRefuseFullDO> quickLoanRefuseFullDOs) {
		QuickLoanRefuseFullDO quickLoanRefuseFullDO = null;
		if(quickLoanRefuseFullDOs.size() >0){
			//TODO 调用判断插入full表逻辑及数据
			quickLoanRefuseFullDO = quickLoanRefuseFullDOs.get(0);
			if (quickLoanRefuseFullClientDO.getTotalQty() == 1){
				quickLoanRefuseFullDO.setTotalOne(quickLoanRefuseFullDO.getTotalOne()+1);
			}else if (quickLoanRefuseFullClientDO.getTotalQty() == 2){
				quickLoanRefuseFullDO.setTotalOne(quickLoanRefuseFullDO.getTotalOne()-1);
				quickLoanRefuseFullDO.setTotalTwo(quickLoanRefuseFullDO.getTotalTwo()+1);
			}else if (quickLoanRefuseFullClientDO.getTotalQty() == 3){
				quickLoanRefuseFullDO.setTotalTwo(quickLoanRefuseFullDO.getTotalTwo()-1);
				quickLoanRefuseFullDO.setTotalThree(quickLoanRefuseFullDO.getTotalThree()+1);
			}else if (quickLoanRefuseFullClientDO.getTotalQty() > 3){
				quickLoanRefuseFullDO.setTotalThree(quickLoanRefuseFullDO.getTotalThree()+1);
			}
			quickLoanRefuseFullDO.setModifyTime(new Date());
			quickLoanRefuseFullDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
			quickLoanRefuseFullDao.updateByPrimaryKey(quickLoanRefuseFullDO);
		}else {
			quickLoanRefuseFullDO = new QuickLoanRefuseFullDO();
			quickLoanRefuseFullDO.setProductId(qlrpb.getProductId());
			quickLoanRefuseFullDO.setTotalOne(1);
			quickLoanRefuseFullDO.setTotalTwo(0);
			quickLoanRefuseFullDO.setTotalThree(0);
			quickLoanRefuseFullDO.setCreateTime(new Date());
			quickLoanRefuseFullDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
			quickLoanRefuseFullDao.insert(quickLoanRefuseFullDO);
		}
	}

	/**
	 * 
	     * method_name: updateRefuseFullClient
	     * param: @param qlrpb
	     * param: @param quickLoanRefuseFullClientDOs
	     * param: @return
	     * describe: 修改客户拒贷申请表数据
	     * creat_user: zhanghao
	     * creat_date: 2018年12月24日上午10:35:11
	     *
	 */
	@Transactional
	private QuickLoanRefuseFullClientDO updateRefuseFullClient(QuickLoanReportParameterBean qlrpb,List<QuickLoanRefuseFullClientDO> quickLoanRefuseFullClientDOs,int totalQty,int applyQty) {
		QuickLoanRefuseFullClientDO quickLoanRefuseFullClientDO = null;
		if(quickLoanRefuseFullClientDOs.size() > 0){
			//修改
			quickLoanRefuseFullClientDO = quickLoanRefuseFullClientDOs.get(0);
			quickLoanRefuseFullClientDO.setTotalQty(quickLoanRefuseFullClientDO.getTotalQty()+totalQty);
			quickLoanRefuseFullClientDO.setApplyQty(quickLoanRefuseFullClientDO.getApplyQty()+applyQty);
			quickLoanRefuseFullClientDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
			quickLoanRefuseFullClientDO.setModifyTime(new Date());
			quickLoanRefuseFullClientDao.updateByPrimaryKey(quickLoanRefuseFullClientDO);
		}else {
			//新增
			quickLoanRefuseFullClientDO = new QuickLoanRefuseFullClientDO();
			quickLoanRefuseFullClientDO.setClientId(qlrpb.getClientId());
			quickLoanRefuseFullClientDO.setClientName(qlrpb.getClientName());
			quickLoanRefuseFullClientDO.setClientIdcard(qlrpb.getClientIdcard());
			quickLoanRefuseFullClientDO.setClientPhone(qlrpb.getClientPhone());
			quickLoanRefuseFullClientDO.setProductId(qlrpb.getProductId());
			quickLoanRefuseFullClientDO.setTotalQty(totalQty);
			quickLoanRefuseFullClientDO.setApplyQty(applyQty);
			quickLoanRefuseFullClientDO.setCreateUser(CurrencyConstant.SYSTEM_USER);
			quickLoanRefuseFullClientDO.setCreateTime(new Date());
			quickLoanRefuseFullClientDao.insert(quickLoanRefuseFullClientDO);
		}
		return quickLoanRefuseFullClientDO;
	}
	
	// - 征信报告验证
    private boolean getCreditInvestigationVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }
	
	
}
