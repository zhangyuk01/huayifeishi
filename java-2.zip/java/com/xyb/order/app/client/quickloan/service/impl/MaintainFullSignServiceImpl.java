package com.xyb.order.app.client.quickloan.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.alibaba.dubbo.config.annotation.Service;
import com.xyb.common.redis.RedisUtil;
import com.xyb.order.app.client.quickloan.model.QuickLoanRedisBean;
import com.xyb.order.app.client.quickloan.service.MaintainFullSignService;
import com.xyb.order.common.constant.RedisConstant;
@Service(interfaceName = "com.xyb.order.app.client.quickloan.service.MaintainFullSignService")
public class MaintainFullSignServiceImpl implements MaintainFullSignService {

	@Override
	public Boolean maintainFullSign(BigDecimal dayLimit, Long ruleSwitch) throws Exception{
		Boolean bool = false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String format = sdf.format(new Date());
		QuickLoanRedisBean quickLoanRedisBean = RedisUtil.getObject((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), QuickLoanRedisBean.class);
		if (quickLoanRedisBean != null) {
			quickLoanRedisBean.setDayLimit(dayLimit);
			quickLoanRedisBean.setRuleSwitch(ruleSwitch);
			if(quickLoanRedisBean.getApplyMoney().compareTo(dayLimit) <= 0){
				quickLoanRedisBean.setIsFull(false);
			}else{
				quickLoanRedisBean.setIsFull(true);
			}
			RedisUtil.set((RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format), 172800, quickLoanRedisBean);
			bool = true;
		}
		return bool;
	}

}
