package com.xyb.order.app.client.quickloan.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.personinfo.model.ApplySubmitDTO;
import com.xyb.order.app.client.personinfo.service.impl.ApplySubmitServiceImpl;
import com.xyb.order.app.client.quickloan.dao.QuickLoanDao;
import com.xyb.order.app.client.quickloan.service.ApplySubmitOptionService;
import com.xyb.order.common.constant.ProductConstant;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.util.SessionUtil;

/**
 * 
* @className : ApplySubmitOptionServiceImpl.java
* @package : com.xyb.order.app.client.personinfo.service.impl
* @description : 申请选择提交接口实现类
* @author : zhanghao
* @createDate : 2018年12月18日下午3:39:24
* @modificationHistory Who        When      What
* --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.app.client.quickloan.service.ApplySubmitOptionService")
public class ApplySubmitOptionServiceImpl implements ApplySubmitOptionService {

	private static final Logger logger = LoggerFactory.getLogger(ApplySubmitServiceImpl.class);
	
	@Autowired
	private XybContractDao xybContractDao;
	
	@Autowired
	private QuickLoanDao quickLoanDao;
	
	@Autowired
	private ApplySubmitServiceImpl applySubmitService;
	
	@Autowired
	private YouXinApplySubmitServiceImpl youXinApplySubmitService;
	
	@Override
	public RestResponse confirmSubmitOption(ApplySubmitDTO applySubmitDTO) {
		RestResponse restResponse = new RestResponse();
		logger.info("APP确认提交ApplySubmitDTO:"+applySubmitDTO.toString());
		//根据产品系统判断走不同产品（信贷，速贷）的业务类方法
		if(ProductConstant.YOU_XIN_JIE_ID.compareTo(applySubmitDTO.getExpectProductId()) == 0){
			restResponse = youXinApplySubmitService.confirmSubmit(applySubmitDTO);
		}else {
			restResponse = applySubmitService.confirmSubmit(applySubmitDTO);
		}
		logger.info("APP确认提交RestResponse:"+restResponse.toString());
		return restResponse;
	}

	@Override
	public RestResponse applySubmitOption() {
		logger.info("APP提交申请开始");
		RestResponse restResponse = new RestResponse();
		// 根据产品系统判断走不同产品（信贷，速贷）的业务类方法
		User user = SessionUtil.getLoginUser(User.class);
		Long loginUserId = user.getId();
		Long productId = quickLoanDao.getProductIdByClientId(loginUserId);
		logger.info("APP提交申请productId："+productId);
		if(ProductConstant.YOU_XIN_JIE_ID.compareTo(productId) == 0){
			restResponse = youXinApplySubmitService.applySubmit();
		}else {
			restResponse = applySubmitService.applySubmit();
		}
		logger.info("APP提交申请RestResponse:"+restResponse.toString());
		return restResponse;
	}

}
