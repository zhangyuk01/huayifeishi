package com.xyb.order.app.client.quickloan.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullClientDO;

public interface QuickLoanRefuseFullClientDao {
    int deleteByPrimaryKey(Long id);

    int insert(QuickLoanRefuseFullClientDO record);

    QuickLoanRefuseFullClientDO selectByPrimaryKey(Long id);

    List<QuickLoanRefuseFullClientDO> selectAll(Map<String,Object> queryMap);

    int updateByPrimaryKey(QuickLoanRefuseFullClientDO record);
}