package com.xyb.order.app.client.quickloan.dao;

import java.util.List;

import com.xyb.order.app.client.quickloan.model.QuickLoanDetailDO;

public interface QuickLoanDetailDao {
    int deleteByPrimaryKey(Long id);

    int insert(QuickLoanDetailDO record);

    QuickLoanDetailDO selectByPrimaryKey(Long id);

    List<QuickLoanDetailDO> selectAll();

    int updateByPrimaryKey(QuickLoanDetailDO record);
}