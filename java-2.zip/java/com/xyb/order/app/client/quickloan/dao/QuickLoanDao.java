package com.xyb.order.app.client.quickloan.dao;

import org.apache.ibatis.annotations.Param;

import com.xyb.order.app.client.quickloan.model.QuickLoanApplyInfoDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanPersonalInformationBean;
import com.xyb.order.app.client.quickloan.model.QuickLoanReportParameterBean;

/**
 * 
 * @author qiaoJinLong
 * @date 2018年12月18日
 */

public interface QuickLoanDao {
	/**
	 * 
	 * method_name: queryQuickLoanRedisBean param: @param applyMainId
	 * param: @return describe: 根据mainid 查询需要组装或比对的数据 creat_user: zhanghao
	 * creat_date: 2018年12月21日下午3:17:26
	 *
	 */
	QuickLoanPersonalInformationBean queryQuickLoanRedisBean(Long applyMainId);

	/**
	 * 
	 * method_name: queryQuickLoanReportParameterBean param: @param applyMainId
	 * param: @return describe: 查询速贷报表所需组装的参数 creat_user: zhanghao creat_date:
	 * 2018年12月21日下午4:44:51
	 *
	 */
	QuickLoanReportParameterBean queryQuickLoanReportParameterBean(Long applyMainId);

	/**
	 * 
	 * method_name: getProductIdByClientId param: @return describe:
	 * 根据clientUserId查询当前申请的产品id creat_user: zhanghao creat_date:
	 * 2018年12月26日下午5:16:03
	 *
	 */
	Long getProductIdByClientId(Long clientUserId);

	/**
	 * 获取
	 * 
	 * @param applyId
	 * @return
	 */
	QuickLoanApplyInfoDTO getQuickApplyInfo(@Param("applyId") Long applyId);

}
