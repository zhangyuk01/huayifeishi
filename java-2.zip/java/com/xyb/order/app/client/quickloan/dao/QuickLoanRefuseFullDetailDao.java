package com.xyb.order.app.client.quickloan.dao;

import java.util.List;

import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullDetailDO;

public interface QuickLoanRefuseFullDetailDao {
    int deleteByPrimaryKey(Long id);

    int insert(QuickLoanRefuseFullDetailDO record);

    QuickLoanRefuseFullDetailDO selectByPrimaryKey(Long id);

    List<QuickLoanRefuseFullDetailDO> selectAll();

    int updateByPrimaryKey(QuickLoanRefuseFullDetailDO record);
}