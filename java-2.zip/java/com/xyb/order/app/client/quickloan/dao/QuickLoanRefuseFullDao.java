package com.xyb.order.app.client.quickloan.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.app.client.quickloan.model.QuickLoanRefuseFullDO;

public interface QuickLoanRefuseFullDao {
    int deleteByPrimaryKey(Long id);

    int insert(QuickLoanRefuseFullDO record);

    QuickLoanRefuseFullDO selectByPrimaryKey(Long id);

    List<QuickLoanRefuseFullDO> selectAll(Map<String,Object> queryMap);

    int updateByPrimaryKey(QuickLoanRefuseFullDO record);
}