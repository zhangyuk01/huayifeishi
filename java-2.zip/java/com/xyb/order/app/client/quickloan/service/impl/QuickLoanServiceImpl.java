package com.xyb.order.app.client.quickloan.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.personinfo.dao.ApplyJobDao;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.PersonalAddressDTO;
import com.xyb.order.app.client.quickloan.dao.QuickLoanDao;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyInfoDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyJobDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanApplyPersonInfoDTO;
import com.xyb.order.app.client.quickloan.model.QuickLoanContactInfoDO;
import com.xyb.order.app.client.quickloan.service.QuickLoanService;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.currency.dao.ApplyCommonProvinceDao;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.ChineseAddressParser;
import com.xyb.util.SessionUtil;

/**
 * 速贷service实现类
 * 
 * @author qiaoJinLong
 * @date 2018年12月18日
 */
@Service(interfaceName = "com.xyb.order.app.client.quickloan.service.QuickLoanService")
public class QuickLoanServiceImpl implements QuickLoanService {

	private static final Logger logger = LoggerFactory.getLogger(QuickLoanServiceImpl.class);
	@Autowired
	private QuickLoanDao quickLoanDao;
	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private ClientRedisUtil clientRedisUtil;
	@Autowired
	private ApplyCommonProvinceDao applyCommonProvinceDao;
	@Autowired
	private ApplyJobDao applyJobDao;

	// 保存/修改申请信息
	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse saveOrUpdateApplyInfo(QuickLoanApplyInfoDTO applyInfo) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		String loginId = loginUser.getLoginId();
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		Long cusId = this.applyPersonDao.getCusIdByClientUserId(loginUserId);
		if (cusId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		if (applyId == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
		}
		QuickLoanApplyPersonInfoDTO personInfo = applyInfo.getPersonInfo();
		QuickLoanContactInfoDO contactInfo = applyInfo.getContactInfo();
		Long personId = this.applyPersonDao.getPersonIdByApplyId(applyId);
		// 判断是否添加了联系人
		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("applyId", applyId);
		paraMap.put("type", 1734);
		List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
		if (family == null || family.size() < 1) {
			RestResponse restResponse = new RestResponse(MsgErrCode.FAIL);
			restResponse.setDescription("请至少填写一个家庭联系人信息");
			return restResponse;
		}
		personInfo.setId(personId);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(loginId);
		if (clientAuthenticationDO != null && clientAuthenticationDO.getAddress() != null) {
			PersonalAddressDTO p = ChineseAddressParser.chaifen(clientAuthenticationDO.getAddress());
			personInfo.setHomeTownProvince(p.getProvince());
			personInfo.setHomeTownCity(p.getCity());
			personInfo.setHomeTownArea(p.getArea());
			personInfo.setHomeTown(p.getAddress());
			personInfo.setHomeAllAddress(clientAuthenticationDO.getAddress());
			personInfo.setValidTime(clientAuthenticationDO.getIdCardEndTime());
		}
		/** 居住地址全地址 */
		String provinceLabel = this.applyCommonProvinceDao
				.getProvinceLabelByProvinceId(personInfo.getNowAddressProvince());
		String cityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(personInfo.getNowAddressCity());
		String areaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(personInfo.getNowAddressArea());
		String adress = personInfo.getNowAddress();
		String allAdress = provinceLabel + cityLabel + areaLabel + adress;
		personInfo.setPhone2(contactInfo.getPhone());
		personInfo.setWebchat(contactInfo.getWebchat());
		// 修改个人信息
		if (personInfo.getId() != null) {
			personInfo.setPhone1(loginId);
			personInfo.setModifyUser(loginUserId);
			personInfo.setNowAllAddress(allAdress);
			this.applyPersonDao.updateQuickApplyPersonBaseInfoById(personInfo);
		} else {
			// 新增个人信息
			personInfo.setApplyId(applyId);
			personInfo.setCusId(cusId);
			personInfo.setCreateUser(loginUserId);
			personInfo.setPhone1(loginId);
			personInfo.setNowAllAddress(allAdress);
			this.applyPersonDao.addQuickApplyPersonBaseInfo(personInfo);
		}
		/** 居住地址全地址 */
		String jobprovinceLabel = this.applyCommonProvinceDao
				.getProvinceLabelByProvinceId(personInfo.getNowAddressProvince());
		String jobcityLabel = this.applyCommonProvinceDao.getCityLabelByCityId(personInfo.getNowAddressCity());
		String jobareaLabel = this.applyCommonProvinceDao.getAreaLabelByAreaId(personInfo.getNowAddressArea());
		String jobadress = personInfo.getNowAddress();
		String joballAdress = jobprovinceLabel + jobcityLabel + jobareaLabel + jobadress;
		Long jobId = this.applyPersonDao.getJobIdByApplyId(applyId);
		QuickLoanApplyJobDTO jobInfo = applyInfo.getJobInfo();
		jobInfo.setId(jobId);
		jobInfo.setCompAlladdress(joballAdress);
		if (jobInfo.getId() != null) {
			jobInfo.setModifyUser(loginUserId);
			this.applyJobDao.updateQuickLoanJobInfoById(jobInfo);
		} else {
			jobInfo.setCreateUser(loginUserId);
			jobInfo.setModifyUser(loginUserId);
			jobInfo.setApplyId(applyId);
			jobInfo.setCusId(cusId);
			this.applyJobDao.addQuickLoanJobInfo(jobInfo);
		}
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	public RestResponse getApplyInfo() throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long loginUserId = loginUser.getId();
		Long applyId = this.applyPersonDao.getApplyIdByClientUserId(loginUserId);
		if (null == applyId) {
			RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
			restResponse.setData(null);
			restResponse.setDescription("不存在申请信息");
			return restResponse;
		}
		QuickLoanApplyInfoDTO applyInfo = quickLoanDao.getQuickApplyInfo(applyId);
		RestResponse restResponse = new RestResponse(MsgErrCode.SUCCESS);
		restResponse.setData(applyInfo);
		return restResponse;
	}

}
