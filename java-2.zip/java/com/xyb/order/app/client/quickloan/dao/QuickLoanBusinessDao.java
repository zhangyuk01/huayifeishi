package com.xyb.order.app.client.quickloan.dao;

import java.util.List;

import com.xyb.order.app.client.quickloan.model.QuickLoanBusinessDO;

public interface QuickLoanBusinessDao {
    int deleteByPrimaryKey(Long id);

    int insert(QuickLoanBusinessDO record);

    QuickLoanBusinessDO selectByPrimaryKey(Long id);

    List<QuickLoanBusinessDO> selectAll();

    int updateByPrimaryKey(QuickLoanBusinessDO record);
}