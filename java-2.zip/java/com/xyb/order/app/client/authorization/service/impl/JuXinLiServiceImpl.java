package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.*;
import com.xyb.order.app.client.authorization.service.JuXinLiService;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.risks.process.juxinli.model.BasicInfo;
import com.xyb.risks.process.juxinli.model.Collect;
import com.xyb.risks.process.juxinli.model.Contact;
import com.xyb.risks.process.juxinli.model.JuXinLiAppInData;
import com.xyb.risks.process.juxinli.model.juxinlibaodan.JuXinLiBaoDanAppInData;
import com.xyb.risks.process.juxinli.service.JuXinLiBaoDanService;
import com.xyb.risks.process.juxinli.service.JuxinliService;
import com.xyb.util.SessionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service(interfaceName = "com.xyb.order.app.client.authorization.service.JuXinLiService")
public class JuXinLiServiceImpl implements JuXinLiService {

    private static final Logger log = LoggerFactory.getLogger(JuXinLiServiceImpl.class);

    @Autowired
    private AuthorizationDao authorizationDao;
    @Reference
    private JuxinliService juxinliService;
    @Reference
    private JuXinLiBaoDanService baoDanService;
    @Autowired
    private ApplyPersonDao applyPersonDao;

    @Override
    public RestResponse subApplyGetReturnMsg() throws Exception{
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.JUXINLI_OPERATOR.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
                if (informationDO != null){
                    // -- 组装风控需要的信息
                    JuXinLiAppInData juXinLiAppInData = new JuXinLiAppInData();
                    juXinLiAppInData.setApplyId(applyId+"");
                    juXinLiAppInData.setSysId("gd");
                    juXinLiAppInData.setTerrace("jinjian");
                    juXinLiAppInData.setSkip_mobile(false);
                    BasicInfo basicInfo = new BasicInfo();
                    basicInfo.setName(informationDO.getName());
                    basicInfo.setId_card_num(informationDO.getIdcard());
                    basicInfo.setCell_phone_num(user.getLoginId());
                    basicInfo.setHome_adder(informationDO.getFamilyAddress());
                    basicInfo.setHome_tel(informationDO.getFamilyPhone());
                    basicInfo.setWorkt_addr(informationDO.getWorkAddress());
                    basicInfo.setWorkt_tel(informationDO.getWorkPhone());
                    juXinLiAppInData.setBasic_info(basicInfo);
                    List<AuthenticateLinkmanDO> dos = authorizationDao.queryLingkmanInfo(applyId);
                    List<Contact> contacts = new ArrayList<>();
                    for (AuthenticateLinkmanDO linkmanDO:dos){
                        Contact ct = new Contact();
                        ct.setContact_name(linkmanDO.getName());
                        ct.setContact_tel(linkmanDO.getPhone());
                        ct.setContact_type(relationCorrespondence(linkmanDO.getRelation()+""));
                        contacts.add(ct);
                    }
                    juXinLiAppInData.setContacts(contacts);
                    try {
                        response = juxinliService.subApplyGetReturnMsg(juXinLiAppInData);
                    }catch (Exception e){
                        e.printStackTrace();
                        log.info("调用风控调用聚信立提交申请表单获取回执信息（运营商）异常");
                        response = new RestResponse(MsgErrCode.FAIL);
                    }
                }else {
                    response = new RestResponse(MsgErrCode.FAIL);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    @Override
    public RestResponse getCollectJuXinLi(JuXinLiCollectDTO juXinLiCollectDTO){
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("authorizationType",SysDictEnum.JUXINLI_OPERATOR.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            return new RestResponse(MsgErrCode.FAIL);
        }
        if (SysDictEnum.NO.getCode().equals(productDO.getIsOpen())){
            return new RestResponse(NativeMsgErrCode.IS_CLOSE);
        }
        try {
            Collect collect = new Collect();
            collect.setApplyId(String.valueOf(applyId));
            collect.setSysId("gd");
            collect.setTerrace("jinjian");
            collect.setToken(juXinLiCollectDTO.getToken());
            collect.setAccount(juXinLiCollectDTO.getAccount());
            collect.setPassword(juXinLiCollectDTO.getPassword());
            collect.setCaptcha(juXinLiCollectDTO.getCaptcha());
            collect.setType(juXinLiCollectDTO.getType());
            collect.setWebsite(juXinLiCollectDTO.getWebsite());
            response = juxinliService.getCollectJuXinLi(collect);
        }catch (Exception e){
            e.printStackTrace();
            log.info("调用风控调用聚信立数据源采集请求（运营商）异常");
            response = new RestResponse(MsgErrCode.FAIL);
        }
        return response;
    }

    @Override
    public RestResponse getAllInsuranceWebsite(){
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("authorizationType",SysDictEnum.JUXINLI_POLICY_REPORT.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            return new RestResponse(MsgErrCode.FAIL);
        }
        if (SysDictEnum.NO.getCode().equals(productDO.getIsOpen())){
            return new RestResponse(NativeMsgErrCode.IS_CLOSE);
        }
        try {
            response = baoDanService.getAllInsuranceWebsite();
        }catch (Exception e){
            e.printStackTrace();
            log.info("调用风控获取支持的数据源具体网站列表(保单)失败");
            response = new RestResponse(MsgErrCode.FAIL);
        }
        return response;
    }

    @Override
    public RestResponse collectJuXinLiBaoDan(JuXinLiBaoDanDTO juXinLiBaoDanDTO) throws Exception{
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("authorizationType",SysDictEnum.JUXINLI_POLICY_REPORT.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            return new RestResponse(MsgErrCode.FAIL);
        }
        if (SysDictEnum.NO.getCode().equals(productDO.getIsOpen())){
            return new RestResponse(NativeMsgErrCode.IS_CLOSE);
        }
        AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
        if (informationDO == null){
            return new RestResponse(MsgErrCode.FAIL);
        }
        try {
            JuXinLiBaoDanAppInData juXinLiBaoDanAppInData = new JuXinLiBaoDanAppInData();
            juXinLiBaoDanAppInData.setApplyId(String.valueOf(applyId));
            juXinLiBaoDanAppInData.setSysId("gd");
            juXinLiBaoDanAppInData.setTerrace("jinjian");
            juXinLiBaoDanAppInData.setAccount(juXinLiBaoDanDTO.getAccount());
            juXinLiBaoDanAppInData.setPassword(juXinLiBaoDanDTO.getPassword());
            juXinLiBaoDanAppInData.setWebsite(juXinLiBaoDanDTO.getWebsite());
            juXinLiBaoDanAppInData.setName(informationDO.getName());
            juXinLiBaoDanAppInData.setId_card_num(informationDO.getIdcard());
            juXinLiBaoDanAppInData.setCell_phone_num(user.getLoginId());
            response = baoDanService.collectJuXinLiBaoDan(juXinLiBaoDanAppInData);
        }catch (Exception e){
            e.printStackTrace();
            log.info("调用风控提交保险网站数据采集申请接口(保单)");
            response = new RestResponse(MsgErrCode.FAIL);
        }
        return response;
    }

    /**
    * 联系人类型关系对应
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/17 下午2:08
    */
    private String relationCorrespondence(String relation){
        switch (relation){
            case "2002":
                relation = "1";
                break;
            case "2003":
                relation = "2";
                break;
            case "2004":
                relation = "4";
                break;
            case "2005":
                relation = "6";
                break;
            case "2007":
                relation = "5";
                break;
            case "2009":
                relation = "3";
                break;
            case "2010":
                relation = "2";
                break;
            case "2011":
                relation = "2";
                break;
            case "2012":
                relation = "4";
                break;
            case "2371":
                relation = "0";
                break;
            case "2375":
                relation = "1";
                break;
            case "2377":
                relation = "3";
                break;
            case "2381":
                relation = "2";
                break;
            case "2382":
                relation = "2";
                break;
            default:
                relation = "6";
                break;
        }
        return relation;
    }
}
