package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AuthenticatePersonalInformationDO;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.authorization.model.RongBizData;
import com.xyb.order.app.client.authorization.service.TianJiService;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.common.constant.AuthorizationConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.tianji.sample.TianjiSample;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service(interfaceName = "com.xyb.order.app.client.authorization.service.TianJiService")
public class TianJiServiceImpl implements TianJiService {

    private static final Logger log = LoggerFactory.getLogger(TianJiServiceImpl.class);

    /**融360社保回调接口*/
    @Value("${insure.rong360.back.url}")
    private String insureRong360BackUrl;
    /**融360公积金回调接口*/
    @Value("${fund.rong360.back.url}")
    private String fundRong360BackUrl;
    /**融360征信回调接口*/
    @Value("${zx.rong360.back.url}")
    private String zxRong360BackUrl;
    /**融360返回地址*/
    @Value("${rong360.return.url}")
    private String rong360ReturnUrl;

    @Value("${method.collectuser}")
    private String methodCollectuser;
    @Value("${insure.type}")
    private String insureType;
    @Value("${fund.type}")
    private String fundType;
    @Value("${zx.type}")
    private String zxType;
    @Value("${rong360.appid}")
    private String rongAppid;

    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private ApplyPersonDao applyPersonDao;

    @Override
    public RestResponse crawlerInsure()throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.TIANJI_SOCIAL_SECURITY.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
                RongBizData rongBizData = perInfoToRongBizData(informationDO,applyId);
                if (rongBizData == null){
                    response = new RestResponse(MsgErrCode.FAIL);
                }else {
                    rongBizData.setReturnUrl(rong360ReturnUrl+"/"+applyId+"/"+user.getId()+"/"+SysDictEnum.TIANJI_SOCIAL_SECURITY.getCode());
                    rongBizData.setType(insureType);
                    rongBizData.setNotifyUrl(insureRong360BackUrl);
                    response = analysissRequest(rongBizData);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    @Override
    public RestResponse crawlerFund()throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.TIANJI_ACCUMULATION_FUND.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
                RongBizData rongBizData = perInfoToRongBizData(informationDO,applyId);
                if (rongBizData == null){
                    response = new RestResponse(MsgErrCode.FAIL);
                }else {
                    rongBizData.setReturnUrl(rong360ReturnUrl+"/"+applyId+"/"+user.getId()+"/"+SysDictEnum.TIANJI_ACCUMULATION_FUND.getCode());
                    rongBizData.setType(fundType);
                    rongBizData.setNotifyUrl(fundRong360BackUrl);
                    response = analysissRequest(rongBizData);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    @Override
    public RestResponse crawlerZX()throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.TIANJI_INTERNET_BUSINESS.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
                RongBizData rongBizData = perInfoToRongBizData(informationDO,applyId);
                if (rongBizData == null){
                    response = new RestResponse(MsgErrCode.FAIL);
                }else {
                    rongBizData.setReturnUrl(rong360ReturnUrl+"/"+applyId+"/"+user.getId()+"/"+SysDictEnum.TIANJI_INTERNET_BUSINESS.getCode());
                    rongBizData.setType(zxType);
                    rongBizData.setNotifyUrl(zxRong360BackUrl);
                    response = analysissRequest(rongBizData);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    /**
    * 组装参数
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/16 下午8:43
    */
    private RongBizData perInfoToRongBizData(AuthenticatePersonalInformationDO informationDO,Long applyId){
        RongBizData rongBizData;
        if (informationDO != null){
            rongBizData = new RongBizData();
            rongBizData.setPlatform("web");
            rongBizData.setName(informationDO.getName());
            rongBizData.setPhone(informationDO.getPhone());
            rongBizData.setIdNumber(informationDO.getIdcard());
            rongBizData.setUserId(applyId+"");
            rongBizData.setOutUniqueId(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
            rongBizData.setHomeAddr(informationDO.getFamilyAddress());
            rongBizData.setCompanyAddr(informationDO.getWorkAddress());
        }else {
            rongBizData = null;
        }
        return rongBizData;
    }

    /**
    * 解析返回数据
    * @author      xieqingyang
    * @return
    * @exception
    * @date        2018/5/16 下午8:44
    */
    private RestResponse analysissRequest(RongBizData rongBizData){
        RestResponse response;
        TianjiSample sample = new TianjiSample();
        //设置Appid
        sample.setAppId(rongAppid);
        // 设置机构私钥，需要机构替换private_key.pem文件
        sample.setPrivateKey(AuthorizationConstant.PRIBATEKEY_RONG);
        // 设置是否为请求测试环境
        sample.setIsTestEnv(false);
        String method = methodCollectuser;
        try {
            log.info("———————————调用融360获取h5方法参数applyId:"+rongBizData.getUserId()+";"+JsonUtils.toJSON(rongBizData));
            JSONObject ret = sample.doOpenApiRequest(method, rongBizData.getMap());
            log.info("————————————融360返回数据applyId:"+rongBizData.getUserId()+";"+ret.toString());
            if (ret.containsKey("error")){
                if (AuthorizationConstant.STATUS_CODE_SUCCESS.equals(ret.getString("error"))){
                    JSONObject collectuserResponse = ret.getJSONObject("tianji_api_tianjireport_collectuser_response");
                    response = new RestResponse(MsgErrCode.SUCCESS,collectuserResponse.getString("redirectUrl"));
                }else {
                    log.info("失败");
                    response = new RestResponse(MsgErrCode.FAIL);
                }
            }else {
                response = new RestResponse(MsgErrCode.FAIL);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.info("解析融360返回数据异常");
            response = new RestResponse(MsgErrCode.FAIL);
        }
        return response;
    }
}
