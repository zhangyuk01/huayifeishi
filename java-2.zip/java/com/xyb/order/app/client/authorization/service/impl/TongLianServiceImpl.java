package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.allinpay.mcp.comm.AllinpayUtils;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.TongLianLogDTO;
import com.xyb.order.app.client.authorization.model.TongLianVerifyInfoDO;
import com.xyb.order.app.client.authorization.service.TongLianService;
import com.xyb.order.common.util.HttpTools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * @author : weiyuhao
 * @projectName :
 * @package : com.xyb.order.app.client.authorization.service.impl
 * @description :
 * @createDate : 2018/9/25 10:14
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.app.client.authorization.service.TongLianService")
public class TongLianServiceImpl implements TongLianService {

    private static final Logger log = LoggerFactory.getLogger(TongLianServiceImpl.class);

    @Autowired
    private AuthorizationDao authorizationDao;

    @Value("${tonglian.url}")
    private String url;

    @Value("${tonglian.privatekey}")
    private String privateKey;

    @Value("${tonglian.merId}")
    private String merId;

    @Value("${tonglian.key}")
    private String Key;

    /**
     * 通联身份证校验
     *
     * @param tongLianVerifyInfoDO
     * @return
     * @throws Exception
     */
    @Override
    public Map verifyIdCard(TongLianVerifyInfoDO tongLianVerifyInfoDO) throws Exception {
        Map result = new HashMap();
        HashMap params = new HashMap();
        params.put("name",URLEncoder.encode(tongLianVerifyInfoDO.getName(), "UTF-8"));
        params.put("idCard",tongLianVerifyInfoDO.getIdCard());
        params.put("custOrderId", null);
        params.put("merId", merId);
        String params_src = JSON.toJSONString(params);
        AllinpayUtils allinpayUtils = new AllinpayUtils();
        //2  使用私钥，加密json格式参数
        String params_encrypt = allinpayUtils.encryptByPrivateKey(params_src, privateKey);
        //3  使用私钥，生成sign
        String sign = allinpayUtils.sign(params_src, privateKey);
        try {
            String requestUrl = url+"key="+Key+"&sign="+ URLEncoder.encode(sign, "UTF-8")+"&params="+URLEncoder.encode(params_encrypt, "UTF-8");
            String data =  HttpTools.sendGet(requestUrl);
            if(data != null && !"".equals(data)) {
                TongLianLogDTO tongLianLogDTO = new TongLianLogDTO();
                JSONObject resultData = (JSONObject) JSONObject.parse(data);
                String code = (String) resultData.get("code");
                String msg = (String) resultData.get("msg");
                String seralNo = (String) resultData.get("seralNo");
                //code:000000 业务查询成功，返回正确结果 其他都为接口调用异常记录异常日志
                if ("000000".equals(code)) {
                    JSONObject resultParam = (JSONObject) resultData.get("data");
                    //result: 0、通过；1、不通过；2、处理失败
                    result.put("result",(String) resultParam.get("result"));
                    result.put("resultMsg",(String) resultParam.get("resultMsg"));
                    tongLianLogDTO.setCode(code);
                    tongLianLogDTO.setName(tongLianVerifyInfoDO.getName());
                    tongLianLogDTO.setIdCard(tongLianVerifyInfoDO.getIdCard());
                    tongLianLogDTO.setResult(result.toString());
                    tongLianLogDTO.setSeralNo(seralNo);
                    this.addVerifyLog(tongLianLogDTO);
                } else {
                    result.put("result",code);
                    result.put("resultMsg","认证失败，请稍后再试");
                    tongLianLogDTO.setCode(code);
                    tongLianLogDTO.setName(tongLianVerifyInfoDO.getName());
                    tongLianLogDTO.setIdCard(tongLianVerifyInfoDO.getIdCard());
                    tongLianLogDTO.setResult(msg);
                    tongLianLogDTO.setSeralNo(seralNo);
                    this.addVerifyLog(tongLianLogDTO);
                }
            }else{
                result.put("result","111111");
                result.put("resultMsg","请求超时，请稍后再试");
            }
        }catch (Exception e){
            e.printStackTrace();
            log.debug("通联认证接口异常："+e.toString());
            System.out.println("通联认证接口异常:"+e.toString());
        }
        return result;
    }

    /**
     * 保存通联认证调用日志
     *
     * @throws Exception
     */
    @Override
    public void addVerifyLog(TongLianLogDTO tongLianLogDTO) throws Exception {
        authorizationDao.addVerifyLog(tongLianLogDTO);
    }

    /**
     * 获取当天认证次数
     *
     * @param tongLianVerifyInfoDO
     * @return
     * @throws Exception
     */
    @Override
    public int getVerifyCountQuantityByIdCard(TongLianVerifyInfoDO tongLianVerifyInfoDO) throws Exception {
        int num = authorizationDao.getVerifyCountQuantityByIdCard(tongLianVerifyInfoDO);
        return num;
    }
}
