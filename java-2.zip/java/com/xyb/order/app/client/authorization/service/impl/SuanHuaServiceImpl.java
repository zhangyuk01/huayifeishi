package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AuthenticatePersonalInformationDO;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.authorization.model.SuanHuaDTO;
import com.xyb.order.app.client.authorization.model.SuanHuaRegisterDTO;
import com.xyb.order.app.client.authorization.service.SuanHuaService;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.common.constant.AuthorizationConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.common.util.SuanHuaUtil;
import com.xyb.risks.process.suanhua.service.SuanhuaService;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Service(interfaceName = "com.xyb.order.app.client.authorization.service.SuanHuaService")
public class SuanHuaServiceImpl implements SuanHuaService {

    private static final Logger log = LoggerFactory.getLogger(SuanHuaServiceImpl.class);

    /**算话提供的机构号*/
    @Value("${orgcode}")
    private String orgcode;
    /**算话提供的机构号*/
    @Value("${private.key}")
    private String privateKey;
    /**算话提供人行注册接口地址，供机构调用*/
    @Value("${suanhua.register}")
    private String suanhuaRegister;

    @Autowired
    private AuthorizationDao authorizationDao;
    @Reference
    private SuanhuaService suanhuaService;
    @Autowired
    private ApplyPersonDao applyPersonDao;

    @Override
    public RestResponse register(SuanHuaRegisterDTO dto) throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(applyId);
        if (informationDO == null){
            return new RestResponse(MsgErrCode.FAIL);
        }
        if (!SuanHuaUtil.pwdVerification(dto.getLoginpwd())){
            response = new RestResponse(NativeMsgErrCode.ERROR_PASSWORD_SUANHUA);
        }else {
            JSONObject dataJson = analysisDataRegister(dto);
            Map<String, String> param = new TreeMap<String, String>();
            param.put("orgcode", orgcode);
            param.put("name",informationDO.getName());
            param.put("idCard",informationDO.getIdcard());
            param.put("data",dataJson.toString());
            param.put("hash", SuanHuaUtil.md5(param.get("data") + param.get("idCard") + param.get("name") + param.get("orgcode") + privateKey,"UTF-8"));
            String result = SuanHuaUtil.sendPost(suanhuaRegister, param, "UTF-8");
            response = analysis(result);
        }
        return response;
    }

    @Override
    public RestResponse suanhuaPush(SuanHuaDTO suanHuaDTO)throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(Long.valueOf(applyId));
                if (informationDO != null){
                    // -- 组装算话需要的信息
                    suanHuaDTO.setName(informationDO.getName());
                    suanHuaDTO.setIdCard(informationDO.getIdcard());
                    suanHuaDTO.setApplyId(applyId);
                    try {
                        response = new RestResponse(MsgErrCode.SUCCESS,suanhuaService.suanhuaPush(JsonUtil.object2json(suanHuaDTO)));
                    }catch (Exception e){
                        e.printStackTrace();
                        log.info("调用风控算话申请接口异常");
                        response = new RestResponse(MsgErrCode.FAIL);
                    }
                }else {
                    response = new RestResponse(MsgErrCode.FAIL);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    @Override
    public RestResponse invokExtractReport(SuanHuaDTO suanHuaDTO)throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("authorizationType",SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode());
        paraMap.put("applyId",applyId);
        AuthorizationProductDO productDO = authorizationDao.queryAuthorizationType(paraMap);
        if (productDO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            if (SysDictEnum.YES.getCode().equals(productDO.getIsOpen())){
                AuthenticatePersonalInformationDO informationDO = authorizationDao.getPersonalInfo(Long.valueOf(applyId));
                if (informationDO != null){
                    // -- 组装算话需要的信息
                    suanHuaDTO.setName(informationDO.getName());
                    suanHuaDTO.setIdCard(informationDO.getIdcard());
                    suanHuaDTO.setApplyId(applyId);
                    try {
                        response = new RestResponse(MsgErrCode.SUCCESS,suanhuaService.invokExtractReport(JSONObject.fromObject(suanHuaDTO)));
                    }catch (Exception e){
                        e.printStackTrace();
                        log.info("调用风控算话提取报告接口异常");
                        response = new RestResponse(MsgErrCode.FAIL);
                    }
                }else {
                    response = new RestResponse(MsgErrCode.FAIL);
                }
            }else {
                response = new RestResponse(NativeMsgErrCode.IS_CLOSE);
            }
        }
        return response;
    }

    /**
    * 组装返回数据
    * @author      xieqingyang
    * @param dto
    * @return
    * @exception
    * @date        2018/5/17 上午10:11
    */
    private JSONObject analysisDataRegister(SuanHuaRegisterDTO dto){
        JSONObject returnJson = new JSONObject();
        // -- 短信验证
        if (AuthorizationConstant.CODE.equals(dto.getRetCode())){
            String phone = dto.getPhone();
            String activationCode = dto.getActivationCode();
            String iid = dto.getIid();
            returnJson.put("phone",phone);
            returnJson.put("activationCode",activationCode);
            returnJson.put("iid",iid);
        }else {
            String phone = dto.getPhone();
            String loginname = dto.getLoginname();
            String loginpwd = dto.getLoginpwd();
            returnJson.put("phone",phone);
            returnJson.put("loginname",loginname);
            returnJson.put("loginpwd",loginpwd);
            returnJson.put("idname","");
            returnJson.put("idno","");
        }
        return returnJson;
    }

    /**
    * 解析返回数据
    * @author      xieqingyang
    * @param result 结果
    * @date        2018/5/17 上午10:29
    */
    private RestResponse analysis(String result)throws Exception{
        RestResponse response;
        if (StringUtils.isNotNullAndEmpty(result)) {
            JSONObject jsonObject = JSONObject.fromObject(result);
            boolean success = jsonObject.getBoolean("success");
            String errors = jsonObject.getString("errors");
            if (!success) {
                response = new RestResponse(1,errors);
            } else {
                JSONObject data = JSONObject.fromObject(jsonObject.getString("data"));
                if (!data.containsKey("resp") && "00".equals(data.getString("retCode"))){
                    data.put("retCode","1");
                }
                response = new RestResponse(MsgErrCode.SUCCESS,data);
            }
        }else {
            response = new RestResponse(MsgErrCode.FAIL);
        }
        return response;
    }
}
