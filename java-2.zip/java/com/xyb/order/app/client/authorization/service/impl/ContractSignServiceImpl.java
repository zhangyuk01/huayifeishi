package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.DateTimeUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.*;
import com.xyb.order.app.client.authorization.service.ContractSignService;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.fdd.service.FddService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.common.util.NumberToCN;
import com.xyb.order.common.util.StringUtils;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import java.math.BigDecimal;
import java.util.*;

/**
 * 签约相关功能
 * @author         xieqingyang
 * @date     2018/6/9 下午12:02
*/
@Service(interfaceName = "com.xyb.order.app.client.authorization.service.ContractSignService")
public class ContractSignServiceImpl implements ContractSignService {

    private static final Logger log = LoggerFactory.getLogger(ContractSignServiceImpl.class);

    /**个人信息采集、查询、授权书模版ID*/
    @Value("${authorize.templateid}")
    private String authorizeTemplateid;
    /**委托扣款授权书、借款人声明函模版ID*/
    @Value("${loan.col.templateid}")
    private String loanColTemplateid;
    /**借款服务协议模版ID*/
    @Value("${loan.service.templateid}")
    private String loanServiceTemplateid;
    /**法大大公司名称*/
    @Value("${fadada.company.name}")
    private String fddCompanyName;

    @Autowired
    private ApplyPersonDao applyPersonDao;
    @Autowired
    private ClientRedisUtil clientRedisUtil;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private FddService fddService;
    @Autowired
    private BankDao bankDao;

    @Override
    public RestResponse personalAuth() throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        // -- 判断用户是否实名认证
        if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
        }
        // -- 判断用户是否已经签约成功法大大ca证书
        if (StringUtils.isNullOrEmpty(clientAuthenticationDO.getCustomerId())){
            response = fddService.invokeSyncPersonAuto(clientAuthenticationDO.getId());
            if (response.getResult() != 0){
                return response;
            }else {
                clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
            }
        }
        // -- 判断是否已经签约完成
        if (SysDictEnum.HAVE_SUGNED_CONTRACT.getCode().equals(clientAuthenticationDO.getAgreementCompleted())){
            response = new RestResponse(MsgErrCode.FAIL);
            response.setDescription("已签约完成!");
            return response;
        }
        // -- 调用法大大合同生成接口
        // -- 生成法大大合同编号
        String contractId = UUID.randomUUID().toString().trim().replaceAll("-", "");
        JSONObject parameterMap = new JSONObject();
        parameterMap.put("contractNo2",String.valueOf(clientAuthenticationDO.getId()));
        parameterMap.put("borrowerName2",clientAuthenticationDO.getName());
        parameterMap.put("sex",IdCardUtil.getSex(clientAuthenticationDO.getIdCard()));
        parameterMap.put("identificationNumber2",clientAuthenticationDO.getIdCard());
        parameterMap.put("telephoneNo2",user.getLoginId());
        parameterMap.put("name",clientAuthenticationDO.getName());
        parameterMap.put("date",DateTimeUtil.getDate());
        RestResponse resultResp = fddService.invokeGenerateContract(authorizeTemplateid,contractId,"个人信息采集、查询、授权书",null,null,parameterMap.toString(),null,clientAuthenticationDO.getId(),user.getId());
        // -- 成功
        if (resultResp.getResult() == 0){
            AgreementInFoDO agreement = addAgreement(resultResp.getData(),SysDictEnum.AUTHORIZE_URL.getCode(),contractId,user.getId(),clientAuthenticationDO.getId(),null);
            if (agreement != null){
                List<AgreementInFoDO> list = new ArrayList<>();
                list.add(agreement);
                authorizationDao.insertAgreementinFoList(list);
            }
        }else {
            return new RestResponse(MsgErrCode.FAIL);
        }
        // -- 让用户去调用签署接口
        String transactionId = UUID.randomUUID().toString().trim().replaceAll("-", "");
        String signUrl = fddService.invokeExtSign(transactionId,clientAuthenticationDO.getCustomerId(),contractId,"个人信息采集、查询、授权书","授权人(签章)",clientAuthenticationDO.getId(),user.getId());
        response = new RestResponse(MsgErrCode.SUCCESS);
        response.setData(signUrl);
        return response;
    }

    @Override
    public RestResponse loanCol() throws Exception {
        RestResponse restResponse;
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("clientUserId",user.getId());
        paraMap.put("list", Arrays.asList(NodeStateConstant.CONTRACT_ENTRY));
        // -- 查询客户申请单信息
        FddClientApplyInFoDTO fddClientApplyInFoDTO = applyPersonDao.getFddClientApplyInFo(paraMap);
        if (fddClientApplyInFoDTO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        // -- 判断用户是否实名认证
        if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
        }
        // -- 判断用户是否已经签约成功法大大ca证书
        if (StringUtils.isNullOrEmpty(clientAuthenticationDO.getCustomerId())){
            restResponse = fddService.invokeSyncPersonAuto(clientAuthenticationDO.getId());
            if (restResponse.getResult() != 0){
                return restResponse;
            }
            clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        }
        // -- 判断是否已经签约完成借款人服务协议和委托扣款协议书、先签约委托扣款协议书
        paraMap.put("agreementType",SysDictEnum.LOAN_SERVICE_URL.getCode());
        paraMap.put("cusId",clientAuthenticationDO.getId());
        paraMap.put("applyId",fddClientApplyInFoDTO.getApplyId());
        paraMap.put("isValid",SysDictEnum.IS_VALID.getCode());
        int count = authorizationDao.getAgreementInFoCount(paraMap);
        if (count > 0){
            return new RestResponse(NativeMsgErrCode.HAVE_SIGNED_CONTRACT);
        }
        // -- 判断是否签约过委托扣款协议书
        paraMap.put("agreementType",SysDictEnum.LOAN_COL_URL.getCode());
        count = authorizationDao.getAgreementInFoCount(paraMap);
        // -- 调用法大大合同生成接口
        // -- 查询用户的银行卡信息
        ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
        paraClient.setClientId(clientAuthenticationDO.getId());
        paraClient.setState(SysDictEnum.YES.getCode());
        paraClient.setIsDefault(SysDictEnum.YES.getCode());
        List<ClientBankInfoNoDO> list = bankDao.queryClientBankInFoNo(paraClient);
        if (list == null || list.size() == 0){
            return new RestResponse(NativeMsgErrCode.NO_EXISTENCE);
        }
        // -- 生成法大大合同编号
        String contractId = UUID.randomUUID().toString().trim().replaceAll("-", "");
        JSONObject parameterMap = new JSONObject();
        RestResponse resultResp;
        String docTitle;
        Long agreementType;
        String date = DateTimeUtil.getDate();
        String templateid;
        // -- 签约委托扣款协议书
        if (count < 1){
            parameterMap.put("borrowerName",clientAuthenticationDO.getName());
            parameterMap.put("contractNo",String.valueOf(fddClientApplyInFoDTO.getMainId()));
            parameterMap.put("identificationNumber",clientAuthenticationDO.getIdCard());
            parameterMap.put("bankAccountName",list.get(0).getBankRealName());
            parameterMap.put("bankAccountId",list.get(0).getBankNum());
            parameterMap.put("telephoneNo",list.get(0).getPhone());
            parameterMap.put("contractNo3",String.valueOf(fddClientApplyInFoDTO.getApplyId()));
            parameterMap.put("borrowerName3",clientAuthenticationDO.getName());
            parameterMap.put("userid",String.valueOf(user.getId()));
            parameterMap.put("idType","身份证");
            parameterMap.put("idNumber",clientAuthenticationDO.getIdCard());
            parameterMap.put("purpose",fddClientApplyInFoDTO.getBorrowDesc());
            parameterMap.put("kfphone","400-687-0880");
            parameterMap.put("date",date);
            docTitle = "《委托扣款授权书》《借款人声明函》";
            agreementType = SysDictEnum.LOAN_COL_URL.getCode();
            templateid = loanColTemplateid;
        // -- 签约借款人服务协议
        }else {
            parameterMap.put("htnum",fddClientApplyInFoDTO.getApplyNum());
            parameterMap.put("name",clientAuthenticationDO.getName());
            parameterMap.put("userid",String.valueOf(user.getId()));
            parameterMap.put("idtype","身份证");
            parameterMap.put("idnumber",clientAuthenticationDO.getIdCard());
            parameterMap.put("jkje",NumberToCN.number2CNMontrayUnit(fddClientApplyInFoDTO.getContractMoney().setScale(2,BigDecimal.ROUND_DOWN)));
            parameterMap.put("jkje2",fddClientApplyInFoDTO.getContractMoney().setScale(2,BigDecimal.ROUND_DOWN).toString());
            parameterMap.put("rate",fddClientApplyInFoDTO.getProductProrotion().multiply(new BigDecimal(12)).setScale(4,BigDecimal.ROUND_DOWN).toString());
            parameterMap.put("fwfee",NumberToCN.number2CNMontrayUnit(fddClientApplyInFoDTO.getServiceAmount().setScale(2,BigDecimal.ROUND_DOWN)));
            parameterMap.put("fwfee2",fddClientApplyInFoDTO.getServiceAmount().setScale(2,BigDecimal.ROUND_DOWN).toString());
            parameterMap.put("name2",clientAuthenticationDO.getName());
            parameterMap.put("xyb",fddCompanyName);
            parameterMap.put("date1",date);
            parameterMap.put("date2",date);
            docTitle = "《信用宝借款信息咨询与服务协议》";
            agreementType = SysDictEnum.LOAN_SERVICE_URL.getCode();
            templateid = loanServiceTemplateid;
        }
        resultResp = fddService.invokeGenerateContract(templateid,contractId,docTitle,null,null,parameterMap.toString(),null,clientAuthenticationDO.getId(),user.getId());
        // -- 成功
        if (resultResp.getResult() == 0){
            AgreementInFoDO agreement = addAgreement(resultResp.getData(),agreementType,contractId,user.getId(),clientAuthenticationDO.getId(),fddClientApplyInFoDTO.getApplyId());
            if (agreement != null){
                List<AgreementInFoDO> agreements = new ArrayList<>();
                agreements.add(agreement);
                authorizationDao.insertAgreementinFoList(agreements);
            }
        }else {
            return new RestResponse(MsgErrCode.FAIL);
        }
        // -- 让用户去调用签署接口
        String transactionId = UUID.randomUUID().toString().trim().replaceAll("-", "");
        String signUrl = fddService.invokeExtSign(transactionId,clientAuthenticationDO.getCustomerId(),contractId,docTitle,"借款人（签章）",clientAuthenticationDO.getId(),user.getId());
        restResponse = new RestResponse(MsgErrCode.SUCCESS);
        restResponse.setData(signUrl);
        return restResponse;
    }


    @Override
    public RestResponse queryAgreementInFo(QueryAgreementDTO queryAgreementDTO) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        if (clientAuthenticationDO == null){
            return new RestResponse(NativeMsgErrCode.NON_QUALIFIED_ACCOUNT);
        }
        List<AgreementInFoVO> agreementInFoVOS  = new ArrayList<>();
        AgreementInFoVO agreement;
        List<AgreementListVO> vos;
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("cusId",clientAuthenticationDO.getId());
        paraMap.put("isValid",SysDictEnum.IS_VALID.getCode());
        paraMap.put("type",SysDictEnum.AUTHORIZE_URL.getCode());
        // -- 查询《个人信息采集、查询、授权书》
        AgreementListVO authorize = authorizationDao.queryAgreementInFo(paraMap);
        vos = new ArrayList<>();
        agreement = new AgreementInFoVO();
        vos.add(authorize);
        agreement.setList(vos);
        agreement.setType(SysDictEnum.AUTHORIZE_URL.getCode());
        agreementInFoVOS.add(agreement);
        paraMap.put("type",SysDictEnum.LOAN_COL_URL.getCode());
        paraMap.put("applyId",queryAgreementDTO.getApplyId());
        // -- 查询《委托扣款授权书》 《借款人声明函》
        AgreementListVO loanCol = authorizationDao.queryAgreementInFo(paraMap);
        vos = new ArrayList<>();
        agreement = new AgreementInFoVO();
        vos.add(loanCol);
        agreement.setList(vos);
        agreement.setType(SysDictEnum.LOAN_COL_URL.getCode());
        agreementInFoVOS.add(agreement);
        paraMap.put("type",SysDictEnum.LOAN_SERVICE_URL.getCode());
        // -- 查询《信用宝借款信息咨询与服务协议》
        AgreementListVO loanService = authorizationDao.queryAgreementInFo(paraMap);
        vos = new ArrayList<>();
        agreement = new AgreementInFoVO();
        vos.add(loanService);
        agreement.setList(vos);
        agreement.setType(SysDictEnum.LOAN_SERVICE_URL.getCode());
        agreementInFoVOS.add(agreement);
        return new RestResponse(MsgErrCode.SUCCESS,agreementInFoVOS);
    }


    /**
     * @description 解析法大大生成合同接口返回数据并保存
     * @author      xieqingyang
     * @CreatedDate 2018/8/1 下午2:02
     * @Version     1.0
     * @param data 法大大的数据
     * @param agreementType 协议类型
     * @param contractId 法大大啊合同ID
     * @param operatorUser 操作人
     * @param clientId 用户信息表ID
     * @param applyId 申请单ID
     * @return 返回协议model
     */
    private AgreementInFoDO addAgreement(Object data,Long agreementType,String contractId,Long operatorUser,Long clientId,Long applyId){
        AgreementInFoDO agreementInFoDO = null;
        JSONObject resultJson = JSONObject.fromObject(data);
        // -- 合同下载地址
        String downloadUrl = null;
        // -- 合同查看地址
        String viewpdfUrl = null;
        if (resultJson.containsKey(AuthorizationConstant.DOWNLOAD_URL)){
            downloadUrl = resultJson.getString(AuthorizationConstant.DOWNLOAD_URL);
        }
        if (resultJson.containsKey(AuthorizationConstant.VIEWPDF_URL)){
            viewpdfUrl = resultJson.getString(AuthorizationConstant.VIEWPDF_URL);
        }
        if (StringUtils.isNotNullAndEmpty(downloadUrl) && StringUtils.isNotNullAndEmpty(viewpdfUrl)){
            agreementInFoDO = new AgreementInFoDO();
            agreementInFoDO.setDownloadAddress(downloadUrl);
            agreementInFoDO.setLookAddress(viewpdfUrl);
            agreementInFoDO.setIsValid(SysDictEnum.NO_VALID.getCode());
            agreementInFoDO.setApplyId(applyId);
            agreementInFoDO.setCusId(clientId);
            agreementInFoDO.setAgreementType(agreementType);
            agreementInFoDO.setCreateUser(operatorUser);
            agreementInFoDO.setContractId(contractId);
        }
        return agreementInFoDO;
    }
}
