package com.xyb.order.app.client.authorization.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.constant.Constant;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.beiming.kun.utils.UUIDUtil;
import com.fadada.sdk.client.FddClientBase;
import com.xyb.auth.user.model.User;
import com.xyb.credit.common.model.SystemAuditParamDTO;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.*;
import com.xyb.order.app.client.authorization.service.AuthorizationService;
import com.xyb.order.app.client.authorization.service.TongLianService;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.PersonalAddressDTO;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.TableModifyLogDTO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.fdd.dao.FddDao;
import com.xyb.order.common.fdd.model.FddLogDO;
import com.xyb.order.common.fdd.service.FddService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import com.xyb.order.common.util.*;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.consultation.dao.ConsultationDao;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.service.FastFileStorageService;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

@Service(interfaceName = "com.xyb.order.app.client.authorization.service.AuthorizationService")
public class AuthorizationServiceImpl implements AuthorizationService {

    private static final Logger log = LoggerFactory.getLogger(AuthorizationServiceImpl.class);

    /**app_id*/
    @Value("${app.id}")
    private String appId;

    /**app_secret*/
    @Value("${app.secret}")
    private String appSecret;

    /**法大大地址*/
    @Value("${fadada.url}")
    private String fddUrl;

    /**法大大版本号*/
    @Value("${fadada.version}")
    private String fddVersion;

    /**是否是正式环境*/
    @Value("${is.formal}")
    private String isFormal;

    /**通联验证开关*/
    @Value("${tongLian.switch}")
    private String tongLianSwitch;

    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private ClinetUserDao clinetUserDao;
    @Autowired
    private TableModifyLogService tableModifyService;
    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private ConsultationDao consultationDao;
    @Autowired
    private FastFileStorageService fastFileStorageService;
    @Autowired
    private ApplyPersonDao applyPersonDao;
    @Resource(name = "jmsQueueTemplate")
    private JmsTemplate jmsQueueTemplate;
    @Autowired
    private OtherPlatformRelevantService otherPlatformRelevantService;
    @Reference
    private ForeignService foreignservice;
    @Autowired
    private FddService fddService;
    @Autowired
    private FddDao fddDao;
    @Autowired
    private TongLianService tongLianService;


    @Override
    public RestResponse queryAuthorizationList()throws Exception{
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
        List<AuthorizationResultVO> authorizationResultVOS = new ArrayList<>();
        if (authorizationListVO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            // -- 获取风控报告有效时间
            Map<String,Integer> maps = null;
            try {
                maps = foreignservice.getAuthorizationValidTimeOfOrder();
            }catch (Exception e){
                e.printStackTrace();
                log.error("获取风控报告有效时间异常:"+e);
            }
            if (maps == null){
                maps = new HashMap<>(0);
            }
            authorizationListVO.setExpectMoney(authorizationListVO.getExpectMoney().substring(0,authorizationListVO.getExpectMoney().indexOf(".")));
            authorizationListVO.setExpectTerm(authorizationListVO.getExpectTerm() + "个月");
            List<AuthorizationProductDO> doList = authorizationDao.queryAuthorizationProduct(authorizationListVO.getProductId());
            Map<String,Object> paraMap = new HashMap<>();
            int count;
            for (AuthorizationProductDO productDO:doList){
                AuthorizationResultVO authorizationResultVO = new AuthorizationResultVO();
                authorizationResultVO.setAuthorizationType(productDO.getAuthorizationType() + "");
                authorizationResultVO.setAuthorizationTypeName(productDO.getAuthorizationTypeName());
                authorizationResultVO.setForceType(SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())?CurrencyConstant.N:CurrencyConstant.Y);
                paraMap.put("authorizationType",productDO.getAuthorizationType());
                paraMap.put("applyId",applyId);
                paraMap.put("isSuccess",SysDictEnum.YES.getCode());
                Integer time = maps.get(productDO.getAuthorizationType().toString());
                paraMap.put("time",time == null?1:time);
                count = authorizationDao.getAuthorizationInfoCount(paraMap);
                if (count > 0){
                    authorizationResultVO.setResult("成功");
                    authorizationResultVOS.add(authorizationResultVO);
                    continue;
                }else {
                    authorizationResultVO.setResult("待授权");
                    paraMap.remove("isSuccess");
                    count = authorizationDao.getAuthorizationInfoCount(paraMap);
                    if (count > 0){
                        if (SysDictEnum.COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                            authorizationResultVO.setResult("成功");
                        }else {
                            authorizationResultVO.setResult("待授权");
                        }
                    }else {
                        authorizationResultVO.setResult("待授权");
                    }
                }
                authorizationResultVOS.add(authorizationResultVO);
            }
            authorizationListVO.setApplyId(applyId);
            authorizationListVO.setAuthorizationResultVOS(authorizationResultVOS);
            authorizationListVO.setPhone(user.getLoginId());
            response = new RestResponse(MsgErrCode.SUCCESS,authorizationListVO);
        }
        return response;
    }

    @Override
    public boolean updateAuthorizationProductAdditional(AuthorizationProductDO authorizationProductDO) {
        boolean boo = false;
        if (authorizationProductDO != null){
            if (SysDictEnum.YES.getCode().equals(authorizationProductDO.getIsAdditional())){
                authorizationProductDO.setForceType(SysDictEnum.EMPOWERMENT_SUCCESS.getCode());
                authorizationProductDO.setIsOpen(SysDictEnum.YES.getCode());
            }else {
                authorizationProductDO.setForceType(SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode());
            }
            if (authorizationProductDO.getProductId() != null && authorizationProductDO.getAuthorizationType() == null){
                Map<String,Object> paraMap = new HashMap<>(2);
                paraMap.put("typeId",SysDictEnum.TIANJI_SOCIAL_SECURITY.getParentCode());
                paraMap.put("state",SysDictEnum.IS_VALID.getCode());
                List<Map<String,Object>> sys = currencyDao.findSysDict(paraMap);
                if (sys != null && sys.size() > 0){
                    for (Map<String,Object> map:sys){
                        Long id = (Long) map.get("id");
                        if (!SysDictEnum.SUANHUA_REGISTER.getCode().equals(id)) {
                            authorizationProductDO.setAuthorizationType(id);
                            int count = authorizationDao.updateAuthorizationProductAdditional(authorizationProductDO);
                            // -- 如果没有代表添加
                            if (count == 0 && authorizationProductDO.getProductId() != null && authorizationProductDO.getAuthorizationType() != null) {
                                authorizationDao.insertAuthorizationProduct(authorizationProductDO);
                            }
                        }
                    }
                }
            }
            int count = authorizationDao.updateAuthorizationProductAdditional(authorizationProductDO);
            // -- 如果没有代表添加
            if (count == 0 && authorizationProductDO.getProductId() != null && authorizationProductDO.getAuthorizationType() != null){
                authorizationDao.insertAuthorizationProduct(authorizationProductDO);
            }
            boo = true;
        }
        return boo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse identityInformation(IdentityInformationDTO dto) throws Exception {
        RestResponse response;
        TongLianVerifyInfoDO tongLianVerifyInfoDO = new TongLianVerifyInfoDO();
        tongLianVerifyInfoDO.setName(dto.getName());
        tongLianVerifyInfoDO.setIdCard(dto.getIdcard());
        Map results = new HashMap();
        //查询当天认证次数
        int num = tongLianService.getVerifyCountQuantityByIdCard(tongLianVerifyInfoDO);
        if(num <= 5) {
            //调用通联身份认证
            if(CurrencyConstant.Y.equals(tongLianSwitch)){
                 results = tongLianService.verifyIdCard(tongLianVerifyInfoDO);
            }else{
                results.put("result","0");
            }
            //认证通过
            if ("0".equals(results.get("result"))) {
                if (!new IdcardValidator().isValidate18Idcard(dto.getIdcard())) {
                    return new RestResponse(NativeMsgErrCode.ILLEGALITY_IDCARD);
                }
                if (!IdCardUtil.ansysic(dto.getIdcard(), dto.getBirthday())) {
                    response = new RestResponse(MsgErrCode.FAIL);
                    response.setDescription("出生日期错误");
                    return response;
                }
                User user = SessionUtil.getLoginUser(User.class);
                Map<String, Object> paraMap = new HashMap<>(10);
                paraMap.put("clientUserId", user.getId());
                paraMap.put("idcard", dto.getIdcard());
                // -- 验证重复
                ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
                if (!IdCardUtil.ifGrownUp(dto.getIdcard())) {
                    response = new RestResponse(NativeMsgErrCode.UNDER_AGE);
                } else if (applyClientInfoDO == null) {
                    paraMap.remove("idcard");
                    ApplyClientInfoDO infoDO = clinetUserDao.getApplyClientInfo(paraMap);
                    if (StringUtils.isNotNullAndEmpty(infoDO.getIdcard()) && !infoDO.getIdcard().equals(dto.getIdcard())) {
                        return new RestResponse(NativeMsgErrCode.NO_VALID_OPERATION);
                    }
                    if (StringUtils.isNotNullAndEmpty(infoDO.getName()) && !infoDO.getName().equals(dto.getName())) {
                        return new RestResponse(NativeMsgErrCode.NO_VALID_OPERATION);
                    }
                    applyClientInfoDO = new ApplyClientInfoDO();
                    // -- 存入客户信息
                    if (infoDO.getId() != null) {
                        applyClientInfoDO.setId(infoDO.getId());
                    }
                    SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
                    applyClientInfoDO.setName(dto.getName());
                    applyClientInfoDO.setGender(Long.valueOf(dto.getGender()));
                    applyClientInfoDO.setBirthday(sd.parse(dto.getBirthday()));
                    applyClientInfoDO.setIdcard(dto.getIdcard());
                    applyClientInfoDO.setPhone(user.getLoginId());
                    applyClientInfoDO.setAddress(dto.getAddress());
                    applyClientInfoDO.setIsvalid(SysDictEnum.YES.getCode());
                    applyClientInfoDO.setNation(Integer.valueOf(dto.getNation()));
                    applyClientInfoDO.setIdcardStartTime(sd.parse(dto.getIdcardStartTime()));
                    applyClientInfoDO.setIdcardEndTime(sd.parse(dto.getIdcardEndTime()));
                    applyClientInfoDO.setIdcardPoliceStation(dto.getIdcardPoliceStation());
                    applyClientInfoDO.setCertificationState(SysDictEnum.YES.getCode());
                    applyClientInfoDO.setCreateUser(user.getId());
                    applyClientInfoDO.setModifyUser(user.getId());
                    applyClientInfoDO.setClientUserId(user.getId());
                    byte[] imgByteFront = Base64.decodeBase64(dto.getIdcardFrontSide());
                    byte[] imgByteBack = Base64.decodeBase64(dto.getIdcardBackSide());
                    // -- 上线打开
                    // -- 调用法大大 验证是否实名认证
                    // -- 保存调用法大大接口日志
                    if (CurrencyConstant.Y.equals(isFormal)){
                        FddLogDO fddLogDO = new FddLogDO();
                        fddLogDO.setCreateUser(user.getId());
                        fddLogDO.setInterfaceName("个人 CA 申请接口");
                        JSONObject reqPmt = new JSONObject();
                        reqPmt.put("customer_name", applyClientInfoDO.getName());
                        fddLogDO.setReqPmt(reqPmt.toString());
                        fddDao.insertFddLog(fddLogDO);
                        // -- 调用法大大个人 CA 申请接口
                        FddClientBase fddClientBase = new FddClientBase(appId, appSecret, fddVersion, fddUrl);
                        String data = fddClientBase.invokeSyncPersonAuto(applyClientInfoDO.getName(), "", applyClientInfoDO.getIdcard(), "0", applyClientInfoDO.getPhone());
                        log.info("法大大返回结果：" + data);
                        String customerId = null;
                        String result = null;
                        String code = null;
                        String msg = null;
                        if (data != null) {
                            JSONObject resultJson = JSONObject.fromObject(data);
                            msg = resultJson.getString(AuthorizationConstant.FDD_MSG);
                            result = resultJson.getString(AuthorizationConstant.FDD_RESULT);
                            code = resultJson.getString(AuthorizationConstant.FDD_CODE);
                            if (resultJson.containsKey(AuthorizationConstant.FDD_CUSTOMER_ID)) {
                                customerId = resultJson.getString(AuthorizationConstant.FDD_CUSTOMER_ID);
                            }
                        }
                        // -- 修改调用法大大接口日志
                        fddLogDO.setRespPmt(data);
                        fddLogDO.setModifyUser(user.getId());
                        fddLogDO.setCode(code);
                        fddLogDO.setResult(result);
                        fddLogDO.setMsg(msg);
                        fddDao.updateFddLog(fddLogDO);
                        // -- 判断结果
                        if (AuthorizationConstant.FDD_RESULT_1000.equals(code)) {
                            applyClientInfoDO.setCustomerId(customerId);
                        } else {
                            response = new RestResponse(MsgErrCode.FAIL);
                            response.setDescription(msg);
                            return response;
                        }
                    }
                    // -- 调用图片服务器 存入身份证正面图片信息
                    ByteArrayInputStream inputStreame = new ByteArrayInputStream(imgByteFront);
                    String fileName = UUIDUtil.getUUID() + ".jpg";
                    //***** 上传图片服务器   *********//
                    ResultFileInfo uploadFile = this.fastFileStorageService.uploadFile(inputStreame, fileName, null);
                    // -- 调用图片服务器 存入身份证反面图片信息
                    ByteArrayInputStream inputStreameBack = new ByteArrayInputStream(imgByteBack);
                    String fileNameBack = UUIDUtil.getUUID() + ".jpg";
                    //***** 上传图片服务器   *********//
                    ResultFileInfo uploadFileBack = this.fastFileStorageService.uploadFile(inputStreameBack, fileNameBack, null);
                    applyClientInfoDO.setIdcardFrontSide(CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ", ""));
                    applyClientInfoDO.setIdcardBackSide(CurrencyConstant.HTTP + uploadFileBack.getFullAllPath().replace(" ", ""));
                    log.info("身份认证保存数据：" + JsonUtils.toJSON(applyClientInfoDO));
                    if (infoDO.getId() == null) {
                        clinetUserDao.insertApplyClientInfo(applyClientInfoDO);
                        RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + user.getLoginId());
                    } else {
                        TableModifyLogDTO modifyLogDTO = new TableModifyLogDTO();
                        modifyLogDTO.setCreateUser(user.getId());
                        modifyLogDTO.setModifyNewValue(JsonUtil.object2json(applyClientInfoDO));
                        modifyLogDTO.setModifyOldValue(JsonUtil.object2json(infoDO));
                        modifyLogDTO.setTableKey(infoDO.getId());
                        modifyLogDTO.setTableName(TableConstant.T_APPLY_CLIENT_INFO);
                        modifyLogDTO.setNoNeed(new String[]{"createTime", "createUser", "modifyTime", "modifyUser"});
                        boolean boo = tableModifyService.insertTableModirfyLog(modifyLogDTO);
                        if (boo) {
                            clinetUserDao.updateApplyClientInfo(applyClientInfoDO);
                            RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + user.getLoginId());
                            // -- 保存用户登录信息表
                            ClientUserDO clientUserDO = new ClientUserDO();
                            clientUserDO.setLoginName(user.getLoginId());
                            clientUserDO.setName(applyClientInfoDO.getName());
                            clientUserDO.setTerritoriality(applyClientInfoDO.getAddress());
                            clinetUserDao.updataClinetUser(clientUserDO);
                            // -- 更改缓存中用户存储的用户信息
                            RedisUtil.del(Constant.USER + user.getLoginId());
                            user.setName(applyClientInfoDO.getName());
                            RedisUtil.setex(Constant.USER + user.getLoginId(), user);
                        }
                    }
                    response = new RestResponse(MsgErrCode.SUCCESS);
                } else {
                    response = new RestResponse(NativeMsgErrCode.IDCARD_IS_USE);
                }
            } else if ("1".equals(results.get("result"))) {
                //认证不通过
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription(results.get("resultMsg").toString());
            } else {
                //认证处理失败
                response = new RestResponse(MsgErrCode.FAIL);
                response.setDescription(results.get("resultMsg").toString());
            }
        }else{
            //当天认证次数超过限制次数
            response = new RestResponse(NativeMsgErrCode.VERIFY_NUM_GO_BEYOND);
        }
        return response;
    }

    @Override
    public RestResponse insertAuthorizationLog(ThreePartyAuthorizationLogDO dto) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        dto.setApplyId(applyId);
        dto.setCreateUser(user.getId());
        authorizationDao.insertAuthorizationLog(dto);
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    public RestResponse insertLog(ThreePartyAuthorizationLogDO dto) throws Exception {
        authorizationDao.insertAuthorizationLog(dto);
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse confirmAuthorization() throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        int total = 0;
        AuthorizationListVO authorizationListVO = authorizationDao.getAuthorizationListApplyInfo(applyId);
        if (authorizationListVO == null){
            response = new RestResponse(MsgErrCode.FAIL);
        }else {
            // -- 获取风控报告有效时间
            Map<String,Integer> maps = null;
            try {
                maps = foreignservice.getAuthorizationValidTimeOfOrder();
            }catch (Exception e){
                e.printStackTrace();
                log.error("获取风控报告有效时间异常:"+e);
            }
            if (maps == null){
                maps = new HashMap<>(0);
            }
            List<AuthorizationProductDO> doList = authorizationDao.queryAuthorizationProduct(authorizationListVO.getProductId());
            Map<String,Object> paraMap = new HashMap<>();
            int count;
            for (AuthorizationProductDO productDO:doList){
                paraMap.put("authorizationType",productDO.getAuthorizationType());
                paraMap.put("applyId",applyId);
                paraMap.put("isSuccess",SysDictEnum.YES.getCode());
                Integer time = maps.get(productDO.getAuthorizationType().toString());
                paraMap.put("time",time == null?1:time);
                count = authorizationDao.getAuthorizationInfoCount(paraMap);
                if (count <= 0) {
                    if (SysDictEnum.EMPOWERMENT_SUCCESS.getCode().equals(productDO.getForceType())) {
                        total++;
                        break;
                    }
                    if (SysDictEnum.COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())) {
                        paraMap.remove("isSuccess");
                        count = authorizationDao.getAuthorizationInfoCount(paraMap);
                        if (count <= 0) {
                            total++;
                            break;
                        }
                    }
                }
            }
            if (total > 0){
                response = new RestResponse(1,"请完成授权信息");
            }else {
                paraMap = new HashMap<>();
                paraMap.put("orgId",authorizationListVO.getStoreOrgId());
                paraMap.put("configItem",SysDictEnum.CONSULT_SWITCH.getCode());
                Long switchOrg = consultationDao.getOrgSwitch(paraMap);
                // -- 流程跳转
                ApplyBillMainInfoDO mainInfoDO = new ApplyBillMainInfoDO();
                if (SysDictEnum.CLOSE_SWITCH.getCode().equals(switchOrg)){
                    mainInfoDO.setId(authorizationListVO.getMainId());
                    mainInfoDO.setState(NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE);
                    paraMap.put("businessState",NodeStateConstant.UNDISTRIBUTED_CUSTOMER_SERVICE);
                    paraMap.put("businessStateName","待分配客服");
                }else {
                    mainInfoDO.setId(authorizationListVO.getMainId());
                    mainInfoDO.setState(NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
                    paraMap.put("businessState",NodeStateConstant.CUSTOMER_SERVICE_ENTRY);
                    paraMap.put("businessStateName","客服录入中");
                    Map<String,Object> resultMap = consultationDao.getService(authorizationListVO.getStoreOrgId());
                    if (resultMap == null || !resultMap.containsKey("id")){
                        return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
                    }else {
                        mainInfoDO.setServiceName((String) resultMap.get("name"));
                        mainInfoDO.setServiceUid((Long) resultMap.get("id"));
                    }
                    Map<String,Object> serviceManager = consultationDao.getServiceManager(mainInfoDO.getServiceUid());
                    if (serviceManager != null){
                        if (serviceManager.containsKey("id")) {
                            mainInfoDO.setServiveManagerUid((Long) serviceManager.get("id"));
                        }
                        if (serviceManager.containsKey("name")) {
                            mainInfoDO.setServiveManagerName((String) serviceManager.get("name"));
                        }
                    }
                }
                /**系统审核组装参数*/
                SystemAuditParamDTO systemAuditParamDTO = otherPlatformRelevantService.getSystemAuditParam(authorizationListVO.getMainId(), NodeStateConstant.TO_BE_PRETRIAL);
                if (systemAuditParamDTO == null) {
                    return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
                }
                systemAuditParamDTO.setSubmitUser(user.getName());
                systemAuditParamDTO.setSynOrAsy("asynchronous");
                mainInfoDO.setSubmitConsultTime(new Date());
                mainInfoDO.setModifyUser(user.getId());
                paraMap.put("mainId",authorizationListVO.getMainId());
                paraMap.put("modifyUser",user.getId());
                paraMap.put("modifyUserName",user.getName());
                paraMap.put("lastState",NodeStateConstant.TO_BE_PRETRIAL);
                currencyDao.insertMainLog(paraMap);
                currencyDao.updateMainInFo(mainInfoDO);
                jmsQueueTemplate.convertAndSend(MqConstant.SYSTEM_AUDITING_MONITORING_DESTINATION, JsonUtils.toJSON(systemAuditParamDTO));
                response = new RestResponse(MsgErrCode.SUCCESS);
            }
        }
        return response;
    }

    @Override
    public RestResponse addressSplit(String address) throws Exception {
        if (StringUtils.isNullOrEmpty(address)){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        PersonalAddressDTO personalAddressDTO = ChineseAddressParser.chaifen(address);
        if (StringUtils.isNotNullAndEmpty(personalAddressDTO.getProvince())){
            Long provinceCode = currencyDao.getProvinceCodeByName(personalAddressDTO.getProvince());
            if (provinceCode != null){
                personalAddressDTO.setProvinceCode(provinceCode+"");
            }
        }
        if (StringUtils.isNotNullAndEmpty(personalAddressDTO.getCity())){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("city",personalAddressDTO.getCity());
            paraMap.put("fatherid","".equals(personalAddressDTO.getProvinceCode())?null:personalAddressDTO.getProvinceCode());
            Long cityCode = currencyDao.getCityCodeByName(paraMap);
            if (cityCode != null){
                personalAddressDTO.setCityCode(cityCode+"");
            }
        }
        if (StringUtils.isNotNullAndEmpty(personalAddressDTO.getArea())){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("area",personalAddressDTO.getArea());
            paraMap.put("fatherid","".equals(personalAddressDTO.getCityCode())?null:personalAddressDTO.getCityCode());
            Long areaCode = currencyDao.getAreaCodeByName(paraMap);
            if (areaCode != null) {
                personalAddressDTO.setAreaCode(areaCode + "");
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS,personalAddressDTO);
    }

    @Override
    public RestResponse verification(String authorizationType) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Long applyId = applyPersonDao.getApplyIdByClientId(user.getId());
        if (applyId == null) {
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_APPLY);
        }
        // -- 获取风控报告有效时间
        Map<String,Integer> maps = null;
        try {
            maps = foreignservice.getAuthorizationValidTimeOfOrder();
        }catch (Exception e){
            e.printStackTrace();
            log.error("获取风控报告有效时间异常:"+e);
        }
        if (maps == null){
            maps = new HashMap<>(0);
        }
        Map<String,Object> paraMap = new HashMap<>(4);
        paraMap.put("authorizationType",authorizationType);
        paraMap.put("applyId",applyId);
        paraMap.put("isSuccess",SysDictEnum.YES.getCode());
        Integer time = maps.get(authorizationType);
        paraMap.put("time",time == null?1:time);
        int count = authorizationDao.getAuthorizationInfoCount(paraMap);
        if (count > 0){
            RestResponse response = new RestResponse(MsgErrCode.FAIL);
            response.setDescription("已授权");
            return response;
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }
}
