package com.xyb.order.app.client.authorization.dao;

import com.xyb.order.app.client.authorization.model.*;
import com.xyb.order.app.client.cuser.model.ClientBankInFoDO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 三方相关查询
 * @author         xieqingyang
 * @date           2018/10/18 4:33 PM
*/
public interface AuthorizationDao {

    /**
     * 根据产品查询需要授权的三方
     * @author      xieqingyang
     * @date        2018/10/18 4:33 PM
     * @version     1.0
     * @param productId 产品ID
     * @return 返回三方信息
     */
    List<AuthorizationProductDO> queryAuthorizationProduct(Long productId);

    /**
     * 根据三方类型查询三方是否必附
     * @author      xieqingyang
     * @date        2018/10/18 4:34 PM
     * @version     1.0
     * @param paraMap 查询参数
     * @return 返回三方信息
     */
    AuthorizationProductDO queryAuthorizationType(Map<String,Object> paraMap);

    /**
     * 修改三方必附项信息
     * @author      xieqingyang
     * @date        2018/10/18 4:34 PM
     * @version     1.0
     * @param authorizationProductDO 待修改信息
     * @return 返回执行结果
     */
    int updateAuthorizationProductAdditional(AuthorizationProductDO authorizationProductDO);

    /**
     * 添加三方必附信息
     * @author      xieqingyang
     * @date        2018/10/18 4:34 PM
     * @version     1.0
     * @param authorizationProductDO 三方必附信息
     * @return 返回执行结果
     */
    int insertAuthorizationProduct(AuthorizationProductDO authorizationProductDO);

    /**
     * 查询授权信息
     * @author      xieqingyang
     * @date        2018/10/18 4:35 PM
     * @version     1.0
     * @param paraMap 查询参数
     * @return 返回授权信息
     */
    int getAuthorizationInfoCount(Map<String,Object> paraMap);

    /**
     * 查询三方列表页申请信息
     * @author      xieqingyang
     * @date        2018/10/18 4:35 PM
     * @version     1.0
     * @param applyId 申请单ID
     * @return 返回查询信息
     */
    AuthorizationListVO getAuthorizationListApplyInfo(Long applyId);

    /**
     * 插入三方授权日志
     * @author      xieqingyang
     * @date        2018/10/18 4:35 PM
     * @version     1.0
     * @param authorizationLogDO 待插入数据
     * @return 返回执行结果
     */
    int insertAuthorizationLog(ThreePartyAuthorizationLogDO authorizationLogDO);

    /**
     * 查询认证相关个人信息
     * @author      xieqingyang
     * @date        2018/10/18 4:36 PM
     * @version     1.0
     * @param applyId 申请单ID
     * @return 返回个人信息
     */
    AuthenticatePersonalInformationDO getPersonalInfo(Long applyId);

    /**
     * 查询个人相关联系人信息
     * @author      xieqingyang
     * @date        2018/10/18 4:36 PM
     * @version     1.0
     * @param applyId 申请单ID
     * @return 返回联系人信息
     */
    List<AuthenticateLinkmanDO> queryLingkmanInfo(Long applyId);

    /**---------------------------------合同签约相关功能---------------------------------*/
    /**
     * 添加协议信息（批量）
     * @author      xieqingyang
     * @date 2018/6/11 下午8:56
     * @version     1.0
     * @param list  参数集合
     * @return      成功条数
     */
    int insertAgreementinFoList(@Param("list") List<AgreementInFoDO> list);

    /**
     * 根据协议类型查询数量
     * @author      xieqingyang
     * @date 2018/6/11 下午9:05
     * @version     1.0
     * @param paraMap 传入参数 agreementType：协议类型 applyId：申请单ID cusId：客户ID
     * @return
     */
    int getAgreementInFoCount(Map<String,Object> paraMap);

    /**
     * 查询合同信息
     * @author      xieqingyang
     * @date 2018/6/26 下午3:25
     * @version     1.0
     * @param paraMap 传入参数
     * @return 返回合同信息
     */
    AgreementListVO queryAgreementInFo(Map<String,Object> paraMap);

    /**
     * 查询借款协议
     * @author      xieqingyang
     * @date 2018/6/26 下午3:25
     * @version     1.0
     * @param paraMap 传入参数
     * @return 返回合同信息
     */
    List<AgreementListVO> queryAgreementInFos(Map<String,Object> paraMap);

    /**
     * 根据协议表中所含字段查询协议内容
     * @author      xieqingyang
     * @date 2018/8/2 下午3:35
     * @version     1.0
     * @param agreement 查询条件
     * @return 返回协议内容
     */
    AgreementInFoDO getAgreementInfo(AgreementInFoDO agreement);

    /**
     * 修改协议信息
     * @author      xieqingyang
     * @date 2018/8/2 下午3:36
     * @version     1.0
     * @param agreement 协议信息
     * @return 返回执行结果
     */
    int updateAgreementInfo(AgreementInFoDO agreement);

    /**---------------------------------通联认证相关功能---------------------------------*/

    /**
     * 保存通联认证调用日志
     * @author      weiyuhao
     * @date        2018/10/18 4:40 PM
     * @version     1.0
     * @param tongLianLogDTO 待保存数据
     */
    void addVerifyLog(TongLianLogDTO tongLianLogDTO);

    /**
     * 获取当天认证次数
     * @author      weiyuhao
     * @date        2018/10/18 4:41 PM
     * @version     1.0
     * @param tongLianVerifyInfoDO 查询条件
     * @return 返回当天认证次数
     */
    int getVerifyCountQuantityByIdCard(TongLianVerifyInfoDO tongLianVerifyInfoDO);
}
