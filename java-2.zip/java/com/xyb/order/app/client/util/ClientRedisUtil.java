package com.xyb.order.app.client.util;

import com.beiming.kun.redis.RedisUtil;
import com.xyb.order.app.client.mine.dao.MineDao;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.common.constant.RedisConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 缓存相关功能
 * @author         xieqingyang
 * @date           2018/6/11 下午2:56
*/
@Service
public class ClientRedisUtil {

    private static final Logger log = LoggerFactory.getLogger(ClientRedisUtil.class);

    @Autowired
    private MineDao mineDao;

    /**
     * 获取用户认证相关信息
     * @author      xieqingyang
     * @date 2018/6/11 下午3:01
     * @version     1.0
     * @param loginId 登录ID
     * @return  返回用户认证信息
     */
    public ClientAuthenticationDO getClientAuthenticationDO(String loginId){
        ClientAuthenticationDO authenticationDO;
        if (RedisUtil.exists(RedisConstant.CLIENT_AUTHENTICATION_INFO + loginId)){
            authenticationDO = RedisUtil.get(RedisConstant.CLIENT_AUTHENTICATION_INFO + loginId,ClientAuthenticationDO.class);
        }else {
            authenticationDO = mineDao.getClientAuthenticationInFo(loginId);
            log.info("查询出的用户相关数据:loginId="+loginId+";用户数据:"+authenticationDO.toString());
            if (authenticationDO != null){
                RedisUtil.setex(RedisConstant.CLIENT_AUTHENTICATION_INFO + loginId,authenticationDO);
            }
        }
        return authenticationDO;
    }
}
