package com.xyb.order.app.client.homepage.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.apply.dao.ApplyDao;
import com.xyb.order.app.client.apply.model.ApplyClientDO;
import com.xyb.order.app.client.apply.model.ApplyDTO;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AgreementListVO;
import com.xyb.order.app.client.authorization.model.AuthorizationProductDO;
import com.xyb.order.app.client.authorization.model.AuthorizationResultVO;
import com.xyb.order.app.client.cuser.model.ApplyLoanDTO;
import com.xyb.order.app.client.homepage.dao.HomeDao;
import com.xyb.order.app.client.homepage.model.BannerDO;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.app.client.homepage.model.ProductListVO;
import com.xyb.order.app.client.homepage.service.HomePageService;
import com.xyb.order.app.client.mine.dao.MineDao;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.personinfo.dao.ApplyJobDao;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.personinfo.model.ApplyPersonBaseInfoDO;
import com.xyb.order.app.client.personinfo.model.JobInfoDO;
import com.xyb.order.app.client.personinfo.model.PersonBaseRelationInfoDO;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.ProductConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.material.dao.FileDataInfoDao;
import com.xyb.order.common.material.model.FileDataInfo;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.ApplyNumberUtil;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.common.util.StringUtils;
import com.xyb.risks.process.foreign.model.QualificationAuditDTO;
import com.xyb.risks.process.foreign.service.FraudService;
import com.xyb.util.SessionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Service(interfaceName = "com.xyb.order.app.client.homepage.service.HomePageService")
public class HomePageServiceImpl implements HomePageService {

    private static final Logger log = LoggerFactory.getLogger(HomePageServiceImpl.class);

    @Autowired
    private HomeDao homeDao;
    @Reference
    private FraudService fraudService;
    @Autowired
    private ClientRedisUtil clientRedisUtil;
    @Autowired
    private HomePageService homePageService;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private ApplyPersonDao applyPersonDao;
    @Autowired
    private ApplyJobDao applyJobDao;
    @Autowired
    private MineDao mineDao;
    @Autowired
    private BankDao bankDao;
    @Autowired
    private FileDataInfoDao fileDataInfoDao;
    @Autowired
    private ApplyDao applyDao;
    @Autowired
    private CurrencyDao currencyDao;
    /**是否是正式环境*/
    @Value("${is.formal}")
    private String isFormal;

    @Override
    public RestResponse queryValidBanners() throws Exception{
        RestResponse response;
        List<BannerDO> bannerDOS = homeDao.queryValidBanners();
        if (bannerDOS != null && bannerDOS.size() > 0){
            response = new RestResponse(MsgErrCode.SUCCESS,bannerDOS);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS);
        }
        return response;
    }

    @Override
    public RestResponse queryProductList() throws Exception {
        RestResponse response;
        List<ProductListVO> productListVOS = new ArrayList<>();
        if (RedisUtil.exists(RedisConstant.PRODUCT_EXHIBITION)){
            productListVOS = RedisUtil.get(RedisConstant.PRODUCT_EXHIBITION,List.class);
        }else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            //从Redis查询优信借当天放款额度是否已满标识
            String format = sdf.format(new Date());
            String flag = RedisUtil.get(RedisConstant.YOU_XIN_JIE_FULL_AMOUNT_FLAG+format);
            if(StringUtils.isNullOrEmpty(flag)){
                flag = "N";
            }
            List<ProductExhibitionDO> exhibitionDOS = homePageService.queryProductExhibition(null);
            log.info("查询出的产品展示信息："+JsonUtils.toJSON(exhibitionDOS));
            for (ProductExhibitionDO exhibitionDO:exhibitionDOS){
                ProductListVO vo = new ProductListVO();
                if( ProductConstant.YOU_XIN_JIE_ID.equals(exhibitionDO.getProductId())){
                    vo.setFullAmount(flag);
                }
                vo.setProductId(String.valueOf(exhibitionDO.getProductId()));
                vo.setProductName(String.valueOf(exhibitionDO.getProductName()));
                vo.setProductRate(exhibitionDO.getMinProportion().multiply(new BigDecimal(100)).stripTrailingZeros().toPlainString() + "%-" + exhibitionDO.getMaxProportion().multiply(new BigDecimal(100)).stripTrailingZeros().toPlainString() + "%");
                vo.setProductLimit(exhibitionDO.getProductLimit());
                vo.setProductAmount(exhibitionDO.getMinAmount().divide(new BigDecimal(10000)).stripTrailingZeros().toPlainString() + "-" + exhibitionDO.getMaxAmount().divide(new BigDecimal(10000)).stripTrailingZeros().toPlainString() + "万");
                vo.setProductMaxAmount(String.valueOf(exhibitionDO.getMaxAmount()));
                vo.setProductMinAmount(String.valueOf(exhibitionDO.getMinAmount()));
                vo.setProductCondition(exhibitionDO.getMinAge() + "-" + exhibitionDO.getMaxAge() + "周岁");
                vo.setIsHot(SysDictEnum.YES.getCode().equals(exhibitionDO.getIsHot())?CurrencyConstant.Y:CurrencyConstant.N);
                productListVOS.add(vo);
            }
        }
        if (productListVOS != null && productListVOS.size() > 0){
            RedisUtil.setex(RedisConstant.PRODUCT_EXHIBITION,3600,productListVOS);
            response = new RestResponse(MsgErrCode.SUCCESS,productListVOS);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS);
        }
        return response;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse applyLoan(ApplyLoanDTO applyLoanDTO) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        int count = 0;
        // -- 客户认证相关信息
        ClientAuthenticationDO authenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
        // -- 查询产品展示信息
        List<ProductExhibitionDO> exhibitionDOS = homePageService.queryProductExhibition(applyLoanDTO.getProductId());
        // 8.-- 判断是否能够进件 查询当前用户最近一条历史拒贷申请对应的拒贷重交天数限制，当前时间对比其拒贷申请日期，是否达到拒贷时长，未达到，提示请与 ? 天后申请
        Date allowableEntryTime = authenticationDO.getAllowableEntryTime();
        if (allowableEntryTime == null){
            allowableEntryTime = new Date();
        }
        if(new Date().before(allowableEntryTime)){
            SimpleDateFormat sd = new SimpleDateFormat("yyyy年MM月dd日");
            RestResponse response = new RestResponse(MsgErrCode.FAIL);
            response.setDescription("基于您上次申请的结果，请于"+sd.format(authenticationDO.getAllowableEntryTime())+"后再次申请");
            return response;
        }
        // 2.-- 判断是否身份认证 校验是否身份认证，未认证跳转认证页面进行身份认证
        if (CurrencyConstant.N.equals(authenticationDO.getCertificationState())){
            return  new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
            // 3.--判断身份证是否过期 校验当前身份信息是否有效，即身份证有效期结束日期是否大于当前日，无效身份证，跳转身份认证页面，吐司提示，身份信息已失效，请重新认证
        }else if (authenticationDO.getIdCardEndTime() == null || IdCardUtil.validationIdCard(authenticationDO.getIdCardEndTime())){
            return  new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
            // 5.-- 判断年龄是否符合 当前用户的年龄是否在当前申请产品的年龄范围内，非法，吐司提示年龄不符
        }else if (StringUtils.isNullOrEmpty(authenticationDO.getIdCard()) || IdCardUtil.IdNOToAge(authenticationDO.getIdCard()) > exhibitionDOS.get(0).getMaxAge() || IdCardUtil.IdNOToAge(authenticationDO.getIdCard()) < exhibitionDOS.get(0).getMinAge()){
            return  new RestResponse(1,"借款年龄范围为：" + exhibitionDOS.get(0).getMinAge() + "-" + exhibitionDOS.get(0).getMaxAge() + "周岁");
        }else{
            // 6.-- 判断是否有借款申请 当前用户是否存在借款申请（查询节点新增确认借款节点），存在，吐司提示已有一笔借款申请处理中
            count = homeDao.getApplicationApply(user.getId());
            if (count > 0){
                return new RestResponse(NativeMsgErrCode.LOAN_APPLICATION);
            }
            // 7.-- 判断是否有未还清的单子 当前用户是否有未还清的合同，存在，吐司提示有借款未还清
            count = homeDao.getNotRepaidApply(user.getId());
            if (count > 0){
                return new RestResponse(NativeMsgErrCode.NOT_REPAID);
            }
        }
        // 1. - 校验当前定位是否存在营业部，无，提示当前城市无服务网点
        if (StringUtils.isNullOrEmpty(applyLoanDTO.getCity())){
            return new RestResponse(1,"请定位当前位置");
        }
        // 4.-- 资质审核 风控接口 校验当前用户信息是否为黑名单用户，是，吐司提示资质不符该接口需与反欺诈人员沟通，接口发生变更需一起变更接口，若无变更，与现有保持一致即可
        try {
            QualificationAuditDTO qualificationAuditDTO = new QualificationAuditDTO();
            qualificationAuditDTO.setIdCard(authenticationDO.getIdCard());
            qualificationAuditDTO.setPhone(user.getLoginId());
            qualificationAuditDTO.setProductId(applyLoanDTO.getProductId());
            String result = fraudService.fraudQualificationAudit(qualificationAuditDTO);
            if (CurrencyConstant.N.equals(result)){
                return new RestResponse(NativeMsgErrCode.INCOMPETENCE);
            }else if (CurrencyConstant.NINE.equals(result)){
                log.info("调用风控资质审核接口异常");
                return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
            }
        }catch (Exception e){
            e.printStackTrace();
            log.info("调用风控资质审核接口异常");
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
        //9.--上线打开
        //- 查询是否完成授权协议  是否签署个人信息采集查询授权协议书，未签署，跳转签署该协议页面
        if (CurrencyConstant.Y.equals(isFormal)) {
            ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
            Map<String, Object> paraMap = new HashMap<>(5);
            paraMap.put("cusId", clientAuthenticationDO.getId());
            paraMap.put("isValid", SysDictEnum.IS_VALID.getCode());
            paraMap.put("type", SysDictEnum.AUTHORIZE_URL.getCode());
            // -- 查询《个人信息采集、查询、授权书》
            AgreementListVO authorize = authorizationDao.queryAgreementInFo(paraMap);
            if (authorize == null) {
                return new RestResponse(NativeMsgErrCode.PLEASE_SIGN_AGREEMENT);
            }
        }

        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("productId",applyLoanDTO.getProductId());
        Long applyId = this.applyPersonDao.getApplyIdByClientUserId(user.getId());
        Long mainId = this.applyDao.getMainIdByLoginId(user.getId());
        if(applyId != null && mainId != null){
            resultMap.put("applyId",applyId);
            ApplyDTO applyDTO = new ApplyDTO();
            applyDTO.setApplyId(applyId);
            applyDTO.setMainId(mainId);
            applyDTO.setExpectProductId(applyLoanDTO.getProductId());
            this.applyDao.updateProductByApplyId(applyDTO);
            this.applyDao.updateProductByMainId(applyDTO);
        }
        // 一 初始化数据 ---------------------------------------------------------------------------------------------
        if(mainId == null){
            ApplyDTO applyDTO = new ApplyDTO();
            ApplyClientDO applyClientDO = this.applyDao.getClientByLoginId(user.getId());
            if (applyClientDO != null) {
                applyDTO.setClientId(applyClientDO.getId());
                applyDTO.setClientIdCard(applyClientDO.getIdcard());
                applyDTO.setClientRealName(applyClientDO.getName());
                int loopCount = this.applyDao.getLoopContractByCusId(applyClientDO.getId());
                if (loopCount > 0) {
                    applyDTO.setIsLoop(SysDictEnum.YES.getCode());
                }else{
                    applyDTO.setIsLoop(SysDictEnum.NO.getCode());
                }
            }
            String applyNum = ApplyNumberUtil.getsApplyNumber();
            applyDTO.setApplyNum(applyNum);
            applyDTO.setCreateUser(user.getId());
            applyDTO.setModifyUser(user.getId());
            applyDTO.setState(NodeStateConstant.CLIENT_APPLY);
            applyDTO.setExpectProductId(applyLoanDTO.getProductId());
            /**新增申请t_apply_bill_info表数据**/
            this.applyDao.addBillInfo(applyDTO);
            applyDTO.setApplyId(applyDTO.getId());
            resultMap.put("applyId",applyDTO.getId().toString());
            /**新增主表t_apply_main_info表数据**/
            this.applyDao.addMainInfo(applyDTO);
            /**添加主表日志*/
            MainLogDTO mainLogDTO = new MainLogDTO();
            mainLogDTO.setMainId(applyDTO.getId());
            mainLogDTO.setModifyUser(user.getId());
            mainLogDTO.setModifyUserName(user.getName());
            mainLogDTO.setBusinessState(NodeStateConstant.CLIENT_APPLY);
            mainLogDTO.setBusinessStateName("客户申请");
            currencyDao.addMainLog(mainLogDTO);
        }
        return new RestResponse(MsgErrCode.SUCCESS,resultMap);
    }

    @Override
    public List<ProductExhibitionDO> queryProductExhibition(Long productId) throws Exception {
        List<ProductExhibitionDO> exhibitionDOS = homeDao.queryProductExhibition(productId);
        for (int i = 0;i < exhibitionDOS.size();i++){
            String exhibition = homeDao.getAllProductLimitByProductId(exhibitionDOS.get(i).getProductId());
            if (StringUtils.isNotNullAndEmpty(exhibition) && exhibitionDOS.get(i).getMinProportion() != null && exhibitionDOS.get(i).getMaxProportion() != null){
                exhibitionDOS.get(i).setProductLimit(exhibition);
            }else {
                exhibitionDOS.remove(i);
                i--;
            }
        }
        return exhibitionDOS;
    }

    /**
     * 获取填写资料列表
     *
     * @param productId
     * @return
     */
    @Override
    public RestResponse fillList(Long productId) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        String submitFlag = "N";
        //基本信息
        boolean baseInfo = true;
        //绑卡信息
        boolean bankInfo = true;
        //图片信息
        boolean pictureInfo = true;
        //运营商报告
        boolean operatorInfo = true;
        //保单
        boolean guaranteeInfo = true;
        //社保
        boolean crawlerInsureInfo = true;
        //公积金
        boolean crawlerFundInfo = true;
        //征信报告
        boolean creditInvestigationInfo = true;

        Long applyId = this.applyPersonDao.getApplyIdByClientUserId(user.getId());
        // -- 组装页面数据 ---------------------------------------------------------------------------------------------
        List<AuthorizationResultVO> authorizationResultVOS = new ArrayList<>();
        Map<String,Object> resultMap = new HashMap<String, Object>();
        // 1.-- 基本信息
        AuthorizationResultVO authorizationResultVO1 = new AuthorizationResultVO();
        authorizationResultVO1.setAuthorizationType("JBXX");
        authorizationResultVO1.setAuthorizationTypeName("基本信息");
        authorizationResultVO1.setForceType(CurrencyConstant.Y);
        boolean baseInfoFlag = this.getPersonInfoVerifyResult(applyId);
        if(baseInfoFlag){
            authorizationResultVO1.setResult("已填写");
        }else{
            baseInfo = false;
            authorizationResultVO1.setResult("去填写");
        }
        authorizationResultVOS.add(authorizationResultVO1);
        // 2.一 绑卡信息
        AuthorizationResultVO authorizationResultVO2 = new AuthorizationResultVO();
        authorizationResultVO2.setAuthorizationType("BDYHK");
        authorizationResultVO2.setAuthorizationTypeName("绑定银行卡");
        authorizationResultVO2.setForceType(CurrencyConstant.Y);
        boolean bankInfoFlag = this.getBindingBankVerifyResult(user.getLoginId());
        if(bankInfoFlag){
            authorizationResultVO2.setResult("已绑卡");
        }else{
            bankInfo = false;
            authorizationResultVO2.setResult("未绑卡");
        }
        authorizationResultVOS.add(authorizationResultVO2);
        // 3.一 图片信息
        AuthorizationResultVO authorizationResultVO3 = new AuthorizationResultVO();
        authorizationResultVO3.setAuthorizationType("ZWTJTP");
        authorizationResultVO3.setAuthorizationTypeName("自我推荐图片");
        authorizationResultVO3.setForceType(CurrencyConstant.Y);
        boolean pictureInfoFlag = this.getPictureVerifyResult(applyId);
        if(pictureInfoFlag){
            authorizationResultVO3.setResult("已上传");
        }else{
            pictureInfo = false;
            authorizationResultVO3.setResult("未上传");
        }
        authorizationResultVOS.add(authorizationResultVO3);
        // - 第三方授权信息
        List<AuthorizationProductDO> doList = authorizationDao.queryAuthorizationProduct(productId);
        for (AuthorizationProductDO productDO:doList){
            AuthorizationResultVO authorizationResultVO = new AuthorizationResultVO();
            authorizationResultVO.setAuthorizationType(productDO.getAuthorizationType() + "");
            authorizationResultVO.setForceType(SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())?CurrencyConstant.N:CurrencyConstant.Y);
            if(SysDictEnum.JUXINLI_OPERATOR.getCode().equals(productDO.getAuthorizationType())){
                authorizationResultVO.setAuthorizationTypeName("运营商报告");
                // 5.一 运营商报告
                boolean operatorInfoFlag = this.getOperatorVerifyResult(applyId);
                if(operatorInfoFlag){
                    authorizationResultVO.setResult("已授权");
                }else {
                    authorizationResultVO.setResult("去授权");
                }
                if(!SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                    operatorInfo = operatorInfoFlag;
                }
            }
            if(SysDictEnum.JUXINLI_POLICY_REPORT.getCode().equals(productDO.getAuthorizationType())){
                authorizationResultVO.setAuthorizationTypeName("保单");
                // 8.一 保单
                boolean guaranteeInfoFlag = this.getGuaranteeVerifyResult(applyId);
                if(guaranteeInfoFlag){
                    authorizationResultVO.setResult("已授权");
                }else {
                    authorizationResultVO.setResult("去授权");
                }
                if(!SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                    guaranteeInfo = guaranteeInfoFlag;
                }
            }
            if(SysDictEnum.TIANJI_SOCIAL_SECURITY.getCode().equals(productDO.getAuthorizationType())){
                authorizationResultVO.setAuthorizationTypeName("社保");
                // 7.一 社保
                boolean crawlerInsureInfoFlag = this.getCrawlerInsureVerifyResult(applyId);
                if(crawlerInsureInfoFlag){
                    authorizationResultVO.setResult("已授权");
                }else {
                    authorizationResultVO.setResult("去授权");
                }
                if(!SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                    crawlerInsureInfo = crawlerInsureInfoFlag;
                }
            }
            if(SysDictEnum.TIANJI_ACCUMULATION_FUND.getCode().equals(productDO.getAuthorizationType())){
                authorizationResultVO.setAuthorizationTypeName("公积金");
                // 6.一 公积金
                boolean crawlerFundInfoFlag = this.getCrawlerFundVerifyResult(applyId);
                if(crawlerFundInfoFlag){
                    authorizationResultVO.setResult("已授权");
                }else {
                    authorizationResultVO.setResult("去授权");
                }
                if(!SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                    crawlerFundInfo = crawlerFundInfoFlag;
                }
            }
            if(SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode().equals(productDO.getAuthorizationType())){
                authorizationResultVO.setAuthorizationTypeName("征信报告");
                // 4.一 征信报告
                boolean creditInvestigationInfoFlag = this.getCreditInvestigationVerifyResult(applyId);
                if(creditInvestigationInfoFlag){
                    authorizationResultVO.setResult("已授权");
                }else {
                    authorizationResultVO.setResult("去授权");
                }
                if(!SysDictEnum.NON_COMPULSORY_AUTHORIZATION.getCode().equals(productDO.getForceType())){
                    creditInvestigationInfo = creditInvestigationInfoFlag;
                }
            }
            authorizationResultVOS.add(authorizationResultVO);
        }
        //是否可以提交标识
        if(baseInfo && bankInfo && pictureInfo && operatorInfo && guaranteeInfo && crawlerInsureInfo && crawlerFundInfo && creditInvestigationInfo){
            submitFlag = "Y";
        }
        resultMap.put("authorizationResultVOS",authorizationResultVOS);
        resultMap.put("applyId",applyId);
        resultMap.put("submitFlag",submitFlag);
        return new RestResponse(MsgErrCode.SUCCESS,resultMap);
    }

    // - 基本信息验证
    private boolean getPersonInfoVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        if(applyId != null){
            // 1.- 个人信息
            ApplyPersonBaseInfoDO applyPersonBaseInfo = this.applyPersonDao.getApplyPersonBaseInfo(applyId);
            if(applyPersonBaseInfo == null){
                flag = false;
                return flag;
            }
            // 2.- 联系信息
            PersonBaseRelationInfoDO personBaseRelationInfoDO = this.applyPersonDao.getPersonBaseRelationInfo(applyId);
            Map<String, Object> paraMap = new HashMap<String, Object>();
            paraMap.put("applyId", applyId);
            paraMap.put("type", SysDictEnum.FAMILY_PERSON_LINK.getCode());
            List<Map<String, Object>> family = this.applyPersonDao.getLinkManList(paraMap);
            paraMap.put("type", SysDictEnum.QUICK_PERSON_LINK.getCode());
            List<Map<String, Object>> quick = this.applyPersonDao.getLinkManList(paraMap);
            paraMap.put("type", SysDictEnum.WORK_PERSON_LINK.getCode());
            List<Map<String, Object>> work = this.applyPersonDao.getLinkManList(paraMap);
            if(personBaseRelationInfoDO == null || family.size() == 0 || quick.size() < 2 || work.size() == 0){
                flag = false;
                return flag;
            }
            // 3.- 工作信息
            JobInfoDO jobInfoDO = this.applyJobDao.getJobInfoByApplyId(applyId);
            if(jobInfoDO == null){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 绑卡信息校验
    private boolean getBindingBankVerifyResult(String loginId)throws Exception{
        boolean flag = true;
        ClientAuthenticationDO  authenticationDO = mineDao.getClientAuthenticationInFo(loginId);
        if(authenticationDO == null){
            flag = false;
            return flag;
        }
        // -- 查询用户银行卡信息
        ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
        paraClient.setClientId(authenticationDO.getId());
        paraClient.setState(SysDictEnum.YES.getCode());
        paraClient.setIsDefault(SysDictEnum.YES.getCode());
        List<ClientBankInfoNoDO> list = bankDao.queryClientBankInFoNo(paraClient);
        if (list == null || list.size() == 0){
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 图片信息校验
    private boolean getPictureVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        if(applyId != null){
            Map<String,Object> paraMap =  new HashMap<>();
            paraMap.put("applyId",applyId);
            paraMap.put("fileCode",SysDictEnum.IMAGE_TYPE_ZWTJ.getName());
            List<FileDataInfo> fileDataInfos = fileDataInfoDao.queryFileDateInfoList(paraMap);
            if(fileDataInfos.size() == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return  flag;
    }

    // - 征信报告验证
    private boolean getCreditInvestigationVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.SUANHUA_HUMAN_DECENCY.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 运营商报告
    private boolean getOperatorVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.JUXINLI_OPERATOR.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 公积金
    private boolean getCrawlerFundVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.TIANJI_ACCUMULATION_FUND.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 社保
    private boolean getCrawlerInsureVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.TIANJI_SOCIAL_SECURITY.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }

    // - 保单
    private boolean getGuaranteeVerifyResult(Long applyId)throws Exception{
        boolean flag = true;
        int count;
        if(applyId != null){
            Map<String,Object> paraMap = new HashMap<>();
            paraMap.put("authorizationType",SysDictEnum.JUXINLI_POLICY_REPORT.getCode());
            paraMap.put("applyId",applyId);
            paraMap.put("isSuccess",SysDictEnum.YES.getCode());
            count = authorizationDao.getAuthorizationInfoCount(paraMap);
            if(count == 0){
                flag = false;
                return flag;
            }
        }else {
            flag = false;
            return flag;
        }
        return flag;
    }
}
