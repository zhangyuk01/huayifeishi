package com.xyb.order.app.client.homepage.dao;

import com.xyb.order.app.client.cuser.model.ApplyLoanOrgDO;
import com.xyb.order.app.client.homepage.model.BannerDO;
import com.xyb.order.app.client.homepage.model.ProductExhibitionDO;
import com.xyb.order.app.client.mine.model.ApplyRecordListVO;
import com.xyb.order.app.client.mine.model.ApplyRecordVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
* @Description:    C端首页方法
* @Author:         xieqingyang
* @CreateDate:     2018/5/8 下午5:39
*/
public interface HomeDao {

    /**查询banner图*/
    List<BannerDO> queryValidBanners();

    /**查询产品展示列表*/
    List<ProductExhibitionDO> queryProductExhibition(@Param("productId") Long productId);

    /**根据产品ID查询产品所有期限*/
    String getAllProductLimitByProductId(@Param("productId") Long productId);

    /**根据推荐码查询营业部*/
    List<ApplyLoanOrgDO> queryApplyLoanOrgByRecommenCode(String getRecommendCode);

    /**根据市查询营业部*/
    List<ApplyLoanOrgDO> queryApplyLoanOrg(String city);

    /**查询是否有未还清的单子*/
    int getNotRepaidApply(Long loginId);

    /**查询拒贷后是否可以申请*/
    Integer getRefuseApply(Long loginId);

    /**查询是否有借款申请中的单子*/
    int getApplicationApply(Long loginId);

    /**查询当前登录人客户经理推荐码*/
    String getRecommendCode(Long userId);

    /**
     * @description 根据营业部ID和产品ID查询数量来判断是否支持此产品
     * @author      xieqingyang
     * @CreatedDate 2018/5/24 上午10:48
     * @Version     1.0
     * @param paraMap
     * @return  数量
     */
    int getProductCountByOrg(Map<String,Object> paraMap);
    
    List<Long>  getOrgIdsByOrgIdsAndProDuctId(Map<String,Object> paraMap);
}
