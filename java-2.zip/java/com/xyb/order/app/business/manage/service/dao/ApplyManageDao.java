package com.xyb.order.app.business.manage.service.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.app.business.manage.model.AppBillInfoDO;
import com.xyb.order.app.business.manage.model.AppBillInfoDetailDO;
import com.xyb.order.app.business.manage.model.AppCustomerInfoDO;

/**
 * @ClassName ApplyManageDao
 * @author ZhangYu
 * @date 2018年6月13号
 */
public interface ApplyManageDao {

	/**
	 * 获取客户经理下的所有客户信息 
	 * @return
	 */
	List<AppCustomerInfoDO> getCustomerListByLoginId(Map<String, Object> paramMap);
	
	/**
	 * 获取客户经理下的所有申请单信息 
	 * @param loginUserId
	 * @return
	 */
	List<AppBillInfoDO> getApplyBillInfoListByLoginId(Map<String, Object> paramMap);
	

	/**
	 * 根据申请单ID查询客户经理下的申请单详情信息 
	 * @param applyId
	 * @return
	 */
	AppBillInfoDetailDO getApplyBillInfoByApplyId(Long applyId);
	

	/**
	 * 查询客户经理下客户信息数量 
	 * @param paramMap
	 * @return
	 */
	Integer getCustomerListCount(Map<String, Object> paramMap);
	

	/**
	 * 查询详情申请单信息列表的数量 
	 * @param paramMap
	 * @return
	 */
	Integer getApplyBillInfoListCount(Map<String, Object> paramMap);
	
	

}
