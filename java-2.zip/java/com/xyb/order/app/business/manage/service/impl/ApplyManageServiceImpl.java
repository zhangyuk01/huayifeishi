package com.xyb.order.app.business.manage.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.business.manage.model.AppBillInfoDO;
import com.xyb.order.app.business.manage.model.AppBillInfoDetailDO;
import com.xyb.order.app.business.manage.model.AppCustomerInfoDO;
import com.xyb.order.app.business.manage.model.ApplyBillInfoDTO;
import com.xyb.order.app.business.manage.model.ApplyBillinfoVO;
import com.xyb.order.app.business.manage.model.ApplyCustomerInfoDTO;
import com.xyb.order.app.business.manage.model.ApplyCustomerInfoVO;
import com.xyb.order.app.business.manage.service.ApplyManageService;
import com.xyb.order.app.business.manage.service.dao.ApplyManageDao;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.util.StringUtils;
import com.xyb.util.SessionUtil;
/**
 * @ClassName ApplyManageServiceImpl
 * @author ZhangYu
 * @date 2018年6月13号
 */
@Service(interfaceName = "com.xyb.order.app.business.manage.service.ApplyManageService")
public class ApplyManageServiceImpl implements ApplyManageService{

	@Autowired
	private ApplyManageDao applyManageDao;

	@Override
	public RestResponse getCustomerList(ApplyCustomerInfoDTO applyCustomerInfoDTO) throws Exception{
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		Integer page;
		String searchConditon = null; 
		Map<String, Object> paramMap = new HashMap<>(3);
		if (applyCustomerInfoDTO != null) {
			page = applyCustomerInfoDTO.getPage();
			searchConditon = applyCustomerInfoDTO.getSearchConditon();
			if (page == null) {
				page = 0;
			}
			if (StringUtils.isNotNullAndEmpty(searchConditon)) {
				paramMap.put("searchConditon",searchConditon);
			}
		}else{
			page = 0;
		}
		paramMap.put("page", page*10);
		paramMap.put("loginUserId", userId);
		List<AppCustomerInfoDO> customerList = this.applyManageDao.getCustomerListByLoginId(paramMap);
		ApplyCustomerInfoVO applyCustomerInfoVO = new ApplyCustomerInfoVO();
		int count = this.applyManageDao.getCustomerListCount(paramMap);
		if (count-(page + 1) * 10 >= 1){
			applyCustomerInfoVO.setIsMore(CurrencyConstant.Y);
		}else {
			applyCustomerInfoVO.setIsMore(CurrencyConstant.N);
		}
		applyCustomerInfoVO.setCustomerList(customerList);
		return new RestResponse(MsgErrCode.SUCCESS, applyCustomerInfoVO);
	}

	@Override
	public RestResponse getApplyBillInfoList(ApplyBillInfoDTO applyBillInfoDTO) throws Exception {
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		Integer page;
		String searchConditon = null; 
		Map<String, Object> paramMap = new HashMap<>(3);
		if (applyBillInfoDTO != null) {
			page = applyBillInfoDTO.getPage();
			searchConditon = applyBillInfoDTO.getSearchConditon();
			if (page == null) {
				page = 0;
			}
			if (StringUtils.isNotNullAndEmpty(searchConditon)) {
				paramMap.put("searchConditon",searchConditon);
			}
		}else{
			page = 0;
		}
		paramMap.put("page", page*10);
		paramMap.put("loginUserId", userId);
		List<AppBillInfoDO> applyBillInfoList = this.applyManageDao.getApplyBillInfoListByLoginId(paramMap);
		ApplyBillinfoVO applyBillinfoVO = new ApplyBillinfoVO();
		int count = this.applyManageDao.getApplyBillInfoListCount(paramMap);
		if (count-(page + 1) * 10 >= 1){
			applyBillinfoVO.setIsMore(CurrencyConstant.Y);
		}else {
			applyBillinfoVO.setIsMore(CurrencyConstant.N);
		}
		applyBillinfoVO.setAppBillInfoDOs(applyBillInfoList);
		return new RestResponse(MsgErrCode.SUCCESS, applyBillinfoVO);
	}

	@Override
	public RestResponse getApplyBillDetailInfo(Long applyId) throws Exception {
		AppBillInfoDetailDO appBillInfoDetailDO = this.applyManageDao.getApplyBillInfoByApplyId(applyId);
		if (appBillInfoDetailDO != null) {
			String applyNum = appBillInfoDetailDO.getApplyNum();
			if (StringUtils.isNullOrEmpty(applyNum)) {
				appBillInfoDetailDO.setApplyNum("");		
			}
			String expectProductName = appBillInfoDetailDO.getExpectProductName();
			if (StringUtils.isNullOrEmpty(expectProductName)) {
				appBillInfoDetailDO.setExpectProductName("");		
			}
			BigDecimal contractMoney = appBillInfoDetailDO.getContractMoney();
			if (contractMoney == null) {
				appBillInfoDetailDO.setContractMoney(new BigDecimal(0));
			}
			BigDecimal expectMoney = appBillInfoDetailDO.getExpectMoney();
			if (expectMoney == null) {
				appBillInfoDetailDO.setExpectMoney(new BigDecimal(0));
			}
			Integer paidPeriod = appBillInfoDetailDO.getPaidPeriod();
			if (paidPeriod == null) {
				appBillInfoDetailDO.setPaidPeriod(new Integer(0));
			}
			Integer productLimit = appBillInfoDetailDO.getProductLimit();
			if (productLimit == null) {
				appBillInfoDetailDO.setProductLimit(new Integer(0));
			}
			Integer totalLatePeriod = appBillInfoDetailDO.getTotalLatePeriod();
			if (totalLatePeriod == null) {
				appBillInfoDetailDO.setTotalLatePeriod(new Integer(0));
			}
		}
		return new RestResponse(MsgErrCode.SUCCESS, appBillInfoDetailDO);
	}

}
