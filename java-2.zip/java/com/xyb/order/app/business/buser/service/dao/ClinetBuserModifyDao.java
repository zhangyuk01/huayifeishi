package com.xyb.order.app.business.buser.service.dao;

import com.xyb.order.app.business.buser.model.ClientBuserDO;

/**
 * @ClassName ClinetBuserModifyDao
 * @author ZhangYu
 * @date 2018年6月25号
 */
public interface ClinetBuserModifyDao {
	
	/**
	 * 根据登录手机号查询用户登录信息 
	 * @param mobile
	 * @return
	 */
    ClientBuserDO getClientBuserByMobile(String mobile);
   
    /**
     * 修改新的手机号
     * @param clientBuserDO
     * @return
     */
    int updateClientBuser(ClientBuserDO clientBuserDO);

}
