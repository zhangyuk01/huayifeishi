package com.xyb.order.app.business.buser.service.impl;

import com.xyb.order.common.message.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.DesUtil;
import com.xyb.auth.constant.Constant;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.business.buser.model.ClientBuserDO;
import com.xyb.order.app.business.buser.service.ClinetBuserModifyService;
import com.xyb.order.app.business.buser.service.dao.ClinetBuserModifyDao;
import com.xyb.order.app.client.cuser.model.ClientUserUpdateDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePasswordDTO;
import com.xyb.order.app.client.cuser.model.ClientUserUpdatePhoneDTO;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.util.SessionUtil;

/**
 * @ClassName ClinetBuserModifyServiceImpl
 * @author ZhangYu
 * @date 2018年6月25号
 */
@Service(interfaceName = "com.xyb.order.app.business.buser.service.ClinetBuserModifyService")
public class ClinetBuserModifyServiceImpl implements ClinetBuserModifyService{

	@Autowired
	private MessageService validMessageService;
    @Autowired 
    private ClinetBuserModifyDao clinetBuserModifyDao;

    @Override
    public RestResponse updatePhone(ClientUserUpdatePhoneDTO clientUserUpdatePhoneDTO) throws Exception {
    	User user = SessionUtil.getLoginUser(User.class);
    	RestResponse response;
    	response = validMessageService.validateMessageCode(clientUserUpdatePhoneDTO.getPhone(),clientUserUpdatePhoneDTO.getMsgCode(),CurrencyConstant.MESSAGE_VALID_TIME,null,null);
    	if (response.getResult() == 0) {
    		if ("one".equals(clientUserUpdatePhoneDTO.getType())){
    			ClientBuserDO clientBuserDO = this.clinetBuserModifyDao.getClientBuserByMobile(clientUserUpdatePhoneDTO.getPhone());
    			if (clientBuserDO != null) {
    				return new RestResponse(MsgErrCode.SUCCESS);
				}else{
					return new RestResponse(NativeMsgErrCode.ACCOUNTNOTREGISTERED);
				}
    		}else if("two".equals(clientUserUpdatePhoneDTO.getType())) {
    			if (!clientUserUpdatePhoneDTO.getPhone().equals(user.getLoginId())){
    				ClientBuserDO clientBuserDO = new ClientBuserDO();
    				clientBuserDO.setNewMobile(clientUserUpdatePhoneDTO.getPhone());
    				clientBuserDO.setModifyUser(user.getId());
    				clientBuserDO.setLoginId(user.getLoginId());
    				this.clinetBuserModifyDao.updateClientBuser(clientBuserDO);
    				String userId = user.getLoginId();
    				user.setLoginId(clientUserUpdatePhoneDTO.getPhone());
//    				RedisUtil.setex(Constant.USER + clientUserUpdatePhoneDTO.getPhone(), user);
    				RedisUtil.setex(Constant.USER + userId, user);
    				RedisUtil.setex( Constant.TOKEN + clientUserUpdatePhoneDTO.getPhone(),10800,RedisUtil.get(Constant.TOKEN + userId));
    				RedisUtil.del(Constant.USER + userId);
    				RedisUtil.del(Constant.TOKEN + userId);
    			}
    			response = new RestResponse(MsgErrCode.SUCCESS);
			}else {
				return new RestResponse(1,"请传入正确验证类型");
			}
    	}
    	return response;
	}

	@Override
	public RestResponse updatePassword(ClientUserUpdatePasswordDTO clientUserUpdatePasswordDTO) throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		RestResponse response;
		String password = DesUtil.encrypt(clientUserUpdatePasswordDTO.getOldPassword());
		if (password.equals(user.getPassword())){
			ClientBuserDO clientBuserDO = new ClientBuserDO();
			clientBuserDO.setLoginId(user.getLoginId());
			clientBuserDO.setPassword(DesUtil.encrypt(clientUserUpdatePasswordDTO.getNewPassword()));
			clientBuserDO.setModifyUser(user.getId());
			clientBuserDO.setIsFirstLand(SysDictEnum.YES.getCode());
			this.clinetBuserModifyDao.updateClientBuser(clientBuserDO);
			RedisUtil.del(Constant.USER + user.getLoginId());
			user.setPassword(password);
			RedisUtil.setex(Constant.USER + user.getLoginId(), user);
			response = new RestResponse(MsgErrCode.SUCCESS);
		}else {
			response = new RestResponse(NativeMsgErrCode.ERROR_PASSWORD);
		}
		return response;
	}

	@Override
	public RestResponse forgetPassword(ClientUserUpdateDTO clientUserUpdateDTO) throws Exception {
		RestResponse response;
		response = validMessageService.validateMessageCode(clientUserUpdateDTO.getPhone(),clientUserUpdateDTO.getMsgCode(),CurrencyConstant.MESSAGE_VALID_TIME,null,null);
		if (response.getResult() == 0) {
			ClientBuserDO clientBuserDO = this.clinetBuserModifyDao.getClientBuserByMobile(clientUserUpdateDTO.getPhone());
			if (clientBuserDO != null) {
				ClientBuserDO cbUserDO = new ClientBuserDO();
				cbUserDO.setPassword(DesUtil.encrypt(clientUserUpdateDTO.getNewPassword()));
				cbUserDO.setModifyUser(clientBuserDO.getId());
				cbUserDO.setLoginId(cbUserDO.getLoginId());
				cbUserDO.setIsFirstLand(SysDictEnum.YES.getCode());
				this.clinetBuserModifyDao.updateClientBuser(clientBuserDO);
				response = new RestResponse(MsgErrCode.SUCCESS);
			}else {
				response = new RestResponse(NativeMsgErrCode.ACCOUNTNOTREGISTERED);
			}
		}
		return response;
	}

}
