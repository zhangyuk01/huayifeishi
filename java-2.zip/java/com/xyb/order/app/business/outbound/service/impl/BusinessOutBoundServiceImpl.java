package com.xyb.order.app.business.outbound.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.DateTimeUtil;
import com.xyb.auth.user.model.User;
import com.xyb.credit.common.model.DepotTimeDO;
import com.xyb.credit.common.service.CreditCommonService;
import com.xyb.credit.constant.DictionariesConstant;
import com.xyb.credit.creditreport.model.AuditSingleRecordDO;
import com.xyb.credit.creditreport.service.CreditReportService;
import com.xyb.order.app.business.outbound.dao.BusinessOutBoundDao;
import com.xyb.order.app.business.outbound.model.*;
import com.xyb.order.app.business.outbound.service.BusinessOutBoundService;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.service.AuditCheckItemService;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.material.service.FileDataInfoService;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.util.SessionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.service.impl
 * @description :
 * @createDate : 2018/6/13 11:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
@Service(interfaceName = "com.xyb.order.app.business.outbound.service.BusinessOutBoundService")
public class BusinessOutBoundServiceImpl implements BusinessOutBoundService {

    @Autowired
    private BusinessOutBoundDao businessOutBoundDao;
    @Autowired
    private ApplyBillInfoDao applyBillInfoDao;
    @Autowired
    private CurrencyDao currencyDao;
    @Autowired
    private AuditCheckItemService auditCheckItemService;
    @Autowired
    private TableModifyLogService tableModifyService;
    @Reference
    private CreditReportService creditReportService;
    @Autowired
    private FileDataInfoService fileService;
    @Reference
    private CreditCommonService commonService;

    /**信审系统审批项值*/
    private Integer item = 15;

    /**
     * 查询外访列表
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessOutBoundList() throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
//        User user = new User();
//        user.setId(20L);
        List<BusinessOutBoundListVO> businessOutBoundList = businessOutBoundDao.getBusinessOutBoundList(user.getId());
        return new RestResponse(MsgErrCode.SUCCESS,businessOutBoundList);
    }

    /**
     * 查询客户信息
     * @param applyMainId
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessClientInfo(Long applyMainId) throws Exception{
        BusinessOutBoundClientInfoVO businessOutBoundClientInfoVO = businessOutBoundDao.getBusinessClientInfo(applyMainId);
        return new RestResponse(MsgErrCode.SUCCESS,businessOutBoundClientInfoVO);
    }

    /**
     * 查询工作信息
     * @param visitMainId
     * @param applyMainId
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessJobInfo(Long visitMainId,Long applyMainId) throws Exception{
         Map<String,Object>  resultMap = new HashMap<>(2);
         BusinessOutBoundJobInfoVO businessOutBoundJobInfo = businessOutBoundDao.getBusinessJobInfo(visitMainId);
        //如果对象是null证明是第一次录入给默认一致；
         if(businessOutBoundJobInfo == null){
               BusinessOutBoundJobInfoVO  businessOutBoundJobInfoVO = new BusinessOutBoundJobInfoVO();
               // 单位名称是否一致
               businessOutBoundJobInfoVO.setIsCompNameSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
               //单位电话是否一致
               businessOutBoundJobInfoVO.setIsCompTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
               //单位地址是否一致
               businessOutBoundJobInfoVO.setIsCompAddressSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
               resultMap.put("businessOutBoundJobInfo",businessOutBoundJobInfoVO);
         }else {
                if(businessOutBoundJobInfo.getIsCompNameSame() == null){
                      // 单位名称是否一致
                      businessOutBoundJobInfo.setIsCompNameSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                }
                if(businessOutBoundJobInfo.getIsCompTellSame() == null){
                      //单位电话是否一致
                      businessOutBoundJobInfo.setIsCompTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                }
                if(businessOutBoundJobInfo.getIsCompAddressSame() == null){
                      //单位地址是否一致
                      businessOutBoundJobInfo.setIsCompAddressSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                }
               resultMap.put("businessOutBoundJobInfo",businessOutBoundJobInfo);
         }
        BusinessOutBoundJobInfoVO applyJobInfo = businessOutBoundDao.getApplyJobInfo(applyMainId);
        resultMap.put("applyJobInfo",applyJobInfo); 
        return new RestResponse(MsgErrCode.SUCCESS,resultMap);
    }

    /**
     * 查询家庭信息
     * @param visitMainId
     * @param applyMainId
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessFamilyInfo(Long visitMainId,Long applyMainId) throws Exception{
        Map<String,Object>  resultMap = new HashMap<>(2);
        List<BusinessOutBoundFamilyVO> businessOutBoundFamilyList = businessOutBoundDao.getBusinessFamilyInfo(visitMainId);
         //如果list的size是0证明是第一次录入给默认一致；
        if(businessOutBoundFamilyList.size() == 0){
            BusinessOutBoundFamilyVO businessOutBoundFamily = new BusinessOutBoundFamilyVO();
            //家庭电话是否一致
            businessOutBoundFamily.setIsFamilyTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
            //家庭地址是否一致
            businessOutBoundFamily.setIsFamilyAddressSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
            businessOutBoundFamilyList.add(businessOutBoundFamily);
            resultMap.put("businessOutBoundFamily",businessOutBoundFamilyList);
        }else {
            List<BusinessOutBoundFamilyVO> businessOutBoundFamilyVOList = new LinkedList<>();
            for (int i=0;i<businessOutBoundFamilyList.size();i++){
                BusinessOutBoundFamilyVO  businessOutBoundFamilyInfo = businessOutBoundFamilyList.get(i);
                if(businessOutBoundFamilyInfo.getIsFamilyTellSame() == null){
                     //家庭电话是否一致
                     businessOutBoundFamilyInfo.setIsFamilyTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                }
                if(businessOutBoundFamilyInfo.getIsFamilyAddressSame() == null){
                    //家庭地址是否一致
                    businessOutBoundFamilyInfo.setIsFamilyAddressSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                }
                 businessOutBoundFamilyVOList.add(businessOutBoundFamilyInfo);
            }
               resultMap.put("businessOutBoundFamily",businessOutBoundFamilyVOList);
        }
        BusinessOutBoundFamilyVO applyFamilyInfo = businessOutBoundDao.getApplyFamilyInfo(applyMainId);
        resultMap.put("applyFamilyInfo",applyFamilyInfo);
        return new RestResponse(MsgErrCode.SUCCESS,resultMap);
    }

    /**
     * 查询经营信息
     * @param visitMainId
     * @param applyMainId
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessManagermentInfo(Long visitMainId,Long applyMainId) throws Exception{
         Map<String,Object>  resultMap = new HashMap<>(2);
         List<BusinessOutBoundManagermentInfoVO> businessOutBoundManagermentInfoList = businessOutBoundDao.getBusinessManagermentInfo(visitMainId);
         //如果list的size是0证明是第一次录入给默认一致；
         if(businessOutBoundManagermentInfoList.size() == 0){
               BusinessOutBoundManagermentInfoVO businessOutBoundManagermentInfo = new BusinessOutBoundManagermentInfoVO();
               //经营公司名称是否一致
               businessOutBoundManagermentInfo.setIsManagementCompNameSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
               //经营公司电话是否一致
               businessOutBoundManagermentInfo.setIsManagementCompTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
               businessOutBoundManagermentInfoList.add(businessOutBoundManagermentInfo);
               resultMap.put("businessOutBoundManagermentInfo",businessOutBoundManagermentInfoList);
         }else {
                List<BusinessOutBoundManagermentInfoVO> businessOutBoundManagermentInfoVOList = new LinkedList<>();
               for (int i=0;i<businessOutBoundManagermentInfoList.size();i++){
                    BusinessOutBoundManagermentInfoVO businessOutBoundManagermentInfo = businessOutBoundManagermentInfoList.get(i);
                    if(businessOutBoundManagermentInfo.getIsManagementCompNameSame() == null){
                        //经营公司名称是否一致
                        businessOutBoundManagermentInfo.setIsManagementCompNameSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                    }
                    if(businessOutBoundManagermentInfo.getIsManagementCompTellSame() == null){
                        //经营公司电话是否一致                                                       
                        businessOutBoundManagermentInfo.setIsManagementCompTellSame(CurrencyConstant.CURRENCY_CONSTANT_2486);
                    }
                    businessOutBoundManagermentInfoVOList.add(businessOutBoundManagermentInfo);
               }
               resultMap.put("businessOutBoundManagermentInfo",businessOutBoundManagermentInfoVOList);
         }
         BusinessOutBoundManagermentInfoVO applyManagermentInfo = businessOutBoundDao.getApplyManagermentInfo(applyMainId);
         resultMap.put("applyManagermentInfo",applyManagermentInfo);
        return  new RestResponse(MsgErrCode.SUCCESS,resultMap);
    }

    /**
     * 查询产调信息
     * @param applyId
     * @return
     * @throws Exception
     */
    @Override
    public RestResponse getBusinessPropertySurveyInfo(Long applyId) throws Exception{
            BusinessOutBoundPropertySurveyVO businessOutBoundPropertySurveyVO = businessOutBoundDao.getBusinessPropertySurveyInfo(applyId);
            if(businessOutBoundPropertySurveyVO != null){
                if(businessOutBoundPropertySurveyVO.getPropertySurveyDate() != null){
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date  parse = sdf.parse(businessOutBoundPropertySurveyVO.getPropertySurveyDate());
                    String format = sdf.format(parse);
                    businessOutBoundPropertySurveyVO.setPropertySurveyDate(format);
                }
            }
        return  new RestResponse(MsgErrCode.SUCCESS,businessOutBoundPropertySurveyVO);
    }

    /**
     * 工作信息新增和修改
     * @param businessOutBoundJobInfoDTO
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateOrAddBusinessJobInfo(BusinessOutBoundJobInfoDTO businessOutBoundJobInfoDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        if(businessOutBoundJobInfoDTO.getId() != null && 0 != businessOutBoundJobInfoDTO.getId()){
                businessOutBoundJobInfoDTO.setModifyUser(user.getId());
                businessOutBoundDao.updateBusinessJobInfo(businessOutBoundJobInfoDTO);
        }else {
                businessOutBoundJobInfoDTO.setCreateUser(user.getId());
                businessOutBoundJobInfoDTO.setCreateTime(new Date());
                businessOutBoundJobInfoDTO.setModifyUser(user.getId());
                businessOutBoundJobInfoDTO.setModifyTime(new Date());
                businessOutBoundDao.addBusinessJobInfo(businessOutBoundJobInfoDTO);
        }
        return  new RestResponse(MsgErrCode.SUCCESS);
    }

    /**
     * 家庭信息新增和修改
     * @param businessOutBoundFamilyInfoDTO
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateOrAddBusinessFamilyInfo(BusinessOutBoundFamilyInfoDTO businessOutBoundFamilyInfoDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
        List<BusinessOutBoundFamilyInfoDO> businessOutBoundFamilyInfoDO = businessOutBoundFamilyInfoDTO.getBusinessOutBoundFamilyInfoDOs();
        if(businessOutBoundFamilyInfoDO.size() > 0){
            for (int i=0;i < businessOutBoundFamilyInfoDO.size();i++){
                BusinessOutBoundFamilyInfoDO outBoundFamilyInfoDO = businessOutBoundFamilyInfoDO.get(i);
                if(outBoundFamilyInfoDO.getId() != null && 0 != outBoundFamilyInfoDO.getId()){
                    outBoundFamilyInfoDO.setModifyUser(user.getId());
                    businessOutBoundDao.updateBusinessFamilyInfo(outBoundFamilyInfoDO);
                }else {
                    outBoundFamilyInfoDO.setCreateUser(user.getId());
                    outBoundFamilyInfoDO.setCreateTime(new Date());
                    outBoundFamilyInfoDO.setModifyUser(user.getId());
                    outBoundFamilyInfoDO.setModifyTime(new Date());
                    businessOutBoundDao.addBusinessFamilyInfo(outBoundFamilyInfoDO);
                }
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    /**
     * 经营信息新增和修改
     * @param businessOutBoundManagermentInfoDTO
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateOrAddBusinessManagermentInfo(BusinessOutBoundManagermentInfoDTO businessOutBoundManagermentInfoDTO) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);
//        User user = new User();
//        user.setId(20L);
        List<BusinessOutBoundManagermentInfoDO> businessOutBoundManagermentInfoDO =  businessOutBoundManagermentInfoDTO.getBusinessOutBoundManagermentInfoDOs();
        if(businessOutBoundManagermentInfoDO.size() >0){
            for (int i=0;i<businessOutBoundManagermentInfoDO.size();i++){
                BusinessOutBoundManagermentInfoDO outBoundManagermentInfoDO = businessOutBoundManagermentInfoDO.get(i);
                if(outBoundManagermentInfoDO.getId() != null && 0 != outBoundManagermentInfoDO.getId()){
                    outBoundManagermentInfoDO.setModifyUser(user.getId());
                    businessOutBoundDao.updateBusinessManagermentInfo(outBoundManagermentInfoDO);
                }else {
                    outBoundManagermentInfoDO.setCreateUser(user.getId());
                    outBoundManagermentInfoDO.setCreateTime(new Date());
                    outBoundManagermentInfoDO.setModifyUser(user.getId());
                    outBoundManagermentInfoDO.setModifyTime(new Date());
                    businessOutBoundDao.addBusinessManagermentInfo(outBoundManagermentInfoDO);
                }
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    /**
     * 产调新增和修改（提交流程）
     * @param businessOutBoundPropertySurveyDTO
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse updateOrAddBusinessPropertySurveyInfo(BusinessOutBoundPropertySurveyDTO businessOutBoundPropertySurveyDTO) throws Exception{
        RestResponse restResponse;
        User user = SessionUtil.getLoginUser(User.class);
//        User user = new User();
//        user.setId(20L);
        if(businessOutBoundPropertySurveyDTO.getId() != null && 0 != businessOutBoundPropertySurveyDTO.getId()){
            businessOutBoundPropertySurveyDTO.setModifyUser(user.getId());
            businessOutBoundDao.updateBusinessPropertySurveyInfo(businessOutBoundPropertySurveyDTO);
        }else{
            businessOutBoundPropertySurveyDTO.setCreateUser(user.getId());
            businessOutBoundPropertySurveyDTO.setCreateTime(new Date());
            businessOutBoundPropertySurveyDTO.setModifyUser(user.getId());
            businessOutBoundPropertySurveyDTO.setModifyTime(new Date());
            businessOutBoundDao.addBusinessPropertySurveyInfo(businessOutBoundPropertySurveyDTO);
        }
        Map<String, Object> map = new HashMap<>(2);
        map.put("visitIndustryDate",businessOutBoundPropertySurveyDTO.getPropertySurveyDate());
        map.put("industryDescription",businessOutBoundPropertySurveyDTO.getRemark());
        map.put("applyId",businessOutBoundPropertySurveyDTO.getApplyId());
        map.put("modifyTime",new Date());
        businessOutBoundDao.updateApplyVisitMainInfo(map);

        //如果提交标识flag为N，则走提交流程
        if(CurrencyConstant.N.equals(businessOutBoundPropertySurveyDTO.getFlag())) {
            BusinessOutBoundVisitMainInfoDO businessOutBoundVisitMainInfoDO = businessOutBoundDao.queryVisitMainInfo(businessOutBoundPropertySurveyDTO.getApplyId());
            if (NodeStateConstant.VISIT_MAIN_TYPE_2522.equals(businessOutBoundVisitMainInfoDO.getVisitType())) {
                BusinessOutBoundJobInfoVO businessOutBoundJobInfo = businessOutBoundDao.getBusinessJobInfo(businessOutBoundPropertySurveyDTO.getVisitMainId());
                List<BusinessOutBoundFamilyVO> businessOutBoundFamily = businessOutBoundDao.getBusinessFamilyInfo(businessOutBoundPropertySurveyDTO.getVisitMainId());
                List<BusinessOutBoundManagermentInfoVO> businessOutBoundManagermentInfoVO = businessOutBoundDao.getBusinessManagermentInfo(businessOutBoundPropertySurveyDTO.getVisitMainId());
                if (businessOutBoundJobInfo != null && businessOutBoundFamily.size() > 0 && businessOutBoundManagermentInfoVO.size() > 0 ) {
                    businessOutBoundSubmit(businessOutBoundPropertySurveyDTO.getVisitMainId(), businessOutBoundPropertySurveyDTO.getApplyId());
                    restResponse = new RestResponse(MsgErrCode.SUCCESS);
                }else {
                    restResponse = new RestResponse(MsgErrCode.FAIL,"请完善工作信息,家庭信息,经营信息之后再进行提交");
                }
            }else {
                businessOutBoundSubmit(businessOutBoundPropertySurveyDTO.getVisitMainId(), businessOutBoundPropertySurveyDTO.getApplyId());
                restResponse = new RestResponse(MsgErrCode.SUCCESS);
            }
        }else {
            restResponse = new RestResponse(MsgErrCode.SUCCESS);
        }
        return restResponse;
    }

    /**
     * 经营信息提交流程
     *
     * @param businessOutBoundManagermentSubmitDTO
     * @return
     */
    @Override
    public RestResponse businessManagermentSubmit(BusinessOutBoundManagermentSubmitDTO businessOutBoundManagermentSubmitDTO) throws Exception {
        RestResponse restResponse;
        Map<String, Object> map = new HashMap<>(2);
        map.put("visitDate", businessOutBoundManagermentSubmitDTO.getVisitDate());
        map.put("customerIntegratedDescription", businessOutBoundManagermentSubmitDTO.getCustomerIntegratedDescription());
        map.put("visitMainId", businessOutBoundManagermentSubmitDTO.getVisitMainId());
        map.put("modifyTime", new Date());
        businessOutBoundDao.updateApplyVisitMainInfo(map);

        if (CurrencyConstant.N.equals(businessOutBoundManagermentSubmitDTO.getFlag())) {
            BusinessOutBoundVisitMainInfoDO businessOutBoundVisitMainInfoDO = businessOutBoundDao.queryVisitMainInfo(businessOutBoundManagermentSubmitDTO.getApplyId());
            if (NodeStateConstant.VISIT_MAIN_TYPE_2522.equals(businessOutBoundVisitMainInfoDO.getVisitType())) {
                BusinessOutBoundPropertySurveyVO businessOutBoundPropertySurveyVO = businessOutBoundDao.getBusinessPropertySurveyInfo(businessOutBoundManagermentSubmitDTO.getApplyId());
                if (businessOutBoundPropertySurveyVO != null) {
                    businessOutBoundSubmit(businessOutBoundManagermentSubmitDTO.getVisitMainId(), businessOutBoundManagermentSubmitDTO.getApplyId());
                    restResponse = new RestResponse(MsgErrCode.SUCCESS);
                } else {
                    restResponse = new RestResponse(MsgErrCode.FAIL,"请完善产调信息之后再提交");
                }
            } else {
                businessOutBoundSubmit(businessOutBoundManagermentSubmitDTO.getVisitMainId(), businessOutBoundManagermentSubmitDTO.getApplyId());
                restResponse = new RestResponse(MsgErrCode.SUCCESS);
            }
        }else {
            restResponse = new RestResponse(MsgErrCode.SUCCESS);
        }
        return restResponse;
    }

    private void businessOutBoundSubmit(Long visitMainId, Long applyId) throws Exception{
        User user = SessionUtil.getLoginUser(User.class);

        /**更新外访主表信息*/
        Map<String, Object> map = new HashMap<>(2);
        map.put("visitUid",user.getId());
        map.put("visitState", SysDictEnum.OUT_BOUND_TYPEFOUR.getCode());
        map.put("visitMainId",visitMainId);
        businessOutBoundDao.updateApplyVisitMainInfo(map);
        /**2.更改流程状态为终审中*/
        Map<String, Object> queryMap = new HashMap<>(2);
        queryMap.put("applyId", applyId);
        ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(queryMap);
        Integer provious = applyBillMainInfoDO.getPrevious();

        MainLogDTO mainLogDTO = new MainLogDTO();
        mainLogDTO.setBusinessState(NodeStateConstant.IN_THE_FINAL_TRIAL);
        mainLogDTO.setMainId(applyBillMainInfoDO.getId());
        mainLogDTO.setModifyUser(user.getId());
        currencyDao.addMainLog(mainLogDTO);

        String oldData =  JsonUtil.object2json(applyBillMainInfoDO);

        applyBillMainInfoDO.setState(applyBillMainInfoDO.getPrevious());
        applyBillMainInfoDO.setPrevious(NodeStateConstant.OUTSIDE_VISIT);
        applyBillMainInfoDO.setModifyTime(new Date());
        applyBillMainInfoDO.setModifyUser(user.getId());
        applyBillMainInfoDO.setVisitSubmitAuditTime(new Date());
        currencyDao.updateMainInFo(applyBillMainInfoDO);

        String newData = JsonUtil.object2json(applyBillMainInfoDO);
        boolean flag = tableModifyService.insertApplyCommonModifyLog(user.getId(),applyBillMainInfoDO.getId(), TableConstant.T_APPLY_MAIN_INFO,oldData,newData);
        if(flag){
            /**更新审批时效*/
            updateDepotTime(applyBillMainInfoDO.getApplyId(),provious,user.getId());
            currencyDao.updateMainInFo(applyBillMainInfoDO);
        }
        /**3.更新图片信息为不可删除*/
        fileService.updateFileState(applyBillMainInfoDO.getApplyId(), user.getId(), FileNameConstant.OUTBOUND_IMAGES_TYPE);
        /**4.更新审核项表信息*/
        AuditSingleRecordDO auditSingleRecordDO = new AuditSingleRecordDO();
        auditSingleRecordDO.setApplyId(applyBillMainInfoDO.getApplyId());
        auditSingleRecordDO.setItem(item);
        creditReportService.deleteAuditSingleRecord(auditSingleRecordDO);
        auditCheckItemService.insertCheckItem(applyBillMainInfoDO.getApplyId(), AuditCheckItemConstant.FIELD_LETTER);
    }


    private void updateDepotTime(Long applyId,Integer previous,Long userId){
        DepotTimeDO timeDO = new DepotTimeDO();
        Date startTime = DateTimeUtil.getNow();
        timeDO.setBeginTimeOne(startTime);
        timeDO.setBeginTimeTwo(startTime);
        timeDO.setBeginTimeThree(startTime);
        timeDO.setCreateUser(userId);
        timeDO.setApplyId(applyId);
        if(NodeStateConstant.AUDIT.equals(previous)){
            /**上一节点高级审核更新初审审批时效*/
            timeDO.setAuditType(DictionariesConstant.AUDIT_STATE_2669);
        }else if(NodeStateConstant.IN_THE_FINAL_TRIAL.equals(previous)){
            /**上一节点终审更新终审审批时效*/
            timeDO.setAuditType(DictionariesConstant.AUDIT_STATE_2670);
        }
        commonService.updateDepotTime(timeDO);
    }
}