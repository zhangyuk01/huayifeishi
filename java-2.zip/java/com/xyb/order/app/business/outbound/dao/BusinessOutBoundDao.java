package com.xyb.order.app.business.outbound.dao;

import com.xyb.order.app.business.outbound.model.*;

import java.util.List;
import java.util.Map;

/**
 * @author : weiyuhao
 * @projectName : credit
 * @package : com.xyb.order.app.business.outbound.dao
 * @description :
 * @createDate : 2018/6/13 11:09
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface BusinessOutBoundDao {

    List<BusinessOutBoundListVO> getBusinessOutBoundList(Long userId);

    BusinessOutBoundClientInfoVO getBusinessClientInfo(Long applyMainId);

    BusinessOutBoundJobInfoVO getBusinessJobInfo(Long visitMainId);

    List<BusinessOutBoundFamilyVO> getBusinessFamilyInfo(Long visitMainId);

    List<BusinessOutBoundManagermentInfoVO> getBusinessManagermentInfo(Long visitMainId);

    BusinessOutBoundPropertySurveyVO getBusinessPropertySurveyInfo(Long applyId);

    void updateBusinessJobInfo(BusinessOutBoundJobInfoDTO businessOutBoundJobInfoDTO);

    void addBusinessJobInfo(BusinessOutBoundJobInfoDTO businessOutBoundJobInfoDTO);

    void updateBusinessFamilyInfo(BusinessOutBoundFamilyInfoDO businessOutBoundFamilyInfoDO);

    void addBusinessFamilyInfo(BusinessOutBoundFamilyInfoDO businessOutBoundFamilyInfoDO);

    void updateBusinessManagermentInfo(BusinessOutBoundManagermentInfoDO businessOutBoundManagermentInfoDO);

    void addBusinessManagermentInfo(BusinessOutBoundManagermentInfoDO businessOutBoundManagermentInfoDO);

    void updateBusinessPropertySurveyInfo(BusinessOutBoundPropertySurveyDTO businessOutBoundPropertySurveyDTO);

    void addBusinessPropertySurveyInfo(BusinessOutBoundPropertySurveyDTO businessOutBoundPropertySurveyDTO);

    void updateApplyVisitMainInfo(Map map);

    BusinessOutBoundVisitMainInfoDO queryVisitMainInfo(Long applyId);

    BusinessOutBoundJobInfoVO getApplyJobInfo(Long applyMainId);

    BusinessOutBoundFamilyVO getApplyFamilyInfo(Long applyMainId);

    BusinessOutBoundManagermentInfoVO getApplyManagermentInfo(Long applyMainId);
}
