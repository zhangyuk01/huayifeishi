package com.xyb.order.common.currency.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.common.currency.dao.AuditCheckItemDao;
import com.xyb.order.common.currency.service.AuditCheckItemService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

@Service(interfaceName = "com.xyb.order.common.currency.service.AuditCheckItemService")
public class AuditCheckItemServiceImpl implements AuditCheckItemService {

    private static final Logger logger = LoggerFactory.getLogger(AuditCheckItemServiceImpl.class);

    @Autowired
    private AuditCheckItemDao auditCheckItemDao;

    @Override
    public RestResponse insertCheckItem(Long primaryInfoId, Integer item)throws Exception {
        try {
            if (primaryInfoId != null && item != null){
                Map<String,Object> paraMap = new HashMap<>();
                paraMap.put("item",item);
                paraMap.put("primaryInfoId",primaryInfoId);
                int count = auditCheckItemDao.getCheckItemCount(paraMap);
                if (count < 1){
                    paraMap.put("user",CurrencyConstant.SYSTEM_USER);
                    auditCheckItemDao.insertAuditCheckItem(paraMap);
                }
                return new RestResponse(MsgErrCode.SUCCESS);
            }else {
                return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
            }
        }catch (Exception e){
            logger.error("调用添加未过审页面接口异常applyId="+primaryInfoId+",item="+item+":"+e);
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }
}
