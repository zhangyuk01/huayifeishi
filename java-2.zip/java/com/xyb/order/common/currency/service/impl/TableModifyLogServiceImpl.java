package com.xyb.order.common.currency.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.xyb.order.common.constant.TableConstant;
import com.xyb.order.common.currency.dao.TableModifyLogDao;
import com.xyb.order.common.currency.model.TableModifyLogDTO;
import com.xyb.order.common.currency.service.TableModifyLogService;
import com.xyb.order.common.util.JsonDiff;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

/**
 * 比较方法
 * @author         xieqingyang
 * @date           2018/10/19 5:06 PM
*/
@Service(interfaceName="com.xyb.order.common.currency.service.TableModifyLogService")
public class TableModifyLogServiceImpl implements TableModifyLogService{

    @Autowired
    private TableModifyLogDao tableModifyLogDao;
    @Autowired
    private TableModifyLogService tableModifyLogService;

    @Override
    public boolean insertTableModirfyLog(TableModifyLogDTO modifyLogDTO){
        JsonDiff jsonDiff = new JsonDiff();
        jsonDiff.setTableKey(modifyLogDTO.getTableKey());
        jsonDiff.setTableName(modifyLogDTO.getTableName());
        jsonDiff.setCreateUser(modifyLogDTO.getCreateUser());
        if (modifyLogDTO.getNoNeed() != null && modifyLogDTO.getNoNeed().length > 0){
            jsonDiff.setNoNeedMap(modifyLogDTO.getNoNeed());
        }
        jsonDiff.getDiff(modifyLogDTO.getModifyOldValue(),modifyLogDTO.getModifyNewValue());
        List<TableModifyLogDTO> modifyLogDTOS = jsonDiff.getModifyLogDTOS();
        if (modifyLogDTOS != null && modifyLogDTOS.size() > 0) {
            tableModifyLogDao.insertTableModirfyLog(modifyLogDTOS);
        }
        return jsonDiff.getState();
    }

    @Override
    public boolean insertApplyCommonModifyLog(Long userId,Long id,String tableName,String oldJsonData,String newJsonData){
        String[] noNeed;
        if (TableConstant.T_APPLY_BILL_INFO.equals(tableName)) {
            /**申请表**/
            noNeed = new String[]{TableConstant.T_FIELD_APPLYTIME,TableConstant.T_FIELD_BORROWDESCCODESTR,TableConstant.T_FIELD_IS_TEMP_SAVE,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER,TableConstant.T_FIELD_RECOMMENDER};
        }else if(TableConstant.T_APPLY_CLIENT_INFO.equals(tableName)){
            /**客户信息表**/
            noNeed = new String[]{TableConstant.T_FIELD_NATIONSTR,TableConstant.T_FIELD_GENDERSTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_APPLY_PERSONAL_INFO.equals(tableName)){
            /**个人信息表**/
            noNeed = new String[]{TableConstant.T_FIELD_CHILDRENNUMSTR,TableConstant.T_FIELD_EDUCATIONSTR,TableConstant.T_FIELD_YEARINCOME,TableConstant.T_FIELD_MARRIAGESTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_APPLY_JOB_INFO.equals(tableName)){
            /**工作信息**/
            noNeed = new String[]{TableConstant.T_FIELD_COMPTYPESTR,TableConstant.T_FIELD_STAFFAMOUNTSTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER,TableConstant.T_FIELD_COMPDUTYSTR};
        }else if(TableConstant.T_APPLY_PRIVATE_INFO.equals(tableName)){
            /**私营信息**/
            noNeed = new String[]{TableConstant.T_FIELD_PALACESTR,TableConstant.T_FIELD_STAFFAMOUNTSTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_APPLY_PRIVATE_INFO.equals(tableName)){
            /**企业信息表**/
            noNeed = new String[]{TableConstant.T_FIELD_ENTETYPESTR,TableConstant.T_FIELD_STAFFAMOUNTSTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_AUDIT_PERSONAL_INCOME.equals(tableName) ||
                TableConstant.T_AUDIT_COMP_INCOME.equals(tableName)){
            /**个人收入证明和企业收入证明**/
            noNeed = new String[]{TableConstant.T_FIELD_IS_DEL_STATE,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_AUDIT_OTHER_HOUSE.equals(tableName)){
            /**房产证明**/
            noNeed = new String[]{TableConstant.T_FIELD_PRODUCTID, TableConstant.T_FIELD_MORTGAGEEXPLAINSTR,TableConstant.T_FIELD_HOUSESHARESTR,TableConstant.T_FIELD_HOUSEADDRESSPROVINCESTR,TableConstant.T_FIELD_HOUSEADDRESSCITYSTR,
                    TableConstant.T_FIELD_HOUSEADDRESSAREASTR,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_APPLY_INSURANCE_INFO.equals(tableName)){
            /**保单证明页签**/
            noNeed = new String[]{TableConstant.T_FIELD_SYSTEMDATE,TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }else if(TableConstant.T_APPLY_JOB_INFO.equals(tableName)){
            /**工作证明页签**/
            noNeed = new String[]{TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER,TableConstant.T_FIELD_COMPNAME,TableConstant.T_FIELD_COMPDEPT,TableConstant.T_FIELD_COMPDUTY,TableConstant.T_FIELD_COMPDUTYSTR,TableConstant.T_FIELD_COMPJOINDATE};
        }else{
            noNeed = new String[]{TableConstant.T_FIELD_CREATE_TIME,TableConstant.T_FIELD_CREATE_USER,TableConstant.T_FIELD_MODIFY_TIME,TableConstant.T_FIELD_MODIFY_USER};
        }
        TableModifyLogDTO tableModifyLogDTO = new TableModifyLogDTO();
        tableModifyLogDTO.setTableName(tableName);
        tableModifyLogDTO.setModifyOldValue(oldJsonData);
        tableModifyLogDTO.setTableKey(id);
        tableModifyLogDTO.setModifyNewValue(newJsonData);
        tableModifyLogDTO.setNoNeed(noNeed);
        tableModifyLogDTO.setCreateUser(userId);
        return tableModifyLogService.insertTableModirfyLog(tableModifyLogDTO);
    }
}
