package com.xyb.order.common.currency.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.xyb.auth.bulletin.service.BulletinService;
import com.xyb.auth.user.model.User;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.currency.model.*;
import com.xyb.order.common.currency.service.CurrencyService;
import com.xyb.risks.process.foreign.service.ForeignService;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.DropDownBoxConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by xieqingyang on 2018/4/17.
 */
@Service(interfaceName = "com.xyb.order.common.currency.service.CurrencyService")
public class CurrencyServiceImpl implements CurrencyService{

    @Autowired
    private CurrencyDao currencyDao;
    @Reference
    private BulletinService bulletinService;
    @Reference
    private ForeignService foreignService;

    @Override
    public RestResponse queryProcessLog(Long mainId)  throws Exception{
        List<ProcessLogDO> processLogDOS = currencyDao.queryProcessLog(mainId);
        return new RestResponse(MsgErrCode.SUCCESS, processLogDOS);
    }

    @Override
    public RestResponse queryDropDownBox(DropDownBoxListDTO downBoxListDTO) throws Exception{
        List<DropDownBoxDTO> dropDownBoxDTOS = downBoxListDTO.getDownBoxDTOS();
        Map<String,Object> map = new HashMap<>();
        String key;
        for (DropDownBoxDTO dto:dropDownBoxDTOS){
            key = RedisConstant.ORDER + (StringUtils.isNullOrEmpty(dto.getType())?"":dto.getType())+(dto.getParamete()==null?"":dto.getParamete()+"");
            if (StringUtils.isNotNullAndEmpty(dto.getType())){
                if (RedisUtil.exists(key)){
                    map.put(key,RedisUtil.get(key,List.class));
                }else {
                    map.put(key, findDropDownBoxByType(key, dto));
                }
            }else {
                map.put(key, null);
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS, map);
    }

    @Override
    public RestResponse queryProductLimitByOrg(QueryProductLimitByProductIdAndOrgIdDTO dto) throws Exception {
        RestResponse response;
        List<Map<String, Object>> list = currencyDao.queryProductLimitByOrg(dto);
        if (list != null && list.size() > 0){
            response = new RestResponse(MsgErrCode.SUCCESS,list);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS);
        }
        return response;
    }

    @Override
    public RestResponse findBulletin(Integer pageNumber, Integer pageSize) throws Exception {
        return bulletinService.findBulletinByLogin(pageNumber,pageSize);
    }

    @Override
    public RestResponse findTeamManagerByOrgId(QueryTeanManagerDTO queryTeanManagerDTO) throws Exception {
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("teamOrgId",queryTeanManagerDTO.getTeamOrgId());
        paraMap.put("storeOrgId",queryTeanManagerDTO.getStoreOrgId());
        List<Map<String, Object>> mapList = this.currencyDao.findTeamManagerByOrgId(paraMap);
        if (mapList != null && mapList.size() > 0) {
            return new RestResponse(MsgErrCode.SUCCESS, mapList);
        }else {
            return new RestResponse(MsgErrCode.SUCCESS);
        }
    }

    /**
     * 根据查询类型使用不同方法查询
     * @param dropDownBoxDTO
     * @return
     */
    private List<Map<String, Object>> findDropDownBoxByType(String key,DropDownBoxDTO dropDownBoxDTO)throws Exception{
        List<Map<String, Object>> mapList;
        User user;
        switch (dropDownBoxDTO.getType()){
            case DropDownBoxConstant.PROVINCE:
                mapList = this.currencyDao.findAllProvince();
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.CITY:
                mapList = this.currencyDao.findCityByParent(dropDownBoxDTO.getParamete());
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.AREA:
                mapList = this.currencyDao.findAreaByParent(dropDownBoxDTO.getParamete());
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.SUBORDINAT_ORG:
                user = SessionUtil.getLoginUser(User.class);
                mapList = findAllTeamOrg(SysDictEnum.IS_VALID.getCode(), dropDownBoxDTO.getParamete(), user.getDataOrgId());
                break;
            case DropDownBoxConstant.SUBORDINAT:
                user = SessionUtil.getLoginUser(User.class);
                mapList = findAllTeamOrg(SysDictEnum.IS_VALID.getCode(), dropDownBoxDTO.getParamete(), user.getOrgId());
                break;
            case DropDownBoxConstant.LARGE_AREA:
                mapList = findAllTeamOrg(SysDictEnum.IS_VALID.getCode(), dropDownBoxDTO.getParamete(), null);
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.PERSONNEL_BY_USER:
                user = SessionUtil.getLoginUser(User.class);
                mapList = findAllOrgServiceManger(dropDownBoxDTO.getParamete(), SysDictEnum.IS_VALID.getCode(), user.getOrgId());
                break;
            case DropDownBoxConstant.PERSONNEL_BY_ORG:
                user = SessionUtil.getLoginUser(User.class);
                mapList = findAllOrgServiceManger(dropDownBoxDTO.getParamete(), SysDictEnum.IS_VALID.getCode(), user.getDataOrgId());
                break;
            case DropDownBoxConstant.SUBM_RESON_FULL_SCALE_PROCESS_TABLE:
                mapList = currencyDao.findRefuseCodeFull();
                List<Map<String,Object>> list = foreignService.getRepellentCode();
                if (list != null && list.size() > 0){
                    mapList.addAll(list);
                }
                Map<String,Object> map = new HashMap<>(2);
                map.put("id",0);
                map.put("label","FQ001");
                mapList.add(map);
                break;
            case DropDownBoxConstant.SUBM_RESON_COMPREHENSIVE_ALL_QUERY:
                mapList = currencyDao.findRefuseCodeFull();
                List<Map<String,Object>> list1 = foreignService.getRepellentCode();
                if (list1 != null && list1.size() > 0){
                    mapList.addAll(list1);
                }
                Map<String,Object> map1 = new HashMap<>(2);
                map1.put("id",0);
                map1.put("label","FQ001");
                mapList.add(map1);
                break;
            case DropDownBoxConstant.PERSONNEL_ALL:
                mapList = findAllOrgServiceManger(dropDownBoxDTO.getParamete(), SysDictEnum.IS_VALID.getCode(), null);
                break;
            case DropDownBoxConstant.PRODUCT:
                user = SessionUtil.getLoginUser(User.class);
                mapList = this.currencyDao.findAllProductByOrg(user.getOrgId());
                break;
            case DropDownBoxConstant.PRODUCT_ALL:
                mapList = this.currencyDao.findAllProduct();
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.NATION:
                mapList = this.currencyDao.findAllNation();
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.PRODUCT_LIMIT:
                mapList = findProductLimit(SysDictEnum.IS_VALID.getCode(),dropDownBoxDTO.getParamete());
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.PRODUCT_LIMIT_BY_ORG:
                user = SessionUtil.getLoginUser(User.class);
                QueryProductLimitByProductIdAndOrgIdDTO dto = new QueryProductLimitByProductIdAndOrgIdDTO();
                dto.setProductId(dropDownBoxDTO.getParamete());
                dto.setOrgId(user.getOrgId());
                mapList = currencyDao.queryProductLimitByOrg(dto);
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.SUBM_RESON:
                mapList = findRefuseCode(SysDictEnum.YES.getCode(), SysDictEnum.NO.getCode(), dropDownBoxDTO.getParamete());
                break;
            case DropDownBoxConstant.STATE_ALL:
                mapList = findState(null, SysDictEnum.IS_VALID.getCode(), null);
                if (mapList != null &&mapList.size() > 0) {
                    RedisUtil.setex(key, mapList);
                }
                break;
            case DropDownBoxConstant.RISK_SUBMIT_STATE:
                mapList = findRiskSubmitState();
                break;
            case DropDownBoxConstant.HAVE_DONE_APPLY_STATE:
                mapList = findHaveDoneApplyState();
                break;
            case DropDownBoxConstant.VISIT_STATE:
                mapList = findVisitState();
                break;
            case DropDownBoxConstant.CONTRACT_ABOLISH_STATE:
                mapList = findContractAbolishState();
                break;
            case DropDownBoxConstant.COMPREHENSIVE_QUERY:
                mapList = findComprehensiveQuery();
                break;
            case DropDownBoxConstant.FULL_SCALE_PROCESS_TABLE:
                mapList = findFullScaleProcessTable();
                break;
            case DropDownBoxConstant.COMPREHENSIVE_ALL_QUERY:
                mapList = findComprehensiveAllQuery();
                break;
            case DropDownBoxConstant.RECONSIDERATION_QTY:
                mapList = findReconsiderationQty();
                break;
            case DropDownBoxConstant.BANK_CATEGORY:
                mapList = this.currencyDao.findBankCategory();
                 if (mapList != null &&mapList.size() > 0) {
                     RedisUtil.setex(key, mapList);
                 }
                break;
            case DropDownBoxConstant.CONTRACT_AUDIT_STATE:
                mapList = findContractAuditState();
                break;
            case DropDownBoxConstant.CONTRACT_STATE:
                mapList = findContractState();
                break;
            case DropDownBoxConstant.SUBORDINATES:
                mapList = this.currencyDao.findSubordinates(dropDownBoxDTO.getParamete());
                break;
            case DropDownBoxConstant.SUPERIOR:
                mapList = this.currencyDao.findSuperior(dropDownBoxDTO.getParamete());
                break;
            case DropDownBoxConstant.ENQUIRY_BY_INSTITUTION:
                mapList = findAllOrgServiceManger(dropDownBoxDTO.getParamete(), dropDownBoxDTO.getParametes().containsKey("isValid")?(Long) dropDownBoxDTO.getParametes().get("isValid"):null, (Long)dropDownBoxDTO.getParametes().get("orgId"));
                break;
            default:
                mapList = findSysDict(SysDictEnum.valueOf(dropDownBoxDTO.getType()).getParentCode());
                break;
        }
        return mapList;
    }

    /**
     * 获取岗位人员
     * @param postCode 岗位编号
     * @param isValid 是否有效
     * @param orgId 登录人orgID
     */
    private List<Map<String, Object>> findAllOrgServiceManger(Long postCode,Long isValid,Long orgId) {
        Map<String,Object> paraMap = new HashMap<>(3);
        paraMap.put("postCode", postCode);
        paraMap.put("orgId", orgId);
        paraMap.put("isValid",isValid);
        return currencyDao.findAllOrgServiceMangerForUserId(paraMap);
    }

    /**
     * 营业机构
     * @param isValid 是否有效
     * @param orgCode 结构类型
     * @param orgId 登录人营业部ID
     */
    private List<Map<String, Object>> findAllTeamOrg(Long isValid,Long orgCode,Long orgId) {
        Map<String,Object> paraMap = new HashMap<>(3);
        paraMap.put("orgCode", orgCode);
        if (orgId != null) {
            paraMap.put("orgId", orgId);
        }
        paraMap.put("isValid",isValid);
        return currencyDao.findAllTeamOrg(paraMap);
    }

    /**
     * 查询数据字典表中的下拉选项
     */
    private List<Map<String,Object>> findSysDict(Long typeId){
        if (typeId == null){
            return null;
        }
        String key = RedisConstant.DICT+typeId;
        if (RedisUtil.exists(key)){
            return RedisUtil.get(key,List.class);
        }
        Map<String,Object> paraMap = new HashMap<>(2);
        paraMap.put("typeId",typeId);
        paraMap.put("state",SysDictEnum.IS_VALID.getCode());
        List<Map<String,Object>> mapList = currencyDao.findSysDict(paraMap);
        if (mapList != null &&mapList.size() > 0) {
            RedisUtil.setex(key, mapList);
        }
        return mapList;
    }

    /**
     * 查询产品期限
     * @param isValid 是否有效
     */
    private List<Map<String,Object>> findProductLimit(Long isValid,Long productId){
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("isValid",isValid);
        if (productId != null){
            paraMap.put("productId",productId);
        }
        return currencyDao.findProductLimit(paraMap);
    }

    /**
     * 查询拒贷码
     * @param isValid 是否有效
     * @param isPrimary 是否主拒贷码
     * @param refuseNode 拒贷节点
     */
    private List<Map<String,Object>> findRefuseCode(Long isValid,Long isPrimary,Long refuseNode){
        Map<String,Object> paraMap = new HashMap<>(5);
        if (isValid != null) {
            paraMap.put("isValid", isValid);
        }
        if (isPrimary != null) {
            paraMap.put("isPrimary", isPrimary);
        }
        if (refuseNode != null) {
            paraMap.put("refuseNode", refuseNode);
        }
        return currencyDao.findRefuseCode(paraMap);
    }

    /**
     * 查询流程节点
     * @param state 流程节点ID
     * @param isValid 是否有效
     * @param map 条件
     */
    private List<Map<String,Object>> findState(List<Integer> state,Long isValid,Map<String,Object> map){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("isValid",isValid);
        if (state != null && state.size() > 0){
            paraMap.put("state",state);
            mapList = currencyDao.findState(paraMap);
            if (map != null) {
                mapList.add(map);
            }
        }else {
            mapList = currencyDao.findState(paraMap);
        }
        return mapList;
    }


    /**风险提报当前状态*/
    private List<Map<String,Object>> findRiskSubmitState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",111);
        map.put("label","材料补充");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",280);
        map.put("label","确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",131);
        map.put("label","签约前核验");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",240);
        map.put("label","签约前核验审核");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",141);
        map.put("label","合同录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",142);
        map.put("label","合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",143);
        map.put("label","募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",145);
        map.put("label","客户签约");
        mapList.add(map);
        return mapList;
    }
    /**已办申请状态*/
    private List<Map<String,Object>> findHaveDoneApplyState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_SYSTEM_AUDIT);
        map.put("label","系统审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.SYSTEM_REFUSING_LEND);
        map.put("label","系统拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",111);
        map.put("label","材料补充");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_AUDIT);
        map.put("label","审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",121);
        map.put("label","外访中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",280);
        map.put("label","确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",141);
        map.put("label","合同录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",142);
        map.put("label","合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",250);
        map.put("label","复议审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",131);
        map.put("label","签约前核验");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",240);
        map.put("label","签约前核验审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",143);
        map.put("label","募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.AUDIT_SYSTEM_REFUSING_LEND);
        map.put("label","审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",197);
        map.put("label","合同审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",145);
        map.put("label","客户签约");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",119);
        map.put("label","冻结");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",149);
        map.put("label","合同作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",144);
        map.put("label","合同生效");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",196);
        map.put("label","风险提报拒贷");
        mapList.add(map);
        return mapList;
    }
    /**外访状态*/
    private List<Map<String,Object>> findVisitState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_AUDIT);
        map.put("label","审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_CONTRACT);
        map.put("label","合同中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.ABOLISH_CONTRACT);
        map.put("label","合同废除");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",299);
        map.put("label","终审拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",144);
        map.put("label","合同生效");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",145);
        map.put("label","客户签约");
        mapList.add(map);
        return mapList;
    }

    /**合同废除当前状态*/
    private List<Map<String,Object>> findContractAbolishState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",142);
        map.put("label","合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 143);
        map.put("label", "募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",149);
        map.put("label","已废除");
        mapList.add(map);
        return mapList;
    }

    /**区域综合查询状态*/
    private List<Map<String,Object>> findComprehensiveQuery(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",105);
        map.put("label","客服录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.APPLY_FOR_INVALIDATION);
        map.put("label","申请作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_SYSTEM_AUDIT);
        map.put("label","系统审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.SYSTEM_REFUSING_LEND);
        map.put("label","系统拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",111);
        map.put("label","补充材料");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_AUDIT);
        map.put("label","审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",121);
        map.put("label","外访中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",280);
        map.put("label","确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",141);
        map.put("label","合同录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",142);
        map.put("label","合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",250);
        map.put("label","复议审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",131);
        map.put("label","签约前核验");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",240);
        map.put("label","签约前核验审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",143);
        map.put("label","募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.AUDIT_SYSTEM_REFUSING_LEND);
        map.put("label","审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",145);
        map.put("label","客户签约");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",149);
        map.put("label","合同作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
        map.put("label","合同审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",144);
        map.put("label","合同生效");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.CONTRACT_FREEZE);
        map.put("label","冻结");
        mapList.add(map);
        return mapList;
    }
    
    /**综合查询状态*/
    private List<Map<String, Object>> findComprehensiveAllQuery() {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Map<String, Object> map = new HashMap<>(2);
        map.put("id", 105);
        map.put("label", "客服录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 111);
        map.put("label", "补充材料");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 109);
        map.put("label", "申请作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 196);
        map.put("label", "风险提报拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 119);
        map.put("label", "冻结");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 299);
        map.put("label", "终审拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 298);
        map.put("label", "签约前核验拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", NodeStateConstant.IN_AUDIT);
        map.put("label", "审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", NodeStateConstant.IN_SYSTEM_AUDIT);
        map.put("label", "系统审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", NodeStateConstant.SYSTEM_REFUSING_LEND);
        map.put("label", "系统拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 121);
        map.put("label", "外访中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 280);
        map.put("label", "确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 131);
        map.put("label", "签约前核验");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 240);
        map.put("label", "签约前核验审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 250);
        map.put("label", "复议审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 141);
        map.put("label", "合同录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 142);
        map.put("label", "合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
        map.put("label", "合同审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 143);
        map.put("label", "募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 145);
        map.put("label", "客户签约");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 149);
        map.put("label", "合同作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id", 144);
        map.put("label", "合同生效");
        mapList.add(map);
        return mapList;
    }

    /**全量进程表*/
    private List<Map<String,Object>> findFullScaleProcessTable(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",105);
        map.put("label","客服录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.APPLY_FOR_INVALIDATION);
        map.put("label","申请作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_SYSTEM_AUDIT);
        map.put("label","系统审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.SYSTEM_REFUSING_LEND);
        map.put("label","系统拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",111);
        map.put("label","补充材料");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_AUDIT);
        map.put("label","审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.OUTSIDE_VISIT);
        map.put("label","外访中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",280);
        map.put("label","确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",141);
        map.put("label","合同录入中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",142);
        map.put("label","合同审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",250);
        map.put("label","复议审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",131);
        map.put("label","签约前核验");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",240);
        map.put("label","签约前核验审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",143);
        map.put("label","募标中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.AUDIT_SYSTEM_REFUSING_LEND);
        map.put("label","审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",145);
        map.put("label","客户签约");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",149);
        map.put("label","合同作废");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.CONTRACT_REVIEW_TO_LEND);
        map.put("label","合同审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",144);
        map.put("label","合同生效");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.CONTRACT_FREEZE);
        map.put("label","冻结");
        mapList.add(map);
        return mapList;
    }
    /**复议次数*/
    private List<Map<String,Object>> findReconsiderationQty(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",0);
        map.put("label","0次");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",1);
        map.put("label","1次");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",2);
        map.put("label","2次");
        mapList.add(map);
        return mapList;
    }

    /**合同审核当前状态*/
    private List<Map<String,Object>> findContractAuditState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",2486);
        map.put("label","暂存");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",2487);
        map.put("label","未处理");
        mapList.add(map);
        return mapList;
    }

    /**外访已办合同状态*/
    private List<Map<String,Object>> findContractState(){
        List<Map<String,Object>> mapList = new ArrayList<>();
        Map<String,Object> map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_SYSTEM_AUDIT);
        map.put("label","系统审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_AUDIT);
        map.put("label","审核中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",280);
        map.put("label","确认借款");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.IN_CONTRACT);
        map.put("label","合同中");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.CLIENT_CONTRACT);
        map.put("label","客户签约");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.AUDIT_SYSTEM_REFUSING_LEND);
        map.put("label","审核拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.SYSTEM_REFUSING_LEND);
        map.put("label","系统拒贷");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.ABOLISH_CONTRACT);
        map.put("label","合同未通过");
        mapList.add(map);
        map = new HashMap<>(2);
        map.put("id",NodeStateConstant.THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT);
        map.put("label","合同生效");
        mapList.add(map);
        return mapList;
    }
}
