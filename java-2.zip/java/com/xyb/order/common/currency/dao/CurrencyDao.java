package com.xyb.order.common.currency.dao;

import com.xyb.credit.common.model.*;
import com.xyb.order.common.currency.model.AppVersionDO;
import com.xyb.order.common.currency.model.QueryProductLimitByProductIdAndOrgIdDTO;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.common.currency.model.MainLogDTO;
import com.xyb.order.common.currency.model.ProcessLogDO;
import com.xyb.order.pc.task.model.ParameterConfigDO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by xieqingyang on 2018/4/17.
 */
public interface CurrencyDao {

    /**查询流程日志*/
    List<ProcessLogDO> queryProcessLog(Long mainId);

    /**查询下拉框*/
    List<Map<String,Object>> findAllOrgServiceMangerForUserId(Map<String,Object> paraMap);

    /**查询机构*/
    List<Map<String,Object>> findAllTeamOrg(Map<String,Object> paraMap);

    /**根据机构查询团队经理*/
    List<Map<String,Object>> findTeamManagerByOrgId(Map<String,Object> paraMap);

    /**根据机构ID查询下属机构*/
    List<Map<String,Object>> findSubordinates(Long orgId);

    /**查询上级机构*/
    List<Map<String,Object>> findSuperior(Long orgId);

    /**查询省*/
    List<Map<String,Object>> findAllProvince();

    /**查询市*/
    List<Map<String,Object>> findCityByParent(Long parentId);

    /**查询区县*/
    List<Map<String,Object>> findAreaByParent(Long parentId);

    /**查询营业部产品*/
    List<Map<String,Object>> findAllProductByOrg(Long orgId);

    /**查询所有产品*/
    List<Map<String,Object>> findAllProduct();

    /**查询民族*/
    List<Map<String,Object>> findAllNation();

    /**查询字典*/
    List<Map<String,Object>> findSysDict(Map<String,Object> paraMap);

    /**查询产品期限*/
    List<Map<String,Object>> findProductLimit(Map<String,Object> paraMap);

    /**查询拒贷码*/
    List<Map<String,Object>> findRefuseCode(Map<String,Object> paraMap);

    /**全量进程表主拒贷码*/
    List<Map<String,Object>> findRefuseCodeFull();

    /**综合查询主拒贷码*/
    List<Map<String,Object>> findRefuseCodeComprehensive();

    /**查询流程节点*/
    List<Map<String,Object>> findState(Map<String,Object> paraMap);

    /**银行类别*/
    List<Map<String,Object>> findBankCategory();

    /**根据营业部和产品查询产品期限*/
    List<Map<String, Object>> queryProductLimitByOrg(QueryProductLimitByProductIdAndOrgIdDTO dto);

    /**添加主表日志（单个）*/
    int insertMainLog(Map<String,Object> paraMap);

    /**添加主表日志（批量）*/
    int insertMainLogList(Map<String,Object> paraMap);

    /**批量修改main表状态*/
    int updateMainInfo(Map<String,Object> paraMap);
    
    /**批量修改main表合同相关字段*/
    int updateContractUidOrContractReviewId(Map<String,Object> paraMap);

    /**查询通用配置通过parametercode*/
    ParameterConfigDO getParameter(String parameterCode);

    /**添加主表日志*/
    int addMainLog(MainLogDTO mainLogDTO);

    /**修改主表（main）*/
    int updateMainInFo(ApplyBillMainInfoDO applyBillMainInfoDO);

    /**查询app版本*/
    AppVersionDO getAppVersion(AppVersionDO appVersionDO);

    /**风控获取系统审核信息*/
    IndatainfoBeanDTO getApplyInfo(@Param("applyMainId") Long applyMainId);
    XybProductExtDTO getProductExt(@Param("applyMainId") Long applyMainId);
    ClientInfoBeanDTO getClientInfo(@Param("clientId") Long clientId);
    JobInfoBeanDTO getJobInfo(@Param("applyId") Long applyId);
    List<LinkmanInfoBeanDTO> getLinkManInfoList(@Param("applyId") Long applyId);
    PersonalInfoBeanDTO getPersonalInfo(@Param("applyId") Long applyId);
    ThirdParam getThirdParam(@Param("applyId") Long applyId);

    /**
     * 获取mq消息消费数据
     *
     * @param map
     * @return
     */
    Integer getMessageConsumeLog(Map<String, Object> map);

    /**
     * 添加mq消息消费
     *
     * @param map
     */
    void addMessageConsumeLog(Map<String, Object> map);

    /**
     * 接口日志添加
     *
     * @param cheatInterfaceLogDO
     */
    void addCheatInterfaceLog(CheatInterfaceLogDO cheatInterfaceLogDO);

    /**
     * 获得风险提报数据
     * @author      xieqingyang
     * @date        2018/10/12 3:08 PM
     * @version     1.0
     * @param mainId 主表ID
     * @return 返回查询数据
     */
    Map<String,Object> getFxtbJson(Long mainId);

    /**
     * 获得风险提报数据
     * @author      xieqingyang
     * @date        2018/10/12 3:08 PM
     * @version     1.0
     * @param mainId 主表ID
     * @return 返回查询数据
     */
    Map<String,Object> getFXTBDTO(Long mainId);

    /**
     * @description 根据省份名称查询ID
     * @author      xieqingyang
     * @CreatedDate 2018/7/11 下午3:59
     * @Version     1.0
     * @param province 省份
     * @return 返回省份ID
     */
    Long getProvinceCodeByName(String province);

    /**
     * @description 根据市名称查询ID
     * @author      xieqingyang
     * @CreatedDate 2018/7/11 下午3:59
     * @Version     1.0
     * @param paraMap 市
     * @return 返回省份ID
     */
    Long getCityCodeByName(Map<String,Object> paraMap);

    /**
     * @description 根据区县名称查询ID
     * @author      xieqingyang
     * @CreatedDate 2018/7/11 下午3:59
     * @Version     1.0
     * @param paraMap 区县
     * @return 返回省份ID
     */
    Long getAreaCodeByName(Map<String,Object> paraMap);
}
