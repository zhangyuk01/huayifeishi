package com.xyb.order.common.currency.dao;

import com.xyb.order.common.currency.model.AuditCodeInfo;
import com.xyb.order.common.currency.model.ParameterDO;

/**
 * @author : jiangzhongyan
 * @projectName : credit
 * @package : com.xyb.credit.common.dao
 * @description : 信审系统通用功能DAO
 * @createDate : 2017/11/29 15:13
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface SystemDao {

 
    /**
     * 根据parameterCode获取数据参数
     *
     * @param parameterCode
     * @return
     */
    ParameterDO getParameter(String parameterCode);
    /**
     * 根据拒代码查询拒代码配置信息
     * @param refuseCode
     * @return
     */
    AuditCodeInfo getAuditCodeInfo(String refuseCode);
    
    

}
