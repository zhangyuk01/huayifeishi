package com.xyb.order.common.currency.dao;

import java.util.Map;

public interface AuditCheckItemDao {

    int getCheckItemCount(Map<String,Object> paraMap);

    int insertAuditCheckItem(Map<String,Object> paraMap);
}
