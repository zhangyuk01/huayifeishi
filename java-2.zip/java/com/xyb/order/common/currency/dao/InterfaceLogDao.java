package com.xyb.order.common.currency.dao;

import com.xyb.order.pc.contract.model.InterfaceLogDO;

/**
 * @author : jiangzhongyan
 * @projectName : finance-api
 * @package : com.xyb.common.dao
 * @description : 接口日志记录管理
 * @createDate : 2017/12/12 14:33
 * @modificationHistory Who        When      What
 * --------- ---------     ---------------------------
 */
public interface InterfaceLogDao {

    /**
     * 添加接口日志数据
     *
     * @param interfaceLogDO
     */
    void addInterfaceLog(InterfaceLogDO interfaceLogDO);

}
