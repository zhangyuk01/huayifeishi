package com.xyb.order.common.currency.dao;

/**
 * @ClassName ApplyCommonProvinceDao
 * @author ZhangYu
 * @date 2018年7月17号
 */
public interface ApplyCommonProvinceDao {

	/**
	 * 根据省ID查询省名称 
	 * @param provinceId
	 * @return
	 */
	String getProvinceLabelByProvinceId(Long provinceId);

	/**
	 *根据市ID查询市名称 
	 * @param cityId
	 * @return
	 */
	String getCityLabelByCityId(Long cityId);

	/**
	 *根据区ID查询区名称 
	 * @param areaId
	 * @return
	 */
	String getAreaLabelByAreaId(Long areaId);


}
