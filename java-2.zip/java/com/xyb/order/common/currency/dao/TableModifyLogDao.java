package com.xyb.order.common.currency.dao;

import com.xyb.order.common.currency.model.TableModifyLogDTO;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * Created by xieqingyang on 2018/4/2.
 */
public interface TableModifyLogDao {

    int insertTableModirfyLog(@Param("modifyLogDTOS") List<TableModifyLogDTO> modifyLogDTOS);

}
