package com.xyb.order.common.depositbank.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.app.client.cuser.service.ClinetUserModifyService;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.agreement.model.DepositBankResultDTO;
import com.xyb.order.common.agreement.model.ResultDTO;
import com.xyb.order.common.agreement.model.SignedEntryDTO;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.bank.model.ClientBankLogDO;
import com.xyb.order.common.bank.model.XybContractUpdateDTO;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.DepositBankConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.constant.SysConstants;
import com.xyb.order.common.depositbank.dao.DepositBankDao;
import com.xyb.order.common.depositbank.model.*;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.HttpTools;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.common.util.SignMatchesUtil;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.util.SessionUtil;
import com.xyb.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 存管功能接口实现类
 *
 * @author xieqingyang
 * @date 2018/11/22 6:29 PM
 */
@Service(interfaceName = "com.xyb.order.common.depositbank.service.DepositBankService")
public class DepositBankServiceImpl implements DepositBankService {

	private static final Logger logger = LoggerFactory.getLogger(DepositBankServiceImpl.class);

	@Autowired
	private DepositBankDao depositBankDao;
	@Autowired
	private ClientRedisUtil clientRedisUtil;
	@Autowired
	private BankDao bankDao;
	@Autowired
	private XybContractDao xybContractDao;
	@Autowired
	private ClinetUserDao clinetUserDao;
	@Autowired
	private DepositBankService depositBankService;
	@Autowired
	private ClinetUserModifyService clinetUserModifyService;

	/**
	 * 接口签名密钥(深圳)
	 */
	@Value("${sys.id}")
	private String sysId;

	/**
	 * 接口签名密钥(深圳)
	 */
	@Value("${http.secret.key}")
	private String secretKey;

	/**
	 * 银行存管接口(存管新开户)地址(深圳)
	 */
	@Value("${account.open}")
	private String accountOpen;

	/**
	 * 绑卡网关接口地址(深圳)
	 */
	@Value("${account.bindBankCard}")
	private String accountBindBankCard;

	/**
	 * 解绑银行卡接口地址(深圳)
	 */
	@Value("${account.unBindBankCard}")
	private String accountUNBindBankCard;

	/**
	 * 重置电子账户交易密码接口地址(深圳)
	 */
	@Value("${account.repwd}")
	private String accountRepwd;

	/**
	 * 查询存管是否已经开户
	 */
	@Value("${account.findAccIdQuery}")
	private String accountFindAccIdQuery;

	/**
	 * 成功跳转地址
	 */
	@Value("${success.jump.url}")
	private String successJumpUrl;

	/**
	 * 借款人放款手续费和还款金额签约
	 */
	@Value("${account.signContract}")
	private String accountSignContract;

	/**
	 * 失败跳转地址
	 */
	@Value("${fail.jump.url}")
	private String failJumpUrl;

	@Override
	public RestResponse accountOpen(ClientInfoDTO clientInfoDTO) throws Exception {
		RestResponse response;
		User user = SessionUtil.getLoginUser(User.class);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (clientAuthenticationDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(clientAuthenticationDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		// -- 去深圳查询是否有有效的存管户
		boolean isOpenAccount = depositBankService.accountFindAccIdQuery(user.getId(),clientAuthenticationDO.getId(),clientAuthenticationDO.getIdCard(),clientInfoDTO.getClient(),null,clientInfoDTO.getClient_ip(),clientInfoDTO.getClient_service());
		// -- 已经有存管户信息
		if (isOpenAccount){
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setResult(2);
			response.setDescription("存管账户已开通，请绑卡!");
			return response;
		}
		// -- 存管开户信息model
		AccountOpenRequestDTO accountOpenRequestDTO = new AccountOpenRequestDTO();
		accountOpenRequestDTO.setSysId(Long.valueOf(sysId));
		accountOpenRequestDTO.setAccount_type(DepositBankConstant.ACCOUNT_TYPE_200201);
		accountOpenRequestDTO.setRole_type(DepositBankConstant.ROLE_TYPE_2);
		accountOpenRequestDTO.setSuccess_url(successJumpUrl);
		accountOpenRequestDTO.setFail_url(failJumpUrl);
		accountOpenRequestDTO.setMobile(user.getLoginId());
		accountOpenRequestDTO.setIdCard(clientAuthenticationDO.getIdCard());
		accountOpenRequestDTO.setIdCardType(DepositBankConstant.IDCARD_TYPE_15);
		accountOpenRequestDTO.setClient(clientInfoDTO.getClient());
		accountOpenRequestDTO.setClient_ip(clientInfoDTO.getClient_ip());
		accountOpenRequestDTO.setClient_service(clientInfoDTO.getClient_service());
		SignedEntryDTO signedEntry = new SignedEntryDTO();
		signedEntry.setBody(accountOpenRequestDTO);
		// -- 进行指定字段加签
		String sign = SignMatchesUtil.signEncode(signedEntry, secretKey);
		signedEntry.setSign(sign);
		// -- 推送深圳
		String dataJson = JsonUtils.toJSON(signedEntry);
		String result = null;
		try {
			result = HttpTools.sendPost(accountOpen, dataJson, "utf-8");
		} catch (Exception e) {
			logger.error("存管开户接口异常:" + e);
		}
		// -- 添加日志
		depositBankService.addLog(null, "存管开户接口(accountOpen)", dataJson, result, user.getId());
		ResultDTO<AccountOpenResponseDTO> resultDTO = (ResultDTO<AccountOpenResponseDTO>) JSON.parseObject(result,new TypeReference<ResultDTO<AccountOpenResponseDTO>>() {});
		// -- 验签
		if (resultDTO.getBody() == null) {
			return new RestResponse(MsgErrCode.FAIL);
		}
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		// -- 验签成功，并且接口调用成功
		if (boo && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setData(resultDTO.getBody().getUrl());
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return response;
	}

	@Override
	public RestResponse accountReqwd(ClientInfoDTO clientInfoDTO) throws Exception {
		RestResponse response;
		User user = SessionUtil.getLoginUser(User.class);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (clientAuthenticationDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(clientAuthenticationDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		// -- 查询存管账户信息
		Map<String, Object> queryMap = new HashMap<>(1);
		queryMap.put("clientId", clientAuthenticationDO.getId());
		AccountInterfaceDTO accountInterface = depositBankDao.queryAccountInterfaceInfo(queryMap);
		if (accountInterface == null) {
			return new RestResponse(MsgErrCode.FAIL);
		}
		AccountRepwdRequestDTO accountRepwdRequestDTO = new AccountRepwdRequestDTO();
		accountRepwdRequestDTO.setSysId(Long.valueOf(sysId));
		accountRepwdRequestDTO.setCard_no(accountInterface.getCardNo());
		accountRepwdRequestDTO.setCustomer_no(accountInterface.getCustomerNo());
		accountRepwdRequestDTO.setSuccess_url(successJumpUrl);
		accountRepwdRequestDTO.setFail_url(failJumpUrl);
		accountRepwdRequestDTO.setClient(clientInfoDTO.getClient());
		accountRepwdRequestDTO.setClient_ip(clientInfoDTO.getClient_ip());
		accountRepwdRequestDTO.setClient_service(clientInfoDTO.getClient_service());
		SignedEntryDTO signedEntry = new SignedEntryDTO();
		signedEntry.setBody(accountRepwdRequestDTO);
		// -- 进行指定字段加签
		String sign = SignMatchesUtil.signEncode(signedEntry, secretKey);
		signedEntry.setSign(sign);
		// -- 推送深圳
		String dataJson = JsonUtils.toJSON(signedEntry);
		String result = null;
		try {
			result = HttpTools.sendPost(accountRepwd, dataJson, "utf-8");
		} catch (Exception e) {
			logger.error("重置电子账户交易密码接口异常:" + e);
		}
		// -- 添加日志
		depositBankService.addLog(null, "重置电子账户交易密码接口(accountReqwd)", dataJson, result, user.getId());
		ResultDTO<AccountRepwdResponseDTO> resultDTO = (ResultDTO<AccountRepwdResponseDTO>) JSON.parseObject(result,new TypeReference<ResultDTO<AccountRepwdResponseDTO>>() {});
		// -- 验签
		if (resultDTO.getBody() == null) {
			return new RestResponse(MsgErrCode.FAIL);
		}
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		// -- 验签成功，并且接口调用成功
		if (boo && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setData(resultDTO.getBody().getUrl());
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return response;
	}

	@Override
	public RestResponse unBindBankCardSubmit(ClientInfoDTO info) throws Exception {
		RestResponse response;
		User user = SessionUtil.getLoginUser(User.class);
		UnBindBankCardRequestBodyDTO body = new UnBindBankCardRequestBodyDTO();
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (clientAuthenticationDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(clientAuthenticationDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		Map<String, Object> queryMap = new HashMap<>(1);
		queryMap.put("clientId", clientAuthenticationDO.getId());
		AccountInterfaceDTO accountInterface = depositBankDao.queryAccountInterfaceInfo(queryMap);
		if (info != null && accountInterface != null) {

			body.setSysId(sysId);
			body.setClient(info.getClient());
			body.setClient_ip(info.getClient_ip());
			body.setClient_service(info.getClient_service());

			body.setCard_no(accountInterface.getCardNo());
			body.setBank_card_no(accountInterface.getBankNum());
			body.setCustomer_no(accountInterface.getCustomerNo());
			body.setSerial_no(accountInterface.getSerialNo());
			body.setSuccess_url(successJumpUrl);
			body.setFail_url(failJumpUrl);

			/*
			 * body.setCard_no("8666882002072706051");
			 * body.setCustomer_no("12000635285");
			 * body.setBank_card_no("6217856300021991594");
			 * body.setSerial_no("8D94C5DACDE64BF3B54618FC2AECC100");
			 */

			SignedEntryDTO signedEntryDTO = new SignedEntryDTO();
			signedEntryDTO.setBody(body);

			// -- 进行指定字段加签
			String sign = SignMatchesUtil.signEncode(signedEntryDTO, secretKey);
			signedEntryDTO.setSign(sign);

			String dataJson = JsonUtils.toJSON(signedEntryDTO);
			logger.info("解绑银行卡接口开始,card_no:" + body.getCard_no() + ";请求参数：" + dataJson);
			String result = HttpTools.sendPost(accountUNBindBankCard, dataJson, "utf-8");
			logger.info("解绑银行卡接口结束,card_no:" + body.getCard_no() + ";返回参数：" + result);

			// -- 添加日志
			depositBankService.addLog(null, "解绑银行卡接口结束(unBindBankCardSubmit)", dataJson, result, user.getId());
			ResultDTO<UnBindBankCardResponseBodyDTO> resultDTO = (ResultDTO<UnBindBankCardResponseBodyDTO>) JSON.parseObject(result, new TypeReference<ResultDTO<UnBindBankCardResponseBodyDTO>>() {});
			// -- 验签
			if (resultDTO.getBody() == null) {
				return new RestResponse(MsgErrCode.FAIL);
			}
			boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
			// -- 验签成功，并且接口调用成功
			if (boo && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
				response = new RestResponse(MsgErrCode.SUCCESS);
				response.setData(resultDTO.getBody().getUrl());
			} else {
				response = new RestResponse(MsgErrCode.FAIL);
			}
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse unBindNotice(ResultDTO<UnbindNoticeDTO> resultDTO) {
		logger.info("=============[解绑卡通知]===================" + resultDTO.toString());
		try {
			UnbindNoticeDTO unbindNoticeDTO = resultDTO.getBody();
			boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
			if (!boo) {
				return unBindNoticeResult(JSON.toJSONString(unbindNoticeDTO), "验签失败", null,
						SysConstants.INTERFACE_FAIL);
			}
			// 解绑成功
			if (unbindNoticeDTO.getSign_flag().equals("1")) {
				// 获取存管用户信息
				DepositAccountStatementInfoDO infoDo = new DepositAccountStatementInfoDO();
				infoDo.setCardNo(unbindNoticeDTO.getCard_no());
				infoDo.setCustomerNo(unbindNoticeDTO.getCustomer_no());
				infoDo.setIsValid(SysDictEnum.YES.getCode());
				List<DepositAccountStatementInfoDO> infos = depositBankDao.getDepositAccountStatementInfo(infoDo);
				if (infos.size() > 0) {
					// 银行卡置为无效
					logger.info("=============[解绑卡通知]获取到存管账户信息\r" + resultDTO.toString());
					DepositAccountStatementInfoDO depositAccountStatementInfoDO = infos.get(0);
					Long clientId = depositAccountStatementInfoDO.getClientId();
					ClientBankInfoNoDO clientBankInfoNoDO = new ClientBankInfoNoDO();
					if (null != clientId && null != depositAccountStatementInfoDO.getClientBankId()) {
						clientBankInfoNoDO.setId(depositAccountStatementInfoDO.getClientBankId());
						clientBankInfoNoDO.setState(2487L);
						clientBankInfoNoDO.setIsState(1);
						bankDao.updateClientBankInFoNo(clientBankInfoNoDO);
						// 解除存管关系
						DepositAccountStatementInfoDO param = new DepositAccountStatementInfoDO();
						param.setClientId(clientId);
						param.setClientBankId(null);
						depositBankDao.updateDepositAccountStatementInfoById(param);
						// 更新合同表信息（已生效未结清）
						XybContractUpdateDTO xybContractUpdateDTO = new XybContractUpdateDTO();
						xybContractUpdateDTO.setClientId(clientId);
						xybContractDao.updateContractBankInfo(xybContractUpdateDTO);
						// 更新银行卡操作记录
						ClientBankLogDO clientBankLogDO = new ClientBankLogDO();
						clientBankLogDO.setBusinessType(3108L);
						clientBankLogDO.setClientId(clientId);
						clientBankLogDO.setCreateTime(new Date());
						bankDao.addClinetBankLog(clientBankLogDO);
						// 删除用户卡信息
						updateBankStateInRedis(clientBankLogDO.getClientId());
						return unBindNoticeResult(JSON.toJSONString(resultDTO), "请求成功", null,
								SysConstants.INTERFACE_SUCCESS);
					} else {
						logger.info("=============[解绑卡通知]系统获取到数据缺少<clientId>或<clientBandId>\r"+ depositAccountStatementInfoDO.toString());
						return unBindNoticeResult(JSON.toJSONString(resultDTO), "存管账户信息不完整", null,SysConstants.INTERFACE_FAIL);
					}

				} else {
					return unBindNoticeResult(JSON.toJSONString(resultDTO), "无此卡信息", null, SysConstants.INTERFACE_FAIL);
				}
			}
		} catch (Exception e) {
			logger.info("=============[解绑卡通知异常]===================" + e);
			logger.error("=============[解绑卡通知异常]===================", e);
			return unBindNoticeResult(JSON.toJSONString(resultDTO), "解绑通知异常", null, SysConstants.INTERFACE_FAIL);
		}
		return unBindNoticeResult(JSON.toJSONString(resultDTO), "请求失败", null, SysConstants.INTERFACE_FAIL);
	}

	private RestResponse unBindNoticeResult(String jsonStr, String message, Long cardNo, String code) {
		DepositAccountInterfaceLogDO logDO = new DepositAccountInterfaceLogDO();
		logDO.setCreateTime(new Date());
		logDO.setInterfaceName("解绑通知");
		logDO.setRequestMsg(jsonStr);
		logDO.setDepositAccountId(cardNo);
		DepositBankResultDTO result = new DepositBankResultDTO();
		result.setCode(code);
		result.setMessage(message);
		String signEncode = SignMatchesUtil.signEncode(result, secretKey);
		result.setSign(signEncode);
		// 保存日志
		logDO.setResponseMsg(JSON.toJSONString(result));
		depositBankDao.insertDepositAccountInterfaceLog(logDO);
		return new RestResponse(MsgErrCode.SUCCESS, result);
	}

	@Override
	public RestResponse loanSignContract(ClientInfoDTO clientInfoDTO) throws Exception {
		RestResponse response;
		User user = SessionUtil.getLoginUser(User.class);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(clientAuthenticationDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (clientAuthenticationDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(clientAuthenticationDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		// -- 查询存管账户信息
		Map<String, Object> queryMap = new HashMap<>(1);
		queryMap.put("clientId", clientAuthenticationDO.getId());
		AccountInterfaceDTO accountInterface = depositBankDao.queryAccountInterfaceInfo(queryMap);
		if (accountInterface == null) {
			return new RestResponse(MsgErrCode.FAIL);
		}
		LoanSignContractRequestDTO loanSignContractRequestDTO = new LoanSignContractRequestDTO();
		loanSignContractRequestDTO.setSysId(Long.valueOf(sysId));
		loanSignContractRequestDTO.setClient(clientInfoDTO.getClient());
		loanSignContractRequestDTO.setClient_ip(clientInfoDTO.getClient_ip());
		loanSignContractRequestDTO.setClient_service(clientInfoDTO.getClient_service());
		loanSignContractRequestDTO.setAcctId(accountInterface.getAccId());
		loanSignContractRequestDTO.setSuccess_url(successJumpUrl);
		loanSignContractRequestDTO.setFail_url(failJumpUrl);
		SignedEntryDTO signedEntry = new SignedEntryDTO();
		signedEntry.setBody(loanSignContractRequestDTO);
		// -- 进行指定字段加签
		String sign = SignMatchesUtil.signEncode(signedEntry, secretKey);
		signedEntry.setSign(sign);
		// -- 推送深圳
		String dataJson = JsonUtils.toJSON(signedEntry);
		String result = null;
		try {
			result = HttpTools.sendPost(accountSignContract, dataJson, "utf-8");
		} catch (Exception e) {
			logger.error("借款人放款手续费和还款金额签约接口异常:" + e);
		}
		// -- 添加日志
		depositBankService.addLog(null, "借款人放款手续费和还款金额签约(loanSignContract)", dataJson, result, user.getId());
		ResultDTO<LoanSignContractResponseDTO> resultDTO = (ResultDTO<LoanSignContractResponseDTO>) JSON.parseObject(result, new TypeReference<ResultDTO<LoanSignContractResponseDTO>>() {});
		// -- 验签
		if (resultDTO.getBody() == null) {
			return new RestResponse(MsgErrCode.FAIL);
		}
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		// -- 验签成功，并且接口调用成功
		if (boo && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
			response = new RestResponse(MsgErrCode.SUCCESS);
			response.setData(resultDTO.getBody().getUrl());
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
		}
		return response;
	}

	/**
	 * 保存存管接口调用日志并组合返回数据
	 *
	 * @param logDO
	 *            存管日志实体
	 * @param message
	 *            返回深圳信息
	 * @param code
	 *            返回深圳接口码
	 * @return 返回给存管调用方数据接收结果
	 * @author qiaojinlong
	 * @date 2018/11/26 11:41 AM
	 * @version 1.0
	 */
	private DepositBankResultDTO unBindNoticeResult(DepositAccountInterfaceLogDO logDO, String message, String code) {
		DepositBankResultDTO result = new DepositBankResultDTO();
		result.setCode(code);
		result.setMessage(message);
		String signEncode = SignMatchesUtil.signEncode(result, secretKey);
		result.setSign(signEncode);
		// 保存日志
		logDO.setResponseMsg(JSON.toJSONString(result));
		depositBankDao.insertDepositAccountInterfaceLog(logDO);
		return result;
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
	public void addLog(Long depositAccountId, String interfaceName, String requestMsg, String responseMsg,
			Long createUser) {
		DepositAccountInterfaceLogDO logDO = new DepositAccountInterfaceLogDO();
		if (depositAccountId != null) {
			logDO.setDepositAccountId(depositAccountId);
		}
		if (interfaceName != null) {
			logDO.setInterfaceName(interfaceName);
		}
		if (requestMsg != null) {
			logDO.setRequestMsg(requestMsg);
		}
		if (responseMsg != null) {
			logDO.setResponseMsg(responseMsg);
		}
		if (createUser != null) {
			logDO.setCreateUser(createUser);
		}
		depositBankDao.insertDepositAccountInterfaceLog(logDO);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse bindBankCard(ClientInfoDTO clientInfoDTO) throws Exception {
		RestResponse response = new RestResponse(MsgErrCode.FAIL);
		Map<String, Object> paraMap = new HashMap<>(2);
		String responseResult = null;
		User user = SessionUtil.getLoginUser(User.class);
		ClientAuthenticationDO clientAuthenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());

		DepositAccountStatementInfoDO depositInfo = new DepositAccountStatementInfoDO();
		depositInfo.setClientId(clientAuthenticationDO.getId());
		depositInfo.setIsValid(SysDictEnum.YES.getCode());
		List<DepositAccountStatementInfoDO> depositList = depositBankDao.getDepositAccountStatementInfo(depositInfo);
		if (depositList != null && depositList.size() > 0 && depositList.size() == 1) {
			BindBankCardRequestDTO bindBankCardDTO = new BindBankCardRequestDTO();
			bindBankCardDTO.setSysId(Long.valueOf(sysId));
			bindBankCardDTO.setCard_type(DepositBankConstant.CARD_TYPE_0);
			bindBankCardDTO.setCard_no(depositList.get(0).getCardNo());
			bindBankCardDTO.setFail_url(failJumpUrl);
			bindBankCardDTO.setSuccess_url(successJumpUrl);
			bindBankCardDTO.setClient(clientInfoDTO.getClient());
			bindBankCardDTO.setCustom("");
			bindBankCardDTO.setClient_ip(clientInfoDTO.getClient_ip());
			bindBankCardDTO.setClient_service(clientInfoDTO.getClient_service());
			// 签名
			String sign = SignMatchesUtil.signEncode(bindBankCardDTO, secretKey);
			SignedEntryDTO signedEntryDTO = new SignedEntryDTO();
			signedEntryDTO.setBody(bindBankCardDTO);
			signedEntryDTO.setSign(sign);
			signedEntryDTO.setSn("");
			String requestJson = JsonUtils.toJSON(signedEntryDTO);
			// 推送深圳
			try {
				responseResult = HttpTools.sendPost(accountBindBankCard, requestJson, "UTF-8");
			} catch (Exception e) {
				logger.error("存管绑卡接口异常:" + e);
			}
			// 添加日志
			depositBankService.addLog(null, "存管绑卡接口(bindBankCard)", requestJson, responseResult, user.getId());
			ResultDTO<BindBankCardResponseDTO> resultDTO = (ResultDTO<BindBankCardResponseDTO>) JSON.parseObject(responseResult, new TypeReference<ResultDTO<BindBankCardResponseDTO>>() {});
			// 验证签名
			if (resultDTO.getBody() == null) {
				return new RestResponse(MsgErrCode.FAIL);
			}
			Boolean flag = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
			// 验签成功，并且接口调用成功
			if (flag && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
				response = new RestResponse(MsgErrCode.SUCCESS);
				response.setData(resultDTO.getBody().getUrl());
			} else {
				response = new RestResponse(MsgErrCode.FAIL);
			}
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("存管信息有误或不存在");
		}
		return response;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse depositAccountToNotice(ResultDTO<DepositAccountToNoticeDTO> resultDTO) {
		DepositBankResultDTO depositBankResultDTO = new DepositBankResultDTO();
		DepositAccountToNoticeDTO depositAccountToNoticeDTO = resultDTO.getBody();
		// 添加日志
		depositBankService.addLog(null, "个人绑卡注册通知(depositAccountToNotice)", JsonUtils.toJSON(resultDTO), null, null);
		// 验签
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		if (boo) {
			// 获取cleintId
			Long clientId = depositBankDao.getClientIdByCertNo(depositAccountToNoticeDTO.getCert_no());

			boolean flag = false;
			// -- 判断是否需要修改个人信息（身份证号，姓名）如果有不同则修改信息
			if (clientId != null) {
				Map<String, Object> paraMap = new HashMap<>(1);
				paraMap.put("id", clientId);
				// -- 查询用户信息数据
				ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
				flag = (applyClientInfoDO.getIdcard().equals(depositAccountToNoticeDTO.getCert_no()) && applyClientInfoDO.getName().equals(depositAccountToNoticeDTO.getName()));
				if (!flag) {
					// -- 修改用户不可进件时间200年
					clinetUserModifyService.updateClientAllowableEntryTime(clientId, 73000);
				}
			}

			// 初始化 客户银行卡列表(非存管) t_client_bank_info_no
			long clientBankInfoId = this.initializeClientBankInfo(depositAccountToNoticeDTO, clientId, flag);

			// 初始化 存管账户表 t_deposit_account_statement_info
			this.initializeDepositAccountStatementInfo(depositAccountToNoticeDTO, clientId, clientBankInfoId, flag);

			// 清除用户绑卡状态信息
			this.updateBankStateInRedis(clientId);

			depositBankResultDTO.setCode("000");
			depositBankResultDTO.setMessage("请求成功!");
		} else {
			depositBankResultDTO.setCode("999");
			depositBankResultDTO.setMessage("非法接口调用!");
		}
		String sign = SignMatchesUtil.signEncode(depositBankResultDTO, secretKey);
		depositBankResultDTO.setSign(sign);
		return new RestResponse(MsgErrCode.SUCCESS, depositBankResultDTO);
	}

	@Override
	public RestResponse signingNotification(ResultDTO<SigningNotificationDTO> resultDTO) {
		DepositBankResultDTO depositBankResultDTO = new DepositBankResultDTO();
		SigningNotificationDTO signingNotificationDTO = resultDTO.getBody();

		// 添加日志
		depositBankService.addLog(null, "异步通知签约结果(signingNotification)", JsonUtils.toJSON(resultDTO), null, null);
		// 验签
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		if (boo) {
			DepositAccountStatementInfoDO depositAccountStatementInfoDO = new DepositAccountStatementInfoDO();
			if (DepositBankConstant.SIGN_FLAG_HAVING.equals(signingNotificationDTO.getSign_flag())) {
				depositAccountStatementInfoDO.setIsSign(SysDictEnum.YES.getCode());
			} else {
				depositAccountStatementInfoDO.setIsSign(SysDictEnum.NO.getCode());
			}
			depositAccountStatementInfoDO.setCardNo(signingNotificationDTO.getCard_no());
			depositBankDao.updateDepositAccountStatementInfoSignState(depositAccountStatementInfoDO);
			depositBankResultDTO.setCode("000");
			depositBankResultDTO.setMessage("请求成功!");
		} else {
			depositBankResultDTO.setCode("999");
			depositBankResultDTO.setMessage("非法接口调用!");
		}
		String sign = SignMatchesUtil.signEncode(depositBankResultDTO, secretKey);
		depositBankResultDTO.setSign(sign);
		return new RestResponse(MsgErrCode.SUCCESS, depositBankResultDTO);
	}

	/**
	 * 初始化 存管账户表
	 *
	 * @param depositAccountToNoticeDTO 通知数据
	 * @param clientId 客户信息表主键ID
	 * @param clientBankInfoId 银行卡表主键ID
	 * @param flag 响应身份认证数据是否和用户身份数据一致
	 * @return 返回存管账户表主键ID
	 * @author jiangzhongyan
	 * @date 2018/11/26 4:53 PM
	 * @version 1.0
	 */
	private Long initializeDepositAccountStatementInfo(DepositAccountToNoticeDTO depositAccountToNoticeDTO, Long clientId, Long clientBankInfoId, boolean flag) {
		// -- 查询是否已经存在有效存管账户
		DepositAccountStatementInfoDO depositAccountStatementInfoDO = new DepositAccountStatementInfoDO();
		depositAccountStatementInfoDO.setClientId(clientId);
		depositAccountStatementInfoDO.setIsValid(SysDictEnum.YES.getCode());
		List<DepositAccountStatementInfoDO> depositAccountStatementInfoDOList = depositBankDao.getDepositAccountStatementInfo(depositAccountStatementInfoDO);
		depositAccountStatementInfoDO.setAccId(Long.valueOf(depositAccountToNoticeDTO.getAcctId()));
		depositAccountStatementInfoDO.setClientId(clientId);
		depositAccountStatementInfoDO.setClientBankId(clientBankInfoId);
		if (flag) {
			depositAccountStatementInfoDO.setIsValid(SysDictEnum.YES.getCode());
		} else {
			depositAccountStatementInfoDO.setIsValid(SysDictEnum.NO.getCode());
		}
		depositAccountStatementInfoDO.setOpenPlatform(SysDictEnum.LOAN_CHANNEL_SHENZHEN.getCode());
		depositAccountStatementInfoDO.setCardNo(depositAccountToNoticeDTO.getCard_no());
		depositAccountStatementInfoDO.setCustomerNo(depositAccountToNoticeDTO.getCustomer_no());
		depositAccountStatementInfoDO.setSerialNo(depositAccountToNoticeDTO.getSerial_no());
		if (depositAccountStatementInfoDOList != null && depositAccountStatementInfoDOList.size() > 0) {
			depositAccountStatementInfoDO.setId(depositAccountStatementInfoDOList.get(0).getId());
			depositBankDao.updateDepositAccountStatementInfo(depositAccountStatementInfoDO);
		}else {
			depositBankDao.insertDepositAccountStatementInfo(depositAccountStatementInfoDO);
		}
		return depositAccountStatementInfoDO.getId();
	}

	/**
	 * 初始化 客户银行卡列表
	 *
	 * @param depositAccountToNoticeDTO
	 *            通知数据
	 * @param clientId
	 *            客户信息表主键ID
	 * @param flag
	 *            响应身份认证数据是否和用户身份数据一致
	 * @return 返回银行卡表主键ID
	 * @author jiangzhongyan
	 * @date 2018/11/26 4:50 PM
	 * @version 1.0
	 */
	private Long initializeClientBankInfo(DepositAccountToNoticeDTO depositAccountToNoticeDTO, Long clientId, boolean flag) {
		int bankType = depositBankDao.getBankType(depositAccountToNoticeDTO.getBank_no());
		ClientBankInfoNoDO clientBankInfoNoDO = new ClientBankInfoNoDO();
		clientBankInfoNoDO.setClientId(clientId);
		clientBankInfoNoDO.setBankId(bankType);
		clientBankInfoNoDO.setBankRealName(depositAccountToNoticeDTO.getName());
		clientBankInfoNoDO.setBankIdcard(depositAccountToNoticeDTO.getCert_no());
		clientBankInfoNoDO.setBankNum(depositAccountToNoticeDTO.getBank_card_no());
		clientBankInfoNoDO.setBankName(depositAccountToNoticeDTO.getBank_name());
		clientBankInfoNoDO.setBankcardBankname(depositAccountToNoticeDTO.getBank_name());
		clientBankInfoNoDO.setPhone(depositAccountToNoticeDTO.getMobile());
		if (flag) {
			clientBankInfoNoDO.setState(SysDictEnum.YES.getCode());
			clientBankInfoNoDO.setIsDefault(SysDictEnum.YES.getCode());
		} else {
			clientBankInfoNoDO.setState(SysDictEnum.NO.getCode());
			clientBankInfoNoDO.setIsDefault(SysDictEnum.NO.getCode());
		}
		bankDao.addClientBankInfoNo(clientBankInfoNoDO);
		return clientBankInfoNoDO.getId();
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse bindCardNotice(ResultDTO<BindCardNoticeDTO> noticeDto) {
		DepositBankResultDTO depositBankResultDTO = new DepositBankResultDTO();
		BindCardNoticeDTO bindCardNoticeDTO = noticeDto.getBody();
		// 验证签名
		Boolean flag = SignMatchesUtil.matches(noticeDto, secretKey, noticeDto.getSign());
		if (flag) {
			// String code = noticeDto.getCode();
			// if (SysConstants.INTERFACE_SUCCESS.equals(code)) {
			// 获取clientId
			Long clientId = depositBankDao.getClientIdByCertNo(bindCardNoticeDTO.getCert_no());
			if (clientId == null) {
				depositBankResultDTO.setCode(SysConstants.INTERFACE_FAIL);
				depositBankResultDTO.setMessage("无此用户信息!");
			} else {
				// -- 查询用户信息数据
				Map<String, Object> paraMap = new HashMap<>(1);
				paraMap.put("id", clientId);
				ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
				boolean boo = (applyClientInfoDO.getIdcard().equals(bindCardNoticeDTO.getCert_no()) && applyClientInfoDO.getName().equals(bindCardNoticeDTO.getName()));

				updateBankStateInRedis(clientId);
				int bankCode = depositBankDao.getBankType(bindCardNoticeDTO.getBank_id_no());
				// 1.新增到客户银行卡表
				ClientBankInfoNoDO clientBankInfoNoDO = new ClientBankInfoNoDO();
				clientBankInfoNoDO.setClientId(clientId);
				clientBankInfoNoDO.setBankRealName(bindCardNoticeDTO.getName());
				clientBankInfoNoDO.setBankIdcard(bindCardNoticeDTO.getCert_no());
				clientBankInfoNoDO.setBankNum(bindCardNoticeDTO.getBank_card_no());
				clientBankInfoNoDO.setBankName(bindCardNoticeDTO.getBank_name());
				clientBankInfoNoDO.setBankcardBankname(bindCardNoticeDTO.getBank_name());
				clientBankInfoNoDO.setPhone(bindCardNoticeDTO.getMobile());
				clientBankInfoNoDO.setBankId(bankCode);
				if (boo) {
					clientBankInfoNoDO.setIsDefault(SysDictEnum.YES.getCode());
					clientBankInfoNoDO.setState(SysDictEnum.YES.getCode());
				} else {
					clientBankInfoNoDO.setIsDefault(SysDictEnum.NO.getCode());
					clientBankInfoNoDO.setState(SysDictEnum.NO.getCode());
					// -- 修改用户不可进件时间200年
					clinetUserModifyService.updateClientAllowableEntryTime(clientId, 73000);
				}
				bankDao.addClientBankInfoNo(clientBankInfoNoDO);

				// 2.更新存管账户表
				DepositAccountStatementInfoDO depositAccountStatementInfoDO = new DepositAccountStatementInfoDO();
				depositAccountStatementInfoDO.setClientId(clientId);
				depositAccountStatementInfoDO.setIsValid(SysDictEnum.YES.getCode());
				List<DepositAccountStatementInfoDO> depositAccountStatementInfoDOList = depositBankDao.getDepositAccountStatementInfo(depositAccountStatementInfoDO);
				if (depositAccountStatementInfoDOList != null && depositAccountStatementInfoDOList.size() > 0) {
					depositAccountStatementInfoDO = depositAccountStatementInfoDOList.get(0);
					depositAccountStatementInfoDO.setClientBankId(clientBankInfoNoDO.getId());
					depositAccountStatementInfoDO.setCardNo(bindCardNoticeDTO.getCard_no());
					depositAccountStatementInfoDO.setCustomerNo(bindCardNoticeDTO.getCustomer_no());
					depositAccountStatementInfoDO.setSerialNo(bindCardNoticeDTO.getSerial_no());
					if (!boo){
					    depositAccountStatementInfoDO.setIsValid(SysDictEnum.NO.getCode());
                    }
					depositBankDao.updateDepositAccountInfoById(depositAccountStatementInfoDO);
				}

				// 3.变更合同表中的银行卡信息
				XybContractUpdateDTO xybContractDO = new XybContractUpdateDTO();
				xybContractDO.setClientId(clientId);
				xybContractDO.setBankType(bankCode);
				xybContractDO.setBankAccount(bindCardNoticeDTO.getBank_name());
				xybContractDO.setBankAccountOpen("");
				xybContractDO.setRefundCardNum(bindCardNoticeDTO.getBank_card_no());
				xybContractDO.setMp(bindCardNoticeDTO.getMobile());
				xybContractDO.setCustName(bindCardNoticeDTO.getName());
				// -- 更换用户合同的银行卡信息
				xybContractDao.updateContractBankInfo(xybContractDO);
				depositBankResultDTO.setCode(SysConstants.INTERFACE_SUCCESS);
				depositBankResultDTO.setMessage("请求成功!");
			}
			// } else {
			// depositBankResultDTO.setCode(SysConstants.INTERFACE_FAIL);
			// depositBankResultDTO.setMessage("非法接口调用!");
			// }
		} else {
			depositBankResultDTO.setCode(SysConstants.INTERFACE_FAIL);
			depositBankResultDTO.setMessage("验签失败!");
		}
		// 给返回信息加签
		String sign = SignMatchesUtil.signEncode(depositBankResultDTO, secretKey);
		depositBankResultDTO.setSign(sign);
		// -- 添加日志
		depositBankService.addLog(null, "个人绑卡网关通知接口(bindCardNotice)", JsonUtils.toJSON(noticeDto),JsonUtils.toJSON(depositBankResultDTO), null);
		return new RestResponse(MsgErrCode.SUCCESS, depositBankResultDTO);
	}

	@Override
	public Long getSignState(Long clientId) {
		// -- 查询存管账户信息
		Map<String, Object> queryMap = new HashMap<>(1);
		queryMap.put("clientId", clientId);
		AccountInterfaceDTO accountInterface = depositBankDao.queryAccountInterfaceInfo(queryMap);
		if (accountInterface == null) {
			return SysDictEnum.NO.getCode();
		}
		if (accountInterface.getIsSign() == null) {
			return SysDictEnum.NO.getCode();
		}
		return accountInterface.getIsSign();
	}

	@Override
	public boolean accountFindAccIdQuery(Long userId,Long clientId,String certNo, String client, String custom, String clientIp, String clientService) {
		AccountFindAccIdQueryRequestDTO accountFindAccIdQueryRequestDTO = new AccountFindAccIdQueryRequestDTO();
		accountFindAccIdQueryRequestDTO.setSysId(Long.valueOf(sysId));
		accountFindAccIdQueryRequestDTO.setCert_no(certNo);
		accountFindAccIdQueryRequestDTO.setClient(client);
		accountFindAccIdQueryRequestDTO.setCustom(custom);
		accountFindAccIdQueryRequestDTO.setClient_ip(clientIp);
		accountFindAccIdQueryRequestDTO.setClient_service(clientService);
		SignedEntryDTO signedEntry = new SignedEntryDTO();
		signedEntry.setBody(accountFindAccIdQueryRequestDTO);
		// -- 进行指定字段加签
		String sign = SignMatchesUtil.signEncode(signedEntry, secretKey);
		signedEntry.setSign(sign);
		// -- 推送深圳
		String dataJson = JsonUtils.toJSON(signedEntry);
		String result = null;
		try {
			result = HttpTools.sendPost(accountFindAccIdQuery, dataJson, "utf-8");
		} catch (Exception e) {
			logger.error("查询用户是否开户接口异常:" + e);
		}
		// -- 添加日志
		depositBankService.addLog(null, "查询用户是否开户接口(findAccIdQuery)", dataJson, result, userId);
		if (StringUtils.isNullOrEmpty(result)){
			return false;
		}
		ResultDTO<AccountFindAccIdQueryResponseDTO> resultDTO = (ResultDTO<AccountFindAccIdQueryResponseDTO>) JSON.parseObject(result,new TypeReference<ResultDTO<AccountFindAccIdQueryResponseDTO>>() {});
		boolean boo = SignMatchesUtil.matches(resultDTO, secretKey, resultDTO.getSign());
		// -- 验签成功，并且接口调用成功
		if (boo && SysConstants.INTERFACE_SUCCESS.equals(resultDTO.getCode())) {
			DepositAccountToNoticeDTO depositAccountToNoticeDTO = new DepositAccountToNoticeDTO();
			depositAccountToNoticeDTO.setCert_type(resultDTO.getBody().getCert_type());
			depositAccountToNoticeDTO.setCert_no(resultDTO.getBody().getCert_no());
			depositAccountToNoticeDTO.setName(resultDTO.getBody().getName());
			depositAccountToNoticeDTO.setCustomer_no(resultDTO.getBody().getCustomer_no());
			depositAccountToNoticeDTO.setCard_no(resultDTO.getBody().getCard_no());
			depositAccountToNoticeDTO.setService(resultDTO.getBody().getService());
			depositAccountToNoticeDTO.setAcctId(resultDTO.getBody().getAcctId());
			// -- 初始化/修改存管账户表
			initializeDepositAccountStatementInfo(depositAccountToNoticeDTO,clientId,null,true);
			return true;
		}
		return false;
	}

	// 删除redis的中的KEY
	private void updateBankStateInRedis(Long applyClientUserId) {
		// 获取logonId
		ClientUserDO clientUserDO = clinetUserDao.getClientUserByApplyClientUserId(applyClientUserId);
		if (null != clientUserDO && StringUtils.isNotNullAndEmpty(clientUserDO.getLoginName())) {
			String key = RedisConstant.ORDER_USER_BANK_STATE + clientUserDO.getLoginName();
			if (RedisUtil.exists(key)) {
				RedisUtil.del(key);
			}
		}
	}

}
