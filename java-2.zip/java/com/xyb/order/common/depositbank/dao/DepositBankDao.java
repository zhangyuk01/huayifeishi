package com.xyb.order.common.depositbank.dao;

import com.xyb.order.common.depositbank.model.AccountInterfaceDTO;
import com.xyb.order.common.depositbank.model.DepositAccountInterfaceLogDO;
import com.xyb.order.common.depositbank.model.DepositAccountStatementInfoDO;
import java.util.List;
import java.util.Map;

/**
 * 存管用到的sql
 * 
 * @author xieqingyang
 * @date 2018/11/23 10:15 AM
 */
public interface DepositBankDao {

	/**
	 * 添加存管接口调用日志
	 *
	 * @param depositAccountInterfaceLogDO
	 *            待添加日志信息
	 * @return 返回添加结果
	 * @author xieqingyang
	 * @date 2018/11/23 10:28 AM
	 * @version 1.0
	 */
	int insertDepositAccountInterfaceLog(DepositAccountInterfaceLogDO depositAccountInterfaceLogDO);

	/**
	 * 添加存管账户信息
	 *
	 * @param depositAccountStatementInfoDO
	 *            待添加存管账户信息
	 * @return 返回添加结果
	 * @author xieqingyang
	 * @date 2018/11/23 10:32 AM
	 * @version 1.0
	 */
	int insertDepositAccountStatementInfo(DepositAccountStatementInfoDO depositAccountStatementInfoDO);

	/**
	 * 修改存管账户签约状态信息
	 * 
	 * @author xieqingyang
	 * @date 2018/12/26 3:18 PM
	 * @version 1.0
	 * @param depositAccountStatementInfoDO
	 *            存管账户信息
	 * @return 返回修改结果
	 */
	int updateDepositAccountStatementInfoSignState(DepositAccountStatementInfoDO depositAccountStatementInfoDO);

	/**
	 * 修改存管账户信息
	 *
	 * @param depositAccountStatementInfoDO
	 *            待修改账户信息
	 * @return 返回修改结果
	 * @author xieqingyang
	 * @date 2018/11/23 10:34 AM
	 * @version 1.0
	 */
	int updateDepositAccountStatementInfo(DepositAccountStatementInfoDO depositAccountStatementInfoDO);

	/**
	 * 修改存管账户信息
	 *
	 * @param depositAccountStatementInfoDO
	 *            待修改账户信息
	 * @return 返回修改结果
	 * @author xieqingyang
	 * @date 2018/11/23 10:34 AM
	 * @version 1.0
	 */
	int updateDepositAccountStatementInfoById(DepositAccountStatementInfoDO depositAccountStatementInfoDO);
    
    /**
     * 查询用户存管账户信息
     *
     * @param infoDO 查询条件
     * @return 存管账户信息个数
     * @author 张浩
     * @date 2019/1/16 10:57 AM
     * @version 1.0
     */
    Integer queryDepositAccountStatementInfoCount(Map<String,Object> queryMap);

	/**
	 * 查询用户存管账户信息
	 *
	 * @param infoDO
	 *            查询条件
	 * @return 存管账户信息
	 * @author xieqingyang
	 * @date 2018/11/23 10:57 AM
	 * @version 1.0
	 */
	List<DepositAccountStatementInfoDO> getDepositAccountStatementInfo(DepositAccountStatementInfoDO infoDO);

	/**
	 * 获取clientId
	 * 
	 * @author jiangzhongyan
	 * @date 2018/11/26 5:04 PM
	 * @version 1.0
	 * @param certNo
	 *            电子账户(开户返回的电子账户)
	 * @return 返回客户信息表主键ID
	 */
	Long getClientIdByCertNo(String certNo);

	/**
	 * 获取bankType
	 * 
	 * @author jiangzhongyan
	 * @date 2018/11/26 5:03 PM
	 * @version 1.0
	 * @param bankNo
	 *            银行编号（三方）
	 * @return 返回banktype
	 */
	int getBankType(String bankNo);

	/**
	 * 查询存管请求通用参数（查询有效的 有且只有一个）
	 *
	 * @param queryMap
	 *            查询条件
	 * @return 返回存管需要参数
	 * @author fangjie
	 * @date 2018/11/26 11:36 AM
	 * @version 1.0
	 */
	AccountInterfaceDTO queryAccountInterfaceInfo(Map<String, Object> queryMap);

	int updateDepositAccountInfoById(DepositAccountStatementInfoDO depositAccountStatementInfoDO);

	/**
	 * 根据apply_client_id获取一条记录
	 * 
	 * @param id
	 * @return
	 */
	DepositAccountStatementInfoDO getDepositAccountStatementInfoOneSelect(Long id);

}
