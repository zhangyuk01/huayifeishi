package com.xyb.order.common.fdd.dao;

import com.xyb.order.common.fdd.model.FddLogDO;

/**
 * @description:    法大大相关sql
 * @author:         xieqingyang
 * @createDate:     2018/7/30 下午4:28
*/
public interface FddDao {

    /**
     * @description 添加法大大接口调用日志
     * @author      xieqingyang
     * @CreatedDate 2018/7/30 下午4:30
     * @Version     1.0
     * @param fddLogDO 法大大调用参数
     * @return 返回执行结果
     */
    int insertFddLog(FddLogDO fddLogDO);

    /**
     * @description 修改法大大接口日志 增加返回结果
     * @author      xieqingyang
     * @CreatedDate 2018/7/30 下午4:30
     * @Version     1.0
     * @param fddLogDO 法大大返回参数
     * @return 返回执行结果
     */
    int updateFddLog(FddLogDO fddLogDO);
}
