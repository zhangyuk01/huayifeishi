package com.xyb.order.common.fdd.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.beiming.kun.utils.StringUtils;
import com.fadada.sdk.client.FddClientBase;
import com.fadada.sdk.client.FddClientExtra;
import com.fadada.sdk.util.crypt.FddEncryptTool;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AgreementInFoDO;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.common.constant.AuthorizationConstant;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.fdd.dao.FddDao;
import com.xyb.order.common.fdd.model.FddLogDO;
import com.xyb.order.common.fdd.model.FddReturnInFoDTO;
import com.xyb.order.common.fdd.service.FddService;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.util.SessionUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.HashMap;
import java.util.Map;

@Service(interfaceName = "com.xyb.order.common.fdd.service.FddService")
public class FddServiceImpl implements FddService {

    private static final Logger log = LoggerFactory.getLogger(FddServiceImpl.class);

    /**app_id*/
    @Value("${app.id}")
    private String appId;

    /**app_secret*/
    @Value("${app.secret}")
    private String appSecret;

    /**法大大地址*/
    @Value("${fadada.url}")
    private String fddUrl;

    /**法大大版本号*/
    @Value("${fadada.version}")
    private String fddVersion;

    /**法大大地同步回调地址*/
    @Value("${fadada.return.url}")
    private String fddReturnUrl;

    /**法大大异步回调地址*/
    @Value("${fadada.notify.url}")
    private String fddNotifyUrl;

    /**法大大客户编号*/
    @Value("${fadada.cusnum}")
    private String fddCusNum;

    /**法大大公司名称*/
    @Value("${fadada.company.name}")
    private String fddCompanyName;

    @Autowired
    private FddDao fddDao;
    @Autowired
    private ClinetUserDao clientUserDao;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private ClinetUserDao clinetUserDao;


    @Override
    public RestResponse invokeSyncPersonAuto(Long clientId) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        if (clientId == null){
            return new RestResponse(NativeMsgErrCode.DEVICE_TYPE_ERROR);
        }
        // -- 获取用户信息
        Map<String,Object> paraMap = new HashMap<>(1);
        paraMap.put("id",clientId);
        ApplyClientInfoDO applyClientInfoDO = clientUserDao.getApplyClientInfo(paraMap);
        if (applyClientInfoDO == null){
            return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
        }
        // -- 保存调用法大大接口日志
        FddLogDO fddLogDO = new FddLogDO();
        fddLogDO.setClientId(clientId);
        fddLogDO.setCreateUser(user.getId());
        fddLogDO.setInterfaceName("个人 CA 申请接口");
        JSONObject reqPmt = new JSONObject();
        reqPmt.put("customer_name",applyClientInfoDO.getName());
        reqPmt.put("idcard",applyClientInfoDO.getIdcard());
        reqPmt.put("phone",applyClientInfoDO.getPhone());
        fddLogDO.setReqPmt(reqPmt.toString());
        fddDao.insertFddLog(fddLogDO);
        // -- 调用法大大个人 CA 申请接口
        FddClientBase fddClientBase = new FddClientBase(appId,appSecret,fddVersion,fddUrl);
        String data = fddClientBase.invokeSyncPersonAuto(applyClientInfoDO.getName(),"",applyClientInfoDO.getIdcard(),"0",applyClientInfoDO.getPhone());
        String customerId = null;
        String result = null;
        String code = null;
        String msg = null;
        if (data != null){
            JSONObject resultJson = JSONObject.fromObject(data);
            result = resultJson.getString(AuthorizationConstant.FDD_RESULT);
            code = resultJson.getString(AuthorizationConstant.FDD_CODE);
            msg = resultJson.getString(AuthorizationConstant.FDD_MSG);
            if (resultJson.containsKey(AuthorizationConstant.FDD_CUSTOMER_ID)){
                customerId = resultJson.getString(AuthorizationConstant.FDD_CUSTOMER_ID);
            }
        }
        // -- 修改调用法大大接口日志
        fddLogDO.setRespPmt(data);
        fddLogDO.setModifyUser(user.getId());
        fddLogDO.setCode(code);
        fddLogDO.setResult(result);
        fddLogDO.setMsg(msg);
        fddDao.updateFddLog(fddLogDO);
        // -- 判断结果
        if (AuthorizationConstant.FDD_RESULT_1000.equals(code)){
            applyClientInfoDO.setCustomerId(customerId);
            clientUserDao.updateApplyClientInfo(applyClientInfoDO);
            RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + applyClientInfoDO.getPhone());
            return new RestResponse(MsgErrCode.SUCCESS);
        }else {
            return new RestResponse(MsgErrCode.FAIL);
        }
    }

    @Override
    public RestResponse invokeGenerateContract(String templateId, String contractId, String docTitle, String fontSize, String fontType, String parameterMap, String dynamicTables, Long clientId, Long operatorUser) throws Exception {
        RestResponse response;
        if (fontSize == null){fontSize = "";}
        if (fontType == null){fontType = "";}
        if (dynamicTables == null){dynamicTables = "";}
        // -- 保存调用法大大接口日志
        FddLogDO fddLogDO = new FddLogDO();
        fddLogDO.setClientId(clientId);
        fddLogDO.setCreateUser(operatorUser);
        fddLogDO.setInterfaceName("合同生成接口");
        fddLogDO.setContractId(contractId);
        JSONObject reqJson  = new JSONObject();
        reqJson.put("template_id",templateId);
        reqJson.put("contract_id",contractId);
        reqJson.put("doc_title",docTitle);
        reqJson.put("font_size",fontSize);
        reqJson.put("font_type",fontType);
        reqJson.put("parameter_map",parameterMap);
        reqJson.put("dynamic_tables",dynamicTables);
        fddLogDO.setReqPmt(reqJson.toString());
        fddDao.insertFddLog(fddLogDO);
        // -- 调用法大大合同生成接口
        FddClientBase fddClientBase = new FddClientBase(appId,appSecret,fddVersion,fddUrl);
        String data = fddClientBase.invokeGenerateContract(templateId,contractId,docTitle,fontSize,fontType,parameterMap,dynamicTables);
        String result = null;
        String code = null;
        String msg = null;
        if (data != null){
            JSONObject resultJson = JSONObject.fromObject(data);
            result = resultJson.getString(AuthorizationConstant.FDD_RESULT);
            code = resultJson.getString(AuthorizationConstant.FDD_CODE);
            msg = resultJson.getString(AuthorizationConstant.FDD_MSG);
        }
        // -- 修改调用法大大接口日志
        fddLogDO.setCode(code);
        fddLogDO.setResult(result);
        fddLogDO.setMsg(msg);
        fddLogDO.setRespPmt(data);
        fddLogDO.setModifyUser(operatorUser);
        fddDao.updateFddLog(fddLogDO);
        if (AuthorizationConstant.SUCCESS.equals(result) && AuthorizationConstant.FDD_RESULT_1000.equals(code)){
            response = new RestResponse(MsgErrCode.SUCCESS);
        }else {
            response = new RestResponse(MsgErrCode.FAIL);
        }
        if (StringUtils.isNotNullAndEmpty(data)) {
            response.setData(data);
        }
        return response;
    }

    @Override
    public String invokeExtSign(String transactionId, String customerId, String contractId, String docTitle, String signKeyword, Long clientId, Long operatorUser) throws Exception {
        if (signKeyword == null){signKeyword = "";}
        // -- 保存调用法大大接口日志
        String returnUrl = fddReturnUrl+"/"+contractId;
        FddLogDO fddLogDO = new FddLogDO();
        fddLogDO.setClientId(clientId);
        fddLogDO.setCreateUser(operatorUser);
        fddLogDO.setInterfaceName("文档签署接口(手动签)");
        fddLogDO.setContractId(contractId);
        fddLogDO.setTransactionId(transactionId);
        JSONObject reqJson  = new JSONObject();
        reqJson.put("transaction_id",transactionId);
        reqJson.put("customer_id",customerId);
        reqJson.put("contract_id",contractId);
        reqJson.put("doc_title",docTitle);
        reqJson.put("sign_keyword",signKeyword);
        reqJson.put("return_url",returnUrl);
        reqJson.put("notify_url",fddNotifyUrl==null?"":fddNotifyUrl);
        fddLogDO.setReqPmt(reqJson.toString());
        fddDao.insertFddLog(fddLogDO);
        // -- 调用法大大文档签署接口(手动签)
        FddClientBase fddClientBase = new FddClientBase(appId,appSecret,fddVersion,fddUrl);
        String signUrl = fddClientBase.invokeExtSign(transactionId,customerId,contractId,docTitle,signKeyword,returnUrl,fddNotifyUrl==null?"":fddNotifyUrl);
        // -- 修改调用法大大接口日志
        fddLogDO.setRespPmt(signUrl);
        fddDao.updateFddLog(fddLogDO);
        return signUrl;
    }

    @Override
    public RestResponse invokeInfoChange(String customerId, String email, String mobile, Long clientId, Long operatorUser) throws Exception {
        if (email == null){email = "";}
        // -- 保存调用法大大接口日志
        FddLogDO fddLogDO = new FddLogDO();
        fddLogDO.setClientId(clientId);
        fddLogDO.setCreateUser(operatorUser);
        fddLogDO.setInterfaceName("客户信息修改接口");
        JSONObject reqJson  = new JSONObject();
        reqJson.put("customer_id",customerId);
        reqJson.put("email",email);
        reqJson.put("mobile",mobile);
        fddLogDO.setReqPmt(reqJson.toString());
        fddDao.insertFddLog(fddLogDO);
        // -- 调用法大大文档签署接口(手动签)
        FddClientExtra clientextra = new FddClientExtra(appId,appSecret,fddVersion,fddUrl);
        String data = clientextra.invokeInfoChange(customerId,email,mobile);
        String result = null;
        String code = null;
        String msg = null;
        if (data != null){
            JSONObject resultJson = JSONObject.fromObject(data);
            msg = resultJson.getString(AuthorizationConstant.FDD_MSG);
            result = resultJson.getString(AuthorizationConstant.FDD_RESULT);
            code = resultJson.getString(AuthorizationConstant.FDD_CODE);
        }
        // -- 修改调用法大大接口日志
        fddLogDO.setRespPmt(data);
        fddLogDO.setModifyUser(operatorUser);
        fddLogDO.setCode(code);
        fddLogDO.setResult(result);
        fddLogDO.setMsg(msg);
        fddDao.updateFddLog(fddLogDO);
        if (AuthorizationConstant.FDD_RESULT_1000.equals(code)){
            return new RestResponse(MsgErrCode.SUCCESS);
        }else {
            return new RestResponse(MsgErrCode.FAIL);
        }
    }

    @Override
    public RestResponse fddAnalysis(FddReturnInFoDTO fddReturnInFoDTO) {
        RestResponse response;
        // -- 保存fdd调用日志
        FddLogDO fddLogDO = new FddLogDO();
        fddLogDO.setInterfaceName("法大大同步或异步回调");
        fddLogDO.setRespPmt(JsonUtils.toJSON(fddReturnInFoDTO));
        fddLogDO.setContractId(fddReturnInFoDTO.getContract_id());
        fddLogDO.setTransactionId(fddReturnInFoDTO.getTransaction_id());
        fddLogDO.setCode(fddReturnInFoDTO.getResult_code());
        fddLogDO.setMsg(fddReturnInFoDTO.getResult_desc());
        try {
            // -- 判断是否是签章成功
            if (AuthorizationConstant.FDD_RESULT_3000.equals(fddReturnInFoDTO.getResult_code())) {
                // -- 根据法大大合同ID查询合同协议
                AgreementInFoDO para = new AgreementInFoDO();
                para.setContractId(fddReturnInFoDTO.getContract_id());
                AgreementInFoDO agreementInFoDO = authorizationDao.getAgreementInfo(para);
                if (agreementInFoDO != null) {
                    agreementInFoDO.setIsValid(SysDictEnum.IS_VALID.getCode());
                    agreementInFoDO.setModifyUser(CurrencyConstant.SYSTEM_USER);
                    if (StringUtils.isNotNullAndEmpty(fddReturnInFoDTO.getViewpdf_url())) {
                        agreementInFoDO.setLookAddress(fddReturnInFoDTO.getViewpdf_url());
                    }
                    if (StringUtils.isNotNullAndEmpty(fddReturnInFoDTO.getDownload_url())) {
                        agreementInFoDO.setDownloadAddress(fddReturnInFoDTO.getDownload_url());
                    }
                    authorizationDao.updateAgreementInfo(agreementInFoDO);
                    fddLogDO.setClientId(agreementInFoDO.getCusId());
                    // -- 清除用户缓存
                    // -- 查询用户信息
                    Map<String,Object> paraMap = new HashMap<>(1);
                    paraMap.put("id",agreementInFoDO.getCusId());
                    ApplyClientInfoDO applyClientInfoDO = clinetUserDao.getApplyClientInfo(paraMap);
                    applyClientInfoDO.setAgreementIsCompleted(SysDictEnum.HAVE_SUGNED_CONTRACT.getCode());
                    if (SysDictEnum.AUTHORIZE_URL.getCode().equals(agreementInFoDO.getAgreementType())) {
                        clinetUserDao.updateApplyClientInfo(applyClientInfoDO);
                    }
                    RedisUtil.del(RedisConstant.CLIENT_AUTHENTICATION_INFO + applyClientInfoDO.getPhone());
                }
            }
            response = new RestResponse(MsgErrCode.SUCCESS);
        }catch (Exception e){
            e.printStackTrace();
            log.error("解析法大大同步或异步返回数据异常");
            response = new RestResponse(MsgErrCode.FAIL);
        }finally {
            fddDao.insertFddLog(fddLogDO);
        }
        return response;
    }
}
