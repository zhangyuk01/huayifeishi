package com.xyb.order.common.material.dao;

/**
 * @ClassName FileClassificationDao
 * @author ZhangYu
 * @date 2018年4月17号
 */

public interface FileClassificationDao {

	public Long getImageIdByCode(String fileClassificationCode);

}
