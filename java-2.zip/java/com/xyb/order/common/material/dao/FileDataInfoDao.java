package com.xyb.order.common.material.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.common.material.model.FileDataDelDTO;
import com.xyb.order.common.material.model.FileDataInfo;

/**
 * @ClassName FileDataInfoDao
 * @author ZhangYu
 * @date 2018年4月17号
 */

public interface FileDataInfoDao {

	/**
	 * 添加图片信息
	 * @param fileDataInfo
	 */
	void addFileDataInfo(FileDataInfo fileDataInfo);

	/**
	 * 判断图片是否存在 
	 * @param paramMap
	 * @return
	 */
	int fileIsExit(Map<String, Object> paramMap);
	

	/**
	 * 根据ID集合查询图片集合 
	 * @param fileDataDelDTO
	 * @return
	 */
	List<FileDataInfo> getListFileDataInfoByIdArray(FileDataDelDTO fileDataDelDTO);

	/**
	 * 
	 * @param paramMap
	 * @return
	 */
	int findFileDataInfoMaxSort(Map<String, Object> paramMap);

	/**
	 * @description 根据图片类型查询图片集合
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/28 下午7:05
	 * @Version     1.0
	 * @param paraMap 包含applyId申请单ID、fileCode图片类型
	 * @return 返回图片类型list
	 */
	List<FileDataInfo> queryFileDateInfoList(Map<String,Object> paraMap);

	/**
	 * @description 批量修改图片为不可删除
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/30 上午10:00
	 * @Version     1.0
	 * @param paraMap 包括修改人，图片类型，申请单ID
	 * @return 返回sql执行结果
	 */
	int updateFileState(Map<String,Object> paraMap);

	/**
	 * @description 查询不可删除的数量
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/30 下午4:16
	 * @Version     1.0
	 * @param fileDataDelDTO
	 * @return 返回数量
	 */
	int canNotDelCount(FileDataDelDTO fileDataDelDTO);

	/**
	 * @description 删除图片-更改图片属性为已删除
	 * @author      xieqingyang
	 * @CreatedDate 2018/5/30 下午4:22
	 * @Version     1.0
	 * @return	返回修改结果
	 */
	int updateFileDelState(FileDataDelDTO fileDataDelDTO);

	/**
	 * @description 根据申请单ID查询用户图片信息
	 * @author      xieqingyang
	 * @CreatedDate 2018/7/17 下午1:03
	 * @Version     1.0
	 * @param applyId 申请单ID
	 * @return 返回个人信息
	 */
	ApplyClientInfoDO getApplyClientFileInfo(Long applyId);
}
