package com.xyb.order.common.material.service;

import java.util.*;

import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.xyb.order.app.client.cuser.model.ApplyClientInfoDO;
import com.xyb.order.common.constant.*;
import com.xyb.order.common.material.model.FileDataDelDTO;
import com.xyb.order.common.material.model.FileDateListVO;
import com.xyb.order.common.material.model.FileSeeDTO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import org.apache.log4j.Logger;
import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.UUIDUtil;
import com.xyb.auth.user.model.User;
import com.xyb.model.ResultFileInfo;
import com.xyb.order.common.material.dao.FileDataInfoDao;
import com.xyb.order.common.material.model.FileDataInfo;
import com.xyb.order.common.util.JsonUtil;
import com.xyb.order.common.util.tianji.utils.Base64Utils;
import com.xyb.service.FastFileStorageService;
import com.xyb.util.SessionUtil;

import net.sf.json.JSONObject;

/**
 * @ClassName FileDataInfoServiceImpl
 * @author ZhangYu
 * @date 2018年4月17号
 */

@Service(interfaceName = "com.xyb.order.common.material.service.FileDataInfoService")
public class FileDataInfoServiceImpl implements FileDataInfoService{
	@Autowired
	private FileDataInfoDao fileDataInfoDao;
	@Autowired
	private FastFileStorageService fastFileStorageService;
	@Autowired
	private FileClassificationService fileClassificationService;
	@Autowired
	private FileDataInfoService fileDataInfoService;

	private final static Logger logger = Logger.getLogger(FileDataInfoServiceImpl.class);

	@Override
	public FileDataInfo addFileDataInfo(FileDataInfo fileDataInfo) {
		this.fileDataInfoDao.addFileDataInfo(fileDataInfo);
		return fileDataInfo;
	}

	@Override
	public int fileIsExit(String fileName,Long fileClassificationId, Long applyId) {
		Map<String, Object>paraMap=new HashMap<String, Object>();
		paraMap.put("fileName", fileName);
		paraMap.put("fileClassificationId", fileClassificationId);
		paraMap.put("applyId", applyId);
		return this.fileDataInfoDao.fileIsExit(paraMap);
	}

	@Override
	public int findFileDataInfoMaxSort(Map<String, Object> paramMap) {
		return this.fileDataInfoDao.findFileDataInfoMaxSort(paramMap);
	}

	@Override
	public RestResponse uploadAppImageFile(String imageFiles, Long applyId, String fileCode) throws Exception {
		String thisMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		logger.info("===============app/身份上传图片   start===================");
		logger.info(thisMethodName + ":start");
		User loginUser = SessionUtil.getLoginUser(User.class);
		Long userId = loginUser.getId();
		FileDataInfo fileDataInfo = new FileDataInfo();
		try {
			byte[] imageFile = Base64Utils.decode(imageFiles);
			ByteArrayInputStream inputStreame = new ByteArrayInputStream(imageFile);
			String fileName = UUIDUtil.getUUID()+".jpg";
			/**1.上传图片服务器*/
			ResultFileInfo uploadFile = this.fastFileStorageService.uploadFile(inputStreame,fileName, null);
			logger.info("===============app/身份上传图片     end===================");
			String fullAllPath = CurrencyConstant.HTTP + uploadFile.getFullAllPath().replace(" ","");
			String group = uploadFile.getGroup();
			Long fileClassificationId = this.fileClassificationService.getImageIdByCode(fileCode);
			/**2.保存图片信息到数据库*/
			fileDataInfo.setPicGroup(group);
			fileDataInfo.setApplyId(applyId);
			fileDataInfo.setFileName(fileName);
			fileDataInfo.setPicPath(fullAllPath);
			fileDataInfo.setOperatorId(userId);
			fileDataInfo.setCreateUser(userId);
			fileDataInfo.setModifyUser(userId);
			fileDataInfo.setFileClassificationId(fileClassificationId);
			fileDataInfo.setCreateTime(new Date());
			this.fileDataInfoService.addFileDataInfo(fileDataInfo);
			fileDataInfo.setIsDel(SysDictEnum.YES.getCode());
			/**3.添加图片信息到缓存*/
			String key = RedisConstant.IMAGE_APPLY + String.valueOf(applyId)+"_"+fileCode+"_"+fileName;
			String bean2json = JsonUtil.object2json(fileDataInfo);
			RedisUtil.setex(key, RedisConstant.IMAGE_CACHE_TIME, bean2json);
			fileDataInfo.setUploadState(TableConstant.T_IMAGE_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
        return new RestResponse(MsgErrCode.SUCCESS,fileDataInfo);
	}

	@Override
	public RestResponse queryFileDataInfoList(FileSeeDTO fileSeeDTO) throws Exception {
		/**查询图片类型*/
		List<String> typeList = fileSeeDTO.getFileType();
		/**查询图片传入参数*/
		Map<String,Object> paraMap;
		/**返回数据*/
		List<Map<String,Object>> returnList = new ArrayList<>();
		Map<String,Object> returnMap;
		/**缓存或数据库数据*/
		List<FileDataInfo> fileDataInfos;
		/**页面展示数据*/
		List<FileDateListVO> fileDateListVOS;
		/**页面展示数据单个*/
		FileDateListVO fileDateListVO;
		for (String type:typeList){
			returnMap = new HashMap<>();
			String key = RedisConstant.IMAGE_APPLY + String.valueOf(fileSeeDTO.getApplyId()) +"_"+type+"_*";
			fileDateListVOS = new ArrayList<>();
			fileDataInfos = new ArrayList<>();
			Set<String> keys = RedisUtil.keys(key);
			if (keys.size()>0) {
				for (String fkey : keys) {
					String value= RedisUtil.get(fkey);
					JSONObject jsonObject = JSONObject.fromObject(value);
					FileDataInfo fileDataInfo = (FileDataInfo) JSONObject.toBean(jsonObject, FileDataInfo.class);
					fileDataInfos.add(fileDataInfo);
				}
				if (fileDataInfos.size() > 1) {
					//图片排序
					Collections.sort(fileDataInfos,Comparator.comparing(FileDataInfo::getCreateTime));
				}
			}else{
				paraMap = new HashMap<>();
				paraMap.put("applyId",fileSeeDTO.getApplyId());
				paraMap.put("fileCode",type);
				fileDataInfos = fileDataInfoDao.queryFileDateInfoList(paraMap);
				if (fileDataInfos != null && fileDataInfos.size() > 0){
					for (FileDataInfo fileDataInfo : fileDataInfos) {
						String dkey = RedisConstant.IMAGE_APPLY + String.valueOf(fileSeeDTO.getApplyId())+"_"+type+"_"+fileDataInfo.getFileName();
						String bean2json = JsonUtil.object2json(fileDataInfo);
						RedisUtil.setex(dkey, RedisConstant.IMAGE_CACHE_TIME, bean2json);
					}
				}
			}
			// -- 如果是身份证明信息 查询身份证图片
			if (FileNameConstant.A0.equals(type)){
				ApplyClientInfoDO applyClientInfoDO = fileDataInfoDao.getApplyClientFileInfo(fileSeeDTO.getApplyId());
				if (applyClientInfoDO != null){
					if (fileDataInfos == null){
						fileDataInfos = new ArrayList<>();
					}
					if (StringUtils.isNotNullAndEmpty(applyClientInfoDO.getBackFileKey())){
						FileDataInfo fileDataInfo = new FileDataInfo();
						fileDataInfo.setPicPath(applyClientInfoDO.getBackFileKey());
						fileDataInfo.setIsDel(SysDictEnum.NO.getCode());
						fileDataInfo.setCreateTime(applyClientInfoDO.getModifyTime());
						fileDataInfos.add(0,fileDataInfo);
					}
					if (StringUtils.isNotNullAndEmpty(applyClientInfoDO.getFrontFileKey())){
						FileDataInfo fileDataInfo = new FileDataInfo();
						fileDataInfo.setPicPath(applyClientInfoDO.getFrontFileKey());
						fileDataInfo.setIsDel(SysDictEnum.NO.getCode());
						fileDataInfo.setCreateTime(applyClientInfoDO.getModifyTime());
						fileDataInfos.add(0,fileDataInfo);
					}
				}
			}
			for (FileDataInfo info:fileDataInfos){
				fileDateListVO = new FileDateListVO();
				fileDateListVO.setName(info.getName());
				fileDateListVO.setUploadTime(info.getCreateTime());
				fileDateListVO.setPicPath(info.getPicPath());
				fileDateListVO.setDel(SysDictEnum.YES.getCode().equals(info.getIsDel())?true:false);
				String fileNameDe = info.getPicPath().substring(info.getPicPath().lastIndexOf(".")+1);
				if ("pdf".equalsIgnoreCase(fileNameDe)){
					fileDateListVO.setBfile(true);
					fileDateListVO.setFileType("p");
					fileDateListVO.setPicPath(info.getPicPath()+"?filename="+info.getFileName());
				}
				if ("xls".equalsIgnoreCase(fileNameDe) || "xlsx".equalsIgnoreCase(fileNameDe)){
					fileDateListVO.setBfile(true);
					fileDateListVO.setFileType("x");
					fileDateListVO.setPicPath(info.getPicPath()+"?filename="+info.getFileName());
				}
				if ("doc".equalsIgnoreCase(fileNameDe) || "docx".equalsIgnoreCase(fileNameDe)){
					fileDateListVO.setBfile(true);
					fileDateListVO.setFileType("d");
					fileDateListVO.setPicPath(info.getPicPath()+"?filename="+info.getFileName());
				}
				fileDateListVO.setId(info.getId());
				fileDateListVO.setType(type);
				fileDateListVOS.add(fileDateListVO);
			}
			returnMap.put("type",type);
			returnMap.put("list",fileDateListVOS);
			returnList.add(returnMap);
		}
		return new RestResponse(MsgErrCode.SUCCESS,returnList);
	}

	@Override
	public RestResponse fileDataDel(FileDataDelDTO fileDataDelDTO) throws Exception {
		int count = fileDataInfoDao.canNotDelCount(fileDataDelDTO);
		if (count > 0){
			return new RestResponse(NativeMsgErrCode.CANNOT_DEL);
		}else {
			/**1.删除缓存中图片信息*/
			List<FileDataInfo> fileDataInfos = this.fileDataInfoDao.getListFileDataInfoByIdArray(fileDataDelDTO);
			if (fileDataInfos != null && fileDataInfos.size() > 0) {
				for (FileDataInfo fileDataInfo : fileDataInfos) {
					String key = RedisConstant.IMAGE_APPLY + String.valueOf(fileDataDelDTO.getApplyId())+"_"+fileDataDelDTO.getType()+"_"+fileDataInfo.getFileName();
					RedisUtil.del(key);
				}
			}
			/**2.修改图片删除状态*/
			User loginUser = SessionUtil.getLoginUser(User.class);
			fileDataDelDTO.setUserId(loginUser.getId());
			fileDataInfoDao.updateFileDelState(fileDataDelDTO);
			return new RestResponse(MsgErrCode.SUCCESS);
		}
	}

	@Override
	public boolean updateFileState(Long applyId, Long userId, List<String> fileType) {
		Map<String,Object> paraMap = new HashMap<>(3);
		paraMap.put("user",userId);
		paraMap.put("applyId",applyId);
		paraMap.put("list",fileType);
		for (String ft: fileType) {
			String key = RedisConstant.IMAGE_APPLY +applyId+"_"+ft;
			RedisUtil.delPre(key);
		}
		fileDataInfoDao.updateFileState(paraMap);
		return true;
	}

	@Override
	public RestResponse delFile(String filePath) {
		if (com.beiming.kun.utils.StringUtils.isNullOrEmpty(filePath)){
			return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
		}
		fastFileStorageService.deleteFile(filePath);
		return new RestResponse(MsgErrCode.SUCCESS);
	}
}
