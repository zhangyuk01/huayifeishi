package com.xyb.order.common.material.service;

import org.springframework.beans.factory.annotation.Autowired;
import com.alibaba.dubbo.config.annotation.Service;
import com.xyb.order.common.material.dao.FileClassificationDao;

/**
 * @ClassName FileClassificationServiceImpl
 * @author ZhangYu
 * @date 2018年4月17号
 */

@Service(interfaceName = "com.xyb.order.common.material.service.FileClassificationService")
public class FileClassificationServiceImpl implements FileClassificationService{

	@Autowired
	private FileClassificationDao fileClassificationDao;

	@Override
	public Long getImageIdByCode(String fileClassificationCode)  {
		Long imageId = this.fileClassificationDao.getImageIdByCode(fileClassificationCode);
		return imageId;
	}


	
}
