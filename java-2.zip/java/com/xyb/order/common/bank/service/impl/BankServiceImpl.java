package com.xyb.order.common.bank.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xyb.order.common.util.CheckBankCardUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.client.mine.model.ClientAuthenticationDO;
import com.xyb.order.app.client.personinfo.dao.ApplyPersonDao;
import com.xyb.order.app.client.util.ClientRedisUtil;
import com.xyb.order.common.bank.dao.BankDao;
import com.xyb.order.common.bank.model.BankCardInfoVO;
import com.xyb.order.common.bank.model.BankUpdateDTO;
import com.xyb.order.common.bank.model.ChangeBankApplyDO;
import com.xyb.order.common.bank.model.ClientBankInfoNoDO;
import com.xyb.order.common.bank.model.ClientBankLogDO;
import com.xyb.order.common.bank.model.DepositAccountStateVO;
import com.xyb.order.common.bank.model.JieAnLogDO;
import com.xyb.order.common.bank.model.JieAnResultDO;
import com.xyb.order.common.bank.model.JieAnVerifyParamDTO;
import com.xyb.order.common.bank.model.JieAnVerifyRequestDTO;
import com.xyb.order.common.bank.model.XybBankCodeDO;
import com.xyb.order.common.bank.model.XybContractUpdateDTO;
import com.xyb.order.common.bank.service.BankService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.depositbank.dao.DepositBankDao;
import com.xyb.order.common.depositbank.model.DepositAccountStatementInfoDO;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.msg.ParameterConfigEnum;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.IdCardUtil;
import com.xyb.order.pc.contract.dao.XybContractDao;
import com.xyb.order.pc.contract.model.XybContractDO;
import com.xyb.order.pc.task.model.ParameterConfigDO;
import com.xyb.util.SessionUtil;
import com.xyb.util.StringUtils;

import net.sf.json.JSONObject;

@Service(interfaceName = "com.xyb.order.common.bank.service.BankService")
public class BankServiceImpl implements BankService {

	private static final Logger log = LoggerFactory.getLogger(BankServiceImpl.class);
	private static final String PORD_ID = "CARD4";

	/** 捷安访问地址 */
	@Value("${jiean.verify.url}")
	private String url;
	/** 捷安客户号 */
	@Value("${jiean.verify.cust.id}")
	private String custId;
	/** 捷安秘钥 */
	@Value("${jiean.verify.mac}")
	private String mac;
	/** 是否是正式环境 */
	@Value("${is.formal}")
	private String isFormal;

	@Autowired
	private BankDao bankDao;
	@Autowired
	private CurrencyDao currencyDao;
	@Autowired
	private ClientRedisUtil clientRedisUtil;
	@Autowired
	private ApplyPersonDao applyPersonDao;
	@Autowired
	private BankService bankService;
	@Autowired
	private XybContractDao xybContractDao;
	@Autowired
	private DepositBankDao depositBankDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, rollbackFor = Exception.class)
	public RestResponse jieAnVerifyAccount(JieAnVerifyParamDTO jieAnVerifyParamDTO, Long clientId) throws Exception {
		try {
			User user = SessionUtil.getLoginUser(User.class);
			// -- 捷安重复调用控制时长查询历史数据
			ParameterConfigDO parameterConfigDO = currencyDao
					.getParameter(ParameterConfigEnum.PARAMETER_CONFIG_07.getParameterCode());
			int time = 0;
			if (parameterConfigDO != null) {
				time = Integer.parseInt(parameterConfigDO.getParameterValue());
			}
			Map<String, Object> paraMap = new HashMap<>(6);
			paraMap.put("clientId", clientId);
			paraMap.put("cardId", jieAnVerifyParamDTO.getCARD_ID());
			paraMap.put("certId", jieAnVerifyParamDTO.getCERT_ID());
			paraMap.put("certName", jieAnVerifyParamDTO.getCERT_NAME());
			paraMap.put("mP", jieAnVerifyParamDTO.getMP());
			paraMap.put("time", time);
			// -- 防止重复鉴权
			JieAnResultDO jieAnResultDO = bankDao.getJieAnResult(paraMap);
			if (jieAnResultDO != null) {
				return analysis(jieAnResultDO);
			} else {
				// -- 组装捷安参数
				JieAnVerifyRequestDTO jieAnVerifyRequestDTO = assemble(jieAnVerifyParamDTO);
				List<NameValuePair> nvps = assembleHttp(jieAnVerifyRequestDTO);
				HttpPost httpPost = new HttpPost(url);
				httpPost.setEntity(new UrlEncodedFormEntity(nvps, StandardCharsets.UTF_8));
				// -- 添加请求日志
				JieAnLogDO jieAnPortLog = new JieAnLogDO();
				jieAnPortLog.setOrderId(jieAnVerifyRequestDTO.getOrdId());
				jieAnPortLog.setReqPmt(nvps.toString());
				jieAnPortLog.setCreateUser(user.getId());
				bankDao.addJieAnPortLog(jieAnPortLog);
				// 发送捷安并解析数据 并添加返回记录
				jieAnResultDO = sendPost(httpPost, clientId, user.getId(), jieAnPortLog);
				// -- 添加捷安返回数据记录
				if (jieAnResultDO != null) {
					bankDao.insertJieAnResult(jieAnResultDO);
				}
				return analysis(jieAnResultDO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("调用捷安接口异常:" + e);
			return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
		}
	}

	@Override
	public RestResponse getBankInfoByBankId(String bankCard) throws Exception {
		if (StringUtils.isNullOrEmpty(bankCard)) {
			return new RestResponse(NativeMsgErrCode.NO_NULL_BANKCARD);
		}
		Long bankId = getBANKID(bankCard);
		if (bankId == null) {
			return new RestResponse(NativeMsgErrCode.NO_VALID_BANKCARD);
		}
		XybBankCodeDO queryDo = new XybBankCodeDO();
		queryDo.setBankId(bankId);
		XybBankCodeDO bankCodeDO = bankDao.getBankIconByBankID(queryDo);
		if (bankCodeDO == null) {
			return new RestResponse(NativeMsgErrCode.NO_VALID_BANKCARD);
		} else {
			return new RestResponse(MsgErrCode.SUCCESS, bankCodeDO);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public RestResponse queryBankIcon() throws Exception {
		List<XybBankCodeDO> list;
		if (RedisUtil.exists(RedisConstant.CAPP_BANKLIST)) {
			list = RedisUtil.get(RedisConstant.CAPP_BANKLIST, List.class);
		} else {
			list = bankDao.queryBankIcon();
			if (list != null) {
				RedisUtil.setex(RedisConstant.CAPP_BANKLIST, list);
			}
		}
		if (list == null || list.size() == 0) {
			return new RestResponse(MsgErrCode.SUCCESS);
		} else {
			return new RestResponse(MsgErrCode.SUCCESS, list);
		}
	}

	@Override
	public RestResponse getClientInfo() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		ClientAuthenticationDO authenticationDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(authenticationDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
			// -- 判断身份证是否过有效期
		} else if (authenticationDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(authenticationDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		} else {
			return new RestResponse(MsgErrCode.SUCCESS, authenticationDO);
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse tieOnCard(BankUpdateDTO bankUpdateDTO) throws Exception {
		// -- 上线打开
		if (CurrencyConstant.Y.equals(isFormal)) {
			if (!CheckBankCardUtil.checkBankCard(bankUpdateDTO.getBankCard())) {
				return new RestResponse(NativeMsgErrCode.ERROR_BANKCARD);
			}
		}
		User user = SessionUtil.getLoginUser(User.class);
		// -- 查询用户信息
		ClientAuthenticationDO applyClientInfoDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		if (applyClientInfoDO == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(applyClientInfoDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (applyClientInfoDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(applyClientInfoDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		// -- 根据银行卡类型查询银行卡信息
		XybBankCodeDO para = new XybBankCodeDO();
		para.setBankType(bankUpdateDTO.getBankType());
		XybBankCodeDO xybBankCodeDO = bankDao.getBankIconByBankID(para);
		if (xybBankCodeDO == null) {
			return new RestResponse(NativeMsgErrCode.NO_VALID_BANKCARD);
		}
		// -- 上线打开
		if (CurrencyConstant.Y.equals(isFormal)) {
			JieAnVerifyParamDTO jieAnVerifyParamDTO = new JieAnVerifyParamDTO();
			jieAnVerifyParamDTO.setCARD_ID(bankUpdateDTO.getBankCard());
			jieAnVerifyParamDTO.setCERT_ID(applyClientInfoDO.getIdCard());
			jieAnVerifyParamDTO.setCERT_NAME(applyClientInfoDO.getName());
			jieAnVerifyParamDTO.setMP(bankUpdateDTO.getPhone());
			jieAnVerifyParamDTO.setPROD_ID(PORD_ID);
			RestResponse response = bankService.jieAnVerifyAccount(jieAnVerifyParamDTO, applyClientInfoDO.getId());
			if (response.getResult() != 0) {
				return response;
			}
		}
		// -- 存入银行卡信息
		ClientBankInfoNoDO clientBankInfoNoDO = new ClientBankInfoNoDO();
		clientBankInfoNoDO.setClientId(applyClientInfoDO.getId());
		clientBankInfoNoDO.setBankRealName(applyClientInfoDO.getName());
		clientBankInfoNoDO.setBankIdcard(applyClientInfoDO.getIdCard());
		clientBankInfoNoDO.setBankNum(bankUpdateDTO.getBankCard());
		clientBankInfoNoDO.setBankName(xybBankCodeDO.getBankDes());
		clientBankInfoNoDO.setBankcardBankname(xybBankCodeDO.getBankDes());
		clientBankInfoNoDO.setPhone(bankUpdateDTO.getPhone());
		clientBankInfoNoDO.setBankId(bankUpdateDTO.getBankType());
		clientBankInfoNoDO.setIsDefault(SysDictEnum.YES.getCode());
		clientBankInfoNoDO.setState(SysDictEnum.YES.getCode());
		clientBankInfoNoDO.setCreateUser(user.getId());
		// -- 存入银行卡信息日志
		ClientBankLogDO clientBankLogDO = new ClientBankLogDO();
		clientBankLogDO.setClientId(applyClientInfoDO.getId());
		clientBankLogDO.setBusinessType(SysDictEnum.BANK_CARD_BUSINESS_TYPE_3105.getCode());
		JSONObject afterContent = new JSONObject();
		afterContent.put("idcard", applyClientInfoDO.getIdCard());
		afterContent.put("name", applyClientInfoDO.getName());
		afterContent.put("bankcard", bankUpdateDTO.getBankCard());
		afterContent.put("phone", bankUpdateDTO.getPhone());
		clientBankLogDO.setAfterContent(afterContent.toString());
		clientBankLogDO.setCreateUser(user.getId());
		// -- 变更合同表中的银行卡信息
		XybContractUpdateDTO xybContractDO = new XybContractUpdateDTO();
		xybContractDO.setClientId(applyClientInfoDO.getId());
		xybContractDO.setBankType(clientBankInfoNoDO.getBankId());
		xybContractDO.setBankAccount(applyClientInfoDO.getName());
		xybContractDO.setBankAccountOpen(xybBankCodeDO.getBankDes());
		xybContractDO.setRefundCardNum(clientBankInfoNoDO.getBankNum());
		xybContractDO.setMp(clientBankInfoNoDO.getPhone());
		xybContractDO.setCustName(applyClientInfoDO.getName());
		// -- 更换用户合同的银行卡信息
		xybContractDao.updateContractBankInfo(xybContractDO);
		bankDao.addClientBankInfoNo(clientBankInfoNoDO);
		bankDao.addClinetBankLog(clientBankLogDO);
		RedisUtil.del(RedisConstant.ORDER_USER_BANK_STATE + user.getLoginId());
		return new RestResponse(MsgErrCode.SUCCESS);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public RestResponse changeCard(BankUpdateDTO bankUpdateDTO) throws Exception {
		if (bankUpdateDTO.getBankId() == null) {
			return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
		}
		// -- 上线打开
		if (CurrencyConstant.Y.equals(isFormal)) {
			if (!CheckBankCardUtil.checkBankCard(bankUpdateDTO.getBankCard())) {
				return new RestResponse(NativeMsgErrCode.ERROR_BANKCARD);
			}
		}
		User user = SessionUtil.getLoginUser(User.class);
		// -- 查询用户信息
		ClientAuthenticationDO applyClientInfoDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		if (applyClientInfoDO == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_CUS);
		}
		// -- 判断用户是否实名认证
		if (CurrencyConstant.N.equals(applyClientInfoDO.getCertificationState())) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		// -- 判断身份证是否过有效期
		if (applyClientInfoDO.getIdCardEndTime() == null
				|| IdCardUtil.validationIdCard(applyClientInfoDO.getIdCardEndTime())) {
			return new RestResponse(NativeMsgErrCode.IDCARD_EXPIRED);
		}
		// -- 查询用户银行卡信息
		ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
		paraClient.setId(bankUpdateDTO.getBankId());
		paraClient.setState(SysDictEnum.YES.getCode());
		List<ClientBankInfoNoDO> list = bankDao.queryClientBankInFoNo(paraClient);
		if (list == null || list.size() == 0) {
			return new RestResponse(NativeMsgErrCode.NO_EXISTENCE);
		}
		if (list.get(0).getBankNum().equals(bankUpdateDTO.getBankCard())) {
			return new RestResponse(NativeMsgErrCode.CHANGE_SUCCESS);
		}
		// -- 根据银行卡类型查询银行卡信息
		XybBankCodeDO para = new XybBankCodeDO();
		para.setBankType(bankUpdateDTO.getBankType());
		XybBankCodeDO xybBankCodeDO = bankDao.getBankIconByBankID(para);
		if (xybBankCodeDO == null) {
			return new RestResponse(NativeMsgErrCode.NO_VALID_BANKCARD);
		}
		// -- 上线打开
		if (CurrencyConstant.Y.equals(isFormal)) {
			JieAnVerifyParamDTO jieAnVerifyParamDTO = new JieAnVerifyParamDTO();
			jieAnVerifyParamDTO.setCARD_ID(bankUpdateDTO.getBankCard());
			jieAnVerifyParamDTO.setCERT_ID(applyClientInfoDO.getIdCard());
			jieAnVerifyParamDTO.setCERT_NAME(applyClientInfoDO.getName());
			jieAnVerifyParamDTO.setMP(bankUpdateDTO.getPhone());
			jieAnVerifyParamDTO.setPROD_ID(PORD_ID);
			RestResponse response = bankService.jieAnVerifyAccount(jieAnVerifyParamDTO, applyClientInfoDO.getId());
			if (response.getResult() != 0) {
				return response;
			}
		}
		// -- 判断用户是否有过历史申请，如果没有直接执行换卡操作
		Map<String, Object> paraMap = new HashMap<>(1);
		paraMap.put("clientUserId", user.getId());
		paraMap.put("list", NodeStateConstant.CHANGE_CARD_LIST);
		Long applyId = applyPersonDao.getMainIdByClientUsrIdAndState(paraMap);
		// -- 直接执行换卡操作
		if (applyId == null) {
			// -- 修改银行卡信息
			ClientBankInfoNoDO ct = list.get(0);
			ct.setModifyUser(user.getId());
			ct.setBankRealName(applyClientInfoDO.getName());
			ct.setBankIdcard(applyClientInfoDO.getIdCard());
			ct.setBankNum(bankUpdateDTO.getBankCard());
			ct.setBankName(xybBankCodeDO.getBankDes());
			ct.setBankcardBankname(xybBankCodeDO.getBankDes());
			ct.setPhone(bankUpdateDTO.getPhone());
			ct.setBankId(bankUpdateDTO.getBankType());
			ct.setState(SysDictEnum.YES.getCode());
			// -- 新增银行卡信息日志
			ClientBankLogDO clientBankLogDO = new ClientBankLogDO();
			clientBankLogDO.setClientId(applyClientInfoDO.getId());
			clientBankLogDO.setBusinessType(SysDictEnum.BANK_CARD_BUSINESS_TYPE_3106.getCode());
			JSONObject afterContent = new JSONObject();
			afterContent.put("idcard", applyClientInfoDO.getIdCard());
			afterContent.put("name", applyClientInfoDO.getName());
			afterContent.put("bankcard", bankUpdateDTO.getBankCard());
			afterContent.put("phone", bankUpdateDTO.getPhone());
			clientBankLogDO.setAfterContent(afterContent.toString());
			JSONObject beforeContent = new JSONObject();
			beforeContent.put("idcard", paraClient.getBankIdcard());
			beforeContent.put("name", paraClient.getBankRealName());
			beforeContent.put("bankcard", paraClient.getBankNum());
			beforeContent.put("phone", paraClient.getPhone());
			clientBankLogDO.setBeforeContent(beforeContent.toString());
			clientBankLogDO.setCreateUser(user.getId());
			// -- 变更合同表中的银行卡信息
			XybContractUpdateDTO xybContractDO = new XybContractUpdateDTO();
			xybContractDO.setClientId(applyClientInfoDO.getId());
			xybContractDO.setBankType(ct.getBankId());
			xybContractDO.setBankAccount(applyClientInfoDO.getName());
			xybContractDO.setBankAccountOpen(xybBankCodeDO.getBankDes());
			xybContractDO.setRefundCardNum(ct.getBankNum());
			xybContractDO.setMp(ct.getPhone());
			xybContractDO.setCustName(applyClientInfoDO.getName());
			// -- 更换用户合同的银行卡信息
			xybContractDao.updateContractBankInfo(xybContractDO);
			bankDao.updateClientBankInFoNo(ct);
			bankDao.addClinetBankLog(clientBankLogDO);
			return new RestResponse(NativeMsgErrCode.CHANGE_SUCCESS);
		} else {
			// -- 存入银行卡申请表
			ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
			changeBankApplyDO.setClientId(applyClientInfoDO.getId());
			changeBankApplyDO.setBankInfoId(bankUpdateDTO.getBankId());
			changeBankApplyDO.setBankNum(bankUpdateDTO.getBankCard());
			changeBankApplyDO.setPhone(bankUpdateDTO.getPhone());
			changeBankApplyDO.setBankId(bankUpdateDTO.getBankType());
			changeBankApplyDO.setState(SysDictEnum.BANK_CARD_STATUS_3102.getCode());
			bankDao.addChangeBankApply(changeBankApplyDO);
			RedisUtil.del(RedisConstant.ORDER_USER_BANK_STATE + user.getLoginId());
			return new RestResponse(NativeMsgErrCode.CHANGE_APPLICATION_HAS_BEEN_SUBMITTED);
		}
	}

	@Override
	public RestResponse getBankCardInfo() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);

		BankCardInfoVO bankCardInfoVO = new BankCardInfoVO();
		DepositAccountStateVO stateVo = new DepositAccountStateVO();
		// -- 查询用户信息
		ClientAuthenticationDO applyClientInfoDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());

		if (applyClientInfoDO == null) {
			return new RestResponse(NativeMsgErrCode.UNIDENTIFIED_IDENTITY);
		}
		bankCardInfoVO.setCode(1);
		bankCardInfoVO.setName(applyClientInfoDO.getName());
		bankCardInfoVO.setIdCard(applyClientInfoDO.getIdCard().substring(0, 6) + "********"
				+ applyClientInfoDO.getIdCard().substring(applyClientInfoDO.getIdCard().length() - 4));
		// 获取存管账户
		DepositAccountStatementInfoDO infodo = depositBankDao
				.getDepositAccountStatementInfoOneSelect(applyClientInfoDO.getId());
		int flag = 0;
		if (null != infodo) {
			if (infodo.getIsValid() == (2487)) {
				bankCardInfoVO.setDepositState(stateVo);
				RestResponse response = new RestResponse();
				response.setData(bankCardInfoVO);
				response.setResult(0);
				response.setDescription("电子账户无效，请核实个人信息后，再绑定");
				response.setHttpcode(HttpStatus.OK);
				return response;
			}
			flag += 1;
			stateVo.setIsOpen(0);
			if (null != infodo.getClientBankId()) {
				ClientBankInfoNoDO clientBankInfoNo = bankDao.queryClientBankInFoNoById(infodo.getClientBankId());
				if (null != clientBankInfoNo) {
					flag += 1;
					stateVo.setIsBind(0);
					// -- 根据银行卡类型查询银行卡信息
					XybBankCodeDO para = new XybBankCodeDO();
					para.setBankType(clientBankInfoNo.getBankId());
					XybBankCodeDO xybBankCodeDO = bankDao.getBankIconByBankID(para);
					// -- 封装页面展示信息
					bankCardInfoVO.setBankName(clientBankInfoNo.getBankName());
					bankCardInfoVO.setBankType(clientBankInfoNo.getBankId());
					bankCardInfoVO.setBankNum(clientBankInfoNo.getBankNum().substring(0, 4) + "  ****  ****  "
							+ clientBankInfoNo.getBankNum().substring(clientBankInfoNo.getBankNum().length() - 4));
					bankCardInfoVO.setBankCode(xybBankCodeDO.getBankCode());
					bankCardInfoVO.setId(clientBankInfoNo.getId());
				}
			}

			if (null != infodo.getIsSign() && infodo.getIsSign() == 2486) {
				flag += 1;
				stateVo.setIsSign(0);
			}
			// 获取用户生效中的合同
			Long applyId = applyPersonDao.getApplyIdByClientUserIdToCheck(user.getId());
			if (null != applyId) {
				XybContractDO xybContractDO = xybContractDao.getXybContractDO(applyId);
				if (null != xybContractDO) {
					Long contractState = xybContractDO.getContractState();
					if (null != contractState && contractState == 2761) {
						flag += 1;
						stateVo.setIsValid(0);
					}
				}
			}
		}
		if (flag == 4) {
			bankCardInfoVO.setCode(0);
		}
		bankCardInfoVO.setDepositState(stateVo);
		return new RestResponse(MsgErrCode.SUCCESS, bankCardInfoVO);

	}

	@Override
	public RestResponse getBankCardState() throws Exception {
		User user = SessionUtil.getLoginUser(User.class);
		String key = RedisConstant.ORDER_USER_BANK_STATE + user.getLoginId();
		// -- 查询用户信息
		ClientAuthenticationDO applyClientInfoDO = clientRedisUtil.getClientAuthenticationDO(user.getLoginId());
		String bank;
		String idCard = "未实名";
		if (RedisUtil.exists(key)) {
			bank = RedisUtil.get(key);
		} else {
			if (applyClientInfoDO == null) {
				bank = "未绑卡";
			} else {
				// -- 查询用户银行卡信息
				ClientBankInfoNoDO paraClient = new ClientBankInfoNoDO();
				paraClient.setClientId(applyClientInfoDO.getId());
				paraClient.setState(SysDictEnum.YES.getCode());
				paraClient.setIsDefault(SysDictEnum.YES.getCode());
				List<ClientBankInfoNoDO> list = bankDao.queryClientBankInFoNo(paraClient);
				System.out.println(list != null ? list.size() : null);
				if (list == null || list.size() == 0) {
					bank = "未绑卡";
				} else {
					// -- 查询用户申请信息
					ChangeBankApplyDO changeBankApplyDO = new ChangeBankApplyDO();
					changeBankApplyDO.setClientId(applyClientInfoDO.getId());
					changeBankApplyDO.setBankInfoId(list.get(0).getId());
					List<ChangeBankApplyDO> applyDOList = bankDao.queryChangeBankApply(changeBankApplyDO);
					if (applyDOList == null || applyDOList.size() == 0) {
						bank = "已绑卡";
					} else {
						bank = "已绑卡";
						for (ChangeBankApplyDO c : applyDOList) {
							if (SysDictEnum.BANK_CARD_STATUS_3102.getCode().equals(c.getState())
									|| SysDictEnum.BANK_CARD_STATUS_3103.getCode().equals(c.getState())) {
								bank = "申请变更中";
								break;
							}
						}
					}
				}
			}
			RedisUtil.setex(key, bank);
		}
		if (CurrencyConstant.Y.equals(applyClientInfoDO.getCertificationState())) {
			if (IdCardUtil.validationIdCard(applyClientInfoDO.getIdCardEndTime())) {
				idCard = "认证已过期";
			} else {
				idCard = "已实名";
			}
		}
		JSONObject json = new JSONObject();
		json.put("bank", bank);
		json.put("idCard", idCard);
		return new RestResponse(MsgErrCode.SUCCESS, json);
	}

	/**
	 * ------------------------------------------------------------------内部提取方法-
	 * -----------------------------------------------------------------
	 */
	/**
	 * @description 查询所属银行
	 * @author xieqingyang
	 * @CreatedDate 2018/7/19 下午3:19
	 * @Version 1.0
	 * @param bankCard
	 *            银行卡号
	 * @return 返回bankId
	 */
	private Long getBANKID(String bankCard) {
		Long bankID = null;
		List<String> list = new ArrayList<String>();
		String a = bankCard.substring(0, 7);
		String b = bankCard.substring(0, 6);
		String c = bankCard.substring(0, 5);
		String d = bankCard.substring(0, 4);
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		for (String accountNum : list) {
			bankID = bankDao.getBankID(accountNum);
			if (bankID != null) {
				break;
			}
		}
		return bankID;
	}

	/**
	 * @description 组装捷安参数
	 * @author xieqingyang
	 * @CreatedDate 2018/7/19 下午12:36
	 * @Version 1.0
	 * @param jieAnVerifyParamDTO
	 *            需要的参数
	 * @return 返回组装好的数据
	 */
	private JieAnVerifyRequestDTO assemble(JieAnVerifyParamDTO jieAnVerifyParamDTO) {
		JieAnVerifyRequestDTO verifyRequest = new JieAnVerifyRequestDTO();
		verifyRequest.setVersionId("01");
		verifyRequest.setChrSet("UTF-8");
		verifyRequest.setCustId(custId);
		verifyRequest.setOrdId(getCurrentDate() + verifyRequest.getCustId() + getCurrentTime());
		verifyRequest.setTransType("STD_VERI");
		verifyRequest.setBusiType("");
		verifyRequest.setMerPriv("");
		verifyRequest.setRetUrl("");
		verifyRequest.setJsonStr(JSONObject.fromObject(jieAnVerifyParamDTO).toString());
		verifyRequest.setMacStr(getMacStr(verifyRequest, mac));
		return verifyRequest;
	}

	/**
	 * 根据请求参数域的值以及MAC_KEY生成MAC_STR字段的值
	 *
	 * @param verifyRequest
	 *            请求参数
	 * @param macKey
	 *            商户MAC_KEY值
	 * @return MAC_STR值
	 */
	private String getMacStr(JieAnVerifyRequestDTO verifyRequest, String macKey) {
		// 注意，顺序连接所有请求参数，连接顺序不可打乱
		StringBuilder allInputAreaParams = new StringBuilder();
		allInputAreaParams.append(verifyRequest.getVersionId());
		allInputAreaParams.append(verifyRequest.getChrSet());
		allInputAreaParams.append(verifyRequest.getCustId());
		allInputAreaParams.append(verifyRequest.getOrdId());
		allInputAreaParams.append(verifyRequest.getTransType());
		allInputAreaParams.append(verifyRequest.getBusiType());
		allInputAreaParams.append(verifyRequest.getMerPriv());
		allInputAreaParams.append(verifyRequest.getRetUrl());
		allInputAreaParams.append(verifyRequest.getJsonStr());
		String allInputAreaParamsStr = allInputAreaParams.toString();
		String md5SourceText = allInputAreaParamsStr + macKey;
		return DigestUtils.md5Hex(md5SourceText);
	}

	/**
	 * @description 封装http请求信息
	 * @author xieqingyang
	 * @CreatedDate 2018/7/19 下午12:43
	 * @Version 1.0
	 * @param verifyRequest
	 * @return
	 */
	private List<NameValuePair> assembleHttp(JieAnVerifyRequestDTO verifyRequest) throws UnsupportedEncodingException {
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("versionId", verifyRequest.getVersionId()));
		nvps.add(new BasicNameValuePair("chrSet", verifyRequest.getChrSet()));
		nvps.add(new BasicNameValuePair("custId", verifyRequest.getCustId()));
		nvps.add(new BasicNameValuePair("ordId", verifyRequest.getOrdId()));
		nvps.add(new BasicNameValuePair("transType", verifyRequest.getTransType()));
		nvps.add(new BasicNameValuePair("busiType", verifyRequest.getBusiType()));
		nvps.add(new BasicNameValuePair("merPriv", verifyRequest.getMerPriv()));
		nvps.add(new BasicNameValuePair("retUrl", verifyRequest.getRetUrl()));
		nvps.add(new BasicNameValuePair("jsonStr", verifyRequest.getJsonStr()));
		nvps.add(new BasicNameValuePair("macStr", verifyRequest.getMacStr()));
		return nvps;
	}

	/**
	 * @description 发送捷安并解析数据
	 * @author xieqingyang
	 * @CreatedDate 2018/7/19 下午12:52
	 * @Version 1.0
	 * @param httpPost
	 *            请求体数据
	 * @param clientId
	 *            用户信息表ID
	 * @param userId
	 *            用户登录信息表ID
	 * @return 返回解析后的数据
	 */
	private JieAnResultDO sendPost(HttpPost httpPost, Long clientId, Long userId, JieAnLogDO jieAnPortLog)
			throws IOException, DocumentException {
		JieAnResultDO jieAnResult = null;
		// 发送请求
		HttpClient client = HttpClientBuilder.create().build();
		// DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
		HttpResponse httpResponse = client.execute(httpPost);
		StringBuilder responseXmlText = new StringBuilder();
		BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent()), "UTF-8"));
		String output;
		while ((output = br.readLine()) != null) {
			responseXmlText.append(output);
		}
		// 解析返回数据入库
		String resqStr = responseXmlText.toString();
		log.info("捷安返回数据:" + resqStr);
		if (!"<respCode>999</respCode><respDesc>系统繁忙</respDesc>".equals(resqStr)) {
			// -- 解析捷安数据
			Document reqDoc = DocumentHelper.parseText(resqStr);
			Element msgEl = reqDoc.getRootElement();
			String respCode = msgEl.elementTextTrim("respCode");
			String respDesc = msgEl.elementTextTrim("respDesc");
			String versionId = msgEl.elementTextTrim("versionId");
			String custId = msgEl.elementTextTrim("custId");
			String ordId = msgEl.elementTextTrim("ordId");
			String transType = msgEl.elementTextTrim("transType");
			String merPriv = msgEl.elementTextTrim("merPriv");
			String jsonStr = msgEl.elementTextTrim("jsonStr");
			String resTxnId = msgEl.elementTextTrim("resTxnId");
			String macStr = msgEl.elementTextTrim("macStr");
			JSONObject json = JSONObject.fromObject(jsonStr);
			jieAnResult = new JieAnResultDO();
			jieAnResult.setClientId(clientId);
			jieAnResult.setVersionId(versionId);
			jieAnResult.setCustId(custId);
			jieAnResult.setOrderId(ordId);
			jieAnResult.setTransType(transType);
			jieAnResult.setMerPriv(merPriv);
			jieAnResult.setCardId(json.getString("CARD_ID"));
			jieAnResult.setCertId(json.getString("CERT_ID"));
			jieAnResult.setCertName(json.getString("CERT_NAME"));
			jieAnResult.setProdId(json.getString("PROD_ID"));
			jieAnResult.setmP(json.getString("MP"));
			jieAnResult.setRespCode(respCode);
			jieAnResult.setRespDesc(respDesc);
			jieAnResult.setResTxnId(resTxnId);
			jieAnResult.setMacStr(macStr);
			jieAnResult.setCreateUser(userId);
		}
		// -- 添加返回日志记录
		jieAnPortLog.setRespPmt(resqStr);
		jieAnPortLog.setModifyUser(userId);
		bankDao.updateJieAnPortLog(jieAnPortLog);
		return jieAnResult;
	}

	/**
	 * 获取系统当前日期，格式yyyyMMdd
	 */
	private String getCurrentDate() {
		Date nowDate = new Date();
		DateFormat sipleDateFormat = new SimpleDateFormat("yyyyMMdd");
		return sipleDateFormat.format(nowDate);
	}

	/**
	 * 获取系统当前时间，格式HHmmss
	 */
	private String getCurrentTime() {
		Date nowDate = new Date();
		DateFormat sipleDateFormat = new SimpleDateFormat("HHmmss");
		return sipleDateFormat.format(nowDate);
	}

	/**
	 * @description 解析捷安数据
	 * @author xieqingyang
	 * @CreatedDate 2018/7/19 下午12:59
	 * @Version 1.0
	 * @param jieAnResultDO
	 *            捷安返回的数据
	 * @return
	 */
	private RestResponse analysis(JieAnResultDO jieAnResultDO) {
		RestResponse response;
		if (jieAnResultDO == null) {
			response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription("系统繁忙，请稍后重试！");
			return response;
		}
		if ("000".equals(jieAnResultDO.getRespCode())) {
			return new RestResponse(MsgErrCode.SUCCESS);
		} else {
			response = new RestResponse(MsgErrCode.FAIL);
			response.setDescription(jieAnResultDO.getRespDesc());
			return response;
		}
	}
}
