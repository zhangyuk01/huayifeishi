package com.xyb.order.common.bank.dao;

import com.xyb.order.common.bank.model.*;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * 银行卡相关操作
 * 
 * @author xieqingyang
 * @date 2018/7/18 下午9:19
 */
public interface BankDao {

	/**
	 * 添加捷安访问日志
	 * 
	 * @author xieqingyang
	 * @date 2018/7/18 下午10:07
	 * @version 1.0
	 * @param jieAnLogDO
	 *            捷安日志表映射model
	 * @return 返回执行结果
	 */
	int addJieAnPortLog(JieAnLogDO jieAnLogDO);

	/**
	 * 修改捷安访问日志
	 * 
	 * @author xieqingyang
	 * @date 2018/7/18 下午10:07
	 * @version 1.0
	 * @param jieAnLogDO
	 *            捷安日志表映射model
	 * @return 返回执行结果
	 */
	int updateJieAnPortLog(JieAnLogDO jieAnLogDO);

	/**
	 * 捷安解析数据存库
	 * 
	 * @author xieqingyang
	 * @date 2018/7/19 上午9:59
	 * @version 1.0
	 * @param jieAnResultDO
	 *            解析的数据
	 * @return 返回执行结果
	 */
	int insertJieAnResult(JieAnResultDO jieAnResultDO);

	/**
	 * 查询符合规则的捷安数据
	 * 
	 * @author xieqingyang
	 * @date 2018/7/19 上午10:44
	 * @version 1.0
	 * @param paraMap
	 *            传入参数
	 * @return 返回捷安结果
	 */
	JieAnResultDO getJieAnResult(Map<String, Object> paraMap);

	/**
	 * 获取bankId
	 * 
	 * @author xieqingyang
	 * @date 2018/7/19 下午3:13
	 * @version 1.0
	 * @param bankCard
	 *            银行卡号
	 * @return 返回bankId
	 */
	Long getBankID(String bankCard);

	/**
	 * 根据银行卡已知信息查询银行卡信息
	 * 
	 * @author xieqingyang
	 * @date 2018/7/19 下午3:15
	 * @version 1.0
	 * @param codeDO
	 *            银行卡查询信息
	 * @return 返回银行卡信息
	 */
	XybBankCodeDO getBankIconByBankID(XybBankCodeDO codeDO);

	/**
	 * 获取支持的银行卡列表
	 * 
	 * @author xieqingyang
	 * @date 2018/7/19 下午4:13
	 * @version 1.0
	 * @return 返回银行卡列表信息
	 */
	List<XybBankCodeDO> queryBankIcon();

	/**
	 * 添加银行卡申请
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:21
	 * @version 1.0
	 * @param changeBankApplyDO
	 *            银行卡申请信息
	 * @return 返回执行结果
	 */
	int addChangeBankApply(ChangeBankApplyDO changeBankApplyDO);

	/**
	 * 修改银行卡申请状态
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:22
	 * @version 1.0
	 * @param changeBankApplyDO
	 *            银行卡申请信息
	 * @return 返回执行结果
	 */
	int updateChangeBankApply(ChangeBankApplyDO changeBankApplyDO);

	/**
	 * 查询银行卡申请信息
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:23
	 * @version 1.0
	 * @param changeBankApplyDO
	 *            查询条件
	 * @return 返回银行卡申请信息
	 */
	List<ChangeBankApplyDO> queryChangeBankApply(ChangeBankApplyDO changeBankApplyDO);

	/**
	 * 查询银行卡信息
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:26
	 * @version 1.0
	 * @param clientBankInfoNoDO
	 *            查询条件
	 * @return 返回银行卡信息
	 */
	List<ClientBankInfoNoDO> queryClientBankInFoNo(ClientBankInfoNoDO clientBankInfoNoDO);

	/**
	 * 添加用户银行卡信息
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:29
	 * @version 1.0
	 * @param clientBankInfoNoDO
	 *            需要添加的信息
	 * @return 返回执行结果
	 */
	int addClientBankInfoNo(ClientBankInfoNoDO clientBankInfoNoDO);

	/**
	 * 修改用户银行卡信息
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午3:31
	 * @version 1.0
	 * @param clientBankInfoNoDO
	 *            需要修改的用户银行卡信息
	 * @return 返回执行结果
	 */
	int updateClientBankInFoNo(ClientBankInfoNoDO clientBankInfoNoDO);

	/**
	 * 添加银行卡修改日志
	 * 
	 * @author xieqingyang
	 * @date 2018/7/20 下午4:11
	 * @version 1.0
	 * @param clientBankLogDO
	 *            银行卡修改信息
	 * @return 返回执行结果
	 */
	int addClinetBankLog(ClientBankLogDO clientBankLogDO);

	/**
	 * 获取银行信息
	 * 
	 * @param id
	 * @return
	 */
	ClientBankInfoNoDO queryClientBankInFoNoById(@Param("id") Long id);
}
