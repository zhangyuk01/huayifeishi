package com.xyb.order.common.otherplatformrelevant.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.utils.DateTimeUtil;
import com.xyb.credit.common.model.*;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.currency.dao.AuditCheckItemDao;
import com.xyb.order.common.currency.dao.CurrencyDao;
import com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 和其他平台相关业务实现
 * @author         xieqingyang
 * @date           2018/10/19 5:41 PM
*/
@Service(interfaceName = "com.xyb.order.common.otherplatformrelevant.service.OtherPlatformRelevantService")
public class OtherPlatformRelevantServiceImpl implements OtherPlatformRelevantService {

    @Autowired
    private AuditCheckItemDao auditCheckItemDao;
    @Autowired
    private CurrencyDao currencyDao;

    @Override
    public void insertCheckItem(Long primaryInfoId, Integer item) {
        if (primaryInfoId != null && item != null) {
            Map<String, Object> paraMap = new HashMap<>();
            paraMap.put("item", item);
            paraMap.put("primaryInfoId", primaryInfoId);
            int count = auditCheckItemDao.getCheckItemCount(paraMap);
            if (count < 1) {
                paraMap.put("user", CurrencyConstant.SYSTEM_USER);
                auditCheckItemDao.insertAuditCheckItem(paraMap);
            }
        }
    }

    @Override
    public SystemAuditParamDTO getSystemAuditParam(Long applyMainId, Integer state) {
        //组装系统审核参数
        SystemAuditParamDTO systemAuditParamDTO = new SystemAuditParamDTO();
        systemAuditParamDTO.setSubmitNode(String.valueOf(state));
        systemAuditParamDTO.setSubmitTime(DateTimeUtil.getDateTime());
        systemAuditParamDTO.setSys_id("gd");
        systemAuditParamDTO.setTerrace("jinjian");
        systemAuditParamDTO.setSubmitType("1");
        MainAppInfoBeanDTO mainAppInfoBeanDTO = new MainAppInfoBeanDTO();
        //获取申请单信息
        IndatainfoBeanDTO indatainfoBeanDTO = currencyDao.getApplyInfo(applyMainId);
        //获取审批产品期限信息
        XybProductExtDTO xybProductExtDTO = currencyDao.getProductExt(applyMainId);
        if (xybProductExtDTO != null) {
            indatainfoBeanDTO.setInterest_rate(xybProductExtDTO.getProductProportion());
            indatainfoBeanDTO.setService_rate(xybProductExtDTO.getServiceProportion());
        }
        mainAppInfoBeanDTO.setIndatainfo(indatainfoBeanDTO);
        //客户基本信息
        ClientInfoBeanDTO clientInfoBeanDTO = currencyDao.getClientInfo(indatainfoBeanDTO.getCus_id());
        mainAppInfoBeanDTO.setClientInfo(clientInfoBeanDTO);
        //获取工作信息
        JobInfoBeanDTO jobInfoBeanDTO = currencyDao.getJobInfo(indatainfoBeanDTO.getApply_id());
        mainAppInfoBeanDTO.setJobInfo(jobInfoBeanDTO);
        //获取联系人信息
        List<LinkmanInfoBeanDTO> list = currencyDao.getLinkManInfoList(indatainfoBeanDTO.getApply_id());
        mainAppInfoBeanDTO.setLinkmanInfo(list);
        //获取客户详细信息
        PersonalInfoBeanDTO personalInfoBeanDTO = currencyDao.getPersonalInfo(indatainfoBeanDTO.getApply_id());
        mainAppInfoBeanDTO.setPersonalInfo(personalInfoBeanDTO);
        //字典转换
        ThirdParam thirdParam = currencyDao.getThirdParam(indatainfoBeanDTO.getApply_id());
        mainAppInfoBeanDTO.setThirdParam(thirdParam);
        systemAuditParamDTO.setApplyMainId(String.valueOf(applyMainId));
        systemAuditParamDTO.setApply_id(String.valueOf(indatainfoBeanDTO.getApply_id()));
        systemAuditParamDTO.setApply_num(indatainfoBeanDTO.getApply_num());
        systemAuditParamDTO.setConsult_id(indatainfoBeanDTO.getConsult_id());
        systemAuditParamDTO.setCus_id(String.valueOf(indatainfoBeanDTO.getCus_id()));
        systemAuditParamDTO.setUnauthorized(indatainfoBeanDTO.getUnauthorized());
        systemAuditParamDTO.setUnauthorizedRemark(indatainfoBeanDTO.getUnauthorizedRemark());
        systemAuditParamDTO.setMainAppInfo(mainAppInfoBeanDTO);
        return systemAuditParamDTO;
    }

    @Override
    public Boolean getAndInsertMessageConsumeLog(Map<String, Object> map) {
        Boolean mark = false;
        int count = currencyDao.getMessageConsumeLog(map);
        if (count > 0) {
            mark = true;
        } else {
            currencyDao.addMessageConsumeLog(map);
        }
        return mark;
    }

    @Override
    public void addCheatInterfaceLog(CheatInterfaceLogDO cheatInterfaceLogDO) {
        currencyDao.addCheatInterfaceLog(cheatInterfaceLogDO);
    }

    @Override
    public JSONObject getFxtbJson(Long mainId, String remark, Long modifyUserId, String modifyUserName) {
        Map<String,Object> map = currencyDao.getFxtbJson(mainId);
        JSONObject fxtbJson = new JSONObject();
        fxtbJson.put("applyId",map.get("applyId"));
        fxtbJson.put("applyNum",map.get("applyNum"));
        fxtbJson.put("cheatChannel",136);
        JSONArray fieldList = new JSONArray();
        if (map.get("idCard") != null){
            JSONObject idCard = new JSONObject();
            idCard.put("idCard",map.get("idCard"));
            fieldList.add(idCard);
        }
        if (map.get("phone") != null){
            JSONObject phone = new JSONObject();
            phone.put("phone",map.get("phone"));
            fieldList.add(phone);
        }
        fxtbJson.put("fieldList",fieldList);
        fxtbJson.put("remark",remark);
        fxtbJson.put("createUser",modifyUserId);
        fxtbJson.put("createUserName",modifyUserName);
        return fxtbJson;
    }
}
