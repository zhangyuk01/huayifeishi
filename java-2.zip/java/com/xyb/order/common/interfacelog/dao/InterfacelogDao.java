package com.xyb.order.common.interfacelog.dao;

import java.util.List;
import java.util.Map;

import com.xyb.order.pc.contract.model.InterfaceLogDO;


public interface InterfacelogDao {
	
	List<InterfaceLogDO> queryInterfaceLogs(Map<String, Object> map);
	
	/**
     * 添加接口日志数据
     *
     * @param interfaceLogDO
     */
    void addInterfaceLog(InterfaceLogDO interfaceLogDO);

}
