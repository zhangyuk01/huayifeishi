package com.xyb.order.common.agreement.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.utils.JsonUtils;
import com.xyb.order.app.client.authorization.dao.AuthorizationDao;
import com.xyb.order.app.client.authorization.model.AgreementInFoDO;
import com.xyb.order.app.client.authorization.model.AgreementListVO;
import com.xyb.order.common.agreement.model.*;
import com.xyb.order.common.agreement.service.AgreementService;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.constant.InterfaceLogConstants;
import com.xyb.order.common.constant.NodeStateConstant;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.HttpTools;
import com.xyb.order.common.util.SignMatchesUtil;
import com.xyb.order.pc.applybill.dao.ApplyBillInfoDao;
import com.xyb.order.pc.applybill.model.ApplyBillMainInfoDO;
import com.xyb.order.pc.contract.model.InterfaceLogDO;
import com.xyb.order.pc.ownuse.service.interfacelog.InterfaceLogOwnService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service(interfaceName = "com.xyb.order.common.agreement.service.AgreementService")
public class AgreementServiceImpl implements AgreementService {

    private static final Logger log = LoggerFactory.getLogger(AgreementServiceImpl.class);

    /**系统ID*/
    @Value("${sys.id}")
    private String sysid;
    /**接口签名密钥(深圳)*/
    @Value("${http.secret.key}")
    private String secretKey;
    /**签约查询地址(深圳)*/
    @Value("${query.loan.col.url}")
    private String queryLoanColUrl;

    @Autowired
    private InterfaceLogOwnService interfaceLogOwnService;
    @Autowired
    private AuthorizationDao authorizationDao;
    @Autowired
    private AgreementService agreementService;
    @Autowired
    private ApplyBillInfoDao applyBillInfoDao;

    @Override
    public ResultDTO<QueryLoanColResponseDTO> getContractAgreement(Long applyId) throws Exception{
        // -- 深证查找借款协议
        QueryLoanColDTO colDTO = new QueryLoanColDTO();
        colDTO.setSysId(Long.valueOf(sysid));
        colDTO.setApplyId(String.valueOf(applyId));
        SignedEntryDTO signedEntry = new SignedEntryDTO();
        signedEntry.setBody(colDTO);
        // -- 进行指定字段加签
        String sign = SignMatchesUtil.signEncode(signedEntry, secretKey);
        signedEntry.setSign(sign);
        // -- 推送深圳
        String dataJson = JsonUtils.toJSON(signedEntry);
        log.info("深圳查询签约协议接口开始,applyid:"+applyId+";请求参数："+ dataJson);
        String result = HttpTools.sendPost(queryLoanColUrl, dataJson,"utf-8");
        log.info("深圳查询签约协议接口结束,applyid:"+applyId+";返回参数："+result);
        /**日志存储*/
        InterfaceLogDO interfaceLogDO = new InterfaceLogDO();
        interfaceLogDO.setApply_id(applyId);
        interfaceLogDO.setInterface_name(InterfaceLogConstants.QUERY_LOAN_COL);
        interfaceLogDO.setInvocation(InterfaceLogConstants.INVOK_TYPE_2);
        interfaceLogDO.setRequest(dataJson);
        interfaceLogDO.setResponse(result);
        interfaceLogOwnService.addInterfaceLog(interfaceLogDO);
        // -- 结果转json
        JSONObject resultJson = JSONObject.fromObject(result);
        String code = resultJson.getString("code");
        String message = resultJson.getString("message");
        sign = resultJson.getString("sign");
        JSONObject body = resultJson.getJSONObject("body");
        JSONArray loanContract= new JSONArray();
        if (body.containsKey("loanContracts")){
            loanContract = body.getJSONArray("loanContracts");
        }
        List<ContractBriefDTO> contractBriefDTOS = new ArrayList<>();
        for (int i = 0;i<loanContract.size();i++){
            JSONObject jsonObject  = loanContract.getJSONObject(i);
            ContractBriefDTO contractBriefDTO = new ContractBriefDTO();
            contractBriefDTO.setDownload_url(jsonObject.getString("download_url"));
            contractBriefDTO.setViewpdf_url(jsonObject.getString("viewpdf_url"));
            contractBriefDTOS.add(contractBriefDTO);
        }
        ResultDTO<QueryLoanColResponseDTO> resultDTO = new ResultDTO<>();
        resultDTO.setCode(code);
        resultDTO.setMessage(message);
        resultDTO.setSign(sign);
        QueryLoanColResponseDTO queryLoanColResponseDTOResultDTO = (QueryLoanColResponseDTO)JSONObject.toBean(body,QueryLoanColResponseDTO.class);
        if (queryLoanColResponseDTOResultDTO != null) {
            queryLoanColResponseDTOResultDTO.setLoanContracts(contractBriefDTOS);
            resultDTO.setBody(queryLoanColResponseDTOResultDTO);
        }
        return resultDTO;
    }

    @Override
    public RestResponse queryAgreements(Long applyId) throws Exception {
        RestResponse response = new RestResponse(MsgErrCode.FAIL);
        // -- 判断是否是合同生效节点
        Map<String,Object> paraMap = new HashMap<>(5);
        paraMap.put("applyId",applyId);
        ApplyBillMainInfoDO applyBillMainInfoDO = applyBillInfoDao.getMainInfoByApplyNumOrApplyId(paraMap);
        if (applyBillMainInfoDO == null){
            log.error("查询主表数据异常:"+applyId);
            return response;
        }
        if (!NodeStateConstant.THE_ENTRY_INTO_FORCE_OF_THE_CONTRACT.equals(applyBillMainInfoDO.getState())){
            response = new RestResponse(MsgErrCode.SUCCESS);
            return response;
        }
        paraMap.put("cusId",applyBillMainInfoDO.getClientId());
        paraMap.put("isValid",SysDictEnum.IS_VALID.getCode());
        paraMap.put("type",SysDictEnum.LOAN_URL.getCode());
        // -- 查询《个人信息采集、查询、授权书》
        List<AgreementListVO> agreementListVOS = authorizationDao.queryAgreementInFos(paraMap);
        if (agreementListVOS == null || agreementListVOS.size() < 1){
            ResultDTO<QueryLoanColResponseDTO> queryLoanColResponseDTOResultDTO = agreementService.getContractAgreement(applyId);
            if(!String.valueOf(applyId).equals(queryLoanColResponseDTOResultDTO.getBody().getApplyId())){
                log.error("查询深圳借款协议接口返回申请单ID不匹配");
                return response;
            }
            if (!ResultDTO.SUCCESS.equals(queryLoanColResponseDTOResultDTO.getCode())){
                log.error("查询深圳借款协议接口返回失败");
                return response;
            }
            if (!ResultDTO.SUCCESS.equals(queryLoanColResponseDTOResultDTO.getCode())){
                log.error("查询深圳借款协议接口返回失败");
                return response;
            }
            List<ContractBriefDTO> loanContracts = queryLoanColResponseDTOResultDTO.getBody().getLoanContracts();
            if (loanContracts == null || loanContracts.size() < 1){
                log.error("查询深圳借款协议接口返回协议数为0");
                return response;
            }
            agreementListVOS = ansynis(applyId,applyBillMainInfoDO.getClientId(),queryLoanColResponseDTOResultDTO.getBody().getExpCount(),queryLoanColResponseDTOResultDTO.getBody().getActCount(),loanContracts);
            response = new RestResponse(MsgErrCode.SUCCESS,agreementListVOS);
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS,getName(agreementListVOS));
        }
        return response;
    }

    /**
     * 解析数据 并保存
     * @author      xieqingyang
     * @date        2018/10/19 10:19 AM
     * @version     1.0
     * @param expCount 应传协议份数
     * @param actCount 实际传协议份数
     * @param loanContracts 协议数据
     * @return 返回页面展示数据
     */
    private List<AgreementListVO> ansynis(Long applyId,Long cusId,Integer expCount,Integer actCount,List<ContractBriefDTO> loanContracts){
        // -- 是否需要保存
        boolean isBoo = expCount.equals(actCount);
        // -- 页面展示数据
        List<AgreementListVO> agreementListVOS = new ArrayList<>();
        // -- 待保存数据
        List<AgreementInFoDO> agreements = new ArrayList<>();
        // -- 遍历深圳返回数据
        for (int i = 0;i < loanContracts.size();i ++){
            AgreementListVO agreementListVO = new AgreementListVO();
            agreementListVO.setName("借款协议"+(i+1));
            agreementListVO.setLookAddress(loanContracts.get(i).getViewpdf_url());
            agreementListVO.setDownloadAddress(loanContracts.get(i).getDownload_url());
            agreementListVOS.add(agreementListVO);
            if (isBoo){
                AgreementInFoDO agreement = new AgreementInFoDO();
                agreement.setApplyId(applyId);
                agreement.setCusId(cusId);
                agreement.setDownloadAddress(loanContracts.get(i).getDownload_url());
                agreement.setLookAddress(loanContracts.get(i).getViewpdf_url());
                agreement.setAgreementType(SysDictEnum.LOAN_URL.getCode());
                agreement.setIsValid(SysDictEnum.IS_VALID.getCode());
                agreement.setCreateUser(CurrencyConstant.SYSTEM_USER);
                agreements.add(agreement);
            }
        }
        // -- 保存协议
        if (isBoo){
            authorizationDao.insertAgreementinFoList(agreements);
        }
        return agreementListVOS;
    }

    /**
     * 起名
     * @author      xieqingyang
     * @date        2018/10/19 10:36 AM
     * @version     1.0
     * @param agreementListVOS 待处理数据
     * @return 返回处理完成数据
     */
    private List<AgreementListVO> getName(List<AgreementListVO> agreementListVOS){
        for (int i = 0;i < agreementListVOS.size();i ++){
            agreementListVOS.get(i).setName("借款协议"+(i+1));
        }
        return agreementListVOS;
    }
}
