package com.xyb.order.common.message.service;

import com.xyb.order.common.util.StringUtils;
import com.xyb.order.common.util.youmeng.AndroidNotification;
import com.xyb.order.common.util.youmeng.PushClient;
import com.xyb.order.common.util.youmeng.android.AndroidBroadcast;
import com.xyb.order.common.util.youmeng.android.AndroidUnicast;
import com.xyb.order.common.util.youmeng.ios.IOSBroadcast;
import com.xyb.order.common.util.youmeng.ios.IOSUnicast;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 推送友盟
 * @author         xieqingyang
 * @date           2018/10/19 5:35 PM
*/
@Service
public class UMengSendUtil {

    private static final Logger log = LoggerFactory.getLogger(UMengSendUtil.class);

    /*——————————————————————————————————————————单播/列播——————————————————————————————————————————————*/
    /**ios*/
    public String sendIOSUnicast(String appkey,String appMasterSecret,String deviceToken,String title,String content,String url){
        String result = null;
        try {
            PushClient client = new PushClient();
            IOSUnicast unicast = new IOSUnicast(appkey,appMasterSecret);
            unicast.setDeviceToken(deviceToken);
            unicast.setAlert(title);
            unicast.setTestMode();
            unicast.setDescription(title);
//          unicast.setProductionMode();
            unicast.setTestMode();
            result = client.send(unicast);
        }catch (Exception e){
            log.info("友盟推送单播/列播消息失败："+e);
        }finally {
            return result;
        }
    }

    /**android*/
    public String sendAndroidUnicast(String appkey,String appMasterSecret,String deviceToken,String title,String content,String url){
        String result = null;
        try {
            PushClient client = new PushClient();
            AndroidUnicast unicast = new AndroidUnicast(appkey,appMasterSecret);
            unicast.setDeviceToken(deviceToken);
            unicast.setTicker(title);
            unicast.setTitle(title);
            unicast.setText(content);
            unicast.goAppAfterOpen();
            unicast.setDisplayType(AndroidNotification.DisplayType.NOTIFICATION);
            if (StringUtils.isNotNullAndEmpty(url)){
                unicast.setAfterOpenAction(AndroidUnicast.AfterOpenAction.go_url);
                unicast.setUrl(url);
            }
//          unicast.setProductionMode();
            unicast.setTestMode();
            result = client.send(unicast);
        }catch (Exception e){
            log.info("友盟推送单播/列播消息失败："+e);
        }finally {
            return result;
        }
    }

    /*————————————————————————————————————————————广播————————————————————————————————————————————*/
    /**ios*/
    public String sendIOSBroadcast(String appkey,String appMasterSecret,String title,String content,String url,Date startTime){
        String result = null;
        try {
            PushClient client = new PushClient();
            IOSBroadcast broadcast = new IOSBroadcast(appkey,appMasterSecret);
            broadcast.setAlert(title);
            broadcast.setTestMode();
            broadcast.setDescription(title);
            if (startTime != null){
                SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                broadcast.setStartTime(sd.format(startTime));
            }
//          broadcast.setProductionMode();
            broadcast.setTestMode();
            result = client.send(broadcast);
        }catch (Exception e){
            log.info("友盟推送广播消息失败："+e);
        }finally {
            return result;
        }
    }
    /**android*/
    public String sendAndroidBroadcast(String appkey,String appMasterSecret,String title,String content,String url,Date startTime){
        String result = null;
        try {
            PushClient client = new PushClient();
            AndroidBroadcast broadcast = new AndroidBroadcast(appkey,appMasterSecret);
            broadcast.setTicker(title);
            broadcast.setTitle(title);
            broadcast.setText(content);
            broadcast.setDescription(title);
            if (StringUtils.isNotNullAndEmpty(url)){
                broadcast.goUrlAfterOpen(url);
            }else {
                broadcast.goAppAfterOpen();
            }
            if (startTime != null){
                SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                broadcast.setStartTime(sd.format(startTime));
            }
            broadcast.setDisplayType(AndroidNotification.DisplayType.NOTIFICATION);
//          broadcast.setProductionMode();
            broadcast.setTestMode();
            return client.send(broadcast);
        }catch (Exception e){
            log.info("友盟推送广播消息失败："+e);
        }finally {
            return result;
        }
    }

    /*————————————————————————————————————————————解析————————————————————————————————————————————*/
    /**
     * @description 解析友盟结果
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午4:17
     * @Version     1.0
     * @param result 友盟结果
     * @return 返回deviceToken
     */
    public String parseResult(String result){
        String deviceToken = "";
        if (!StringUtils.isNullOrEmpty(result)){
            JSONObject resultJson = JSONObject.fromObject(result);
            if ("SUCCESS".equals(resultJson.getString("ret"))){
                deviceToken = resultJson.getJSONObject("data").getString("task_id");
            }
        }
        return deviceToken;
    }
}
