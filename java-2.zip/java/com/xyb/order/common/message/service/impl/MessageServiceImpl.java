package com.xyb.order.common.message.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.beiming.kun.framework.msg.MsgErrCode;
import com.beiming.kun.framework.msg.RestResponse;
import com.beiming.kun.redis.RedisUtil;
import com.beiming.kun.utils.JsonUtils;
import com.fr.third.v2.org.apache.poi.hssf.usermodel.HSSFWorkbook;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Cell;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Row;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Sheet;
import com.fr.third.v2.org.apache.poi.ss.usermodel.Workbook;
import com.fr.third.v2.org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.google.common.base.Joiner;
import com.xyb.auth.user.model.User;
import com.xyb.order.app.business.buser.model.ClientBuserDO;
import com.xyb.order.app.business.buser.service.dao.ClinetBuserModifyDao;
import com.xyb.order.app.client.cuser.dao.ClinetUserDao;
import com.xyb.order.app.client.cuser.model.ClientUserDO;
import com.xyb.order.common.constant.MqConstant;
import com.xyb.order.common.constant.RedisConstant;
import com.xyb.order.common.message.dao.MessageDao;
import com.xyb.order.common.message.model.*;
import com.xyb.order.common.message.service.MessageService;
import com.xyb.order.common.message.service.UMengSendUtil;
import com.xyb.order.common.msg.SysDictEnum;
import com.xyb.order.common.util.StringUtils;
import com.xyb.order.common.util.youmeng.PushClient;
import com.xyb.util.SessionUtil;
import com.xyb.order.common.constant.CurrencyConstant;
import com.xyb.order.common.msg.NativeMsgErrCode;
import com.xyb.order.common.util.MDClient;
import com.xyb.order.common.util.MessageCountStr;
import com.xyb.order.common.util.RandomUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @description:    消息相关
 * @author:         xieqingyang
 * @createDate:     2018/6/25 下午7:17
*/
@Service(interfaceName = "com.xyb.order.common.message.service.MessageService")
public class MessageServiceImpl implements MessageService{

    private static final Logger log = LoggerFactory.getLogger(MessageServiceImpl.class);

    @Value("${youmeng.bapp.key}")
    private String youmengBappKey;
    @Value("${youmeng.bapp.master.secret}")
    private String youmengBappMasterSecret;
    @Value("${youmeng.capp.key}")
    private String youmengCappKey;
    @Value("${youmeng.capp.master.secret}")
    private String youmengCappMasterSecret;
    /**是否是正式环境*/
    @Value("${is.formal}")
    private String isFormal;

    @Autowired
    private MessageDao messageDao;
    @Autowired
    private ClinetUserDao clinetUserDao;
    @Autowired
    private ClinetBuserModifyDao clinetBuserModifyDao;
    @Resource(name = "jmsQueueTemplate")
    private JmsTemplate jmsQueueTemplate;
    @Autowired
    private UMengSendUtil uMengSendUtil;

    /**——------——————————————————————————————————————————————————短信验证码————————————————————————————————————————————————————————————————————*/
    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse getMessageCode(SendMessageVerificationDTO messageDTO) throws Exception{
        int effectiveNum = 0;
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("messageTypeId",messageDTO.getMessageTypeId());
        paraMap.put("phone",messageDTO.getPhone());
        paraMap.put("create",getDateString());
        if (CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_102 == messageDTO.getMessageTypeId() || CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_103 == messageDTO.getMessageTypeId() || CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_104 == messageDTO.getMessageTypeId()
                || CurrencyConstant.MESSAGE_FREQUENCY_LIMIT_105 == messageDTO.getMessageTypeId()){
            if (messageDTO.getEffectiveNum() == null){
                effectiveNum = CurrencyConstant.MESSAGE_UP_COUNT;
            }
            int count = messageDao.queryMessageCount(paraMap);
            if (count >= effectiveNum){
                return new RestResponse(NativeMsgErrCode.EXCEED_UPPER_LIMIT);
            }
        }
        User user = SessionUtil.getLoginUser(User.class);
        paraMap.put("type",CurrencyConstant.MESSAGE_LIST_CURRENCY);
        // -- 查询短信模版
        MessageTemplateDO messageTemplate = messageDao.getMessageTemplateByType(paraMap);
        if (messageTemplate == null){
            return new RestResponse(NativeMsgErrCode.NO_TEMPLATES_AVAILABLE_FOR_TIME_BEING);
        }
        // -- 保存验证码
        Long userId = CurrencyConstant.SYSTEM_USER;
        String vCode = RandomUtil.getSix();
        String content = messageTemplate.getValue();
        content = content.replace("vCode", vCode);
        MessageCodeDTO messageCodeDTO = new MessageCodeDTO();
        messageCodeDTO.setPhone(messageDTO.getPhone());
        messageCodeDTO.setType(CurrencyConstant.MESSAGE_LIST_CURRENCY);
        messageCodeDTO.setCode(vCode);
        if (user != null && user.getId() != null){
            userId = user.getId();
            messageCodeDTO.setOperationUser(userId);
        }else {
            messageCodeDTO.setOperationUser(CurrencyConstant.SYSTEM_USER);
        }
        messageCodeDTO.setState(CurrencyConstant.MESSAGE_IS_VALID);
        int messageCodeCount = messageDao.addMessageCode(messageCodeDTO);
        if (messageCodeCount != 1){
            return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
        }
        paraMap.put("state", CurrencyConstant.CHANNEL_MESSAGE_NO_VALID);
        // -- 查询短信渠道商
        MessageChannelDO messageChannelDO = messageDao.getMessageChannelIsvalid(paraMap);
        if (messageChannelDO == null){
            return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
        }
        if (messageChannelDO.getId() == CurrencyConstant.MESSAGE_CHANNEL_MD){
            return sendMessageMD(messageChannelDO,messageDTO.getPhone(),content,messageTemplate,userId);
        }else {
            return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse getMessageCode(SendMessageCurrencyDTO messageDTO){
        Map<String,Object> paraMap = new HashMap<>();
        // -- 查询短信模版
        paraMap.put("id",messageDTO.getMessageTemplateId());
        MessageTemplateDO messageTemplate = messageDao.getMessageTemplateByType(paraMap);
        if (messageTemplate == null){
            return new RestResponse(NativeMsgErrCode.NO_TEMPLATES_AVAILABLE_FOR_TIME_BEING);
        }
        String content = messageTemplate.getValue();
        paraMap.clear();
        paraMap = messageDTO.getParaMap();
        for(String key:paraMap.keySet()){
            content = content.replace(key, (String)paraMap.get(key));
        }
        // -- 查询短信渠道商
        paraMap.put("state", CurrencyConstant.CHANNEL_MESSAGE_NO_VALID);
        MessageChannelDO messageChannelDO = messageDao.getMessageChannelIsvalid(paraMap);
        if (messageChannelDO == null){
            return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
        }
        if (messageChannelDO.getId() == CurrencyConstant.MESSAGE_CHANNEL_MD){
            return sendMessageMD(messageChannelDO,messageDTO.getPhone(),content,messageTemplate,messageDTO.getUserId());
        }else {
            return new RestResponse(NativeMsgErrCode.NO_AVAILABLE_CHANNEL_MERCHANTS);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RestResponse validateMessageCode(ValidMessageDTO validMessageDTO) throws Exception {
        User user = SessionUtil.getLoginUser(User.class);
        Map<String,Object> paraMap = new HashMap<>();
        paraMap.put("phone",validMessageDTO.getPhone());
        paraMap.put("code",validMessageDTO.getvCode());
        if (validMessageDTO.getValidTime() != null){
            paraMap.put("time",validMessageDTO.getValidTime());
        }
        if (CurrencyConstant.Y.equals(validMessageDTO.getState())){
            paraMap.put("create",getDateString());
        }
        paraMap.put("state",CurrencyConstant.MESSAGE_IS_VALID);
        MessageCodeDO messageCode = messageDao.getMessageCode(paraMap);
        if (messageCode != null){
            paraMap.put("loginId",user.getId());
            paraMap.put("state",CurrencyConstant.MESSAGE_NO_VALID);
            int count = messageDao.updateMessageCodeToInvalid(paraMap);
            if (count == 1) {
                return new RestResponse(MsgErrCode.SUCCESS);
            }else {
                return new RestResponse(NativeMsgErrCode.STATUS_CODE_SYSTEM_FAILED);
            }
        }else{
            return new RestResponse(NativeMsgErrCode.STATUS_CODE_USER_FAILED);
        }
    }

    @Override
    public RestResponse validateMessageCode(String phone, String vCode, Integer validTime, String state, Long userId) {
        Map<String,Object> paraMap = new HashMap<>(10);
        paraMap.put("phone",phone);
        paraMap.put("code",vCode);
        if (validTime != null){
            paraMap.put("time",validTime);
        }
        if (StringUtils.isNotNullAndEmpty(state) && CurrencyConstant.Y.equals(state)){
            paraMap.put("create",getDateString());
        }
        paraMap.put("state", CurrencyConstant.MESSAGE_IS_VALID);
        MessageCodeDO messageCode = messageDao.getMessageCode(paraMap);
        if (messageCode != null){
            paraMap.put("loginId",userId);
            paraMap.put("state",CurrencyConstant.MESSAGE_NO_VALID);
            int count = messageDao.updateMessageCodeToInvalid(paraMap);
            if (count >= 1) {
                return new RestResponse(MsgErrCode.SUCCESS);
            }else {
                return new RestResponse(NativeMsgErrCode.STATUS_CODE_SYSTEM_FAILED);
            }
        }else{
            return new RestResponse(NativeMsgErrCode.STATUS_CODE_USER_FAILED);
        }
    }

    /**
     * 漫道发送短信
     * @return
     */
    private RestResponse sendMessageMD(MessageChannelDO messageChannelDO,String phone,String content,MessageTemplateDO messageTemplate,long userId){
        String sn = messageChannelDO.getChannelKey();
        String password = messageChannelDO.getChannelPassword();
        String serviceURL = messageChannelDO.getChannelAddress();
        MDClient mdClient = null;
        try {
            mdClient = new MDClient(sn, password, serviceURL);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String messageText= null;
        try {
            messageText = URLEncoder.encode(content, "utf8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String resultMt = mdClient.mdsmssend(phone, messageText, "", "", "", "");
        // -- 保存短信发送记录
        SendMessageLogDTO sendMessageLog = new SendMessageLogDTO();
        sendMessageLog.setPhone(phone);
        sendMessageLog.setReturnValue(resultMt);
        sendMessageLog.setMessageChannel(String.valueOf(messageChannelDO.getId()));
        sendMessageLog.setMessageTemplateId(messageTemplate.getId());
        sendMessageLog.setMessageTypeId(messageTemplate.getMessageTypeId());
        sendMessageLog.setOperationUser(userId);
        sendMessageLog.setValueCount(String.valueOf(MessageCountStr.countSum(content)));
        int sendMessageLogCount = messageDao.addSendMessageLog(sendMessageLog);
        if (sendMessageLogCount != 1){
            return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
        }
        // -- 判断短信接口是否调用成功
        boolean flag = mdClient.isNumeric(resultMt);
        if (flag){
            return new RestResponse(MsgErrCode.SUCCESS);
        }else{
            return new RestResponse(NativeMsgErrCode.SEND_MESSAGE_ERROR);
        }
    }

    /**
     * 获得当前时间年月日
     * @author      xieqingyang
     * @date        2018/10/19 5:28 PM
     * @version     1.0
     * @return 返回当前时间年月日
     */
    private String getDateString(){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.format(new Date());
    }
    /**——------——————————————————————————————————————————————————app推送消息————————————————————————————————————————————————————————————————————*/

    @Override
    public RestResponse addDeviceToken(DeviceTokenDTO deviceTokenDTO) throws Exception {
        RestResponse response;
        User user = SessionUtil.getLoginUser(User.class);
        String deviceToken = user.getDeviceToken();
        if (StringUtils.isNullOrEmpty(deviceToken) || !deviceTokenDTO.getDeviceToken().equals(deviceToken)){
            if ("B".equals(deviceTokenDTO.getAppType())){
                ClientBuserDO clientBuserDO = new ClientBuserDO();
                clientBuserDO.setDeviceToken(deviceToken);
                clientBuserDO.setLoginId(user.getLoginId());
                clinetBuserModifyDao.updateClientBuser(clientBuserDO);
                response = new RestResponse(MsgErrCode.SUCCESS);
            }else if ("C".equals(deviceTokenDTO.getAppType())){
                ClientUserDO clientUserDO = new ClientUserDO();
                clientUserDO.setDeviceToken(deviceTokenDTO.getDeviceToken());
                clientUserDO.setLoginName(user.getLoginId());
                clinetUserDao.updataClinetUser(clientUserDO);
                response = new RestResponse(MsgErrCode.SUCCESS);
            }else {
                response = new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
            }
        }else {
            response = new RestResponse(MsgErrCode.SUCCESS);
        }
        return response;
    }

    @Override
    public RestResponse queryNoticeList(Integer pageNumber, Integer pageSize,NoticeQueryDTO noticeQueryDTO) throws Exception {
        noticeQueryDTO.getPage().setPageSize(pageSize);
        noticeQueryDTO.getPage().setPageNumber(pageNumber);
        List<NoticeListVO> vos = messageDao.queryNoticeListPage(noticeQueryDTO);
        for (NoticeListVO vo:vos){
            if (StringUtils.isNotNullAndEmpty(vo.getTitle())){
                if ( vo.getTitle().length() > 10){
                    vo.setTitle(vo.getTitle().substring(0,10) + "...");
                }
                if (StringUtils.isNotNullAndEmpty(vo.getContent()) && vo.getContent().length() > 10){
                    vo.setContent(vo.getContent().substring(0,10) + "...");
                }
            }
        }
        noticeQueryDTO.getPage().setContents(vos);
        return new RestResponse(MsgErrCode.SUCCESS,noticeQueryDTO.getPage());
    }

    @Override
    public RestResponse getNoticeInfo(Long templateId) throws Exception {
        if (templateId == null){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        AppNoticeTemplateDO para = new AppNoticeTemplateDO();
        para.setId(templateId);
        AppNoticeTemplateDO appNoticeTemplateDO = messageDao.getAppNoticeTemplateDO(para);
        if (appNoticeTemplateDO == null){
            appNoticeTemplateDO = new AppNoticeTemplateDO();
        }
        return new RestResponse(MsgErrCode.SUCCESS,appNoticeTemplateDO);
    }

    @Override
    public RestResponse addNoticeInfo(AppNoticeTemplateAddDTO appNoticeTemplateAddDTO) throws Exception {
        if (!SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appNoticeTemplateAddDTO.getType()) && !SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateAddDTO.getType())){
            return new RestResponse(1,"通知类型填写错误");
        }
        if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateAddDTO.getType()) && (StringUtils.isNullOrEmpty(appNoticeTemplateAddDTO.getMessageFilePath()) || StringUtils.isNullOrEmpty(appNoticeTemplateAddDTO.getMessageFileName()))){
            return new RestResponse(1,"请上传附件");
        }
        if (!SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateAddDTO.getAppType()) && !SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateAddDTO.getAppType())){
            return new RestResponse(1,"app版本填写错误");
        }
        if (SysDictEnum.YES.getCode().equals(appNoticeTemplateAddDTO.getIsTiming()) && appNoticeTemplateAddDTO.getReleaseTime() == null){
            return new RestResponse(1,"请选择发布时间");
        }
        if (SysDictEnum.NO.getCode().equals(appNoticeTemplateAddDTO.getIsTiming()) && appNoticeTemplateAddDTO.getReleaseTime() != null){
            appNoticeTemplateAddDTO.setReleaseTime(null);
        }
        User user = SessionUtil.getLoginUser(User.class);
        appNoticeTemplateAddDTO.setCreateUser(user.getId());
        appNoticeTemplateAddDTO.setModifyUser(user.getId());
//        jmsQueueTemplate.convertAndSend(MqConstant.MESSAGE_QUEUE, JsonUtils.toJSON(appNoticeTemplateAddDTO));
        // -- 任务处理
        String appkey = null;
        String appMasterSecret = null;
        List<UserDTO> userDTOs;
        // -- 判断app版本类型
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateAddDTO.getAppType())){
            appkey = youmengCappKey;
            appMasterSecret = youmengCappMasterSecret;

        }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateAddDTO.getAppType())){
            appkey = youmengBappKey;
            appMasterSecret = youmengBappMasterSecret;
        }
        AppNoticeTemplateDO appNoticeTemplateDO = new AppNoticeTemplateDO();
        appNoticeTemplateDO.setState(SysDictEnum.IS_VALID.getCode());
        appNoticeTemplateDO.setType(appNoticeTemplateAddDTO.getType());
        appNoticeTemplateDO.setTitle(appNoticeTemplateAddDTO.getTitle());
        appNoticeTemplateDO.setContent(appNoticeTemplateAddDTO.getContent());
        appNoticeTemplateDO.setUrl(appNoticeTemplateAddDTO.getUrl());
        appNoticeTemplateDO.setAppType(appNoticeTemplateAddDTO.getAppType());
        appNoticeTemplateDO.setReleaseTime(appNoticeTemplateAddDTO.getReleaseTime());
        appNoticeTemplateDO.setIsTiming(appNoticeTemplateAddDTO.getIsTiming());
        appNoticeTemplateDO.setMessageFileName(appNoticeTemplateAddDTO.getMessageFileName());
        appNoticeTemplateDO.setMessageFilePath(appNoticeTemplateAddDTO.getMessageFilePath());
        appNoticeTemplateDO.setCreateUser(appNoticeTemplateAddDTO.getCreateUser());
        appNoticeTemplateDO.setModifyUser(appNoticeTemplateAddDTO.getModifyUser());
        // -- 公告
        if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appNoticeTemplateAddDTO.getType())){
//            String iosResult = uMengSendUtil.sendIOSBroadcast(appkey,appMasterSecret,appNoticeTemplateAddDTO.getTitle(),appNoticeTemplateAddDTO.getContent(),appNoticeTemplateAddDTO.getUrl(),SysDictEnum.YES.getCode().equals(appNoticeTemplateAddDTO.getIsTiming())?appNoticeTemplateAddDTO.getReleaseTime():null);
//            String andResult = uMengSendUtil.sendAndroidBroadcast(appkey,appMasterSecret,appNoticeTemplateAddDTO.getTitle(),appNoticeTemplateAddDTO.getContent(),appNoticeTemplateAddDTO.getUrl(),SysDictEnum.YES.getCode().equals(appNoticeTemplateAddDTO.getIsTiming())?appNoticeTemplateAddDTO.getReleaseTime():null);
//            appNoticeTemplateDO.setIosTaskId(uMengSendUtil.parseResult(iosResult));
//            appNoticeTemplateDO.setAndroidTaskId(uMengSendUtil.parseResult(andResult));
            messageDao.insertAppNoticeTemplate(appNoticeTemplateDO);
            // -- 通知
        }else if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateAddDTO.getType())){
            userDTOs = getUserInFos(appNoticeTemplateAddDTO.getMessageFilePath(),appNoticeTemplateAddDTO.getMessageFileName(),appNoticeTemplateAddDTO.getAppType());
            messageDao.insertAppNoticeTemplate(appNoticeTemplateDO);
            if (userDTOs != null) {
//                send(userDTOs,appkey,appMasterSecret,appNoticeTemplateAddDTO.getTitle(),appNoticeTemplateAddDTO.getContent(),appNoticeTemplateAddDTO.getUrl());
                List<AppNoticeDetailsDO> dos = new ArrayList<>();
                for (UserDTO userDTO:userDTOs){
                    AppNoticeDetailsDO appNoticeDetailsDO = new AppNoticeDetailsDO();
                    appNoticeDetailsDO.setMainId(appNoticeTemplateDO.getId());
                    appNoticeDetailsDO.setUserId(userDTO.getId());
                    appNoticeDetailsDO.setName(userDTO.getName());
                    appNoticeDetailsDO.setPhone(userDTO.getPhone());
                    appNoticeDetailsDO.setDeviceToken(userDTO.getDeviceToken());
                    appNoticeDetailsDO.setState(SysDictEnum.NO.getCode());
                    appNoticeDetailsDO.setTitle(appNoticeTemplateDO.getTitle());
                    appNoticeDetailsDO.setContent(appNoticeTemplateDO.getContent());
                    appNoticeDetailsDO.setUrl(appNoticeTemplateDO.getUrl());
                    appNoticeDetailsDO.setCreateUser(appNoticeTemplateDO.getCreateUser());
                    appNoticeDetailsDO.setModifyUser(appNoticeTemplateDO.getModifyUser());
                    dos.add(appNoticeDetailsDO);
                    delRedis(appNoticeTemplateDO,userDTO);
                }
                messageDao.insertAppNoticeDetails(dos);
            }
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    @Override
    public int getUserCount(List<String> list) {
        return messageDao.getUserCount(list);
    }

    @Override
    public int getClientUserCount(List<String> list) {
        return messageDao.getClientUserCount(list);
    }

    @Override
    public RestResponse revokeNotice(Long templateId) throws Exception {
        if (templateId == null){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        // -- 查询模版信息
        AppNoticeTemplateDO para = new AppNoticeTemplateDO();
        para.setId(templateId);
        AppNoticeTemplateDO appNoticeTemplateDO = messageDao.getAppNoticeTemplateDO(para);
        if (appNoticeTemplateDO == null){
            return new RestResponse(NativeMsgErrCode.UNMATCHED_TEMPLATE);
        }
        // -- 判断是否能够撤销
        if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appNoticeTemplateDO.getType()) && SysDictEnum.IS_VALID.getCode().equals(appNoticeTemplateDO.getState()) && SysDictEnum.YES.getCode().equals(appNoticeTemplateDO.getIsTiming()) && appNoticeTemplateDO.getReleaseTime() != null && new Date().before(appNoticeTemplateDO.getReleaseTime())){
            String appKey;
            String appMasterSecret;
            if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())){
                appKey = youmengCappKey;
                appMasterSecret = youmengCappMasterSecret;
            }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateDO.getAppType())){
                appKey = youmengBappKey;
                appMasterSecret = youmengBappMasterSecret;
            }else {
                return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
            }
            // -- 撤销ios
            RestResponse iosRes;
            if (StringUtils.isNullOrEmpty(appNoticeTemplateDO.getIosTaskId())){
                iosRes = new RestResponse(MsgErrCode.FAIL);
            }else {
                iosRes = sendAndParse(appKey,appNoticeTemplateDO.getIosTaskId(),appMasterSecret);
            }
            // -- 撤销android
            RestResponse androidRes;
            if (StringUtils.isNullOrEmpty(appNoticeTemplateDO.getAndroidTaskId())){
                androidRes = new RestResponse(MsgErrCode.FAIL);
            }else {
                androidRes = sendAndParse(appKey,appNoticeTemplateDO.getIosTaskId(),appMasterSecret);
            }
            if (iosRes.getResult() == 0 && androidRes.getResult() == 0){
                appNoticeTemplateDO.setState(SysDictEnum.NO_VALID.getCode());
                messageDao.updateAppNoticeTemplate(appNoticeTemplateDO);
                return new RestResponse(0,"撤销成功");
            }else if (iosRes.getResult() != 0 && androidRes.getResult() == 0){
                return new RestResponse(1,"ios撤销失败");
            }else {
                return new RestResponse(1,"android撤销失败");
            }
        }else {
            return new RestResponse(NativeMsgErrCode.CURRENT_MESSAGES_CANNOT_REVOKED);
        }
    }

    @Override
    public RestResponse test(String phone, String code) {
        if (CurrencyConstant.N.equals(isFormal)) {
            Map<String, Object> paraMap = new HashMap<>(2);
            paraMap.put("phone", phone);
            paraMap.put("code", code);
            messageDao.test(paraMap);
        }
        return new RestResponse(MsgErrCode.SUCCESS);
    }

    /**——------——————————————————————————————————————————————————app查询消息————————————————————————————————————————————————————————————————————*/
    @Override
    public RestResponse getMessageInFo(AppMessageQueryDTO appMessageQueryDTO) throws Exception {
        if (!SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appMessageQueryDTO.getAppType()) && !SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appMessageQueryDTO.getAppType())){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        if ((!SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appMessageQueryDTO.getType()) && !SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appMessageQueryDTO.getType()))){
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        AppMessageVO messageVO;
        User user = SessionUtil.getLoginUser(User.class);
        // -- 公告
        if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appMessageQueryDTO.getType())){
            messageVO = getappNOtice(appMessageQueryDTO);
        // -- 通知
        }else {
            appMessageQueryDTO.setUserId(user.getId());
            messageVO = getappMessage(appMessageQueryDTO);
        }
        return new RestResponse(MsgErrCode.SUCCESS,messageVO);
    }

    @Override
    public RestResponse getMessageList(AppMessageQueryDTO appMessageQueryDTO) throws Exception {
        if (appMessageQueryDTO.getPageNum() == null){
            return new RestResponse(NativeMsgErrCode.PAGE_NUM_NOT_NULL);
        }
        User user = SessionUtil.getLoginUser(User.class);
        appMessageQueryDTO.setUserId(user.getId());
        AppMessageListInFoVO appMessageListInFoVO;
        // -- 公告
        if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appMessageQueryDTO.getType())){
            appMessageListInFoVO = getappNOticeList(appMessageQueryDTO);
        // -- 消息
        }else if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appMessageQueryDTO.getType())){
            appMessageListInFoVO = getappMessageList(appMessageQueryDTO);
        }else {
            return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
        }
        return new RestResponse(MsgErrCode.SUCCESS,appMessageListInFoVO);
    }

    /**——------——————————————————————————————————————————————————对外接口————————————————————————————————————————————————————————————————————*/
    @Override
    public RestResponse sendMessage(Long templateId, String phone, Map<String, Object> paraMap,Long userId) {
        try {
            if (templateId == null){
                return new RestResponse(NativeMsgErrCode.PARAMETERS_ERROR);
            }
            if (phone == null){
                return new RestResponse(NativeMsgErrCode.NO_VALID_PHONE);
            }
            // -- 查询模版信息
            AppNoticeTemplateDO para = new AppNoticeTemplateDO();
            para.setId(templateId);
            AppNoticeTemplateDO appNoticeTemplateDO = messageDao.getAppNoticeTemplateDO(para);
            if (appNoticeTemplateDO == null){
                return new RestResponse(NativeMsgErrCode.UNMATCHED_TEMPLATE);
            }
            String appkey;
            String appMasterSecret;
            UserDTO userDTO = null;
            // -- 判断app版本类型
            if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())){
                appkey = youmengCappKey;
                appMasterSecret = youmengCappMasterSecret;
                if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateDO.getType()) && StringUtils.isNotNullAndEmpty(phone)){
                    userDTO = messageDao.getClientUser(phone);
                }
            }else{
                appkey = youmengBappKey;
                appMasterSecret = youmengBappMasterSecret;
                if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateDO.getType()) && StringUtils.isNotNullAndEmpty(phone)){
                    userDTO = messageDao.getUser(phone);
                }
            }
            if (userDTO == null){
                return new RestResponse(NativeMsgErrCode.NON_QUALIFIED_ACCOUNT);
            }
            String title = appNoticeTemplateDO.getTitle();
            String content = appNoticeTemplateDO.getContent();
            String url = appNoticeTemplateDO.getUrl();
            String deviceToken = userDTO.getDeviceToken();
            if (StringUtils.isNotNullAndEmpty(deviceToken)){
                // -- Android的device_token是44位字符串，iOS的device_token是64位
                if (deviceToken.length() == 44){
                    uMengSendUtil.sendAndroidUnicast(appkey,appMasterSecret,deviceToken,title,content,url);
                }else {
                    uMengSendUtil.sendIOSUnicast(appkey,appMasterSecret,deviceToken,title,content,url);
                }
            }
            // -- 添加用户消息
            List<AppNoticeDetailsDO> dos = new ArrayList<>();
            AppNoticeDetailsDO appNoticeDetailsDO = new AppNoticeDetailsDO();
            appNoticeDetailsDO.setMainId(templateId);
            appNoticeDetailsDO.setUserId(userDTO.getId());
            appNoticeDetailsDO.setName(userDTO.getName());
            appNoticeDetailsDO.setPhone(userDTO.getPhone());
            appNoticeDetailsDO.setDeviceToken(deviceToken);
            appNoticeDetailsDO.setState(SysDictEnum.NO.getCode());
            appNoticeDetailsDO.setTitle(title);
            appNoticeDetailsDO.setContent(content);
            appNoticeDetailsDO.setUrl(url);
            appNoticeDetailsDO.setCreateUser(userId);
            appNoticeDetailsDO.setModifyUser(userId);
            dos.add(appNoticeDetailsDO);
            messageDao.insertAppNoticeDetails(dos);
            // -- 删除用户缓存
            delRedis(userDTO.getId(),appNoticeTemplateDO.getAppType());
            return new RestResponse(MsgErrCode.SUCCESS);
        }catch (Exception e){
            log.info("友盟推送消息接口异常："+e);
            return new RestResponse(NativeMsgErrCode.SYSTEM_ABNORMALITY);
        }
    }
    /**——————————————————————————————————————————提取方法——————————————————————————————————————————————*/
    /**
     * @description 删除缓存数据
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午5:51
     * @Version     1.0
     * @param userId 用户ID
     * @param appType app类型
     */
    private void delRedis(Long userId,Long appType){
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appType)) {
            RedisUtil.delPre(RedisConstant.C_MESSAGE_USER + userId);
            RedisUtil.delPre(RedisConstant.C_LAST_MESSAGE_USER + userId);
        } else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appType)) {
            RedisUtil.delPre(RedisConstant.B_MESSAGE_USER + userId);
            RedisUtil.delPre(RedisConstant.B_LAST_MESSAGE_USER + userId);
        }
    }

    /**
     * @description 发送并解析撤销结果
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 上午10:33
     * @Version     1.0
     * @param appKey app标识
     * @param taskId 任务ID
     * @param appMasterSecret 应用的app_master_secret
     * @return 返回处理结果
     */
    private RestResponse sendAndParse(String appKey,String taskId,String appMasterSecret){
        JSONObject msg = new JSONObject();
        msg.put("appkey",appKey);
        msg.put("task_id",taskId);
        PushClient client = new PushClient();
        try {
            String result = client.send(msg,appMasterSecret);
            if (StringUtils.isNullOrEmpty(result)){
                return new RestResponse(MsgErrCode.FAIL);
            }else {
                net.sf.json.JSONObject resultJson = net.sf.json.JSONObject.fromObject(result);
                if ("SUCCESS".equals(resultJson.getString("ret"))){
                    return new RestResponse(MsgErrCode.SUCCESS);
                }else if ("FAIL".equals(resultJson.getString("ret"))){
                    return new RestResponse(1,resultJson.getJSONObject("data").getString("error_msg"));
                }else {
                    return new RestResponse(MsgErrCode.FAIL);
                }
            }
        } catch (Exception e) {
            log.info("推送友盟撤销消息失败：taskId"+taskId+";"+e);
            return new RestResponse(MsgErrCode.FAIL);
        }
    }

    /**查询app消息首页公告 信息辅助功能*/
    private AppMessageVO getappNOtice(AppMessageQueryDTO appMessageQueryDTO){
        AppMessageVO messageVO = new AppMessageVO();
        // -- c端
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.C_LAST_MESSAGE)){
                messageVO = RedisUtil.get(RedisConstant.C_LAST_MESSAGE,AppMessageVO.class);
            }else {
                messageVO = messageDao.getLastAppNoticeVO(appMessageQueryDTO.getAppType());
                if(messageVO == null) {messageVO = new AppMessageVO();}
                int count = messageDao.getAppNoticeCount(appMessageQueryDTO.getAppType());
                messageVO.setTotalNum(count);
                RedisUtil.set(RedisConstant.C_LAST_MESSAGE,JsonUtils.toJSON(messageVO));
            }
        }
        // -- b端
        if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.B_LAST_MESSAGE)){
                messageVO = RedisUtil.get(RedisConstant.B_LAST_MESSAGE,AppMessageVO.class);
            }else {
                messageVO = messageDao.getLastAppNoticeVO(appMessageQueryDTO.getAppType());
                if(messageVO == null) {messageVO = new AppMessageVO();}
                int count = messageDao.getAppNoticeCount(appMessageQueryDTO.getAppType());
                messageVO.setTotalNum(count);
                RedisUtil.set(RedisConstant.B_LAST_MESSAGE,JsonUtils.toJSON(messageVO));
            }
        }
        return messageVO;
    }

    /**查询app消息首页 信息辅助功能*/
    private AppMessageVO getappMessage(AppMessageQueryDTO appMessageQueryDTO){
        AppMessageVO messageVO = new AppMessageVO();
        // -- c端
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.C_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId())){
                messageVO = RedisUtil.get(RedisConstant.C_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId(),AppMessageVO.class);
            }else {
                messageVO = messageDao.getLastAppMessageVO(appMessageQueryDTO.getUserId());
                if(messageVO == null) {messageVO = new AppMessageVO();}
                int count = messageDao.getAppMessageCount(appMessageQueryDTO.getUserId());
                messageVO.setTotalNum(count);
                RedisUtil.set(RedisConstant.C_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId(),JsonUtils.toJSON(messageVO));
            }
        }
        // -- b端
        if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.B_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId())){
                messageVO = RedisUtil.get(RedisConstant.B_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId(),AppMessageVO.class);
            }else {
                messageVO = messageDao.getLastAppMessageVO(appMessageQueryDTO.getUserId());
                if(messageVO == null) {messageVO = new AppMessageVO();}
                int count = messageDao.getAppMessageCount(appMessageQueryDTO.getUserId());
                messageVO.setTotalNum(count);
                RedisUtil.set(RedisConstant.B_LAST_MESSAGE_USER+appMessageQueryDTO.getUserId(),JsonUtils.toJSON(messageVO));
            }
        }
        return messageVO;
    }

    /**查询app消息公告列表 信息辅助功能*/
    private AppMessageListInFoVO getappNOticeList(AppMessageQueryDTO appMessageQueryDTO){
        AppMessageListInFoVO info = new AppMessageListInFoVO();
        List<AppMessageListVO> list;
        // -- c端
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.C_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum())){
                info = RedisUtil.get(RedisConstant.C_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),AppMessageListInFoVO.class);
            }else {
                appMessageQueryDTO.setPageNum(appMessageQueryDTO.getPageNum()*10);
                list = messageDao.getAppNoticeList(appMessageQueryDTO);
                info.setList(list);
                int count = messageDao.getAppNoticeCount(appMessageQueryDTO.getAppType());
                if (count-(appMessageQueryDTO.getPageNum() + 1) * 10 >= 1){
                    info.setIsMore(CurrencyConstant.Y);
                }else {
                    info.setIsMore(CurrencyConstant.N);
                }
                RedisUtil.set(RedisConstant.C_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),JsonUtils.toJSON(info));
            }
        }
        // -- b端
        if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.B_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum())){
                info = RedisUtil.get(RedisConstant.B_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),AppMessageListInFoVO.class);
            }else {
                appMessageQueryDTO.setPageNum(appMessageQueryDTO.getPageNum()*10);
                list = messageDao.getAppNoticeList(appMessageQueryDTO);
                info.setList(list);
                int count = messageDao.getAppNoticeCount(appMessageQueryDTO.getAppType());
                if (count-(appMessageQueryDTO.getPageNum() + 1) * 10 >= 1){
                    info.setIsMore(CurrencyConstant.Y);
                }else {
                    info.setIsMore(CurrencyConstant.N);
                }
                RedisUtil.set(RedisConstant.B_MESSAGE+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),JsonUtils.toJSON(info));
            }
        }
        return info;
    }

    /**查询app消息列表 信息辅助功能*/
    private AppMessageListInFoVO getappMessageList(AppMessageQueryDTO appMessageQueryDTO){
        AppMessageListInFoVO info = new AppMessageListInFoVO();
        List<AppMessageListVO> list;
        // -- c端
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.C_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum())){
                info = RedisUtil.get(RedisConstant.C_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),AppMessageListInFoVO.class);
            }else {
                appMessageQueryDTO.setPageNum(appMessageQueryDTO.getPageNum()*10);
                list = messageDao.getAppMessageList(appMessageQueryDTO);
                info.setList(list);
                int count = messageDao.getAppMessageCount(appMessageQueryDTO.getAppType());
                if (count-(appMessageQueryDTO.getPageNum() + 1) * 10 >= 1){
                    info.setIsMore(CurrencyConstant.Y);
                }else {
                    info.setIsMore(CurrencyConstant.N);
                }
                RedisUtil.set(RedisConstant.C_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),JsonUtils.toJSON(info));
            }
        }
        // -- b端
        if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appMessageQueryDTO.getAppType())){
            if (RedisUtil.exists(RedisConstant.B_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum())){
                info = RedisUtil.get(RedisConstant.B_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),AppMessageListInFoVO.class);
            }else {
                appMessageQueryDTO.setPageNum(appMessageQueryDTO.getPageNum()*10);
                list = messageDao.getAppMessageList(appMessageQueryDTO);
                info.setList(list);
                int count = messageDao.getAppMessageCount(appMessageQueryDTO.getAppType());
                if (count-(appMessageQueryDTO.getPageNum() + 1) * 10 >= 1){
                    info.setIsMore(CurrencyConstant.Y);
                }else {
                    info.setIsMore(CurrencyConstant.N);
                }
                RedisUtil.set(RedisConstant.B_MESSAGE_USER+appMessageQueryDTO.getUserId()+"_"+appMessageQueryDTO.getPageNum(),JsonUtils.toJSON(info));
            }
        }
        return info;
    }

    /**
     * 解析附件内容 提取所有手机号
     * @author      xieqingyang
     * @date        2018/9/4 下午5:10
     * @version     1.0
     * @param filePath 文件路径
     * @param fileName 文件名称
     * @param appType app类型
     * @return 返回所有用户信息
     * @throws Exception 所有异常
     */
    private List<UserDTO> getUserInFos(String filePath,String fileName,Long appType) throws Exception {
        // -- 根据网络文件地址创建URL   
        URL url = new URL(filePath);
        //获取此路径的连接
        URLConnection conn = url.openConnection();
        // -- 构造读取流
        InputStream is = conn.getInputStream();
        Workbook wb = null;
        // -- 判断文件类型是否符合标准
        if(fileName.endsWith(".xls")) {
            wb = new HSSFWorkbook(is);
        }else if(fileName.endsWith(".xlsx")) {
            wb = new XSSFWorkbook(is);
        }
        // -- 手机号集合
        List<String> phones = new ArrayList<>();
        // 创建工作表sheet
        Sheet sheet = wb.getSheetAt(0);
        int rows = sheet.getPhysicalNumberOfRows();
        // 获取表头的单元格个数
        int cells = 1;
        //从第X行开始获取手机号
        for(int i = 2 ;i < rows; i++) {
            // 创建对象
            Row row = sheet.getRow(i);
            int index =0;
            while(index < cells){
                Cell cell = row.getCell(index);
                if(null == cell){
                    cell = row.createCell(index);
                }
                cell.setCellType(Cell.CELL_TYPE_STRING);
                String value =  (null == cell.getStringCellValue()?"":cell.getStringCellValue().trim().replace(" ",""));
                if (com.xyb.order.common.util.StringUtils.isNotNullAndEmpty(value)) {
                    phones.add(value);
                }
                index++;
            }
        }
        List<UserDTO> list = null;
        if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appType)){
            list = messageDao.getClientUserList(phones);
        }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appType)){
            list = messageDao.getUserList(phones);
        }
        return list;
    }

    /**
     * 发送友盟通知
     * @author      xieqingyang
     * @date        2018/9/4 下午5:34
     * @version     1.0
     * @param userDTOS 用户信息集合
     */
    private void send(List<UserDTO> userDTOS,String appkey,String appMasterSecret,String title,String content,String url){
        // -- 分离ios和android设备
        List<String> ios = new ArrayList<>();
        List<String> android = new ArrayList<>();
        for (UserDTO userDTO:userDTOS){
            if (com.beiming.kun.utils.StringUtils.isNotNullAndEmpty(userDTO.getDeviceToken())) {
                if (userDTO.getDeviceToken().length() == 44) {
                    android.add(userDTO.getDeviceToken());
                } else {
                    ios.add(userDTO.getDeviceToken());
                }
            }
        }
        // -- 友盟接口推送列播 上限500条一个组合  本系统400个为一个组合
        // -- 发送ios
        if (ios.size() > 0){
            int count = ios.size()/400+(ios.size()%400>0?1:0);
            for (int i = 0;i < count;i++){
                String devices = Joiner.on(",").join(ios.subList(i*400,(i+1)*400));
                uMengSendUtil.sendIOSUnicast(appkey, appMasterSecret, devices, title, content, url);
            }
        }
        // -- 发送android
        if (android.size() > 0){
            int count = android.size()/400+(android.size()%400>0?1:0);
            for (int i = 0;i < count;i++){
                String devices = Joiner.on(",").join(android.subList(i*400,(i+1)*400));
                uMengSendUtil.sendAndroidUnicast(appkey, appMasterSecret, devices, title, content, url);
            }
        }
    }


    /**
     * @description 删除缓存数据
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午5:51
     * @Version     1.0
     * @param appNoticeTemplateDO 消息模版数据
     * @param userDTO 用户数据
     */
    private void delRedis(AppNoticeTemplateDO appNoticeTemplateDO,UserDTO userDTO){
        if (appNoticeTemplateDO != null){
            // -- 公告
            if (SysDictEnum.NOTIFICATION_TYPE_NOTICE.getCode().equals(appNoticeTemplateDO.getType())){
                // -- c端
                if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())){
                    RedisUtil.delPre(RedisConstant.C_MESSAGE);
                    RedisUtil.del(RedisConstant.C_LAST_MESSAGE);
                }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateDO.getAppType())){
                    RedisUtil.delPre(RedisConstant.B_MESSAGE);
                    RedisUtil.del(RedisConstant.B_LAST_MESSAGE);
                }
            }else if (SysDictEnum.NOTIFICATION_TYPE_INFORM.getCode().equals(appNoticeTemplateDO.getType())){
                if (SysDictEnum.APP_TYPE_CLIENT.getCode().equals(appNoticeTemplateDO.getAppType())){
                    RedisUtil.delPre(RedisConstant.C_MESSAGE_USER+userDTO.getId());
                    RedisUtil.delPre(RedisConstant.C_LAST_MESSAGE_USER+userDTO.getId());
                }else if (SysDictEnum.APP_TYPE_BUSINESS.getCode().equals(appNoticeTemplateDO.getAppType())){
                    RedisUtil.delPre(RedisConstant.B_MESSAGE_USER+userDTO.getId());
                    RedisUtil.delPre(RedisConstant.B_LAST_MESSAGE_USER+userDTO.getId());
                }
            }
        }
    }
}
