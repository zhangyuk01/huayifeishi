package com.xyb.order.common.message.dao;

import com.xyb.order.common.message.model.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @description:    消息底层
 * @author:         xieqingyang
 * @createDate:     2018/6/25 下午8:29
*/
public interface MessageDao {

    /**——------——————————————————————————————————————————————————短信验证码————————————————————————————————————————————————————————————————————*/
    /**获取短信模板*/
    MessageTemplateDO getMessageTemplateByType(Map<String, Object> paraMap);
    /**获取有效渠道商*/
    MessageChannelDO getMessageChannelIsvalid(Map<String,Object> paraMap);
    /**保存短信验证码*/
    int addMessageCode(MessageCodeDTO messageCodeDTO);
    /**查询短信验证码*/
    MessageCodeDO getMessageCode(Map<String, Object> paraMap);
    /**保存短信日志*/
    int addSendMessageLog(SendMessageLogDTO sendMessageLogDTO);
    /**修改验证码状态*/
    int updateMessageCodeToInvalid(Map<String, Object> paraMap);
    /**查询当天发送的短信次数*/
    int queryMessageCount(Map<String,Object> paraMap);

    /**——------——————————————————————————————————————————————————app推送消息————————————————————————————————————————————————————————————————————*/

    /**
     * @description 查询APP消息推送明细表信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:23
     * @Version     1.0
     * @param appNoticeDetailsDO 传入参数
     * @return  返回APP消息推送明细表信息
     */
    List<AppNoticeDetailsDO> queryAppNoticeDetailsList(AppNoticeDetailsDO appNoticeDetailsDO);

    /**
     * @description 添加APP消息推送明细表信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:24
     * @Version     1.0
     * @param list APP消息推送明细表信息
     * @return  返回执行结果
     */
    int insertAppNoticeDetails(@Param("list") List<AppNoticeDetailsDO> list);

    /**
     * @description 修改APP消息推送明细表信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:24
     * @Version     1.0
     * @param appNoticeDetailsDO APP消息推送明细表信息
     * @return  返回执行结果
     */
    int updateAppNoticeDetails(AppNoticeDetailsDO appNoticeDetailsDO);

    /**
     * @description 查询APP消息模板信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:26
     * @Version     1.0
      * @param appNoticeTemplateDO APP消息模板信息
     * @return  APP消息模板信息
     */    
    AppNoticeTemplateDO getAppNoticeTemplateDO(AppNoticeTemplateDO appNoticeTemplateDO);

    /**
     * @description 添加APP消息模板信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:26
     * @Version     1.0
     * @param appNoticeTemplateDO APP消息模板信息
     * @return  返回执行结果
     */
    int insertAppNoticeTemplate(AppNoticeTemplateDO appNoticeTemplateDO);

    /**
     * @description 修改APP消息模板信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/25 下午8:26
     * @Version     1.0
     * @param appNoticeTemplateDO APP消息模板信息
     * @return 返回执行结果
     */
    int updateAppNoticeTemplate(AppNoticeTemplateDO appNoticeTemplateDO);

    /**
     * @description 查询pc消息列表
     * @author      xieqingyang
     * @CreatedDate 2018/6/27 上午10:04
     * @Version     1.0
     * @param noticeQueryDTO 传入参数
     * @return 返回列表数据
     */
    List<NoticeListVO> queryNoticeListPage(NoticeQueryDTO noticeQueryDTO);

    /**
     * @description 获取B端用户信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午2:59
     * @Version     1.0
     * @param phone 手机号
     * @return 用户信息
     */
    UserDTO getUser(String phone);

    /**
     * @description 获取C端用户信息
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午2:59
     * @Version     1.0
     * @param phone 手机号
     * @return 用户信息
     */
    UserDTO getClientUser(String phone);

    /**
     * @description 获取B端用户信息集合
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午2:59
     * @Version     1.0
     * @param list 手机号
     * @return 用户信息
     */
    List<UserDTO> getUserList(List<String> list);

    /**
     * @description 获取C端用户信息集合
     * @author      xieqingyang
     * @CreatedDate 2018/6/28 下午2:59
     * @Version     1.0
     * @param list 手机号
     * @return 用户信息
     */
    List<UserDTO> getClientUserList(List<String> list);

    /**
     * 获取B端用户信息数量
     * @author      xieqingyang
     * @date        2018/9/4 上午11:21
     * @version     1.0
     * @param list 手机号
     * @return 数量
     */
    int getUserCount(List<String> list);

    /**
     * 获取C端用户信息数量
     * @author      xieqingyang
     * @CreatedDate 2018/9/4 上午11:21
     * @Version     1.0
     * @param list 手机号
     * @return 用户信息
     */
    int getClientUserCount(List<String> list);

    /**测试*/
    int test(Map<String,Object> paraMap);
    /**——------——————————————————————————————————————————————————app查询消息使用————————————————————————————————————————————————————————————————————*/

    /**
     * @description 查询最新一条公告
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:43
     * @Version     1.0
     * @param appType app类型  2526-业务端  2527-客户端
     */
    AppMessageVO getLastAppNoticeVO(Long appType);

    /**
     * @description 查询公告总条数
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:44
     * @Version     1.0
     * @param appType app类型  2526-业务端  2527-客户端
     * @return 条数
     */
    int getAppNoticeCount(Long appType);

    /**
     * @description 查询公告列表
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:56
     * @Version     1.0
     */
    List<AppMessageListVO> getAppNoticeList(AppMessageQueryDTO messageQueryDTO);

    /**
     * @description 查询最新一条消息
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:43
     * @Version     1.0
     * @param userId 登录信息ID
     */
    AppMessageVO getLastAppMessageVO(Long userId);

    /**
     * @description 查询消息总条数
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:44
     * @Version     1.0
     * @param userId 登录信息ID
     * @return 条数
     */
    int getAppMessageCount(Long userId);

    /**
     * @description 查询消息列表
     * @author      xieqingyang
     * @CreatedDate 2018/6/29 下午3:56
     * @Version     1.0
     */
    List<AppMessageListVO> getAppMessageList(AppMessageQueryDTO messageQueryDTO);
}
